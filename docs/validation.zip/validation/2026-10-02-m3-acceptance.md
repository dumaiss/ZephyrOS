# M3 Device Registry and Static Drivers Acceptance — 2026-10-02

## Status

- **Host validation: PASS.** 117 host tests, reproducible clean rebuild,
  and a linked-byte replay of the complete M3 target self-test.
- **Physical Zephyr-80 validation: PASS (2026-10-02).** The acceptance
  image was programmed into the board; the captured transcript below
  shows the console service line, all embedded self-tests, and the
  interactive console RX round trip. **M3 is accepted.**

## Implemented

- Fixed 16-entry bank-7 device registry with kernel-issued handles
  (`1..16`, `0` invalid), capability lookup, duplicate/overflow/invalid
  rejection, and registration checkpoint/rollback transactions
  (`kernel/device/registry.c`, `include/zephyros/device.h`).
- Versioned driver ABI v1 exposing only `device_register`, `irq_claim`,
  and `irq_release`; explicit null-terminated `boot_drivers[]` table;
  ABI-mismatch rejection and per-driver rollback
  (`kernel/device/driver.c`, `include/zephyros/driver.h`).
- Polling SIO0/B static driver registering `sio0.b`
  (`ZDEV_SERIAL`, char + console capabilities) with bounded putc/write/
  poll/getc and explicit 115200 8N1 re-initialization
  (`drivers/sio/`).
- Console service with separate input/output handles, capability-based
  default binding, and explicit unbound/unsupported errors
  (`kernel/device/console.c`, `include/zephyros/console.h`).
- Test-only static IRQ probe driver claiming `IRQ_CTC0` through the driver
  ABI, delivering repeated bank-7 handler invocations via the M2
  executive, with release/quiesce afterwards
  (`drivers/test/irq_probe.c`).
- Fallback build options proving early-console independence:
  `ZOS_M3_NO_STATIC_DRIVERS` and `ZOS_M3_NO_CONSOLE_BIND`
  (`make m3-fallback`).
- mapcheck bank-7 placement rules for registry, console, descriptors,
  ops, handlers, and driver-private state, with a prefix sweep proving no
  driver implementation enters common memory.

## Host validation

```sh
make clean                         PASS
make                               PASS
make test                          PASS  117 tests (13 image-dependent
                                          tests skipped until the self-test
                                          images are built)
make check                         PASS  reproducible rebuild + full
                                          validation stack
make syscall-selftest              PASS
make irq-selftest                  PASS
make m3-selftest                   PASS
make m3-fallback                   PASS
final full unittest discovery      PASS  117 tests, 0 skipped
```

The final discovery run includes the M1 latch/map suites, the M2 focused
IRQ replay and `irq-selftest` driver replay, the syscall-gate replay, and
the new M3 suites (`tests/test_m3.py`, `tests/test_m3_sim.py`).

### Linked-byte replay evidence (`tests/test_m3_sim.py`)

The replay executes the real linked code from
`build-m3-selftest/zephyros-m3-selftest.bin`:

- boot C-runtime initialization (zero/copy/GSINIT), `irq_init()`,
  `device_registry_init()`, `driver_init_static()`,
  `console_bind_defaults()`;
- the full `zos_run_m3_selftest` C driver: empty-registry handles,
  capability iteration, duplicate/descriptor rejection, driver-table
  ABI rejection (`test.badabi` init never runs), partial-init rollback
  (`test.partial.a/.b` removed, earlier `sio0.b` intact), transaction
  checkpoint/rollback, 16-entry exhaustion without overwriting, console
  TX/RX through the captured SIO data port (one injected `R` byte),
  and CTC0 delivered to the bank-7 probe handler by the real M2 entry
  path with mode-11/ISR-stack evidence;
- a production `kernel_main` boot replay (connect delay skipped via its
  exported symbol) ending in the halt loop with the complete serial
  transcript: banner + `console: sio0.b OK`.

Focused checks additionally prove the SIO driver rewrites the documented
`18h, WR4=44h, WR3=C1h, WR5=EAh, WR1=00h` sequence and that both console
directions bind the single capability-matched `sio0.b` handle.

> Amendment (2026-10-03, during the M7 hardware phase): the console init
> was changed from `WR3=E1h/WR5=E8h` (auto-enables on, RTS released, TX
> gated by RR0 CTS) back to the original board-proven `WR3=C1h/WR5=EAh`
> (auto-enables off, RTS asserted, TX gated by TX-empty only) after bench
> findings that the old values let FT230X USB re-enumeration silently mute
> the console.  See `2026-10-03-m7-monitor.md`; the artifact hashes in
> this record predate the change.

## Artifact hashes

| Artifact | SHA-256 |
| --- | --- |
| `build/zephyros.bin` (normal) | `c8aa3cec5634950f030f1030a9bdc0beeb004e577e93dfba6604951dcc4c7dfe` |
| `build-selftest/zephyros-selftest.bin` | `d08fa095c135c2701dd5cd0354d5141efa39ff602132982445cd2036dce52b69` |
| `build-irq-selftest/zephyros-irq-selftest.bin` | `84ae1e856cdbea82bcf79c177bd4a4756c402d938467c6ac3e258b0d22b31aa2` |
| `build-m3-selftest/zephyros-m3-selftest.bin` | `3f837fda3d1928793c6f92e49c828937a3ab8057d855acd6b157c0fe0631d0e0` |
| `build-m3-nodrv/zephyros.bin` | `c823073cc35eca244f15a675f8d2a3cd75e010795227eb6b5b5525030432673e` |
| `build-m3-nobind/zephyros.bin` | `a48efe5ab123ccb704b6b3357c2b9d019d8d85c13470bfcc88062c7287d8125e` |

The normal image contains the console-service line and both fallback
diagnostics but not the self-test harness; each fallback image contains
only its own diagnostic and no `console: sio0.b OK`.

## M0-M2 regression

- The M0 banner is byte-identical (containment check on the normal image).
- `make syscall-selftest` and `make irq-selftest` still build and their
  linked-byte replays still pass (included in the 117 tests).
- No device-layer additions entered common memory: registry, console,
  drivers, and private state are all bank-7 (mapcheck-enforced).

## Physical Zephyr-80 validation — PASS (2026-10-02)

`build-m3-selftest/zephyros-m3-selftest.bin` (sha256
`3f837fda3d1928793c6f92e49c828937a3ab8057d855acd6b157c0fe0631d0e0`) was
programmed into the Zephyr-80 ROM device and captured through SIO0/B at
115200 8N1:

```sh
make smoke-hardware-m3 SERIAL_PORT=/dev/ttyUSB0
```

```text
serial_smoke: listening on /dev/ttyUSB0 at 115200 8N1 (mode=m3, timeout=15s)
serial_smoke: sent RX byte b'R'
serial_smoke: captured 223 bytes
serial_smoke: transcript follows
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
syscall selftest: OK
irq selftest: OK
console: sio0.b OK
m3 selftest: console TX OK
m3 selftest: ready for RX
m3 selftest: RX OK
m3 selftest: OK
serial_smoke: OK (the banner, console service line, syscall/irq/m3 self-tests,
and the console RX round trip)
```

This transcript proves on physical hardware:

- `sio0.b` was registered and selected solely by capabilities, and the
  distinct `console: sio0.b OK` line was emitted through the normal
  console service (not the early console);
- the console RX path received the operator's `R` byte and echoed RX OK;
- the static test driver claimed `IRQ_CTC0` through the driver ABI and
  its bank-7 handler was invoked repeatedly by the M2 executive
  (mode-11 + ISR-stack evidence inside the M3 self-test);
- registry error/rollback/exhaustion/ABI-rejection cases all passed on
  target without heap allocation;
- M0-M2 regressions intact: the exact banner, `syscall selftest: OK`,
  and `irq selftest: OK` all still appear in the same boot.

All M3 acceptance criteria in `docs/architecture.md` section 21 are met;
**M3 is accepted** (host checks plus physical-hardware observation).
