# KonaEdit TUI editor validation

## Result

Package 82 and all three hardware-driven corrections pass focused
standalone-consumer validation. The current executable is ready for the
owner's hardware retest; physical acceptance of the 0.1-second target remains
pending.

The first correction addressed slow ordinary editing and file-dialog controls,
leaked container `/` characters, and directory pagination. The second
correction addresses the remaining slow newline path and the process exit when
Open is activated. The third makes CP/M-padded text load correctly. None of the
corrections changes KonaOS, the console driver, the public SDK, or the TUI
library.

## Second correction

`src/ke_ui.c` now repaints only the affected logical-line tail after inserting
or removing a newline. It stops after the first row that clears stale content
or at the viewport boundary. Same-line edits repaint only the changed suffix.
The cursor line and visual column are computed once and reused by status and
caret rendering.

The Open exit was an XMEM allocation-order defect. A transactional Open needs
the old and fresh eight-object document stores to coexist, then must recreate
two contiguous four-slot history objects. Initializing the complete support
store (two clipboard objects followed by the two history objects) before the
startup document secures those four-slot history runs before the document's
independent allocations can fragment free space. It also makes the later
dispose/allocate/rebuild sequence deterministic. The document remains exactly
eight 8-KiB objects as required by the work contract.

The production-image replay exercises the reported path through the actual file
dialog: it types `PAGE00.TXT`, focuses and activates Open, verifies that `page`
appears in the editor, and finally verifies F10 returns to the shell. Thus an
Open regression cannot pass merely by testing the lower-level file loader.

## Third correction

The reported `/fs/cpm/b/dev/modula-2/list.mod` is 3,840 bytes, but its logical
text ends at byte 3,695. It then contains fifteen CP/M `1Ah` EOF/padding bytes,
followed by NULs and unrelated directory-entry data in the remainder of the
record. The raw `cat` output likewise exposes that trailing material.

The load normalizer now treats the first `1Ah` as logical EOF and does not
inspect later record padding. A NUL before logical EOF remains a binary-file
error. Save behavior is unchanged: KonaEdit writes CP850 document bytes with
Unix LF and does not append a CP/M marker.

Host coverage includes CR immediately before `1Ah`, repeated padding, a later
NUL, and trailing debris. The production-image replay starts a second editor
with the exact nested path, verifies `MODULE List;` and `END List.` as the first
two rows, and returns normally to the shell. Both startup load and the file
picker use this same corrected streaming loader.

## Validation scope

The correction reuses the already-built `build/kos-sdk-0.2.0.tar.gz`. The full
OS and unchanged TUI suites were not rerun: this is a standalone user-mode SDK
consumer, and the owner explicitly requested that unchanged suites not be
repeated.

The focused validation command is:

```sh
make -C UserSoftware/KonaEdit test
```

It covers the host store/history/text/file tests, four project and packaging
checks, and one production-image simulator replay. The project checks pin the
eight-object document geometry and the required executable/stack headroom.
The command passed all five discovered Python tests in 94.719 seconds, and the
host executable reported `KonaEdit store tests: OK`; there were no failures,
warnings, or skips.

## Measured behavior

The final production-image replay measured:

| Operation | Console renders | Z80 cycles |
| --- | ---: | ---: |
| ordinary character insertion | one, 75 bytes | 96,787 |
| newline insertion | one, 99 bytes | 124,873 |
| newline removal | one, 99 bytes | 125,182 |
| popup menu move | one, 78 bytes | 65,278 |
| file-list row move | one, 94 bytes | 73,483 |
| filename character | one, 17 bytes | 40,610 |
| directory page transition | full page plus namespace I/O | 529,285 |
| successful Open | load, allocation rebuild and full editor repaint | 964,167 |

The replay enforces a 150,000-cycle ceiling on ordinary insertion, newline
insertion, newline removal, file-list row movement, and filename entry. The
structural edit paths also enforce exactly one console render per key. The
directory transition and Open are intentionally not per-row or per-character
operations and include filesystem/XMEM work.

Before this correction, newline insertion measured 584,764 cycles and newline
removal 593,906 cycles, each with two render requests. The new paths reduce
those measurements by 78.6% and 78.9%, respectively. Simulator cycle counts
guide the software regression budget but do not replace physical latency
measurement.

The history regression independently types 25 consecutive characters and
observes one history XMEM write during typing plus one staged-tail flush on
Undo. Redo restores all 25 bytes. The UI replay also crosses the eighth-entry
directory boundary and verifies that the unobscured editor row remains exactly
`Xalpha`, with no leaked `/`.

## Resource budget and artifact

- Executable: `UserSoftware/KonaEdit/build/user/konaedit.exe`
- File size: 45,484 bytes
- Image size: 45,448 bytes
- BSS: 10,100 bytes
- Linked end: `D9FCh`
- Stack: 1,024 bytes at `DC00h-E000h`
- Headroom below stack: 516 bytes; required minimum: 512 bytes
- SHA-256:
  `defca465b912dc6cba219b3f221c78db3e2d91e6708fafe1d20ddff2bd5677cd`

The reduced overlay geometry is included in the BSS figure: the dialog save
area is 36 columns by 18 rows (1,296 bytes) and the popup save area is 18 by 9
rows (324 bytes). The fixed 1,024-byte stack and eight-object document contract
were not weakened to obtain the performance correction.

## Owner hardware checklist

- sustained ordinary typing at or below approximately 0.1 seconds per key;
- newline insertion and removal at or below approximately 0.1 seconds per key;
- filename typing and row selection at or below approximately 0.1 seconds per
  key;
- successful Open replaces the document without exiting the process;
- CP/M text with `1Ah` padding opens without exposing or rejecting later record
  debris;
- Down/Up and Page Down/Page Up cross an eight-entry boundary;
- container `/` suffixes remain inside the file dialog;
- edit, save, reopen, navigation, undo/redo and shell restoration continue to
  work.

Pre-existing `docs/architecture.md` and `docs/gfx-sdk.md` changes were not
edited or discarded.
