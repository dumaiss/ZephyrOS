# M9 nested exec — correction-01: memory placement and accounting

**Package:** `28-m9-nested-exec/correction-01` (2026-10-05)
**Scope:** three placement/accounting defects the supervisor logged against
the accepted package 28: a mode-11-only buffer parked in common memory, a
false claim about common memory being unreachable, and common-memory growth
that the `bank7:` ledger did not show.  Exec behavior is unchanged.

## 1. The `SYS_EXEC` path buffer moved to bank-7 `_DATA`

`_zos_process_path_scratch` (ZOS_PATH_MAX = 128 bytes) is now defined by
`kernel/process/process.c` as ordinary bank-7 runtime data:

```c
char zos_process_path_scratch[ZOS_PATH_MAX];
```

The assembly reservation and its `.globl` are gone from
`kernel/process/launch.asm`.  Both ends of its lifetime run in mode 11 -
`kernel/syscall.c` fills it and `process_prepare()` reads it - so the
permanently mapped window bought it nothing.  It stays separate from the
VFS workspace because the loader is using those slots while it reads this
path, which is the original (and unchanged) reason for the buffer.

No copy-in change was needed.  `zos_fs_copy_path()` reads the caller bytes
from `0100h-1FFFh`, the caller window that mode 11 maps over the caller
bank, and writes its destination into mode-11 kernel memory;
the checked bank-copy gate is only used by the `FS_*` data paths, not by
this copy.  Confirmed by the unchanged acceptance transcript.

Ledger effect (production):

```text
before correction-01:  bank7: code 28159 bytes end 8DFFh | arena 36 granules
                       (20 boot, 16 free) | data 2113 bytes at D600h
                       | isr 256 | slack 191 bytes
after  correction-01:  bank7: code 28159 bytes end 8DFFh | arena 36 granules
                       (20 boot, 16 free) | data 2241 bytes at D600h
                       | isr 256 | slack 63 bytes
```

`_DATA` +128, `_COMMON_DATA` -128, `data_base` unchanged at `D600h`, so the
arena stays at **36 granules** (above the 32-granule floor): the move cost
no granule, exactly as the correction predicted from the 191-byte slack.
`_zos_process_path_scratch` is at `DE04h`, inside `_DATA`
(`D600h`-`DEBFh`) - no longer anywhere near `E000h`.

`tools/mapcheck.py` follows the move: `_zos_process_path_scratch` left
`M6_COMMON_STATE` and is pinned as bank-7 runtime data (region check
`DATA_BASE <= addr < DF00h`), so a future re-appearance in common memory
fails the build rather than passing unnoticed.

## 2. The "cannot reach" claims are corrected

Common memory is mapped in mode 10 exactly as in mode 11; there is no
protection and every application can read and write it.  All five
statements claiming otherwise are gone (four documents plus the assembly
header comment), replaced by the real reason each remaining item lives
there: **the resume gate reads it while it changes the mapping and
switches stacks.**

Corrected sites:

```text
docs/abi.md                                        section 11 notes
docs/memory.md                                     section 4
docs/architecture.md                               section 32.40
docs/vfs.md                                        package-28 paragraph
docs/validation/2026-10-05-m9-nested-exec.md       ledger section
kernel/process/launch.asm                          header + _COMMON_DATA
```

`tests/test_m9_exec.py::test_no_document_claims_common_memory_is_unreachable`
now fails if any of those phrasings comes back, and
`kernel/process/process.c` documents the path buffer's placement with the
same reasoning (in mode 11 only, so bank 7).

## 3. Common memory on the ledger

The ledger is now two lines, printed by both tools from one shared format
definition (`tools/pack_image.py` owns `BANK7_LEDGER_LINE` /
`COMMON_LEDGER_LINE`; `tools/zmodpack.py` imports them):

```text
bank7: code 28159 bytes end 8DFFh | arena 36 granules (20 boot, 16 free) | data 2241 bytes at D600h | isr 256 | slack 63 bytes
common: used 2104 of 7424 bytes (code 1410, data 694)
```

- `used` = packed `_COMMON` + `_COMMON_DATA`; `capacity` =
  `ZOS_COMMON_CODE_END - ZOS_COMMON_BASE` = 7424 bytes.
- Both tools emit the same fields into JSON
  (`manifest["bank7"]` and `arena.plan.json["bank7"]`):
  `common_code_bytes`, `common_data_bytes`, `common_used_bytes`,
  `common_capacity_bytes`.  The two dicts are asserted equal by an
  existing host test, which now covers the common fields too.
- `tools/mapcheck.py` derives the two area sizes from the probe link
  (`area_sizes()` over `_COMMON`/`_COMMON_DATA`) and emits
  `ZOS_COMMON_CODE_SIZE` / `ZOS_COMMON_DATA_SIZE` into the generated
  `build/geometry/memory.inc`, so `zmodpack plan` has the same inputs the
  image manifest has.  Both ledger builders refuse a missing input and
  reject a packed run that exceeds the window.
- `docs/memory.md` section 2.2.1 documents the second line, the two
  figures and the fixed reservations (`FD00h-FEFFh`, and the ROM-access
  block at `EEFEh-EF08h`) that sit outside the packed run; `mapcheck`
  already fails the build if any linked area overlaps that block, so the
  packed run cannot reach the lowest reservation.
- **Host test:** `tests/test_m8.py::test_bank7_ledger_matches_map_and_manifest`
  now checks every common figure against the linked map
  (`l__COMMON`, `l__COMMON_DATA`, `s__COMMON`), asserts the two areas are
  one contiguous run, and pins the two-line format;
  `test_plan_reports_modules_and_totals` checks the synthetic-geometry
  case, and `tests/test_m9_exec.py::test_ledger_reports_common_memory`
  checks the production map plus `arena.plan.json` from the package's own
  test module.

Package-28 common-memory history, now visible on the ledger:

```text
package-27 baseline:   common used 1544 of 7424 (code 1041, data 503)
package 28:            common used 2232 of 7424 (code 1410, data 822)  (+688)
correction-01:         common used 2104 of 7424 (code 1410, data 694)  (-128)
```

## 4. Gate-stack canary: not added, and why

The correction allowed skipping it "if the existing measurement already
observes the true high-water mark; say which".  It does, so it is skipped:

- `tests/test_syscall_sim.py` and `tests/test_m9_exec_sim.py` sample `SP`
  **at the start of every single emulated instruction** and keep the
  minimum inside `[zos_gate_stack_top - 256, zos_gate_stack_top)`.  A
  `PUSH` is therefore always observed at the following instruction, so
  `zos_gate_stack_top - min_sp` *is* the exact high-water mark, not a
  sampled estimate.
- A boot-time canary pattern in acceptance builds would re-observe the same
  number from inside the image, at the cost of test-only kernel code in
  every acceptance image.  Both measurement sites now carry a comment
  saying the measurement is exact, so the reason is recorded where the
  next package will read it.

What a canary *would* add is hardware-side observability of the figure
(today the number exists only in the simulator); if IOC-FAT makes a
hardware gate-stack reading worth having, that is the reason to add one.

## Validation (one batch, 280 s wall clock)

```sh
make clean && make check                                                    OK
make m9-exec-selftest                                                       OK
python3 -m unittest tests.test_m9_exec tests.test_m9_exec_sim \
        tests.test_pack_image -v                                            OK
git diff --check                                                            clean
```

```text
make check: reproducible rebuild (60adaf7349d0d934f38ec1794232a86fdf5593a32331570a9be4bb4d8a25fcfa)
make check host stack: 614 tests OK (158 skipped: image-dependent)
m9-exec-selftest: 9 simulator tests OK
  m9 exec: copied gate frame 32 bytes of 48 saved, 37 suspensions,
           37 resumes (+2 kernel), deepest depth 3
  m9 exec: worst-case gate-stack depth 207 of 256 bytes
unittest list: 67 tests OK (test_m9_exec 33, test_m9_exec_sim 9,
               test_pack_image 25)
```

The other two images that share the corrected common layout were rebuilt
and replayed as well, because the correction moves every common address:

```text
make m9-fs-selftest    5 simulator tests OK  (fstest PASS 10/10,
                       fstest launcher OK, m9 fs selftest: OK)
make subsystem-selftest 11 simulator tests OK
both: worst-case gate-stack depth 207 of 256 bytes
```

and the full relevant host suite is green:

```text
python3 -m unittest tests.test_m9_exec tests.test_m9_exec_sim
        tests.test_m9_fs tests.test_m8 tests.test_pack_image
        tests.test_monitor tests.test_source_layout tests.test_syscall_sim
        tests.test_subsys_sim tests.test_docs_evidence
                                                          207 tests OK
git diff --check                                          clean
```

### Why the production image hash changed, and why behavior did not

The production ROM went from `ac0170e1...98a` (package 28 as committed) to
`60adaf73...cfa`.  The correction moves a 128-byte `.ds` reservation out of
`_COMMON_DATA`, which shifts every later common symbol (the continuation
records, the gate-state shadows, the frame-save areas, the gate stack, the
ROM-access block) down by 128 bytes.  Any instruction or table entry that
embeds one of those addresses therefore changes its immediate operand:

```text
image byte diff, pre-correction vs post-correction:
  total differing bytes        100
  page 0 (common SRAM)          30   (rows E000h, E300h, E400h, E500h, E800h)
  page 1 (bank-7 kernel)        70   (code embedding common addresses, and
                                      `ld hl,#_zos_process_path_scratch`
                                      whose target moved E3EEh -> DE04h)
  first/last difference         00E039h .. 018CE2h
```

Every reference moves consistently, so this is an address-encoding change,
not a behavior change, and the two independent acceptances confirm it:

- the extended `fstest` suite still prints `fstest: exec OK` and
  `PASS 10/10` and the depth probe still stops at four levels
  (`m9 exec selftest: OK`, 9 simulator tests, byte-exact frame restore at
  every depth);
- the production boot is unchanged: the same four banner lines with the
  same quiet window, `mapcheck` reports the same 17 areas and the same
  bank-7 code size (`28159` bytes end `8DFFh`).

## Hardware acceptance: PASSED (2026-10-05)

This correction changes common-memory placement, so the supervisor asked
for a production hardware re-run: `make smoke-hardware` with the
banner-only contract, plus the operator's V9958 check.  The corrected
image was flashed and both halves were observed.  Raw transcript:
`docs/validation/2026-10-05-m9-nested-exec-correction-01-hw.txt`.

Image flashed: `build/zephyros.bin`,
sha256 `60adaf7349d0d934f38ec1794232a86fdf5593a32331570a9be4bb4d8a25fcfa`.

**Serial (operator capture):**

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
```

... and nothing further: the four banner lines are the whole serial
contract on a V9958-bound production boot, and the quiet window after them
is empty (no `PANIC`, no failed console bind, no `<module>: unavailable`).
The capture came from the operator's terminal rather than from
`tools/serial_smoke.py` because that session held `/dev/ttyUSB0` for the
whole verification, so no second opener could run; the observable contract
is the same.

**V9958 display (operator screenshot):**

```text
console: dynamic sio0.b OK
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

The operator display step is satisfied (console line, monitor banner,
status line, live prompt).

**Why this is a strong result for a placement change:**

- `scratch=0F19` is *identical* to the pre-correction boot.  It is the
  address of the monitor program's own one-byte BSS scratch
  (`mon_scratch`, `user/monitor/monitor.c`), i.e. a location inside the
  monitor's ZEX image - so the corrected kernel loads and enters exactly
  the same program with the same BSS placement.  The correction's byte diff
  is 30 bytes in ROM page 0 (common SRAM) and 70 bytes in page 1 (bank-7
  kernel); pages 2-7 carry the recovery store and `monitor.zex`, and they
  are byte-identical, which is precisely why this figure cannot move - and
  it did not.
- `bank=00 pid=0` shows the monitor is still the kernel launcher's
  depth-1 child in application bank 0, with `SYS_GETINFO` unaffected.
- The prompt accepts input, so the whole boot path on the corrected image
  is exercised end to end: SIO fallback load, ROMFS read, ZEX load, process
  launch through the common gates, syscall gate, monitor console I/O.

The exec acceptance image was re-run in the simulator only (it relinks the
same common layout, and its acceptance is fully covered there).  Its
package-28 hardware transcript remains valid evidence for the exec
mechanism itself, which this correction does not touch - and the common
layout it shares with the production image is the same one verified above.

## Acceptance criteria

- The exec path buffer lives in bank-7 data without costing an arena
  granule (36 -> 36 granules), and only transition-critical state remains
  in common memory (`M6_COMMON_STATE` no longer lists it; mapcheck pins it
  as bank-7 data).
- No document claims common memory is unreachable from mode 10 (five sites
  fixed, plus a regression test).
- Common-memory usage is printed and test-checked alongside the `bank7:`
  ledger.
- Exec acceptance and the production boot are unchanged (the ROM differs
  only in the 100 bytes that encode the shifted common addresses; both
  acceptances pass on the corrected image, and the production boot was
  re-verified on hardware: see "Hardware acceptance").
