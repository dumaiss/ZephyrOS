# 2026-10-18 - M13 sound driver

## Result

`/dev/sound` is the resident `sound` driver: the Afternoon Blend card's
four SN76489 PSGs at `E0h-E3h` and its DAC at `E4h`, behind the existing
`kos/ksound.h` ABI and `kos/sound.h` SDK.  One reset routine writes
`9Fh BFh DFh FFh` to each PSG and `80h` to the DAC; it runs at init, at
an exclusive acquire, at `KSOUND_OP_RESET` and at the release of an
exclusive hold.  `KSOUND_OP_INFO` returns the 24-byte `struct
ksound_info`, `KSOUND_OP_WRITE` validates the whole pair sequence before
the first `OUT` and performs it through a 64-byte `DRIVER_IO` batch, and
an exclusive open resets the card and refuses a second holder with
`-KOS_EBUSY`.  The driver keeps no shadow of the chips.

The production image boots it, the card program `tests/sound/sound.c`
drives the SDK from the production shell, and the emulated card peer in
`tests/z80sim.py` records every write with its T-state.  The replay
asserts the exact sequence: the init's silence, a four-pair batch, no
writes for an unknown target or an odd count, 2,050 pairs (4,100 bytes)
landing whole, the acquire/refuse/release resets, two `sound_out` writes,
and the resets a close and an exit without one both perform.

`tests/beat/beat.c` now writes its PSG through the driver instead of
`SYS_DIAG_IO_OUT`; no in-tree program writes `E0h-E4h` through
diagnostic I/O any more.

## Driver image and tier ledgers

| item | bytes |
|---|---:|
| `sound` hot segment | 442 |
| `sound` io segment (`_DRIVER_IO` bss) | 67 |
| hot + io | 509 |
| packed container | 510 (one alignment byte) |

The driver's share is 513 bytes; it uses 509, so the packed container
ends one byte under the share.

| ledger | before | after |
|---|---:|---:|
| driver hot used / 32,768 | 28,671 | 29,180 |
| driver hot free | 4,097 | 3,588 |
| driver I/O block (`io_low`-`BFFFh`) | 4,340 (`AF0Ch`) | 4,408 (`AEC8h`) |
| driver I/O segment bytes | 4,336 | 4,403 |
| driver boot/bulk used / 24,576 | 19,598 | 19,598 |
| nucleus cold code | 25,047 bytes, end `C1D7h` | unchanged |
| nucleus cold data | 1,543 bytes at `C200h` | unchanged |
| nucleus cold room | 6,137 | 6,137 |
| common used / ceiling | 3,067 / 3,072 | 3,067 / 3,072 |

The reserve is lowered from 4,096 to 3,584 bytes free in
`tests/test_iocfat.py` and, so both ledger checks agree,
`tests/test_pack_image.py`; `tests/test_sound.py` pins the sound image
at no more than 513 bytes.  The hot tier now has 3,588 bytes free, four
above the new reserve.

## Files

Added:

- `drivers/sound/sound.json`
- `drivers/sound/sound_proto.c` - dispatch, INFO record, lifecycle, init
- `drivers/sound/sound_io.asm` - every `E0h-E4h` access: the reset
  (`OTIR` over the four silence bytes per PSG), the pair loop, and the
  chunked validate/write sequence
- `tests/sound/sound.c` - the card program
- `tests/test_sound.py` - the contract, image-share and production-replay
  tests
- `docs/validation/2026-10-18-m13-sound-driver.md` - this record

Changed:

- `Makefile` - the two sound objects and the `sound` card program
- `systems/production.json` - `sound` between `timer` and `iocfat`
- `platform/zephyr80/public/hardware.{h,inc}` - the PSG/DAC ports, PSG
  count and 3,579,545 Hz clock
- `tests/z80sim.py` - `SoundPeer`, recording `(port, value, T-state)` on
  `E0h-E4h`
- `tests/beat/beat.c` - the PSG tone moved from `diag_io_out` to
  `sound_open`/`sound_write`/`sound_close`
- `tests/test_events.py` - the beat source pins follow the driver
- `tests/test_sound.py`, `tests/test_source_layout.py`,
  `tests/test_sdk.py` - the new driver, sources and program in their
  owning lists
- `tests/test_iocfat.py`, `tests/test_pack_image.py` - the 3,584-byte
  reserve
- `tests/test_hid.py`, `tests/test_v9958.py`, `tests/test_systemgen.py`,
  `tests/test_console_acceptance.py` - the production driver list and
  driver store now carry `sound`
- `tests/test_boot_policy.py` - the longer `drivers.man` wraps its
  trailing prompt, so the manifest read resynchronizes on a fresh prompt
- `tests/test_shell_sim.py` - the `/dev` listing carries `sound`
- `tests/test_device_release.py` - the V9958 endpoint's packed flags are
  `MOD_EP_RELEASE | MOD_EP_EVENTS` (the manifest has declared both; the
  assertion still expected release alone, a pre-existing mismatch)
- `docs/devices.md` - section 10 "SOUND" beside TIMER; later sections
  renumbered; the beat paragraph and test table follow
- `docs/architecture.md` - the 5.6 `sound` row, `/dev/sound` in 4.10,
  `SOUND` in 6.1, the `driver hot` reserve in section 9, and the
  `docs/devices.md` cross-references
- `docs/abi.md`, `docs/vfs.md`, `tests/target/include/driver_client.h` -
  `docs/devices.md` section numbers
- `docs/memory.md` - the current production ledger figures

## Diagnostic I/O moved

- `tests/beat/beat.c`: `psg_write()` (`diag_io_out` on `E0h`) is gone.
  `tone_program()` sends its three bytes as one `sound_write` of three
  `{PSG0, value}` pairs; every event delivery sends one pair through the
  same call; `tone_silence()` sends the one attenuation pair and
  `sound_close()` gives the handle back.  The board's conventional
  SN76489 byte order is unchanged.
- `UserSoftware/VGMPlayer` (`owner's move`, out of scope here):
  `vgmplay.c`'s `psg_port_write()`/`psg_write_chip()` call sites become
  one `struct ksound_write` pair per byte - a tick's writes batched into
  one `sound_write`, or `sound_out(PSG_FIRST_PORT + chip, value)` under
  an exclusive open.
- `UserSoftware/SNTracker` (`owner's move`, out of scope here):
  `psg.c`'s `write_port()` call sites (the register writes reached
  through `PSG_FIRST_PORT + (number >> 2)`) become `ksound_write` pairs
  batched per tick, or `sound_out(port, value)` under an exclusive open.

`UserSoftware/` was not edited.

## Validation

Commands, in order:

```sh
make
python3 -m unittest tests.test_sound tests.test_sdk tests.test_sdk_package tests.test_iocfat tests.test_source_layout
make clean && make check
git diff --check
```

Results:

- `make`: clean, no warnings from the sound sources.
- Focused suite: **118 tests, OK (skipped=1)**, 53.0 s.  The skip is
  `test_sdk.TestHelloWorldImage` (`build-helloworld/konaos-helloworld.bin`
  missing).
- `make clean && make check`: **801 tests, OK (skipped=115)**, unittest
  time 1,389.3 s; wall time for clean + check **25 m 3.4 s**.  The 115
  skips are the acceptance-image replays `make clean` removes (the boot,
  console, fs, IPC, namespace, ROMFS, subsystem, timer-event and xmem
  images); no skip is a sound test.
- `git diff --check`: clean.
- The full check carries 127 pre-existing `ResourceWarning: unclosed
  file` warnings from `tools/modpack.py:424` in the format-fixture tests;
  they are unrelated to this package and no sound build or test emits a
  warning.

Artifacts (clean build):

- `build/konaos.bin` -
  `236f5ed44403e9427a41899f37c7dbe0df837c1347f7d8b295db673e2d363d81`
  (identical to `build/zephyr80.bin`)
- `build/modules/sound.mod` -
  `7089426cc61bf444af1b516ff54cfa0f3a6c98e12ae84a60f35f8bd3a362a215`
  (report image hash
  `d7b015e649fc3db95583dfa0dde9992f83b096b9146fa7399ddb64c9927752f9`)
- `build/user/sound.exe` -
  `57c0d4701c69f1221069805a4bfee3a2df9c5f6cf1a6e3d86dc2507124acfa23`
- ROMFS file
  `c8ef74159061894082c74a509c142320b220c8d0a5c6d1a1639e23ff25000c2d`

## Warnings and limitations

- The write sequence calls the bootstrap `copy_in` through a one-byte
  local `jp (hl)`; the image deliberately does not link
  `drivers/runtime/sdcc_indirect_calls.asm`, whose 79 bytes would take
  the image over its 513-byte share.  This is a local call to the
  bootstrap table, not a second SDCC runtime.
- The driver tier has 3,588 bytes free against the new 3,584-byte
  reserve: the next resident addition has four bytes of headroom and
  needs the reserve revisited.
- The simulator proves the register writes and the protocol outcomes.
  The audible board check is the owner's: `vgmplay` and SNTracker on the
  driver, playing as before, and quitting mid-song (or a reboot) leaving
  the card silent.
- `UserSoftware/VGMPlayer` and `UserSoftware/SNTracker` are listed
  above but not edited, per the package's owner move.

## Unrelated changes

No unrelated source changes were made.  `git status` shows only the
files listed above; no generated file remains in the tree.

## Supervisor review (2026-10-18)

Accepted.

- **Image:** `build/konaos.bin` rebuilt to the recorded hash `236f5ed4...`.
- **Re-run:** `tests.test_sound test_device_release test_iocfat
  test_pack_image test_boot_policy test_events test_vblank` passes (124
  tests, 14 image replays skipped).
- **Code read:**
  - the write sequence's `copy_in` call matches the bootstrap ABI
    (desc in A, offset in DE, buffer and length on the stack, popped by
    the callee, the result tested by its sign);
  - the whole sequence is validated before the first `OUT`;
  - the C dispatch refuses a missing descriptor, a zero or odd count and
    non-zero flags;
  - ACQUIRE and RELEASE reset as designed.
- **Test changes reviewed:**
  - `test_boot_policy`'s prompt resync is the longer `drivers.man`
    wrapping in the glyph model;
  - `test_device_release`'s V9958 flags follow the frame event's
    `"events": true`.
- **Open (owner):** `vgmplay` and SNTracker moved to the driver, and the
  quit-mid-song and reboot silence checks on the board. The tier keeps 4
  bytes above its 3,584-byte reserve, so the next resident addition sets
  its own reserve.

## Board (owner, 2026-10-18)

`vgmplay` and SNTracker use the sound API and play correctly on the
board.
Quitting either mid-song leaves the PSGs silent (the release's reset).
A reboot cuts the sound (the hardware reset); at the restart the PSGs'
power-up tones play for 1-2 s, until the driver's init resets them.
