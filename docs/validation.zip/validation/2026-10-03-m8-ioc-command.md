# M8 — IOC command lane (`ioc.zmod`): validation record

Date: 2026-10-03 (stage 15, worker pass)

Status: **complete — host validation, simulator acceptance and physical
acceptance passed (2026-10-03)**

## Scope

Work package `15-m8-ioc-command` implements the resident IOC
command/status transport over SIO1/B against the deployed MCU firmware
(host contract level `08h`): the platform constants for the command
lane, the `include/zephyros/ioc.h` class API, the `drivers/ioc/` ZMOD
module (assembly port I/O and streaming loops; C framing, CRC,
validation, state, descriptor), its manifest, packer report, ROMFS
entry, deterministic boot load after the SIO fallback, the M8 target
diagnostic image, the simulator IOC command-lane peer, and the host
tests.  See `docs/devices.md` section 5 and `docs/architecture.md`
section 30.6.

## Artifacts (from the clean validation build)

| Artifact | SHA-256 |
| --- | --- |
| `build/modules/ioc.zmod` (1861 bytes, image 1573 + BSS 79, 4 granules) | `2fe3ad90a745adfd864c52fb34d1630f65e5f2104353d1c5ba2d2272f53d3626` |
| `build/modules/sio.zmod` (unchanged) | `bf9a638517488b72e1621c495f098905f73e157fd20dcc9467d465298786877d` |
| `build/modules/monitor.zex` (unchanged M7 oracle, 3546 bytes) | `67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed` |
| `build/zephyros.bin` (production; reproducible) | `55943e49d4e3ed558b4aee1b008fa2ed42140884bc01602234bfc9899e8f31ec` |
| `build-m8-ioc-command-selftest/zephyros-m8-ioc-command-selftest.bin` | `156ebde10eaf4325c581df4faf00bbe5de9e83b91dcafe88edb8d4cbf022317f` |
| `build-m8-ioc-command-selftest/recovery.romfs` | `2548138b2a25b3df01ea55f7b4ec6ecd3ce592a9ed15d6ca3ecd422668f40ee5` |

The packed IOC module: driver ABI 2, 65 `ZREL_ABS16` relocations
(no byte-fragmented relocations), init `+0x05E4` / `_ioc_module_init`,
symbols `_ioc_command`, `_ioc_status`, `_ioc_link_bringup`,
`_ioc_hw_init`, `_ioc_ops`, `_ioc_state`.

The M8 acceptance image keeps the production-derived arena: static
kernel end `60A0h`, arena `6200h-BFFFh` (47 granules), boot set
`5 of 47` granules (sio 1, ioc 4), 42 free.  The production boot set is
`sio + ioc` in `5 of 49` granules (production kernel end `5CD7h`).

## Host validation (literal WORK sequence)

```sh
make clean
make check            # reproducible rebuild (55943e49…) + full host stack: OK
                      # (its embedded suite runs before the image matrix is
                      # built: OK with 112 expected image-dependent skips)
make zmod-test        # 40 tests OK (SIO variants and fixtures; unchanged)
make ioc-command-test # packed-module validate/dump + 26 tests OK
make m8-ioc-command-selftest
                      # image build, mapcheck OK, 10 simulator tests OK
python3 -m unittest discover -s tests -v
                      # 449 tests OK, 0 skipped (run with the complete
                      # M1-M8 image and extras matrix built)
git diff --check      # clean
make clean
```

`make check` verified the identical production hash before and after a
clean rebuild (`check: reproducible rebuild (55943e49…)`).

### Pre-M8 image byte-identity evidence

The complete pre-M8 image matrix was rebuilt in this tree and compared
against the same matrix built from the pristine `HEAD` (package 14)
tree extracted with `git archive`:

- M5 success, M5 corrupt, M6 success, M6 failure and M7 images are
  **byte-identical** (e.g. M7 `d7e26d5a…`, M5 `1ddc8062…`).
- The M1/M2/M3/M4 images differ **only in ROM page 2** (the recovery
  store, offsets `20000h+`): they boot from the embedded catalog and
  never execute those pages, which now carry the updated production
  ROMFS entry (`sio + ioc + monitor`).  Byte diffs of
  `build-selftest/zephyros-selftest.bin` and
  `build-m4-selftest/zephyros-m4-selftest.bin` each show exactly 5747
  differing bytes, all inside page 2 (`20006h-21767h`); pages 0-1 (the
  executable content) are identical.  The `ZOS_IOC_BOOT=0` gate compiles
  the IOC boot load out of every pre-M8 image exactly as before.

## Simulator acceptance

`tests/test_ioc_sim.py` replays the real `156ebde1…` image in the Z80
simulator against the new `IocCommandPeer` (register-level SIO1/B model
with fault injection).  Ten tests cover:

- production-style boot, link bring-up, registration with
  command/status capabilities only (`0x09000000`), the target
  diagnostic lines, and exact wire requests (preload-before-RTS with no
  underrun fill, rolling sequence 1-5, common packet bytes and CRC,
  two `FFh` trailers, one channel reset, one Enter Hunt, RTS asserted
  and released once per exchange);
- repeated PINGs without re-initialisation or re-hunt;
- CRC/length/type/sequence fault rejection with exact error codes,
  RTS release, and immediate recovery;
- leading-byte handling (bounded four-byte drain, `A5 A5 5A` overlap);
- delayed readiness (in and beyond the budget, no request on the wire on
  timeout), delayed reply, stalled clocks with bounded failure and
  recovery;
- rejection of null/oversize frames without lane I/O (`ZIOC_EINVAL`);
- exact IFF restoration for both enabled and disabled entry states;
- held/released HID doorbell sampling returning only
  `ZIOC_STATUS_HID_PENDING`;
- transient link faults retried with Hunt re-armed per attempt, and a
  four-attempt bring-up failure rolling the module back while the SIO
  fallback carries the unchanged monitor to its prompt.

Transcript (decoded, from the hash-pinned image) is preserved next to
this record: `2026-10-03-m8-ioc-command-sim-transcript.txt`.

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: dynamic sio0.b OK
m8 ioc: transport level 08
m8 ioc: controller level 4A
m8 ioc: ping x4 OK
m8 ioc: hid status 00
m8 ioc selftest: OK
# simulator peer: channel resets=1 hunt writes=1 rts assert/release=5/5
#   preload=True frame_start=0
#   requests=[(0x0c,1,0,0), (0x01,2,0,16), (0x01,3,0,16),
#             (0x01,4,0,16), (0x01,5,0,16)]
```

CRC algorithm pinned to the deployed parameter set (poly `1021h`,
preset `0000h`, MSB-first, no final XOR; standard check value `31C3h`)
by `tests/test_ioc.py`, and the driver's wire CRC is compared byte-for
byte against that reference by the simulator tests.

## Physical acceptance — PASSED (2026-10-03)

Flashed image:
`build-m8-ioc-command-selftest/zephyros-m8-ioc-command-selftest.bin`,
`sha256 156ebde10eaf4325c581df4faf00bbe5de9e83b91dcafe88edb8d4cbf022317f`.
The gate was run with the capture started first, then the board was reset:

```sh
make smoke-hardware-m8-ioc-command SERIAL_PORT=/dev/ttyUSB0
#   115200 8N1, raw; the tool announces that it must be listening before
#   the reset, captures the boot log and checks the M0 banner, the dynamic
#   console line, transport level 08h, controller level 4Ah, the repeated
#   PINGs, the HID status sample and "m8 ioc selftest: OK" with no
#   FAIL/PANIC/"ioc: unavailable".
```

**Scripted smoke: passed.**  One run captured the complete boot log
(220 bytes):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: dynamic sio0.b OK
m8 ioc: transport level 08
m8 ioc: controller level 4A
m8 ioc: ping x4 OK
m8 ioc: hid status 00
m8 ioc selftest: OK
```

and the tool reported
`serial_smoke: OK (the banner, the dynamic console line, host transport
level 08h, the controller level 4Ah returned by PING, repeated PINGs, a
HID semantic-status sample, and 'm8 ioc selftest: OK')`.

The transcript is preserved next to this record as
`2026-10-03-m8-ioc-command-hw-transcript.txt`.  The operator additionally
opened an interactive picocom session on the same port after the scripted
gate; the scripted smoke above is the recorded gate evidence.

The image rebuilds to the identical `156ebde1…` hash from the settled
tree (`make BUILD=build-m8-ioc-command-selftest
ZOS_M8_IOC_COMMAND_SELFTEST=1 ...`), so the hardware evidence applies to
the final source state.

This proves on the deployed controller, with no IOC firmware change, the
COMMAND_READY-gated send path, the preload/EOM/RTS sequence, the two
`FFh` trailers and RTS release, the one-time Hunt edge, persistent sync
across the four repeated PINGs, the CRC-validated replies, the returned
controller level (74 / `4Ah`), and the semantic HID status sample.

## Deviations / notes

- `kernel/main.c` gained the `ZOS_IOC_BOOT` build gate: production and
  M8 images load `ioc.zmod` after SIO and tolerate a failed load/bring-up
  (`ioc: unavailable`); every pre-M8 acceptance image compiles the block
  out.
- `PROBE_OBJS` now includes the acceptance target-test objects so the
  derived arena geometry is measured from the same object list the
  image links (the M8 selftest keeps the derived geometry).
- `include/zephyros/errno.h` adds three internal transport codes
  (`ZOS_EPROTO`, `ZOS_ECRC`, `ZOS_EBADSEQ`); they are mapped to the
  negative `ZIOC_E*` results and are not syscall-visible.
- `tools/mapcheck.py` rejects linked `_ioc_` symbols in every image and
  `_m8*` acceptance symbols in production images.
- `tools/serial_smoke.py` gained `--mode m8-ioc-command` with explicit
  wrong-image hints; host-only `make test` never opens a port.
- Source-tree layout tests were extended for `drivers/ioc/`,
  `tests/target/m8/`, the M8 build variant and the selftest macro.
- All pre-existing worktree changes were preserved; nothing under
  `/home/kitamura/Documents/Zephyr-80` was modified.
