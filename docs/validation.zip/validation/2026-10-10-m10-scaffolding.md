# M10 test, tool and build scaffolding (work package 42d)

Work package: `work/42d-m10-scaffolding/WORK.md` (M10 step 8,
architecture 36.24).  The package consolidates the test, tool and build
scaffolding the M10 stages grew: one shared replay helper for every
image replay, an image matrix that only keeps images whose coverage
another image does not already provide, the dead machinery around the
retired models deleted, and the five known problems the 42e record left
behind fixed.  The production image stays byte-identical and every
behaviour that had an outcome test keeps one.  The working log is
`work/42d-m10-scaffolding/progress.md`.

## 1. The image matrix

Fifteen image builds (fourteen acceptance targets plus production) became
nine images in eight acceptance targets plus production:

| before (42e) | after (42d) | why |
| --- | --- | --- |
| `ioc-selftest` | `console-integration-selftest` | the IOC diagnostic runs inside the integration image; its transcript, wire bytes and failure rows are replayed from those bytes |
| `hid-selftest` | `console-integration-selftest` | same, for the HID queue/doorbell and rollback rows |
| `video-selftest` | `console-integration-selftest` | same, for the V9958 renderer, reset and font-failure rows |
| `console-selftest` | `console-integration-selftest` | the console binding diagnostic folded into the integration diagnostic (`console v01`, `output video`, `input hid`, the `C41` marker, the typed `K41` echo, the drained poll row) and the monitor session is replayed from the integration and production bytes |
| `romfs-corrupt-selftest` | folded into `tests/test_romfs_sim.py` | the corrupt-store outcome is an in-ROM header patch on the packed subsystem image, the same patch `tests/subsys/corrupt_romfs.py` wrote (see section 3) |
| `subsystem-selftest` | unchanged | carries the syscall, IRQ, ROMFS and process/ZEX groups |
| `nucleus-selftest` | unchanged | the group's common-memory ledger does not fit the subsystem image (2630 > 2560 bytes), so it stays its own row; documented in the Makefile |
| `console-serial-selftest` (+ the required-console failure store) | unchanged | the serial console lane and the explicit boot failure |
| `fs-selftest`, `ns-selftest`, `ipc-selftest` | unchanged | filesystem, namespace and IPC outcomes |
| `helloworld-image` | unchanged | SDK demo, not an acceptance image (boot program + manifest only) |

Production (`build/zephyros.bin`) is unchanged and remains the reference
every acceptance image is built beside.

### Build and replay time

| image | replay | tests | wall |
| --- | --- | --- | --- |
| subsystem | `test_subsys_sim.py` + `test_romfs_sim.py` | 30 | 22 s |
| nucleus | `test_nucleus_sim.py` | 6 | 1 s |
| console-integration | `test_console_acceptance.py`, `test_ioc_sim.py`, `test_hid_sim.py`, `test_v9958_sim.py` | 15 | 99 s |
| console-serial | `test_console_serial.py` | 4 | 10 s |
| fs | `test_fs_selftest_sim.py` | 3 | 34 s |
| ns | `test_ns_selftest_sim.py` | 3 | 11 s |
| ipc | `test_ipc_selftest_sim.py` | 11 | 338 s (was 1021 s) |
| helloworld | `test_sdk.py` (demo class) | 4 | 7 s |

Building and replaying the whole matrix from a clean tree takes 573 s
(`make -j20 all subsystem-selftest nucleus-selftest
console-integration-selftest console-serial-selftest fs-selftest
ns-selftest ipc-selftest helloworld-image`).  42e had no comparable
figure: `romfs-corrupt-selftest` did not build and the console read check
failed outside the simulator.  The IPC replay is now the only long one,
and it is the image's own work (eight measurement phases plus the
twelve-case probe), not replay overhead.

## 2. One replay helper

`tests/replay.py` (448 lines) now carries what every image replay needs:

- `Replay`: image + symbol map loading (skipping when an image has not
  been built), the machine at reset, the guarded serial-delay skip, the C
  runtime entry, kernel start (host sync, CTC0 arming), `run_until` with
  marker settle and panic detection, stack/ROMFS/geometry/ledger/report
  readers;
- `ConsoleReplay`: the visible V9958 lane - glyph decoding into a
  positioned text model, `run_to`, `run_until_count`, `run_to_pattern`,
  `send_line`, `boot_to_prompt`;
- `IntegrationInputs`: the four scripted input streams the merged
  integration image's diagnostics expect, queued at their transcript
  markers.

Every replay harness uses it: `test_subsys_sim.py`, `test_romfs_sim.py`,
`test_nucleus_sim.py`, `test_ioc_sim.py`, `test_hid_sim.py`,
`test_v9958_sim.py`, `test_console_acceptance.py`,
`test_console_serial.py`, `test_fs_selftest_sim.py`,
`test_ns_selftest_sim.py`, `test_ipc_selftest_sim.py` and `test_sdk.py`.
The per-file copies of boot/run-until/glyph decoding are deleted;
`test_console_sim.py` (284 lines, a second full console replay) is gone.

## 3. Known problems from package 42e

- **`romfs-corrupt-selftest` did not build** (its boot set and its
  production store disagreed).  The image and `tests/subsys/corrupt_romfs.py`
  are deleted.  `tests/test_romfs_sim.py::TestRomfsCorruptStore` patches
  byte 10 of the packed store header inside the loaded image and replays
  the boot: `romfs: init failed, code 0x0A, latch 0x18, header ...` and
  `PANIC: romfs: corrupt recovery image`.  The patch writes exactly what
  the retired script wrote, so the failure path is still exercised on the
  current boot path.
- **`tests/test_romfs_sim.py` read the deleted `arena.plan.json`.**  The
  store scratch is now derived from the build's generated geometry
  (`ZOS_WINDOW_DATA_BASE + ZOS_WINDOW_DATA_SIZE`), so no packed plan file
  is needed.
- **The console-integration self-check printed `FAIL read` on hardware.**
  `integration_test.c`'s read now waits for a key
  (`INTEGRATION_POLL_BUDGET`, with a `uint32_t` poll counter) instead of
  assuming the line is already queued; the replay behavior is unchanged
  (the simulator has the line queued before the hook runs), and
  `tools/serial_smoke.py` tells the operator to type `K41` + Enter when
  the console lanes are reported.
- **`tools/serial_smoke.py` carried M8-era strings.**  1070 -> 614 lines:
  five modes (`normal`, `subsystem`, `console-integration`,
  `console-serial`, `fs`), each pinned to the current transcript, with the
  retired-mode constants, hint functions and token checks deleted.  The
  `console-integration` mode also validates the typed `K41` line.
- **The IPC replay took about 17 minutes.**  1021 s -> 338 s, 1846 -> 530
  lines: the per-instruction tracer is gone, the image boots once and the
  replay asserts outcomes (both verdicts with their check counts, the
  phase markers, the resolver's copy-path counters, the stack high-water
  marks, the slow case's console bytes, the loader report against the
  packer's plan, the one-shot boot segments, and the caller's mapping
  restored at the end).

## 4. Coverage map (old test -> where its outcome is checked now)

Merged or deleted files, with the test that carries each outcome:

| removed | outcome now checked by |
| --- | --- |
| `tests/test_console_sim.py` - production console session | `test_console_acceptance.py::TestProductionImage` (boot lanes, binding report, scripted monitor session, relaunch) |
| `tests/test_console_sim.py` - serial console session | `test_console_serial.py::TestSerialVariant` (monitor prompt, typed `r`, system row, relaunch on the serial lane) |
| `tests/test_console_sim.py` - glyph/console helpers | `tests/replay.py::ConsoleReplay` (used by every console replay) |
| `tests/target/console/console_test.c` + `console_selftest.h` - binding diagnostic | `tests/target/console/integration_test.c` rows (`console v01`, `output video`, `input hid`, `C41` write, `K41` read, poll drain) asserted by `test_console_acceptance.py::TestIntegrationImage` |
| `tests/test_ioc_sim.py` on `build-ioc-selftest` | same test on `build-console-integration-selftest` (transcript, wire bytes, failure rows unchanged; the semantic status word carries the HID doorbell bit because the merged image has HID input queued) |
| `tests/test_hid_sim.py` on `build-hid-selftest` | same test on the integration image (queue/doorbell, typed pass, fault pass, rollback) |
| `tests/test_v9958_sim.py` on `build-video-selftest` | same test on the integration image (init, renderer, reset, font-failure) |
| `tests/hid/manifest.json`, `tests/ioc/manifest.json`, `tests/video/manifest.json` | the integration manifest `tests/console/manifest-integration.json` is the store all four replays boot |
| `romfs-corrupt-selftest` image + `tests/subsys/corrupt_romfs.py` | `test_romfs_sim.py::TestRomfsCorruptStore` (in-ROM header patch) |
| `tests/test_ipc_selftest_sim.py` tracer tests | see below |

The IPC replay is the one place where coverage changed shape, so it is
listed in full:

| tracer test | what the outcome replay checks now |
| --- | --- |
| per-call T-state spans and the T/byte baselines | dropped as a replay assertion: it measured cost, not behaviour.  The twelve-case probe and the 54-check client both verify the paths they take from the inside and print one verdict each; those verdicts, the check count and the resolved path counters are asserted.  The measured figures stay in `docs/validation/2026-10-08-m10-ipc-substrate.md` and `docs/validation/2026-10-09-m10-prune-nucleus.md` |
| kernel-side syscall spans | same (the client's own check count covers the calls completing) |
| descriptor LDIR census and domain intervals | `TestIpcOutcomes.test_copy_path_counters_cover_every_path` - the resolver counts one per outcome, so all three paths (window, aperture, slow) provably carried bytes; the probe's PASS proves the copies were correct |
| per-call latch restore and the aperture installs | `TestIpcOutcomes.test_the_run_ends_in_the_callers_mapping` plus the probe's PASS (its `apcopy-*` checks require the window to be opened, interrupted and restored byte for byte) |
| CTC0 injection framing and the RETI census | kept as an input, not an assertion: the replay still models both delivery profiles and reports the count; the probe's `apcopy-irq` check (`payload[2] >= 1`) and the client's SPIN phases fail if a delivery does not arrive |
| bind census and the refused out-of-window block | the client checks its own binds (six providers, the deliberate miss and the container refusal) and the probe passes; the census itself was a cross-check |
| stack high-water marks | `TestIpcOutcomes.test_stack_high_water_marks` (same instrument, three range tests per step) |
| placement, loader report, boot segments, ledger, fixed-core symbols | unchanged (`TestIpcServiceImages`, `TestIpcPlacement`) |

Every other test file kept its assertions; the ports changed the
harness, not the expectations, except where the merged image's
transcript legitimately differs (the IOC status word, the bring-up
count and the PING payload matching noted above).

## 5. Makefile

Per-image `ifeq` blocks stay (the `$(eval)`/`$(call)` table was tried and
reverted; the supervisor's decision is recorded in `progress.md`).  The
changes are deletions: 1900 -> 1702 lines.

- The selection blocks, image targets and ROMFS-manifest branches for the
  four merged images and the corrupt-store image are gone, with their
  store manifests and the `console_test.rel` rule.
- The integration block links the three device diagnostics and compiles
  their guards, and its target replays all four suites; the subsystem
  target replays the ROMFS suite too.
- Dead machinery deleted: the per-image select flags that no row sets any
  more (`ZOS_IOC_SELFTEST` / `ZOS_HID_SELFTEST` / `ZOS_VIDEO_SELFTEST` /
  `ZOS_CONSOLE_SELFTEST` / `ZOS_ROMFS_CORRUPT_SELFTEST` as *Make*
  variables), the unused `IPC_COLD_EXTRA`, the corrupt-store pack branch,
  and the smoke modes, `.PHONY` entries and `hardware-images` rows for the
  retired images.
- Two wiring bugs the merge exposed are fixed: the nucleus image packed
  the production manifest while selecting the SIO-only service set (it now
  packs the subsystem store), and the helloworld image inherited the
  production service set while its manifest omits `iocfat.zmod` (the
  loader failed on it; the image now declares its own set).

## 6. Tools

- `tools/mapcheck.py`: the dead `_module_loader_load` cold-symbol
  expectation is gone (the M9 loader the symbol belonged to was retired
  in 42b).
- `tools/zmodpack.py`: the dead `required_granules` field assignment is
  gone (the granule accounting it belonged to is retired).
- The M9 `bank7:` budget, the arena/granule rules and the two-bank
  evaluation paths had already been removed by 42b/42c; a sweep of the
  three tools found no other retired-model rule (the remaining `class`/
  `instance` fields are the current service-endpoint model, and the
  `bank7:` mentions left in the tools are the current geometry limits).
- `tools/serial_smoke.py`: see section 3.

## 7. Docs

Brought in line with the tree: `README.md` (build target list, smoke
modes, the operator step for the typed line), `docs/boot.md` (the
corrupt-store outcome, the smoke mode list, the coverage sentence),
`docs/devices.md` (the IOC, HID, V9958 and console sections now name the
integration image and its replays; the acceptance list),
`docs/architecture.md` (section 31's coverage sentence),
`docs/abi.md` (the syscall/IRQ/M6/M7 validation targets, the IPC replay
description), `docs/memory.md` (the IPC and subsystem rows, the self-test
common block) and `docs/vfs.md` (the `--mode normal` note).
`docs/module-format.md` and `docs/filesystem.md` already described the
current model (the latter is marked historical).

## 8. Measured reductions

| area | 42e | 42d | delta |
| --- | --- | --- | --- |
| Makefile | 1900 lines | 1702 | -10.4% |
| Python tests (`tests/*.py`, `tests/subsys/*.py`) | 17,581 lines, 36 files | 15,843 lines, 35 files | -9.9% |
| tools (`tools/*.py`) | 7,156 lines | 6,698 | -6.4% |
| target test programs (`tests/target/**`) | 6,354 lines, 50 files | 6,232 lines, 48 files | -1.9% |
| image builds | 14 (15 images) | 8 (9 images) | -5 images |
| IPC replay | 1021 s | 338 s | -67% |
| image batch from clean | not runnable end to end | 573 s | - |
| host suite, images built | 562 tests (22 s, images absent) | 547 tests / 511 s | the extra time is the image replays the suite now runs |

The line reduction lands at about 9% of test and tool lines rather than
the 20-30% the contract aimed at: the big single win is the IPC tracer
(-1316 lines) and the harness merge (-284 for `test_console_sim.py`,
-456 for `serial_smoke.py`), while the merged images moved coverage into
the existing suites instead of deleting it.  Nothing that had an outcome
test lost one, which is the constraint that bounds this figure.

## 9. Validation (final source)

```sh
make clean && make check            # exit 0, 93 s
make -j20 all subsystem-selftest nucleus-selftest \
     console-integration-selftest console-serial-selftest \
     fs-selftest ns-selftest ipc-selftest helloworld-image   # exit 0, 573 s
git diff --check                    # no output
```

- Reproducible rebuild: `check: reproducible rebuild
  (6e437af55c436c3d4a95275c098beea6da79cc5783c5879f374d4f7ccc5b9c20)` -
  the 42e production hash, unchanged.
- `make check`'s host suite: 540 tests, 0 failures, 92 skipped (21 s) -
  the skip count is the acceptance images, which a clean tree has not
  built yet.
- With the whole matrix built, the host suite runs 547 tests, 0
  failures, 4 skipped, 511 s; every image target's own suite is green:
  subsystem (4 + 26 cases), nucleus (6), console-integration (7 + 2 + 2 +
  4), console-serial (4), fs (3), ns (20 + 3), ipc (29 + 11), helloworld
  (15, 2 skipped).
- `git diff --check`: clean.

## Supervisor review (2026-10-10)

**Accepted.** Production `6e437af5…` is unchanged.
- The image matrix went from 15 builds to 9.
- The IPC replay went from 1,021 s to 338 s.
- One replay helper; the four 42e problems fixed; an honest coverage map.
- The line reduction (about 9%) is below the 20-30% aim, for the stated
  reason: coverage was kept, not dropped. Accepted.
- Requirement 3's table-driven Makefile was dropped by supervisor steer
  (`$(eval)` metaprogramming risk for little gain); the deletions-only
  Makefile pass stands.
- `nucleus-selftest` stays separate because its common ledger exceeds
  the M9 limit of 2,560. Once package 43 lifts the limit to 3,072, merging
  it into the subsystem image becomes possible (optional, low priority).
- Owner hardware, optional: `make smoke-hardware-console-integration` now
  asks the operator to type `K41` + Enter, and should pass on the board.
