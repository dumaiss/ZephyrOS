# GFX foundation (graphics SDK, KVIDEO_OP_DIRECT_INFO, libgfx, gfxtest)

## Result

The graphics foundation is in: `KVIDEO_OP_DIRECT_INFO` (6) with the
`kvideo_direct_info` record, `libgfx` (a third optional SDK archive,
`LIBS=gfx`) with `gfx_open`/`gfx_close`/`gfx_get_info`/`gfx_set_mode`/
`gfx_display_enable`/`gfx_clear` over a V9958 backend whose port I/O is
assembly, and the `gfxtest` outcome program proving the three modes.
`gfx_open` is the only VIDEO IPC the library makes; every later call
works the ports the record reported, directly.  The exclusive release
(and the process exit without `gfx_close`) restores the console.

Validated with the package's named batch, then `make clean && make
check` (reproducible rebuild, the full 900-test suite, mapcheck, pack
checks) — all green.  The board runs (`gfxtest mode6`, `mode7`, `yjk`:
a solid colour, a key, the console back) are PENDING: no hardware in
this session.

## Files

- `abi/kos/protocol.h` - `KVIDEO_OP_DIRECT_INFO` (6) and its protocol
  comment.
- `abi/kos/kvideo.h` - the record: version 1, `KVIDEO_BACKEND_V9958`,
  flags `DIRECT_IO | HW_WAIT | PALETTE | YJK`, `vram_kib` 128, the five
  ports one by one, `config_initial`; `_Static_assert`ed size (19) and
  offsets.
- `drivers/v9958/v9958_proto.c` - the DIRECT_INFO case: `-KOS_EBUSY`
  without the exclusive hold, the record built in the reply payload
  otherwise; the `hardware.h` ports.
- `user/sdk/include/kos/gfx.h` - the public surface.
- `user/sdk/gfx/src/gfx_internal.h` - the private state and the backend
  interface (not shipped as a header of its own; `gfx.c` state is BSS,
  a closed context is `video_handle == 0`).
- `user/sdk/gfx/src/gfx.c` - `gfx_open` (exclusive bind, type check,
  DIRECT_INFO, backend selection; every failure after the bind unbinds
  first), `gfx_close` (idempotent), `gfx_get_info`.
- `user/sdk/gfx/src/gfx_mode.c` - `gfx_set_mode` (argument and
  capability validation, geometry), `gfx_display_enable`.
- `user/sdk/gfx/src/gfx_draw.c` - `gfx_clear` (the 16-colour mode takes
  a 4-bit colour).
- `user/sdk/gfx/src/backends/v9958/v9958_gfx.c` - the mode register set
  (R#46 stop, R#8 = 64Kx4 DRAM + sprites off, R#0 per mode, the common
  table: display off with IE0 off, page-zero addressing, R#9 = 80h
  non-interlaced, R#15 = 2, R#23 = 0, R#26/R#27 = 0, then R#25 = WTE
  plus YJK for the YJK mode) and the clear's HMMV block.
- `user/sdk/gfx/src/backends/v9958/v9958_io.asm` - every port access:
  the register write, the CE wait and the command-engine stream, through
  the record's ports held in two BSS bytes.
- `user/sdk/exe.mk` - `libgfx.lib` (one member per group, `sdar -rcD`).
- `Makefile` - the `gfxtest` program (`LIBS=gfx`), the gfx sources in
  `SDK_INPUTS`, `--libgfx` in the tarball rule, `kvideo.h`/`hardware.h`
  in the v9958 driver object's prerequisites.
- `tools/sdkpack.py` - ships `lib/libgfx.lib` (the `include/kos/gfx.h`
  and `include/abi/kos/kvideo.h` copies follow the header closure).
- `tests/gfx/gfxtest.c` - `info` (refusal, then the record's fields),
  `mode6`/`mode7`/`yjk` (open, set mode, clear to a colour, display on,
  wait for a key, close), and `leak` as an optional second argument
  (return without `gfx_close`, without a further line).
- `tests/test_gfx.py` - the host pins (op number, record layout and
  constants, the backend's port discipline, the Makefile wiring) and the
  production replays (below).
- `tests/test_v9958.py` - the DIRECT_INFO source pin
  (`test_direct_info_is_answered_only_to_the_holder`); the op added to
  the protocol presence check.
- `tests/test_sdk.py` - `gfxtest` in the pinned program list.
- `tests/test_sdk_package.py` - `include/kos/gfx.h`,
  `include/abi/kos/kvideo.h` and `lib/libgfx.lib` in the golden layout,
  `libgfx.lib` in the zero-date archive check, the `build_tree` call.
- `tests/test_source_layout.py` - the gfx sources, header and test
  files in `OWNER_FILES`; the gfx directories in `REQUIRED_DIRS`.
- Docs: `docs/sdk.md` (libgfx, `LIBS=gfx`, the layout, what-links-what,
  the standalone SDK), `docs/devices.md` (the op, its table row), and
  `docs/abi.md` (the takeover answer).  `docs/gfx-sdk.md` is the design
  and is unchanged.

## Requirement results

1. **ABI.** Op 6 in `protocol.h`; `kvideo.h` ships with the SDK through
   the closure (`include/abi/kos/kvideo.h` is in the pinned SDK
   layout), `_Static_assert(sizeof == 19)` plus the offsets
   (`flags == 2`, `vram_kib == 4`, `data_port == 6`,
   `config_initial == 11`).
2. **Driver.** The replay answers DIRECT_INFO only to the holder: a
   plain handle gets `-KOS_EBUSY` (`gfxtest: refused -4`), the
   exclusive one gets version 1, backend 1, flags 000F, 128 KiB, ports
   A0h-A4h, config 0.  Hot budget below.
3. **libgfx.** The named test batch pins: the exclusive lifecycle (the
   hold sequence ACQUIRE → DIRECT_INFO → RELEASE with nothing between,
   read from the dispatch entry's frame op), the mode registers after
   `gfx_set_mode`/`gfx_display_enable` (R#0/R#1/R#8/R#9/R#25 per mode,
   R#15 = 2, R#23 = 0), the clear as exactly one HMMV
   `(0, 0, W, 468, colour)` covering page 0's 256 rows and page 1's
   first 212, waited for, and the console restoration after the key
   (registers, palette, cursor pattern, a prompt drawn, the exclusive
   flag clear, no protocol errors).  A program that exits without
   `gfx_close` restores the console the same way (the `leak` mode).
4. **Program.** `gfxtest` is in-tree under `tests/gfx/` and declared
   with `LIBS=gfx`; its map shows the gfx members and no driver/kernel
   symbol.
5. **Docs.** As listed; `git diff -U0` writing check prints nothing.

## Budgets

| figure | before | after |
|---|---|---|
| v9958 hot image | 6,389 bytes | 6,468 bytes (**+79**) |
| driver-hot ledger | 30,916 / 32,768 (1,852 free) | 30,995 / 32,768 (1,773 free) |
| reserve | 1,536 | held (1,773 free) |

The package share was 64 bytes; the DIRECT_INFO case costs 79 (the
dispatch chain's compare pair, the handler and its payload writes).
The reserve stays held, and the rule on overrun is to report: reported
here.  `report.json`: hot image 6,468, endpoints unchanged otherwise.

## Validation

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_device_release tests.test_sdk tests.test_sdk_package tests.test_v9958 tests.test_source_layout
# 141 tests, OK (2 skipped: the helloworld image and the v9958-test
# font artifact, neither built by the default target; the font artifact
# was built and its test run separately: OK)
make clean && make check   # once, at the end
git diff --check
```

`make check`: reproducible rebuild confirmed (image sha256
`813aba6fc8bfc380ca0510fb50525a630208afef7c35207c20b047abeaf57519`),
the full suite ran 900 tests in 289.7 s, OK (119 skipped — the
acceptance images `make clean` removes, so their replays skip, as the
worker rules state), mapcheck and the pack checks passed, and the
konaos.bin/zephyr80.bin copies compare equal.  Zero failures, zero
errors, no unexpected warnings in the logs.

Artifacts: `build/user/gfxtest.exe` sha256
`c106c3c7bc76ada68903b74f8a6bb9d9380d4e49964295e59354b583cf65cc04`.

## Pins changed

- `tests/test_sdk_package.py`: the golden `SDK_FILES` set, the
  zero-date archive list and the `sdkpack.build_tree` call — all for
  the shipped `libgfx.lib` and the two shipped headers (source: the
  package's own sdkpack change).
- `tests/test_sdk.py`: `gfxtest` added to the pinned declared-program
  list (source: the package's own Makefile declaration).
- `tests/test_source_layout.py`: the gfx files/directories (source:
  the package's own files).
- `tests/test_v9958.py`: one new pin, plus DIRECT_INFO in the ops
  presence check; no existing expected output changed.

## Found outside scope

- None fixed.  `UserSoftware/KonaEdit/` files (`README.md`, and
  mid-session `src/ke_ui.c`, `src/ke_widgets.c`,
  `tests/test_ui_sim.py`) were modified by parallel work in the shared
  tree; they are preserved untouched and unclassified here.

## Preserved

- The release path (`v9958_display_reset`) and the console's drop
  accounting are untouched; `tests/test_device_release.py` and the full
  suite pass.
- The console, TUI, tee, sound and vblank replays all pass unchanged.
- The reproducer: `make clean && make check`'s rebuild hash matches.

## Pending

- Hardware: `gfxtest mode6`, `mode7`, `yjk` on the board (a solid
  colour, a key, the console back).  Image: `build/konaos.bin`, sha256
  `813aba6fc8bfc380ca0510fb50525a630208afef7c35207c20b047abeaf57519`;
  card program `gfxtest.exe` (hash above) run from the shell as
  `/fs/gfxtest.exe mode6|mode7|yjk`, a key, then the console.

## Correction 1 (board finding)

- **The finding:** on the board, `gfxtest yjk` showed the same red as
  `mode7`.
- **The cause:** `GFX_V9958_R25_YJK` was 10h, which is YAE (R#25 bit 4).
  YJK is bit 3 (08h); R#25 is `0 CMD VDS YAE YJK WTE MSK SP2`. YAE alone
  has no effect, so the YJK mode stayed plain GRAPHIC 7.
- **The fix:** the constant is now 08h. `tests/test_gfx.py` had pinned
  R#25 = 14h for the YJK mode, copied from the wrong constant; it now
  pins 0Ch (WTE + YJK).
- **Validation:** `tests.test_gfx` 9 OK.
- **Expected on the board now:** the 1Ch fill read as YJK
  (Y = 3, J = K = -28) is a medium blue, not red.
