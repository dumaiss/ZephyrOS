# m10-rev13-baseline-cleanup — validation record

Package `work/37-m10-rev13-baseline-cleanup/WORK.md` (M10 stage 1, step 1 of
architecture 36.24): decoder **revision 13** — the `6000h` mode-11 window
plus the mode-10 aperture — becomes the tree's single baseline decoder, and
every piece of machinery implementing an option the architecture rejected
leaves the tree.

Hardware state: revision 13 was programmed by the owner on 2026-10-07, and
CP/M and the production ZephyrOS ROM both boot on it. This package adds no
M10 feature, so production stays byte-identical and no further hardware run
was needed.

## Result

- One decoder design, `platform/zephyr80/hdl/MEM_DECODER_rev13.pld`
  (`Revision 13;`), and `tests/z80sim.py` models it and defaults to it for
  every build and test.
- Production image byte-identical: `build/zephyros.bin` sha256
  `f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7`.
  `make check`'s reproducibility rebuild printed the same hash.
- Every item of B.1–B.4 is removed or reduced; the B.5 grep gate is empty
  except for architecture 36.24's deliberate rejection sentence in
  `docs/architecture.md`, which this package may not edit.
- Validation batch: every step exit 0, **8 m 20 s** wall clock (target:
  under 20 minutes).

## A. Revision 13 is the baseline

**A.1 — one design.** `MEM_DECODER_rev13d.pld`/`.si` renamed to
`MEM_DECODER_rev13.pld`/`.si`, replacing the `8000h` design that held that
name; `MEM_DECODER_rev13b.*` and `MEM_DECODER_rev13c.*` deleted. The PLD
header comment describes the programmed revision-13 baseline (6000h window,
mode-10 aperture) with no letters or rejected variants. The tool chain
follows: `tools/rev13_vectors.py` generates only this design's vectors plus
the revision-12 cross-check file, `tools/pld_terms.py` keeps only the
`revision-13` variant (fit and minimum form), and `make rev13-pld` is the
one PLD target (vectors, minimum form, WinCUPL compile and simulate when
available, revision-12 cross-check). `rev13d-pld` is gone.

**A.2 — simulator.** `tests/z80sim.py`'s memory decoder models revision 13
(the `6000h` window and the mode-10 aperture); the variant and window-base
parameters are gone and `Z80`'s default is `decoder_revision=13`.
Revision 12 stays only as the reference for the P = 0 equivalence proof.
`tests/test_decoder_rev13.py` replays all 2048 committed vectors through the
simulator model, proves revision 13 equals revision 12 in every mode when
P = 0 (latch D5–D7 zero), and pins the Z80 default, the mode-10 aperture
rule, the mode-11 layout, the minimum cover and the PLD/header agreement.

**A.3 — images are unaffected.** No image sets P outside mode 00, so every
image behaves identically under the new default:

- `kernel/memory/banking.asm` (`zos_enter_os_mode`/`zos_leave_os_mode`)
  masks the latch to `ZOS_BANK_MASK` before ORing the mode, so D5–D7 are
  cleared on every mode change; boot writes `ZOS_MODE_OS`;
- the only write of D5–D7 in any image is the ROM page switch in
  `kernel/romfs/rom_access.asm` (`page<<5 | mode 00 | bank 0`), and the
  stub restores the caller's exact latch afterwards.

The batch confirms it end to end: production is byte-identical, and the m9
integration image and the resident-service spike both pass with the
revision-13 default. No image code was changed to make this true.

**A.4 — documents.** `docs/memory.md` section 1.1 is new: it records the
latch field D5–D7 (P), the revision-13 mappings per mode, the P = 0 rule and
that revision 13 is programmed, and points to architecture 36.2 for the
target use. The overlay and window-evaluation text it carried is removed.

## B. Removed, by item

**B.1 — transport B (slot overlay).** `MEM_DECODER_rev13b.pld`/`.si`
deleted; the overlay model and variant removed from `tests/z80sim.py`; the
overlay paths removed from `tools/rev13_vectors.py`, `tools/pld_terms.py`
and `tools/wincupl_build.sh`; the overlay tests replaced by the
single-design vector replay; the transport-B spike image
(`build-rsvc-spike-b`) and every B code path in the resident-service spike
removed (`tests/target/rsvc/rsvc_config.h` has no `ZOS_RSVC_TRANSPORT_B`,
`rsvc_core.c` lost the slot field, the slot helpers, the relay, the slot
tables and the IRQ page bits, and `rsvcgate.asm`'s comment follows).

**B.2 — evaluation decoders and the package-34 evaluation.** The `8000h`
window design (today's old `MEM_DECODER_rev13.pld`, replaced per A.1) and
`MEM_DECODER_rev13c.pld`/`.si` with `make rev13c-pld` are gone. The
evaluation configuration `ZOS_REV13_EVAL` is gone from the Makefile together
with `tests/target/rev13/`, `tests/test_rev13_eval_sim.py`,
`tests/m10/manifest-rev13.json`, `tests/m10/rev13-classification.json`,
`tests/m10/rev13-segments.json` and `make rev13-eval-selftest`. The `8000h`
paths left `tools/rev13_layout.py`: it is now the two-bank report at the
fixed `6000h` split.

**B.3 — the package-33 M10 spike (`ZOS_M10_SPIKE`).** Removed:
`SYS_FAR_CALL` (`kernel/syscall/far.c`, `kernel/process/far.asm`), the
auxiliary page zero and low window and the far-entry table; the spike's
xmem, bank map and ZEX v2 loader (`kernel/syscall/xmem.*`,
`kernel/process/bankmap.*`, `kernel/process/zex2prog.h`) and the v2 paths in
`kernel/process/exec.c`, `kernel/process/process.c` and `kernel/syscall.c`;
`abi/zos/xmem.h` and the SDK xmem and far stubs
(`user/sdk/include/zos/xmem.h`, `user/sdk/src/xmem.c`,
`user/sdk/src/xmemgate.asm`, `include/zephyros/zex2.h`); `tests/target/m10/`
with `tests/test_m10_spike_sim.py`, `tests/m10/manifest-spike.json` and
`tests/m10/segments.json`; the `--zex-v2` path of `tools/zexpack.py` (and
`--v2`/`--segments` of `tools/zexmanifest.py`) with `tests/test_zex_v2.py`;
`docs/zex-format.md` section 8; and `make m10-spike-selftest`. The v1
loader is the only loader left in `exec.c`. Stage 6 re-implements xmem and
ZEX v2 against architecture 36.15–36.18.

**B.4 — the resident-service spike stays, reduced.** Transport A on
revision 13 (the `6000h` split) is the one configuration: the
`ZOS_RSVC_SPLIT` knob and the transport-B selection are gone,
`make rsvc-spike-selftest` builds the single `build-rsvc-spike-6000` image,
and `tests/test_rsvc_spike.py` plus the reduced
`tests/test_rsvc_spike_sim.py` pin that configuration.
`tests/m10/two-bank-classification.json` and
`tools/rev13_layout.py --two-bank` are kept for stage 2.

## Line count removed

Measured with `git diff --numstat` against `69cddf8`:

- **20 tracked files deleted outright: 2,505 lines** (xmem/far/bankmap/ZEX
  v2 sources, the two `abi`/`include` headers, the four `tests/target/m10`
  sources, its manifest and segments, `tests/test_m10_spike_sim.py`,
  `tests/test_zex_v2.py`).
- **1,530 lines deleted from 17 surviving tracked files**: the largest are
  `tools/zexpack.py` (735), `kernel/process/exec.c` (404), `Makefile` (146),
  `docs/zex-format.md` (60), `kernel/process/process.c` (46),
  `tools/mapcheck.py` (40), `kernel/syscall.c` (26),
  `tools/zexmanifest.py` (24), `tests/test_source_layout.py` (12),
  `abi/zos/syscall.h` (12), `user/sdk/*` (10),
  `include/zephyros/process.h` (6), `tests/z80sim.py` (5).
- **Total tracked text removed: 4,035 lines** (net −3,227 for the touched
  paths; 808 lines were added back, mostly the retained work in the
  Makefile, `tools/mapcheck.py` and the rewritten simulator/tests).
- Also deleted: the package-34 leftovers that never reached git
  (`tests/target/rev13/`, `tests/m10/manifest-rev13.json`,
  `tests/m10/rev13-classification.json`, `tests/m10/rev13-segments.json`,
  `tests/test_rev13_eval_sim.py`). Their line counts are not recorded
  anywhere and so are not in the figure above.

## Validation batch

Run 2026-10-07 21:55 EDT (2026-10-08T01:55Z). Transcript:
`2026-10-07-m10-rev13-baseline-cleanup-transcript.txt`.

| Step | Result | Time |
| --- | --- | --- |
| `make clean && make check` | reproducible rebuild `f4da0496…bcf7`; `make check: OK`; host suite 788 tests, OK (194 skipped) | 165 s |
| `sha256sum build/zephyros.bin` | `f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7` | — |
| `make m9-selftest` | 7 tests OK; mapcheck OK (17 areas, 314 symbols); worst-case gate stack 213/256 bytes | 213 s |
| `make rsvc-spike-selftest` | 11 tests OK; inner calls 624; stacks 274/384, 86/256, 15/256; two-bank linked fixed core 14104 | 70 s |
| `make rev13-pld` | vectors current; fit 12/9 12/9 12/9 yes; minimum cover exact; WinCUPL `REV13DEC OK`; revision-12 cross-check skipped (see finding 4) | 6 s |
| `make rev13-pld ZOS_REV12_PLD=…/MEM_DECODER.pld.bak` | `REV13DEC OK`, `REV12DEC OK` — the revision-12 cross-check passes | 7 s |
| `python3 -m unittest tests.test_decoder_rev13 tests.test_rsvc_spike tests.test_rsvc_spike_sim -v` | 37 tests OK | 38 s |
| `git diff --check` | clean | 0 s |
| grep gate (B.5) | one hit, `docs/architecture.md:4789` (see below) | 1 s |

Total **500 s (8 m 20 s)**.

The host suite's 194 skips are the image-dependent simulator tests: `make
check` runs from a clean tree, so only `build/` exists at that point. Those
images and their tests are the later steps (`m9-selftest`,
`rsvc-spike-selftest`) and the three named modules, all of which ran.

## Grep gate (B.5)

```sh
grep -rInE 'rev13[abc]|Revision 13[abc]|ZOS_REV13_EVAL|ZOS_M10_SPIKE|ZOS_RSVC_SPLIT|window_base|SYS_FAR_CALL|zos_far|far_entry|build-rsvc-spike-b' \
  --exclude-dir=.git --exclude-dir=build --exclude-dir='build-*' \
  --exclude-dir=work --exclude-dir=validation --exclude-dir=__pycache__ .
```

```text
./docs/architecture.md:4789:(the 8 KiB slot overlay, the `8000h` window split, the `SYS_FAR_CALL`
```

The single hit is the expected one: architecture 36.24 names the rejected
options in order to reject them, and `docs/architecture.md` may not be
edited by this package. The same command without that file produces no
output.

An `overlay` scan (case-insensitive, same exclusions) returns three hits,
none in the decoder sense: `user/sdk/src/zos_internal.h:1` (the argument
block overlay), `docs/module-format.md:136` (a struct overlaying a layout)
and the architecture sentence above. A wider scan for the removed names
(`rev13_nucleus`, `rev13_proto`, `rev13-eval`, `rev13c-pld`, `rev13d-pld`,
`MEM_DECODER_rev13[b-d]`, `ZOS_RSVC_TRANSPORT_B`, `RSVC_SPLIT`,
`rev13_seg`, `spike_seg`, `ZOS_M10_SPIKE`) returns nothing.

## Findings left alone

1. **`kernel/process/exec.c`'s whole-bank clear** is stage 6's (architecture
   36.19). This package removed the ZEX v2 branch and its `ZOS_M10_SPIKE`
   guards only; with the spike macro gone the file builds the v1 path alone,
   and production bytes are unchanged (the hash proves it).
2. **The SDK/ZEX `zex_program` rule lists no headers**, so a header change
   leaves stale client objects behind. During this package a stale `rsvc`
   client object masked a real failure until `build-rsvc-spike-6000` was
   removed and rebuilt. Left alone: removal and renaming only.
3. **The external revision-12 reference is now mislabelled.**
   `~/Documents/Zephyr-80/Code/HDL/WinCUPL/src/MEM_DECODER.pld` holds the
   `8000h` revision-13 design, so the default `make rev13-pld` reports "not
   the revision-12 reference; cross-check skipped". The genuine revision-12
   file in that tree is `MEM_DECODER.pld.bak`, and the cross-check passes
   with `ZOS_REV12_PLD=…/MEM_DECODER.pld.bak`. Nothing in this tree changes:
   the reference lives outside the repository.
4. **Unrelated worktree changes are preserved**: `docs/architecture.md`,
   `docs/m10-m12-target-architecture.md` and `tests/test_sdk.py` carry the
   supervisor's/earlier packages' work and were not touched by this package.

## Deviations

1. **`tests/target/include/rsvc_test.h` was deleted by accident** during the
   B.1 sweep. It was untracked, so `git` had no copy and no other source
   survived on this machine. It was reconstructed from its consumers (the
   spike client, the core, the six services and `rsvcgate.asm`): protocol
   constants, `struct rsvc_frame` (32 bytes), `struct rsvc_api` (12 members
   with signatures matched to the core's implementations), the evidence
   struct, syscall numbers `40h`–`47h` and the request blocks. The reduced
   spike reproduces the recorded package-35/36 measurements: `calls 624` and
   `fsread 300952.2 T` identical, IRQ handler cost 196 T identical, and the
   per-call T-states within about 0.7 %.
2. Two commands beyond the listed batch, both green: the explicit
   `ZOS_REV12_PLD` cross-check run and the wider leftover scans above.
3. An informal `python3 -m unittest discover -s tests` run (788 tests, 176
   skipped, OK) was made while implementing, before the batch; the batch's
   own host-suite run is the recorded one.

## Handoff

Added/replaced: `platform/zephyr80/hdl/MEM_DECODER_rev13.pld`/`.si`
(renamed, `.si` regenerated: 2048 read vectors), `tools/rev13_vectors.py`,
`tools/pld_terms.py`, `tools/rev13_layout.py` (reduced),
`tools/wincupl_build.sh`, `tests/test_decoder_rev13.py`,
`tests/test_rsvc_spike.py`, `tests/test_rsvc_spike_sim.py` (reduced),
`tests/target/include/rsvc_test.h` (reconstructed),
`tests/target/rsvc/*` (reduced), `tests/m10/two-bank-classification.json`.

Rewritten: `Makefile` (selection block, cold set at the 6000h split, PLD
variables, `rsvc-spike-selftest`, `rev13-pld`), `tools/mapcheck.py`,
`tools/pack_image.py` (naming), `tools/zexpack.py`,
`tools/zexmanifest.py`, `kernel/process/exec.c`,
`kernel/process/process.c`, `kernel/syscall.c`,
`include/zephyros/process.h`, `abi/zos/syscall.h`,
`user/sdk/include/zos.h`, `user/sdk/src/zos_internal.h`, `user/sdk/zex.mk`,
`tests/z80sim.py`, `tests/test_source_layout.py`, `docs/memory.md`,
`docs/zex-format.md`.

Removed: the B.1–B.3 files above (20 tracked files, plus the five untracked
package-34 leftovers).

## Supervisor review (2026-10-07)

**Accepted.** Checks run:

- clean `make check` OK, with production `f4da0496…bcf7` byte-identical;
- `git diff --check` clean;
- the grep gate's only hit is architecture 36.1's rejection sentence, as
  expected;
- one PLD, `Revision 13;`;
- the simulator defaults to `decoder_revision=13`.

No rebuild of the other images was needed.

Notes:

- **Deviation 1 (reconstructed `rsvc_test.h`) is accepted.** The reduced
  spike reproduces the package-35/36 evidence. It also shows the real
  risk: all package 34-36 work and the hdl directory are **untracked**.
  The owner should commit the tree before package 38.
- **Finding 2** (the `zex_program` rule has no header dependencies) goes
  into package 38 as a small build fix.
- **Finding 3** is for the owner. The Zephyr-80 reference repo's
  `MEM_DECODER.pld` still holds the old `8000h` design, and the genuine
  revision-12 file is `.pld.bak`. Either update that repo (the programmed
  revision 13 plus a named revision-12 file) or point `ZOS_REV12_PLD` at
  the revision-12 file.
