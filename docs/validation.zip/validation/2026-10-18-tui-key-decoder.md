# TUI key decoder: validation

## Result

`tui_key_pending`, `tui_pollkey` and `tui_getkey` share one parser with
NORMAL, ESC, CSI and SS3 states, an eight-byte bounded sequence buffer and an
eight-byte replay queue.  The parser returns a lone ESC after one immediate
`console_read` look-ahead, ignores NUL in NORMAL state, rejects unknown,
malformed and overlong sequences by returning ESC first and replaying every
consumed tail byte, and recovers to the following key.  `tui_pollkey` never
blocks; `tui_getkey` calls `idle()` between empty polls.

The `keys` replay mode reports 47 symbolic results covering:

- ordinary `A`, arrows, HOME/END, INSERT/DELETE, PGUP/PGDN and F1-F12;
- NUL followed by a known sequence;
- unknown CSI `ESC [ Z`, malformed `ESC [ 1 A`, overlong
  `ESC [ 12345678 ~ Y`, unknown SS3 `ESC O X`;
- standalone ESC followed by a replayable ordinary byte.

The serial and V9958/HID routes produced the same ordered transcript:

```text
0041 0101 0102 0104 0103 0110 0111 0114
0115 0112 0113 0121 0122 0123 0124 0125
0126 0127 0128 0129 012A 012B 012C 001B
005B 005A 001B 005B 0031 0041 001B 005B
0031 0032 0033 0034 0035 0036 0037 0038
007E 0059 001B 004F 0058 001B 0058
```

`tui_core_probe.exe` calls lifecycle, geometry, text and flush only; its map
contains no `tui_key` member and no `_tui_getkey`/`_tui_pollkey`/
`_tui_key_pending` symbol.  `tui_key.rel` is 11,163 bytes in `libtui.lib`
(72,580 bytes); the core probe is 7,617 bytes (image 7,581, BSS 5,129).

## Hardware gate

PENDING.  No physical V9958/HID keyboard and no serial terminal owner was
available for a hand-run of every key.  The emulated V9958/HID route and the
serial route both passed the identical byte vectors; this is not recorded as
physical acceptance.

## Validation

```sh
make build/user/tui_test.exe build/user/tui_core_probe.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_console_serial
git diff --check
```

The combined package 68-72 run completed 173 tests with 171 passed and 2
environmental skips; `git diff --check` was clean.

## Initial supervisor review

The initial result was not accepted. The supervisor reproduced the reported transcript on both
simulator backends and the complete 169-test union (167 passed, 2 environmental
skips), but the transcript never leaves ESC without an immediately available
following byte.

Direct state-machine review found that a lone ESC followed by an empty
nonblocking read leaves the parser in ESC state and returns no key indefinitely.
Parser/replay state also survives `tui_shutdown()` and `tui_init()` because it
is not part of lifecycle-reset state. Package 69 correction 01 is active. The
physical V9958/HID and serial-terminal gate remains `PENDING`.

## Correction 01

The original parser left an `ESC` state waiting across calls, so a lone ESC
only returned when another byte eventually arrived; `tui_getkey()` therefore
hung on a single injected ESC.  The parser now performs the immediate
non-blocking look-ahead directly after reading ESC: no pending continuation
delivers `TUI_KEY_ESC` at once and returns to NORMAL.  There is no timer,
sleep, timeout or driver change.

Parser state is file-static in the separately pulled decoder member, so the
lifecycle cannot call a reset function without pulling the decoder into a
screen-only program.  `tui_init()` instead advances `tui_state.key_generation`;
the next decoder call compares its private generation and clears every parser,
ready-key, sequence and replay field before decoding.  This keeps
`tui_core_probe.exe` free of `tui_key` and all decoder symbols.

Pre-initialization behavior is now explicit and nonblocking:

```text
tui_key_pending()  -KOS_EINVAL
tui_pollkey()      TUI_KEY_NONE
tui_getkey()       TUI_KEY_NONE (returns immediately; no idle loop)
```

The same rule applies after `tui_shutdown()` until the next successful
`tui_init()`.

New replay coverage, on both serial and V9958/HID:

- `loneesc`: inject exactly one ESC byte and no following byte; `tui_getkey()`
  must return `TUI_KEY_ESC`, then polling is empty;
- `keyreset`: inject `ESC [`, leave the parser in CSI, shut down, reinitialize,
  then inject `A`; the clean parser returns ordinary `A`, not a decoded
  cursor key.

The full vocabulary, split-read parsing, malformed-tail replay, NUL ignore and
screen-only link-map result are unchanged.

Final validation after correction: 173 tests, 171 passed, 2 environmental
skips; `git diff --check` clean.  The physical keyboard/serial gate remains
`PENDING`.

## Final supervisor acceptance

Accepted on 2026-10-18 after correction 01. The supervisor independently built
the target, screen-only probe, and SDK, then ran the four correction replays
and the archive/link-map checks. All 14 focused tests passed on the serial and
V9958/HID simulator routes, and `git diff --check` was clean.

The lone-ESC replay supplied no continuation byte. The lifecycle replay left
the decoder in an incomplete CSI state, shut the TUI down, initialized it
again, and injected `A` only after the second session announced readiness.
The physical V9958/HID keyboard and serial-terminal gate remains `PENDING` for
package 73.
