# M13 read path fix (package 58)

Implemented by the supervisor (the worker was stopped).  Drivers and one
measurement program; no kernel, SDK or wire change.

## Change

| file | change |
|---|---|
| `drivers/runtime/sdcc_indirect_calls.asm` | `kos_block_copy(dst, src, count)`: one `LDIR`, count 0 safe |
| `drivers/include/driver.h` | its prototype; data paths copy with it, never a C byte loop |
| `drivers/ioc/ioc_proto.c` | `KIOC_OP_BULK_READ`/`WRITE` direct form: without a descriptor, the bulk loop receives into / sends from the bank-6 hot-tier buffer `payload[0..1]` names (6000h-DFFFh, else `KOS_EINVAL`); the descriptor form is unchanged; the COMMAND reply's bulk-buffer slot is gone; the command/reply DATA copies use the helper |
| `drivers/iocfat/iocfat.c` | `iocfat_transfer` names its own cache slot for both directions (the staging copy and both byte loops are gone); `iocfat_copy`, `iocfat_copy_range` and the two stat replies use the helper |
| `drivers/v9958/v9958.c` | the boot-tier font read uses the helper |
| `abi/kos/protocol.h`, `docs/devices.md` | the bulk ops documented in the direct form |
| `tests/perf/readphase.c` | a stamp pair whose channels disagree on parity (one channel stepped between the two reads) resolves to its nearest candidate, within one count; torn only past 102.4 ms. The sum check verifies every such block |
| `tests/test_readpath.py` | the sum-check comment says so |

Not converted: the HID ring read (wrapping ring of keyboard bytes, not a
data path) and the zero fill of an instance.

## Measurement (simulator, `make phase-image`, 512-byte miss, path B)

| phase | before (ms) | after (ms) |
|---|---|---|
| cache | 0.31 | 0.31 |
| sent | 2.59 | 2.18 |
| reply | 2.05 | 2.15 |
| admit | 1.89 | 1.69 |
| first | 0.18 | 0.18 |
| last (wire) | 12.80 | 12.80 |
| **copy** | **31.74** | **1.66** |
| caller | 1.74 | 1.66 |
| return | 0.13 | 0.13 |
| **timer (door to door)** | **50.79** | **20.33** |

Pass 2 (path C): 53.7 → 23.1 ms.  Pass 3 (128-byte reads): miss 38.8 →
18.6 ms, hit 9.0 → 5.6 ms.  Every block fully stamped, 0 mismatch, 0
torn, worst 1 count.

Target (under 20 ms): missed by 0.3 ms in the simulator.  Requirement 3
did not trigger: `sent` and `reply` are each under 3 ms.

## Board (owner, production image)

SDBENCH port, KonaOS logical read, checksum PASS:

| request | before | after | avg latency | max latency |
|---|---|---|---|---|
| 128 B | | 16.48 KiB/s | 7.58 ms | 20.43 ms |
| 256 B | | 19.60 KiB/s | 12.72 ms | 21.20 ms |
| 512 B | ~10 KiB/s (~50 ms) | 21.66 KiB/s | 22.99 ms | 27.37 ms |
| 1024 B | | 22.57 KiB/s | 44.16 ms | 48.00 ms |
| 2048 B | | 22.97 KiB/s | 86.07 ms | 88.81 ms |
| 4096 B | | 23.22 KiB/s | 170.29 ms | 175.56 ms |

CP/M on the same firmware: ~39 KiB/s (12.8 ms per 512 B).  The board's
23.0 ms against the simulator's 20.3 ms agrees within the lane model.

- `vgmplay night.zvg`: plan 2% utilization, 49 ms startup, feasible; 157
  refills, min 650, mean 1253, max 1506 counts; 0 underruns, 0 missed
  events.
- `timer card`: passes against the owner's watch.
- `fs_selftest`: 37 checks, 0 failures, PASS.
- `hwtest`: 4/4 PASS.

## Remaining gap

Throughput is flat from 512 B to 4 KiB, so the cost is per cache block,
not per call: every block pays the full command exchange (`sent` +
`reply` + `admit`, 5.9 ms, three IPC calls) plus the return and the
caller copy (3.3 ms).  Next: one IPC call per block (command, READY and
bulk in one IOC op, table/assembly frame CRC), then direct transfer into
the caller's buffer for block-aligned reads.

## Validation

```
make                                    OK (mapcheck OK)
make phase-image                        OK (tests.test_readpath, 14 tests)
make fs-selftest                        OK (3 tests)
python3 -m unittest tests.test_ioc tests.test_iocfat tests.test_readpath \
  tests.test_hwtest_sim tests.test_console_acceptance tests.test_shell_sim \
  tests.test_device_release             OK (89 tests)
git diff --check                        OK
```
