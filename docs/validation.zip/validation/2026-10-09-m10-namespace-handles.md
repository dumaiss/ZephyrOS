# M10 namespace and typed handles (package 42a, correction 01)

Date: 2026-10-09.  Contract: `work/42a-m10-namespace-handles/WORK.md` and
its `correction-01/WORK.md` (architecture 36.24 step 6, decisions 11-16
and sections 36.7, 36.13, 36.14).

## Result

Package 42a is implemented and accepted on the simulator.  The VFS is the
root router over the three static nucleus providers, `/dev` is served from
the host-built publication table, `/SYSTEM` is a ROMFS FILE provider, one
global owner-tagged handle table carries typed handles, and
`bind`/`call`/`unbind`/`ns_enum` plus the standard console handles are
live end to end - in the SDK, through the syscall family, into the
providers.

Production bank 7 cannot hold it yet: the M9 `FS_*` front end, the M9 VFS
machinery and the IOC-FAT arena are still linked, and the family needs
6,097 bytes against 2,943 free (correction 01 record in
`work/42a-m10-namespace-handles/progress.md`).  Correction 01 therefore
builds the whole contract into the `namespace-selftest` acceptance image,
at the placement production will use, and production stays byte-identical:

Production artifact: `build/zephyros.bin`
`sha256 11a9bd2b68c7473eab6b624de4155a45ac738f668033b493c965a92fb7016c2e`
(unchanged; reproduced after `make clean && make check`, and again after
the last source edit).

Acceptance image: `build-ns-selftest/zephyros-ns-selftest.bin`
(`make ns-selftest`).

| contract item | state |
|---|---|
| root router over `/FS`, `/SYSTEM`, `/dev` (36.13) | implemented; `/FS` binds `-ZOS_ENODEV` (42b) |
| DEVICE provider over the host-built table | implemented; host packer resolves, loader installs |
| ROMFS `/SYSTEM` FILE provider, in-process endpoint | implemented (read, seek, metadata, `EROFS` write) |
| typed handles in the extended M9 pool | implemented (`bind` returns handle + 8-bit type) |
| `bind` / `call` / `unbind` / `ns_enum` (36.14) | implemented on 06h-09h |
| standard console handles | implemented (bound at start, inherited by exec) |
| `NS_ENUM` with a cookie, containers | implemented (`/`, `/dev`, `/dev/input`, `/SYSTEM`) |
| SDK typed clients | implemented (`zos_ipc_bind/unbind`, `zos_ns_enum`, console via handles) |
| existing M9 `FS_*` path | untouched, still linked and working in the image |
| production switch-over, `SYS_IPC_LOOKUP` removal | 42b, by correction 01 |

## Acceptance criteria (WORK.md)

| criterion | evidence |
|---|---|
| "programs reach every device through `/dev` names or the standard handles" | the client binds `/dev/console`, `/dev/input/keyboard`, `/dev/video`, `/dev/serial/0` and prints every line through handle 1; the console service itself was republished from its manifest row |
| "read `/SYSTEM` files through FILE handles" | the client reads, seeks and stats `/SYSTEM/services.man`; the read name, size and first record are byte-compared with the packed ROMFS |
| "one handle table" | M9 descriptors and bound objects share the pool; the client fills it to `VFS_FD_MAX`, gets `-ZOS_EMFILE`, releases and reuses entries, and the FS_* path shares the same entries |
| "endpoint numbers are invisible to programs" | the image's SDK has no lookup at all and `bind` takes no endpoint; the client's handles are 1, 2, 3, 4, ... and the publisher is reached only through its name |
| "the ledgers are within 36.20" | the image's ledgers are inside every ceiling, and the 42b projection moves the fixed core to 4,782 bytes of room and the cold half to a 21-granule free arena |

## Build selection (correction 01)

One macro selects the half: `abi/zos/object.h` defaults `ZOS_NS_HANDLES`
to 0, and every source that carries both behaviours guards the new half.
Production therefore compiles the stage-3 pair exactly as before
(`kernel/syscall.c` still routes 06h/07h to `zos_ipc_dispatch`) and links
none of the new objects; the acceptance image defines the macro in
`CFLAGS` and in the SDK variant (`ZEX_CFLAGS` in `user/sdk/zex.mk`).

| selection | production | `namespace-selftest` |
|---|---|---|
| 06h / 07h | `SYS_IPC_LOOKUP` / `SYS_IPC_CALL` | `SYS_BIND` / `SYS_CALL` (object handle) |
| 08h / 09h | unassigned | `SYS_UNBIND` / `SYS_NS_ENUM` |
| SDK | `zos_ipc_lookup*` + cache, console by lookup | `zos_ipc_bind/unbind`, `zos_ns_enum`, console by standard handles; no lookup, no cache |
| console client | `SYS_IPC_LOOKUP` on class 6 | handles 1 and 2 |
| new kernel objects | not linked | `vfs_ns`, `vfs_ns_file`, `object` (cold, `test_link`) |
| SDK low data | 68 bytes, code base `0x0144` | 89 bytes (`nsgate.asm`), code base `0x0159` |
| manifest ABI | service ABI 3 (no publications) | ABI 4 for the three packed services |

`config/residency.json` classifies `vfs_ns`, `vfs_ns_file` and `object`
as `cold` and lists them in `test_link`: the image reaches them through
its own `--cold-extra`, `cold_half` (production's cold compile set) and
`linker/zephyr80.lk` are untouched.

## Files added, removed or materially changed

Nothing was removed; the M9 path must keep working until 42b.

| area | what changed |
|---|---|
| `abi/zos/object.h` (new) | protocol types, handle numbers, namespace entry, the four argument blocks with static asserts, the `ZOS_NS_HANDLES` default |
| `kernel/vfs/ns.c`, `ns.h` (new) | root router, DEVICE provider over the publication table, grouping-row synthesis, enumeration, standard handles, `vfs_ns_resolve` |
| `kernel/vfs/ns_file.c` (new) | ROMFS FILE provider: bind (instance inline in the handle), chunked read, seek, metadata, `EROFS` write, dispatch |
| `kernel/syscall/object.c`, `object.h` (new) | the four syscall bodies (path copy + normalization, block validation, result publishing) |
| `kernel/vfs/vfs.h`, `process.c` | the extended descriptor (21 bytes: number, endpoint, object, flags) and its union arm, `VFS_FD_MAX` 12, handle alloc/find/release, endpoint-guarded `vfs_fd_check`, standard handles at process start |
| `kernel/ipc/ipc.c`, `ipc.h` | nucleus endpoints (`IPC_EP_NUCLEUS_BASE` `0x80`), `ipc_call_object`, `ipc_nucleus_copy_out`, linear-scan `endpoint_for`, uniqueness-based `ipc_install_endpoint` |
| `kernel/syscall.c` | the guarded 06h-09h family |
| `kernel/service/service_loader.c` | ABI-4 layout parse, `service_install_publications` |
| `include/zephyros/service.h` | ABI 4, the 20-byte publication record, the reserved-byte rule |
| `tools/zmodpack.py` | `publishes` parse, plan resolution (endpoints, duplicates, grouping rows, capacity), emit, container parse, dump/report of the rows |
| `user/sdk/src/ipc.c`, `include/zos/ipc.h`, `console_service.c`, `src/nsgate.asm`, `zex.mk` | the guarded SDK variant: `zos_ipc_bind/unbind` and `zos_ns_enum` in place of the lookup pair (declarations, wrappers and cache compiled out together), a standard-handle console client, the 21 extra low-data bytes (`nsgate.asm`) and the moved code base |
| `Makefile` | the `ZOS_NS_SELFTEST` block, image-specific service manifests (`SVC_MANIFEST_DIR`), `nsdev`/`ns`/`nschild` rules, `ns-selftest` |
| `config/residency.json` | the three new objects (`cold`, `test_link`) |
| `docs/abi.md` (§12.1, §13), `docs/vfs.md` (§13), `docs/sdk.md`, `docs/devices.md` (§12.7), `docs/module-format.md` (§7.8), `docs/memory.md` | the new contract, tables and evidence pointers |
| `tests/` | `test_ns_selftest.py` (new, 20 tests), `test_ns_selftest_sim.py` (new, 3 tests), `tests/ns/*` and `tests/target/ns/*` (new fixtures), `test_ipc_selftest.py` and `test_sdk.py` updated pins |

Diff by area: 24 tracked files changed, +1,510/-39 lines (abi +31, config
+21/-2, docs +348/-11, include +37/-1, kernel +531/-3, Makefile +153/-4,
tests +9/-5, tools +196/-9, user +193/-5), plus 18 new files (2,700
lines): `abi/zos/object.h` (179), the five kernel sources (1,070), the
eleven test artifacts and suites (1,422) and `user/sdk/src/nsgate.asm`
(29).  Internal-linkage detail: the guard appears at 56 sites across 13
files.

## Ledgers (requirement 8)

Before is the package-41b production plan; `after (production)` is the
same build after 42a - byte-identical by construction; `after (image)` is
the acceptance image, which still links the M9 machinery and the arena.

| ledger | before | after (production) | after (image) |
|---|---|---|---|
| nucleus fixed | required 6,955; overflow 7,752; stacks 768; room 909 | unchanged | required 7,250; overflow 5,829; stacks 768; room 2,537 |
| nucleus cold | code 22,935, end `B997h`; arena 16 granules (13 used, 3 free); data 1,143 at `DA00h`; room 498 | unchanged | code 30,256, end `D630h`; arena 1 granule (0 used, 1 free); data 1,421 at `DA00h`; room 579 |
| driver hot | 12,930 / 32,768 | unchanged | 1,395 / 32,768 |
| driver boot/bulk | 2,170 / 24,576 | unchanged | 57 / 24,576 |
| common | 2,230 of 7,424 (code 1,511, data 719), limit 2,560 | unchanged | unchanged |

The image's cold-code end is *higher* than production's because both the
M9 machinery and the family are linked: the image proves behaviour and
placement, not the production budget.  The bank-6 tiers are near-empty
(1,395 of 32,768 hot; 57 of 24,576 boot/bulk) because the image boots
three services; the projection below is the budget evidence.

## The namespace code's bytes

Measured per object (area sizes from the image's `.rel` files against
production's, same compiler flags apart from the guard), fixed and cold
split by the residency model:

| object | new fixed | new cold | note |
|---|---|---|---|
| `vfs_ns` | - | 2,583 code + 275 data | router, DEVICE provider, enumeration, standard handles |
| `vfs_ns_file` | - | 1,202 code | ROMFS FILE provider |
| `object` | - | 675 code | the four syscall bodies |
| `ipc` | 293 code + 2 data | - | nucleus endpoints, `ipc_call_object`, `endpoint_for`, uniqueness install |
| `vfs_process` | 435 code + 116 data | - | handle table + std handles + endpoint-guarded `vfs_fd_check` (`VFS_FD_MAX` 8 -> 12, descriptor 17 -> 21 bytes) |
| `vfs_mount` | 10 | - | the two `vfs_init` calls into the router |
| `syscall` | - | 4 | the guarded family dispatch |
| `fs` | - | 8 | uses the new object header |
| `service_loader` | - | 491 code + 3 data | ABI-4 parse and `service_install_publications` |
| **total** | **856** | **5,241** | **6,097 bytes** |

Two footnotes for the reviewer:

* `main` links 126 bytes *less* in the image; that is the image's
  configuration (`ZOS_IOCFAT_BOOT=0`, no arena module), not the package.
* The M9 `FS_*` descriptors share the pool, so the pool's growth is
  visible in `vfs_process` and would be smaller if 42b dropped the M9
  kinds first; the number above is the conservative one.

## What 42b frees

Measured from production's own map and object files (bytes per object,
bank-7 areas; the fixed-core entries are the `moves` objects that overflow
into the fixed core):

| object | fixed | cold | source |
|---|---|---|---|
| `fs` | - | 2,727 | the `FS_*` bodies leave; the argument helpers (the pre-dispatch region, ~120 bytes including `zos_fs_copy_path`) stay and move into the object front end |
| `vfs_mount` | 2,235 | - | mount registry, provider registration, mount pass, `vfs_resolve_path` - the router replaces all of it |
| `vfs_file` | 2,484 | - | the M9 file/directory API over a mount + provider handle |
| `vfs_dir` | - | 1,576 | `vfs_opendir`/`vfs_readdir`/`vfs_closedir`; `ns_enum` replaces them |
| `vfs_mutate` | - | 553 | `mkdir`/`rmdir`/`unlink`/`rename` (42b moves them behind `/FS`) |
| `romfs_provider` | - | 1,563 | the M9 provider callbacks; the new FILE provider serves `/SYSTEM` |
| `registry` | - | 1,624 | the M8 device registry (1,316 code + 308 data): production no longer populates it, its only remaining users are the loader fixtures (`kernel/module/loader.c` says so), and package 42 removes it with them |
| generated mount table (`vfs_mounts`) | - | 55 | `config/mounts.json` output |
| **subtotal** | **4,719** | **7,978** | |
| arena | - | 6,656 | the 13 IOC-FAT granules the boot set holds (16-granule arena) |
| **total freed** | | **19,353** | of which 4,719 in the fixed core, 14,634 in the cold half |

## What the new code reuses

42b deletes only the rest - these objects stay, because the router, the
providers and the syscall bodies call into them:

| kept | what the namespace uses | bytes |
|---|---|---|
| `vfs_path` | the whole object is `vfs_path_normalize_at` (CWD-relative, `.`/`..`, repeated slashes) | 739 fixed |
| `vfs_process` | the per-process CWD slots (`vfs_cwd_for`, `vfs_process_start/exit`), the handle pool (`vfs_handle_alloc/find/release`, `vfs_fd_check` for FILE handles) | 1,563 code + 768 data fixed (image) |
| `romfs` | the one ROMFS reader: `romfs_init`, `romfs_lookup_ci`, `romfs_entry_at`, `romfs_read` | 2,767 code + 7 data fixed |
| `ipc` | the endpoint table, `ipc_call_object`, the frame/descriptor resolver and the restricted copy calls (`ipc_nucleus_copy_out`) | fixed core |
| `fs` | `zos_fs_copy_path` and the block/window validation helpers, plus `zos_syscall_success/error` | cold half |
| `vfs_workspace` | the 512-byte path/staging workspace the syscall bodies bracket with `vfs_ws_enter/leave` | 512 fixed |

## Projected production ledgers after 42b

Arithmetic from the measured per-object bytes above (delete the table's
cold and fixed entries, add the package's 856 fixed + 5,241 cold):

| ledger | 42a production | projected after 42b |
|---|---|---|
| nucleus fixed | required 6,955; overflow 7,752; stacks 768; room 909 | required 7,250; overflow 3,584; stacks 768; **room 4,782** |
| nucleus cold code | 22,935, end `B997h` | 19,923, end `AEE6h` |
| nucleus cold arena | `BA00h`-`D9FFh`, 16 granules (13 used, 3 free) | `AF00h`-`D9FFh`, 21 granules, none used |
| nucleus cold data | 1,143 at `DA00h`, room 498 | 1,539 at `DA00h`, room about 100 |
| driver hot | 12,930 / 32,768 | unchanged (the five images are untouched by 42a) |
| driver boot/bulk | 2,170 / 24,576 | unchanged |
| common | 2,230 of 7,424 (limit 2,560) | unchanged |

The fixed core gains room instead of losing it, the cold half gains about
2.7 KiB of code room, and the arena stops being needed at all - which is
the point of the split: 42b is a deletion package, not a squeezing one.
All four 36.20 ceilings stay where they are.

## Acceptance evidence

`make ns-selftest` builds `build-ns-selftest/zephyros-ns-selftest.bin`:
SIO and the console service (real publications `/dev/serial/0`,
`/dev/console`), the synthetic publisher `nsdev` (class 30, publishing
`/dev/input/keyboard` and `/dev/video` with object ids 1 and 2), the store
of six images (`recovery.romfs`, 18,038 bytes) and the SDK client
`/SYSTEM/ns.zex` (10,360 bytes) with the child `/SYSTEM/nschild.zex`
(5,686 bytes).  The client runs 76 checks and prints their outcomes; these
lines appear in this order, and the run ends on the verdict and the
monitor's status:

```text
ns: /dev/console -> 6 handle 3
ns: /dev/input/keyboard -> 4
ns: /dev/video -> 2
ns: call /dev/video whoami -> 4E53
ns: call ping -> 4E53 1234
ns: /dev/serial/0 -> 1
ns: handle table 10 bound, refuse -23
ns: file read 24, first sio.zmod
ns: file size 72
ns: /dev entry serial type 0 container
ns: /SYSTEM 6 entries
nschild: stdout ok
ns: exec /SYSTEM/nschild.zex -> 0
ns: 76/76 checks
ns selftest: OK
monitor: exit status 0x0000
```

The checks cover: the two standard handles and console output through
handle 1; the four `/dev` protocol types (SERIAL 1, VIDEO 2, INPUT 4,
CONSOLE 6) as `bind` returns them; a grouping name refused with
`ZOS_EISDIR`; a call through a bound handle reaching the publishing
endpoint (the synthetic publisher answers `NS_MAGIC` 4E53h and echoes the
ping word, so a wrong endpoint cannot look like a pass); a `/SYSTEM` FILE
handle reading `services.man` (24-byte record, `sio.zmod`), seeking
(`ZFS_SEEK_END` reporting the 72-byte size, a read at the end returning 0,
`ZFS_SEEK_SET` back), metadata (`ZFS_TYPE_FILE`), `EROFS` for a write both
as a call and as a write-flag bind; a root-level name refused with
`ZOS_ENOENT`; unknown names, `/FS` (`ZOS_ENODEV`), foreign and stale
handles and a malformed path refused with the documented values; the
handle table filling to `VFS_FD_MAX` (10 further binds, then `-ZOS_EMFILE`)
and every entry released and reusable; `ns_enum` paging `/`, `/dev`,
`/dev/input` and `/SYSTEM` with the cookie; and a child started with
`SYS_EXEC` that has its own standard handles, uses them and owns none of
the parent's bound handles.

Host tests (both new, part of the target):

* `tests/test_ns_selftest.py` - 20 tests pinning the ABI (numbers, block
  sizes 8/1/12 and the 28-byte entry with `name` at 4, protocol types,
  handle numbers), the production/acceptance selection (`ZOS_NS_HANDLES 0`
  default, `SYS_IPC_LOOKUP` still 06h in production, the production map
  carrying no namespace symbol), the container ABI 4 (section reserved
  bytes, 20-byte record, packer rules, the three packed containers decoded
  row by row with their host-resolved endpoint numbers), the store and
  boot manifest, the residency classification and the SDK variant.
* `tests/test_ns_selftest_sim.py` - 3 tests replaying the boot: the
  transcript in order, the verdict line (76/76) and the monitor's zero
  exit status, `/SYSTEM/services.man` byte-compared against the packed
  ROMFS, and the image's symbol placement.

Neighbouring evidence, re-run on the final source (after the last edit: the
SDK header's lookup declarations are guarded like the functions, see
below):

| target | suite | result |
|---|---|---|
| `make check` | 823 tests | OK (183 skipped) |
| `make console-integration-selftest` | `test_console_acceptance.py` | 6 tests, OK |
| `make console-fallback-selftests` | `test_console_fallback.py` | 3 tests, OK (1 skipped) |
| `make ipc-selftest` | `test_ipc_selftest*.py` | 53 tests, OK |
| `make m9-selftest` | `test_m9_selftest_sim.py` | 7 tests, OK |
| `make ns-selftest` | the two namespace suites | 23 tests, OK |

All seven image binaries (`build/zephyros.bin`, the namespace image, the
IPC image, the M9 integration image and the three console images) hash
identical before and after that last edit, which is the byte-identity
evidence for the neighbours; `git diff --check` is clean.

Last edit, for the record: writing this report surfaced that
`user/sdk/include/zos/ipc.h` still *declared* `zos_ipc_lookup` and
`zos_ipc_lookup_version` unconditionally while `ipc.c` compiles both
functions and the cache out under `ZOS_NS_HANDLES`, so a program in the
acceptance image would have hit a link error with no hint why.  The two
declarations are now inside the same guard, and everything above was
re-run afterwards.

Two existing pins were updated because the package changed what they
count (not what they require): `tests/test_ipc_selftest.py` now lists the
three namespace objects in the residency file's `test_link` set, and
`tests/test_sdk.py`'s program inventory includes `ns` and `nschild`.

## What the package found and fixed while accepting itself

* **Root-level names have no owner.**  The first client revision bound
  `/services.man` and read the `-ZOS_ENOENT` as a provider bug; the
  router was right (only `/FS`, `/SYSTEM` and `/dev` exist, `/` is a
  directory of those roots).  The client now binds `/SYSTEM/services.man`
  and carries an explicit `file-root-refused` check, and the rule is
  documented in `docs/abi.md` section 12.1 and `docs/vfs.md` section 13.
* **Nucleus endpoint numbering.**  `vfs_ns_init()` installs the FILE
  endpoint before the loader runs, so the loader's "number == count + 1"
  install test was wrong for a nucleus endpoint: the guarded
  `ipc_install_endpoint` now checks uniqueness through the
  (already guarded) linear scan.
* **Target constraints.**  sdasz80 has no `-D`, so the SDK variant is a
  separate `nsgate.asm` rather than a `.if` in `runtime.asm`; the kernel
  links no 32-bit arithmetic helpers, so the enumeration's room
  computation is 8-bit; the SDK `printf` has no `%X`, so the client
  prints the magic in lowercase; the IPC frame's `arg0`/`arg1` are 8-bit
  words in a 32-byte frame, so multi-byte fields travel in `payload`.

## Tests retired, kept, and why

`WORK.md` requires "delete the lookup and discovery tests".  In this
build selection that deletion is 42b's, because production still
dispatches the lookup pair: the tests that exercise it are production
tests.

* Kept, unchanged in what they require: the SDK lookup-surface pins
  (`tests/test_ipc_selftest.py` `TestIpcSdkSurface`), the lookup census
  in `tests/test_ipc_selftest_sim.py` (the kernel sees exactly eight
  `SYS_IPC_LOOKUP`s for the six classes of the IPC image), and the
  discovery cases inside `tests/target/ipc/ipc.c`.
* Compensating coverage added now: the namespace suites pin the same
  contract from the other side - `tests/test_ns_selftest.py` asserts that
  production still carries `SYS_IPC_LOOKUP` and no namespace symbol, that
  the acceptance image has no lookup wrappers in its SDK, and that the
  image's 06h-09h family is the object dispatcher's.
* Two pins updated because the package changed what they count, not what
  they require: `tests/test_ipc_selftest.py`'s `test_link` expectation
  (now the three namespace objects) and `tests/test_sdk.py`'s program
  inventory (now includes `ns` and `nschild`).
* 42b's own retirement list is implied by the frees table above: when
  `fs.rel`, `vfs_mount.rel`, `vfs_file.rel`, `vfs_dir.rel`,
  `vfs_mutate.rel`, `romfs_provider.rel`, `registry.rel` and the mount
  table leave, their suites leave with them (the M9 FS/VFS acceptance
  tests and the module-ABI fixtures that use the registry), and the
  lookup tests leave with the lookup.

## Open items

* **42b**: turn the production manifests over to ABI 4, delete the
  objects and arena contents listed above, remove `SYS_IPC_LOOKUP` and
  the SDK cache from production, implement `/FS` (including mutations
  behind it), and switch `config/residency.json`'s `test_link` entries
  into production's cold set.  The projected ledgers above are the target.
* **Hardware**: the owner's `make smoke-hardware` and the console checks
  are not part of this package; the image is a simulator-only acceptance
  image, like packages 39-41.
* **Build selection retires itself**: while `ZOS_NS_HANDLES` is 0 in
  production, every guarded source carries two behaviours.  42b deletes
  the macro, the `#else` halves and the `test_link` entries, which is the
  point at which production links the family for real.

## Supervisor review (2026-10-09)

**Accepted, including correction 01**, on the record's evidence:
- production byte-identical at `11a9bd2b…`;
- `ns-selftest` 76/76, with outcome checks across the contract;
- an exact frees/reuse table for 42b, and a projection that shows 42b is
  a deletion package (fixed room 909 → 4,782 bytes).

Notes for 42b:
- **The `ZOS_NS_HANDLES` guard** (56 sites in 13 files) is transitional
  and must be gone in 42b, together with the `test_link` entries and the
  `#else` halves.
- **Cold data room is projected at about 100 bytes** with the arena
  layout still derived. Removing the arena lets the cold data base move;
  42b reports the re-derived geometry.
- The lookup tests and the registry leave in 42b, with their subjects.
- Re-checked against the final record (after the late `zos/ipc.h`
  declaration-guard fix): every figure above is unchanged, and the seven
  images are byte-identical across that fix. The acceptance stands.
