# M10 acceptance (work package 45)

Date: 2026-10-11.  Contract: `work/45-m10-acceptance/WORK.md` (M10 step
11, architecture 36.24).  Baseline: package 44b at `6b313c2`, clean tree.

## Result

**Every architecture section 37 row is mapped to passing evidence or to a
hardware checklist item.**  Three gaps were found and closed: the VFS root
was not a `chdir` target (a regression against M9, fixed in the nucleus
and covered by new namespace outcomes), the ordinary ZEX v2 `P = 0` row
had no in-program evidence (the subsystem probe now reads the latch), and
the loader's init-status refusal had no outcome test (a test-only
refusing service image now exercises it).  The production ledgers meet
every 36.20 headroom target, the gate stack measures 275 of 384 bytes
against the 360-byte worst case, and the driver stack high-water is 246
of 512.  M10 is marked COMPLETE pending the owner's hardware sign-off;
the checklist is section 7.

## 1. Tree identity

- Source frozen at `6b313c2` plus this package's changes; the final
  validation ran on the frozen tree (section 6).
- Unrelated pre-existing changes: none; the baseline tree was clean.
- No commits were made by this package.

## 2. Coverage map (architecture section 37)

Tests are host replays of the images named unless marked otherwise.

### hardware

| row | evidence |
| --- | --- |
| revision 13 programmed; CP/M boots; the production image boots | already passed on the board: CP/M and the production ROM both boot with the revision-13 decoder (owner report 2026-10-06, `docs/validation/2026-10-06-m10-rev13-window.md` section 8; production boot re-confirmed 2026-10-09, `docs/validation/2026-10-09-m10-files-on-handles.md`).  Re-run items: checklist 7.7/7.8 |
| P = 0 equivalence with revision 12 (vectors) and on hardware | host: `tests/test_decoder_rev13.py` (`test_page_zero_is_revision_12_in_every_mode`, `test_revision_13_is_the_simulator_default`); hardware: the CP/M run and the production boot (checklist 7.8), whose page-zero vectors are the revision-12 ones |

### residency

| row | evidence |
| --- | --- |
| nucleus fixed / nucleus cold / driver hot / driver boot-bulk / common ledgers emitted and within 36.20, headroom targets met | `tools/pack_image.py`/`tools/mapcheck.py --residency` ledger lines on the final tree (section 5); emitted and pinned by `tests/test_ipc_selftest.py::TestIpcServiceImages`, `test_ns_selftest.py`, `test_source_layout.py` |
| gate-stack worst case <= 360; driver-stack high-water reported | `tests/test_ipc_selftest_sim.py::TestIpcOutcomes::test_stack_high_water_marks` measures and prints all three stacks on the one ipc run: gate 275 of 384 (`E65Dh`), driver/service 246 of 512 (`5E0Ah`), ISR 12 of 256.  Section 5 |

### IPC / typed object lifecycle

| row | evidence |
| --- | --- |
| bind -> handle + 8-bit type; no expected-type argument | `ipc-selftest` client (`tests/target/ipc/ipc.c`): `bind-echo/con/vfs/fat/ioc/irqx` check the returned 8-bit type; the ABI shape carries no input type (`abi/zos/object.h`, static asserts in `tests/test_ns_selftest.py::TestNsContainers`) |
| call; 32-byte frame both ways; unbind releases the instance | `ipc-selftest` client: `null-status`, `null-echo` (payload round trip), `null-ring` (32 bytes); `ns-selftest` client: `unbind-*`, `table-release`, `table-reuse` |
| no generic handle_info and no class/capability lookup | the token appears nowhere in the tree; the syscall family is exactly 06h-0Bh (`tests/test_ipc_selftest.py::test_dispatch_is_routed_in_the_dispatcher_proper`, `test_ns_selftest.py::test_production_switch_over_retires_the_guard_and_lookup`) |
| descriptors: copy in/out, bounds rejection, forged id rejection | `ipc-selftest` client: `desc-none`, `desc-in`, `desc-out`, `capture-low-refused` (out of window), `capture-length-refused` (past the descriptor), `forged-refused` |
| no driver can name a caller address | drivers receive the frame and nucleus-issued descriptor ids, never an address: `desc-*` (the id is the only handle on the buffer), `capture-*` refusals, `upcall-exec` (the nucleus-held executable-object stream carries no caller address), and the service-facing closure test (`tests/test_source_layout.py::test_service_facing_closure_keeps_the_abi_surface`) |
| chained FILE read: application -> IOC-FAT -> IOC with direct copy | `fs-selftest` reads `/FS` files through the real driver chain; `ipc-selftest` measures the same chain with its synthetic set: `read-status`/`read-pattern` (direct, one 512-byte copy to the caller), `readoffset-*` (slice), `staged-*` (provider buffers), `conform-payload` (direct repeat == staged bytes) |
| nesting limit enforced; re-entrant call -> EBUSY unless declared | `ipc-selftest` client: `reent-refused` (`-ZOS_EBUSY`), `reent-allowed` (declared endpoint), `depth-refused` (depth 4 -> `-ZOS_ENOSPC`) |
| driver-to-driver near-direct path gives identical protocol results | `tests/target/ipc/vfs.c` forwards with `api->call(fat_handle, ...)` (frame by reference) and FAT does the same to IOC; the client checks the direct answer against the IOC pattern (`read-pattern`) and the staged variant against the direct bytes (`staged-pattern`, `conform-payload`) |
| driver-owned IRQ fires during a driver call; interrupted latch restored exactly | `ipc-selftest`: the replay injects 13 CTC0 deliveries (while calls are in progress, and one inside the mode-10 aperture window); the client's `irq-release/unclaimed/release-again/reclaim/service/count` and `post-irq-call` prove the handler ran and the interrupted call survived; the replay asserts the run ends in the caller's mapping.  Real interrupt timing is hardware (checklist 7.2) |

### host assembly / drivers

| row | evidence |
| --- | --- |
| resident drivers linked at final bank-6 addresses on the host | `tests/test_service_images.py::TestHostLinking` (the io pointer lands in the io block's final base, the boot pointer in the hot image's final base, pack-time relocation bounds); `ipc-selftest` replay pins the loader's placement report against the packer's plan (`test_loader_reports_the_packer_plan`) |
| endpoint numbers and driver dependencies resolved by the host | `tests/test_service_images.py` (`test_endpoint_numbers_are_host_assigned_in_load_order`, `test_a_required_dependency_resolves_to_the_exporter_number`, missing/later/duplicate refusals); the container carries no version and no relocation table (`tests/test_zmod.py`) |
| no runtime relocation, device registration, class discovery or hardware probing | structural, enforced: flat plan without relocation records (`test_zmod.py`), retired registry/loader objects absent from the linker and the classification (`test_ipc_selftest.py::test_classification_covers_the_substrate`, `test_production_linker_script_lists_the_substrate`), no registry vocabulary in the service-facing headers (`test_source_layout.py::test_service_facing_closure_keeps_the_abi_surface`), consoles selected per build with no probe or fallback (`test_console_acceptance.py::test_console_manifests_select_the_build`, `test_console_serial.py`) |
| one driver may implement several protocol types and publish several objects | `ns-selftest`: the `nsdev` image publishes `/dev/input/keyboard` (INPUT) and `/dev/video` (VIDEO) from one endpoint; the client binds both and the types arrive from the host-built table (`bind-dev-input`, `bind-dev-video`, `call-video-whoami`) |
| required-driver initialization failure is explicit boot/configuration failure | gap closed: `tests/test_console_serial.py::TestRequiredConsoleFailure` (image missing -> `service loader: console-serial.zmod: no image`) and the new `TestRequiredConsoleInitFailure` (init returns non-zero -> `service loader: init_fail.zmod: invalid`); both stop before the launcher with `console: service failed` |

### namespace

| row | evidence |
| --- | --- |
| VFS owns exactly the global root routing | `ns-selftest`: `enum-root` is exactly the three provider roots; `file-root-refused` (a root-level name has no owner); the replay asserts no `vfs: ` mount line exists (`test_boot_transcript_and_verdict`) |
| /FS -> static FS provider | `fs-selftest` drives files under `/FS` through the provider; `ns-selftest` proves the static route refuses cleanly with `-ZOS_ENODEV` when the build carries no filesystem driver (`bind-fs-enodev`) |
| /SYSTEM -> static ROMFS provider and works before bank-6 drivers | the subsystem/ROMFS replays load the SIO image from `/SYSTEM` before any console service exists (`romfs selftest: OK`); `ns-selftest` and `fs-selftest` read `/SYSTEM` files; the card-absent fs replay keeps `/SYSTEM` readable |
| /dev -> static DEVICE provider over the host-built publication table | `ns-selftest` binds the host-built publications with their declared types (SERIAL, CONSOLE, INPUT, VIDEO); `tests/test_ns_selftest.py::test_manifests_declare_the_publications` pins the manifest-to-table derivation |
| provider owns every hierarchy component below its root | `ns-selftest`: `enum-input` (keyboard under the `/dev/input` grouping), `enum-system` (flat), `enum-unknown`, `bind-group` (`-ZOS_EISDIR`) |
| root and provider enumeration work without a DIRECTORY protocol/handle | `ns-selftest`: `enum-root*`, `enum-dev-*`, `enum-system*` page with the cookie (no handle is bound for any of them); no DIRECTORY token exists in the tree |
| CWD traversal works through provider validation | gap closed: `ns-selftest` now checks `cwd-initial`, `chdir-system`, `cwd-system`, `cwd-relative-bind` (a relative bind resolves against the stored CWD), `chdir-case`, `chdir-parent`, `cwd-root`, `chdir-dev-input`, `cwd-dev-input`, `chdir-object-refused` (bindable object -> `-ZOS_ENOTDIR`), `chdir-absent`, `chdir-no-provider` (`-ZOS_ENODEV`), `cwd-survives-refusal`, `chdir-dev`, `cwd-dev` |
| no M9 runtime mount/provider registry or root merge remains | `test_ns_selftest_sim.py` asserts the mount line never returns; `test_ipc_selftest.py` pins the linker without `vfs_mount.rel`; `test_source_layout.py` keeps the retired vocabulary out |

### device publication and composition

| row | evidence |
| --- | --- |
| /dev/video resolves to VIDEO without exposing V9958 by name | `ns-selftest` (`bind-dev-video` -> type VIDEO, `call-video-whoami` answers); the production `v9958` manifest publishes `/dev/video` with type VIDEO (`services/manifests/v9958.json`, pinned by `test_service_images.py`); the console-integration diagnostic resolves it by endpoint only (`services ... video=01`, `output video`) |
| /dev/console resolves to CONSOLE and is otherwise ordinary | `ns-selftest` (`bind-dev-console` -> CONSOLE); `console-integration-selftest` and `console-serial-selftest` replays drive the whole dynamic console through it |
| selected console driver uses host-resolved dependencies | `services/manifests/console-*.json` dependencies (VIDEO+HID / SERIAL) resolved by the packer (`test_service_images.py`); `test_console_acceptance.py::test_console_manifests_select_the_build` |
| V9958+HID console configuration works | `console-integration-selftest`: the loader places SIO/IOC/HID/V9958/CONSOLE, the diagnostic rows and the monitor session (typed `r` through HID) run on the V9958 lane; ESC `c` resets the display |
| serial console configuration works with a different CONSOLE driver | `console-serial-selftest`: the whole dynamic console (boot line, banner, prompt, typed `r`) arrives on SIO0/B; the V9958 trace carries no monitor text |
| alternate implementations can publish the same protocol/name in another build | the two CONSOLE manifests publish the same `/dev/console` with type CONSOLE; `test_console_serial.py::test_store_carries_the_serial_console` |

### files

| row | evidence |
| --- | --- |
| fs_open(path, flags) is bind + FILE-type check | SDK `fs.h` builds `open` on bind+type check; `ns-selftest` `file-bind` checks the returned `ZOS_TYPE_FILE`; `fs-selftest` opens through it |
| fs_close is unbind | SDK source; `ns-selftest` `file-unbind`; `fs-selftest` `fs-close-*` |
| /FS file operations use the selected filesystem driver | `fs-selftest` card case: create, write, stat, read, cross-block, seek, EOF, mkdir/rename/unlink/rmdir over IOC-FAT |
| /SYSTEM produces ordinary read-only FILE handles through ROMFS | `ns-selftest` `file-read`/`file-seek`/`file-meta`/`file-size`; `fs-selftest` `system-*`; writes refuse with `-ZOS_EROFS` (`file-write-erofs`) |
| namespace/path operations (enumeration, mkdir, unlink, rename) require no DIRECTORY handle | `fs-selftest` `enum-root-system`/`enum-root-fs`/`enum-card-file`/`enum-card-subdir`, `fs-mkdir`, `fs-rename`, `fs-unlink`, `fs-rmdir` (all on paths, no handle); `ns-selftest` `enum-*` |
| old FS_* syscall front end absent | `abi/zos/syscall.h` keeps 10h-1Fh reserved (ENOSYS), the dispatcher routes only the object family (`kernel/syscall.c`), and `test_ipc_selftest.py::test_dispatch_is_routed_in_the_dispatcher_proper` pins the absence of the retired lookup and shim |

### process lifetime

| row | evidence |
| --- | --- |
| standard /dev/console handles present at process start and inherited | `ns-selftest` writes every line through `ZOS_HANDLE_STDOUT`; its child binds its own console at `ZOS_HANDLE_FIRST_BOUND` (3) with its own numbering; `fs-selftest`/`xmem-selftest` `startup-*` checks |
| exec(path) resolves through VFS, requires FILE, streams it and unbinds it | `ns-selftest`/`fs-selftest`/`xmem-selftest` exec `/SYSTEM` FILEs; the media gate refuses a non-`ROMFS_FLAG_ZEX` entry (`zex-wrong-type.dat` in the subsystem process selftest, exact `ZEX_EXEC_ERR_TYPE`); the nucleus-held stream path is `ipc-selftest` `upcall-exec` |
| exit force-unbinds leaked handles before releasing xmem/segments/bank | `fs-selftest` `exec-child-handles-released` (the child leaked a card file and a bind; the parent's next open succeeds); `xmem-selftest` `exec-child-released` (child objects gone) and the launcher's `free-banks 6` (all six banks returned) |
| nested exec, startup-tail transport and CWD inheritance unchanged | `fs-selftest`/`xmem-selftest` nested exec with tails (`startup-tail`), exit statuses, and the parent's state intact; gap closed for CWD: the `ns-selftest` child reports the parent's CWD (`nschild: cwd /dev`), moves only its own slot (`nschild: cwd /SYSTEM`), and the parent checks `cwd-after-child` |

### ordinary ZEX v2

| row | evidence |
| --- | --- |
| zero segments; normal exec/exit; nested parent/child exec | subsystem process selftest: `zextest` (a zero-segment container, BSS/image/stack/getinfo outcomes), `zex2probe` (segment_count 0, pinned by `test_zex.py::test_outcome_programs_pack_and_carry_their_segments`), repeated exec/exit and the launcher; `helloworld-image` is the SDK's own zero-segment program |
| full 0000h-DFFFh available; P = 0 throughout | gap closed: `zex2probe` now reads the banking latch and fails unless mode 10 with P = 0 (`ZOS_PCST_Z2_FAIL_LATCH`), keeps the `D000h` marker outside its image/BSS/stack (`zex2bank` outcomes), and `zextest`'s stack window sits at `DC00h-E000h`; exec starts every child with P = 0 (the `xmem-child` latches and the `ns`/`fs` children) |

### xmem

| row | evidence |
| --- | --- |
| 1 / 8191 / 8192 / 8193 bytes; multiple objects per bank | `xmem-selftest` outcomes `size-1`, `size-8191`, `size-8192`, `size-8193`, `multi-alloc`, `multi-contents`, `multi-distinct` |
| largest object; oversized rejection; exhaustion; fragmentation | `largest-*`, `alloc-oversized`, `alloc-mappable-oversized`, `exhaustion-16k*`, `exhaustion-mappable*`, `fragmentation-*` |
| stale/foreign handle rejection; no pre-zeroing | `stale-free`, `stale-reused`, `stale-read-live`, `stale-info-live`, `no-zeroing`; foreign handles refused by the child outcomes |
| first/last byte, slot boundary, whole object; range rejection | `boundary-first`, `boundary-last`, `boundary-slot`, `whole-object`, `range-*` |
| automatic cleanup on exit | `exec-child-released`, `far-program-released`, `hold-anchors` then the launcher's `free-banks 6` |

### far code and data

| row | evidence |
| --- | --- |
| map a far-code segment; primary -> far -> primary by plain CALL | `xmem-far` outcomes `seg-info-*`, `seg-map-token`, `seg-map-page`, `far-call-1`, `far-latch-1`, `far-call-2`, `far-latch-2`, `far-banks-differ`; the SDK demo `fardemo` |
| far code calls primary code; ordinary and FILE syscalls from far code | `far-marker` (far code calls back into primary), `far-exec-status` (SYS_EXEC from far), `far-buffer`/`far code says hello` (a console syscall whose buffer is an aperture literal) |
| buffer in the aperture used as a syscall buffer (buffer identity) | `identity-write`/`identity-read` (parent) and `far-buffer` (far code); the replay also pins the far console line twice |
| mappable xmem object read/written directly through the aperture | `map-token`, `map-address-low/high`, `map-token-page`, `aperture-open`, `aperture-direct`, `aperture-xmem-read`, `aperture-close`; the far program's `far-mappable-same-bank`/`far-mappable-alloc` |
| no token for banks 6/7 or for another process's objects | `map-token-page` and `seg-map-page` (the token's page field proves the bank is 0-5), `seg-map-refused`/`exec-child-*` (a child cannot map the parent's handle or segment id); `map-non-mappable` |
| exec from far context starts the child with P = 0; parent latch restored | `far-exec-status` and the child's own latch lines (`xmem-child: latch 12` = mode 10, page 0), `exec-latch-restored` |
| exit from far context releases everything | `far-program-released` (capacity before == after) and the launcher's `free-banks 6` |

### ZEX v2

| row | evidence |
| --- | --- |
| one and several far-code segments; data segments; image + BSS | `tests/test_zex.py` (far rows: `test_far_segment_packs_from_the_linked_area`, `test_several_far_segments_from_one_area`; DATA rows: `test_table_rows_offsets_and_slot_total`); runtime: `xmem-far` two far segments in two banks, subsystem `zex2seg` (DATA segment, image 1024 + BSS 64 zeroed) |
| container larger than 64 KiB; malformed header/table rejection | host: `tests/test_zex.py` (`test_container_over_64_kib`, the 24 malformed fixtures with exact codes); runtime: `zex2big` (67924 bytes, two 32-KiB segments) and the subsystem process selftest's fixture loop + the corrupt-entry re-run |
| segment allocation rollback | subsystem process selftest 8d: with the banks reserved, the load fails with NOSPACE and leaves no slot, bank, object or segment (no-pass), then 8e reruns the same program after release |

### lifetime

| row | evidence |
| --- | --- |
| suspended parent retains its objects and segments | `xmem-selftest` `exec-parent-object-intact` (the parent's mapped object is untouched across the child) and `exec-latch-restored` |
| child receives none of the parent's | child outcomes refuse the parent's handle and segment id; `ns-selftest` child refuses a parent handle number; `fs-selftest` child leaks are its own |
| repeated exec/exit and map/unmap leak nothing | the subsystem repeated exec/exit loop (`test_zex.py` replay), `xmem-selftest` capacity checks, `aperture-open`/`aperture-close`, and the launcher's `free-banks 6` |

### Coverage gaps found and closed

1. **CWD (namespace "CWD traversal works through provider validation";
   process lifetime "nested exec, startup-tail transport and CWD
   inheritance unchanged").**  No acceptance program exercised
   `chdir`/`getcwd`, and the nucleus refused `chdir("/")` with
   `-ZOS_ENOTDIR` — a regression against M9, whose retired `fstest`
   checked `chdir("/")` and `chdir("..")` back to `/`.  Fixed minimally:
   `vfs_ns_dir_check()` answers `ok` for the VFS-owned root (`/` is the
   VFS's own traversable location, not a provider's).  Covered by the
   `ns-selftest` CWD outcomes (parent and child; section 2, namespace and
   process-lifetime rows).
2. **Ordinary ZEX v2 `P = 0`.**  The bank-preservation marker proved the
   bank is not cleared, but nothing read the latch from inside an ordinary
   program.  `zex2probe` now reads port 00h and fails with
   `ZOS_PCST_Z2_FAIL_LATCH` unless the mode is 10 and the page field is
   zero; the marker at `D000h` and the `zextest` stack window at
   `DC00h-E000h` cover "full bank".
3. **Required-driver initialization failure.**  The 42e failure store
   proves the missing-image stop; the loader's init-status refusal branch
   had no outcome test.  Added the test-only `init_fail` service image
   (`tests/target/console/init_fail.c`,
   `tests/console/manifests/init_fail.json`) and the
   `build-service-init-fail-selftest` store, replayed by the new
   `tests/test_console_serial.py::TestRequiredConsoleInitFailure`.

## 3. What the package changed

- `kernel/vfs/ns.c` — `vfs_ns_dir_check()`: the VFS root is traversable
  (the CWD fix; the only production change, -9 bytes of cold code).
- `tests/ns/ns.c`, `tests/ns/nschild.c` — the CWD outcomes; the memory-map
  docstrings note them.
- `tests/target/process/zex2probe.c`,
  `tests/target/include/process_selftest.h` — the latch outcome.
- `tests/target/console/init_fail.c`,
  `tests/console/manifests/init_fail.json`,
  `tests/console/manifest-init-fail.json`, `Makefile` (the
  `ZOS_SERVICE_INIT_FAIL_SELFTEST` selection, its pack rule and the
  `console-serial-selftest` third image) — the init-failure outcome.
- Tests: `tests/test_ns_selftest.py`, `tests/test_ns_selftest_sim.py`,
  `tests/test_console_serial.py` (new class).
- Docs: `docs/architecture.md` (36.16 derived per-object limits; 34 M10
  close), `docs/sdk.md` (one `_FAR_CODE` area per link), `docs/memory.md`
  and `docs/abi.md` (gate stack 384), `docs/devices.md` (12.6 current
  placement numbers), `README.md` (M10 entry), this record.

## 4. The image matrix

The 42d matrix (production, subsystem, nucleus, console-integration,
console-serial, filesystem, namespace, IPC, helloworld) plus
`xmem-selftest` (43).  Formal batch on the frozen source:

```sh
make clean && make check                                  # exit 0, 100.19 s
make -j16 all subsystem-selftest nucleus-selftest \
     console-integration-selftest console-serial-selftest \
     fs-selftest ns-selftest ipc-selftest xmem-selftest \
     helloworld-image                                     # exit 0, 640.60 s
git diff --check                                          # exit 0, no output
```

`make check` on the final tree: reproducible rebuild
`fd4436710e3fae940cee619bbf87831a0aa939bdf9e39328c74f928845f6e91d`, 575
host tests `OK` (104 skipped: the image replays run in the matrix
targets), `mapcheck: OK (18 areas, 344 symbols) [production]`,
`cmp` proves `zephyros.bin == zephyr80.bin`.

Every matrix replay is green; 159 replay tests in 13 discovery runs:

| target | replay tests | wall |
| --- | --- | --- |
| `subsystem-selftest` | 30 (4 `test_subsys_sim` + 26 `test_romfs_sim`) | 64 s |
| `nucleus-selftest` | 6 | 2 s |
| `console-integration-selftest` | 15 (7 + 2 `test_ioc_sim` + 2 `test_hid_sim` + 4 `test_v9958_sim`) | 87 s |
| `console-serial-selftest` | 6 (variant, missing-image failure, init failure) | 14 s |
| `fs-selftest` | 3 | 79 s |
| `ns-selftest` | 23 | 26 s |
| `ipc-selftest` | 40 | 403 s |
| `xmem-selftest` | 8 | 346 s |
| `helloworld-image` | 28 (`test_sdk`) | 12 s |
| **total** | **159** | **640.60 s** |

The `fardemo` image (44b; checklist 7.6) is not part of the matrix target
list; it was built beside it and replayed once by hand (an extra, section
8) with the expected transcript.  The first matrix attempt exposed a
missing prerequisite in the new init-failure rule (`init_fail.zmod` did
not depend on `init_fail.rel`); the rule was fixed and the definitive run
above built everything from the clean tree.

Image hashes (final tree):

| image | sha256 |
| --- | --- |
| production `build/zephyros.bin` (= `build/zephyr80.bin`) | `fd4436710e3fae940cee619bbf87831a0aa939bdf9e39328c74f928845f6e91d` |
| subsystem `build-subsys-selftest/zephyros-subsys-selftest.bin` | `b158c60bb43319751b401edbbce07764c83d9b237a3cb9923c7bf3940606c158` |
| nucleus `build-nucleus-selftest/zephyros-nucleus-selftest.bin` | `ee24dad5564bccefa6df70a64fedd88356333af53ecd1c6269476c6db0ff3bcd` |
| console-integration `build-console-integration-selftest/zephyros-console-integration-selftest.bin` | `3767ba3c1fa492245af3e5b47682a264129fd2eb8dec25b8fdee994b35ed656b` |
| console-serial `build-console-serial-selftest/zephyros-console-serial-selftest.bin` | `739c29bed18d288a2966cc16b0f51ec35477146ba9882c392d330e61b62d4af1` |
| console-serial failure `build-console-serial-fail-selftest/zephyros-console-serial-fail-selftest.bin` | `039ec28f0fce650fbdbb4e889859cf8f94e69c4d26167c29e5f132c232ae1a0c` |
| service init-failure `build-service-init-fail-selftest/zephyros-service-init-fail-selftest.bin` | `51a9490a23966dc2e8ed303885bda02168a95d57aafe4be11076066dc0fc826e` |
| filesystem `build-fs-selftest/zephyros-fs-selftest.bin` | `4697112273e468bd12e036692dc7dc83d0be83af3961c4bbe13254b7874770f4` |
| namespace `build-ns-selftest/zephyros-ns-selftest.bin` | `f6ea2149d12f8622877e2e8e69da293a647c58d245414f2e2d64eec0195ce09e` |
| IPC `build-ipc-selftest/zephyros-ipc-selftest.bin` | `52cbd01e4f115601098adf6fd19916067a0834f8bc09663db5362a1777701d62` |
| extended memory `build-xmem-selftest/zephyros-xmem-selftest.bin` | `49cbe9fb9ac588b2d6ee550d082fc9c3973ae2688710409c6de55ac7c9c1c4e4` |
| helloworld `build-helloworld/zephyros-helloworld.bin` | `0bd2d9fea9bf9cbf7e00fd9b2923b9a31928c68d818df13e67665291eb439aa5` |
| fardemo `build-fardemo/zephyros-helloworld.bin` | `75cd4eb1c6a5c01483165620da77aa418789e9352d136994b3e65b6bc9e8e296` |

All images are byte-reproducible: every hash above was captured twice
from independent builds.

## 5. Final ledgers

Production (bank 7, common and the bank-6 domain), against the 36.20
targets:

```text
nucleus fixed: required 8335 bytes | overflow 2 bytes | stacks 768 | room 7279 bytes   target >= 2048  met
nucleus cold: code 23352 bytes end BB38h | data 1655 bytes at BC00h | room 7561 bytes target >= 4096  met
driver hot: 21846 bytes of 32768                                                      target >= 4096 free, 10922 free  met
driver boot/bulk: 2170 bytes of 24576
common: used 2358 of 7424 bytes (code 1511, data 847) | ceiling 3072                   2358 <= 3072     met
```

Stacks (architecture 36.20): the gate stack is 384 bytes; the deepest
chain the acceptance image drives into it measures **275 bytes**
(`E65Dh-E76Fh`, IPC replay) against the 360-byte worst case — 85 bytes of
headroom.  The driver (service) stack high-water is **246 of 512 bytes**
(`5E0Ah-5EFFh`); the ISR stack high-water is 12 of 256.  Both are
measured and printed by
`tests/test_ipc_selftest_sim.py::TestIpcOutcomes::test_stack_high_water_marks`
on the same one run.

Per-image ledgers (the acceptance images keep the same accounting; the
milestone targets are the production line above):

| image | fixed req+ovf+stacks, room | cold code end, data at, room | hot / boot-bulk | common |
| --- | --- | --- | --- | --- |
| production | 8335+2+768, 7279 | 23352 `BB38h`, 1655 `BC00h`, 7561 | 21846 / 2170 | 2358 |
| subsystem | 8370+1012+768, 6234 | 30126 `D5AEh`, 1863 `D600h`, 697 | 1113 / 47 | 2523 |
| nucleus | 8370+296+768, 6950 | 25661 `C43Dh`, 1669 `C600h`, 4987 | 1113 / 47 | 2465 |
| console-integration | 8370+2+768, 7244 | 30272 `D640h`, 1999 `D800h`, 49 | 12924 / 2170 | 2358 |
| console-serial | 8335+2+768, 7279 | 24044 `BDECh`, 1669 `BE00h`, 7035 | 21845 / 2170 | 2358 |
| init-failure | 8335+2+768, 7279 | 23380 `BB54h`, 1655 `BC00h`, 7561 | 4 / 0 | 2358 |
| filesystem | 8370+2+768, 7244 | 24176 `BE70h`, 1669 `C000h`, 6523 | 15035 / 107 | 2358 |
| namespace | 8335+2+768, 7279 | 23347 `BB33h`, 1655 `BC00h`, 7561 | 1199 / 57 | 2358 |
| IPC | 8370+2+768, 7244 | 25084 `C1FCh`, 1669 `C200h`, 6011 | 5860 / 143 | 2358 |
| extended memory | 8335+2+768, 7279 | 23358 `BB3Eh`, 1655 `BC00h`, 7561 | 1113 / 47 | 2358 |
| helloworld | 8335+2+768, 7279 | 23350 `BB36h`, 1655 `BC00h`, 7561 | 12924 / 2170 | 2358 |
| fardemo | 8335+2+768, 7279 | 23352 `BB38h`, 1655 `BC00h`, 7561 | 12924 / 2170 | 2358 |

**Reported, not fixed:** the `console-integration` acceptance image leaves
49 bytes of cold room, under the 4,096-byte headroom target.  The image
links the merged IOC/HID/V9958/console diagnostics into the cold half on
top of production's code; the gap is 4,047 bytes and is pre-existing (the
fix in this package *adds* 9 bytes; the image built and replayed green in
42d/42e, which did not report per-image ledgers).  The production ledger
the milestone is judged on is unaffected.  Per the contract this is
reported rather than fixed: slimming the diagnostic surface is a larger
change than acceptance allows.

The `gate stack: 384 bytes reserved, 275-byte worst case (target <= 360)`
is recorded in section 34 with the other ledgers.

## 6. Validation

Formal batch, one pass on the frozen source (the earlier development
iterations are listed in section 8):

| command | result | wall |
| --- | --- | --- |
| `make clean && make check` | exit 0: reproducible rebuild `fd443671…`; 575 tests OK (104 skipped, image-dependent); `mapcheck: OK (18 areas, 344 symbols) [production]`; image repacked and compared | 100.19 s |
| `make -j16 all subsystem-selftest nucleus-selftest console-integration-selftest console-serial-selftest fs-selftest ns-selftest ipc-selftest xmem-selftest helloworld-image` | exit 0: 159 replay tests OK, every image built once | 640.60 s |
| `git diff --check` | exit 0, no output | — |

The tree was frozen before the batch: the last source edit (the
init-failure prerequisite fix in the Makefile) precedes both commands.

## 7. Hardware matrix (owner checklist)

Serial lane for every item: SIO0/B, **115200 8N1**.  The smoke tool prints
the image path and its sha256 before it starts and passes on the four
banner lines with no failure marker; the outcome lines below are what the
owner reads in the same transcript.  Items marked **passed** were already
run on the board in earlier packages and are listed for the record.

### 7.1 Bank switching and the aperture (open)

- Image: `build-xmem-selftest/zephyros-xmem-selftest.bin`,
  `49cbe9fb9ac588b2d6ee550d082fc9c3973ae2688710409c6de55ac7c9c1c4e4`.
- Steps: flash the image; run
  `python3 tools/serial_smoke.py --mode normal --port /dev/ttyUSBx`
  (it prints the boot log and the program's own lines) or capture the
  lane in a terminal.
- Expected: `xmem-selftest: 63 checks, 0 failures`,
  `xmem-far: 19 checks, 0 failures`, `xmem-child: PASS` three times
  (latches `11`, `12`, `12`), `xmem-selftest: PASS`, then
  `monitor: exit status 0x0000 active 0 free-banks 6`.
- Authoritative: the aperture opens onto the far bank under P != 0, the
  map tokens select only application banks, and every map/restore cycle
  leaves the machine running.

### 7.2 Driver IRQs on real sources (open)

- Image: `build-ipc-selftest/zephyros-ipc-selftest.bin`,
  `52cbd01e4f115601098adf6fd19916067a0834f8bc09663db5362a1777701d62`.
- Steps: flash; capture serial 115200 8N1
  (`python3 tools/serial_smoke.py --mode normal --port /dev/ttyUSBx`).
- Expected: `service loader: 8 images in bank 6`; `ipc selftest: client
  OK`; `ipc: 54/54 checks` (the suite needs >= 49); `ipc: PASS`;
  `ipccopy: PASS`.
- Authoritative: a real CTC0 interrupt lands while a driver call is in
  progress (the client claims the channel and spins on it) and the
  interrupted latch/stack are restored exactly; the simulator's injected
  deliveries are the same outcomes but not real interrupt timing.

### 7.3 Both console builds, and ESC `c`

- Images: production `build/zephyros.bin`,
  `fd4436710e3fae940cee619bbf87831a0aa939bdf9e39328c74f928845f6e91d`;
  `build-console-integration-selftest/zephyros-console-integration-selftest.bin`,
  `3767ba3c1fa492245af3e5b47682a264129fd2eb8dec25b8fdee994b35ed656b`;
  `build-console-serial-selftest/zephyros-console-serial-selftest.bin`,
  `739c29bed18d288a2966cc16b0f51ec35477146ba9882c392d330e61b62d4af1`.
- **Passed** on the board: the V9958 console with keyboard input, ESC
  `c`, and the `console-serial` build.  To re-run:
  `make smoke-hardware-console-integration SERIAL_PORT=/dev/ttyUSBx`
  (serial diagnostics + the human HID/V9958 session: banner, prompt,
  typed `r` row, ESC `c` line `escc: display reset`);
  `make smoke-hardware-console-serial SERIAL_PORT=/dev/ttyUSBx` (the
  whole dynamic console on the serial lane, typed `r` returns
  `system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02`).

### 7.4 Production with and without a FAT card; files under `/FS`; the monitor from `/SYSTEM` (open)

- Images: production (as 7.3); `build-fs-selftest/zephyros-fs-selftest.bin`,
  `4697112273e468bd12e036692dc7dc83d0be83af3961c4bbe13254b7874770f4`.
- Steps, production: flash with a FAT card -> the monitor boots from
  `/SYSTEM` (V9958); `make smoke-hardware SERIAL_PORT=/dev/ttyUSBx`
  must report `serial_smoke: OK`.  Remove the card and repeat: the boot
  must still come up and `/FS` must be unavailable.
- Steps, files under `/FS`: flash the fs image **with** a card and run
  `make smoke-hardware-fs SERIAL_PORT=/dev/ttyUSBx`; expected
  `fs-selftest: <n> checks, 0 failures`, `fs-selftest: PASS` (create,
  write, stat, read, cross-block, seek, EOF, mkdir, rename, unlink,
  rmdir over the real IOC-FAT driver and the card).  With **no** card,
  capture the lane and expect the honest line
  `fs-selftest: card absent: /FS not served` plus the `/SYSTEM`
  outcomes still passing.

### 7.5 Nested exec (open)

- Images: fs (as 7.4) and extended memory (as 7.1).
- Steps: part of the two transcripts above.
- Expected: fs -> `fs-selftest: exec-status` and
  `fs-selftest: exec-child-handles-released` (the child ran with a tail,
  exited with its status and left no handle behind); xmem -> the three
  `xmem-child: PASS` runs (parent, and once per far call) and
  `xmem-selftest: exec-latch-restored`.

### 7.6 xmem and far code (open)

- Images: extended memory (as 7.1); `fardemo`
  `build-fardemo/zephyros-helloworld.bin`,
  `75cd4eb1c6a5c01483165620da77aa418789e9352d136994b3e65b6bc9e8e296`.
- Steps: the xmem transcript above; then flash the fardemo image and
  capture the visible V9958 console (the demo's console is the V9958).
- Expected, fardemo:

  ```text
  fardemo: begin
  fardemo: token 50
  fardemo: hello from the far bank
  fardemo: far result 502B
  fardemo: PASS
  monitor: exit status 0x0000 active 0 free-banks 6
  ```

  The `token` byte depends on the bank the loader chose; `far result`'s
  high byte must equal it (`502B` = token `50`, result `2B`).
- Authoritative: the aperture on the real latch, far code executed from
  the far bank, and the restore of the caller's mapping.

### 7.7 CP/M still boots (passed 2026-10-06)

- The owner reported *"CP/M works with rev 13 of the PLD equations"*
  (`docs/validation/2026-10-06-m10-rev13-window.md` section 8): boot the
  ZSDOS-based CP/M with the revision-13 decoder fitted, `DIR` drives A:
  and B:, read a file longer than 8 KiB, run programs, copy with `PIP`,
  warm-boot once, then power-cycle and repeat.  No re-run is needed for
  M10 close; the production boot row (7.4) is the ZephyrOS half of the
  same equivalence.

### 7.8 Subsystem acceptance and the production smoke (open)

- Images: `build-subsys-selftest/zephyros-subsys-selftest.bin`,
  `b158c60bb43319751b401edbbce07764c83d9b237a3cb9923c7bf3940606c158`;
  production (as 7.3).
- Steps: `make smoke-hardware-subsystem SERIAL_PORT=/dev/ttyUSBx` ->
  banner, `console: service OK`, `syscall selftest: OK`,
  `irq selftest: OK`, `romfs selftest: OK`, `process selftest: OK`,
  monitor session, `serial_smoke: OK`; then flash production and run
  `make smoke-hardware SERIAL_PORT=/dev/ttyUSBx` -> `serial_smoke: OK`.

## 8. Warnings, skipped checks, uncertainties, deviations

- Warnings: none from a compiler or a tool.  The build logs carry the
  Makefile's own `-j20 forced ... resetting jobserver mode` notices
  (pre-existing default parallelism) and the ns image's
  `overriding recipe` notices for its test-manifest pattern rule
  (present since 42a, unchanged by this package).  The new init-failure
  build prints neither class beyond the `-j20` notice.
- Skips: the formal `make check` reports 104 skips — the image-dependent
  host tests, which ran in the matrix targets instead (0 skips there).
  No unexpected skip.
- Deviations: (1) the first matrix attempt failed the new init-failure
  target because its pack rule lacked the object prerequisite; the rule
  was fixed and the definitive batch ran clean.  The first attempt's
  other targets were green.  (2) Development-pass runs before the formal
  batch (reported for honesty): `make ns-selftest` twice,
  `make subsystem-selftest`, `make ipc-selftest`,
  `make console-serial-selftest` (after the fix), focused
  `unittest` runs of the touched modules, and the manual fardemo replay.
  (3) `make hardware-images` was deliberately not run (the worker rules
  exclude it); every image it would build is covered by the matrix above.
- Uncertainties: the aperture, bank switching, real interrupt timing and
  resident-driver IRQ delivery are hardware-authoritative; section 7 is
  the pending part of the acceptance.  `console-integration`'s 49-byte
  cold room is reported in section 5 (pre-existing, acceptance image
  only).  The fardemo image has no automated replay in the tree (44b
  shipped it with a manual transcript); this record re-ran it by hand.
- Unrelated pre-existing changes: none; the baseline tree was clean, and
  every change this package made is listed in section 3.
- The 32 KiB per-object xmem cap (and the 16 KiB mappable cap) are now
  stated as derived per-object limits in architecture 36.16 (requirement
  1b), with the explicit note that they are not application limits.


## Supervisor review (2026-10-11)

**Accepted. M10 is complete in code; the owner signs off the hardware
checklist (section 7).**
- Production `fd443671…`; the full matrix is green.
- Every section-37 row is mapped. Three gaps were closed, including a
  real `chdir("/")` regression.
- Every production ledger meets 36.20; the gate stack's worst case is 275
  of 384.

Carried to the post-M10 list: the `console-integration` acceptance image
has only 49 bytes of cold room, because it links the merged diagnostics.
Split or slim it before anything is added to that image.

### Hardware (owner, 2026-10-12): `ipc-selftest`

**PASS on the board**: real CTC interrupts into driver calls (checklist
7.2). The image then repeats, because the boot launcher relaunches its
boot program (`ipccopy.zex`) after each exit. That is expected: the
simulator replay stops at the first verdict. Only `subsystem-selftest`
(7.8) remains for the M10 hardware sign-off.

### Hardware (owner, 2026-10-12): `subsystem-selftest`, and the M10 sign-off

**PASS on the board** (checklist 7.8):
- `syscall selftest: OK`, `irq selftest: OK`, `romfs selftest: OK`;
- `process selftest: OK`, including repeated cycles, two-bank, raw
  return `EFAULT`, malformed rejected, corrupt entry rolled back, and
  `zex v2 outcomes OK` (`zex2probe`, `zex2seg`, `zex2big`, rollback);
- then the monitor prompt.

**The M10 hardware sign-off is complete.** Every hardware-authoritative
checklist item has passed on the board:
- production `hwtest` with and without a card (aperture, xmem, far code,
  files, running from `/FS`, nested exec, namespace);
- `ipc-selftest` (real interrupts into driver calls);
- `subsystem-selftest`;
- both console builds and ESC `c`;
- CP/M on revision 13.

Architecture 34 now reads **M10 COMPLETE**.
