# M13 nucleus call path (package 62)

Implemented by the supervisor (owner request). The nucleus only. Closed
early by the owner's decision on the board result: the layers' remaining
cost is spread thin, and the next step would be structural.

## Change

| area | change |
|---|---|
| `kernel/ipc/ipc.c` | an endpoint slot map by number (host and in-process numbers; the two kinds are installed in any order, so every lookup used to scan); descriptors classified once at capture (`IPC_CLS_A`/`_B`), so a copy decides only its driver side, the full decision kept for every other case; a syscall's frame passed in place (the argument block is in the caller window, which the driver mapping shows) - no frame copy in either direction; `desc_release_all` walks a pointer |
| `kernel/vfs/handles.c` | the handle lookup remembers the last entry found per handle number (re-validated on every use) |
| `kernel/event/event_common.asm`, `event.c`, `event.h` | `kos_event_maybe`: a post sets it, and the exit scan returns at once while it is clear (it clears it first and sets it again for any row still pending, so a post during the scan is never lost) |

Measurement tool (scratch, not in the tree): the nucleus profile now places
every object's statics exactly from the link order and the `.rel` area
sizes (all 343 map globals agree).

## Measurement

Simulator, phase image, cold 512-byte miss: 12.70 ms after 61, 11.85 ms
after 62; a cached 128-byte read 4.97 -> 4.22 ms. Much of that is the
measurement program's own per-read syscalls (two clock reads and the phase
fetch), which the same changes speed up.

Board, SDBENCH (checksum PASS):

| request | 61 | 62 |
|---|---|---|
| 128 B | 21.54 KiB/s (5.79 ms) | 22.59 (5.53 ms) |
| 512 B | 31.22 (15.95 ms) | 31.46 (15.82 ms) |
| 4096 B | 35.59 | 35.33 |

Not reached: the 13.5 ms target. What remains per call is spread over a
dozen layers at ~0.05-0.1 ms each; merging the IPC dispatch layers would
be the next step (~0.3-0.4 ms per call).

Common memory: 3,067 of its 3,072-byte ceiling.

## Validation

Validated together with package 63 (one full check at the end).
