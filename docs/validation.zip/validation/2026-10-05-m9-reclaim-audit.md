# M9 reclaim audit (package 30b): measurement record

Work package: `work/30b-m9-reclaim-audit`.  Date: 2026-10-05.
Host toolchain: SDCC 4.5.0 (`sdcc`/`sdldz80`/`sdasz80`), Python 3 host tools.

This is a measurement-and-report package.  The only code it adds is
measurement tooling and its host test; no kernel, driver, provider, SDK or
program byte changes, and the production image and module bytes are
identical to the accepted package-30 build (section 9).

The audit is written against the accepted package-30 ledger:

```text
bank7: code 28476 bytes end 8F3Ch | arena 35 granules (33 boot, 2 free) | data 2241 bytes at D600h | isr 256 | slack 63 bytes
common: used 2104 of 7424 bytes (code 1410, data 694)
```

## 1. Granule-threshold tooling (permanent)

`tools/pack_image.py` and `tools/zmodpack.py plan` already shared the
`bank7:`/`common:` ledger.  They now additionally report, for every boot-set
module and for the kernel, the distance to the granule thresholds:

* `pack_image.granule_thresholds(total)` returns `above_lower_bytes` (the
  saving that reaches the lower threshold, so removing it frees one granule)
  and `before_higher_bytes` (the room left before the next higher threshold
  spends one granule).
* `pack_image.kernel_granule_thresholds(code_end, data_base, data_size,
  runtime_end)` does the same for the arena start (the linked code end) and
  the derived data base (the runtime-data size): `code_above_lower_bytes` /
  `code_before_higher_bytes` and `data_above_lower_bytes` /
  `data_before_higher_bytes`.  The data pair is expressed as runtime-data
  size changes; with the derived-base invariant
  `data_base = align_down(DF00h - data_size, 512)` the values are exact.
* `pack_image.format_granule_thresholds(modules, kernel)` is the readable
  table, printed by both tools (byte-identical, one definition).
* `arena.plan.json` carries the per-module fields in each `modules[]` entry
  and a `kernel` object; `zephyros.manifest.json` carries the same `kernel`
  object.  No ledger field or image byte changed.

Production output:

```text
granule thresholds: bytes above the lower threshold free one granule; bytes before the higher threshold spend one
  module       image    bss   total granules free-granule  cost-granule
  sio            324      4     328        1          328           184
  ioc           3599    112    3711        8          127           385
  hid            955     24     979        2          467            45
  v9958         4038    460    4498        9          402           110
  iocfat        6006    637    6643       13          499            13
  kernel           -      -       -        -            -             -
  code end 8F3Ch: 316 bytes free a granule, 196 before one is spent
  data size 2241 at D600h: 449 bytes free a granule, 63 before one is spent
```

`tests/test_pack_image.py::TestGranuleThresholds` checks the arithmetic
against the linked map and the packed containers (unit boundary cases plus,
when the derived build is present, `manifest["kernel"]`, `plan["kernel"]` and
every module entry recomputed from `build/zephyros.map` and
`build/arena.plan.json`).

## 2. Inventory (production map, `.rel`/`.sym`)

Measured from `build/zephyros.map`, `build/*.rel`/`*.sym` and the packed
`build/modules/*.zmod`.  Kernel `_CODE` totals 28476 bytes (28473 in
`_CODE` + 2 `_INITIALIZER` + 1 `_GSFINAL`); kernel data totals 2241 bytes
(2239 `_DATA` + 2 `_INITIALIZED`).

### 2.1 Kernel `_CODE` (bytes)

| object | bytes | object | bytes |
| --- | ---: | --- | ---: |
| `romfs` | 2879 | `syscall` | 1391 |
| `fs` (syscall front end) | 2727 | `registry` | 1331 |
| `vfs_file` | 2484 | `vfs_process` | 1128 |
| `module_relocate` | 2277 | `vfs_path` | 854 |
| `vfs_mount` | 2153 | `process` | 785 |
| `process_exec` | 1730 | `irq` | 627 |
| `main` | 1661 | `diag` | 615 |
| `vfs_dir` | 1568 | `console` | 604 |
| `romfs_provider` | 1513 | `vfs_mutate` | 553 |
| `module_loader` | 1484 | `vfs_mounts` + asm glue | 109 |

### 2.2 Kernel `_DATA`/`_INITIALIZED` (bytes)

| object | bytes | contents |
| --- | ---: | --- |
| `vfs_process` | 652 | `vfs_descriptors[8]` 136 + `vfs_cwd_path[4][128]` 512 + owners 4 |
| `vfs_workspace` | 512 | single VFS workspace (4 x 128 path slots, aliased 512 staging) |
| `module_loader` | 373 | `granule_used[95]` 95 + `module_table[16]` 272 + counters |
| `registry` | 308 | `device_table[16]` 256 + `device_used[16]` + `device_generation[16]` (16-bit) |
| `process` | 188 | `path_scratch[128]` + `process_table[4]` + status |
| `irq` | 65 | IRQ bookkeeping |
| `vfs_mount` | 62 | `vfs_mount_state[4]` + init data |
| `romfs_provider` | 50 | provider slot state |
| `main`, `romfs`, `syscall`, `console` | 31 | boot/report and leftovers |

### 2.3 Common `_COMMON`/`_COMMON_DATA` (bytes)

| owner | `_COMMON` | `_COMMON_DATA` | why common |
| --- | ---: | ---: | --- |
| `process_launch` | 467 | 201 | `SYS_EXEC` resume gate and per-depth continuation state restored while the mapping changes |
| `banking` | 123 | 265 | mode 10/11 gates; 256-byte gate stack + saved latch/IFF/SP |
| `user_copy` | 167 | 92 | mode-crossing user-buffer copy primitive |
| `rom_access` | 148 | 136 | mode-00 mirrored stub; 128-byte staging + request state |
| `irq_entry` | 141 | 0 | IRQ entry gate (full context + mode cross) |
| `syscall_entry` | 125 | 0 | `RST 30h` syscall gate |
| `start` | 97 | 0 | boot common entry and C runtime init |
| `early_console` | 68 | 0 | pre-console panic path (runs before any device) |
| `panic`, `platform_irq` | 37 + 37 | 0 | panic and IRQ init |
| **packed total** | **1410** | **694** | 2104 of 7424 bytes |

Fixed absolute reservations outside the packed run: IM2 vector page
`FD00h-FE00h` (256), IRQ transition state `FE01h-FE7Fh` (127), transition
stack `FE80h-FEFFh` (128) - 511 bytes.

### 2.4 Resident ZMOD images

| module | image | BSS | total | granules | rounding waste |
| --- | ---: | ---: | ---: | ---: | ---: |
| `sio` | 324 | 4 | 328 | 1 | 184 |
| `ioc` | 3599 | 112 | 3711 | 8 | 385 |
| `hid` | 955 | 24 | 979 | 2 | 45 |
| `v9958` | 4038 | 460 | 4498 | 9 | 110 |
| `iocfat` | 6006 | 637 | 6643 | 13 | 13 |
| **boot set** | **14922** | **1237** | **16159** | **33** | **737** |

Granule rounding waste is 737 bytes (5.0 of the 33 allocated granules);
the other 1024 bytes are the two free granules.  Rounding waste is already
paid for: it only becomes a granule when a module is pushed back below its
threshold in section 1.

## 3. Findings, ranked

Classes: **A** reusable structural improvement that keeps layering; **B**
contained low-risk cleanup; **C** code golf (listed, not recommended unless a
granule is cheap).  "Granule effect" is the ledger change; a saving that does
not cross a threshold frees zero granules.

### 3.1 Category 1 - duplication across the kernel and ZMODs

**F1 (C, 24 bytes, 0 granules).**  `modules/runtime/sdcc_indirect_calls.asm`
defines `___sdcc_call_iy` (2), `___sdcc_call_hl` (2) and `___sdcc_enter_ix`
(9); the 13-byte object is packed into all five modules.  The copied subset
each module actually references is `sio` 2, `ioc` 11, `hid` 4, `v9958` 11,
`iocfat` 13 (41 of 65 bytes).  Splitting the shared source per module saves
24 bytes but breaks the single-source runtime; not recommended.  Kernel copy:
11 bytes (`sdcc_helpers`) + 2 (`irq_code_end`) = 13.

**F2 (C, ~200 bytes total, 0 granules).**  Little-endian decode/encode is
re-implemented per owner: `_romfs_le16` 5 + `_romfs_le32` 52 + `_fs_le16` 31
+ `_read_le16` 5 in the kernel; `_iocfat_get16` 5 + `_iocfat_get32` 52 +
`_iocfat_put16` 4 + `_iocfat_put32` 37 in `iocfat` (98 bytes).  The module
copies are required by module isolation (a ZMOD may not import kernel
symbols), so only the kernel-side pair could share, and the widths differ.

**F3 (A, 222 measured / ~60-120 reclaimable, 0 granules).**  ASCII
case-insensitive compare is implemented three times in the kernel:
`_vfs_name_equal` 85, `_romfs_name_match` 120, `_device_name_equal` 17.
A single kernel-private `zos_ascii_equal_ci` helper would serve VFS, ROMFS
and the device registry.  This is the one category-1 item worth doing: it is
reusable and keeps layering, but its ~100 bytes alone do not reach the
316-byte kernel-code threshold.

### 3.2 Category 2 - SDCC runtime helpers pulled in accidentally

**None found.**  No `__mulint`, `__divuint`, `__modslong`, `__rlslong`,
`__rrulong` or any 32-bit/soft-multiply helper appears in any kernel or
module `.rel`/`.sym`.  The only SDCC runtime symbols anywhere are the three
frame/indirect-call helpers: `___sdcc_enter_ix` (9, selected by
`--opt-code-size` for stack-argument frames) and `___sdcc_call_iy` /
`___sdcc_call_hl` (2 each).  They are deliberate and already covered by F1;
there are no accidental helpers and thus no call sites to remove.

### 3.3 Category 3 - oversized static buffers / duplicated workspace

**F4 (B, 128 bytes data, 0 granules).**  `kernel/process/process.c` keeps
`_zos_process_path_scratch[128]` (`_DATA`) for the `SYS_EXEC` path copy-in.
It does not cross a mode change, and the VFS workspace already provides four
128-byte path slots (`VFS_WS_SLOT`); the boot loader already builds its
module path in `VFS_WS_IN_A`.  The exec path could use the same slot (the VFS
workspace is provably free in the syscall path before any VFS call reads the
path).  Saves 128 bytes of data; the data threshold is 449, so this raises
slack, not the granule count.

No other buffer is oversized: `vfs_workspace` (512) exactly tiles its four
path slots and staging; `vfs_cwd_path[4][128]` is `ZOS_EXEC_MAX_DEPTH` x
`ZOS_PATH_MAX`; the `iocfat` 512-byte cache is a required 32.19 feature; the
`v9958` 256-byte renderer stack and font/atlas staging are bounded by VDP
timing.  No second copy of the VFS workspace pattern was found.

**F5 (B, 60 bytes data, 0 granules).**  `module_loader`'s `granule_used[95]`
is sized to the architectural maximum (`ZMOD_MAX_GRANULES`), but the derived
production arena has 35 granules; sizing the bitmap from the image granule
count would save 60 bytes.  Risky for acceptance images with a different
arena, so only if the loader consumes a build-time count.

### 3.4 Category 4 - per-module rounding waste

Already tabulated in section 2.4 (737 bytes over five modules).  The
threshold table in section 1 gives the exact per-module saving that would
reclaim each: `ioc` 127, `v9958` 402, `hid` 467, `iocfat` 499, `sio`
impossible (one granule is the minimum).  No rounding waste can be reclaimed
without crossing one of those, so the granule effect of category 4 alone is
**zero**.

### 3.5 Category 5 - resident functions that could move to user space

**None found.**  The monitor is already an ordinary user process in the
recovery store, launched through `/SYSTEM/monitor.zex`; it owns the
userland-facing diagnostics.  Every remaining resident function holds a
system responsibility that cannot run from user space: the kernel boot path
(`romfs_diagnose`, `kernel_module_unavailable`) runs before any process
exists; `kernel_boot_report` is the launcher's post-exit reporting; the M7
`diag` service only performs privileged bank/IRQ inspection on behalf of the
user-space monitor.  Nothing here is safely relocatable without redesigning
a boot mechanism (that is M10/M12 scope, not reclaim).

### 3.6 Category 6 - generic helpers duplicated inside `iocfat`

**F6 (C, 223 bytes, 0 granules).**  `iocfat` carries `_iocfat_get16` 5,
`_iocfat_get32` 52, `_iocfat_put16` 4, `_iocfat_put32` 37, `_iocfat_copy` 57
and `_iocfat_copy_from` 68 - 223 bytes of generic little-endian/copy
primitives that the kernel (`_romfs_le*`, `_fs_le16`) and SDK already have.
A ZMOD cannot import kernel symbols (module isolation), and folding them into
the shared `sdcc_indirect_calls`-style runtime object still copies them into
every image.  `_iocfat_get32` (52) and `_iocfat_put32` (37) are unusually
large for their work; a table/unrolled form is pure code golf.  **No byte
saving is available** without a module-facing helper ABI, which is M10+
scope.

The 8.3 name codec (`_iocfat_pack` 287, `_iocfat_unpack` 141,
`_iocfat_legal` 75, `_iocfat_walk` 128) is provider-private FS2 policy, not a
duplicated kernel helper.

### 3.7 Category 7 - code paths with no current consumer

**F7 (B, 338 bytes kernel code, frees 1 granule).**  Five exported kernel
functions have no caller anywhere in the tree (kernel, drivers, providers,
SDK or target tests); they survive only their own definition plus the
declaration and the `mapcheck.py` placement list:

| symbol | file | bytes |
| --- | --- | ---: |
| `zmod_validate_container` | `kernel/module/relocate.c` | 237 |
| `module_load` | `kernel/module/loader.c` | 63 |
| `vfs_path_normalize` | `kernel/vfs/path.c` | 28 |
| `vfs_provider_owner` | `kernel/vfs/mount.c` | 5 |
| `device_registry_owner` | `kernel/device/registry.c` | 5 |
| **total** | | **338** |

`zmod_validate_container` is the memory-blob M4 entry; the M9 loader uses
`zmod_validate_source` via the VFS adapter.  `module_load` is documented as
the historical blob wrapper beside the VFS adapter.  `vfs_path_normalize` is
the fixed-`/` wrapper around the used `vfs_path_normalize_at`.
`vfs_provider_owner`/`device_registry_owner` are unused accessors.

338 bytes is above the 316-byte kernel-code threshold, so removing them
moves `__kernel_code_end` from `8F3Ch` to about `8DEAh`, drops the arena
start one granule (`9000h` -> `8E00h`) and frees **one granule**.  Risk:
removal touches `include/zephyros/module.h`, `kernel/vfs/vfs.h`,
`kernel/device/registry.h`, the `mapcheck.py` bank-7 symbol list and the
`tests/maptools.py` fixture maps; the exact link delta must be measured in
30c.  This is the single largest clean reclaim in the audit.

**F8 (B, 36 bytes module code, 0 granules).**
`v9958_write_ctrl_byte` (36 bytes, `drivers/v9958/v9958.c`) is a dead
`static` function; `v9958_write_palette_byte` beside it is used.  Removing it
gives `v9958` 4462 bytes, still 9 granules (needs 402).  An unused
`FS2_CMD_RESET` macro in `iocfat` emits no bytes.

### 3.8 Category 8 - inefficient tables / constants

**F9 (C, 17 bytes data, 0 granules).**  `registry`'s
`device_generation[16]` is a 16-bit array (32 bytes) and
`_device_next_generation` is 16-bit; generation is a wrap-detection counter,
so 8 bits suffice for 16 devices.  `_device_generation` 32 -> 16 and
`_device_next_generation` 2 -> 1 saves 17 bytes.  Everything else measured is
already efficient: `iocfat_status_table` (15) and `iocfat_open_table` (16)
are table-driven; the 32-bit offsets and generations in VFS/`iocfat` are
required by the native ABI and the FS2 protocol, not a 16-bit-suffices case.

### 3.9 Category 9 - stored state that could be recomputed

**F10 (C, ~16 bytes, 0 granules).**  `iocfat.files[2].generation` (8) and
`iocfat.dirs[0].generation` (4) mirror `iocfat.generation` for media-change
stale detection; `vfs_cwd_owner[4]` (4) tags the CWD slot owner.  All three
are cheaper to store than to recompute (a scan of the process/descriptor
state) and none is material.  `_device_generation` is covered by F9.

### 3.10 Category 10 - consolidating filesystem/provider logic

**None found within the layering.**  VFS is already the single common path
layer: mount selection, path normalization, the descriptor pool, the CWD
pool and the root merge live once in `kernel/vfs/`.  The per-provider handle
pools (`romfs_provider` `_romfs_pv_slot_alloc/get` 96 bytes vs `iocfat`
`file_alloc/get`, `dir_alloc/get` 121 bytes) are provider policy by
architecture 32.30 - the global pool is the VFS *descriptor* pool, not a
provider-handle pool - so moving them into VFS would violate 32.10-32.12.
The one legitimate shared helper is F3 (kernel ASCII-ci compare).

### 3.11 Ranked summary

| rank | id | category | class | bytes | region | granule effect |
| ---: | --- | --- | --- | ---: | --- | --- |
| 1 | F7 | 7 no consumer | B | 338 | kernel `_CODE` | **+1 granule** |
| 2 | F3 | 1 duplication | A | 60-120 | kernel `_CODE` | 0 (feeds the 316 threshold) |
| 3 | F4 | 3 buffers | B | 128 | kernel `_DATA` | 0 (data slack +128) |
| 4 | F5 | 3 buffers | B | 60 | kernel `_DATA` | 0 |
| 5 | F8 | 7 no consumer | B | 36 | `v9958` image | 0 |
| 6 | F1 | 1 duplication | C | 24 | five modules | 0 |
| 7 | F9 | 8 tables | C | 17 | kernel `_DATA` | 0 |
| 8 | F10 | 9 stored state | C | 16 | kernel `_DATA` | 0 |
| 9 | F2 | 1 duplication | C | ~200 | kernel + `iocfat` | 0 |
| 10 | F6 | 6 helpers | C | 223 | `iocfat` | 0 |

F7 is the only finding that frees a granule by itself.

## 4. `iocfat` threshold analysis

```text
iocfat: image 6006 + bss 637 = 6643 bytes = 13 granules (6656-byte ceiling)
  12 granules at 6144 bytes: needs 499 bytes removed
  11 granules at 5632 bytes: needs 1011 bytes removed
  current rounding room to 14 granules: 13 bytes
```

`iocfat` is the tightest module (13 bytes of room), and the correction
already trimmed it: the constructor is one bulk helper (`_iocfat_transfer`
395) and table-driven status/open mapping, and all five FS2 command handlers
have consumers.  The only sizable non-essential bytes are the F6 generic
helpers (223), which cannot be removed because a ZMOD may not import kernel
symbols, and the required 512-byte write-through cache - removing the cache
would reach 12 granules but lose a required 32.19 feature.

**Result: 12 granules is not realistically reachable with A/B findings
alone** (499 bytes, with no dead code and no removable duplication), and 11
granules (1011 bytes) is further out of reach.  `iocfat` should stay at 13.

## 5. Common-memory ceiling proposal

Every packed common item is listed with its owner in section 2.3; all are
mode-crossing or boot-critical.  Measured M9 use is 2104 of 7424 bytes (1410
code + 694 data), with 511 bytes of fixed reservations above the packed run.

Target 2.13-2.15 adds common memory for the far-call contract: the
mode-crossing far-call gate/return trap and the per-process far-execution
state (the auxiliary low window itself lives in the auxiliary bank's
`0100h-1FFFh`, not common).  Estimate: common code 128-256 bytes, common
data 16-32 bytes; round to a **512-byte M10 reservation**.

Proposal:

```text
common-memory ceiling (packed _COMMON + _COMMON_DATA)  3072 bytes
M10 far-call reservation                               -512 bytes
M9 enforced limit (used <= ceiling - reservation)      2560 bytes
current use                                            2104 bytes
spare against the enforced limit                        456 bytes
```

Derivation: the M10 common estimate rounds up to one granule (512); 3072
leaves 968 bytes above the current use, of which 456 is M9/M10 working
margin and 512 is the far-call reservation.  Pinning the ceiling at 3072 and
enforcing `used <= 2560` keeps the current build valid and makes any future
common growth visible on the `common:` line.  Package 30c pins the value in
the platform memory description, enforces it in `mapcheck`, and prints it.

## 6. M10 residency estimate

Using the measured M9 density (about 6.7 bytes per C line; section 32.39 and
the package-26 record) and the measured ZEX v1 loader.  "Net new" counts
what replaces the removed ZEX v1 code (600 + 100 + 239 = 939 bytes in
`process_exec`).

| M10 mechanism | kind | kernel code | kernel data | common |
| --- | --- | ---: | ---: | ---: |
| `SYS_XMEM_*` family + allocator | new | 500-900 | 16-32 | 0 |
| Unified bank ownership | extend | 200-340 | 8-16 | 0 |
| ZEX v2 loader (aux segments, reloc, 32-bit, far-entry validate) | replace v1 | +360 to +1060 net | 32-64 | 0 |
| Far-entry table | new | 100-170 | 48-96 | 0 |
| `SYS_FAR_CALL` + auxiliary low window | new | 270-470 | 32-64 | 128-256 |
| `SYS_ZEX_SEGMENT_INFO` | new | 100-170 | 0 | 0 |
| **net total** | | **~1530-3110** | **~136-272** | **128-256** |

Headroom comparison.  The budget is one total, but code and data move the
arena in 512-byte steps, so the room is best read from the threshold table:
the production boot set is 33 granules, the floor is 32, and the current
free count is 2.

```text
post-30:  2 free granules + 196 code room + 63 data slack
          => up to 1220 bytes of kernel code, or 1087 of data, or ~1283 mixed
best-case post-reclaim (F7 + F4):  3 free granules, code end 22 bytes below
          a boundary + 191 data slack
          => up to 1558 bytes of kernel code, or 1727 of data, or ~1749 mixed
M10 estimate, low  (code 1530 + data 136, common 128):
          does not fit post-30; fits the post-reclaim mix (code <=1558, data <=191)
M10 estimate, high (code 3110 + data 272, common 256):
          fits neither
```

Even the low estimate exceeds the post-30 budget before the boot set fits
(1530 code > 1220 code), and it fits the best-case post-reclaim budget only
in the favorable mix.  Common stays inside the 512-byte M10 reservation with
room to spare.  The M10 mechanisms are kernel-resident by name and semantics
(allocator, loader, syscall family, far gate), so reclaiming the two free
granules is not sufficient for the high estimate and only barely sufficient
for the low one.

## 7. Recommendation

Implement in **package 30c** (all behavior-preserving):

1. **F7 (required, +1 granule):** remove the five dead exported functions.
   Update `include/zephyros/module.h`, `kernel/vfs/vfs.h`,
   `kernel/device/registry.h`, the `tools/mapcheck.py` bank-7 symbol list and
   the `tests/maptools.py` fixture maps with them.
2. **F3 (recommended, class A):** consolidate the kernel ASCII
   case-insensitive compare into one helper; keep the ROMFS/VFS semantics.
3. **F4 (recommended, +128 data slack):** share the exec path buffer with the
   VFS workspace path slot.
4. **F8, F5 (optional):** drop the dead `v9958` function and, only if the
   loader can consume a build-time granule count, the oversized bitmap.

Do **not** implement F1/F2/F6 (module isolation, no bytes), F9/F10 (not
material), or remove the `iocfat` cache.

Expected end-of-M9 ledger after F7 + F4 (F3 helps but does not cross the
threshold on its own): arena 36 granules, 33 boot, 3 free; runtime data 2113
at `D600h` (the 128-byte scratch moves but the data base stays `D600h`), so
`slack` rises to 191 and total slack to `3 x 512 + 191 = 1727` bytes - above
the 1 KiB target and enough to make the low M10 estimate fit.  If F4 proves
unsafe, the fallback is `3 free granules, 63 slack = 1599`.

**Does M10 fit?**  Not with confidence.  After the reclaim the low estimate
fits and the high estimate does not; the mechanisms are all resident kernel
code.  Per target architecture sections 1 and 2.18, the project owner must
decide the larger kernel-residency architecture (for example a second kernel
bank or relocating a resident mechanism) **before** M10 implementation, and
must not weaken the 32-granule floor or the common ceiling chosen in
section 5 to make it fit.

## 8. What this package changed

Measurement tooling and its test only:

* `tools/pack_image.py` - `granule_thresholds`, `kernel_granule_thresholds`,
  `format_granule_thresholds`; `manifest["kernel"]`; the printed table.
* `tools/zmodpack.py` - per-module threshold fields, `plan["kernel"]`, the
  printed table.
* `tests/test_pack_image.py` - `TestGranuleThresholds`.
* `docs/memory.md`, `docs/module-format.md` - the new report format.

No finding was implemented.  No kernel, driver, provider, SDK, program or
image byte changed.

## 9. Validation

```sh
make clean && make check
python3 -m unittest tests.test_pack_image tests.test_m8 -v
git diff --check
```

Production artifacts identical to the accepted package-30 build
(sha256):

```text
build/zephyros.bin   7966f18fb5ecd58eeebc09ca8f857e0dae5399145450a4dcd44973f255a09b7c
build/zephyr80.bin   7966f18fb5ecd58eeebc09ca8f857e0dae5399145450a4dcd44973f255a09b7c
build/modules/sio.zmod     bf435bcacd42bc93148b3d84b5896463884ff304c56b40a90da6578321388159
build/modules/ioc.zmod     3f1e3fa26b2d1635d2457876276c8be935fe662560eda004b8c3668b53004b5d
build/modules/hid.zmod     7513af162fde691780a6e853be0916dd0ec46fbbd024ee124e92c0601d2174d7
build/modules/v9958.zmod   a978e7a0b83c269de5a67ac5f0413fa526d1191eeb13e2eaf636f9a1d24891f3
build/modules/iocfat.zmod  5efd30fa1e428c0c546eaaa8ee11048646a01c522680ac5ee64fe4d4e5cbcaa6
build/recovery.romfs       39244134dd10ff4853cc580d8cc5b6c2ed1ab8166e65e278addff3ec8040e149
```

No hardware run (measurement-only package).
