# Package 51 — m11 shell commands

The native shell's file built-ins: `ls cat stat cp mv rm mkdir rmdir` in
`user/shell/fscmd.c`, on the public SDK only, plus the tests and the one
`mv` policy the system does not offer (a rename across providers becomes a
copy and an unlink).  No kernel, driver, SDK, system-file or store change:
the shell is still a card program, started with `X /fs/SHELL.EXE`, and the
production image is byte-for-byte the one package 50 validated.

## Files

Added:

| file | part |
|---|---|
| `user/shell/fscmd.c` | the file built-ins, the `cp`/`mv` target rule and the copy loop |
| `work/51-m11-shell-commands/progress.md` | the package's progress note (untracked: `work/` is ignored) |

Changed:

| file | change |
|---|---|
| `user/shell/shell.h` | `shell_file_command`, `shell_fscmd_target`, `shell_path_root` |
| `user/shell/path.c` | `shell_path_root` (fs/system/dev or NULL); `path_reserved_root` defers to it |
| `user/shell/builtin.c` | `help` lists the file built-ins; `shell_builtin` falls through to `shell_file_command` |
| `Makefile` | `fscmd.c` in the shell's `exe_program` source list |
| `tests/test_shell.py` | the target rule, the no-card message path, the staging-area guard, the linked-member list |
| `tests/test_shell_sim.py` | the file-command session; the `help` row of the 50 session |
| `tests/test_source_layout.py` | `user/shell/fscmd.c` in `OWNER_FILES` |

Removed: none.

## Result

Every requirement of `work/51-m11-shell-commands/WORK.md` is implemented
and validated.

| requirement | where |
|---|---|
| 1 one shared `io_buf[512]`, no other buffer over `KOS_PATH_MAX` | `fscmd.c` |
| 2 `ls [path…]`, containers, sizes, several arguments | `fscmd_ls*` |
| 3 `cat file…` raw, 512-byte chunks | `fscmd_cat*` |
| 4 `stat path…` (`type`/`attributes`/`size`/`mtime`) | `fscmd_stat*` |
| 5 `cp src dst`, target rule, `sync`, `EISDIR`, partial-target unlink | `fscmd_cp`, `fscmd_copy_data` |
| 6 `mv src dst`, `rename` first, `EXDEV`/roots, kept copy on a failed unlink | `fscmd_mv` |
| 7 `rm`/`mkdir`/`rmdir`: one call per argument, last error wins | `fscmd_leaves` |
| 8 `<cmd>: <display path>: <message>`, positive status | `fscmd_error` and the package-50 table |
| 9 the size is recorded, far code only over 24 KiB | below — no far code |

**Shell size** (`build/user/shell/shell.report.json`):

| | package 50 | package 51 |
|---|---|---|
| packed `shell.exe` | 10602 | **16272** |
| primary image | 10566 | **16236** |
| BSS | 1487 | **3023** |
| stack | 512 | 512 |
| segments | 0 | **0** |

The primary image is 16 KiB, well under the 24 KiB line, so `fscmd.c`
stays in the primary image and no `FAR1=` segment was added.

sha256 `build/user/shell.exe`:
`f589167e5ed988e9abd97123d2a1ad67229a95cf8528f1d85b2b7785670a7ebe`

`build/user/shell/shell.json` image sha256:
`7489c8e7c5e60372c3c67ab3033f245334b58bce1c8985956a0136c3f257a78`

## Validation

One batch, in this order (wall clock 1 min 30 s):

1. `make` — during development this built the shell's objects, link and
   pack from the new source list (the identities above are the default
   target's own output); the run in the final batch then reported
   "Nothing to be done for 'all'".  The production image and the monitor
   were never rebuilt (`build/konaos.bin` sha256
   `3638e156229e79320a5a221a86548c841e578ffb96085223214e71f39b03051d`,
   `build/modules/monitor.exe` 6310 bytes /
   `8a25071a468ff7aca212d929d03f2088c0eef5d8412be17b9eddc7b651acde7f`:
   the package-50 values), so the pinned acceptance identity needed no
   re-pin.
2. `python3 -m unittest tests.test_shell tests.test_shell_sim` — **20
   tests, OK, 89.9 s**.  The two replays are 34.5 s (the file session) and
   the rest is package 50's scripted session.
3. `git diff --check` — clean.

Extra (with reasons):

- `python3 -m unittest tests.test_sdk tests.test_console_acceptance` — 34
  tests, OK, 1 skipped, 48.4 s.  The SDK is untouched, but the shell's
  program entry lives in `tests/test_sdk.py`'s declared list, and the
  acceptance replay is the strongest statement that the production image
  still boots after the build; it passes untouched.
- `python3 -m unittest tests.test_source_layout` — 52 tests, OK: the
  package adds `user/shell/fscmd.c` to its owner file list.

## The host tests

Two kinds of row could not be replayed (the shell is started from the
card, so a card-less run of it does not exist before package 52), and the
package's WORK.md puts both on the host:

- **the `cp`/`mv` target rule** — `shell_fscmd_target` is linked
  non-static, so `tests/test_shell.py` calls it on the image itself and
  asserts the resulting string: a directory destination (`stat` answer),
  a trailing `/` with no `stat` answer, a name destination, a relative
  destination, the longest target there can be (63 + 63 bytes) and a
  refused one over the limit.
- **the `no device` message path** — `_stat`, `_list` and `_mkdir` are
  replaced by `-KOS_ENODEV` stubs staged in the program's bank and
  `_console_write` by a capture stub, then `shell_file_command` runs
  `ls /` and `mkdir /X`: both return `KOS_ENODEV` and print
  `ls: /: no device` and `mkdir: /X: no device`.  The capture reads the
  buffer back through the memory map, because `printf` formats on the
  process stack (in the common bank) — a formatted message shorter than
  printf's 32-byte flush buffer arrives as one call.

The staging constants moved with the image: package 50 staged at
0x4000-0x4600, and the linked image and BSS now end at 0x4C3B, so the
host tests stage at 0x6000-0x7000.  `TestShellArtifact` gained
`test_it_leaves_the_host_tests_their_staging_area`, which fails if a
future image grows into them (that failure would otherwise look like a
test bug).

## The session replay

`tests/test_shell_sim.py` gained `test_file_commands`: the production
image, the emulated card and `X /fs/SHELL.EXE`, one typed session.  Every
write stays in `/fs/SHTEST`, which the session creates with `mkdir` and
removes again, so the end of the session asserts the card is exactly as it
was found.  The rows and what they pin:

| row | pins |
|---|---|
| `ls //` | the three namespace roots as containers |
| `ls /` | the card: two files with their decimal sizes, `SUB/` |
| `ls /system` | the packed store's names and sizes (`build/recovery.romfs`) |
| `ls /dev` | `serial/ ioc input/ video console` — the publication table's order and containers, with no sizes (a `/dev` entry's `stat` does not answer) |
| `ls /dev/input` | a grouping entry's own child |
| `ls /SUB/ORIG.TXT` | a file's single line (`ORIG.TXT  4`) |
| `ls /SUB /system` | `<display path>:` before each of several listings |
| `cp /SUB/ORIG.TXT`, `cat` | `usage: cp src dst` and `usage: cat file ...` (package 50's argument-count rule) |
| `mkdir /SHTEST`, `ls /SHTEST` | creation, and that an empty listing prints nothing |
| `cp /SUB/ORIG.TXT /SHTEST` | a directory target takes the source's last component |
| `cp /system/known.bin /SHTEST/KNOWN.BIN` | a name target, and the copy's bytes (asserted against the store's payload) |
| `cat /SHTEST/ORIG.TXT` | the copy reads back as `card`, the source's bytes |
| `stat /SHTEST/ORIG.TXT` / `stat /SHTEST` | all four lines for a file and for a directory |
| `mv /SHTEST/ORIG.TXT /SHTEST/MOVED.TXT` | the rename: one name gone, the other there |
| `mv /system/known.bin /SHTEST/STORE.BIN` | the copy, then `mv: /system/known.bin: read-only` with the copy kept |
| `rm` of two files and one missing | `rm: /SHTEST/MISSING.TXT: not found`, and the others gone |
| `rmdir /SHTEST` (non-empty), `rm /SHTEST/STORE.BIN`, `rmdir /SHTEST` | `rmdir: /SHTEST: not empty`, then the removal |
| `cp /SUB/ORIG.TXT /system/X.TXT` | `cp: /system/X.TXT: read-only` |
| `exit 0` | the monitor's `exec: exit status 0x0000` |

The `help` row of package 50's session now pins
`built-ins: cd pwd echo path help exit ls cat stat cp mv rm mkdir rmdir`
(one line, 70 columns).

## Notes, decisions and uncertainties

- **`ls` is `stat` first, `list` second.**  Only `stat` answers "file";
  only `list` answers for `/` and `/dev`, whose `stat` is the namespace's
  own and returns `ENOENT`.  So a failed `stat` is not an `ls` error
  until the listing fails too, and an entry's size is skipped when its own
  `stat` fails — which is exactly every `/dev` entry.
- **`mv` decides by reserved root, not by the error alone.**  The router
  sees the source first and answers `EROFS` for a `/system` path before it
  ever looks at the destination, so `mv /system/x /fs/y` must not try
  `rename` at all; the shell compares `shell_path_root` of both sides (a
  relative path takes the CWD's root) and copies directly.  `EXDEV` from
  a same-root `rename` still falls through to the copy.
- **A failed unlink keeps the copy and is the status.**  `mv
  /system/known.bin /SHTEST/STORE.BIN` copies, then reports
  `read-only`; the copy is on the card, asserted byte for byte.  This is
  the shell's policy, not the system's ("the system never turns a rename
  into a copy", `docs/filesystem.md` section 2).
- **The copy loop handles a short write.**  `KFILE_OP_WRITE` may complete
  in part; the driver advances the position with the bytes it confirmed,
  so the rest goes out as the next chunk.  A zero-progress write is
  `KOS_EIO`.  A failed read, write or flush closes both handles, removes
  the partial target and reports that error.
- **`attributes` and `mtime` are 0 everywhere today** — the card driver
  and ROMFS both report no attributes and `KFS_TIME_UNKNOWN`, and a
  directory's `size` is 0 by the ABI.  The formats (`%02x`, `%08lx`,
  `%lu`) are pinned in the replay so a future provider with real values
  shows up as a test failure, not a surprise.
- **Static path buffers, not stack ones.**  `cp` needs three paths and the
  program's stack is 512 bytes; the six `KOS_PATH_MAX` buffers and
  `io_buf` are static because the shell is single-tasked and the file
  commands are leaves (they call the SDK, never back into the shell).
- **`stat` prints the number for a type that is neither file nor dir**;
  no provider produces one today.
- **A destination word that is empty** (`cp x ""`) fails on `open` with
  `invalid argument`; nothing else can go wrong with it.
- **The store's `ls` order is the manifest's** (the ROMFS enumerates its
  directory in order), so the replay's expectation is computed from
  `build/recovery.romfs` rather than transcribed: it stays exact, and it
  moves with the store.
- **No documentation change was needed.**  `docs/architecture.md`
  section 14 already names the file built-ins and `mv`'s copy-and-unlink
  policy; the shell is still a card program, and package 52 documents its
  place in the store.
- **No hardware run**: this package changes no driver, no store and no
  kernel code, and the production image is byte-identical to the one
  package 50 validated.
