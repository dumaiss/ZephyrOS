# 2026-11-01 xmem-objects: 32 extended-memory objects system-wide

Result: **PASS** (sim). Board: **PENDING** (owner steps below).

## Change

- `kernel/syscall/xmem.c`: `XMEM_MAX_OBJECTS 32u`; `XMEM_HANDLE_MAX`
  (`32 * 16 - 1` = `1FFh`) replaces the `handle > 0xFFu` bound in
  `xmem_lookup`, and the now-redundant `index >= XMEM_MAX_OBJECTS` test is
  gone (the bound implies it; 10 bytes of cold code freed). Structural
  property: `_Static_assert(XMEM_HANDLE_MAX == 0x1FFu, "an xmem handle is
  9 bits: index 0-31, generation 1-15")` beside the 12-byte entry assert.
  Header and table comments state the 9-bit handle.
- `user/sdk/src/seg.c`: `farmap_handles[4]` was `unsigned char` (a byte
  store of an xmem handle); it is `unsigned int` (+4 bytes BSS in programs
  linking `farmap`).
- `tests/xmem/xmem_selftest.c`: `held[]` sized by `XMEM_OBJECTS` (32), so
  every fill loop stops at `KOS_ENOSPC` (the `exec-child-released` fill is
  memory-bound again, 25 objects, not capped by the array); five boot-path
  rows `objects-32`, `objects-33-refused`, `objects-handles`,
  `objects-reuse`, `objects-stale`.
- `tests/test_xmem_selftest_sim.py`: the five rows in `OUTCOMES` (68
  checks); the token-cache frame pin (below).
- `docs/architecture.md` 4.8: "At most 32 objects exist system-wide ...;
  the 33rd allocation is `KOS_ENOSPC`" (only that bullet; the file's other
  uncommitted changes are package 108's and were preserved).
- `docs/memory.md` 4: the cold ledger line, the window-data base sentence
  and the object table's size (32 x 12 = 384 bytes).

## The exhaustion proof (boot path)

With the two anchors live, 25 plain one-slot objects fill the plain runs
and 5 mappable ones fill the table: 32 live (`objects-32`). The 33rd -
mappable and plain - is `-KOS_ENOSPC` while 3 mappable runs are still free
(`objects-33-refused`). Every held handle answers `xinfo` and the highest
is above `FFh` (`objects-handles`). Freeing the last plain object (index 26,
handle above `FFh`) frees a table entry but no mappable run, so the
mappable allocation that follows can only succeed through that entry: same
index, different handle (`objects-reuse`). The old handle is stale, and the
live handle plus `1000h` (which a byte-truncated index would alias) is
`-KOS_EINVAL` (`objects-stale`). In a stage run the open banks bind before
the table, so the rows are boot-path only; the exerciser's stage count
stays 61.

## Handle stores audited (none narrows to a byte after this change)

| place | type |
|---|---|
| `kernel/syscall/xmem.c:93` `xmem_lookup(uint16_t handle, ...)` | u16 |
| `kernel/syscall/xmem.c:219` alloc result `kos_syscall_success((uint16_t)...)` | u16 |
| `kernel/syscall/xmem.c:298` `*handle` (segment alloc out) | `uint16_t *` |
| `kernel/syscall/xmem.c:494,508,514-515` seg-info handle, record bytes 4-5 | u16, both bytes |
| `kernel/process/exec.c:721` loader segment handle | `uint16_t` |
| `abi/kos/xmem.h:111,121,141,151`, `abi/kos/seg.h:64` | `uint16_t` |
| `user/sdk/src/xmem.c:22-70` every wrapper | `unsigned int` |
| `user/sdk/src/xload.c:30,66,97` `object` | `int` |
| `user/sdk/src/seg.c:64` `farmap_handles` | **was `unsigned char`, now `unsigned int`** |
| `user/sdk/src/seg.c:98` `handle`, `farmap_scan` return | `int` |
| `user/sdk/kres/konaos/kres_cache_xmem.c:26` catalog cache | `int` |
| `tests/xmem/xmem_selftest.c:79,262-263,271,387,541` | `unsigned int` / `int` |
| `tests/xmem/xmem_child.c:107,112-113,237` | `unsigned int` / `int` |
| `tests/xmem/xmem_far.c:162-163`, `xmem_far_code.c:51` | `unsigned int` / `int` |
| `tests/fardata/far_data.c:126-127` | `int` |
| `tests/target/process/exe2seg.c`, `exe2big.c:37` (`info.handle`) | u16 / `unsigned int` |
| `tests/hwtest/hwtest.c:238` `held[8]` | `unsigned int` |

`tests/xmem/xmem_far.c:231` masks `(handle + 1) & FFh`: it compares a far
return value whose high byte is the latch, not a stored handle.
Read only (not edited): `UserSoftware/KonaEdit/src/ke_store.h:12`,
`ke_history.h:28-29` (`uint16_t`), `UserSoftware/DonkeyKong/main.c:208`
(`int`).

## Validation

| command | result |
|---|---|
| `make && python3 -m unittest tests.test_xmem_selftest_sim tests.test_ipc_selftest_sim tests.test_exe tests.test_far_data` | 85 tests OK, 19 skipped (ipc, subsys and fs images not built; exe2probe) |
| `make xmem-selftest` | 9 tests OK, 0 skipped; `xmem-selftest: 68 checks, 0 failures`, `xmem-far: 37 checks, 0 failures` |
| `make clean && make check` | 1037 tests OK, 120 skipped, 13 min 8 s (19:41-19:54) |

The 120 skips are the acceptance images `make clean` removes (subsys,
ipc, xmem, nucleus, fs, ns, console-serial, boot/driver failure images,
helloworld, phase, romfs-corrupt) plus two abstract harness bases; the
xmem replay ran before the clean on the frozen sources. No compiler
warning; 314 Python `ResourceWarning` lines from unrelated test helpers.
`git diff --check` clean; the history-word check prints nothing.

Images (sources frozen before both):

- `build/konaos.bin` sha256
  `477c10be1d6d7f29dbf1ff442ceeff3cc0957f3fd568eae4bad9c6b9c161359b`
  (plain make, and again after `make clean && make check`).
- `build-xmem-selftest/konaos-xmem-selftest.bin` sha256
  `cfdf5ad99fa412c54e413194de4f58cc21805a13549e4791797669fce36d765e`.

## Ledgers

| ledger | before | after |
|---|---|---|
| nucleus fixed | room 5,950 | room 5,950 |
| nucleus cold | code 25,087 end C1FFh, data 1,623 at C200h, room 6,057 | code 25,077 end C1F5h, data 1,815 at C200h, room 5,865 (rule ≥ 4,096) |
| driver hot / boot/bulk / mapped | 31,873 / 21,128 / 3,584 | unchanged |
| common | 3,067 of ceiling 3,072 | unchanged |

Data +192 as budgeted; code -10.

## Pins changed

- `tests/test_xmem_selftest_sim.py` `OUTCOMES`: +5 rows (63 to 68 checks).
  Source: WORK.md requirement 2.
- `tests/test_xmem_selftest_sim.py` token-cache class
  `("xmem_far", "___sdcc_bcall_ehl")` to `("xmem_far", "_bcall_token")`,
  counts unchanged `{1: 1, 2: 1}`. Class: test artifact. Source:
  `user/sdk/src/bcall.asm:97` as committed in 5b8cea5 (automatic
  placement) makes the `call _segmap` from the global subroutine
  `_bcall_token`; the pin predates it (e6cf239), and the last xmem-selftest
  record (2026-10-12-banked-calls) predates 5b8cea5. It failed on the first
  `make xmem-selftest` of this package independently of this change.

## Found outside scope

- The token-cache pin above (stale since 5b8cea5; fixed because it blocked
  the `make xmem-selftest` Must).
- WORK.md names `docs/snd-sdk.md` and `tests/test_ipc_selftest_sim.py` as
  mentioning the limit; neither does. Architecture 9 holds rules only (the
  values live in `docs/memory.md`), so it has no figure to change.
- No runtime test drives `farmap` with a segment handle above `FFh` (a
  segment's index is past 15 only when 16 entries are in use at its exec).
- `docs/alteration-guide-outline.md` appeared untracked during the run;
  not this package's, untouched.

## Preserved

The uncommitted package-108 SDK work and package 108b's `UserSoftware/`
changes were not edited (15 `UserSoftware/` files modified before and
after); `docs/architecture.md` keeps its other uncommitted hunks.

## Owner checklist (board)

1. Flash `build/konaos.bin` (sha256 above).
2. `/system/hwtest.exe`: expect `hwtest: 4/4 PASS`.
3. Run `kedit.exe`, open a file, then File > Open another: it replaces the
   document.
