# M13 SDK hot paths (package 63)

Implemented by the supervisor (owner request). The SDK only
(`user/sdk`): no ABI, kernel or driver change. Every program linked to the
SDK gains on its next build.

## Change

| area | change |
|---|---|
| `klibc/sdcc_arith16.asm` | `__divuint`/`__moduint` (and `kos_divuint`/`kos_moduint`) as one shift-subtract core, `kos_divmod16`; a 0 divisor returns 0 as before |
| `klibc/divmod.asm` | `kos_divmod16`/`kos_divmod32(value *, base)`: one step divides in place and returns the remainder |
| `klibc/mul.asm` | `__mulint`, `__mulschar`, `__mulsuchar`, `__muluschar`: an archive member, linked only by programs that multiply |
| `klibc/utoa.c`, `itoa.c`, `ultoa.c`, `ltoa.c` | one divide-by-base step per digit (printf through them) |
| `klibc/{memcpy,memset,memmove,memcmp,strlen,strcmp,strncmp,strchr}.asm` | the C byte loops replaced: `memcpy` unrolled `LDI`, `memset` an `LDIR` spread, `memmove` `LDIR`/`LDDR`, `strlen` `CPIR` |
| `klibc/sdcc_arith.c`, `sdcc_arith_entries.asm` | the 32-bit helpers only |
| `timer.c` | `timer_now` stores its four bytes directly |
| `exe.mk` | the member lists |
| `tests/test_klibc.py` | the routines driven in the simulator against Python's results (every input class, 0 divisors included) |
| `tests/z80sim.py` | `CPIR` and `LDDR`; `CPIR`/`CPDR` are charged for the iterations they run (they stop at the match), not for the whole `BC` count |

`call()` was left as it is: its frame copy is the ABI's message frame, and
the profile puts it at ~0.19 ms per call.

## Measurement

Simulator, user-mode profile of the phase program's read loop (54 reads):

| item | before | after |
|---|---|---|
| user-mode total | 385.2 ms | 294.0 ms |
| `__moduint` per call | ~3,400 T | ~51 T |
| `timer_now` per call | ~4,170 T | ~1,260 T |

Board (owner, 16:35 image): SDBENCH 512 B 15.77 ms (31.6 KiB/s), 4 KiB
35.4 KiB/s, checksum PASS. That is unchanged, as expected: the read path
didn't change here. `fs_selftest` 37/0 (card exec included), `hwtest` 4/4.

Not done: 32-bit division in assembly (`__modslong` and its family remain
in C; the profile's largest remaining user item when a program prints
32-bit values).

## Validation

```
make clean && make check                       OK except two tests, both fixed:
  test_sdk hello module set                    expected list updated (hello now links kos_divmod, not the 32-bit helpers)
  test_timer card copy                         simulator CPIR cost fixed; 0 expiries lost
tests.test_klibc test_sdk test_stdio test_timer test_events
  test_readpath test_shell_sim test_hwtest_sim test_io_sim   OK (106 tests, 11 skipped)
```
