# Console serial tee

## Result

The production console owns a serial rescue path.  Three 1Bh bytes from
the serial line toggle input ownership between the HID and the serial
line and arm a tee that mirrors `WRITE` and `PUTC` to SERIAL (VIDEO
first; a SERIAL failure does not fail the call); three more switch
ownership back, and the tee stays armed until the reboot, the
launcher's reset before every boot program included.  While the tee is
armed, `KCONSOLE_OP_RENDER` answers `-KOS_ENOTSUP`, so `libtui` falls
back to ANSI text, which the tee carries to both screens.

Detection is polled: every input op drains the serial line through
`KSIO_OP_GETC`.  Only the third consecutive ESC of a run is consumed;
the first two are data, so a VT100 key sequence's lead-in reaches the
program while the serial line owns input - the behaviour of ZSDOS's
`sercon_rx_sink`, matched exactly.

No kernel, filesystem, timer, sound or console-client behaviour
changed; the console-serial build is byte-identical to before.

## Files

Added:

- `tests/test_console_tee.py` - the production-image replays: arming,
  input ownership, the switch-back, partial-gesture resets, the
  consumed gesture, serial-side key sequences and the armed/unarmed
  RENDER answer (the TUI examples are packed into a copy of the
  production store; the code image is untouched).
- `docs/validation/2026-10-20-console-serial-tee.md`.

Materially changed:

- `drivers/console/console_proto.c` - the rescue state (three bytes:
  `input_owner`, `tee_armed`, `esc_count`, written only by the dispatch
  paths), the one-byte serial staging byte, the polled gesture drain,
  the per-op serial input answers and the teed output paths.
- `drivers/console/console-v9958-hid.json` - `SERIAL` as the third
  required dependency (`deps[2]`).
- `tests/test_console_acceptance.py` - the console image's resolved
  dependencies and the two-manifest selection check.
- `tests/test_systemgen.py` - the resolved production dependencies
  (class 4, 2, 1).
- `tests/test_iocfat.py`, `tests/test_pack_image.py`,
  `tests/test_sound.py` - the driver-hot reserve pin lowered from 2,048
  to 1,536 bytes (the budget rule below).
- `docs/devices.md` (console section and the driver table) and
  `docs/architecture.md` (5.5 composition, the 5.6 driver notes and the
  hot-tier ledger) - the rescue path and the lowered reserve.

## The serial-side ESC finding

The owner's hardware run showed the tee working but serial-side key
sequences losing their lead-in (left arrow rendered `[[D`, F1 `OP`,
with putty, tio and picocom alike).  The first implementation consumed
every 1Bh byte into the gesture count, so no program on the serial
line could ever receive an ESC.  The drain now matches ZSDOS's
`sercon_rx_sink`: only the third consecutive ESC is the gesture and is
consumed; the first two of a partial match are held and delivered as
data while SERIAL owns input.  The regression pin is
`test_serial_key_sequences_keep_their_lead_in` (`ESC [ D` and `ESC O P`
on the serial line report `0103 LEFT` and `0121 F1` through the key
decoder, teed to both lanes).  The shell's own `[[D`/`OP` echo at a
prompt is the pre-existing line editor behaviour (ESC is a control
byte); the console passes the full sequence through.  The owner
confirmed the fixed build in hardware: the gesture and the serial-side
key sequences both work on real terminals.

## Validation

```sh
make && python3 -m unittest tests.test_console_tee tests.test_console_acceptance tests.test_shell_sim tests.test_iocfat tests.test_source_layout
make console-serial-selftest
python3 -m unittest tests.test_tui_sim
make clean && make check   # once, at the end
```

- The prescribed batch: **87 tests, 0 failures** (7 tee, plus the
  console acceptance, shell and IOC-FAT/layout modules).
- `make console-serial-selftest`: **6 tests, 0 failures**, twice (before
  and after the final clean rebuild).
- `tests.test_tui_sim`: **41 tests, 0 failures** (the unchanged TUI
  replays, run as the record's proof of the unarmed invariant).
- `make clean && make check`: **OK** (45m31s); the rebuild is
  reproducible, the production image is
  `0a9f74a7293023f522e15738619f3390956a9c7cd13eecc05ec44c11c0c3c537`
  (konaos.bin equals zephyr80.bin).
- `git diff --check`: clean.

Image hashes after the final build:

```text
build/konaos.bin                0a9f74a7293023f522e15738619f3390956a9c7cd13eecc05ec44c11c0c3c537
build/modules/console-v9958-hid.mod
                                9534a607e802b01a717ec49da35673d27bb88889bc2892ddb3defcbfb560d107
build-console-serial-selftest/modules/console-serial.mod
                                1150f41f29a4c3ab77660564b984fe28bcb348b05447613a1ccc76f1c8d3d690
build-console-serial-selftest/konaos-console-serial-selftest.bin
                                913f9b5a0cf02096115539377137a3d4a2df0c370c8681c6994df7ea5efebe4b
```

## Budgets

| figure | before | after |
|---|---|---|
| driver hot tier free | 2,126 | **1,737** (reserve lowered 2,048 -> 1,536; growth 389 <= 590) |
| console-v9958-hid hot | 390 image + 0 bss | **773 image + 0 bss** (+383 <= 400) |
| console-v9958-hid io | 0 image + 4 bss | **0 image + 10 bss** (+6) |
| console-serial image | hot 377 + 0, io 0 + 4 | **byte-identical** (same module hash) |

## Informational

One idle `POLL`, unarmed, measured with the store's `iobench`
(`ipc.null`, 100 calls, min = mean = max):

- before: **15,368** T-states;
- after: **19,121** T-states (+3,753: the serial drain's one call per
  poll).

## Pins changed, with their sources

- `tests/test_iocfat.py`, `tests/test_pack_image.py`,
  `tests/test_sound.py`: the driver-hot reserve 2,048 -> 1,536, per the
  package's budget rule (growth up to 590 bytes; the measured growth is
  389, of which 383 is the console image and 6 the placement padding).
  Those three modules and the ledger row in `docs/architecture.md` were
  the only 2,048 pins.
- `tests/test_console_acceptance.py` and `tests/test_systemgen.py`: the
  console image's resolved dependencies gain `(1, 0)` (SERIAL), per the
  manifest change.

## Preserved

- Unarmed behaviour: the console acceptance, shell and TUI replays pass
  unchanged (the suites above).
- The console-serial build: its module is byte-identical (same SHA-256
  as before the package), and its selftest passes.
- `console_forward` stays the only path to a dependency: the tee is two
  such calls.

## Warnings, skips and pending

- No unexpected warnings or failures.  `make clean` removes the
  acceptance images, so the replay suites that need them ran before and
  after the clean gate as listed.
- Hardware (owner, 2026-10-20): the serial rescue path was tested on
  the board with real terminals - the ESC ESC ESC gesture arms the tee
  and takes input, serial-side arrow and function keys work with the
  fixed drain, ESC ESC ESC returns the input to the keyboard with the
  tee still armed, and `reboot` clears it.  Confirmed working.
  The simulator models no baud timing, flow control or terminal
  key-sequence timing; the hardware run covered them.

## Notes

- The unrelated changes present in the tree at the start of the package
  (none - the tree was clean) are preserved; no commit is made.

## Supervisor review

Accepted on 2026-10-20 (source review of commit `de3bf64` against the
worker's evidence; nothing rebuilt). Requirements 1-7 hold in
`drivers/console/console_proto.c`: the rescue state is the one
`console_rescue` struct, touched only by the dispatch paths; input is
served from the one staging byte while SERIAL owns it; the tee is two
`console_forward` calls, VIDEO first; RENDER is refused while armed. The
budget is within its rule (+383 bytes console, reserve 1,536, 1,737
free), and the console-serial module hash is unchanged. The owner's
board run covers the gesture, serial key sequences, the switch-back and
reboot.

Accepted deviation: `WORK.md` said the gesture's bytes are never
delivered. The owner's hardware finding (lost VT100 lead-ins) moved the
drain to ZSDOS's `sercon_rx_sink` rule: only the third ESC is consumed.
Consequence: a program reading the serial line receives the first two
ESCs of a switch-back gesture, as on ZSDOS.

Carried forward, not defects of this package:

- A TUI program already running when the tee arms sees `-KOS_ENOTSUP`
  after earlier RENDER successes; `libtui` then fails every flush.
  Fixed by package 74 correction-01, requirement 3, which is now the
  next priority; the tee tests start TUI programs after arming only.
- Idle POLL cost +3,753 T-states (board `ipc.null` 18,925): every input
  op drains the serial line. Draining only when the HID reports no key
  would remove it from the keyboard path; not required here.
- The SIO is polled with a 3-byte receive FIFO: a gesture typed while
  no program calls the console's input ops can be lost (the documented
  limit).
