# M10 driver services (package 41, correction 01)

Date: 2026-10-08.  Contract: `work/41-m10-driver-services/WORK.md` and
`correction-01/WORK.md`.

## Result

Package 41 is closed.  SIO, IOC, HID, V9958 and console are resident bank-6
services using service ABI 2 and the versioned protocols in
`abi/zos/protocol.h`.  Production routes IPC in the normal syscall dispatcher,
loads those five images from `services.man`, and retains IOC-FAT as the sole
arena driver until package 42.  The old console syscalls and the migrated
drivers' `zdriver_api` path are absent.  The registry implementation remains
only for module-loader/Mn-1 acceptance fixtures; it is not in the production
device path.

The console service composes HID, V9958 and SIO endpoints.  Early and panic
output remain nucleus-owned and the two tested degraded configurations retain
video/serial and serial/serial operation.  V9958 display reset is a hot path;
its font is read from the 2,048-byte bulk segment.  The IOC-FAT cold-half
client reaches IOC through the package-38 upcall path.

The CTC placement test leaves `drivers/ctc` in the nucleus: its production
role is global interrupt-source quiescing, not a device endpoint, and it must
be available independently of the service bank.  CTC0 programming remains
test-owned.

## Correction 01

### Gate-visible SDK state

Every ZEX now links `_ZOS_SDK_DATA` first.  Its 68-byte fixed area contains
`zos_scratch` (16 bytes), the raw syscall request (4), IPC lookup block (4),
and IPC call block (44) at `0100h-0143h`; ordinary code starts at `0144h`.
The caller-buffer probe deliberately uses `0300h-0343h` and code at `0344h`.
`zexmanifest` continues to enforce that every gate-visible block is within
`0100h-1FFFh`.  The final ordinary program sizes measured during validation
were hello 5,072, fstest 8,487, ipc 6,970 and ipccopy 4,520 bytes; program
size no longer determines whether the gate can see the SDK blocks.

The requested helloworld client cost is unchanged:

| component | before | after |
|---|---:|---:|
| console stub | 429 | 429 |
| IPC client | 451 | 451 |
| syscall gate | 23 | 23 |
| **total** | **903** | **903** |

Before the correction, the 77 IPC data bytes followed the program BSS.  After
it, the same 77 bytes are split into the fixed gate blocks (52) and cache/state
(25).  The separate 16-byte runtime scratch makes the whole fixed low area 68
bytes but is not part of the console+IPC+gate cost above.

### Acceptance-image placement

The IPC image uses image-local module/report paths and production placement.
Its final fixed core has 746 bytes of room; cold code ends at `C490h`, the
arena is `C600h-DA00h` with 10 free granules, and cold data has 696 bytes of
room.  Its loader census correctly includes SIO and console plus the six
synthetic services.

The M9 image omits verbose service evidence and moves the fault workload into
the existing public-SDK `fsfat.zex` client.  Its fixed core has 170 bytes of
room; cold code ends at `BF6Eh`, its 13-granule arena exactly fills
`C000h-DA00h`, and cold data has 473 bytes of room.  All nine fault fences and
the nested fstest/fsdeep execution remain observable.

IOC and HID manifests now include `console.zmod`; the IOC test object tracks
`service_client.h`.  The ROMFS store rule already had `ROMFS_MANIFEST` as a
prerequisite.  Their replays now check the public transcript and exchanged
data rather than private result bytes.

## Protocol and service evidence

`docs/devices.md` records the operation numbers, descriptor direction and
frame/result rules for buffered console, HID, V9958, SIO and IOC transport and
block access.  Hot calls are batched (`WRITE`, `READ_TEXT`, IOC bulk, and V9958
streaming operations).  Bootstrap claims the service IRQs and the normal IRQ
executive owns final `RETI`; simulator evidence covers IOC and HID operation,
V9958 reset, mode-10 delivery and restoration, and console fallback.

The production service plan reports:

| service | hot bytes (image+BSS) | boot | bulk |
|---|---:|---:|---:|
| SIO | 889 | 47 | 0 |
| IOC | 5,034 | 60 | 0 |
| HID | 1,733 | 0 | 0 |
| V9958 | 5,088 | 15 | 2,048 |
| console | 472 | 0 | 0 |
| **total** | **13,216 / 32,768** | **122** | **2,048** |

Package 36 projected the four migrated drivers at 8,013 hot and 1,467 boot
bytes (its 14,166/1,957 totals also included the 6,153/490-byte IOC-FAT driver,
which intentionally remains in the arena).  The four actual services consume
12,744 hot bytes: +4,731 for endpoint dispatch, descriptors, relocation/runtime
support, service I/O state, and the V9958 reset/upload path that had to become
hot.  Console adds 472.  Conversely, their boot code fell to 122 bytes because
runtime-reachable initialization moved hot.  The font remains exactly the
projected 2,048 bytes.  Thus the plan's combined boot/bulk ledger is 2,170 of
24,576 bytes.

## Nucleus and service ledgers

Before is the accepted package-40 production baseline; after is the final
package-41 production plan.

| ledger | before | after |
|---|---|---|
| nucleus fixed | required 3,746; overflow 10,891; stacks 768; room 979 | required 7,083; overflow 7,752; stacks 768; room 781 |
| nucleus cold | code 14,822, end `99E6h`; arena 33 granules; data 892 at `DC00h`; room 158 | code 24,153, end `BE59h`; arena 13 granules; data 1,208 at `DA00h`; room 751 |
| service hot | 0 / 32,768 | 13,216 / 32,768 |
| service boot/bulk | 0 / 24,576 | 2,170 / 24,576 |
| common | used 2,106 (code 1,412, data 694); ceiling 3,072, reservation 512, limit 2,560 | used 2,230 (code 1,511, data 719); ceiling 3,072, reservation 512, limit 2,560 |

The arena reduction from 33 to 13 granules leaves only IOC-FAT.  No ceiling or
capacity was raised.

The shared ZREL validation/arithmetic lives in `kernel/module/relocate.c`;
the service loader retains only gate-based patch I/O.  Production loader cost
is `_WINDOW` 5,679 + `_WINDOW_DATA` 232 = **5,911 bytes**.  The acceptance
build is 6,234 + 232 bytes, so evidence/plan/ledger output costs about 555
test-only code bytes.  Production contains none of those evidence strings.

## Stall root cause

The apparent loader stall was a simulator-hook error.  Replay harnesses used
the address of `_kernel_serial_connect_delay` alone to skip the one-second
spin.  Under M10 the same logical address can name bank-6 service code; the
hook popped a service stack frame and corrupted the loader.  The shared skip
helper now also requires latch `18h` (mode 11, page 0, bank 7).  Frozen-image
replays were deterministic before and after this change, establishing that
the loader itself was not stalled.

## Retired tests and fixtures

The following were deleted rather than ported because their subjects no
longer exist:

- `TestTargetTestWiring`: asserted the retired IOC target wiring.
- old V9958 failure-macro and `video: video0 OK` cases: asserted the pre-service
  video harness and transcript.
- old HID smoke/no-IOC/bad-IOC cases: asserted removed optional-driver modes.
- driver-ABI bad-IOC and arena-exhaustion manifests: exercised the retired
  production driver set.
- `manifest-fontfail.json` ownership/layout checks: the old font-failure image
  was removed with the boot-only font path.
- dead serial-smoke bad-IOC/arena modes and M8 tokens: those images and tokens
  are no longer produced; the two live fallback modes remain.
- the IPC whole-program-below-`2000h` assertion: the gate contract is for the
  individual SDK blocks, now checked directly, not the whole executable.

## Validation

The completed validation evidence is collated rather than rerunning the full
matrix a second time, per supervisor direction.  `make clean && make check`
completed once after the implementation changes: **790 tests OK, 176 skipped**,
including reproducibility, map/image checks and production hash verification.
The only later changes affecting that evidence were six IPC trace expectations;
all six were rerun on the final file and passed in 241.002 s.  No production
source changed after the clean pass.

| command/evidence | result |
|---|---|
| `make clean && make check` | PASS: 790 OK, 176 conditional-image skips; reproducible production hash |
| `make console-integration-selftest console-fallback-selftests video-selftest` | PASS: console 6/6; fallback 3/3 plus 1 abstract-harness skip; video 4/4 |
| `make ioc-selftest hid-selftest` | PASS: 2/2 each, each replayed twice during focused diagnosis |
| `make ipc-selftest` | Target transcripts PASS (IPC 55/55; ipccopy 23/23); 47/53 host assertions passed in the full run, then the six corrected trace assertions passed on the final file, giving 53/53 composite evidence |
| `make m9-selftest` | PASS: 7/7; fstest fault workload 9/9 |
| `git diff --check` | PASS |

The aborted attempt to repeat `make clean && make check` after all of the above
is not counted as validation; it was stopped on supervisor instruction because
it duplicated already completed coverage.

Fresh high-water evidence from the final acceptance images is **gate stack 213
of 256 bytes** (M9) and **service stack 256 of 512 bytes** (IPC).  The IPC run
also observed 639 calls returning the caller latch, 13 injected CTC deliveries,
2,759 window LDIRs, and all six boot segments discarded while hot segments
remained live.

Production artifact: `build/zephyros.bin`
`sha256 21ca993c5336dcc55acf2d019008033fe6183291d0c18a26f252399b8456e563`.

## Diff by area

The final package diff from package 40 is recorded after the documentation-only
closeout edit:

| area | files | added | removed |
|---|---:|---:|---:|
| OS/build/SDK | 63 | 2,916 | 1,644 |
| tests | 90 | 3,396 | 6,808 |
| docs/work | 4 | 457 | 64 |
| tools | 4 | 157 | 156 |
| **total** | **161** | **6,926** | **8,672** |

## Hardware

**PENDING (owner).** Flash `build/zephyros.bin` with the hash above, connect the
serial console at **115200 8N1**, and run:

```sh
make smoke-hardware SERIAL_PORT=/dev/ttyUSB0
```

With that same image, confirm console input from a USB keyboard and output on
the V9958, force and confirm the serial fallback, then press **ESC `c`** and
confirm the V9958 display resets and remains usable.  Physical IRQ timing,
daisy chaining and wiring remain hardware-authoritative.

## Supervisor review (2026-10-08)

**Accepted**, with hardware pending (owner).
- Validation ran once on the implementation, then six test-only trace
  assertions were re-run; no production source changed after the clean
  pass.
- The SDK low-window fix is general; retired tests were deleted with
  reasons; no capacity was raised.

**Finding: service wrappers cost 600-900 bytes each.** From
`build/modules/*.rel`:

| service | wrapper | driver |
|---|---:|---:|
| SIO | 597 | 207 |
| IOC | 894 | 3,467 |
| HID | about 700 | — |
| V9958 | 695 | 3,850 |

At these rates, package 42 (IOC-FAT plus the VFS) projects the hot tier to
about 33.4 KB of 32 KB. Package 41b reduces the wrapper cost and pins the
42 budget before the VFS moves.
