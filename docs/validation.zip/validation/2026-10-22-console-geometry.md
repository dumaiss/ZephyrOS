# Console geometry

## Result

The console's text grid is a reported value (architecture 5.6, "Console
geometry is reported, not fixed"): `KCONSOLE_OP_INFO` returns
`struct kconsole_info` (columns, rows, attribute bits, RENDER flag), the
render stream is bounded by the reporting driver's grid, and `libtui`
adopts the grid at `tui_init`, refusing one above its compiled capacity.
The public `tui_*` API is unchanged. One Must is not met:
KonaCommander, in the owner's tree, no longer links (below).

## Files

- `abi/kos/protocol.h` - `KCONSOLE_OP_INFO` (7), `KVIDEO_OP_INFO` (5); the
  VIDEO comment no longer describes an atlas upload.
- `abi/kos/console_render.h` - `struct kconsole_info` (8 bytes, asserted),
  `KCONSOLE_ATTR_REVERSE`, `KCONSOLE_INFO_RENDER`, `KCONSOLE_INFO_SIZE`;
  `KCONSOLE_RENDER_COLS`/`ROWS` removed. The record lives here because the
  SDK ships this header and not `protocol.h`.
- `drivers/v9958/v9958_proto.c` - the INFO answer (85, 26, reverse,
  RENDER); render validation bounded by `V9958_COLUMNS`/`V9958_ROWS`, the
  attribute by the reported bit.
- `drivers/console/console_proto.c` - `console_info`: the serial build
  answers 85 x 26, reverse, no RENDER; the V9958 build passes the caller's
  frame to VIDEO (the reply lands in place, the op is put back) and
  clears RENDER while the tee is armed.
- `user/sdk/src/console_info.c` (its own libkos member),
  `user/sdk/include/kos/console.h`, `user/sdk/exe.mk`.
- `user/sdk/tui/src/tui_internal.h` (`TUI_MAX_COLS`/`ROWS`, the capacity),
  `tui_lifecycle.c` (asks, refuses 0 or above capacity with
  `-KOS_ENOTSUP`), `tui_flush.c` (cursor clamp by the screen).
- `tests/tui/tui_test.c` - the `grid` mode; `bad_y` in `renderbad`.
- `tests/test_tui_sim.py` - `_grid_hook` (overrides the console's INFO
  reply at its return: a test console reporting another grid) and three
  tests on both lanes; `tests/test_console_tee.py` - INFO while armed;
  `tests/test_tui.py` - the ABI pins.
- Docs: `docs/abi.md`, `docs/sdk.md`, `docs/tui.md`, `docs/devices.md`;
  `docs/architecture.md` roadmap item removed.

## Requirement results

1. **ABI.** As above; `test_tui.TestTuiHeader.test_render_abi_is_pinned`
   pins the numbers, the record and the absence of the grid constants.
2. **Answers.** `tui: grid console 85x26 attr 1 flags 1` on the V9958
   console, `flags 0` on the serial console and while the tee is armed
   (`test_info_withdraws_render_while_armed`).
3. **Validation.** `renderbad` refuses a column (85) and a row (26)
   outside the grid before any drawing.
4. **SDK.** `console_info` is its own member.
5. **libtui.** With a reported 80 x 24 grid `tui_get_size` reports 80x24
   and a full-screen fill stays inside it (columns 80-84 and rows 24-25
   untouched); 90 x 30 fails `tui_init` with -7 (`-KOS_ENOTSUP`).
6. **INVERT.** Documented as the normal/reverse exchange; libtui emits it
   only for that exchange (unchanged).
7. **Docs.** As listed.

## Budgets

| figure | before | after |
|---|---|---|
| driver hot | 30,471 used | 30,550 (+79; budget 64) |
| v9958 hot image | 5,987 | 6,023 (+36) |
| console-v9958-hid hot image | 773 | 816 (+43) |
| `tui_dialog.exe` | 20,955 | 21,300 |
| `tui_test.exe` | 35,879 | 37,647 (with the `grid` mode) |
| `konacmd.exe` | 37,637 | does not link |

The driver-tier figure is 15 bytes over the package's budget. The first
cut cost 184 bytes (two 32-byte frame copies and a stack frame in the
console dispatch); the in-place reply, pointer-walk fills and a separate
function bring it to 79. 2,218 bytes stay free against the 1,536 reserve,
so it is reported, not chased further.

## Found - KonaCommander (Must not met)

`make -C UserSoftware/KonaCommander test` fails at the pack step:
`EXE_EXEC_ERR_COLLISION`. Built against the previous SDK, KonaCommander's
BSS ends at DC76h and its 896-byte stack starts at DC80h: 10 bytes of
headroom. Package 80 adds 198 bytes of code to it (`console_info` 102,
`tui_init` +60, the rest), so it now overlaps its stack by 188 bytes. The
SDK side cannot give that back; the program needs about 190 bytes of room
in its own tree (a smaller `STACK`, or less code or data). Not changed:
the owner's tree.

## Pins changed, with their sources

- `test_tui.TestTuiHeader.test_render_abi_is_pinned`: the grid constants
  pinned there are removed (`WORK.md` requirement 1); it pins the INFO ABI.

## Validation

```sh
make && make sdk
make console-serial-selftest
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_console_tee tests.test_console_serial tests.test_sdk tests.test_sdk_package tests.test_source_layout tests.test_v9958
make -C UserSoftware/KonaCommander test
make clean && make check
git diff --check
```

- The batch: 215 run, 1 failure in this package's own new test (the shell
  prompt can land on row 2 before the screen is decoded; rows are checked
  from 3), rerun on both lanes: OK.
- `make -C UserSoftware/KonaCommander test`: fails (above).
- `make clean && make check`: **881 tests, `make check: OK`** (2,339 s);
  reproducible rebuild
  `0cea638a5526ef9e10b00d8f847fc2f9fc8a7c2266ba6435178c0b8f25ac76a2`.
- `make console-serial-selftest`: OK.
- `git diff --check`: clean.

## KonaCommander resolved

Package 81 (`docs/validation/2026-10-22-tui-storage.md`) gives every TUI
program 1,105 bytes back and clamps a larger grid; KonaCommander links
with 868 bytes of headroom and its suites pass.
