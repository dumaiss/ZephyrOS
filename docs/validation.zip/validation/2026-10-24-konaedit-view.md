# KonaEdit view

## Result

KonaEdit's display is decoupled from its store. A RAM view of the
visible lines (`src/ke_view.c`) holds each row's line start and the top
row's line number. Rows are built from page spans and written with one
`tui_put_text` per attribute run. The store is read only for rows that
change or scroll in. Every key budget is met in the simulator, on a
3 KiB source with the cursor near line 60.

## Budgets (whole-system T-states, one key)

| key | before | budget | after |
|---|---|---|---|
| printable key, line 60 | 2.93M | <= 800,000 | 704,327 |
| Backspace / Delete in a line | (n/a) | <= 800,000 | 519,015 / 504,596 |
| cursor right / down (no scroll) | 1.79M | <= 500,000 | 281,035 / 294,692 |
| one-line scroll down / up | 6.67M | <= 1,200,000 | 790,484 / 745,270 |
| Enter mid-line / join | 37.3M / 4.4M | <= 1,500,000 | 1,165,132 / 1,494,277 |
| stack headroom (`test_project`) | 2,760 B | >= 512 B | 605 B |

All are asserted in
`tests/test_ui_sim.py::KonaEditViewBudgets.test_keys_meet_their_budgets_anywhere_in_the_file`.
The join has the least margin. Two full rows (one newly exposed, one
merged) cost the simulated driver about 5k T-states per changed cell.

## Files

- **`src/ke_store.c`, `.h`:**
  - `ke_store_span` (the cached page holding a position, with its offset
    and length);
  - `ke_store_count` walks spans;
  - `low_edit` and `note_change` are removed.
- **`src/ke_text.c`, `.h`:**
  - `ke_line_start` and `ke_line_end` walk spans;
  - `ke_walk_line` is the shared line walk behind `ke_visual_column` and
    `ke_position_for_column`.
- **`src/ke_view.c`, `.h` (new):**
  - **The ring:** `row_start[]`, with `KE_POS_NONE` marking rows past the
    end, and `top_line`.
  - **Row drawing:** an 8-bit column walk (a horizontal scroll first
    walks to the left column with `ke_walk_line`) and a single selected
    span per row.
  - **Scrolls:** one-line view scrolls.
  - **Edits:** inline edits shift the starts. A newline or a join moves
    the rows on whichever side of the cursor leaves fewer screen rows for
    the console to restore. Near the bottom the top part moves and the
    top line steps by one.
- **`src/ke_ui.c`:**
  - **Per key:** each key records what it did to the view (inline,
    newline, join or rebuild), then `follow_cursor` (a scroll for one line
    past an edge, otherwise a rebuild with a recount), the horizontal
    follow, the selection rows, the status and the cursor.
  - **Line numbers:** the line is `top_line + row`. Page Up/Down move the
    view by the lines moved; only jumps and actions recount.
  - **Status:** written with one `tui_put_text`, and only when the line,
    column or flags changed (an action redraws all). Numbers are formatted
    by subtracting powers of ten.
  - **Dispatch:** the named keys are one `switch` on the low byte.
  - **`tui_window`:** `tui_clear` and `tui_reset_window` are dropped.
    `tui_init` clears the screen, `render_all` writes every cell, and
    KonaEdit never narrows the window, so the member is no longer linked.
- **`src/ke_history.c`:** arena offsets split by shift and mask (the
  object sizes are powers of two) instead of 32-bit `/` and `%`. This
  saves about 110k T-states per edit and the divide helpers.
- **`src/ke_widgets.c`:** `ke_statusbar` is removed (unused).
- **`tests/test_ui_sim.py`:**
  - `press_and_measure` reports `tstates`;
  - new `KonaEditViewBudgets`: the 3 KiB fixture covering scroll down and
    up, Down, Right, typing, Backspace, Delete, Enter and join at the
    bottom and in the middle, Page Up/Down, a three-row selection and
    Esc, Edit > Undo, and Search > Go To Line 40;
  - a long-line horizontal scroll test (End, Home, and a left column
    inside a leading TAB).
- **libtui `tui_scroll.asm`:** a one-row region skips the block moves
  (below).

## Found and fixed

- **`tui_scroll_rows` on a one-row region** ran `LDIR`/`LDDR` with
  `BC = 0`, from package 87. On the board that copies 64 KiB over memory.
  - **Why tests missed it:** the simulator's `LDIR`/`LDDR` copy nothing
    for `BC = 0` but charge the 65,536-iteration cost. That cost is what
    exposed it here: a join near the bottom spent 2.77M T-states in
    `tui_scroll_rows`.
  - **Fix:** the block moves are skipped when `(height - 1) x stride` is
    zero.
  - **Test:** `test_tui_sim` timing mode now times a one-row scroll and
    asserts at most 40,000 T-states. The unfixed code measures 2,780,003.

## Simulator model note (not changed here)

The Python core's `LDIR`/`LDDR` (and the C core, which copies it) treat
`BC = 0` as zero iterations; silicon runs 65,536. `opcode_cost` already
charges 65,536. Making the copy match silicon is a separate decision for
the model.

## Pins changed, with their sources

- **The newline and its undo** (`test_edit_menu_invert_save...`) send one
  SCROLL record and one render (`[10, n]`), where they were pinned to one
  render. The rows below now move by hardware scroll (WORK.md
  requirement 4). Their instruction counts fell (47,714 / 52,982 against
  the 150,000 limit).

## Validation

```
make -C UserSoftware/KonaEdit test        # 10 tests OK
make clean && make check                  # 890 tests OK, 119 skipped (C core)
make -C UserSoftware/KonaCommander test   # OK
git diff --check                          # clean
```

The reproducible-rebuild hash is unchanged:
`2e7e3e00ad9840fd0473bb5c5ce04a2c781ccc437e124f1f357d5a14968428bb`.

## Owner checklist

On a 3 KiB source on the board:
- typing in mid-file;
- a held arrow key scrolling;
- Enter and Backspace at a line start, near the bottom and in the middle;
- a selection;
- undo.

The simulator runs the VDP's HMMM copies instantly, so check scroll,
Enter and join speed on the board.
