# M9 nested exec (`SYS_EXEC`) — validation (package 28)

**Package:** `28-m9-nested-exec` (2026-10-05)
**Scope:** make the existing process machinery nest: `SYS_EXEC 05h` as a
thin composition of the process slot / bank / ZEX loader / page-zero /
VFS-hook / exit path, plus the one genuinely new piece - a bounded
continuation stack for the shared common gate stack (architecture
sections 26.1-26.9, 32.21-32.22, 32.39, 33 and the new 32.40;
`work/M9-REFERENCE.md`).
**Status:** host-validated, simulator-accepted and physically accepted
2026-10-05 (both images run on the bench; see "Hardware acceptance"),
then corrected by `correction-01` (place/accounting only; see below and
`docs/validation/2026-10-05-m9-nested-exec-correction-01.md`).

## What was implemented

- `include/zephyros/process.h`: `ZOS_EXEC_MAX_DEPTH` (4),
  `ZOS_EXEC_FRAME_SAVE` (48, measured) and `ZOS_EXEC_FRAME_SLACK` (16),
  `struct process_child`, the depth-indexed continuation state and the
  `process_prepare()`/`process_launch()` split.
- `kernel/process/launch.asm`: the single-depth M6 launcher generalized to
  depth-indexed continuation records (SP/IX/latch/IFF per depth), three
  frame-save areas in common memory, per-depth shadow copies of the
  syscall gate's transition state, and a stackless resume window.
- `kernel/process/{process,exec}.c`: `process_prepare()` (every fallible
  step, source closed before it returns) followed by an infallible
  `process_launch()`; `process_exec()` kept as the kernel-launcher wrapper
  with its M6 `ZEX_EXEC_ERR_*` space; `process_exit()` resumes the parent
  found through the existing `parent` field.
- `kernel/syscall.c` + `include/zephyros/syscall.h`: the `SYS_EXEC 05h`
  handler (path copy-in through the package-27 gate, depth and frame
  preflight before any allocation, native error mapping) and the pinned
  ABI header.
- `user/runtime/{zos_fs.c,zex_exec_runtime.h}`: the `zos_exec()` wrapper on
  the shared FS argument block and gate stub.
- Tests: `tests/target/m9/exec/` (`fschild`, `fsdeep`, `fsraw`),
  `m9_exec_test.c`, `tests/m9/manifest-exec.json`, the extended
  `fstest.zex` `exec` case, `tests/test_m9_exec.py`,
  `tests/test_m9_exec_sim.py`.  `fschild` also asserts through
  `zex_getinfo` that a `SYS_EXEC` child sees its true (user) parent - the
  kernel-parent flag clear - its own slot and its own application bank.
- Tooling (rides along as specified): the banner-only production serial
  contract plus `--quiet` and the `m9-exec` mode (`tools/serial_smoke.py`,
  `tests/test_monitor.py`), the `zex-fixtures` prerequisite, and parallel
  builds by default.

## Two runtime bugs found and fixed by this package's acceptance

Both were found by the simulator instrumentation, not by reading code:

1. **The child overwrote the suspended parent's gate transition state.**
   `zos_gate_saved_sp/latch/iff` are single-depth common bytes: the child's
   own syscalls replace them, so the resumed parent returned through the
   gate into *the child's* bank with the child's stack pointer and halted
   in the wrong image.  Fixed with per-depth `zos_proc_gate_*` shadow
   copies written by the launch gate and restored by the resume gate
   (measured: the parent now returns over its own bank at every depth).
2. **The frame-area offset still used the M6 factor.** The gate scales the
   frame-area number with a shift chain (no multiply instruction); it was
   hardcoded to `80 x` while `ZOS_EXEC_FRAME_SAVE` became 48, so depths 2
   and 3 wrote 32 bytes past their area.  `tools/mapcheck.py` pins the
   *size* of the area and `tests/test_m9_exec.py` now pins the chain's
   factor against the header, so the two halves cannot drift apart again.

## Host and simulator validation (one clean batch, 332 s wall clock)

```text
make clean && make check                                    OK (reproducible rebuild,
                                                             ac0170e1...98a,
                                                             production mapcheck OK)
make m9-fs-selftest m9-exec-selftest subsystem-selftest      OK
  m9 fs image:          5 simulator tests OK (fstest PASS 10/10,
                        fstest launcher OK, m9 fs selftest: OK)
  m9 exec image:        9 simulator tests OK (m9 exec selftest: OK)
  subsystem image:      5 simulator tests OK
python3 -m unittest tests.test_m9_exec tests.test_m9_exec_sim \
        tests.test_syscall_sim tests.test_subsys_sim tests.test_monitor -v
                                                             78 tests OK
make check's own host stack                                 609 tests OK
                                                             (157 skipped)
git diff --check                                             clean
```

`tests/test_m9_exec_sim.py` replays the linked `m9-exec-selftest` image
and instruments every suspension:

```text
m9 exec: copied gate frame 32 bytes of 48 saved, 37 suspensions,
         37 resumes (+2 kernel), deepest depth 3
m9 exec: worst-case gate-stack depth 207 of 256 bytes
```

It asserts, at every depth: the copied frame is identical in size and
fits `ZOS_EXEC_FRAME_SAVE`; the frame save area still holds the launch's
copy after the child ran (the child reused the same common gate stack);
the resumed frame is byte-identical above the restored SP; the latch is
the launcher's again and the parent returns to application mode over
*its own* bank; 37 suspensions/re-resumes leave the process table, the
descriptor pool and every frame area at baseline; and the depth probe
stops at exactly 4 live processes (`fsdeep` status 4, the fifth exec
refused with `ZOS_EBUSY`).

The "nothing borrowed survives the child" invariant is checked directly:
at every suspension (before the child's first instruction) the replay
overwrites all 512 bytes of the shared VFS workspace with a moving
pattern, physically, and the whole acceptance still passes - so no part of
the suspended parent's continuation lives in that workspace.  The same
claim is stated in a comment at the suspension point in
`kernel/process/process.c` (`process_launch()`).

`tests/test_m9_exec.py` (29 tests) pins the ABI number and argument block,
the user-runtime surface, the depth example, the frame geometry, the
launch primitive's structure (depth 0 skips the frame copy, the resume
window takes no stack action, `process_launch()` carries no failing
check), the mapcheck/test-harness parity, the production map (no
acceptance symbols, continuation state present) and the build wiring.

## Measured frame size and the preflight

```text
launch gate's captured continuation SP   = zos_gate_stack_top - 32  (every depth)
SYS_EXEC handler frame (the preflight)    = 21 bytes
ZOS_EXEC_FRAME_SAVE                       = 32 + 25 % = 40 -> 48 (16-byte unit)
ZOS_EXEC_FRAME_SLACK                      = 16 (covers the measured 11-byte gap)
```

**Documented deviation.** The package asked for an assert that *the value
measured at launch equals the preflight value*.  That equality is not
expressible in the shipped C: the preflight runs in the `SYS_EXEC` handler
frame, while the launch gate captures the deeper `process_launch()` frame,
and the compiler's own register pushes around the second call change the
frame by a value it does not expose.  The substantive invariant is
therefore enforced where it is observable instead:

- the preflight (allocation-free, before anything is reserved) rejects a
  handler frame above `ZOS_EXEC_FRAME_SAVE - ZOS_EXEC_FRAME_SLACK`, which
  keeps an oversize frame from ever reaching the copy;
- the simulator asserts the *actually copied* length against
  `ZOS_EXEC_FRAME_SAVE` at every suspension (32 of 48 bytes measured), so
  the frame can neither overflow its area nor differ between depths.

## Bank-7 ledger (section 32.39)

```text
before (package 27 + correction-01):
    production:        code 27759 end 8C6Fh | arena 36 granules (20 boot, 16 free)
                       | data 2113 at D600h | isr 256 | slack 191
after (package 28):
    production:        code 28159 end 8DFFh | arena 36 granules (20 boot, 16 free)
                       | data 2113 at D600h | isr 256 | slack 191
    package delta:     +400 _CODE, +0 bank-7 data, arena unchanged
    m9-fs-selftest:    code 28653 end 8FEDh | arena 35 granules (1 boot, 34 free)
                       | data 2115 at D600h | isr 256 | slack 189
    m9-exec-selftest:  code 28655 end 8FEFh | arena 35 granules (1 boot, 34 free)
                       | data 2115 at D600h | isr 256 | slack 189
```

The package spends about 400 bytes of bank-7 code and, after
correction-01, 128 bytes of bank-7 data (the `SYS_EXEC` path buffer); the
continuation records, the three frame-save areas (144 bytes) and the
gate-state shadows (16 bytes) stay in permanent common memory
(`kernel/process/launch.asm`, `_COMMON`/`_COMMON_DATA`) because the
resume gate reads them *while* it changes the mapping and switches
stacks.  Common memory is not isolated - mode 10 maps it exactly as mode
11 does - so that is a reachability argument, not a protection one, and
correction-01 additionally reports common usage on its own ledger line.
The production arena stays at 36 granules, above the 32-granule floor,
and the acceptance images keep their 35-granule arena.

Per-object sizes of the touched objects in the production build:

```text
kernel/process/launch.asm   process_launch.rel   _COMMON 467   _COMMON_DATA 329
kernel/process/process.c    process.rel          _CODE   780   _DATA 59
kernel/process/exec.c       process_exec.rel     _CODE  1537
kernel/syscall.c            syscall.rel          _CODE  1307
```

### Correction-01 (2026-10-05)

The supervisor logged three placement/accounting defects against this
package, all fixed in `correction-01` (separate record:
`docs/validation/2026-10-05-m9-nested-exec-correction-01.md`), with the
exec behavior unchanged:

```text
1. `_zos_process_path_scratch` moved out of common memory into bank-7
   `_DATA` (kernel/process/process.c): it is only touched in mode 11.
   bank7 ledger: data 2113 -> 2241 at D600h, slack 191 -> 63, arena
   36 -> 36 granules (no granule cost);
   common ledger: used 2232 -> 2104 of 7424 (code 1410, data 694).
2. The claims that common memory is out of reach from mode 10 were
   false (mode 10 maps it exactly as mode 11 does) and are replaced by
   the real reason the remaining items live there: the resume gate reads
   them while it changes the mapping and switches stacks.
3. Common memory is now on the ledger: a second
   `common: used <n> of <n> bytes (code <n>, data <n>)` line printed by
   both tools beside the `bank7:` line, emitted into arena.plan.json and
   checked against the linked map by a host test.
```

The gate-stack canary was evaluated and deliberately not added: the
existing simulator measurement samples `SP` at the start of every
instruction, so it already records the exact high-water mark (see the
correction record).

The corrected production image was re-flashed and re-verified on the bench
(banner-only serial contract plus the V9958 monitor check, with the
unchanged `scratch=0F19` figure confirming the same monitor image is
loaded and entered).

## Tooling riders

- **Production smoke contract.** `tools/serial_smoke.py --mode normal`
  now accepts what serial can observe on real hardware: the four banner
  lines in order, then a quiet window (default 5 s, `--quiet`) with no
  `PANIC`, no `console: unbound`, no `console: dynamic driver failed` and
  no `<module>: unavailable` line.  On a banner-only PASS it prints the
  explicit operator step (confirm the monitor banner, status line and
  `Z80>` prompt on the V9958).  An SIO-fallback bench still gets the
  stronger console/monitor check.  `tests/test_monitor.py` was updated to
  the new contract (`test_banner_alone_passes_with_an_operator_step`, the
  inverted old expectation) and gained negative tests for `PANIC` after
  the banner, an `unavailable` module line, a failed console bind, a
  missing banner line and an out-of-order banner.  This closes the
  package-27 "recommended follow-up".
- **`zex-test` prerequisite.** `$(MODULES)/zex-fixtures.stamp` now
  declares `tests/subsys/gen_zmod_fixtures.py` and its real input
  `build/modules/m4_probe.zmod`, so `make clean && make zex-test` works on
  its own (2 s, `zex-test: OK`).  This closes the package-27
  "build-order prerequisite" note.
- **Parallel builds by default.** `ZOS_JOBS ?= $(shell nproc)`;
  `MAKEFLAGS += -j$(ZOS_JOBS)`; `make ZOS_JOBS=1` forces the serial build.
  Hash proof (race-free):

```text
production,   parallel (make check, twice):  ac0170e116009c1871ca54d7b425a41e99585d1ce5e50091b0f17a851b1d998a
production,   serial  (ZOS_JOBS=1, 95 s):    ac0170e116009c1871ca54d7b425a41e99585d1ce5e50091b0f17a851b1d998a
m9-exec,      parallel (28 s):               506195e04ca6b9cd2c6bf7a15adf7328ec2a0b4ec8a0ef8fa9f00edf65919ae4
m9-exec,      serial  (ZOS_JOBS=1, 116 s):   506195e04ca6b9cd2c6bf7a15adf7328ec2a0b4ec8a0ef8fa9f00edf65919ae4
```

## Documentation

`docs/abi.md` gains section 11 (`SYS_EXEC`, the pinned error-mapping
table, the continuation/shadow design and the reference to the tests);
`docs/memory.md` records the common-resident continuation state, the
per-depth gate shadows and the measured frame size; `docs/zex-format.md`
splits the load sequence into `process_prepare()` + `process_launch()` and
documents the child's CWD/descriptor inheritance; `docs/architecture.md`
extends 26.9 (the suspended parent is now an ordinary process) and adds
32.40 plus the nesting lines in the section 33 acceptance list.

## Re-run after the child's SYS_GETINFO assertion

`fschild` gained the parent-report check after the formal batch, so the
two acceptance images and the unittest list were re-run (production bytes
unchanged, because the change is test-only):

```text
make m9-fs-selftest      5 simulator tests OK in 47 s (fstest PASS 10/10)
make m9-exec-selftest    9 simulator tests OK in 82 s
python3 -m unittest ...  79 tests OK (0 skips; subsystem image rebuilt)
production hash          ac0170e1...98a, identical to the formal run
m9-exec image hash       506195e0...9ae4 (the child's ROMFS bytes changed)
```

A final batch after the workspace-poisoning test and the suspension-point
comment reproduced the same two hashes (`make check`: reproducible rebuild
`ac0170e1...98a`), so the production image was byte-stable across every
re-run of this package.

## Hardware acceptance: PASSED (2026-10-05)

All acceptance items of architecture section 33 are now covered on the
board as well as in the simulator.

Both images ran on the bench (FTDI FT230X, 115200 8N1).  Raw transcripts:
`docs/validation/2026-10-05-m9-nested-exec-hw.txt`.

**Production image** (`build/zephyros.bin`, `ac0170e1...98a`) —
`make smoke-hardware SERIAL_PORT=/dev/ttyUSB0`:

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
serial_smoke: banner-only PASS - the production console is bound to the
  V9958, so serial carries only the banner
serial_smoke: operator step: confirm on the V9958 the monitor banner, the
  status line and the 'Z80>' prompt, then type a key
serial_smoke: OK ...
```

65 bytes captured = the four banner lines exactly, then a quiet window with
no `PANIC`, no console-bind failure and no `<module>: unavailable` line.
The operator display step is satisfied on the V9958:

```text
console: dynamic sio0.b OK
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

`scratch=0F19` is identical to the package-27 production record, so the
package-28 common-memory additions did not disturb the process / CWD /
descriptor state.

**This is the first hardware run of the reworked production serial
contract** (a package-28 tooling rider): the previous contract demanded the
console and monitor lines on serial and could never pass on a V9958-bound
production boot.

**`SYS_EXEC` acceptance image**
(`build-m9-exec-selftest/zephyros-m9-exec-selftest.bin`, `506195e0...9ae4`):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
console: dynamic sio0.b OK
fstest: namespace OK
fstest: romfs OK
fstest: ramfs OK
fstest: errors OK
fstest: pool OK
fstest: stale OK
fstest: writefail OK
fstest: exdev OK
fstest: window OK
fschild: cwd /D1
fstest: exec OK
fstest: PASS 10/10
m9 exec selftest: OK

ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> r
system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02
process: pid 0 bank 0 flags 0001
bank: current 00 mask 7F
Z80> h
R              system/bank information
D addr len     dump monitor bank (16-byte rows)
DB bank addr len  dump bank 0-6
M addr value   set byte in monitor bank
MB bank addr value set byte in bank 0-6
I port         input port (10-FF)
O port value   output port (10-FF)
Q              quit
H or ?         help
Z80>
```

What the physical run proves:

- all ten `fstest` cases pass on hardware, including the new `exec` case:
  the child inherits `/D1`, its `chdir` to `/R2` does not move the parent,
  it exits `0x5A5A` with a descriptor still open, the raw-return child
  yields `ZOS_EFAULT`, every failure mode returns with the parent
  undisturbed, and 32 exec/exit cycles leak nothing;
- the depth probe stops at exactly `ZOS_EXEC_MAX_DEPTH` and the target
  hook's own leak check on the process table, bank map and descriptor pool
  passes (`m9 exec selftest: OK`);
- the launcher's ordinary depth-1 path still works *after* the nested
  chain: the monitor came up, answers `r` and `h`, and `SYS_GETINFO`
  reports `pid 0 bank 0 flags 0001` - the monitor at slot 0 over its own
  bank, with the kernel-parent flag set because it was started by the
  launcher rather than by `SYS_EXEC`.

The acceptance image is SIO-bound, so this transcript is exactly what
`make smoke-hardware-m9-exec SERIAL_PORT=/dev/ttyUSB0` gates on.  The
capture was taken with `picocom` rather than through the smoke tool because
the operator session owned the port; the expected marker is in it.

## Wall clock

```text
formal validation batch (clean + check + 3 images + unittest list)   332 s
target                                                             < 600 s
```

Hardware runs were operator-driven (flash + `make smoke-hardware` +
`picocom`) and are not part of that figure; the production smoke run itself
returned in its 5 s quiet window after the 15 s capture timeout.
