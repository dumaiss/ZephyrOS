# TUI styles and drawing primitives: validation

## Result

Semantic styles resolve to the private normal/reverse attribute.  The mapping
is `0` (normal) for NORMAL, DISABLED, ERROR, INPUT and ACCENT, and `1`
(reverse) for TITLE, SELECTED and STATUS.  Style changes affect only later
drawing; they do not dirty existing cells.  Flush already emits SGR only when
a run's attribute differs from the backend's last known attribute.

`tui_fill`, `tui_hline`, `tui_vline`, `tui_frame` and `tui_frame_title` all use
the common clipping layer.  The twelve CP850 box bytes live only in
`tui_style.c`; application and test drawing code uses symbolic frame and style
values.  `TUI_FRAME_NONE` emits no border.  One-cell, two-cell and flat
frames choose one corner per cell without duplicate writes.  A title starts
one cell inside the left corner where room permits, never overwrites a border
corner and is clipped at the interior right edge.

The `styles` mode draws single, double and title-only frames, degenerate
1 x 1, 2 x 2, 1 x 3 and 3 x 1 frames, an ERROR fill, horizontal and vertical
lines, a high-attribute run, and a status row with alternating reverse/normal
runs.  Serial writes were `[126, 8, 119, 27, 116, 13, 113, 17, 105, 7, 18]`;
each dispatch carried a run or a cursor/SGR sequence, never one cell.  A style
change followed by `tui_flush()` emitted no cell run.

`tui_style.rel` is 12,381 bytes.  The final `libtui.lib` is 72,580 bytes and
`tui_test.exe` is 32,070 bytes (image 32,034, BSS 7,487, stack 256).

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk_package tests.test_v9958 tests.test_console_serial
git diff --check
```

The combined package 68-72 run completed 173 tests with 171 passed and 2
environmental skips; `git diff --check` was clean.  Both console backends
decoded the same 21-row model, including reverse attributes.

## Supervisor review

Correction required. The package's reported validation passes, but direct
review found a missing zero-area guard in `tui_frame_title()`. A rectangle
with nonzero width, zero height, and a visible `y` causes `tui_frame()` to do
nothing and then allows the title path to write cells on that row. This
violates the degenerate-rectangle and clipping contract. Package 70 correction
01 is active; package 71 acceptance remains gated by it.

## Correction 01

The original `tui_frame_title()` called `tui_frame()` (which correctly no-ops
for an empty clipped rectangle), then continued from the original rectangle.
A visible `5 x 0` rectangle with width at least five therefore wrote separator
spaces and title bytes outside its empty area.

The function now validates lifecycle, pointers, frame style and text style,
then returns success immediately for any `w == 0` or `h == 0` rectangle.  It
changes no cell, cursor, window, style or transaction state and emits no
backend write.  `TUI_FRAME_NONE` title-only rendering for nonempty rectangles
and partially clipped titles are unchanged.

The `styles` target also keeps a `SENT` model sentinel and covers `5 x 0`,
`0 x 5`, a titled `1 x 1` frame and a partially clipped titled rectangle at
the right edge.  Both serial and V9958/HID models assert that the sentinel
survives the two empty titled frames and that the clipped title stops at the
right screen edge.

Final sizes and styled writes:

```text
tui_style.rel             12,381 bytes
libtui.lib                72,580 bytes
tui_test.exe              31,531 bytes (image 31,495, BSS 7,487)
styled writes            126, 8, 119, 27, 116, 13, 113, 17, 105, 7, 18
```

Full validation after correction: 173 tests, 171 passed, 2 environmental skips;
`git diff --check` clean.

## Final supervisor acceptance

Accepted on 2026-10-18 after correction 01. Direct review confirmed that the
zero-area return follows lifecycle, pointer, frame-style, and text-style
validation, while preserving nonempty title-only frames. The supervisor ran
only the correction-specific styles replay: serial and V9958/HID both passed,
including the sentinel oracle that the prior implementation overwrote. The
worker's reported full 173-test gate is accepted without a duplicate run.
