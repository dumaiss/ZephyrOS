# Package 57 — m13 read-path measurement

This package *measures* the read path; it changes no behaviour and fixes
nothing about it.  A measurement build option (`KOS_IOC_PHASES=1`)
records the clock at each step of one `/fs` block read inside the IOC and
IOC-FAT drivers, and a card program fetches that table through a new
provider operation and prints per-phase min/mean/max.  Every shipped
image is byte-identical with the option off: `build/konaos.bin` is
`0a7dde34…` before and after this work.

The instrument did not survive its first board run in the shape it was
written in: the stamps the masked bulk receive took cost the receiver
more than its three-byte FIFO covers, and every bulk transfer failed with
`EIO` while the command lane kept working.  The instrument is therefore
recorded here in its fixed shape - two raw counter reads inside the
receive, no call, no retry, no parity check - together with the budget
that forced it, the before-and-after measurements, and the host model
that now reproduces the board's failure (section 6).  That fix is
option-only too: with the flag off the image is the same bytes it was.

The contract implemented here is `work/57-m13-read-path/WORK.md`: four
requirements (the instrument, the fetch operation, the program, the
measurement image and its tests), its test list, its hand-off and
validation list.  The record path is the one that file names.

## 1. Files

Added:

| file | part |
|---|---|
| `drivers/include/ioc_phases.h` | the stamping half of the instrument: the two channels' elapsed bytes per phase, the retaking stamp the phases *outside* the receive use, the table clear (option-only) |
| `drivers/include/ioc_phases_clock.h` | the clock half: channel 1's port, its one-shot programming, the boot segment's init (option-only) |
| `tests/perf/readphase.c` | the card program: three passes, the raw fetch, the CRT resolver, the report |
| `tests/test_readpath.py` | the wiring, ABI, placement, budget and replay acceptance (14 tests) |

Changed:

| file | change |
|---|---|
| `abi/kos/protocol.h` | `KFILE_OP_PHASES`, the ten `KFILE_PHASE_*` ids, the flags and path constants, `struct kfile_phases` (24 bytes, the payload of one fetch), and the documentation of the handshake slot |
| `drivers/ioc/ioc.c` | the instrument's table in DRIVER_IO (`ioc_phases`), the receive's validity bits (`ioc_phases_bulk_done`, set after a validated transfer, outside the masked window), the SENT and REPLY stamps |
| `drivers/ioc/ioc_driver.h` | the option-only table declaration |
| `drivers/ioc/ioc_boot.c` | starts channel 1 in `ioc_hw_init` under the option |
| `drivers/ioc/ioc_io.asm` | the assembly side: the generated switch, and the three inline raw stamps inside the masked receive (admission, after the header loop, at the trailer) with their budget note |
| `drivers/ioc/ioc_proto.c` | publishes the table's address for the provider, in the request payload's spare slot |
| `drivers/iocfat/iocfat.c` | its own table and five stamps, the peer address capture, and `KFILE_OP_PHASES` (its table merged with the peer's phases) |
| `kernel/vfs/fs.c` | forwards the fetch op to the provider inside the option's guard (one extra comparison in the measurement build, nothing in the shipped one) |
| `Makefile` | `KOS_PHASE_FLAGS`, the generated `ioc_phase_build.inc` the assembler reads (sdasz80 has no `-D`), the `readphase` program row, the option header dependencies, and the `phase-image` target |
| `tests/z80sim.py` | the instruction-cost table's single-run ED forms (section 7.2) and the receive FIFO/overrun model the board's finding asked for (section 6) |
| `README.md` | the `phase-image`/`readph` note in "Running on a board" |

Nothing else reads the option, and no system file names it: `phase-image`
is the only recipe that defines it, and the test asserts that.

## 2. The instrument's clock

The WORK's parenthetical ("tick count and down-counter") cannot measure
the thing this package is about: the bulk transfer runs with interrupts
masked, the timer's CTC latches one pending request, and every masked
expiry past the first is lost - so a reading of the *kernel's* tick
counter inside that window reports the window's length as zero.  The
instrument therefore reads two **free-running CTC counters** instead:

- **channel 1** (port 42h, the physical channel no shipped image
  programs): programmed once by the IOC driver's boot segment - reset,
  timer mode on the internal 10 MHz / 256 clock, interrupts off, constant
  0 (256 counts per cycle);
- **channel 2** (port 41h): the timer driver's own tick channel, 250
  counts per cycle, which the instrument only reads.

Both count the same 10 MHz / 256 clock as the tick counter, so one count
is the documented 25.6 us, and both keep counting while interrupts are
masked.  A stamp is two port reads that store `0 - counter` per channel,
one byte each, in the table; two stamps are resolved to a single count
difference through the two cycle lengths (250 and 256, LCM 32,000 counts
= 0.8192 s window, one-count resolution) by the fetching program, so no
epoch is stored.

The three stamps the *masked bulk receive* takes are not the retaking
stamp described below: inside that window a stamp is two raw counter
reads and nothing else, because the receiver's FIFO - not the clock -
bounds what a stamp may cost (section 6).  Everything outside the
receive uses the retaking stamp this section describes, and the program
cannot tell the two apart on the wire: both store the same two bytes.

Two readings taken a few T-states apart are not automatically a valid
pair: if the second read lands across a channel-2 reload, its count is
one ahead of channel 1's, and the congruence the resolution solves has
**no answer at all** - a naive solver returns a number that is a whole
cycle out (the failure mode the replay showed before the fix, ~22,000
counts off).  The parity invariant is what removes it:

- both channels advance one count per 256 T-states, so a **clean** pair's
  two cycle differences are congruent modulo 2, and that parity is a
  constant of the two clocks;
- the stamp retakes a pair while channel 1 moved inside it, or while its
  parity differs from the last accepted pair's (bounded, four tries);
- the program checks the same invariant *before* resolving a difference,
  and a pair that fails it is reported as **torn** and left out of its
  row's samples rather than answered - the retry only ever costs a
  sample, it can never produce a wrong count.

## 3. The phases

Ten stamps, in time order for a cache miss (the ids in `protocol.h` are
in that order): `entered` (the provider's read call), `cache` (hit or
miss decided), `sent`, `reply`, `admit`, `first`, `last` (the transport,
stamped by the IOC driver and its assembly), `copy` (the payload staged
into the provider's buffer), `caller` (the copy-out), `return` (the
provider's call returned).  A report row is the time from the step before
it to it, which reads as what that step cost to reach; `entered` is the
read's first step and never carries a time.

The table is 24 bytes: ten elapsed bytes per channel, a sixteen-bit valid
mask, the flags byte and the path byte, which is exactly one request
payload.  `KFILE_OP_PHASES` carries no descriptor: the kernel forwards it
to the provider, which copies its own table into the reply payload and
merges the transport phases the IOC driver published.  Two pieces of the
ABI are worth knowing:

- the provider cannot see the caller's buffer - that is what a descriptor
  is for - so the table's own `path` stays unknown and the *program*
  classifies it from the buffer it passed (the replay cross-checks that
  against the nucleus's own copy-path counters);
- the fetch is option-only, and an image without the instrument answers
  it with nothing: the program detects that (a dispatched call leaves the
  zeroed payload alone) and says so, which is the run-time form of "the
  op is absent here".

## 4. The program

`tests/perf/readphase.c` builds as `/system/readphase.exe` and lands on a
card as `READPH.EXE` (FAT 8.3 truncates the name).  Three passes, each
re-reading the file from the start, because the copy path is the
nucleus's choice for the *caller's* buffer (architecture 4.9):

1. 512-byte reads into the program's own static buffer (low memory, clear
   of the aperture): the caller's bank, mode-10 one-LDIR path B;
2. 512-byte reads into 8000h of the caller's own bank: an
   aperture-range address, so the nucleus stages the copy through the
   bank gate, path C;
3. 128-byte reads into the static buffer: four reads per 512-byte block,
   so three of them answer from the provider's cache and only the first
   carries the transport's phases.

Usage is `readph FILE [BLOCKS]` (default 256 blocks).  Nothing is printed
while a pass runs (the report is built from the same 6.4 ms-resolution
data either way, but a print would move the clock); the pass lines carry
the reads, misses and hits, the rows carry `n`, min, mean and max in ms,
the `timer` row brackets the read calls with the timer driver's own
reading, and the `sum` line is the arithmetic's check: the ten
differences of one block telescope, so their total must equal the
ENTERED-to-RETURN difference to within the four-count allowance, and the
line prints the mismatch count, the torn count and the worst deviation,
so a pass says how much of its data it could verify and by how much it
missed.

## 5. What the replay shows

`make phase-image` builds the instrumented image, checks its map, and
replays it with a card carrying the program and an 8 KiB file
(`tests/test_readpath.py`, 14 tests, all passing).  The report below is
that replay's, verbatim (`build-phase/konaos.bin` `7b22a20d…`, program
`c532056f…`):

```
pass 1: 512-byte reads into 3569h, path B, 2 reads, 2 misses, 0 hits
     phase     n      min     mean      max
   entered     0         -
     cache     2    0.281    0.307    0.332
      sent     2    2.483    2.585    2.713
     reply     2    2.048    2.048    2.048
     admit     2    1.817    1.894    1.996
     first     2    0.179    0.179    0.179
      last     2   12.800   12.800   12.800
      copy     2   31.744   31.744   31.744
    caller     2    1.664    1.740    1.817
    return     2    0.128    0.128    0.128
     timer     2   50.764   50.790   50.816
       sum     2 of 2 fully stamped, 0 mismatch, 0 torn, worst 0 counts
pass 2: 512-byte reads into 8000h, path C, 2 reads, 2 misses, 0 hits
     phase     n      min     mean      max
   entered     0         -
     cache     2    0.307    0.307    0.307
      sent     2    2.713    2.713    2.713
     reply     2    2.048    2.073    2.099
     admit     2    1.792    1.792    1.792
     first     2    0.179    0.179    0.204
      last     2   12.800   12.800   12.825
      copy     2   31.718   31.718   31.744
    caller     2    4.736    4.736    4.736
    return     2    0.128    0.128    0.128
     timer     2   53.708   53.708   53.734
       sum     2 of 2 fully stamped, 0 mismatch, 0 torn, worst 0 counts
pass 3: 128-byte reads into 3769h, path B, 8 reads, 2 misses, 6 hits
     phase     n      min     mean      max
   entered     0         -
     cache     8    0.307    0.332    0.358
      sent     2    2.534    2.611    2.713
     reply     2    2.048    2.124    2.227
     admit     2    1.817    1.817    1.817
     first     2    0.179    0.179    0.179
      last     2   12.800   12.800   12.800
      copy     2   20.454   20.454   20.454
    caller     8    0.844    0.896    1.049
    return     8    0.128    0.128    0.153
     timer     8    8.985   16.486   38.784
       sum     2 of 8 fully stamped, 0 mismatch, 0 torn, worst 0 counts
readphase: end
```

What it says, and what it does not:

- **The arithmetic holds.**  Every fully stamped block's ten differences
  add up to its door-to-door difference exactly (worst deviation 0
  counts, no torn pair, in all three passes), and every row carries the
  sample count the semantics require: the two miss-only passes fill all
  ten rows per read; the cache-hit pass keeps the transport rows at one
  per 512-byte block (`sent`/`reply`/`admit`/`first`/`last` n=2 of 8)
  while `cache`, `caller` and `return` see all eight reads.
- **The copy path is the one the buffer asked for.**  Path B for the
  static buffer, path C for 8000h, and the nucleus's own copy counters
  move with it (>= 5 descriptor copies per block for B, one per read for
  C) - the program's classification is not just its own claim.
- **The lane now sets the clock.**  The modelled controller releases its
  bytes at the wire rate section 6 derives (one per 250 T-states), so
  the `last` row - the payload's own span - reads 12.800 ms in all three
  passes, which is exactly 512 bytes at that rate.  The transport rows
  are the wire's time, not the host model's instruction loop.
- **The masked window is where the time is.**  The `timer` row brackets
  the same reads and reports 50.8 ms (pass 1), 53.7 ms (pass 2) and 9.0
  to 38.8 ms (pass 3) - the last one shows the cache cleanly: the hit
  reads never enter the transport, so their bracket is a quarter of the
  miss's.  The instrument's own rows show the transport and the copy
  inside that bracket.
- **The receive stayed inside its budget.**  Every masked receive in the
  replay - the boot's own file loads as much as the program's reads, 32
  of them - takes three stamps, and the replay measures each stamp's
  service gap from the wire.  The worst is 218 T-states against the 750
  T-states the three-byte FIFO covers at the wire rate (the three stamps
  cost 105, 112 and 218 T-states at their sites), and the modelled
  receiver reports no overrun: the check the board's failure asked for
  (section 6).
- **What these numbers are not: board timings.**  The replay's ms values
  are the model's, and the ones to publish are the owner's board run
  (section 8).  What the replay establishes is that the instrument, the
  fetch and the report are right: the phases are all stamped, the clock
  resolves, the check holds, the paths are what the buffers say, and the
  receive lives inside the FIFO's budget.

Two negative results are part of the acceptance, too: the shipped image
*refuses* the fetch (the program prints the phase table is missing), and
with the option off the instrument costs the image nothing (section 7.2
and the wiring tests).

## 6. The board's finding: a stamp cost more than the three-byte FIFO

The first board run of this image failed, and what it found is what the
instrument's shape now answers:

- **Symptom.**  The command lane was fine - `ls` worked, lookups
  worked - and every *bulk* transfer failed: loading any card program
  ended in `EIO`.
- **Cause.**  The three stamps inside the masked receive were calls into
  C, and the C side is the *retaking* stamp: two counter reads per
  attempt, a channel-1 stability re-read, a parity comparison against the
  last accepted pair, and up to four attempts.  The controller clocks the
  lane at about one byte per 250 T-states - the owner's own board figure
  for this lane, from the CP/M comparison in
  `work/57-m13-read-path/WORK.md`: 512 bytes per 12.8 ms of ZREAD, so
  25.6 us a byte - and the receiver's FIFO holds three bytes
  (`KOS_IOC_RX_FIFO_DEPTH`).  The whole cushion is **750 T-states**, and
  what has to fit in it is the code the driver runs between two bytes, not
  the clock's resolution.  A stamp that calls into C does not fit:
  measured in the replay with the pre-fix shape restored - each inline
  stamp cut back to `call _ioc_phase_*`, a thin C wrapper around the
  retaking stamp, which is *cheaper* than what the board ran - the two
  stamps that ran inside the first failing receive cost the receiver
  service gaps of **741 and 878 T-states**, and the transfer lost the byte
  the controller was sending.
- **The fix.**  The three stamps inside the receive are now twelve
  instructions of inline assembly: load the table address, `in` channel
  1, `in` channel 2, negate both, store both - **88 T-states**, 15
  T-states between the two counter reads, no call, no retry, no
  arithmetic.  The retaking stamp stays where the FIFO is not at risk:
  the two phases the C side stamps (SENT, REPLY) and the five the
  provider stamps are outside the masked window and keep it.  All
  checking moves out of the window as well: the fetching program rejects
  a torn pair instead of resolving it (section 2), and the driver marks
  the three receive phases valid in C after a *validated* transfer, so a
  failed or short transfer reports nothing instead of a partial
  measurement.  The worst service gap the replay then measures is **218
  T-states**, a third of the cushion.
- **The fallback the work list allowed was not needed.**  Dropping the
  `first` stamp and reporting `admit`->`last` as one span was the plan if
  even two reads between bytes were too much.  At 88 T-states a stamp
  costs about a third of a byte time, so all three survive and the report
  keeps its admission/first/last rows.
- **The host model now fails the way the board failed.**  The board peer
  in `tests/z80sim.py` gained the receiver's side: a three-byte FIFO, a
  release rate of one byte per 250 T-states, and an overrun when the
  host's masked code is away from the lane long enough for the
  controller's next byte to arrive with the FIFO full (`a_overruns`,
  `a_fifo_fault` - the "lost packet" the driver reports as `EIO`).  With
  the pre-fix stamps the replay reproduces the board exactly (`readph:
  I/O error`, `a_overruns: 1`); with the fixed ones it reports **no
  overrun** in any of the 32 receives, and the test asserts it.  A model
  that cannot fail the way the board failed cannot show a fix working.
- **What the fix does not change.**  The stamps store the same two bytes
  per channel, so the program, the ABI, the table and every row, sum and
  tolerance of section 5 are as they were; what changed is the cost of
  taking them, which is the whole point of a stamp inside a three-byte
  FIFO's window.

The budget, in one place (T-states; one lane byte is 250 of them):

| quantity | T-states | byte times |
|---|---|---|
| one lane byte, the controller's clock period | 250 | 1.00 |
| the receiver's cushion: three bytes of FIFO | 750 | 3.00 |
| a pre-fix receive stamp, measured in the failing receive (741 and 878) | 741-878 | 3.0-3.5 |
| the fixed in-receive stamp, twelve instructions | 88 | 0.35 |
| the window in which its two counter reads can tear | 15 | 0.06 |
| the worst service gap it measured, with the code that follows it | 218 | 0.87 |

## 7. Deviations

### 7.1 The clock is a CTC pair, not the tick counter

As section 2 says: the WORK's suggested reading loses the very window
this package exists to measure.  The substitution is the work's only
design deviation, and it is what the two `timer` and instrument rows
together witness in the replay.

### 7.2 The host model's single-run ED forms were charged a whole BC run

Found while validating this package, and fixed because it is what the
measurement reads: `tests/z80sim.py`'s cost table treated `ini`/`outi`
(and `ldi`/`cpi`/... , 160h-171h) as block instructions and charged them
`21 * BC - 5` T-states *per execution*, where the simulator executes one
iteration and the driver's payload read is a per-byte `ini`.  A 512-byte
block read was therefore modelled ~87,000x too slow (one instruction per
byte at ~1.4 M T), which pushed a single read's door-to-door span against
the instrument's 0.8192 s window and aliased the resolution.  With the
single-run forms charged their real 16 T-states (`ED_BLOCK` now holds the
repeating forms only) the modelled block read costs what its instructions
do.  No other package's figures are invalidated: the m12 delivery
measurement, the one recorded number that sits near this code, measures
**8,416 T** with the corrected table against **8,486 T** with the old one
- closer to the 8,407 T its record quotes, and inside that test's 9,250 T
bound either way.

### 7.3 The card name is 8.3

`readphase.exe` is `READPH.EXE` on the card; the owner types
`readph BIG.BIN 256`.  The test pins the stored name.

### 7.4 A torn pair is reported, not answered

Section 2: the instrument retakes a pair whose parity breaks the
invariant, and the program drops a pair it still cannot resolve.  In this
replay there are none (`0 torn` in all three passes); on a board with
different interrupt traffic the resolver would drop a sample and say so
rather than print a count it cannot stand behind.

## 8. Hand-off: the board run

The numbers to publish are the owner's, and the package's remaining work
is one card and one command:

```sh
make phase-image                       # builds both artifacts, replays them
# copy build/user/readphase.exe to the card as READPH.EXE
# copy any test file to the card as BIG.BIN (a few blocks is enough)
```

at the prompt:

```text
readph BIG.BIN 256
```

The contract's validation list asks for the report to be captured twice:
the production image (where the fetch must be refused with a clear
message) and the measurement image (`make phase-image`), whose table is
then the record's board section.  This record marks that half
**PENDING** - it needs the physical card, and nothing in this package can
stand in for it.

The first board run happened, and what it produced is section 6: the
phase image as it was then written broke every bulk transfer.  The fix is
in this tree, so the board check that closes the package is now the one
the work list names:

```sh
make phase-image                       # build-phase/konaos.bin `7b22a20d…`
# write build-phase/konaos.bin to the board
```

on the board:

1. `X /system/hwtest.exe` - loading a program from the card is itself a
   bulk transfer, so this is the check that failed before: it must load
   and run with no `EIO`, and print `hwtest: 4/4 PASS`;
2. copy `READPH.EXE` and a few-block `BIG.BIN` to the card and
   `readph BIG.BIN 256` - the load is a second bulk transfer that failed
   before, and the report is the record's board numbers; its three
   receive rows (`admit`, `first`, `last`) must carry their sample
   counts, which is the instrument's "the receive survived" statement.

Status: **PENDING** for items 1-2 on hardware.  The host model now
reproduces the failure and passes with the fix (section 6), which is as
far as this tree can take it.

## 9. Test coverage

`python3 -m unittest tests.test_readpath` (14 tests, run by
`make phase-image` after the image is built):

- **wiring**: the flag is empty by default and only the `phase-image`
  recipe sets it; no system file names the option; the assembly switch is
  generated from the same variable the C half consumes; every writer of
  the table (both drivers' stamps, the kernel's forwarding, the published
  handshake slot) is inside the option's guard, and both shared headers
  carry nothing a shipped build would compile; the boot segment includes
  the clock header alone;
- **the receive's budget**: the three in-receive stamps are the twelve
  raw instructions the board's failure asked for - no `call`, no jump, no
  retry - and their tabulated cost stays inside `RECEIVE_STAMP_BUDGET_TSTATES`
  (250 T-states); what they write is two counter reads, by the ABI's own
  offsets;
- **ABI**: the op number, the ten ids in stamp order, and the 24-byte
  table shape;
- **placement**: the program's areas end at 3AFC h, clear of the 8000h
  frame its second pass reads into, and its card name is 8.3;
- **the instrumented replay**: the report's passes, paths, cache counts,
  per-row sample counts, `min <= mean <= max`, real work in the transport
  rows, the sum check (no mismatch, no torn pair, worst deviation inside
  the allowance), the nucleus's copy-path counters as an independent
  witness of the path claim, and the wire's own check - every masked
  receive in the replay takes exactly three stamps, each stamp's service
  gap is inside the 750-T-state FIFO budget, and the modelled receiver
  reports no overrun;
- **the production refusal**: the same program in the production image
  gets nothing from the fetch and reports it.

The modules this work touches are green: `tests.test_ioc`,
`tests.test_iocfat`, `tests.test_ipc_selftest_sim`, `tests.test_timer`,
`tests.test_events`, `tests.test_hwtest_sim`, `tests.test_fs_selftest_sim`,
`tests.test_ns_selftest_sim`, `tests.test_driver_images`,
`tests.test_sdk`, `tests.test_readpath`.  The whole-host-suite run has two
failures this package leaves alone, both present in the tree it started
from: three `tests.test_console_serial` replays (checked by re-running
that module with the harness table reverted to its old numbers) and
`tests.test_sdk_package`'s tarball pin, which does not list
`include/klibc/stdio.h` or `include/kos/stream.h` - package 56's
additions, untouched here.

## 10. What this record does not say

No board number is claimed here: section 8 is the hand-off, and the
package deliberately stops before it.  The replay's ms values are the
host model's; what they establish is the instrument's correctness and
that its receive stamps live inside the FIFO's budget, not what the read
path costs on the card.

## Addendum: the board run is abandoned; the simulator is the instrument (owner, 2026-10-16)

On the board the instrumented image broke every bulk-lane transfer:
lookups and `ls` (command lane) worked, but loading any card program and
`fs_selftest`'s card I/O failed with `EIO` - the stamps inside the
controller-clocked bulk receive overran the SIO's three-byte FIFO.  The
stamps were cut to two raw counter reads, but the image still could not be
made to run reliably, and the owner decided to proceed from the simulator.

The simulator is trustworthy for this measurement since section 6.2's fix
(the single-run `ED` forms were charged a whole `BC` run, which had made
every IOC timing in the model meaningless): Z80 work is now costed per
instruction, and only the controller's own latency is idealised.  The
cross-check is the total: the simulator's 512-byte read (47.4 ms) is close
to the board's (~50 ms, the SDBENCH port), so nearly all of the board's
time is Z80 work and the phase table attributes it.  The finding: the
`copy` phase (the payload staged from the IOC driver's bulk buffer into
the IOC-FAT buffer, and the return between them) is 31.6 ms of 47.4; the
staging is a C byte loop that SDCC compiles to about 290 T-states per byte
(~15 ms per block) where an `LDIR` costs 21.  The fix package is
`work/58-m13-read-path-fix`.
