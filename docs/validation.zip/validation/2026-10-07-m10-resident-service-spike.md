# M10 resident-service spike: measurement report (package 35)

Date: 2026-10-07.  Work package:
[WORK.md](../../work/35-m10-resident-service-spike/WORK.md).

Images:

| transport | image | configuration |
|---|---|---|
| **A** (package-34 24 KiB window) | `build-rsvc-spike/zephyros-rsvc-spike.bin` | `ZOS_RSVC_SPIKE=1`, page 1 (`P=1`, `8000h-DFFFh` = bank 6) |
| **B** (8 KiB slot overlay) | `build-rsvc-spike-b/zephyros-rsvc-spike-b.bin` | `ZOS_RSVC_SPIKE=1 ZOS_RSVC_TRANSPORT_B=1`, `P = 4/5/6` |

Every number below is an evaluation measurement: both images are built from
test-only sources (`tests/target/rsvc/`, `tests/target/include/rsvc_test.h`,
`tests/m10/manifest-rsvc.json`) and a syscall hook that exists only under
`ZOS_RSVC_SPIKE=1`.  The production image is byte-identical to package 34's,
SHA-256
`f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7`.

The spike is a resident-service architecture in miniature: a bank-7 nucleus
substrate (endpoint table, bounded frames, nucleus-issued buffer
descriptors, a copy primitive, an IRQ trampoline, a loader upcall path) and
six synthetic bank-6 services (`echo`, `con`, `ioc`, `fat`, `vfs`, `irqx`)
whose call graph is `client -> vfs -> fat -> ioc`.  A client program
(`rsvc.zex`) runs the protocol matrix over the substrate and prints its own
verdict: **`rsvc: 49/49 checks` / `rsvc: PASS`** on both transports.

## 1. Summary

* All nine claims have a measured verdict.  **C1-C4 and C6-C8 are
  confirmed on both transports; C5 is confirmed on A and refuted on B; C9
  is confirmed for A and refuted for B** (B fails the product-term fit
  before its capacity is even reached).
* The crossings are cheap: a null call is **9,858 T-states** on A, a
  512-byte chained read **84,787 T (165.6 T/B)** against today's direct
  `FS_READ` of the same chunk at **300,952 T (587.8 T/B)**, and a
  256-byte `con.WRITE` **129,260 T (505 T/B)** against today's direct
  console write at **165,532 T (646.6 T/B)**.  The service path pays one
  crossing per call and wins above **≈48 bytes** per write.
* The service domain is bounded: the deepest chain nests **4** deep with a
  **278-byte** service-stack high-water mark (measured with 384 bytes
  allocated) and 624 calls executed.
* An IRQ owned by a service is delivered in **937 T-states** and the
  handler costs **196 T-states** on top of a 542-T baseline ISR pass; the
  interrupted call completes.
* Transport B's overlay **cannot be programmed on the 22V10 as built**:
  19 product terms on `RAM_A16` against a budget of 10 (17 without the low
  region, 18 with one region reserved).  Transport A's window needs 8
  terms per output and still fits with the mode-10 aperture (7/7/7).
* The phase-0 parameters are pinned in §10: transport A, 32-byte frame,
  nesting 4, refuse-by-default re-entrancy, direct descriptors with staged
  copies only for invisible buffers, and a 512-byte service stack that
  requires the common ceiling to move to the M10 reservation (3,072).

## 2. How the spike works

* **Endpoint identity.**  Services register endpoints as
  `(class, instance)` (6 classes, `RSVC_MAX_ENDPOINTS` 8).  The client
  holds handles, never addresses or slot numbers.
* **Bounded frame.**  One 32-byte frame (8-byte header, 24-byte payload:
  `op`, `flags`, `desc`, `arg0`, `arg1`, `result`, payload) carries every
  protocol in the matrix.  The nucleus copies the caller's frame into
  nucleus storage at entry and the reply back at exit; a service only ever
  reads and writes the nucleus-owned copy.
* **Descriptors.**  Data movement uses nucleus-issued descriptor ids
  (`RSVC_DESC_MAX` 4096).  A descriptor that does not name a buffer the
  caller may touch is refused (`-ZOS_EINVAL`); a raw caller address is never
  part of the ABI.  All payload movement inside the domain is the nucleus
  copy primitive `rsvc_copy_run` (LDIR): 1,247 copies / 140,576 bytes on A,
  1,728 / 156,964 on B.
* **Domains.**  On A one page value maps the whole resident bank into
  `8000h-DFFFh` (`ZOS_RSVC_DOMAIN_SIZE` 0x6000); on B the page field
  selects one 8 KiB region (slots 4/5/6 at `8000h`/`A000h`/`C000h`; slot 7
  is unusable because it would overlay the caller's low window).  Mode 11
  keeps the caller's bank in `0000h-1FFFh`, so the caller's buffer window
  is never overlaid.
* **Entry/exit.**  The fixed bank-7 primitives save and restore the latch
  (`rsvc_domain_enter`/`rsvc_domain_exit`); nested calls use
  `rsvc_domain_set` with a locally saved latch and have their own
  epilogue, so a nested call can never decide the outermost call's exit.
* **Measured by replay.**  `tests/test_rsvc_spike_sim.py` boots the built
  images in the revision-13 decoder model with the package-34 T-state
  opcode table, so every figure is an exact T-state count (no sampling
  noise).  Phases are delimited by markers the client prints; the per-call
  figure is the marginal cost between iteration 8 and iteration 24 of each
  phase (`N1=8`, `N2=24`), which removes first-call effects.  The CTC0
  stand-in used for C6 injects the vector only when the kernel's own CTC
  helper has armed it, `iff1` is set, page bits are set and the program
  counter is inside the resident domain - i.e. only where the kernel would
  receive it.

## 3. Claim verdicts

| claim | verdict | evidence |
|---|---|---|
| **C1** one small bounded frame serves real protocols | **confirmed** (A and B) | 32-byte frame carries all protocols: null (8/16/32-byte frames), `con.WRITE` 1/16/64/256 B, console, a 512-byte chained read (direct and staged), same-domain conformance, process-exit upcall and the executable stream.  `49/49` in-program checks (`null-status`, `con*-status`, `read-status`/`read-pattern`, `staged-*`, `upcall-*`, ...).  No side channel: results, payload and descriptor ids only |
| **C2** no raw cross-domain pointers | **confirmed** (A and B) | `capture-refused` and `forged-refused` both `-ZOS_EINVAL`; evidence `desc_forged 2`, `desc_refused 1`; every byte moved by the nucleus copy primitive (see §2); services never see a caller address (the ABI has none) |
| **C3** crossing cost acceptable with batching | **confirmed** (A and B) | null call 9,858 T; 256-byte `con.WRITE` 505 T/B against 646.6 T/B for today's direct console write; 512-byte chained read 165.6 T/B (direct) / 216.8 (staged) against 587.8 T/B for today's `FS_READ`; gate baseline from package 34: 7,358 T per 64-byte request.  Tables in §4 |
| **C4** call graphs nest within a small bound | **confirmed** | deepest chain `client -> vfs -> fat -> ioc` runs; `nested_max 4`, `depth-refused -ZOS_ENOSPC` beyond the bound, 624 calls; stack high-water marks: service 278 of 384, gate 87 of 256, ISR 15 of 256 (§6) |
| **C5** same-domain calls are an invisible optimisation | **confirmed on A, refuted on B** | A: `fastpath` 84,791 T vs `fullpath` 84,872 T for the identical 512-byte chain (81 T, 0.1 %), payloads equal (`conform-payload`), 200 fast-path dispatches.  B: first hop crosses slots, so the distinction collapses: `fastpath` 85,332 T vs `fullpath` 85,243 T (Δ = -89 T, i.e. below the measurement's own resolution) and only 103 fast dispatches |
| **C6** IRQs can be owned by services | **confirmed** (A and B) | a test-owned CTC0 helper armed by the kernel fires while a service call is in progress: `irq_count 2`, `irq_in_domain 1`, handler latch restored exactly (`call-latch`), final `RETI` executed by kernel code (`E1D5h`, never inside the resident domain), and the interrupted call completes.  Delivery 937 T, handler cost 196 T (§5) |
| **C7** re-entrancy is detectable and refusable | **confirmed** | a self-call into the service already on the stack is refused `-ZOS_EBUSY` (`reent-refused`, 1 refusal); the same call into an endpoint that declares `RSVC_EP_REENTRANT` succeeds (`reent-allowed`); depth beyond 4 refused `-ZOS_ENOSPC` (`depth-refused`, 1) |
| **C8** nucleus -> service upcalls | **confirmed** | process-exit notification reaches the vfs-like endpoint and returns 42 (`upcall-exit`, `exit_notify 1`); the loader streams an executable through `vfs -> fat -> ioc` using a nucleus-held object handle - no pathname in the nucleus - and the client reads its 512-byte blocks back (`upcall-exec`, `stream-bytes`, `chain-words`) |
| **C9** the nucleus fits bank 7 with room for M10 | **confirmed for A, refuted for B** | ledger in §8: the measured substrate is 3,900 code + 343 data + 384 common bytes (A) and fits the fixed region with the 16-granule arena; the VFS/provider objects that leave bank 7 measure 17,115 B and the page-0 window still has 2,821 B of code room, so the package-33 M10 mechanisms fit with the arena floor restated (or preserved by linking the mechanism page-0-only).  The real M9 driver set (16,123 B) plus today's VFS (17,115 B) needs **two** service banks, which A provides by adding page values (`P=2` -> bank 5, verified in the decoder).  B cannot be programmed at all (§9) |

## 4. Cycle tables (transport A)

Baselines are package 34's rev-13 window figures
([2026-10-06-m10-rev13-window.md](2026-10-06-m10-rev13-window.md)):
window call round trip **242 T**; 512-byte window copy **10,827 T
(21.1 T/B)**; revision-12 gate fallback ≈**7,358 T per 64-byte request**
and 147,163 T (287.4 T/B) for 512 bytes.

### 4.1 Null call and frame sizes

| phase | frame bytes | T/call | note |
|---|---:|---:|---|
| `null8` | 8 | 9,858 | |
| `null16` | 16 | 9,930 | |
| `null32` | 32 | 9,858 | full frame |

The cost is size-independent because the nucleus copies the whole frame;
the ceiling can be raised without a per-call cost change, and a smaller
frame buys nothing.

### 4.2 `con.WRITE` per size, against today's console write

| size | service path T | T/byte | today's direct path T | T/byte |
|---:|---:|---:|---:|---:|
| 1 B | 13,745 | 13,745 | 5,548 | 5,548 |
| 16 B | 20,540 | 1,284 | - | - |
| 64 B | 42,284 | 661 | - | - |
| 256 B | 129,260 | 505 | 165,532 | 646.6 |

The service path is a fixed 13,745 T plus **453 T/byte**; the direct path is
5,548 T plus **627.4 T/byte**.  Break-even is **≈48 bytes per write**;
below that the direct syscall is cheaper, above it the resident service is,
and at 256 bytes it is 1.28x faster.  A 256-byte write crosses as 8 frames.

### 4.3 512-byte chained read, direct vs staged, against `FS_READ`

| phase | T/call | T/byte | what it is |
|---|---:|---:|---|
| `read` | 84,787 | **165.6** | `vfs -> fat -> ioc` with direct descriptors |
| `staged` | 110,987 | **216.8** | same chain, buffer staged through the nucleus |
| `fastpath` | 84,791 | 165.6 | same client code, same-domain fast dispatch |
| `fullpath` | 84,872 | 165.7 | same client code, forced full nucleus path |
| `fsread` | 300,952 | **587.8** | today's `SYS_FS_READ` of the same 512-byte chunk (with the rewind the resident path does not need, so the baseline is generous to today's path) |

The resident chain is **3.5x cheaper per byte** than today's direct
filesystem call; staging costs a further **+30.9 %** (A) when the receiver
cannot see the caller's buffer.

## 5. IRQ owned by a service

| measurement | A | B |
|---|---:|---:|
| delivery (injection -> domain entry) | 937 T | 937 T |
| ISR span, baseline pass (no handler) | 542 T | 542 T |
| ISR span, service pass (handler runs) | 738 T | 738 T |
| handler cost (difference) | **196 T** | **196 T** |
| deliveries / in-domain | 2 / 1 | 2 / 1 |
| final `RETI` | kernel code, `E1D5h` | kernel code, `E1D5h` |

The IRQ path is transport-independent: the trampoline needs only the fixed
core, the common stack and the page bits it writes itself.  The handler
runs inside the service domain on the service-safe ISR stack (15 of 256
bytes used), and the interrupted call's latch is restored exactly
(`ev.latch_ok == 1`), which is what lets the client continue to `PASS`.

## 6. Stacks and nesting

| domain | high-water mark | allocated |
|---|---:|---:|
| service dispatch (`client -> vfs -> fat -> ioc`) | **278 B** | 384 B |
| nucleus gate path | 87 B | 256 B |
| ISR | 15 B | 256 B |

Deepest nesting **4**; 624 service calls; one re-entrancy refusal and one
depth refusal.  The original 256-byte service stack saturates in the
deepest chain, so the spike runs 384 - the largest stack the current
2,560-byte common limit allows (usage 2,488).  §10 pins 512 bytes together
with the common-ceiling revision.

## 7. Resident bytes

Measured from the linked maps and the module containers of the built images.

| item | A | B |
|---|---:|---:|
| bank-7 kernel code end (`___kernel_code_end`) | `597Eh` (14,718 B from `2000h`) | `5AFAh` (15,098 B) |
| bank-7 `_CODE` | 14,677 B | 15,057 B |
| - IPC substrate in `_CODE` (`rsvc_core` + `rsvc_asm`) | **3,900 B** | **4,280 B** |
| bank-7 `_DATA` | 1,098 B (mapcheck 1,100 with alignment) | 1,162 B |
| - substrate data in it | 343 B | 407 B |
| driver arena | 8,192 B (16 granules) | 7,680 B (15 granules) |
| slack below the window | 438 B | 374 B |
| window code `_WINDOW` (page-0-only) | 19,708 B | 19,708 B |
| window cold data `_WINDOW_DATA` | 1,484 B | 1,484 B |
| common (`_COMMON` + `_COMMON_DATA`) | **2,488** of 2,560 B | 2,488 of 2,560 B |
| - service stack in common | 384 B | 384 B |
| bank-6 service payload loaded (image+bss) | 3,772 B | 3,772 B |
| bank-6 containers stored in bank 7 (6 files) | 2,625 B | 2,625 B |
| client IPC stub (`call_prepare` 71 B + `call_run` 53 B) | **124 B** | 124 B |
| client package | image 6,015 / bss 1,341 / stack 256 | same |

Per service (container file / loaded image+bss): `echo` 235/174, `con`
398/560, `ioc` 369/781, `fat` 521/910, `vfs` 837/1,173, `irqx` 265/174.
There is no per-service dispatcher to charge: dispatch, framing, copying
and the trampoline are shared nucleus code, counted in the substrate above.
On B the six services occupy slot 4 908 B, slot 5 1,173 B and slot 6
1,691 B of 8,192 B each.

## 8. C9 ledger: nucleus and service domains

Today's nucleus (end of M9, package 30c, before the spike - from
[M10-REFERENCE.md](../../work/M10-REFERENCE.md)):

```
bank7:  code 27990 bytes end 8D56h | arena 36 granules (33 boot, 3 free)
        | data 2241 bytes at D600h | isr 256 | slack 63 bytes
common: used 2104 of 7424 bytes (code 1410, data 694)
        | ceiling 3072, m10 512, limit 2560
```

In the evaluated revision-13 layout the spike build (the same kernel objects
plus the substrate) measures:

| region | A | B |
|---|---|---:|---:|
| fixed `2000h-7FFFh` (24,576 B) | code 14,718 + arena 8,192 + data 1,098 + slack 438 | code 15,098 + arena 7,680 + data 1,162 + slack 374 |
| window (`8000h-DFFFh`, page-0-only) | 19,708 code + 1,484 data | same |
| common | 2,488 of 2,560 | 2,488 of 2,560 |

Projection for the resident-service M10 (all quantities measured, not
estimated, except the package-33 mechanism table):

* **Substrate (new nucleus cost):** 3,900 code + 343 data + 384 common
  (A); transport B adds 380 code + 64 data for the cross-slot relay.
* **Objects that move to bank 6** (package 34's classification: 33 fixed /
  14 cold objects): the cold set measures **21,311 B** code+data in this
  build, of which the VFS/provider subset (`name`, `fs`, `romfs`,
  `romfs_provider`, `vfs_mounts`, `vfs_path`, `vfs_mount`, `vfs_file`,
  `vfs_dir`, `vfs_mutate`, `vfs_process`, `vfs_workspace`) is **17,115 B**.
  They stop occupying bank 7.
* **M10 mechanisms** (package 33): 1,530-3,110 code + 136-272 data +
  128-256 common on the nucleus side.
* **Fixed region after the move (A):** it holds 14,718 B of code today
  *including* the substrate, with an 8,192-B (16-granule) arena, 1,098 B
  of data and 438 B of slack - 24,446 of 24,576 B.  Subtracting the
  substrate, the non-substrate kernel is **10,818 B**; adding the
  substrate plus the M10 mechanisms back gives 16,248-17,828 B of code,
  which leaves room for **11-14 arena granules** - below the evaluation
  floor of 16.
* **Where that room comes from:** the evaluated layout already links
  19,708 B of page-0-only kernel code above `8000h`, where **2,821 B of
  code room and 564 B of cold-data room** remain; every gate normalizes
  the page field to 0, so syscall-side M10 machinery may be linked there.
  If the floor must hold at 16 granules, a further ~2-4 KB has to leave
  the fixed region as well (the measured `console`, `registry`,
  `module_loader` and `module_relocate` objects are 5,974 B), or the
  phase-0 record restates the floor.
* **Bank-6 occupancy:** today's driver modules (M9: `sio` 328, `hid` 979,
  `ioc` 3,711, `v9958` 4,462, `iocfat` 6,643 = **16,123 B**) plus the
  VFS/provider implementation above (17,115 B) total **33,238 B**, which
  exceeds one 24 KiB domain.  A therefore needs **two service banks**
  (`P=1` -> bank 6, `P=2` -> bank 5, verified against the decoder model).
  The spike's own synthetic `vfs+fat+ioc` is only 2,864 B, so a
  purpose-built service-side VFS is an order of magnitude smaller than
  today's implementation if the capacity is contested.

**Verdict:** C9 holds for transport A - the measured substrate fits the
fixed region with the 16-granule arena today, and the M10 mechanisms fit
once the VFS/provider objects leave bank 7 (page-0-only code has 2.8 KB of
code room above the split) or the arena floor is restated.  It cannot hold
for transport B, which fails the product-term fit outright.

## 9. Transport A versus B

| aspect | A: 24 KiB window | B: 8 KiB slot overlay |
|---|---|---|
| page field | one value shows the whole service bank (`8000h-DFFFh`) | one value per 8 KiB region; slot 7 must stay unused (it would overlay the caller's low window) |
| product terms (exact minimiser, `tools/pld_terms.py`) | `RAM_A16/A17/A18 = 8/8/8` (budgets 10/12/14); with the mode-10 aperture **7/7/7** | **19/8/8 - does not fit** `RAM_A16`; 17 without the low region; 18 with one region reserved; no reserved-region variant reaches 10 |
| never-overlaid core | fixed region + common; the whole window is the service's | fixed region + common, plus the two window regions the page field is not showing; the low window is never overlaid |
| service capacity | 24 KiB per page value; more banks by adding page values (`P=2` -> 5) | 3 usable slots (24 KiB of bank 6) |
| real modules | 16,123 B of M9 modules + 17,115 B VFS => two banks | `iocfat` 6,643 + `ioc` 3,711 = 10,354 B > 8,192: the measured M9 block+controller pair does not fit one slot |
| arena | 16 granules | 15 granules (380 B more kernel code) |
| null call | 9,858 T | 9,898 T (+40) |
| `con.WRITE` 1 B / 256 B | 13,745 T / 129,260 T (505 T/B) | 14,036 T / 129,551 T (506 T/B) |
| 512-byte read direct / staged | 84,787 T (165.6 T/B) / 110,987 T (216.8) | 85,328 T (166.7) / 134,194 T (**262.1**, +20.9 %) |
| cross-slot traffic | none - every call is same-domain | relay moved 16,388 B; staged reads pay a 23,207-T penalty |
| fast path | real and measurable (81 T per 512-byte chain) | collapses (`fastpath` 85,332 vs `fullpath` 85,243): the first hop already crosses slots, so a same-domain ABI hint would be a lie |
| IRQ | delivery 937 T, handler 196 T | identical (transport-independent) |
| what it forces on service design | no per-service size limit inside 24 KiB; no cross-slot discipline; keep the fast path for cost, not for semantics | every service must fit 8 KiB beside its slot neighbours; chains must be planned against the slot map; cross-slot buffers must be staged (nucleus relay); nothing the fixed core touches may live in a slot |

## 10. Pinned phase-0 recommendations

1. **Transport A** (the package-34 24 KiB window at the `8000h` split), not
   B.  B's overlay needs 19 product terms on `RAM_A16` against a budget of
   10 and no reserved-region variant reaches it; it also costs a granule
   of the driver arena, forces an 8 KiB-per-service partition the measured
   M9 set violates, and buys nothing measurable (same-slot fast path
   collapses).  If more service room is needed, add page values
   (`P=2` -> bank 5) rather than change the decoder.
2. **Frame: 32 bytes** (8-byte header + 24-byte payload).  Cost is
   frame-size independent, so this is a comfort ceiling, not a cost: a
   larger frame can be adopted later without re-measuring; protocols above
   it chunk (a 256-byte console write is 8 frames at 505 T/B).
3. **Nesting limit 4**, endpoints 8, and a **512-byte service stack**.
   The deepest measured chain uses 278 of 384 bytes; 384 was the largest
   stack the old ceiling allowed.  The common ceiling must move to the
   M10 reservation: **limit 2,560 -> 3,072** (usage becomes 2,616).
4. **Re-entrancy: refuse by default** (`ZOS_EBUSY`) unless the endpoint
   declares `RSVC_EP_REENTRANT`; depth beyond 4 is refused
   (`ZOS_ENOSPC`).  Both refusals are exercised in-program.
5. **Descriptors: nucleus-issued ids over nucleus-owned buffers.**  Direct
   copies are the default (165.6 T/B for a 512-byte read); staged copies
   only where the receiver cannot see the buffer (cross-slot, or
   cross-call lifetime), at +30.9 % on A.  No raw caller address ever
   crosses the ABI.
6. **Upcalls** (process exit, executable streaming) use the nucleus-held
   object-handle model proven in C8; the nucleus carries no pathname.
7. **Architecture points the evidence contradicts:**
   * the proposal's hand count for the overlay (about 11 terms on
     `RAM_A16`) is wrong: the exact minimiser gives 19 (17 with the low
     region reserved) against a budget of 10 - B is not programmable on
     the 22V10 as built;
   * "VFS (~9-10 KiB) exceeds one slot" understates it: today's VFS and
     provider code measures 17,115 B, and the M9 block+controller module
     pair alone is 10,354 B, over the 8 KiB slot;
   * one service bank cannot hold today's drivers plus VFS
     (16,123 + 17,115 = 33,238 B > 24,576 B): the phase-0 record must plan
     two service banks;
   * the 384-byte service stack is a ceiling artefact, not a design
     choice: the phase-0 common ceiling has to carry 512.
8. **Arena floor:** the production floor of 32 granules cannot be
   inherited (the drivers no longer live in bank 7).  At the projected
   nucleus size the fixed region supports **11-14 granules**; the floor
   can stay at 16 if the M10 machinery is linked page-0-only (2,821 B of
   code room above the split) or a further ~2-4 KB of kernel objects moves
   out; otherwise the phase-0 record must restate the floor explicitly.

## 11. Hardware

Revision 13 has been programmed and hardware-verified since package 34
(production image and CP/M both boot, decoder fitted and reproducible).
The window-transport image built here is a candidate for the same
hardware run, and bank switching with an open window plus IRQ interaction
would be hardware-authoritative there.

**PENDING (spike):** no hardware run of the spike image is recorded in this
report; every measurement above is from the revision-13 decoder model.

## 12. Validation

One formal batch at the efficiency defaults, run 2026-10-06 23:59 EDT
ending 2026-10-07:

```sh
make clean && make check          # production hash + host suite
make rsvc-spike-selftest          # both spike images and their sims
python3 -m unittest tests.test_rsvc_spike tests.test_rsvc_spike_sim \
                     tests.test_decoder_rev13
git diff --check
```

Result: **BATCH OK**, wall clock **6m11.6s** (the 15-minute target is
met).  The production image hash is unchanged
(`f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7`, verified
by the batch's reproducible-rebuild step) and the simulator still defaults
to revision 12.  The spike's host checks
(`tests/test_rsvc_spike.py`, 17 checks incl. the product-term table, slot
plan, transport geometry, the common ceiling and the client package
geometry), the replay checks (`tests/test_rsvc_spike_sim.py`, 28 checks)
and the decoder suite (`tests/test_decoder_rev13.py`, 24 checks) all pass,
and the client prints `rsvc: 49/49 checks` / `rsvc: PASS` in both replays.
The report's figures were taken from the batch's images:

```
538c7934c7a517fba750b6285f1f9e8e  zephyros-rsvc-spike.bin     (transport A)
b4e83d4f7507fbe6116265ac94677687  zephyros-rsvc-spike-b.bin   (transport B)
```

and a replayed transcript of those images is byte-identical to the one the
numbers in §4-§7 came from.

This record and the `docs/memory.md` pointer to it were written after the
batch; the only suite that scans them (`tests/test_docs_evidence.py`) was
re-run on the final tree and passes.  No production source or build input
changed after the batch.

## 13. What the spike does not prove

* It is a synthetic service set (six small services, one IRQ class, one
  chain); no real driver or VFS migration was attempted, per the
  evaluation-only constraint.
* No asynchronous queues, revocation or generic marshaling: those were out
  of scope, and the synchronous substrate deliberately omits them.
* The IRQ claim rests on the CTC0 stand-in described in §2 (the kernel
  arms its own timer and the injection is gated on the same conditions the
  hardware delivery would have); a hardware run would remove that
  assumption.
* The projected M10 mechanism sizes are package 33's estimates, not
  measurements; only the substrate, the classification and the module
  sizes are measured here.
