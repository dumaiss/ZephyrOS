# Validation - snd-ztr-load (package 101)

Date: 2026-10-26

## Scope

Package 101: the ZTR loader on libsnd - `snd_ztr.c`, the C producer:
open with one forward validation pass over the `kos_reader_t` (never a
seek back, record by record and stream by stream), the resident tables
(the header fields, orders, instrument directory, macro data, pattern
directory and divisors), and the prepared-row queue that
`snd_service` refills row by row in the foreground.  The prepared
records are already-decoded fixed-size rows (`SND_ZTR_ROW_BYTES` = 162,
one 10-byte event slot per channel) - the 102 engine's consumer
contract.  No engine yet, no OS change.

## Files

Added:

- user/sdk/snd/src/snd_ztr.c - open/validate, the resident tables,
  the row producer and the queue, prepare/service/play/pause/resume/
  stop/close, status
- tests/snd/host/host_ztr.c - the producer's host build: drains the
  queue in the foreground and prints every decoded event (the
  oracle's `decode_row` text) plus one per-order row-record checksum
- tests/snd/host/include/kos.h - the host shim umbrella (the error
  codes the producer returns; the fixed-width types come from the ABI
  header through the include paths in Notes)
- docs/validation/2026-10-26-snd-ztr-load.md

Changed:

- user/sdk/include/kos/snd.h - the SND_ZTR_* API and the
  `snd_ztr_status` shape
- user/sdk/snd/src/snd_private.h - the shared producer/engine
  constants (queue, row and slot sizes, the channel/slot field
  layouts)
- user/sdk/exe.mk - snd_ztr.c in the libsnd build
- user/sdk/snd/src/snd_zvg.c - `snd_service` moved out to the ZTR
  arm (snd_ztr.c) and `zvg_refill` exported as `snd_zvg_refill`
- user/sdk/snd/src/snd_tick.asm - the ZTR arm of `_snd_tick`
  (ZVG/ZTR state gates and per-tick calls) beside the ZVG arm
- tests/snd/sndtest.c - the ztrload mode (opens, prepares, drains
  every order in the foreground, prints one checksum per order)
- tests/snd/oracle/ztr_trace.c - the `ZTR_ROWS_DUMP` hook (built with
  `-DZTR_ROWS_DUMP` by the oracle test) and a raised MAX_TICKS so the
  row dump covers every order of both songs
- UserSoftware/SNTracker/player.c - the same dump hook, test-only
- tests/test_snd_oracle.py - builds the oracle with the dump define
- docs/snd-sdk.md - section 6.2 (work-space and memory policy): the
  measured resident and largest-order figures
- work/101-snd-ztr-load/progress.md

## Results

- The producer's prepared rows equal the oracle's `decode_row` dump
  for both songs and every order: `host_ztr` output diffed against
  `ztr_trace SONG 0 --rows FILE` line by line - night-market 3,029
  events over 30 orders, RunawayCircuit 10,898 events over 136
  orders, identical.
- The card's resident records themselves agree with the host byte for
  byte: a spot check dumped the full 162-byte records of orders 4-6
  from both sides and diffed them - zero differing bytes.
- All 43 malformed `.ztr` fixtures are refused by `snd_ztr_open` on
  the host; the oracle's pinned outcome table passes
  (`tests.test_snd_oracle`, 9/9).
- `sndtest ztrload` on the card prints one checksum per order; it
  equals the host's for every order of both songs: night-market 30/30,
  RunawayCircuit 136/136, zero mismatches (target runs complete with
  `ztrload PASS`; RunawayCircuit drains all 136 orders in ~411M
  emulated steps).
- `make && make sdk` build; the image and sndtest.exe pack.

## Deferred to 102

- The `TestSndZtrLoad` class in tests/test_snd.py (the target
  ztrload checksum comparison as a pinned unittest, the counting
  reader's forward-pass proof, the short-read/error reader case).
- The ZVG regression `TestSndZvg.test_malformed_streams_refused_or_stopped`
  (`header-rate-high`); 102's STEER assigns the fix to that package.
- `snd_ztr_open` and one `snd_service` call T-state budgets (report
  figures).
- The KRES source variant (a `.KPR` with both songs) of the ztrload
  owner check.

## Notes

- The host shim's `uint16_t` is 32 bits (`abi/kos/types.h`); the host
  checksum must mask both the rotate and the add to 16 bits or the
  sums drift from the card's (the unmasked add surfaced as a one-bit
  difference at one order).  host_ztr.c masks both, so host and card
  agree byte for byte.
- `produce_row_record` zeroes the whole record: inactive channels'
  slots are fully defined, so the per-order checksums are
  deterministic across the card's reused queue memory.
- The host producer is built after `make` (it needs the SDK headers):
  `cc -O2 -DHOST_ZTR -D_BITS_STDINT_INTN_H -include build/kos-sdk-0.2.0/include/abi/kos/types.h -I tests/snd/host/include -I build/kos-sdk-0.2.0/include -I build/kos-sdk-0.2.0/include/abi -I user/sdk/snd/src -o tests/snd/host/host_ztr tests/snd/host/host_ztr.c`
  (`-include` puts the ABI types ahead of glibc's, and
  `_BITS_STDINT_INTN_H` keeps glibc from re-declaring them).
