# Validation - sntrack-view (package 104)

Date: 2026-10-28

## Scope

`sntview FILE.ZTR [ORDER]`: SN-Track's static GRAPHIC 6 screen
(`docs/sntrack-ui.md`) for one order and one 25-row page, drawn from the
song's own data. Space shows the next page (then the next order) through
a page flip; Q/Esc exits. No playback. No OS, libgfx or libsnd change.

## Files

New:

- UserSoftware/SNTracker/ztrdoc.c, ztrdoc.h - the read-only document:
  header and section checks, orders, the pattern directory (sorted once
  by channel/number, a per-channel index, direct-slot lookup with a
  binary-search fallback), instruments with their arpeggio and
  noise/duty macros' first value, every stream validated at open through
  one in-memory decoder and a 1,024-byte read window, instrument types
  (`T`/`N`/`M`), the per-order stream buffer, the per-row decode
- UserSoftware/SNTracker/view.c, view.h - the screen: palette, title bar,
  the three panels, channel headers (`M` on channels the order does not
  use), rows (middle-dot runs, then present fields), rules, status line,
  XOR highlights on the cursor row, the current order and instrument 00
- UserSoftware/SNTracker/sntview.c - the program: load, one message per
  refusal before `gfx_open`, draw, Space paging, exit
- tests/test_sntrack_view.py - a reference renderer of the spec, compared
  with the peer's VRAM pixel for pixel
- docs/sntrack-ui.md - the specification

Changed:

- UserSoftware/SNTracker/Makefile - `sntview` beside `sntrack`, `LIBS=gfx`
- UserSoftware/SNTracker/README.md - the `sntview` section

`sntrack` (the console player) is unchanged.

## Tests

`tests.test_sntrack_view`, 4 tests, about 40 s:

- Night Market: palette registers, page 0 of order 0, page 1 (rows
  19h-1Fh and blank rows), then order 1 page 0; Q restores the console
  (the ACQUIRE/DIRECT_INFO/RELEASE sequence, registers and palette);
- RunawayCircuit from order 4: the order window starts at 4;
- a synthetic 64-row song: OFF, release, legato, effects 1-6, modifiers
  (not shown), absent fields, instrument types T/N/M, N shown (white with
  a relative arpeggio, a fixed arpeggio) and blank (a delayed macro, no
  instrument); from order 3, pages 00/19h/32h, then order 4 scrolls the
  order window;
- refusals: an instrument on tone and noise channels, an order over 1,024
  stream bytes, a truncated file: each prints its message and the display
  is never acquired.

Every page switch's R#2 write lands inside the retrace.

## Budgets (CPU T-states, simulator)

| figure | measured | target |
|---|---|---|
| `ztrdoc_open`, RunawayCircuit | 83,630,021 (66,300,143 in the reader, 150 calls) | report |
| one order's load | 1,305,101-1,733,657 | report |
| one pattern row | 2,840 (past the end) - 171,186 (dense) | report |
| full viewport (`view_draw_page`) | 2,788,236-5,534,110 | <= 6,000,000 |
| OS bytes | 0 | 0 |

`sntview.exe`: image 32,352 bytes, BSS 19,643.

## Validation

```text
make && make sdk                                   ok
make -C UserSoftware/SNTracker test                FAIL (1): test_sound_api
make clean && make check                           FAIL (4 of 1004, 119 skipped)
git diff --check                                   ok
```

All five failures predate this package and come from HEAD (`04a65b6`,
`8dc1af2`), which changed only player and HID code:

- `test_sound_api.test_empty_console_poll_idles_until_an_interrupt`:
  greps `sntracker.c` for the poll line `04a65b6` rewrote;
- `test_hid.test_stuck_penalty_applied_and_cleared`: greps `hid.c` for the
  backoff line `8dc1af2` rewrote;
- `test_iocfat.test_packed_driver_keeps_the_hot_tier_room`,
  `test_pack_image.test_ledger_lines_match_the_built_image`,
  `test_sound.test_the_driver_tier_keeps_its_reserve`: the driver hot tier
  has 1,500 bytes free against its 1,536-byte reserve after `8dc1af2`'s HID
  backoff.

In the same `make check` run, `test_sntrack_view` (4) and
`test_snd.test_sntrack_plays_both_songs_clean_and_on_tempo` pass.

## Owner checklist

PENDING (board): `sntview /fs/night-market.ztr` and
`sntview /fs/RunawayCircuit.ztr 4`: the layout matches the mockup; on
Space the next page appears all at once; Q returns to the shell.
