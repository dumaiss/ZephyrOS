# Current-State Architecture Conformance Review

**Review date:** 2026-10-04  
**Architecture baseline:** `docs/architecture.md`, implemented through M8  
**Implementation baseline:** current ZephyrOS tree after accepted M8 closure

## Executive summary

The current implementation is substantially conformant with the architecture
through M8. This review accepts M1-M8 closure and the operator's report that
the tests were run and the hardware boots. It does not re-grade individual
milestones.

No P0 correctness/corruption issue was found. The runtime architecture is
intact: memory and transition ownership, IM2/IRQ handling, transactional ZMOD
loading, ROMFS, ZEX/process isolation, driver ABI v2, IOC/HID/V9958 ownership,
console fallback, boot order, and monitor launch all match the current
architecture.

The review found two interface-boundary deviations, one production/test
separation deviation, one repository-evidence deviation, and stale normative
documentation. They do not contradict the accepted working M8 behavior, but
they make the next change harder to implement safely. Four narrow corrective
packages were created; none has been implemented by this review.

## Dependency violations

### P1: HID depends on an IOC-private header

`drivers/hid/hid.c` includes `ioc_proto.h`, while
`drivers/ioc/ioc_proto.h` declares itself private. The global module flags in
the Makefile add `drivers/ioc` to every module include path, and the HID build
rule explicitly depends on that private file. HID's runtime edge is correct --
it discovers `ZDEV_IOC` and uses `zioc_ops`, with no raw SIO access -- but its
compile-time edge crosses a sibling driver's private boundary. This is likely
to cause future errors as storage and other IOC clients arrive.

Correction: `work/21-public-ioc-client-contract/WORK.md`.

### P1: module-facing headers expose kernel-only mechanisms

`driver.h` includes broad `device.h` and `irq.h` headers. Their include closure
publishes registry initialization/checkpoint/rollback/owner controls, IRQ
registry lifecycle and locking, platform hooks, and diagnostics to module
source. `platform.h` also combines declarative board constants with raw memory
latch/bank primitives, and several module files include it without using a
platform item. Current packed modules do not import the forbidden kernel
functions, and the packer rejects unresolved imports, so this is an interface
and enforcement problem rather than observed runtime misuse.

Correction: `work/22-module-facing-header-boundary/WORK.md`.

## Ambiguous ownership

### P2: acceptance-only CTC controls are owned and linked by production

`drivers/ctc/ctc.c` defines `platform_ctc0_test_start()` and
`platform_ctc0_stop()`, and `irq.h` labels them acceptance hooks. Their uses are
test paths, yet the production map contains both symbols because the CTC source
is always linked. The same file exports unused `platform_irq_vector()`.
Production legitimately needs only CTC quiesce from this source. This conflicts
with the architecture's statement that production map checking rejects every
acceptance symbol.

Correction: `work/23-production-test-boundary/WORK.md`.

## Duplicate or obsolete mechanisms

No competing runtime mechanism was found for banking, device discovery,
console I/O, ROMFS access, module loading, IRQ registration, or process launch.
The unused `platform_irq_vector()` function and duplicate target self-test
declaration in the public syscall header are obsolete surface area covered by
package 23.

## Weak interfaces

The two P1 findings above are the weak interfaces: a private IOC vocabulary is
being used as a cross-driver contract, and module-facing headers expose more
kernel machinery than `zdriver_api` permits. The running code still honors the
intended interfaces.

## Build/configuration issues

### P2: referenced validation evidence is ignored

`.gitignore` ignores `docs/validation/`. M1 and M2 records were already tracked
before that rule, but the architecture-linked M3-M8 records and transcripts
are locally present and untracked. A clean clone therefore loses files cited by
the architecture, including the integrated M8 record. This is a repository
reproducibility defect, not a rejection of the evidence or milestone closure.

### P3: current normative docs retain historical values

`docs/module-format.md` calls itself authoritative while stating a current
`required_granules` range of `1..16` and labeling module initialization as
driver API v1. The implementation and architecture correctly use ABI v2, an
80-granule format ceiling, and the smaller live bound derived from the linked
arena. `docs/boot.md` also combines the current 512-KiB image with historical
M0 claims that boot terminates after the banner and never enables interrupts.

Correction for both documentation/evidence findings:
`work/24-current-docs-evidence-alignment/WORK.md`.

## Mechanically enforceable rules

The correction packages require checks that:

- reject a production driver's dependency on a sibling driver's private path;
- keep kernel mutation/locking/banking declarations out of module-facing
  header closure;
- reject CTC test helpers and target-test runners in production maps/headers;
- require every validation record cited by tracked live documentation to exist
  and be tracked.

The existing linker, packer, map, source-layout, and artifact checks remain the
preferred enforcement mechanisms.

## Conforming current-state areas

- `platform/zephyr80/` is declarative; executable behavior has an explicit
  boot, kernel, driver, module-runtime, test, or user owner.
- Mode 10/11 transitions, page zero, common gates/stacks, bank-7 placement, the
  IM2 page, ISR stack, and mirrored ROM-access stub match the memory contract.
- Raw device I/O resides with the owning SIO, IOC, V9958, CTC, or early-console
  implementation. HID uses semantic IOC status and has no raw SIO dependency.
- Device registry selection, class/capability interfaces, driver ABI v2, ZMOD
  validation/relocation, allocation, and exact failed-init rollback match the
  architecture.
- ROMFS access is bounded and the production recovery store contains the four
  boot ZMODs, V9958 font, and monitor in the intended order.
- ZEX loading and process restoration preserve kernel ownership. The native
  monitor uses syscall/runtime interfaces rather than kernel or driver
  internals.
- Production boot loads `sio`, `ioc`, `hid`, then `v9958`, binds the console
  once with independent direction fallback, and launches the unchanged
  monitor. Deferred FAT, writable filesystem, shell, service-manager, and
  multiprocess features are absent.

## Validation evidence

The supervisor ran `make check` on the reviewed source. It completed with 604
tests and no failures; 183 tests were skipped because optional historical
acceptance artifacts were not built by that clean production run. These skips
do not reopen accepted milestones. Production map checking passed with 17
areas and 241 symbols. The linked static kernel ended at `5D6Eh`; the derived
driver arena was `5E00h-BFFFh` (49 granules), with 21 used by the M8 boot set
and 28 free. The production and MAME images were identical with SHA-256:

```text
16307e15dfe5794c4a6987deddd540bc5b62af54fe1fbd173302d443a96706eb
```

The production ZMOD hashes matched the accepted M8 records:

```text
sio.zmod     bf9a638517488b72e1621c495f098905f73e157fd20dcc9467d465298786877d
ioc.zmod     808b6d5e986b7abbc06b943264a8ef277b60b9f288d5ebb66b5e186a27d77ca3
hid.zmod     bd7e3933f669f544e6d5b9fb3f1ff6670d773545041545a8fa7619915193ef11
v9958.zmod   6d35c218ff2c8f65b58bd2cdfbe0c5db5bc7302a4827074d062933d62f8897c8
```

The test run emitted Python resource warnings for unclosed host-side files;
they did not fail validation and are test-tool hygiene rather than an M8
architecture deviation. The source worktree remained clean after validation.

## Recommended cleanup packages

Dispatch exactly one package at a time in this order:

1. `work/21-public-ioc-client-contract/WORK.md` -- close the immediate
   cross-driver private dependency before adding another IOC client.
2. `work/22-module-facing-header-boundary/WORK.md` -- make the allowed ZMOD
   compile surface match ABI v2.
3. `work/23-production-test-boundary/WORK.md` -- relocate acceptance-only CTC
   code and strengthen production symbol checks; repeat hardware gates if
   linked bytes change.
4. `work/24-current-docs-evidence-alignment/WORK.md` -- reconcile current
   normative docs and make cited evidence durable.

The tree should not be called strictly architecture-conformant until these
packages are completed and reviewed. It is, however, behaviorally conformant
at the accepted M8 runtime boundary based on the evidence above.
