# M10 two-bank feasibility (package 36): measurement report

Date: 2026-10-07.  Work package:
[WORK.md](../../work/36-m10-two-bank-feasibility/WORK.md).

Question: **can ZephyrOS stay within two banks** (bank 7 the nucleus, bank 6
the resident services, plus the existing common region) under the
resident-service architecture, at the revision-13 window's **`6000h`
split** (16 KiB fixed core `2000h-5FFFh`, 32 KiB window `6000h-DFFFh`)?
Bank 6's out-of-window space (`0000h-5FFFh` + `E000h-FFFFh`, 32 KiB) is
evaluated as boot-code and bulk-data space.

Scope (correction-01): **transport A at the `6000h` split only**.  No
transport-B evaluation and no new `8000h` measurements; the baseline is
package 35's measured `8000h` figures (its report §4-§6 for the cycles and
stacks, §7/§8 for the resident ledgers), quoted here.

Baseline (package 35's geometry: a 24 KiB window at `8000h`): the hot
service set measured here, 26,267 bytes, is 1,691 bytes over that window —
the wider `6000h` window is what this package measures.

Images built and measured (all test-only sources; production unchanged):

| image | configuration |
|---|---|
| `build-rsvc-spike-6000/zephyros-rsvc-spike.bin` | `ZOS_RSVC_SPIKE=1 ZOS_RSVC_SPLIT=6000` (transport A, 32 KiB window) |

## 1. Result and verdict

**It boots, and two banks fit at `6000h` — with one named change to absorb
the top of the M10 estimate.**

- The resident-service spike boots at the `6000h` split under the
  revision-13c decoder and reports **`rsvc: 49/49 checks` / `rsvc: PASS`**.
  The null call is **9,857.7 T** and a 512-byte chained read **84,786.9 T**,
  i.e. within 1 T-state of package 35's `8000h` measurements (9,858 /
  84,787); every phase, every stack high-water mark and every evidence
  counter is bit-for-bit the package-35 result (§7).
- **Verdict (b):** the *measured* fixed core under the two-bank
  classification is **15,079 of 16,384 bytes** (13,336 code + 975 data +
  768 stacks), leaving **1,305 bytes**.  The package-33 M10 mechanisms
  add **600-1,480 bytes** on the fixed side (estimate range), leaving
  **+705 bytes at the low bound and -175 bytes at the high bound**.  One
  named change closes the high bound with room to spare: moving the
  process-exit notification into a fixed shim makes `process` cold
  (**972 bytes measured**), or splitting the ROMFS reader's
  directory/resource entry points behind a fixed copy primitive
  (**700 bytes, estimate**).  Without either change the design fits if
  the M10 mechanisms land at or below **1,305 bytes** of fixed cost.
- The `6000h` window is what makes the service bank fit: the hot service
  set is **26,267 bytes**, which fits the 32 KiB window with **6,501
  bytes** to spare.  (Baseline: the same set is 1,691 bytes over a 24 KiB
  window.)
- The GAL fits, with the `RAM_A16` budget **exactly consumed**: the
  `6000h` window needs **10/10/10 product terms** against the 22V10's
  10/12/14 budgets, and WinCUPL compiles and simulates the committed
  candidate clean in that exact minimum form (all 2,101 vectors pass;
  §6).  Because `RAM_A16` has no headroom left, the **mode-10 far
  aperture cannot be added to the `6000h` split** (it needs 12 terms on
  RAM_A16 with the required P = 0 gate); it still fits package 35's
  `8000h` window (10/10/10, quoted).  This is a real cost of the wider
  window and belongs in the phase-0 record.
- Time and half of the cold ledger are not constraints: the cold half is
  **3,548 bytes of 32,768**, and the out-of-window service tier is
  **4,005 bytes of 32,768**.

The `6000h` split therefore buys the service bank 8 KiB of window at the
cost of the far aperture and of a 16 KiB fixed core that the M10 estimate
can just exceed.  Both are decision inputs, not blockers.

## 2. The two-bank classification

`tests/m10/two-bank-classification.json` reclassifies every kernel object
linked into the resident-service build plus the package-35 substrate into
exactly one tier, with a reason per object.  Measured sizes come from the
build's object files (`tools/rev13_layout.py --two-bank`); the M10 rows are
tagged estimates from the package-33 corrected table
(`docs/validation/2026-10-05-m9-reclaim-audit.md` §6).

| tier | objects | code | data | placement |
|---|---:|---:|---:|---|
| `fixed` | 27 (minus 2 test/synthetic) | 13,336 | 975 | bank-7 fixed core `2000h-5FFFh` |
| `cold` | 4 (`syscall`, `diag`, `diag_io`, `main`) | 3,526 | 22 | bank-7 window half (`P = 0`) |
| `service` | 11 (8 `vfs_*`, `romfs_provider`, `console`, + the synthetic blobs) | 10,824 | 1,277 | bank 6 |
| `retired` | 2 (`fs`, `registry`) | 4,043 | 308 | not counted |

Stacks: the ISR stack (**256**) and the **512-byte service stack** are
placed in the fixed core (not common) per the package requirements.

The classification's notable moves versus package 34's window evaluation:

- **`process` and `process_exec` become fixed** (they were cold): the
  process-exit notification and the executable-stream read are nucleus →
  VFS upcalls, and any nucleus code that calls a service must stay visible
  while the window shows bank 6.
- **`romfs` (the reader) becomes fixed**: it is the bootstrap-reader
  primitive the provider service calls while bank 6 is mapped (2,767 code
  + 7 data measured).
- **`syscall`, `diag`, `diag_io` become cold**: the common syscall gate
  clears the page field before dispatching (`and BANK_MASK; or OS_MODE`),
  so the dispatcher only ever runs with P = 0; a `6000h` build cannot hold
  it in 16 KiB otherwise.
- **`console` moves to the service bank**; **`registry` is retired** in
  favour of the endpoint table; **`fs` is retired** in favour of IPC
  dispatch.

Common-resident objects (`banking`, `user_copy`, `rom_access`, `start`,
`panic`, `early_console`, `platform_irq`, `process_launch`, `irq_entry`,
`irq_vectors`, `page_zero`, `reset`) are classified fixed and measured
**0 bytes in the bank-7 areas**; their 1,285 code + 694 data live in the
common ledger (M9 usage 2,488 of the 2,560-byte limit).

## 3. The fixed core (requirement 2)

```
two-bank fixed 6000h: 13336 code + 975 data + 768 stacks = 15079 / 16384 bytes, room 1305
                      M10 estimates +600..+1480 -> room -175..+705
```

The `6000h` split holds the classified fixed core with 1,305 bytes to
spare, and it is tight only against the top of the M10 estimate.  **The
smallest set of
changes that brings the `6000h` fixed core under 16 KiB for the whole
estimate range** (each is a single change, ranked by bytes freed):

| # | change | bytes freed | tag |
|---|---|---:|---|
| 1 | split the ROMFS reader: keep only the provider-called read/lookup primitive fixed, move the directory/resource entry points behind a fixed copy primitive | 700 | estimate (`romfs_entry_at` 326 + `romfs_resource_*` 420 measured, minus the wrapper) |
| 2 | move the process-exit notification into a fixed shim so `process` becomes cold | **972** | measured |
| 3 | move the executable-stream upcall into a fixed shim so `process_exec` becomes cold | 1,730 | measured |
| 4 | route the loader's service call through a fixed shim so `module_loader` + `module_relocate` become cold | 3,744 | measured |

Change 1 alone closes the -175-byte high-bound gap with 525 bytes to spare;
change 2, the smallest *measured* one, closes it with 797 bytes to spare.
Nothing else in the fixed tier can move without breaking the
"visible while bank 6 is mapped" rule: the IRQ executive, the IPC
substrate, the gates, the ROMFS primitive, the loader and the process
notification are all on the service-call path.

The classified-versus-linked detail is in §7; the tool prints it on every
run.

## 4. The cold half

```
two-bank cold 6000h: 3526 code + 22 data = 3548 / 32768 bytes (window half), room 29220
```

With the M10 cold estimates (970-1,710 code + 96-192 data: xmem, the
far-entry table and `SYS_FAR_CALL` gate, segment info) the cold half uses
**4,614-5,450 bytes**: 27.3-28.2 KiB free.  The window half is not a
constraint; the `6000h` split's extra 8 KiB is for the *service bank*, not
the cold nucleus.

## 5. The service bank (requirement 3)

```
service bank: window hot 24990 code + 1277 data + 0 service stacks = 26267 / 32768
service bank: out-of-window boot 1957 code + 2048 bulk data = 4005 / 32768
```

The window ledger's `service stacks` item is **0**: the 512-byte service
stack and the ISR stack are counted once, in the fixed core (requirement
1).  If a phase-0 design instead places the service stack in the service
window, add 512 bytes to the window figure (26,779 of 32,768; still
6,501-512 = 5,989 bytes free).

### 5.1 Drivers, hot versus boot-only (from symbol sizes)

Each module's `.sym` tables give per-symbol spans; the asm-only object
(`ioc_io`) is measured from the module report's exported symbols.  The
boot-only set is the bring-up path — init, probing, the V9958 font/atlas
upload, IOC-FAT CAPS/mount, registration — named in
`tests/m10/two-bank-classification.json` (`service_modules`), which the
layout tool validates against the build.

| module | hot | boot | total |
|---|---:|---:|---:|
| `sio` | 232 | 96 | 328 |
| `hid` | 733 | 246 | 979 |
| `ioc` | 3,435 | 276 | 3,711 |
| `v9958` | 3,613 | 849 | 4,462 |
| `iocfat` | 6,153 | 490 | 6,643 |
| **total** | **14,166** | **1,957** | **16,123** |

Measured boot symbols include `_sio0b_hw_init`/`_sio_module_init`,
`_hid_driver_init`/`_hid_module_init`, `_ioc_hw_init` +
`_ioc_link_bringup` + `_ioc_io_bulk_init` (53 bytes, from the module link
map), the whole V9958 G6/palette/font-atlas chain
(`_v9958_init_g6` 98, `_v9958_init_palette` 64,
`_v9958_upload_font_atlas` 52, `_v9958_upload_atlas_chunk` 247,
`_v9958_init_display` 40, ...), and `_iocfat_init` 309 +
`_iocfat_mount` 140 + `_iocfat_reset` 13 + `_iocfat_zero_instance` 21.

Recorded caveat: `v9958_init_display` and its upload chain are also
reachable from a *runtime* display reset (ESC `c`, RIS, `ZVIDEO_RESET`).
The tier treats them as boot-bring-up (the work package names the font
and atlas upload as boot-only); a production design must either keep that
path reachable or reload through the boot loader.

### 5.2 VFS service, structural slimming only

Today's VFS stack (measured from the build's objects):

```
members (service):  vfs_dir 1576, vfs_file 2484, vfs_mount 2233,
                    vfs_mounts 55, vfs_mutate 553, vfs_path 739,
                    vfs_process 1780, vfs_workspace 512,
                    romfs_provider 1563
                    = 10220 code + 1275 data = 11495 bytes
- retired fs:       2727 (IPC dispatch replaces the syscall front end)
- reader:           romfs 2767 code + 7 data = 2774 stays in the nucleus as
                    the bootstrap-reader primitive the provider calls
```

Package 35 counted 17,115 bytes for `name` + `fs` + reader + provider +
`vfs_*`; the two-bank classification also moves `name` (119) into the
nucleus (the fixed reader calls it), which is why the member total here is
11,495 and the nucleus primitive is 2,774.

Speculative SDCC-idiom savings are **excluded** from the figures above and
reported separately, labeled estimate: **574-1,149 bytes** (5-10 % of the
measured service-VFS bytes; a planning placeholder for a phase-0 idiom
pass, not a measurement).

### 5.3 Ledger

| tier | size | capacity | room |
|---|---:|---:|---:|
| window hot (drivers hot 14,166 + VFS 11,495 + console 606) | 26,267 | 32,768 | 6,501 |
| out-of-window: boot-only drivers 1,957 + V9958 font 2,048 (bulk) | 4,005 | 32,768 | 28,763 |

The driver BSS (1,237 bytes: `sio` 4, `hid` 24, `ioc` 112, `v9958` 460,
`iocfat` 637) is runtime state and sits in the hot window figure.  The one
bulk service datum is the ROMFS font resource (2,048 bytes), which the
out-of-window tier can hold and feed through a nucleus copy.

## 6. GAL fit (requirement 4)

`tools/pld_terms.py` now derives the `6000h` variants by exact two-level
minimisation over the whole input space:

```
variant                      RAM_A16  RAM_A17  RAM_A18  fit (10/12/14)
window6000                  10       10       10       yes
window6000+gated-aperture   12       12       12       NO  (RAM_A16 over by 2)
window6000+ungated-aperture  9        9        9       yes (invalid: breaks P=0)
```

Baseline (package 35, quoted): the `8000h` window alone needs 8/8/8 and
7/7/7 ungated with the aperture, 10/10/10 in the gated form.

Findings:

- The `6000h` window needs **10/10/10** — the RAM_A16 budget exactly.
- A **mode-10 far aperture** (region `8000h-BFFFh`; `8000h-9FFFh` is worse
  at 13 terms) needs **12 terms on RAM_A16** once it is correctly gated on
  a non-zero page field, i.e. it does **not fit** the 22V10 alongside the
  `6000h` window.  Package 35's `7/7/7` count for its `window+aperture` is
  the *ungated* form (page 0 would show bank 7 in mode 10, breaking "P = 0
  is revision 12" in a region every application uses).  **Adopting `6000h`
  therefore retires the far aperture**: M10 far access must keep the
  package-33 `SYS_FAR_CALL` gate machinery (whose cost is in the M10
  estimate rows, cold tier).
- The `6000h` variant is committed as a PLD for the owner to program if
  adopted: `platform/zephyr80/hdl/MEM_DECODER_rev13c.pld` with 2,101
  vectors in `MEM_DECODER_rev13c.si`, generated by `tools/rev13_vectors.py`
  from the same truth table the simulator model is checked against.  It is
  **not programmed**; revision 13 (`8000h`) remains the board's decoder and
  revision 12 the simulator default.
- The simulator's `MemoryDecoder` takes a `window_base` parameter
  (`8000h` default, `6000h` opt-in) and is checked against every
  revision-13c vector in `tests/test_decoder_rev13.py`.
- **Vendor check.**  With WinCUPL available (`tools/wincupl_build.sh`
  drives CUPL and CSIM through wine), the committed candidate compiles and
  simulates clean: all 2,101 vectors pass, and the compiler reports no
  error.  The factored equations (`WIN` / `FORCE_B7`, as revision 13 is
  written) need 11-12 terms on `RAM_A16` and are *refused*
  (`excessive number of product terms: RAM_A16`), so
  `MEM_DECODER_rev13c.pld` carries the exact minimum form printed by
  `tools/pld_terms.py --equations window6000`.  `tools/pld_terms.py
  --check-pld` proves the committed equations are that minimum; it runs in
  `make rev13c-pld` and in `tests/test_decoder_rev13.py`, so the file and
  the generator cannot drift.  The 10-term budget is therefore not just a
  counting argument: the part fits, exactly, in the only form that
  compiles.

## 7. Does it boot at `6000h` (requirement 5)

`make rsvc-spike-selftest ZOS_RSVC_SPLIT=6000` builds transport A in
`build-rsvc-spike-6000/` and replays it under the `6000h` decoder.

- The client prints **`rsvc: 49/49 checks`** and **`rsvc: PASS`**; the
  evidence block reports `calls 624 nested 4`, `irq 1/2`, `fast 200
  refused 1/1 forged 2 capfail 1`, byte-identical to package 35.
- Cycles against package 35 (§4 of its report), measured from the same
  marker/MARGIN replay:

| phase | `6000h` | package 35 (`8000h`) |
|---|---:|---:|
| null call (8/16/32-byte frame) | 9,857.7-9,929.9 T | 9,858 T |
| 256-byte `con.WRITE` | 129,259.7 T (505 T/B) | 129,260 T |
| 512-byte chained read (direct) | 84,786.9 T (165.6 T/B) | 84,787 T |
| 512-byte chained read (staged) | 110,986.7 T | 110,987 T |
| today's direct `FS_READ` | 300,952.2 T | 300,952 T |
| IRQ delivery / handler | 924 T / 196 T | 937 T / 196 T |
| stacks high-water (service/gate/ISR) | 278 of 384 / 87 of 256 / 15 of 256 | same |

  The IRQ delivery is 13 T-states *lower* than package 35's figure because
  of the fix below; the handler cost is identical.
- The spike needs one test-only correction to boot at `6000h`:
  `rsvc_irq_trampoline` called `rsvc_domain_enter`/`_exit`, which clobber
  the **single-depth saved latch** of the service call the IRQ interrupts.
  At `8000h` the stale restore is harmless (everything executed after the
  call returns is fixed/common-resident); at `6000h` the classification
  puts the syscall dispatcher in the window, so the stale page-1 mapping
  hid it and the image faulted.  The trampoline now uses
  `rsvc_domain_set` only and leaves the latch to the IRQ entry, which
  already restores it exactly (`irq_saved_latch`).
  Note (outside this package's scope, measured before correction-01
  arrived): the fix is in the shared spike source, so the package-35
  images' IRQ-delivery figure moves from 937 T to 924 T; every other
  package-35 number is unchanged.
- **Linked fixed-core end: `518Ah`** (12,682 bytes of the 16,384-byte
  fixed region, i.e. `2000h-518Ah` loadable plus the derived data area),
  ISR stack `5F00h-6000h`, runtime data 1,093 bytes at `5A00h`, arena
  **4 granules** (1 boot, 3 free).
- **Classified versus linked fixed core**: classified 15,079 bytes;
  linked 14,218 bytes (`kernel_code_end - 2000h` + data area + ISR stack),
  i.e. **-861 bytes**.  The difference is the placement the existing code
  cannot follow:

  * classified fixed but still linked cold: `process` 972,
    `process_exec` 1,730, `romfs` 2,774 (5,476 bytes) — these must move
    into the fixed region in the production design, which is exactly the
    over-subscription in §3;
  * linked fixed but classified elsewhere: `console` 606 (service),
    `registry` 1,624 (retired), the six synthetic containers 2,637
    (service), `diag_io` 14 (cold; the assembler object cannot be compiled
    into `_WINDOW` without touching its source, so it stayed where it
    links) — 4,881 bytes;
  * the spike's 384-byte service stack is still in common (the design
    places a 512-byte stack in the fixed core), and the link uses a
    16-byte code base offset (`_CODE = 2010h`) and one granule of data
    alignment slack.

  The core still **boots** at `6000h` because the package-35 placement
  (with the syscall-side objects moved to the window) is what the image
  links; the classified placement is the target of the phase-0 work, not
  of this spike.

## 8. What this spike does not prove

- No real driver or VFS migration: the service ledger is a *projection*
  from measured module and object sizes, not a linked service bank image.
- The M10 mechanism rows are package-33 estimates, not measurements.
- The IRQ claim rests on the simulator's CTC0 stand-in, as in package 35;
  hardware would be authoritative, and the `6000h` decoder variant is not
  programmed.
- The reader split, shims and idiom savings are named, sized *estimates*
  for the phase-0 pass; no code was rewritten for size.
- The classification's tier boundaries are per object; a production
  implementation will split some objects (for example `syscall` bodies
  between cold and retired) more finely.

## 9. Validation

Formal batch, run 2026-10-07:

```sh
make clean && make check
make rsvc-spike-selftest ZOS_RSVC_SPLIT=6000
python3 -m unittest tests.test_decoder_rev13 tests.test_rsvc_spike \
                     tests.test_rsvc_spike_sim -v
git diff --check
```

Results:

- `make clean && make check` — **green**, 2 m 44 s (re-run after the test
  fix below: 2 m 16 s, same result).  The
  reproducible-rebuild step reports the production image SHA-256
  `f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7` for
  both `build/zephyros.bin` and `build/zephyr80.bin` (`cmp` equal),
  byte-identical to packages 33-35; `check-fast` runs the host suite
  (883 tests, OK, 246 skipped — the same skips as before) plus mapcheck
  and pack_image.  The simulator default stays revision 12.
- `make rsvc-spike-selftest ZOS_RSVC_SPLIT=6000` — **green**, 33 s: builds
  transport A at the split (`build-rsvc-spike-6000/zephyros-rsvc-spike.bin`,
  SHA-256 `c6cddc2a934ad09ec47f4f1115a06fcd4a8b5ea74b595fcfe12504f6f642cfa8`),
  runs the two-bank layout report
  (`build-rsvc-spike-6000/two-bank-layout.json`) and the replay suite:
  39 tests OK (28 skipped — the classes whose images belong to the
  package-35 pair; the `6000h` class runs).  The image prints
  `rsvc: 49/49 checks` / `rsvc: PASS`.
- `python3 -m unittest tests.test_decoder_rev13 tests.test_rsvc_spike
  tests.test_rsvc_spike_sim -v` — **green**, 1 m 58 s, 100 tests OK:
  decoder 36 (13/13b/13c vectors, models, the minimum-cover check), spike
  host checks 25, replays 39 (the `6000h` class adds the fixed-core,
  ISR-stack and syscall-window-residency checks).
- `git diff --check` — clean.

Extra commands (not in the package's validation list; run because WinCUPL
became available in this environment during the work):

- `make rev13c-pld` — **green**, 24 s: vector check, term table, minimum
  cover check, and a WinCUPL compile + simulate of the `6000h` candidate
  into `build-rev13-eval/hdl/window6000/` (JED, CSIM listing, no
  `[NNNNsa]` diagnostics).
- `make rev13-pld` — **green**: revision 13 compiles and simulates; the
  revision-12 cross-check is *skipped* here because the configured
  reference path (`$ZOS_ZEPHYR80_REF/Code/HDL/WinCUPL/src/MEM_DECODER.pld`)
  now holds the revision-13 design — its `Revision` field says 13, and the
  revision-12 file sits beside it as `MEM_DECODER.pld.bak`.  Pointing the
  variable at that file
  (`make rev13-pld ZOS_REV12_PLD=…/MEM_DECODER.pld.bak`) runs the full
  cross-check, **green**: both designs compile and simulate, and revision
  13 matches revision 12 on all 311 equivalence vectors.
- Fixed while verifying: `tools/wincupl_build.sh` overwrote a
  caller-supplied `SI_FILE` with the revision-13 vector path, so variant
  designs were being simulated against the wrong vectors; the script now
  honours the caller's `SI_FILE`, and the
  revision-12 leg first checks that the reference file really is revision
  12 and skips with a message (exit 3) instead of failing on a different
  design.
- Fixed in the batch: the `6000h` replay's fixed-core check asserted
  `irq_isr_stack_top < 6000h`; the symbol is the split address itself
  (the ISR stack is `5F00h-6000h`), so the test now asserts the boundary
  exactly.

Wall clock: the batch is 5 m 15 s in total (2 m 44 s + 33 s + 1 m 58 s);
rebuilding the `6000h` artifacts for the worktree takes 1 m 4 s, the extra
PLD targets add 24 s plus a sub-minute run, and the final `make check`
re-run is 2 m 16 s — everything is inside the 15-minute target.
`tests/m10/rev13-classification.json` and the package-34 target are
untouched apart from the shared mapcheck rule for the `6000h` split
(the syscall dispatcher is a *window* residency assertion there, not a
relaxation: it must sit in `6000h-DFFFh`).

## 10. Hardware

**PENDING (spike):** the revision-13c PLD is committed but not programmed;
no hardware run of the `6000h` image is recorded.  If the owner programs
the variant, `build-rsvc-spike-6000/zephyros-rsvc-spike.bin` is the image
to run, and it should print `rsvc: PASS` on SIO0/B with the same cycle
counts as the simulator replay.  The design can be re-verified on the
owner's machine with `make rev13c-pld` (WinCUPL optional: without it the
committed vectors are still checked against the generator and the
equations against the term minimiser).

## Supervisor review (2026-10-07)

**Accepted.** The evidence is consistent:

- The production hash `f4da0496…` and the spike hash `c6cddc2a…` match the
  artifacts in the tree.
- `git diff --check` is clean.
- The ledger arithmetic checks out (15,079 = 13,336 + 975 + 768; the hot
  set 26,267 = 14,166 + 11,495 + 606).
- WinCUPL independently confirms the 10-term fit.

No rebuild was needed. Notes for the phase-0 record:

1. **The fixed-tier rule in the contract was too strict (supervisor
   error).** The rule should be: *fixed = code that executes, or data that
   is touched, while P ≠ 0.* Nucleus code that *calls* a service only needs
   a fixed upcall shim, because the caller is not executing while the
   window shows bank 6. Changes 2-4 in §3 are therefore the normal design,
   not an emergency measure:
   - `process` 972, `process_exec` 1,730 and `module_loader` +
     `module_relocate` 3,744 (6,446 measured) become cold;
   - the fixed core is about 8.6 KiB plus the shims and the M10 fixed
     rows, which leaves roughly 6 KiB of room at `6000h`.
   
   Constraint: buffers that a service reaches through descriptors must not
   be in bank 7's window half.
2. **GAL: correction to package 35.** The legal (gated) mode-10 aperture
   needs 10/10/10 terms at `8000h`, which exactly fills `RAM_A16`. Package
   35's 7/7/7 figure was for the ungated form, which is not a legal
   decoder. At `6000h` the window alone fills `RAM_A16`, so the split
   choice also decides the far aperture. This needs an owner decision.
3. **IRQ path:** the trampoline bug (it clobbered the single-depth saved
   latch) becomes a design rule: IRQ delivery into a service must not
   disturb the latch saved by the interrupted call. Package 35's
   IRQ-delivery figure is now 924 T.
4. **V9958 runtime reset** (ESC `c`, RIS, `ZVIDEO_RESET`) reaches code
   classified boot-only. Either keep that path in the window or reload it.
5. **The arena floor (16 for acceptance, 32 for production) is obsolete**
   under the service model, because modules live in bank 6. The bank-7
   arena at `6000h` is 4 granules. Re-state the floor in phase 0.
6. **Bank 6 is underused:** the out-of-window tier holds 4,005 of 32,768
   bytes. It is the reserve for bulk service data (the file cache,
   buffers) and boot code.
7. Minor: the driver "hot/boot" figures include BSS (1,237 bytes) under
   the `code` label.

### Supervisor follow-up (2026-10-07): output polarity

The §6 finding that the mode-10 aperture cannot be added at `6000h` holds
only in true polarity. The 22V10's output polarity fuse allows each
`RAM_A1x` to be written as its complement (`!RAM_A1x = ...`), which is
cheaper for every variant (`tools/pld_terms.py` now prints both
polarities). In inverted form:

- the `6000h` window alone needs 6/6/6;
- the window plus the gated aperture needs 9/9/9 against 10/12/14.

`platform/zephyr80/hdl/MEM_DECODER_rev13d.pld` is that design: the `6000h`
split plus the aperture at `8000h-BFFFh`, with no board change beyond
revision 13. Checks:

- `make rev13d-pld` passes: vectors current, exact minimum cover;
- WinCUPL compiles and simulates it with 9/9/9 terms used and no errors;
- an independent replay of the equations matches all 2,064 vectors.

It is not programmed. Adopting `6000h` therefore no longer retires the far
aperture.
