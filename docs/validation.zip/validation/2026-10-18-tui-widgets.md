# TUI widgets: validation

## Result

`user/sdk/include/tui_widgets.h` and the deterministic
`libtui_widgets.lib` archive implement the architecture's procedural widget
surface: status bar, menu bar, label, button, input, checkbox, list box, menu
run and input run, plus non-reentrant message and confirmation boxes.  The
archive depends only on public `tui.h` calls and its own private helpers; it
contains no terminal sequence, CP850 constant, OS call, heap allocation,
object model or cell-map access.

Render-only controls own only their cells.  `tui_menubar` treats `selected` as
an in/out item ID and highlights the matching ID.  `tui_menu_run` starts on
the first item and returns its ID or `TUI_ID_NONE` on ESC.  `tui_input_run`
returns 1 on ENTER, 0 on ESC and a negative error for invalid storage.  Button
masks use `TUI_BUTTON()`, accept only OK/CANCEL/YES/NO, order buttons OK,
YES, NO, CANCEL, focus the first present button, move with left/right or TAB,
commit with ENTER and cancel with ESC (or `TUI_ID_NONE` when CANCEL is
absent).  `tui_confirm` is a YES/NO message box with YES initially focused.

The modal member owns the only hidden store: one static 60 x 16
`struct tui_cell` buffer (1,920 bytes).  It validates the clipped size, saves
before drawing, restores on every exit path and refuses nested modal calls.
Message boxes centre and cap at 60 x 16, wrap at word boundaries, and draw
buttons in the bottom interior row.

## Archive members and sizes

```text
libtui_widgets.lib        51,238 bytes
  widget_common.rel        3,702
  widget_render.rel       18,348
  widget_menu.rel          3,783
  widget_input.rel        10,307
  widget_modal.rel        14,256
```

Program sizes:

```text
no-TUI hello.exe          4,846 bytes  image  4,810  BSS   295
core-only tui_core_probe  7,617 bytes  image  7,581  BSS 5,129
render-only widget probe 12,839 bytes  image 12,803  BSS 5,129
full tui_test.exe        32,070 bytes  image 32,034  BSS 7,487
```

The render-only probe links `widget_render` and `widget_common` only; it has
no `widget_menu`, `widget_input` or `widget_modal` member and no
`_tui_menu_run`, `_tui_input_run`, `_tui_message_box` or `_tui_confirm`
symbol.  The core-only probe links no widget member and has the same BSS as
the render-only probe.  `LIBS=tui_widgets:tui` puts the widget archive before
its core dependency in both link files.

The `widgets` mode draws a configuration form (menu, label, input, checkbox,
list, buttons, status bar), drives it with injected keys through menu run,
input run, list navigation, confirm and message box, and verifies
caller-owned `name == "dam"`, `selected == 0`, the checked flag, menu result
12, shortcut 10, ESC result `TUI_ID_NONE`, input commit/cancel, confirm NO,
message CANCEL and the full-buffer `tiny == "ab"` boundary.  The final serial
and V9958 maps agree on text and attributes, including the reverse menu,
selected list row, focused button and status bar.

## Validation

```sh
make build/user/tui_test.exe build/user/tui_widget_probe.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package
git diff --check
```

The combined package 68-72 run completed 173 tests with 171 passed and 2
environmental skips; `git diff --check` was clean.

## Supervisor acceptance

Accepted on 2026-10-18. Direct review confirmed the public-core-only boundary,
deterministic archive split, absence of hidden render-only storage, bounded
modal buffer, keyboard policies, and restore-on-exit paths. The worker's
combined 173-test result and dual-backend configuration replay are accepted;
the supervisor also observed the widget static/link-map and SDK package checks
pass before stopping duplicate validation at the owner's request.

Package 70 correction 01 does not overlap this result: modal boxes are rejected
below 5 x 5, while that correction is limited to zero-height titled frames.
Package 73 remains gated until package 70 is corrected.
