# file-truncate (package 90) validation

Validated 2026-10-24.

## Scope

KFILE_OP_TRUNCATE (6): the IOC-FAT operation over FS2 TRUNCATE, the
kernel FILE gate's forwarding, the SDK `truncate(handle, length)`
member, the read-only refusal in the system provider, docs and tests.

## What was built

- `abi/kos/protocol.h`: KFILE_OP_TRUNCATE (6), `payload[1..4]` the
  little-endian unsigned 32-bit new length; returns 0 or a negative
  errno; a read-only provider answers KOS_EROFS.
- `drivers/iocfat/iocfat_trunc.asm` (new): `_iocfat_truncate_op` and
  `_iocfat_write_note`, hand-written because the compiled form needed
  two 32-bit compares and a 32-bit copy around the FS2 calls (+343
  bytes) and blew the driver hot budget.  Eight driver symbols were
  un-staticed so the asm can reference them.
- `drivers/iocfat/iocfat.c`: dispatch case, the write-path size note,
  the externs; `drivers/iocfat/iocfat.json` and the Makefile wire the
  new object.
- `kernel/vfs/fs.c`: the FILE gate forwards KFILE_OP_TRUNCATE (before
  this it was refused, and the SDK masked the refusal as success).
- `kernel/vfs/system.c`: KFILE_OP_TRUNCATE answers -KOS_EROFS.
- `user/sdk/src/ipc.c`: `call()` returns the syscall's primary result
  instead of the reply-status field, so an early kernel refusal is
  carried instead of read as a stale zero.  This matches the documented
  SDK contract ("returns the IPC status ... or a negated KOS_E*
  refusal") and is what `truncate()`'s error contract needed.
- `user/sdk/src/truncate.c` (new member), `user/sdk/include/kos/fs.h`,
  `user/sdk/exe.mk`.
- Tests: `tests/fs/fs_selftest.c` `truncate` tail (13 checks) and
  `tests/test_truncate.py` (replay with FS2 request-log pins);
  `tests/test_source_layout.py` owner lists; the monitor payload pin
  in `tests/test_console_acceptance.py` moved with the relink;
  `tests/perf/readphase.c` reads the now-carried kernel refusal.
- Docs: `docs/filesystem.md`, `docs/sdk.md`.

## Driver budget

- Hot tier: 30,995 (baseline) -> 31,230.  This exceeds the package's
  96-byte growth target by 139 bytes (reported as an overrun).  The
  reserve is held: free = 1,538 >= the required 1,536.
- The op itself is 176 bytes of hand assembly.

## Evidence

- Fragment harness against the packed `iocfat.mod` in tests/z80sim.py:
  14 cases pass (shrink, clamp, no-op grow/equal, exchange-failure and
  map-status-failure propagation, read-only and non-write refusals,
  invalid object, stale generation, four write-note cases).
- `python3 -m unittest tests.test_iocfat tests.test_truncate
  tests.test_sdk tests.test_source_layout`: all pass.
- `make check` (reproducible rebuild + full suite): OK.
  - 920 tests, 0 failures, 119 skipped.
  - mapcheck and pack_image clean; konaos.bin and zephyr80.bin
    byte-identical (sha256 81f0f50e...).
  - Driver hot 31,230 bytes of 32,768.

## Notes

- The debug path found two pre-existing bugs outside the asm: the
  kernel gate refused op 6, and `call()` reported a stale zero on
  early refusals.  Both are fixed above.
- The test-program tail initially wrote 2,560 bytes from a 512-byte
  pattern buffer and read 1,000 bytes into a 512-byte buffer; both now
  run in bounded slices (the driver behaved correctly throughout).
- The replay's FS2-count pins sit at markers whose following calls
  cannot change the count (the program races ahead of its console).
- The image hash moved from the previous baseline because the image
  now carries the kernel and SDK changes above.
