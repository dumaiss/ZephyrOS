# M10 host assembly (package 41b)

Date: 2026-10-09.  Contract: `work/41b-m-10-service-slimming/WORK.md`
(architecture 36.24 step 5, decisions 11-16).

## Result

Package 41b is closed.  The five resident drivers are linked on the host at
their final bank-6 addresses: the packer owns placement, endpoint numbers
and the inter-driver dependency table, and the containers carry no
relocation records (driver ABI 3).  The loader is a copier: read the
manifest, bound-check, copy the segments, zero the BSS, install the
host-built endpoint and dependency tables, run each boot segment and hot
init once.  `service_relocate`, runtime registration, runtime lookup
between drivers and the runtime dependency checks are gone.  The nucleus
keeps only the bounds checks that protect it, and drivers keep only the
checks that stop them indexing outside their own arrays or programming
hardware outside its range.

Driver-to-driver calls go through the endpoint table with the caller's
frame passed by reference - no copy and no bank switch - and the ledger
lines are renamed `driver hot:` and `driver boot/bulk:`.  Behaviour is
unchanged: every listed image passes, and production shrinks.

Production artifact: `build/zephyros.bin`
`sha256 11a9bd2b68c7473eab6b624de4155a45ac738f668033b493c965a92fb7016c2e`.

## Files added, removed or materially changed

Nothing was added or moved outside the report itself; no file was removed.

| area | what changed |
|---|---|
| `tools/zmodpack.py` | links each image against the whole load-order set (`pack --set`): per-segment `base`, host-assigned endpoint `number` with an absolute `dispatch` entry, 4-byte dependency records, zero relocation fields, tier-overlap plan, `services` command validation and the two driver ledgers |
| `include/zephyros/service.h` | ABI 3: the linked segment/endpoint/dependency records, `ZMOD_SERVICE_ABI_VERSION 3` |
| `include/zephyros/ipc.h` | driver bootstrap API 3: `register_ep` and `lookup` leave the driver API; `struct ipc_service_boot {api, deps}` carries the host-resolved numbers |
| `kernel/ipc/ipc.c`, `ipc.h` | endpoint install, the fixed `zos_service_deps` bundle, the static boot bundle, near-direct nested calls, the boundary staging frame for cold/outermost callers |
| `kernel/service/service_loader.c` | rewritten as the copier: manifest read, protective bounds, copy/BSS through the copy gate, endpoint and dependency install, boot segment and init, evidence lines |
| `drivers/{sio,ioc,hid,v9958}`, `services/console` | init takes the boot bundle; symbolic dependencies (`HID_DEP_IOC`, `CONSOLE_DEP_HID/SERIAL/VIDEO`); driver-side lookups and frame/argument re-validation deleted, the kept checks named |
| `services/manifests/*`, `tests/target/ipc/manifests/*` | ABI 3, resolved dependencies (console HID/SERIAL/VIDEO optional, vfs self/fat, fat ioc, echo self) |
| `Makefile` | `--set` wiring for both sets (`OBJDIR:MANIFEST` tokens), and the whole set's objects as pack prerequisites |
| `tools/pack_image.py` | ledger lines renamed `driver hot:` / `driver boot/bulk:` |
| `docs/module-format.md` (§7), `docs/devices.md` (§12), `docs/memory.md` | host-linked format, ABI 3, driver wording |
| `tests/*` | `test_service_images.py` rewritten as packer tests; the replays and ABI pins updated; the retired subjects deleted (below) |

Diff by area (48 files, +1,500/-1,249 lines): `tools/` +401/-176,
`kernel/` +367/-558, `tests/` +355/-267, `docs/` +138/-97,
`include/` +131/-103, `services/` +62/-27, `drivers/` +32/-18,
`Makefile` +14/-3.

## Ledgers

Before is the package-41 production plan; after is the host-assembly plan.

| ledger | before | after | delta |
|---|---|---|---|
| nucleus fixed | required 7,083; overflow 7,752; stacks 768; room 781 | required 6,955; overflow 7,752; stacks 768; room 909 | required -128 |
| nucleus cold | code 24,153, end `BE59h`; arena 13 granules (13 used); data 1,208 at `DA00h`; room 751 | code 22,935, end `B997h`; arena 16 granules (13 used, 3 free); data 1,143 at `DA00h`; room 498 | code -1,218 |
| driver hot | 13,216 / 32,768 | 12,930 / 32,768 | -286 |
| driver boot/bulk | 2,170 / 24,576 | 2,170 / 24,576 | 0 |
| common | 2,230 (code 1,511, data 719) | 2,230 (code 1,511, data 719) | 0 |

The loader's smaller cold body moves the cold arena base down to `BA00h`,
so the arena holds 16 granules while the boot set (IOC-FAT) still uses 13:
the boot set gains 3 free granules it did not have.  No ceiling, capacity
or overflow reservation was raised.

Production loader cost is `_WINDOW` 4,461 + `_WINDOW_DATA` 167 =
**4,628 bytes**, down 1,283 bytes (-21.7 %) from 5,679 + 232 = 5,911.

## Per-driver hot bytes

Hot segment image plus BSS, from the packed containers:

| driver | before | after | delta |
|---|---|---|---|
| SIO | 889 | 893 | +4 |
| IOC | 5,034 | 5,008 | -26 |
| HID | 1,733 | 1,523 | -210 |
| V9958 | 5,088 | 5,089 | +1 |
| console | 472 | 417 | -55 |
| total | 13,216 | 12,930 | -286 |

The boot/bulk tier is unchanged at 2,170 bytes (V9958's 2,048-byte font
plus 122 bytes of boot code).

## Wrapper itemization (requirement 7)

Endpoint plumbing per driver, from the final objects: the dispatch entry
and the init entry the loader calls.  Device-core code is not counted.

| driver | dispatch | init | dispatch+init | hot image |
|---|---|---|---|---|
| SIO | 81 | 16 | 97 | 893 |
| IOC | 103 | 35 | 138 | 5,008 |
| HID | 83 | 128 | 211 | 1,523 |
| V9958 | 91 | 74 | 165 | 5,089 |
| console | 167 | 165 | 332 | 417 |

No driver spends more than 300 bytes on dispatch: the largest dispatch
entry is the console's 167 bytes, and the largest dispatch-plus-init
wrapper is the console's 332 bytes, whose init consumes the three
host-resolved dependency numbers and selects the live input/output paths
(the HID readiness probe) - composition, not dispatch.  A shared
table-driven dispatch layer would not save 300
bytes for any driver, so none was added.  Fixed-core growth is -128 bytes
against the at-most-300-byte budget.

## Near-direct driver-to-driver calls (requirement 6)

The same instrument and the same acceptance image as the package-39 table
(`make ipc-selftest` phase markers; measured/warm-up, T-states per call):

| call | before (41) | after (41b) | delta |
|---|---|---|---|
| null call | 18,005.0 | 15,455.5 | -2,549.5 (-14.2 %) |
| vfs-512-direct | 93,653.0 | 87,253.5 | -6,399.5 (-6.8 %) |
| vfs-512-staged | 118,111.0 | 111,711.5 | -6,399.5 (-5.4 %) |
| vfs-64-offset | 84,203.0 | 77,803.5 | -6,399.5 (-7.6 %) |
| con256-write | 110,446.8 | 107,897.4 | -2,549.4 (-2.3 %) |
| console256-direct | 202,937.0 | 198,450.5 | -4,486.5 (-2.2 %) |
| fsread-baseline (M9) | 308,861.0 | 308,221.5 | -639.5 (-0.2 %) |

The nested path is the measured win: a driver-to-driver call now dispatches
through the endpoint table with the caller's frame passed by reference,
while the outermost (cold-half or application) caller still stages through
the fixed boundary frame because its own frame is not visible with the
window on bank 6.  Every measured call set still returns its caller's
latch: 720 calls across 679 domain intervals, 639 syscall returns.

## Retired tests and fixtures

Deleted rather than ported, one line each because the subject no longer
exists; each replacement is a packer test in `tests/test_service_images.py`
unless noted.

- `test_records_name_the_target_segment_and_patch_the_owning_word`:
  containers carry no relocation records; replaced by
  `test_a_container_rejects_relocation_records` and
  `test_a_relocation_overflow_is_refused_at_pack_time`.
- `test_loading_adds_the_target_segment_base`: the loader adds nothing;
  replaced by `test_the_io_pointer_lands_in_the_io_blocks_final_base` and
  `test_the_boot_pointer_lands_in_the_hot_images_final_base`.
- `test_a_missing_dependency_is_refused` (runtime dependency check):
  replaced by the packer's `test_a_missing_required_dependency_is_refused`
  plus `test_a_required_dependency_resolves_to_the_exporter_number`,
  `test_an_optional_dependency_that_is_absent_resolves_to_zero`,
  `test_a_dependency_on_a_later_image_is_refused` and
  `test_an_image_may_depend_on_its_own_endpoint`.
- `test_the_plan_matches_the_loader_tier_policy`: the tier plan is the
  packer's; replaced by `test_the_plan_matches_the_embedded_bases_and_ledgers`,
  `test_the_services_command_accepts_the_linked_containers` and
  `test_the_services_command_reports_the_driver_ledgers`.
- `test_discovery_is_endpoint_lookup_only` (hid): renamed
  `test_discovery_is_host_resolved_only`; a driver can no longer look
  another up.
- `test_loader_enforces_the_service_io_range` (ipc): renamed
  `test_loader_and_packer_enforce_the_service_io_range`; the loader only
  bounds-checks, the packer refuses the tier violation at build time.

## Validation

`make clean && make check` ran on the final sources: **800 tests OK, 176
conditional-image skips**, reproducible production hash, map and image
checks pass (1m32.2s wall clock; the first pass of this package found two
build/test defects - a parallel-make prerequisite for the `--set` link and
three stale replay evidence regexes - both fixed before the runs below).

| command | result |
|---|---|
| `make clean && make check` | PASS: 800 OK (176 conditional skips); reproducible `11a9bd2b...` |
| `make console-integration-selftest console-fallback-selftests video-selftest` | PASS: video 4/4; console integration 6/6; fallback 3/3 plus 1 abstract-harness skip |
| `make ioc-selftest hid-selftest` | PASS: 2/2 each |
| `make ipc-selftest` | PASS: 53/53 (`ipccopy: 23/23 checks`, `ipc: 55/55 checks`); six images placed, `driver hot 6057/32768`, `driver boot/bulk 143/24576` |
| `make m9-selftest` | PASS: 7/7 |
| `git diff --check` | PASS |

The two self-test fixes were found by these runs: each image pack links the
whole load-order set, so both pack rules now wait for every member's
objects (the parallel default build is race-free again), and the IOC/HID/
video replays parse the renamed `driver <name>:` evidence lines.

### Stacks

From the IPC acceptance image on this source: **gate stack worst case 213
of 256 bytes** (`E61Bh-E6EFh`), **driver service stack high-water 246 of
512 bytes** (`5E0Ah-5EFFh`, was 256), ISR stack 12 of 255.  The loader's
own failure path stays on the gate stack; the copier runs before any
driver stack exists.

## Projection for 42a/42b (36.20)

- **bank 6:** the five linked drivers use 12,930 of 32,768 hot bytes and
  2,170 of 24,576 boot/bulk bytes.  IOC-FAT as the `/FS` driver adds its
  6,006-byte image plus 637 bytes of BSS - the same numbers the package-42
  plan assumed - and a wrapper of the same order as the five measured
  above (97-332 bytes): the bank-6 hot tier holds 19,838 free bytes and
  the boot/bulk tier 22,406.
- **bank 7:** the root router, the three static providers, the publication
  table, the handle table and bind/call/unbind/`ns_enum` fit in the room
  the arena frees: production cold room is 498 bytes and the arena
  reservation is 16 granules (8,192 bytes at `BA00h-D9FFh`); removing the
  arena raises the available bank-7 window space to 8,690 bytes before
  the new router code is counted.
- **the arena:** removed; nothing else in the cold half depends on it
  after IOC-FAT moves to bank 6.

## Hardware (owner)

Not run here.  One run covers this package: `make smoke-hardware`, the
console with the keyboard and the V9958, the serial console, and ESC `c`.

## Supervisor review (2026-10-09)

**Accepted** on the record's evidence, with hardware pending (owner; this
run also covers package 41's checks).
- Validation ran once on the final source; production `11a9bd2b…`.
- Driver hot is 12,930 bytes, and the 42 projection leaves about 19.8 KB
  free.
- Wrappers are 97-332 bytes, so no shared dispatch layer was needed.
- Near-direct calls measured faster; fixed core -128 bytes.

**Finding, carried into package 42c:** the "copier" loader is still
4,628 bytes, and `service_read_layout` alone is 1,899 of them: it parses
and re-validates the container tables at boot, which the packer has
already done. 42c makes the packer emit a flat load plan (segments,
endpoint table, dependency table) that the loader iterates with protective
bounds only. Target: loader at most 2,000 bytes.

## Hardware (owner, 2026-10-09)

This run closes packages 41 and 41b on `build/zephyros.bin` `11a9bd2b…`.

- `make smoke-hardware`: **PASS** (banner-only; the console is bound to
  the V9958; the FS2 root probe answered with media present).
- The V9958 console shows the monitor banner and prompt: **PASS**.
- ESC `c`: **not testable** (nothing on the board emits the sequence).
  Deferred; a failure is fixed later.
- Runtime serial fallback with the keyboard unplugged: **not observed**.
  `console: service OK` appears on the V9958 and the console does not
  move to serial. Not fixed by owner decision: package 42c replaces the
  runtime fallback with a build-selected `console-serial` driver, whose
  hardware check covers this.
