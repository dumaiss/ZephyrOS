# M10 files on typed handles, correction 01: retiring the M9 acceptance machinery

Date: 2026-10-09.  Contract: `work/42b-m10-files-on-handles/correction-01/WORK.md`
(owner decision, 2026-10-09: the M9 acceptance machinery is deleted rather
than kept live; the known-good M9 reference is git history).  This report
covers the deletion, the one M10 outcome image that replaces it, and the
suite reconciliation that followed.  The production switch-over itself is
`2026-10-09-m10-files-on-handles.md`.

## Result

The M9 acceptance machinery is gone: seven acceptance images and their
target programs, headers, manifests, fixtures and host test modules, plus
the arena/loader/registry fixtures 42b's own contract listed.  One new
image, `fs-selftest`, replaces them with outcomes in the new model, and
it is the image the docs now name.

```sh
make clean && make check
make fs-selftest ns-selftest ipc-selftest console-integration-selftest
git diff --check
```

| command | result |
|---|---|
| `make clean && make check` | OK (reproducible rebuild, full host suite, `make check: OK`) |
| `make fs-selftest` | OK: 3 replay cases, 35/35 checks with a card, 8/8 without |
| `make ns-selftest` | OK: 23 tests, client 76/76 checks |
| `make ipc-selftest` | OK: 53 tests, client 54/54 checks, probe 23/23 checks |
| `make console-integration-selftest` | OK: 6 tests |
| `git diff --check` | clean |

Production artifact: `build/zephyros.bin`
`sha256 d5e816f2e47ace191077f916487e61c65df39e61a0709954aff7b32179e8abec` -
the 42b hash, reproduced after `make clean && make check`.  Production
behaviour is unchanged by this correction: no production object appears
in any of the deletions below, and the link set the build sees is the one
42b left.

## What was deleted

73 tracked files, 13,416 lines, in two groups: this correction's test
machinery (54 files, 9,891 lines) and the production objects 42b's
requirement 11 retires (19 files, 3,525 lines, listed in the 42b report).

**Acceptance images and their Makefile machinery** (11 targets):
`m9-selftest`, `m9-exec-selftest`, `m9-iocfat-selftest`,
`m9-vfs-selftest`, `m9-required-mount-selftest`, `m9-provider-selftest`,
`m9-fs-selftest`, the four `smoke-hardware-m9*` flashers, and every
`zex_program` rule and manifest that fed them.

**Target programs, headers and fixtures** (43 files, 6,298 lines):
`tests/target/m9/` in full (15 files, 4,250 lines) - `fstest/fstest.c`
(964), `fstest/fsfat.c` (854), `m9_iocfat_test.c` (715),
`m9_provider_test.c` (576), `m9_vfs_test.c` (521), `exec/fschild.c`
(155), `m9_selftest.c` (85), `m9_exec_test.c` (85), `m9_fs_test.c` (81),
`m9_selftest_runner.c` (77), `fstest/fstest_l.c` (67), `exec/fsdeep.c`
(32), `exec/fsraw_entry.asm` (18), `exec/fsraw.c` (10),
`m9_selftest_internal.h` (10); the seven `tests/target/include/` headers
(241 lines, the `m9_*.h` set and `loader_selftest.h`);
`tests/target/loader/loader_test.c` (443); the twelve `tests/m9/*.json`
manifests (389 lines: the mount sets and the image manifests); and the
eight `tests/modules/` fixtures (975 lines:
`{ramfs,m9_probe,m9_fail,m9_dup}.{c,json}`).

**Host test modules** (11 files, 3,593 lines): `test_m9_exec.py` (685),
`test_m9_exec_sim.py` (459), `test_m9_vfs.py` (403), `test_iocfat_sim.py`
(369), `test_m9_vfs_sim.py` (342), `test_m9_fs.py` (334),
`test_m9_selftest_sim.py` (255), `test_block.py` (226),
`test_m9_provider_sim.py` (186), `test_syscall_sim.py` (178),
`test_m9_selftest.py` (156).

Nothing was ported.  Where an M9 suite covered an outcome the new model
still has, the outcome is checked by `fs-selftest` or by the acceptance
image that owns the subject now; the one-line coverage map is in the 42b
report.

## The replacement image: `fs-selftest`

`make fs-selftest` builds `build-fs-selftest/zephyros-fs-selftest.bin`:
the production boot path with an image-specific store manifest and two
new programs (`tests/fs/fs_selftest.c`, 320 lines; `tests/fs/fs_child.c`,
98 lines), plus a replay module (`tests/test_fs_selftest_sim.py`).

With a writable card the boot program reports **35 checks, 0 failures**
and hands the console to the monitor; the outcomes are:

- card surface through `fs.h`: `fs-open-create`, `fs-write-blocks`,
  `fs-close-write`, `fs-stat-type`, `fs-stat-size`, `fs-open-read`,
  `fs-read-head`, `fs-seek-set`, `fs-read-cross-block`, `fs-seek-end`,
  `fs-read-eof`, `fs-seek-cur`, `fs-read-tail`, `fs-close-read`;
- namespace operations: `fs-mkdir`, `fs-mkdir-stat`, `fs-rename`,
  `fs-rename-stat`, `fs-rename-old-gone`, `fs-unlink`, `fs-rmdir`,
  `fs-unlink-gone`;
- enumeration: `enum-root-system`, `enum-root-fs`, `enum-card-file`,
  `enum-card-subdir`;
- `/SYSTEM` read (ROMFS): `system-stat`, `system-open`, `system-read`,
  `system-close`;
- nested exec from `/SYSTEM` with a tail and the child's exit status:
  `exec-status`, with the child reporting its own stdout and its leaked
  handles;
- handle release: `exec-child-handles-released` - the parent proves the
  child's leaked handles are gone by reading the driver's card slots and
  the kernel's `vfs_descriptors` at the moment it reuses them.

With no card the program takes its absent-card branch and reports
**8 checks** (`/FS` binds fail cleanly, `/SYSTEM` still works, the child
still runs), which is the replay's second case.  A third case is the
run that stops at `exec-status` to read the released handles out of the
machine.

## Suite reconciliation

Retiring machinery that other suites were pinned against surfaced the
usual fallout.  None of it is a production change; all of it was needed
to make the contract's four images green.

**Host suite, against the deleted subjects:**

- `tests/test_source_layout.py`: the deleted `test_syscall_sim.py` left
  its `OWNER_FILES` list, and its `ZEX_FILES` list now names the two new
  programs and no `ramfs` module.
- `tests/test_ipc_selftest.py`: the stage-3 lookup symbols are gone
  (`ZOS_SYSCALL_IPC_LOOKUP`, `_ipc_lookup`), `06h` is `bind` and `07h`
  is `call`.
- `docs/{vfs,abi,architecture,romfs-format,sdk}.md` were repointed at the
  new acceptance, including deleting the dead `ramfs`-provider section
  body from `docs/vfs.md`.
- `tools/mapcheck.py` and `tests/maptools.py` carried the old 256-byte
  gate stack; both now mirror `platform/zephyr80/memory.inc` at 384.

**The other acceptance images, against the 42b model.**  These images
are not M9 machinery - they are 42a's (`ns`), 39's (`ipc`) and 41's
(`console`) - but their expectations were frozen before 42b changed the
ABI and the module set, and the contract requires all four to pass:

- `ns-selftest`: the probe read its `SEEK` reply from `payload[0..3]`;
  42b moved the seek word to `payload[1..4]` (ABI, SDK, `ns_file.c` and
  the driver all agree), so a 72-byte file reported `18432`.  Fixed to
  the current contract.  The replay also still expected the M9 mount
  line `vfs: / unavailable 0x03`; the mount pass is gone with the M9 VFS,
  so the line is now asserted *absent*.
- `ipc-selftest`: the client bound six providers and checked the sixth's
  type from a variable the fifth bind had overwritten, and the image's
  boot program held five handles across the `exec` of its six-binding
  child - the global 12-slot handle table then answered `-ZOS_EMFILE`
  for the last three binds, for the file the client reads and for every
  `irq-*` check, which is why the client reported 46/54.  The boot
  program now hands its handles back before `zos_exec` (the pool is one
  global table and "the pool is never per-process", `kernel/vfs/vfs.h`),
  each bind checks its own type, and the client reports 54/54.
  Three replay expectations were re-derived: the lookup-cache census
  (its subject, `ZOS_SYSCALL_IPC_LOOKUP` and the SDK cache, was deleted
  by 42b - it is now a bind census that reads each bind's spelled path),
  the `DIRECT_PHASES` premise that a file read issues no IPC call (the
  filesystem baseline is a FILE call on a bound handle now), and the
  span model (`pc == ret` alone is ambiguous because the fixed-core SDK
  has several call sites at one address; a span now ends at the real
  return, where the caller's SP and latch are back).
- `console-integration-selftest`: no source change; its one earlier
  failure was a replay reading `build/zephyros.bin` while another target
  was rebuilding it.  The acceptance run is serial for that reason.

## Open items

- Hardware: the contract's list is unchanged (production with and without
  a card, files under `/FS`, the monitor from `/SYSTEM`, nested exec).
  `make smoke-hardware-fs` replaces the M9 smoke modes; it has not been
  run here.
- `tools/serial_smoke.py` gained the `fs` mode; the M9 modes were
  removed with their images.
