# M4 Dynamic-Driver Acceptance — 2026-10-02 (stage 08)

## Status

- **Host validation: PASS.** 203 host tests (0 skipped with every
  milestone image present), reproducible clean rebuild (`make check`),
  ZMOD tooling verified byte-for-byte against `sdldz80`, and simulator
  replays of the production boot, the loader self-test, the dynamic SIO
  acceptance (with injected CTC0 deliveries), the shifted placement image,
  and the failure rollback.
- **Physical Zephyr-80 validation: PASS.** Attempt 1 (acceptance image,
  2026-10-02) failed and was root-caused to a CTC0 start/claim race;
  after the fix (`kernel/main.c` starts CTC0 with the M2 lock held) all
  three stage-08 images passed on hardware: the acceptance image
  (`console: dynamic sio0.b OK`, `m4 loader selftest: OK`,
  `m4 selftest: sio at 0xA000`, `m4 selftest: OK`), the placement image
  with the byte-identical `sio.zmod` at the shifted base
  (`m4 selftest: sio at 0x9E00`), and the failure image
  (`console: dynamic driver failed`, `m4 failure selftest: OK`).  The
  stage-07 loader image remains hardware-validated
  (`2026-10-02-m4-loader-hardware.md`).

## Implemented (stage 08)

- `drivers/sio/{sio.c,sio_io.asm,driver.c,sdcc_glue.asm}` plus three
  manifests (`module.json`, `module-irq.json`, `module-fail.json`) are
  built into `build/modules/` and packed to `sio.zmod` (309+4 bytes,
  1 granule), `sio-irq.zmod` (582+8, 2 granules), `sio-fail.zmod`
  (379+8, 1 granule).  No SIO symbol is linked into the kernel; the build
  fails if one appears (mapcheck rejection sweep).
- Every image embeds its boot module through the generated catalog
  (`zmodpack.py emit-asm` -> `kernel/module/embedded.c`); the loader
  neither knows nor checks name, size, load address, relocation list, or
  init entry in advance.
- Boot flow: registry -> empty static table -> loader init -> optional
  live CTC0 (acceptance image) -> catalog load -> optional CTC0 stop ->
  `console: dynamic sio0.b OK` through the module-bound console (or
  `console: dynamic driver failed` on load failure).
- Placement image: arena shifted to 9E00h-BE00h via a generated
  `memory.inc`; embeds the byte-identical `sio.zmod`.
- Failure image: `sio-fail.zmod` registers a device and claims CTC1, then
  returns failure; `zos_run_m4_failure_selftest` proves the rollback left
  no device, claim, descriptor, or granule behind.
- The probe fixture's device naming is derived from its load-base parity,
  so the loader self-test works with the boot module occupying the first
  granule (and at the shifted base).

## Host evidence

```text
$ python3 -m unittest discover -s tests        # 203 tests, OK (no skips)
$ make zmod-test                               # OK
$ make m4-loader-selftest                      # OK (simulator replay)
$ make m4-selftest                             # OK (CTC injection replay)
$ make m4-placement-selftest                   # OK (identity + 9E00h reloc)
$ make m4-failure-selftest                     # OK (rollback replay)
$ make check                                   # reproducible rebuild + stack
```

Key artifacts (sha256):

```text
build/zephyros.bin                                             021f511d0f88f287ba2493ba176f6dfcfc1e3e229aecc0ba238011663137410d
build-m4-loader-selftest/zephyros-m4-loader-selftest.bin       f83e3311f07674d8243a0f18afb3a7694001ffa0f7bc8ab0b283894181487848
build-m4-selftest/zephyros-m4-selftest.bin                     47ceb47211ff72b37f1e8008267c1c83d60f320ff0acd81db863b9106134ea6f
build-m4-placement-selftest/zephyros-m4-placement-selftest.bin 86405e166360c79eb6203166ee6b9684eb63d2e8b54a64908bd9fdc64967b5a3
build-m4-failure/zephyros-m4-failure.bin                       04924af6c567cf9885b707e9bbe4e8aed633d16e6dc8d9a71353169816efaba7

build/modules/sio.zmod       2543e08e529f190c9812a15af1d4f513f9e99a83a2a5d39d782f1c1278d36dd5
build/modules/sio-irq.zmod   88e128f7bd58048056afac66a64905535664d88d476a7954dde188b10d358113
build/modules/sio-fail.zmod  363b2256c6bc4bc2fafb04435d5511e37fc07d29705ec9c00751ee85d81199d8
```

The placement image embeds `sio.zmod` verbatim (byte-compared in
`tests/test_m4.py` and `tests/test_m4_sim.py`), and its map reports the
arena as 9E00h-BE00h.

## Physical validation

### Attempt 1 — acceptance image (2026-10-02): FAILED, root-caused

```text
$ make smoke-hardware-m4 SERIAL_PORT=/dev/ttyUSB0
serial_smoke: captured 132 bytes
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: dynamic driver failed
m4 selftest: FAIL code=0x0A
```

- `0x0A` = `ZOS_M4ST_FAIL_BOOT`: the boot catalog module was not resident.
- Root cause: `irq_init()` leaves interrupts enabled, and the acceptance
  boot starts CTC0 *before* the module claims it.  The first CTC0 tick
  (~152 Hz; the module-load prologue takes milliseconds) was dispatched
  with no owner; `irq_dispatch()` answers unowned sources with
  `platform_irq_quiesce()`, which resets and disables CTC0.  The IRQ
  self-test module then claimed a dead timer, counted zero deliveries in
  its bounded EI spin, returned `ZDRIVER_FAIL` (`ZMOD_EINIT`), and the
  load was rolled back — hence `console: dynamic driver failed` and the
  later boot-module check failing.
- The simulator had masked the race because the replay only injected
  ticks while the CPU was inside the module image (the spin); the M3
  probe was immune because it claims CTC0 *before* starting it.
- Fix: `kernel/main.c` starts CTC0 with the M2 lock held
  (`irq_arch_lock`) and stops it after the load, so pre-claim ticks stay
  pending and are delivered to the relocated handler at the module's
  first `EI` (claim-first ordering).  `tests/test_m4_sim.py` now injects
  a pre-claim tick in the acceptance replay and pins the unowned-tick
  quiesce semantics in a dedicated regression test.

### Acceptance image — post-fix hardware run (2026-10-02): PASS

Flashed `build-m4-selftest/zephyros-m4-selftest.bin`
(sha256 `47ceb47211ff72b37f1e8008267c1c83d60f320ff0acd81db863b9106134ea6f`)
and captured (`make smoke-hardware-m4 SERIAL_PORT=/dev/ttyUSB0`, 168
bytes):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: dynamic sio0.b OK
m4 loader selftest: OK
m4 selftest: sio at 0xA000
m4 selftest: OK
serial_smoke: OK (the banner, the dynamic console line, the loader self-test, the dynamic SIO acceptance line, and 'm4 selftest: OK')
```

What the run proves:

- the packed SIO module is loaded from the embedded catalog and its
  init runs from the loader-allocated arena (`sio at 0xA000`, first
  granule); no kernel symbol special-cases it;
- the CTC0 claim/count/release exercise inside the *relocated* init
  received three real CTC0 deliveries and released the source with the
  post-fix masked start (the exact path that failed in attempt 1);
- the module registered `sio0.b` through the unchanged M3 registry, the
  console service bound it by capability, and the acceptance line was
  printed through the dynamically loaded driver;
- the loader self-test (fixtures, rollback, double relocation,
  exhaustion) still passes with the boot module resident.

### Placement image — hardware run (2026-10-02): PASS

Flashed `build-m4-placement-selftest/zephyros-m4-placement-selftest.bin`
(sha256 `86405e166360c79eb6203166ee6b9684eb63d2e8b54a64908bd9fdc64967b5a3`)
and captured the same acceptance transcript with the shifted base (168
bytes):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: dynamic sio0.b OK
m4 loader selftest: OK
m4 selftest: sio at 0x9E00
m4 selftest: OK
serial_smoke: OK (the banner, the dynamic console line, the loader self-test, the dynamic SIO acceptance line, and 'm4 selftest: OK')
```

This proves the *byte-identical* `sio.zmod` image relocates and runs at
the shifted arena base (9E00h-BE00h): the loader chose 0x9E00 with no
kernel knowledge of the module or the address, the relocated ops/state
pointers resolved correctly, and the console bound to the relocated
device.

### Failure image — hardware run (2026-10-02): PASS

Flashed `build-m4-failure/zephyros-m4-failure.bin`
(sha256 `04924af6c567cf9885b707e9bbe4e8aed633d16e6dc8d9a71353169816efaba7`)
and captured (`make smoke-hardware-m4-failure SERIAL_PORT=/dev/ttyUSB0`,
128 bytes):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: dynamic driver failed
m4 failure selftest: OK
serial_smoke: OK (the banner, 'console: dynamic driver failed' (no dynamic console line), and 'm4 failure selftest: OK')
```

This proves exact rollback on real hardware: the failing module (which
registers a device and claims CTC1 before returning `ZDRIVER_FAIL`) left
no device, claim, descriptor, or granule behind, and the kernel reported
the load failure through the independent early console.

### Transcript: acceptance image

Recorded above (post-fix run, 2026-10-02, 168 bytes).

### Transcript: placement image

Recorded above (2026-10-02, 168 bytes; `m4 selftest: sio at 0x9E00`).

### Transcript: failure image

Recorded above (2026-10-02, 128 bytes).
