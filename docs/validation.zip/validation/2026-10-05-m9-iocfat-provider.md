# M9 IOC-FAT provider (package 30, correction-01): validation record

Work package: `work/30-m9-iocfat-provider` and its `correction-01`.
Dates: host/simulator 2026-10-05; physical 2026-10-05 (all three rows PASS - see section 7).
Host toolchain: SDCC 4.5.0 (`sdcc`/`sdldz80`/`sdasz80`).

## 1. Result

`iocfat.zmod`, the resident filesystem provider that exposes the deployed
MCU FatFs service (FS2) through the IOC command lane, is implemented,
trimmed to the correction budget, integrated into production as the optional
writable `/`, and accepted by target tests plus a simulator replay.

* Fit: `iocfat.zmod` is **6006 image + 637 BSS = 6643 bytes, 13 granules**,
  13 bytes under the 6656-byte ceiling.  The first implementation measured
  7441 bytes (15 granules).
* Production arena: `33 boot, 2 free` granules plus 63 bytes of data slack,
  i.e. **1087 bytes** of total slack against the 1 KiB target the project
  owner set for the end of M9 (architecture section 32.39).
* Gate stack: the worst case through IOC-FAT `read`/`write`/`readdir` on
  the syscall path is **195 bytes**, inside the 224-byte limit; the worst
  case anywhere in the acceptance image is 206 (`SYS_EXEC`), and the M9
  filesystem image is unchanged at 213.
* Cache: the one-slot write-through cache is kept and every rule is proven
  by FS2 command counts observed by the host peer (section 5).
* Host/simulator: the formal batch in section 6 passes end to end, with a
  reproducible production rebuild.
* Physical (2026-10-05): all three hardware rows **PASS** on the exact
  image hashes this record lists - production with a FAT card, production
  with the card removed (`vfs: / unavailable 0x03`, console and `/SYSTEM`
  still usable) and `m9-iocfat-selftest` with a writable card (the native
  IOC-FAT section, the cache phases and the monitor prompt on serial).
  Transcripts: `2026-10-05-m9-iocfat-provider-hw.txt`.

## 2. Ledger (architecture section 32.39)

```text
module                 image   bss   total  granules
iocfat.zmod before      6800   641    7441      15
iocfat.zmod after       6006   637    6643      13

production before       35 granules (35 boot, 0 free), data slack 63 bytes
production after        bank7: code 28476 bytes end 8F3Ch | arena 35 granules
                               (33 boot, 2 free) | data 2241 bytes at D600h |
                               isr 256 | slack 63 bytes
                        common: used 2104 of 7424 bytes (code 1410, data 694)
```

Total slack is `63 + 2 x 512 = 1087` bytes, above the 1 KiB target and below
the original 2 KiB one; the owner accepted that on 2026-10-05 with the
measured reason recorded in architecture section 32.39.  The 32-granule
production floor holds (35), and the boot set is unchanged in kind:
`sio x1, ioc x8, hid x2, v9958 x9, iocfat x13`.

## 3. Trim (per function, `_CODE` bytes)

Measured from `build/modules/iocfat.lst` (function label to next label in
`_CODE`).  "before" is the package-30 measurement the correction quoted.

| function | before | after | change |
| --- | ---: | ---: | --- |
| `write` | 522 | 343 | uses the shared transfer helper |
| `read` | 498 | 510 | keeps only offset/split logic |
| `ready` | 102 | - | folded into `iocfat_transfer` (395, shared by read, write and cache fill) |
| `cache_fill` | 298 | 98 | calls the helper |
| `cache_hit` | 88 | - | inlined into `read` |
| `open` | 408 | 387 | driven by a constant table |
| `open_send` | 298 | 317 | called only by `open` |
| `readdir` | 359 | 359 | unchanged |
| `opendir` | 327 | 86 | shared `dir_open` (180) |
| `closedir` | 126 | 126 | unchanged |
| `dir_is_empty` | 84 | 89 | shared plumbing |
| `dir_find` | 84 | - | merged into the handle lookup |
| `pack` | 292 | 287 | one 8.3 walker |
| `unpack` | 224 | 141 | |
| `parse` | 118 | - | merged into `walk` (128) |
| `legal` | 83 | 75 | |
| `pack_nth` | 57 | - | merged into `walk` |
| `text_equal` | 69 | - | removed; the codec subsumes it |
| `rename` | 241 | 223 | |
| `same_parent` | 119 | 126 | |
| `leaf_op` | 91 | 71 | |
| `rmdir`/`unlink`/`mkdir` | 87/73/69 | 100/81/75 | read-only check first |
| `reset` (+ `reset_files`/`reset_dirs`) | 174 | 13 | one reused zero-init |
| `init` | 323 | 308 | register plus the CAPS probe |

Constants live in tables (`iocfat_status_table` 15, `iocfat_open_table` 16,
`iocfat_ops` 28 bytes), 16-bit arithmetic is used where possible, and the
protocol surface is one `iocfat_exchange` plus one `iocfat_transfer`.

## 4. Behaviour

Everything in the package-30 contract is kept: 8.3 packing with the full
rejection table, resolver sequencing, every open mode, READY/DONE
validation, EOF, write-through DONE-confirmed writes, `STALE`/generation,
`EMFILE`, `ENOTEMPTY`, cross-directory `EXDEV`, `READ_ONLY` CAPS, and the
one-slot write-through cache.

One defect was found and fixed while building the acceptance coverage:
`iocfat_mount()` calls the session reset, which cleared the whole instance
**including the CAPS-derived `read_only` flag**, so a write-protected card
was no longer refused before the provider sent anything.  `iocfat_reset()`
now preserves that flag (a device property, not per-mount state), and the
host peer gained the matching rule (a write-protected card refuses
`MKDIR`/`UNLINK`/`RMDIR`/`RENAME` with `READ_ONLY`).  The simulator replay
asserts that a read-only card sees **no** mutation command at all.

## 5. Cache evidence (FS2 command counts)

The module-side `TEST-ONLY HOOK` counter stays removed, so the cache rules
are proven by counting `FS2_READ` commands at the host peer between the
`m9 iocfat: cache:N` fences the target test emits.  `tests/test_iocfat_sim.py`
asserts each delta exactly; all of them held on the recorded run.

| window | expected `FS2_READ` | rule |
| --- | ---: | --- |
| `cache:0 -> 1` | +1 | the first read fills block 0 |
| `1 -> 2` | 0 | the repeated read is served from the slot |
| `2 -> 3` | +1 | 64 bytes at 500 fetch only block 1 |
| `3 -> 4` | +1 | block 2 |
| `4 -> 5` | +1 | block 0 again |
| `5 -> 6` | +1 | a second handle changes the slot owner |
| `6 -> 7` | 0 | repeat hit |
| `7 -> 8` | +1 | the writing file's own confirmed write drops the slot |
| `8 -> 9` | +1 | the other open file's confirmed write drops it |
| `9 -> 10` | 0 | repeat hit |
| `10 -> 11` | +1 | `close` releases the slot |
| `11 -> stale:end` | +1 | an armed `STALE` really reached the lane |
| `stale:end -> 12` | +1 | the `STALE` dropped the slot, so the read fetches |
| `12 -> 13` | +1 | `close` released the slot again |

Data correctness is checked at every step (a 512-periodic pattern compared
against the read slice), so a hit cannot pass by serving stale bytes.  The
8.3 rejection table is fenced by `names:begin`/`names:end` and asserted to
send **zero** FS2 commands of any class.

## 6. Formal run

```sh
make clean && make check
make m9-fs-selftest m9-iocfat-selftest
python3 -m unittest tests.test_iocfat tests.test_iocfat_sim tests.test_m9_fs tests.test_syscall_sim -v
git diff --check
```

* `make check`: `check: reproducible rebuild
  (7966f18fb5ecd58eeebc09ca8f857e0dae5399145450a4dcd44973f255a09b7c)`,
  then 703 tests OK, skipped=169.
* `make m9-fs-selftest`: `test_syscall_sim` 5 tests OK (worst-case gate
  depth 213 of 256), `test_m9_fs` 22 tests OK.
* `make m9-iocfat-selftest`: `test_iocfat_sim` 11 tests OK; gate depth
  through IOC-FAT 195 of 224, worst case in the image 206 of 256.
* The explicit unittest batch: 56 tests OK, **no skips**.
* `git diff --check`: clean.
* Wall clock for the whole batch: **7m04.7s** (user 23m39s).

Skips: the 169 skips are all simulator image replays, each skipped with
`<build dir>/<image>.bin missing; build the image first` because `make check`
starts from `make clean`.  They are executed by the two `m9-*-selftest`
image targets, which is where the acceptance numbers above come from.  No
skip exists in the four listed suites.

## 7. Hardware validation procedure - all three rows PASS (2026-10-05)

Bench: the package-28c bench (NucBox-M3-Ultra host, FTDI FT230X basic UART,
115200 8N1, ROM programmer for the 512 KiB socket, V9958 monitor and USB
keyboard connected).  Export the serial device once:

```sh
export SERIAL_PORT=/dev/serial/by-id/usb-FTDI_FT230X_Basic_UART_*-if00-port0
```

Build and record the exact bytes to flash (every row uses these two images):

```sh
make clean && make check          # must print "check: reproducible rebuild" and "make check: OK"
make hardware-images              # builds every smoke image, including m9-iocfat-selftest
sha256sum build/zephyros.bin \
          build-m9-iocfat-selftest/zephyros-m9-iocfat-selftest.bin
# 7966f18fb5ecd58eeebc09ca8f857e0dae5399145450a4dcd44973f255a09b7c  build/zephyros.bin
# 6e803153764cad68cb3585e39b264672a13141f6716078848e49db7f252800e6  build-m9-iocfat-selftest/...
```

Each image is exactly 524288 bytes and is programmed with the bench
programmer; `make smoke-hardware*` prints the image path and its sha256 as a
preflight, and exits with a clear message if the image is missing.
Start the smoke command *before* applying power/reset, so the capture sees
the first banner byte.

Transcripts for the completed rows are in
`2026-10-05-m9-iocfat-provider-hw.txt`.

### Row 1 - production with a writable FAT card - PASS (2026-10-05)

1. Insert a FAT16/FAT32 card with free space; keep the USB keyboard and the
   V9958 monitor connected.
2. Flash `build/zephyros.bin` (sha256 `7966f18f...`).
3. `make smoke-hardware SERIAL_PORT=$SERIAL_PORT`, then reset the machine.
   Expected: the tool prints the image and sha256 and ends with `PASS`,
   followed by

   ```text
   serial_smoke: note: the optional fs2 root `/` mounted without a
   diagnostic, so the MCU answered the FS2 root probe with media present
   ```

   On serial, exactly the four banner lines (`ZephyrOS 0.0`,
   `platform: Zephyr-80`, `kernel entry: OK`, `serial: OK`) and **no**
   diagnostic: no `iocfat: unavailable 0xNN` (that would be a module-load
   failure, not a missing card) and no `vfs: / unavailable 0xNN`.  A
   healthy card is silent, and the note above is what tells the two card
   states apart (the mount diagnostics are written to the early SIO
   console, so they are always in this capture; the V9958-bound console
   line and the monitor are not).
4. Operator check on the V9958 display and the USB keyboard: the monitor
   session appears (`ZephyrOS native monitor`, `bank=00 pid=0
   scratch=NNNN`, prompt `Z80>`), typing echoes, `R` prints the system
   line, and `Q` exits to the launcher which relaunches the monitor
   (`monitor: exit status 0x0000 active 0 free-banks 7`).
   Record whether the display session looked normal.
   Production cannot show a directory listing yet (the M9 shell is package
   31), so the positive proof that `/` is *live* on this card is row 3,
   which runs the same `config/mounts.json` against the same card.

Measured result (65 bytes, 0 USB bridge drops): banner-only `PASS` and
nothing else on serial, so the optional `/` mounted with no diagnostic and
no module reported unavailable.  The operator's display check showed
`console: dynamic sio0.b OK`, `ZephyrOS native monitor`,
`bank=00 pid=0 scratch=11A8`, `Z80>`, a typed `r` reporting
`system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02`, and `q`
handing back to the launcher which re-executed the monitor
(`monitor: exit status 0x0000 active 0 free-banks 7`).

Measured result (card out, same image): the early console printed exactly
`vfs: / unavailable 0x03` (`0x03` = `ZOS_ENODEV`, i.e. FS2 `NO_MEDIA` mapped
by the provider's mount probe), with no `iocfat: unavailable` line and no
panic, and the V9958 display still showed the monitor
(`console: dynamic sio0.b OK`, `ZephyrOS native monitor`,
`bank=00 pid=0 scratch=11A8`, `Z80>`).  `/SYSTEM` and the console are
unaffected by the missing card, so this row PASSes.  The earlier "nothing
different" observation compared two runs that both had the card seated:
the diagnostic only appears on a boot with the card actually out, and it is
written to the early SIO console rather than to the V9958-bound console.

### Row 2 - production with the card removed - PASS (2026-10-05)

1. Power off and remove the card; the image is unchanged.
2. `make smoke-hardware SERIAL_PORT=$SERIAL_PORT`, then reset.
   Expected: `PASS` (the production console binds V9958, so serial carries
   the banner), plus exactly one diagnostic line on the early console
   `vfs: / unavailable 0x03` (`0x03` = `ZOS_ENODEV`; any other `0xNN` is a
   different mount failure and must be recorded), and the tool's note

   ```text
   serial_smoke: note: the optional fs2 root `/` is NOT mounted ...
   ```

   There must be no `iocfat: unavailable 0xNN` line and no `PANIC`.

   **If the note instead says `mounted without a diagnostic` with the card
   out**, the MCU still answered the FS2 root probe, so the card state did
   not reach the provider; that is a bench/firmware observation to record,
   and step 3 below is the discriminating test (a phantom root shows up as
   a failing `fstest` section, not as a missing diagnostic).
3. Operator check: the V9958 display still shows the monitor with a working
   keyboard, and `R`/`Q` behave as in row 1 - `/SYSTEM` and the console are
   unaffected by the missing card.

### Row 2b - the card-state discriminator (only if row 1 and row 2 ever
### look identical again)

Row 2 PASSed, so FS2 does report `NO_MEDIA` and the provider maps it to
`ZOS_ENODEV`.  If a future run ever shows no difference between the two
card states, this is the check that separates the possibilities: the
production image cannot show whether `/` really *works* (no shell yet),
while the acceptance image reads and writes, and its console is SIO, so it
distinguishes them in one run each:

1. With the card: the full transcript of row 3 (`fstest: PASS 4/4`, the
   cache markers, `m9 iocfat selftest: OK`, `Z80> `).
2. Without the card, if media detection works:
   `vfs: / unavailable 0x03` and `m9 iocfat selftest: OK (card absent)`.
3. Without the card, if the MCU still reports a mounted volume:
   no `vfs:` line, and the selftest **fails** at the first real I/O
   (`m9 iocfat selftest: FAIL 0xNN` - record the code).  That outcome is a
   firmware/bench finding, not a provider bug.

### Row 3 - `m9-iocfat-selftest` with a writable FAT card - PASS (2026-10-05)

1. Insert the same writable FAT card.  The image creates and removes its own
   `/ZOSTEST` directory and touches nothing else.
2. Flash `build-m9-iocfat-selftest/zephyros-m9-iocfat-selftest.bin`
   (sha256 `6e803153...`).
3. `make smoke-hardware-m9-iocfat SERIAL_PORT=$SERIAL_PORT`, then reset.
   This image compiles HID and V9958 out, so its console is SIO/SIO: the
   whole transcript is on serial and the monitor runs on that link.
   Expected transcript, in order:

   ```text
   ZephyrOS 0.0 / platform: Zephyr-80 / kernel entry: OK / serial: OK
   console: dynamic sio0.b OK
   m9 iocfat: names:begin ... names:end
   m9 iocfat: cache:0 ... cache:11, cache:stale:arm,
              cache:stale:fresh, cache:stale:end, cache:12, cache:13
   m9 iocfat: fresh read
   fstest: namespace OK / fstest: romfs OK
   fstest: MARK ioc0 ... fstest: MARK io9
   fstest: iocfat OK / fstest: window OK / fstest: PASS 4/4
   m9 iocfat: fstest iocfat section passed
   m9 iocfat selftest: OK
   ZephyrOS native monitor / bank=00 pid=0 scratch=NNNN / Z80>
   ```

   The tool reports `PASS` (it requires `fstest: PASS n/n`, the IOC-FAT
   section marker, `m9 iocfat selftest: OK` **and** the `Z80> ` prompt on
   the same link, and it fails on `vfs: / unavailable`).
   `cache:stale:fresh` is the expected hardware wording: no STALE fault is
   injected here, unlike the simulator replay, which asserts
   `cache:stale:observed` with the fault armed.
4. Operator check: the `Z80>` prompt accepts input over serial (`R`, then
   `Q` relaunches the monitor).
5. Confirm the card is unchanged afterwards (no leftover `/ZOSTEST`).
   Verified on the bench: the volume was empty after the run.

Measured result (862 bytes, 0 USB bridge drops): `fstest: PASS 4/4` with
`namespace`/`romfs`/`iocfat`/`window` OK, every cache marker including
`cache:stale:arm` / `cache:stale:fresh` / `cache:stale:end`, `m9 iocfat:
fstest iocfat section passed`, `m9 iocfat selftest: OK`, and the monitor
prompt `Z80>` on the same link.  The section created and removed its own
`/ZOSTEST`, wrote 1024 bytes through the write-through path and compared
every byte read back across a block boundary, so real card reads and
writes are proven, not only the mount.  The wording `cache:stale:fresh` is
the predicted hardware variant (no injected fault).
6. Optional negative check (not a row): with the card removed this image
   prints `vfs: / unavailable 0x03` and
   `m9 iocfat selftest: OK (card absent)`, and the smoke mode reports a
   failure - the row requires a card, and that wording is the documented
   absent-card behaviour.

### Evidence to record

For each row, append a dated transcript file next to this record:

- the image path and its sha256, plus the ROMFS sha256 the build printed;
- the verbatim serial capture, including the smoke tool's image line, its
  `note: the optional fs2 root ...` observation and its final
  `PASS`/failure line;
- the V9958 display observation (rows 1-2) as the operator's transcription
  of the monitor lines, or a photo/screenshot;
- the programmer and the serial adapter used;
- the `bank7:`/`common:` ledger lines of the flashed build, if they differ
  from section 2.

All three rows are recorded as `PASS` (2026-10-05) with their transcripts
in `2026-10-05-m9-iocfat-provider-hw.txt`.

## 8. Artifacts

New: `fs/iocfat/iocfat.c`, `modules/manifests/iocfat.json`,
`tests/target/m9/m9_iocfat_test.c`,
`tests/target/include/m9_iocfat_selftest.h`,
`tests/m9/manifest-iocfat.json`, `tests/test_iocfat.py`,
`tests/test_iocfat_sim.py`.

Changed: `Makefile` (boot gate, boot set, the acceptance image and its
manifest, the `m9-iocfat-selftest` target, the smoke target),
`config/mounts.json`, `recovery/manifest.json`, `kernel/main.c`,
`tests/z80sim.py` (the FS2 host peer), `tests/target/m9/fstest/fstest.c`
(the mount-selected IOC-FAT section), `tests/target/support/target_test.c`,
`tools/serial_smoke.py` (the `m9-iocfat` mode), and the pinned
expectations in `tests/test_m8.py`, `tests/test_m8_acceptance.py`,
`tests/test_hid.py`, `tests/test_v9958.py`, `tests/test_m9_vfs.py`.

The IOC-FAT section inside the shared `fstest.zex` is deliberately small:
with it added, `zos_scratch` sits at `1F0Bh`, near the end of the 8 KiB
caller window the ZEX contract allows.  The exhaustive cache windows and
the full 8.3 table therefore live in the kernel-side target test, which runs
in the same image and so against the same card on hardware.

## 9. Documentation

* architecture 32.39: slack target lowered to 1 KiB with the measured
  reason, plus the package-30 ledger line.
* architecture 32.12: the `statfs` wording now matches 32.26/32.34
  (deferred until a consumer requires it).
* `docs/vfs.md`: the production mount table, the source layout and the
  optional-root rule.
* `docs/filesystem.md`: new section 17.1 with the implemented provider
  rules (names, paths, handles, cache, writes, errors).
