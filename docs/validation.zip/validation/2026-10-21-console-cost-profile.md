# Console cost profile

## Result

Where a console character's cost goes, answered twice: a simulator
profiler that charges every instruction's T-states to a per-layer bucket
for each console row of the I/O bench, and six new bench rows that
answer the two hardware questions on the board - the V9958's command
time per glyph (`vdp.hmmm`) and the CPU's direct VRAM write rate under
the WAIT line (`vdp.direct.on` / `vdp.direct.off`).  No production code
changed; the production image is byte-identical.

## Files

- `tests/bench/iobench.c` - six rows after `con.write`: `con.mixed`
  (2,000 characters of `ls -l`-style lines, eight 256-byte writes),
  `con.space` (2,000 spaces), `con.held` (the con.write text while the
  bench holds the VDP: the whole call chain, staging and drop path, no
  rendering), `vdp.hmmm` (while held, 2,000 back-to-back HMMM copies of
  6x8 from the atlas, then 1,000 of 12x8, each waiting for CE),
  `vdp.direct.on` / `vdp.direct.off` (while held, 2,000 glyph-sized
  direct writes - per glyph, eight unrolled "set the VRAM address, three
  OUT (A0h)" blocks - with sprites on / R#8 sprites off).  The held and
  VDP rows bind `/dev/video` exclusively before the batch and release it
  before the row prints; on a console without a video driver they print
  `SKIP no video`.  The header comment lists the rows.
- `tests/test_io_sim.py` - `BENCH_ROWS` widened with the six new names;
  the four video rows assert their `SKIP no video (-5)` form on the fs
  image (its console is serial and publishes no `/dev/video`).
- `tests/console_profile.py` - the profiler (script, not a unittest).

## The simulator profile

`python3 tests/console_profile.py` splices `iobench.exe` into the
production store, boots the image to the shell and runs the bench.  A
row's span runs from the first entry to the row's key call (after the
row's first clock reading) to the CALL that starts the row's second
clock reading - the bench's own instrument, which it subtracts.  Buckets
come from the driver plan, the driver reports, the link maps and a
regenerated `v9958_io.asm` listing aligned on
`_v9958_io_wait_command`; `_v9958_io_stream_indirect` is attributed
through its last CALL site.  The bench's subtraction underreports by one
clock reading (it removes two readings although only one falls inside
the interval), so the check adds the calibration loop's measured reading
cost (11,686 T-states) back.

T-states per character per bucket:

| bucket | con.putchar | con.printf | con.write | con.mixed | con.space | con.held |
|---|---:|---:|---:|---:|---:|---:|
| SDK and libc (program) | 544 | 748 | 15 | 15 | 15 | 15 |
| syscall gate and kernel IPC | 276 | 227 | 175 | 225 | 175 | 97 |
| console driver | 9 | 9 | 5 | 5 | 5 | 5 |
| V9958 dispatch and staging | 20 | 20 | 18 | 18 | 18 | 18 |
| wrapper (private stack, R#8) | 7 | 7 | 7 | 7 | 7 | 6 |
| parser (term_feed) | 3 | 3 | 3 | 7 | 3 | 0 |
| fast path (term_write) | 330 | 330 | 344 | 339 | 344 | 0 |
| command setup (out_flush) | 680 | 372 | 388 | 647 | 351 | 0 |
| CE wait | 3,392 | 1,752 | 1,824 | 3,318 | 1,885 | 0 |
| SAT writes | 18 | 20 | 21 | 35 | 21 | 0 |
| scroll | 5 | 12 | 12 | 16 | 12 | 0 |
| other | 79 | 97 | 101 | 141 | 101 | 11 |
| bench total | 5,368 | 3,603 | 2,919 | 4,780 | 2,943 | 155 |

`other` is named: terminal glue 5-7, C worker 9-10, timer interrupt
3-5, v9958 remainder 0-120, unclassified 0.

Bucket sums against the bench's own totals, per row: con.putchar +554
(0.01%), con.printf +190 (0.00%), con.write -22 (0.00%), con.mixed
-2,141 (0.02%), con.space -132 (0.00%), con.held +178 (0.06%).  All
inside the 1% rule.

What the numbers say, simulator side (the CE figures are CPU-side
polling against the model's fixed 400-instruction command busy):

- `con.putchar` spends 63% of the character in the CE wait: one command
  per call, never paired.  `con.printf` and `con.write` pair consecutive
  codes into one 12x8 copy and nearly halve the CE wait; `con.mixed`
  breaks the pairs and pays the same wait as `putchar`.
- `con.write` amortises the SDK and libc to 15 T-states per character
  (one 256-byte call carries 256 bytes); `printf` pays 748 for its
  per-byte formatting and buffering.
- `con.held` is the chain without rendering: 155 T-states per character
  (gate and IPC 97, staging 18, wrapper 6, worker 10).  The drop happens
  before any command, SAT or scroll cost.
- The command setup (the HMMM block build and the 15 indirect writes)
  costs 351-680 per character, the fast path 330-344.

Profiler run time: about 56 s of stepping (informational).

## Bench rows

Each row keeps the existing shape (ops/bytes/min/mean/max/per-byte).
The held and VDP rows bind before the batch and release before the row
prints, so the release's display reset never lands inside a measurement
or after the row's line.

## Attribution (board numbers PENDING)

The owner runs `iobench` on the V9958/HID console; the table's board
column is the row's mean, and "board minus simulator" for the CE wait
bucket is the real VDP time versus the model's 400 T-states.  On the
board, `con.write` minus `con.held` is the rendering share.

| row | simulator total | board mean | board minus simulator (CE bucket) |
|---|---:|---:|---:|
| con.putchar | 5,363 | PENDING | PENDING |
| con.printf | 3,604 | PENDING | PENDING |
| con.write | 2,919 | PENDING | PENDING |
| con.mixed | 4,780 | PENDING | PENDING |
| con.space | 2,943 | PENDING | PENDING |
| con.held | 158 | PENDING | PENDING |
| vdp.hmmm6 | - | PENDING | - |
| vdp.hmmm12 | - | PENDING | - |
| vdp.direct.on | - | PENDING | - |
| vdp.direct.off | - | PENDING | - |

The board baseline before this package (owner, after the render
transactions): con.putchar 3,479, con.printf 3,761, con.write 3,071
T-states per character.

## Ceiling estimates

Board figures pending; the formulas are:

- call chain only: chars/s = 10 MHz / board `con.held` per-char;
- with the engine: chars/s = 10 MHz / (board `con.held` per-char +
  `vdp.hmmm6` per copy, or half of `vdp.hmmm12` per copy for paired text);
- with direct writes: chars/s = 10 MHz / (`vdp.direct.on` per 6x8 glyph
  + board `con.held` per-char + the wrapper share of the console rows);
  a port-only ceiling, before any font fetch or expansion.

Simulator-side preview: `con.held` at 155 T-states per character is
about 64,500 chars/s if the call chain were the only cost (the CE waits
and command setup above bring `con.write` to 2,919, about 3,400
chars/s).  SymbOS at 3.58 MHz and 4,500 chars/s is about 795 T-states
per character; the board rows decide how far the chain and the engine
each stand from that.

## Production unchanged

`git diff --stat` touches only `tests/` (the bench, the widened test
regex, the profiler) beside the accepted prior tree; the production
image is byte-identical: `f3e9e5796e841955c76419550a93d4a2957ee8989c918754e5cf30576404521d`
(`build/konaos.bin`).  The profiler boots it and `make check` replays
it.

`iobench.exe`: 17,348 bytes,
sha256 `fd57f3022fc57cf0f8f372098c500f1b06ed5e66a271fffbb0df2a792a1c757c`.

## Validation

```sh
make && python3 -m unittest tests.test_io_sim tests.test_source_layout
python3 tests/console_profile.py
make clean && make check   # once, at the end
git diff --check
```

- `make && python3 -m unittest tests.test_io_sim tests.test_source_layout`:
  55 tests, 0 failures (the fs image rebuilt with the new rows).
- `python3 tests/console_profile.py`: exit 0, six spans profiled in
  55.7 s, every row inside the 1% check (worst 0.06%).
- `make clean && make check`: 873 tests, 116 expected skips, 0
  failures, `make check: OK`; reproducible production image
  `f3e9e579...` (unchanged).
- `git diff --check`: clean.

## Notes and findings

- A static non-const array initialiser in a program creates `_GSINIT`
  content, which sdldz80 appends after the based `_KOS_SDK_DATA` and
  collides with the based `_CODE`; no program had ever initialised one
  before the bench's command template.  The bench copies its template
  from a `static const` table at run time instead.
- The profiler's `other: unclassified` bucket is zero in every row: the
  bucket ranges from the maps cover the whole write path.

## Owner checklist

- Copy `build/konaos.bin` and `build/user/iobench.exe` to the card, run
  `iobench` at the shell prompt on the V9958/HID console, and photograph
  or paste every row.  Run it twice.
- Fill the attribution table's board column and the ceilings above.

## Supervisor review

Reviewed on 2026-10-21 (source and evidence; nothing rebuilt). The
profiler, its bucket closure (worst 0.06%), the `con.*` rows and the
unchanged production image are accepted. The simulator's CE figures are
the model's: `V9958Peer` keeps a command busy for 400 *instructions*
(`Z80.cycles`), as this record says; `WORK.md` called it 400 T-states,
which was the supervisor's error. Findings, to fix before the board run:

1. **Must — `vdp.hmmm` mixes the two widths in one row.** 2,000 6x8 and
   1,000 12x8 copies report one mean, so the board cannot say whether the
   engine is bound per command or per byte, which decides what pairing is
   worth. Split it into `vdp.hmmm6` and `vdp.hmmm12`.
2. **Must — `vdp.direct` is one 6x8 glyph, not a 12x8 pair.** Three
   `OUT (A0h)` per scanline are 6 pixels; the comment's "a 12x8 glyph pair"
   and "one display row of GRAPHIC 6 is 64 bytes" are wrong (a G6 line is
   256 bytes; the stride does not change the write rate). The ceiling
   formula uses the row per 6x8 glyph. The row writes constants: it is
   the port-only ceiling, before any font fetch or expansion, and the
   record says so.
3. **Found outside scope — initialised static arrays in programs.** A
   non-const initialised static array emits `_GSINIT` content that
   sdldz80 places after the based `_KOS_SDK_DATA`, colliding with the
   based `_CODE`. Any program with one fails to link. This is an SDK
   link-layout defect, listed for the supervisor.

## Supervisor fixes (2026-10-21)

Findings 1 and 2 above, fixed by the supervisor in `tests/bench/iobench.c`
and `tests/test_io_sim.py`:

- `vdp.hmmm` is two rows, `vdp.hmmm6` and `vdp.hmmm12`, 2,000 copies
  each (bytes 24 and 48 per copy). Each copy is started and then waited
  for, so a row is setup plus the engine's whole time per copy, never
  overlapped with the next setup; `vdp.hmmm12` against `vdp.hmmm6` says
  whether the engine is bound per command or per byte.
- `vdp.direct.*` is described as one 6x8 glyph of constant bytes (the
  port-only ceiling), and its scanline stride is 256 bytes, one GRAPHIC 6
  line.
- `tests/test_io_sim.py` lists the five video rows and counts their SKIP
  lines from that list.

Validation: `make` and `make fs-selftest` (OK);
`python3 -m unittest tests.test_io_sim.TestTheBenchRows`: 1 test OK;
`python3 tests/console_profile.py`: exit 0, every row within 1% (worst
0.55%, `con.held`), the run reaching the `vdp.hmmm6` line on the
production image. The simulator does not run `vdp.hmmm12` or the direct
rows to completion; the board run covers them. `iobench.exe` 17,422
bytes, sha256
`8a5b2be449fa2913191d827b750870ff10f3b62bba8006ec618a698ec03dca04`.

Owner request (2026-10-21): the VDP rows' display resets wipe the earlier
rows before they can be photographed. The bench keeps each row's mean and
per-byte figure and, after the last row, prints `iobench: summary` and
one `sum:` line per row (or `sum: <row> SKIP`), 19 lines in all.
`TestTheBenchRows` checks every row's summary line. `iobench.exe`
17,877 bytes, sha256
`94b97691d2fcdad397dc93822b1b841022d0ed4229121e74810d8bdb9d666768`.

## Board results (owner, 2026-10-21)

`iobench` summary on the V9958/HID console, image `f3e9e579...`, bench
`94b97691...` (T-states; per character for the console rows, per copy or
per glyph for the VDP rows):

| row | board | simulator | board − simulator (all CE) | CE on the board |
|---|---:|---:|---:|---:|
| ipc.null (per call) | 18,959 | - | - | - |
| con.putchar | 3,479 | 5,368 | −1,889 | 1,503 |
| con.printf | 3,737 | 3,603 | +134 | 1,886 |
| con.write | 3,083 | 2,919 | +164 | 1,988 |
| con.mixed | 3,782 | 4,780 | −998 | 2,320 |
| con.space | 2,682 | 2,943 | −261 | 1,624 |
| con.held | 147 | 155 | −8 | 0 |
| vdp.hmmm6 (per copy) | 3,383 | - | - | - |
| vdp.hmmm12 (per copy) | 4,636 | - | - | - |
| vdp.direct.on (per glyph) | 1,686 | - | - | - |
| vdp.direct.off (per glyph) | 1,631 | - | - | - |

The simulator's CPU-side buckets are exact, so the whole board/simulator
difference is the CE wait. Where the CPU has work between commands
(`con.putchar`), that work overlaps the engine and the real wait is
smaller than the model's.

Ceilings at 10 MHz:

| path | T-states per char | chars/s |
|---|---:|---:|
| call chain only (`con.held`) | 147 | 68,000 |
| HMMM, unpaired (`con.held` + `vdp.hmmm6`) | 3,530 | 2,830 |
| HMMM, paired (`con.held` + `vdp.hmmm12` / 2) | 2,465 | 4,060 |
| direct writes, port-only (`con.held` + `vdp.direct.on`) | 1,833 | 5,450 |
| today: `con.write` / `con.mixed` | 3,083 / 3,782 | 3,240 / 2,640 |
| SymbOS (3.58 MHz) | ~795 | 4,500 |

What the numbers show:

- The call chain is 5% of a character (147 of 3,083); the console is
  bound by the V9958 command engine.
- HMMM has a large per-command cost: a 12x8 copy costs 1.37 times a 6x8
  one (4,636 against 3,383), so pairing pays and realistic text, which
  pairs rarely, runs at the unpaired rate (`con.mixed` 3,782 ≈ `vdp.hmmm6`
  + chain). HMMV fills (`con.space`, 2,682) are not much cheaper.
- Direct writes cost half an unpaired HMMM per glyph and do not depend on
  pairing; sprites off saves 3% there.
- `printf` costs 650 T-states per character more than `console_write`,
  all in the SDK and libc.
