# 2026-11-01 — KonaCommander and KonaEdit use the mouse (package 108b)

Outcome: **accepted** on simulator evidence. Hardware: the owner ran both
programs during the package, with the mouse working; the full checklist
below is PENDING on the final build.

The worker implemented both applications and stopped on a steer (KonaEdit
File > Open). It resumed after the steer was settled, then stopped on its
usage limit. The supervisor finished the remaining tasks: the Makefile
pins, the rerun of the tests, the load-time measurement and this record.

## What changed

- **Names:** `konacmd` → `kc` (`build/user/kc.exe`), `konaedit` → `kedit`
  (`build/user/kedit.exe`): Makefiles, tests, store entries, READMEs,
  usage text.
- **KonaCommander** (`src/kc_ui.c`, `src/kc_serial.c`):
  - a click focuses the pane and selects the entry; a double click
    (500 ms, through the link's timer handle) opens it;
  - the wheel scrolls the pane under the pointer;
  - menu titles, pop-up items and buttons are clickable, and a click
    outside closes the pop-up;
  - in the viewer the wheel pages and a right click returns;
  - the copy confirmation takes clicks through `tui_confirm`.
- **KonaEdit** (`src/ke_ui.c`):
  - in the editing area:
    - a click places the cursor (TAB expansion, sideways scroll, past
      the line end);
    - dragging selects (MARK);
    - the wheel scrolls three lines per notch;
  - menus, pop-ups, message and confirm buttons are clickable;
  - in the file dialog: click, double-click, the wheel, the Name field,
    and Save/Cancel.
- Both programs are placed (they no longer fit one bank with the mouse).
  KonaEdit pins `ke_file.c`, `ke_widgets.c` and
  `libtui.lib(tui_lifecycle.rel)` to far1. KonaCommander's
  `PLACE=libtui.lib(tui_mouse.rel)=resident` makes it placed; the member
  is resident anyway, by the SDK's declared rule.

## Steers

1. **File > Open failed.** The placed KonaEdit's far segment is an xmem
   object; replacing a document needs 16 more, which exceeded the kernel's
   16-object limit. Resolved by package 110 (32 objects). KonaEdit is
   unchanged for it.
2. **Indirect calls and `PLACE=` quoting.** Resolved by package 108
   correction 02:
   - libtui's mouse member is declared resident for every placed program;
   - `kos.mk` quotes the pins itself.

   The apps' literal quotes and their now-redundant mouse pin in KonaEdit
   were removed. Each app's `test_the_mouse_member_stays_resident` checks
   the linked address of `_tui_mouse_enable`, and it passes without a pin
   in KonaEdit.

## Validation (final tree)

| command | result |
|---|---|
| `make sdk` (OS tree) | archive `32a1d267…` |
| `KonaCommander`: `make clean && make && make test` | protocol OK; 10, 8, 5 (1 old + 4 mouse replays) OK |
| `KonaEdit`: `make clean && make && make test` | store OK; 18 OK, including File > Open with a document open in both classes |
| `git diff --check` | clean |

- No expected screen or count was edited.
- Pins changed:
  - the rename pins (requirement 1);
  - KonaCommander `test_project`: `assertLess(end, stack base)` became
    `assertLessEqual` (a placed program's data fills `C000h` up to the
    stack base, `tools/exeplace.py`).
- KonaEdit's `join` budget passes at 1,499,887 against its 1,500,000 cap
  (baseline 1,496,991): tight but deterministic.

## Sizes

| program | before | after |
|---|---|---|
| `konacmd.exe` → `kc.exe` | 38,375 | 53,478 |
| `konaedit.exe` → `kedit.exe` | 45,997 | 59,162 |

Mostly zone fill: both are placed programs now.

## Load time (owner board finding)

On the board, `kedit.exe` opened a ~32 KiB file in about 2 minutes. The
simulator, timed from the launch to the editor's input loop (same OS
image, harness `wait_for_input_loop`), with a text file of 58-byte lines:

| size | `konaedit` (HEAD, baseline) | `kedit` (108b) |
|---|---|---|
| 4 KiB | 80,191,084 T (8.0 s) | 90,460,954 T (9.0 s) |
| 16 KiB | 219,264,540 T (21.9 s) | 228,841,864 T (22.9 s) |
| 32 KiB | 541,499,838 T (54.2 s) | 550,151,955 T (55.0 s) |

- The slowness predates this package: `kedit` is within 2% of the
  baseline.
- It grows faster than the file: about 1.2 s per KiB between 4 and
  16 KiB, and 2.0 s per KiB between 16 and 32 KiB. Something in the load
  path is worse than linear.
- The board's slower link adds to it.
- Not fixed here; it needs a profiling package for KonaEdit's load path
  (store append, line counting, view rebuild).

## Owner checklist

- `kc.exe`:
  - click and double-click entries in both panes;
  - the wheel over each pane;
  - menus by title, an item, a click outside;
  - every button;
  - the viewer's wheel and right click;
  - the copy confirmation by click;
  - the pointer is gone after Quit.
- `kedit.exe`:
  - a click on plain, TAB and sideways-scrolled lines;
  - drag to select, then F8/F9;
  - the wheel;
  - menus by title;
  - a Save As dialog by mouse;
  - File > Open with a document open (ROM `477c10be…`).
- Built files: `UserSoftware/KonaCommander/build/user/kc.exe`,
  `UserSoftware/KonaEdit/build/user/kedit.exe`.

## Found outside scope

- KonaEdit's load time, above.
- KonaEdit pop-ups are drawn at `x = menu × 8`, while the bar titles sit
  at columns 0, 5, 10 and 17. This predates the package; the click
  targets follow what is drawn.
