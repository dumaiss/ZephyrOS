# M10 files on typed handles (package 42b)

Date: 2026-10-09.  Contract: `work/42b-m10-files-on-handles/WORK.md` and
its `correction-01/WORK.md` (architecture 36.24 step 7, sections 36.8,
36.12-36.14, 36.20; decisions 11-16).  The acceptance machinery the
contract's test decisions describe was superseded by correction 01 before
this package closed, so the paper trail is in two reports: this one for
the production switch-over, and
`2026-10-09-m10-files-on-handles-c01.md` for the retirement of the M9
acceptance machinery and the new `fs-selftest` image.

## Result

The production switch-over is implemented and accepted on the simulator.
`FS_*` and the M9 VFS machinery are gone, files live on typed handles:
`fs_open` is `bind` plus a FILE check, `fs_close` is `unbind`, and every
FILE and filesystem operation is an IPC message to the handle's endpoint.
`/FS` is routed by the VFS to IOC-FAT, which is now a bank-6 driver
service rather than an arena module, `/SYSTEM` is served by the in-process
ROMFS provider, `exec` binds the path, requires FILE and streams the
image through FILE calls, and the namespace family (`bind`/`call`/
`unbind`/`ns_enum` plus `chdir`/`getcwd`) is production code: the
`ZOS_NS_HANDLES` build guard and every `#else` half are deleted.

Production artifact: `build/zephyros.bin`
`sha256 d5e816f2e47ace191077f916487e61c65df39e61a0709954aff7b32179e8abec`
(reproduced byte-for-byte by `make clean && make check`; the 42a report
recorded `11a9bd2b...` for the pre-42b image, which this package is
expected to change).

Acceptance image: `build-fs-selftest/zephyros-fs-selftest.bin`
(`make fs-selftest`, correction 01's replacement for the M9 outcome
suites).

| contract item | state |
|---|---|
| FILE protocol: read, write, seek, sync, metadata, data through descriptors | implemented in `kernel/vfs/ns_file.c` and `fs/iocfat/iocfat.c` |
| `mkdir`/`rmdir`/`unlink`/`rename` are filesystem operations in `fs.h` | implemented on the `/FS` namespace protocol; no DIRECTORY handle, no nucleus support |
| FS provider routes `/FS` to the build's driver, holds no FS2 semantics | implemented in `kernel/vfs/ns.c` (`ns_fs_*`, `VFS_NS_FS_ROOT`) |
| IOC-FAT as a driver | `services/manifests/iocfat.json`, class 7, cache in `SERVICE_IO`, IOC dependency host-resolved |
| enumeration and CWD below `/FS` | `ns_enum` through the driver; `chdir`/`getcwd` over the canonical global path |
| `fs.h` on `bind`/`call`/`unbind` | `user/sdk/src/fs.c` |
| `exec` binds a FILE and unbinds before launch | `kernel/process/exec.c`; startup block v1 unchanged |
| `FS_*` (10h-1Fh), `kernel/syscall/fs.c`, the M9 descriptor kinds | deleted |
| paths that named card files as `/...` | moved to `/FS/...` |
| driver hot tier keeps >= 4096 bytes free | the whole driver tier is free: IOC-FAT is a service now (see ledgers) |
| production switch-over and the deletions that make room | done here; the revised test decisions are correction 01 |

## Acceptance criteria (WORK.md)

| criterion | evidence |
|---|---|
| "files work through FILE handles on IOC-FAT (`/FS`) and ROMFS (`/SYSTEM`), with one call path" | `fs-selftest` writes, reads back, seeks, stats, renames, unlinks and enumerates a card file, then reads `/SYSTEM`: both go through `bind` + FILE calls, and the replay reads the driver's slots and the kernel's descriptor table to prove the instances are the same handles |
| "namespace operations need no DIRECTORY handle" | `fs_mkdir`/`fs_rmdir`/`fs_unlink`/`fs_rename` are `SYS_CALL`s on the `/FS` namespace handle with the path remainder; the descriptor table shows no directory instance |
| "`FS_*` is gone" | `abi/zos/syscall.h` keeps only the object and namespace families; `tests/test_sdk.py` and `test_source_layout.py` fail if `FS_*`, `fsgate` or the M9 front end come back |
| "the behaviour holds on hardware" | PENDING (owner): production with and without a card, files under `/FS`, the monitor from `/SYSTEM`, nested exec |
| "the ledgers are within 36.20" | fixed core room 5,089 bytes, cold half ends `AAEEh` with 24 free arena granules, common 2,358 of the 2,560 limit |

## What changed

**Kernel.** `kernel/vfs/` is now the router plus providers: `ns.c` (root
routing, `/dev` publications, `/FS` forwarding, the `/SYSTEM` ROMFS
provider, `bind`/`call`/`unbind`/`ns_enum`/`chdir`/`getcwd`, the handle
table), `ns_file.c` (the FILE protocol for handle instances, in-process
for ROMFS) and `process.c` (the descriptor pool, owner teardown, CWD
pool).  Deleted with their subjects: `mount.c`, `mount_config.h`,
`file.c`, `dir.c`, `mutate.c`, `kernel/syscall/fs.c`, `kernel/device/
registry.c`, `fs/romfs/romfs_provider.c`, the module loader, relocator and
IOC shim, and `kernel/syscall/ipc.{c,h}` (the stage-3 lookup; `06h` is
`bind` and `07h` is `call` now).

**Driver.** `fs/iocfat/iocfat.c` implements FILE and the filesystem
namespace protocol for `/FS`, keeps its 512-byte cache and transfer
staging in `SERVICE_IO`, and publishes `/FS` from
`services/manifests/iocfat.json`.  Its host tests (`tests/test_iocfat.py`)
moved with it.

**SDK.** `user/sdk/src/fs.c` is the FILE/filesystem client over
`zos_ipc_bind`/`zos_ipc_call`/`zos_ipc_unbind`; `fsgate.asm` and the
`FS_*` wrappers are deleted.

## Ledgers (requirement 10)

Production, from `tools/mapcheck.py` on `build/`:

| ledger | value |
|---|---|
| nucleus fixed core | end `42C5h`: 7,668 required + 2,859 overflow + 768 stacks, **5,089 bytes room** |
| nucleus cold half | code end `AAEEh`, data `642` bytes at `DC00h`, 661 bytes room |
| arena | `AC00h-DBFFh`, 24 granules, **0 boot granules, 24 free** |
| driver hot | 0 of 32,768 bytes (IOC-FAT is a service container, not a driver module) |
| driver boot/bulk | 0 of 24,576 bytes |
| common | 2,358 of 7,424 used (code 1,511, data 847); ceiling 3,072, m10 512, limit 2,560 |

Against 42a's projection for production after 42b ("fixed core about
4,782 bytes of room and a 21-granule free arena"): the fixed core came
out **307 bytes better** and the arena **three granules better**, and the
arena boot set is empty as intended.

## Acceptance evidence

```sh
make clean && make check
make fs-selftest ns-selftest ipc-selftest console-integration-selftest
git diff --check
```

| command | result |
|---|---|
| `make clean && make check` | OK; reproducible rebuild of `build/zephyros.bin`, full host suite, mapcheck 20 areas / 329 symbols, `make check: OK` |
| `make fs-selftest` | OK: 3 replay cases (writable card 35/35, absent card 8/8, handle-release run) |
| `make ns-selftest` | OK: 23 tests, client 76/76 checks |
| `make ipc-selftest` | OK: 53 tests, client 54/54 checks, probe 23/23 checks |
| `make console-integration-selftest` | OK: 6 tests |
| `git diff --check` | clean |

Hardware validation is **PENDING (owner)**: the four items in the
contract's hardware list.

## The coverage map for the retired M9 file-operation suites

Correction 01 deleted the M9 file-operation tests rather than porting
them; each outcome they covered has one home now:

| M9 outcome | where it is checked now |
|---|---|
| create a file | `fs-selftest`: `fs-open-create` (plus the driver's own host tests) |
| write | `fs-selftest`: `fs-write-blocks`, `fs-close-write` |
| read | `fs-selftest`: `fs-read-head`, `fs-read-cross-block`, `fs-read-tail`, `fs-read-eof` |
| seek | `fs-selftest`: `fs-seek-set`, `fs-seek-end`, `fs-seek-cur` |
| readdir | `fs-selftest`: `enum-root-system`, `enum-root-fs`, `enum-card-file`, `enum-card-subdir`; and the `/SYSTEM` enumeration in `ns-selftest` |
| mkdir | `fs-selftest`: `fs-mkdir`, `fs-mkdir-stat` |
| unlink | `fs-selftest`: `fs-unlink`, `fs-unlink-gone` |
| rename | `fs-selftest`: `fs-rename`, `fs-rename-stat`, `fs-rename-old-gone` |
| card absent | `fs-selftest` absent-card replay case (8 checks: console, `/SYSTEM` stat/open/read/close, exec) |
| nested exec from `/SYSTEM` with a tail and exit status | `fs-selftest`: `exec-status` plus the child's own stdout |
| leaked handles released at exit | `fs-selftest` release run: driver slots and `vfs_descriptors` read out of the machine |

## What the package found and fixed while accepting itself

The acceptance images were written against the new model, not ported, and
they paid for themselves immediately: five real defects and one latent
one were found and fixed.  They are production fixes, so they are part of
this package rather than test noise.

1. **Cross-block file reads delivered block-aligned bytes.**  A 64-byte
   read at offset 500 of a 512-byte-block file returned the cached block's
   *first* 64 bytes: `iocfat_file_read()`'s chunked loop copied every
   cache slice to the same staging address.  Fixed with
   `iocfat_copy_range()`, which takes the destination offset as an
   argument (`&global[runtime index]` is refusable by the module packer,
   mode 09h).
2. **`/FS` root enumeration passed the driver a pointer it could not
   read.**  `ns_enum_fs` staged the kernel's literal `"/"`, but the driver
   window maps bank 6, not the image, so the driver read `FF FF` and
   answered `-ZOS_EINVAL` with no wire traffic at all.  `ns_fs_root_path()`
   now stages the root spelling in the path view's spare slot; the same
   latent bug covered `zos_stat("/FS")` and friends.
3. **The common gate stack was 256 bytes and the nested-exec chain needs
   287.**  The chain (exec -> ROMFS read -> provider and driver
   transaction) overran into `zos_gate_saved_sp/latch`, and the parent
   resumed in a corrupt mapping: a mode-fault panic on the next syscall.
   `ZOS_GATE_STACK_SIZE` is 384 now (`platform/zephyr80/memory.{h,inc}`),
   the way the M8 console fix handled the same class of fault.  Accounting
   alone never catches this: the depths have to be measured in the
   simulator, and both `tools/mapcheck.py` and `tests/maptools.py` were
   carrying the old 256.
4. **Process exit leaked its standard handles.**  `vfs_process_exit()`
   went through `vfs_ns_unbind()`, which refuses handles below
   `ZOS_HANDLE_FIRST_BOUND` (a live program must not drop its console), so
   every exited process left two entries in the 12-slot global table - and
   a launcher that relaunches the boot program exhausts it.  Factoring
   `vfs_ns_release_desc()` out of the unbind path let the teardown release
   every descriptor the pid owns.
5. **ZEX v1 forbids initialised writable data** (`static int card = 1;`
   made the linker place `_INITIALIZED` at the code base and `zexpack`
   refused the container with "conflicting content for 015Fh").  The
   program was fixed; the packer's diagnostic deserves a clearer message
   in a later package.

The replay instrument itself had one premise to correct: a call's span
must end at the real return (`pc`, the caller's SP *and* the caller's
latch), because the fixed-core SDK puts several call sites at one
address; `pc == ret` alone ends a span when the next call is entered from
there.

## Open items

- Hardware: the four items above (owner).
- Residual M9-era narrative in `docs/` where it describes machinery this
  package deleted but the *outcome* is unchanged (`docs/filesystem.md`,
  `docs/vfs.md` section 13, `docs/memory.md`'s arena notes): 42c's
  pruning, recorded here so it is not lost.
- `kernel/module/arena.asm` and the `GEOMETRY_*` constants are kept
  deliberately (the granule allocator is still part of the derived-arena
  plan); only the loader, relocator, registry and IOC shim were deleted.
- `include/zephyros/{driver.h,vfs.h}` are pruning candidates for 42c.
- `zexpack`'s message for an initialised writable area, and the packer's
  refusal of `&global[runtime index]` - both cost debugging time and both
  are worth a better diagnostic in a later package.

## Supervisor review (2026-10-09)

**Accepted, together with correction 01**, on the records' evidence, with
hardware pending (owner: `make smoke-hardware-fs`, production with and
without a card, files under `/FS`, the monitor from `/SYSTEM`, nested
exec).
- Production `d5e816f2…`.
- The fixed core has 5,089 bytes of room, 307 better than projected.
- The new outcome images found five real defects and fixed them.
- 73 files and 13,416 lines of retired machinery are gone.

Findings:
1. **The driver ledger is mis-reported.** The production ledger prints
   `driver hot 0 of 32,768`, but `build/modules/services.plan.json` holds
   the real figure: **21,838 of 32,768** (about 10.9 KB free, above the
   4 KB target), with boot/bulk at 2,170. `pack_image` lost the plan's
   input in 42b. → Fixed in 42c.
2. **The gate stack was raised from 256 to 384 bytes** to fix a real
   overflow (the nested exec → ROMFS read → driver chain needs 287
   bytes). This is a capacity raise that the contracts say to stop and
   report. → Owner decision required (see below); architecture 36.9/36.20
   still says 256.
3. **The arena is dead weight:** 24 free granules (12,288 bytes of the
   cold half) reserved with no tenant, plus `arena.asm` and the
   `GEOMETRY_*` constants. → Deleted in 42c (dead code first).
4. **The global handle table has 12 entries.** `ipc-selftest` exhausted
   it with a parent holding handles across exec. → Watch item for the
   M12 shell; programs should release their handles before exec.
5. Pruning candidates `include/zephyros/{driver,vfs}.h` go to 42c, the
   residual M9 docs narrative to 42d, and the `zexpack` diagnostics to
   44a (the v2 packer).

### Hardware (owner, 2026-10-09)

On production `d5e816f2…`:
- **Boot: PASS.** The V9958 shows `console: service OK`, the native
  monitor banner (`bank=00 pid=0`) and the `Z80>` prompt. The boot
  program is the monitor loaded from `/SYSTEM`, so exec through the new
  bind/FILE path works on hardware.
- Not run this session: files under `/FS` on a card, the card-absent
  boot, and nested exec from the monitor. These carry into the next owner
  hardware pass (42e/45).
