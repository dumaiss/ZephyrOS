# M10 prune of the nucleus (work package 42c)

Work package: `work/42c-m10-prune-nucleus/WORK.md` (M10 step 8,
architecture 36.24).  This is **deletion work**: the abstractions M10 made
obsolete are gone, `ZMOD` is a plain host-linked service image with a flat
load plan, residency has two tiers, the arena reservation is deleted, the
bank-6 driver ledger is reported from the services plan, and `main.c`'s
boot path carries no module/arena code.  Behaviour is unchanged and the
production bytes shrink.  The working log is
`work/42c-m10-prune-nucleus/progress.md`.

## 1. Bytes removed per item

The supervisor inventory in `WORK.md` lists production object sizes after
package 41; the items 42b had already removed are listed with their
inventory size and verified gone.  The service-loader figure is measured
from the linked object in both trees (`build/service_loader.rel`: `_WINDOW`
+ `_WINDOW_DATA`); every other 42c figure is measured the same way.

| # | item | bytes removed | how it is gone |
| --- | --- | --- | --- |
| 1 | bank-7 driver arena (the reservation itself) | **12,288** bytes of bank-7 space (24 granules x 512 B) | no `GEOMETRY_*`/arena derivation, no `__driver_arena_*` symbols, no `arena` object in the image manifest; the cold data base derives straight from the cold code end |
| 2 | `kernel/module/arena.asm` | 60 lines (it declared the reservation) | file deleted; `kernel/module/` no longer exists |
| 3 | service loader's container re-validation (`service_read_layout` and its tables) | **3,136** of the loader's 5,122 linked bytes | loader rewritten to iterate the flat plan with protective bounds only: 5,122 -> 1,986 (section 4) |
| 4 | dead packer command `zmodpack.py emit-asm` and its fixtures | 62 tool lines; `tests/modules/` (447 lines) and `tests/subsys/gen_zmod_fixtures.py` (49) | the arena loader's self-test fixtures had no consumer left |
| 5 | `zdriver_api` and the driver-ABI contract | `include/zephyros/driver.h` (96 lines) | deleted; a service image receives `struct ipc_service_boot` and has no import table |
| 6 | device class/capability model | `include/zephyros/device.h` (202), `include/zephyros/hid.h` (88), `include/zephyros/video.h` (86), `include/zephyros/block.h` (84) | deleted with `kernel/device/`; reachability is the host-built endpoint/publication tables |
| 7 | every driver ops table (`zchar_ops`, `zioc_ops`, `zvideo_ops`, `zhid_ops`, `zblock_ops`) | 0 linked bytes (the tables were dead or driver-private) | the definitions and their users are gone; a driver's dispatch is called through its endpoint |
| 8 | provider ops-table interface and registration path | `include/zephyros/vfs.h` (90), `kernel/vfs/file.c`, `dir.c`, `mutate.c`, `fs/romfs/romfs_provider.c` | deleted; the FS service image publishes `/FS` and VFS reaches it through its one in-kernel FS path |
| 9 | module-loading VFS phase and its boot code | the phase symbols, `kernel/module/loader.c`, `relocate.c` | deleted (42b); the service loader places the images and nothing registers |
| 10 | runtime version fields | `ZDRIVER_ABI_VERSION`, the service-API `version` entry, the format version byte | deleted; the packer validates on the host |
| 11 | M9 mount machinery | `tools/mountgen.py` (275 lines), `config/mounts.json` (17), `kernel/vfs/mount.c`, `config/mounts.json` consumers | deleted; `/FS`, `/SYSTEM` and `/dev` are static roots |
| 12 | `include/zephyros/module.h` | 253 lines (M4 container/loader ABI) | deleted; the service image header `include/zephyros/service.h` is the one format |
| 13 | arena/module loader, module relocator, device registry, IOC shim, M9 `fs` | 1,874 + 2,097 + 1,624 + 1,157 + 2,727 = **9,479** (removed by 42b; verified gone) | no such objects or sources are linked or present |
| 14 | tests whose subject is removed | 958 (`test_driver_abi.py`) + 768 (`test_v9958_console.py`) lines | deleted with a reason each (section 6) |

Nucleus total: the linked production objects are **3,084 bytes smaller**
than at the start of 42c: the service loader lost 3,136 and one byte went
in `kernel/ipc/ipc.c`, while `kernel/process/exec.c` gained 53 for the
media gate of section 4 (the rest of the nucleus links byte-identically
once the placement tiers are applied).

## 2. The five ledgers, before and after

Before = the 42b source (`git` HEAD when 42c started), after = this
package.  All figures are the production `make` ledgers.

| ledger | before (42b) | after (42c) |
| --- | --- | --- |
| fixed core | `code end 42C5h, 7668 required + 2859 overflow + 768 stacks, room 5089` | `code end 3C9Bh, 8179 required + 2 overflow + 768 stacks, room 7435` |
| cold code | `19182 bytes end AAEEh` | `17845 bytes end A5B5h` |
| cold data | `642 bytes at DC00h, room 656` | `1241 bytes at A600h, room 13607` |
| common | `used 2358 of 7424 (code 1511, data 847), ceiling 3072, m10 512, limit 2560` | unchanged |
| bank-6 services | `driver hot 0 / boot-bulk 0` printed, plan 21838 / 2170 | `driver hot 22013 / boot-bulk 2170`, printed from the plan |

What the moves mean:

- the 12,288-byte arena reservation is gone, and the cold data base now
  follows the linked cold code (`A5B5h` code end -> `A600h` data base)
  instead of the fixed `DC00h` the arena pushed it to; the cold half's
  spare room grew from 656 bytes to 13,607;
- the fixed core no longer overflows by 2,859 bytes: everything 36.5
  classifies `fixed-required` now links inside `2000h-5FFFh` with 7,435
  bytes free.  The VFS path/handle/workspace objects moved to `cold`
  because they execute (and, for the workspace, are read by a bank-6
  dispatch) with the window showing bank 7.

## 3. Bank-6 driver bytes

| image | before (42b) img+bss | after (42c) | delta |
| --- | --- | --- | --- |
| sio | 940 | 937 | -3 |
| ioc | 5068 | 5059 | -9 |
| hid | 1523 | 1717 | +194 |
| v9958 | 7152 | 7150 | -2 |
| console | 417 | 416 | -1 |
| iocfat | 8908 | 8904 | -4 |

The **+175** on the `driver hot` ledger is the sum of that column.  It is
not a service change: removing the `version` entry from
`struct ipc_service_api` (requirement 3) changes SDCC's register
allocation in `hid_fetch`, and `hid` alone grows 194 bytes (the other five
images shrink by 19).  Re-inserting a padding byte in the interface table
reproduces `hid._CODE = 1461`, so the effect is the documented codegen
shift, not a new code path.

## 4. The loader: a flat plan, 1,986 bytes

`kernel/service/service_loader.c` now reads the packer's flat plan once,
front to back, and checks only the bounds that protect the nucleus and the
fixed driver-bank layout (36.11, M10-REFERENCE decision 2): the header's
counts against the loader's tables, each segment's allocation inside its
role's tier (with a 16-bit wrap guard), the boot entry inside the boot
image, the hot init inside the hot image, each endpoint number non-zero
(dependency numbers are checked against what the nucleus installed) and
each publication record terminated.  There is no version check, no
`service_read_layout`, no table index search.

| step | code | data |
| --- | --- | --- |
| 42b loader (before) | 4,952 | 170 |
| after the flat-plan rewrite | 1,985 | 1 |

Final: **1,986 bytes** (1,985 code + 1 data, measured as the object's
linked `_WINDOW` + `_WINDOW_DATA` areas) against the 2,000-byte target of
the 41b review.  The last 30 bytes came from the failure words
(`copy`/`endpoint`/`publication`/`invalid` instead of the longer phrases);
the messages are documented in `docs/module-format.md` section 7.  The
evidence lines (`driver <name>:`, the two ledgers) stay acceptance-only:
production links the failure line only.

Bugs found and fixed while making the plan work:

- **table read order.**  The rewritten loader read the publication table
  before the dependency table; the packer writes
  segments -> endpoints -> dependencies -> publications, so every image
  with dependencies (hid, iocfat, console) mis-read its records and the
  loader refused the image with "publication refused".  Diagnosed by
  replaying the production image in `z80sim` and by comparing the
  packer's `build_service_container` record order with the loader's loops;
  fixed by swapping the two loops.  `iocfat`'s resolved IOC number is now
  `2` in the fs image (it is what the driver reads from its boot bundle).
- **`driver boot/bulk` printed 0.**  The rewritten ledger classified a
  `boot` segment as hot (`role <= ZMOD_SEGMENT_IO`); fixed to
  `role == HOT || role == IO`, and the line now equals the packer's
  `services.plan.json` ledger (`tests/test_console_acceptance.py` reads the
  plan instead of pinning the figures).
- **`vfs_workspace` residency (real regression).**  The two-tier pass had
  classified the VFS workspace `cold`.  A bank-6 dispatch receives the
  protocol frame - which lives in the fixed core - with the path *address*
  in it, so the workspace is read while the window shows bank 6 and must
  be `fixed-required` (36.5).  With it cold, `iocfat` read `0FFh` as the
  path and refused the SDK's `/FS` open with `EINVAL`:
  `make fs-selftest` printed `fs-selftest: card not writable` and the
  nested-exec child failed.  Fixed in `config/residency.json` (with the
  reason recorded in the entry) and in the Makefile, which now rebuilds
  the classified objects when the residency file changes.
- **role presented as absent at address 0.**  The loader's plan line
  printed a role only when its base was non-zero, so a boot segment placed
  at `0000h` (the bottom of the boot tier) vanished from the line the
  acceptance replay compares with `zmodpack.py services`.  The roles now
  carry an explicit `SERVICE_ROLE_ABSENT` sentinel.  Found by
  `make ipc-selftest`; production bytes are unaffected (the line is
  acceptance evidence).
- **`make subsystem-selftest` repaired (two 42b gaps).**  The target did
  not build at 42b (`_module_get`/`_module_count` undefined, and its
  manifest still named the m4 fixture containers that 42b had deleted), so
  its replay had not run since the arena was retired.  With the image
  building again, two real gaps surfaced: the loader accepted
  `zex-wrong-type.dat` - a `DATA` entry holding a valid ZEX image -
  because the namespace bind carries no exec intent, so 42b lost the M6
  media gate (restored in `process_prepare`: an executable under
  `/SYSTEM` must be a `ROMFS_FLAG_ZEX` entry, `ZEX_EXEC_ERR_TYPE`
  otherwise), and `service_cli_write()` wrote through the early console
  but returned 0, so the ROMFS and process groups' final console checks
  could never pass (it now returns the byte count it wrote).  The target
  passes with every result word zero.
- **latch-audit false positive.**  `tests/test_validation_cli.py`'s
  cold-half latch audit matched operand bytes: SDCC's `ld -45(ix),#0`
  emits `DD 36 D3 00`, which contains the `D3 00` latch-write pattern.
  `tools/pack_image.py` now decodes instructions (a Z80 length table
  including the `DD`/`FD` prefixes and `(IX+d)` displacement, anchored at
  map symbols) and flags `D3 00` only at a decoded instruction boundary;
  `tests/test_validation_cli.py` gained the regression case.

## 5. Residency, geometry and tooling

- `config/residency.json` has exactly two tiers, `fixed-required` and
  `cold`, one entry per linked kernel object, each with its reason; the
  `moves`/`overflow` machinery is gone from the file and from
  `tools/mapcheck.py`.
- `tools/mapcheck.py` derives the geometry from the probe link: the fixed
  core's data base from the fixed data size, and the cold data base
  straight from the linked cold code end (`bank7_end.asm` exports
  `__kernel_code_end`).  There is no arena, no boot plan and no granule
  accounting.
- `tools/pack_image.py` prints and stores the real bank-6 ledgers from
  `services.plan.json`, and the nucleus ledgers without an arena column.
- `tools/zmodpack.py` consumes and emits the flat container only
  (16-byte header, four tables, payload); `parse_container` is the single
  authority and rejects anything the loader would have to re-validate.

## 6. Tests deleted, with reasons

| test / fixture | subject that was removed |
| --- | --- |
| `tests/test_driver_abi.py` (958 lines) | the driver ABI: the import table, `device_register`, the registry transaction and the arena/module layout it reconciled |
| `tests/test_v9958_console.py` (768 lines) | the `zchar_ops` console-device contract; the character path is the VIDEO endpoint's write operation, covered by `tests/test_v9958.py` |
| `tests/modules/` (7 files) | the arena loader's fixtures: `abi_probe`, `m4_fail`, `m4_filler`, `m4_probe` and their manifests |
| `tests/subsys/gen_zmod_fixtures.py` | the generator of the malformed-container fixtures |
| `tests/target/loader/` group and its manifest entries | the arena loader: relocation, rollback and arena exhaustion (the subsystem image now carries the syscall, IRQ, ROMFS and process groups) |

Reconciled instead of deleted: `tests/test_zmod.py` (flat container, no
ABI/type/relocation), `tests/test_pack_image.py` (ledger suite instead of
granules), `tests/test_source_layout.py` (service-facing header boundary,
retired owners negative test), `tests/test_service_images.py`,
`tests/test_ipc_selftest.py`, `tests/test_ns_selftest.py`,
`tests/test_console_acceptance.py`, `tests/test_iocfat.py`,
`tests/test_hid.py`, `tests/test_ioc.py`, `tests/test_v9958.py`,
`tests/test_subsys_sim.py`, `tests/maptools.py` and the subsystem
manifest.

## 7. Docs

`docs/module-format.md` is rewritten as the service-image format (header,
four tables, placement, ledgers, publications, boot path, loader budget;
its historical name is kept deliberately - the container is still the ZMOD
container).  `docs/devices.md` keeps the M8/M9 driver record but its
sections 1-3, 8 and 12 now describe the service model, the delete list and
the current protocols.  `docs/filesystem.md`, `docs/vfs.md`,
`docs/architecture.md`, `docs/memory.md`, `docs/romfs-format.md` and
`README.md` carry the same prune: the mount table, the provider ABI, the
device registry, the block class, the arena and the module-loading VFS
phase are marked retired where they were described as current, and the
grep gate of section 9 is empty outside the validation and work
directories.

## 8. Validation

```sh
make clean && make check
make fs-selftest
make ns-selftest
make ipc-selftest
make console-integration-selftest
make console-fallback-selftests
make subsystem-selftest
git diff --check
```

The M9 acceptance targets `WORK.md` names (`m9-selftest`,
`m9-exec-selftest`, `m9-iocfat-selftest`) do not exist: they were retired
at the start of M10 with the M9 outcome images, and their successors are
the current images above - `fs-selftest` is the M9 filesystem outcome
image's replacement (`/FS` writes, reads, seeks, renames, unlinks and
enumerates through FILE handles), `ns-selftest` the namespace/handle
outcome image, and the console/ipc images the device-stack and IPC
substrate outcomes.

Results (final source, clean rebuild):

| command | result |
| --- | --- |
| `make clean && make check` | reproducible rebuild `b0b8def1f0c83ba2f3707eab8e167c8431eeae1b060e35639787c5f92c034c80`; 560 host tests, 0 failures (111 skipped: image-dependent replays) |
| `make fs-selftest` | 3 replay cases OK: writable card 35/35 checks, absent card 8/8, handle-release run |
| `make ns-selftest` | 23 tests OK |
| `make ipc-selftest` | 53 tests OK (the service-image replay compares every `driver <name>:` line and both ledgers with `services.plan.json`) |
| `make console-integration-selftest` | 6 tests OK |
| `make console-fallback-selftests` | 3 tests OK (`nohid`, `nohid-nov9958` compositions) |
| `make subsystem-selftest` | 4 replay tests OK: syscall/IRQ/ROMFS/process groups, every result word zero, the monitor session and its relaunch |
| `git diff --check` | clean |

Grep gate (the `WORK.md` list) is empty outside `docs/validation/` and
`work/`: no `zdriver_api`, no device-class or ops-table identifier, no
provider interface or registration, no module relocator, no IOC shim, no
module-loading VFS phase and no driver-ABI version survives anywhere in
the source, tools, tests, Makefile or docs.

**Hardware: pending.**  `make smoke-hardware`, and production with and
without a FAT card, are the owner's runs; the simulator and image evidence
above is what this package can close.

## Supervisor review (2026-10-10)

**Accepted** on the record's evidence, with hardware pending (owner).
- Production `b0b8def1…`.
- The fixed core has 7,435 bytes free with no overflow; the cold half has
  13,607 free; driver hot is 22,013 of 32,768, now reported from the plan.
- The loader is 1,986 bytes (target 2,000).
- The grep gate is empty, and the deletions came with their reasons.
- A real residency regression (`vfs_workspace`) and the lost `/SYSTEM` ZEX
  media gate were found and fixed.

Carried forward: `mapcheck` still enforces the M9 common limit of 2,560
bytes (2,358 used). M10 is entitled to the 3,072 ceiling (36.20), so
package 43 lifts the enforced limit to the ceiling.
