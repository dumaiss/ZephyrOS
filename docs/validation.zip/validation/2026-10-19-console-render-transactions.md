# Console render transactions

## Result

The TUI output path now submits one bounded render stream per flush.  The
V9958 console forwards that stream as one `KVIDEO_OP_RENDER` transaction;
attribute-only normal/reverse changes use LMMV/EOR over the existing pixels
instead of repainting glyphs.  The serial console rejects the extension with
`-KOS_ENOTSUP`, and `libtui` retains the accepted ANSI dirty-run fallback.

No kernel, filesystem, timer, sound or console-client behavior changed.  The
monitor identity remains the accepted 6,790-byte image with hash
`3f73f28b46ee928d08917045f68f9152b470339729da3264c6d6ea3f59bbce49`.

## Files

Added:

- `abi/kos/console_render.h` - v1 stream header, TEXT/INVERT/STATE records
  and the pinned 85 x 26 bounds.
- `user/sdk/src/console_render.c` - `console_render()` as its own libkos
  member, so clients that do not use RENDER keep their previous link size.
- `docs/validation/2026-10-19-console-render-transactions.md`.

Materially changed:

- `abi/kos/protocol.h`, `drivers/console/console_proto.c` - CONSOLE and VIDEO
  operation numbers and forwarding.
- `drivers/v9958/v9958_proto.c`, `drivers/v9958/v9958.c`,
  `drivers/v9958/v9958_io.asm`, `drivers/v9958/v9958_driver.h` - validation,
  private-stack execution, LMMV/EOR and the transaction boundary.
- `user/sdk/tui/src/tui_flush.c`, `tui_internal.h`, `tui_screen.c`,
  `tui_state.c`, `tui_lifecycle.c` - dirty/invert classification, bounded
  stream construction and fallback caching.
- `user/sdk/include/kos/console.h`, `user/sdk/include/tui.h` - the low-level
  entry and the unchanged public TUI surface.
- `tools/modpack.py` - deterministic placement backfill for smaller hot
  segments below the driver I/O block.
- `platform/zephyr80/public/hardware.h`, `hardware.inc` - sprites-off bit.
- `docs/tui.md`, `docs/sdk.md`, `docs/abi.md`, `docs/devices.md`,
  `docs/architecture.md` - current behavior and the lowered hot reserve.
- `tests/tui/tui_test.c`, `tests/test_tui.py`, `tests/test_tui_sim.py`,
  `tests/test_v9958.py`, `tests/test_sdk_package.py`,
  `tests/test_monitor.py`, `tests/test_stdio.py` - transaction, replay,
  malformed-stream, split/fallback and link/package coverage.
- `UserSoftware/KonaCommander/*` - the intended TUI-based UI conversion.

## Validation

```sh
make clean && make check
make console-serial-selftest
python3 -m unittest tests.test_tui_sim.TestTuiSerialScreen
make -C UserSoftware/KonaCommander test
git diff --check
```

- `make clean && make check`: **859 tests, 116 expected skips, 0 failures**;
  final `make check: OK`.  The skips are images the clean gate does not build.
- Reproducible production image:
  `be2ab1867b574bd2282dcfa2662098a2c1fad7626a2df509919dc21eff8a3ca4`.
- `make console-serial-selftest`: **6 tests, 0 failures**, including the
  serial image and both failure stores.
- `TestTuiSerialScreen`: **20 tests, 0 failures**.
- KonaCommander: host **10**, project **7**, UI replay **1**, all passing.
- `git diff --check`: clean.

The full TUI simulator run covered **41 tests**.  One shutdown assertion was
stale because it compared the complete post-program write list, including a
3-byte shell prompt write; it was corrected to compare the program's
shutdown and pass writes.  The focused rerun and the clean gate pass.

## Measurements

TUI example artifacts after the final build:

```text
tui_test.exe    35,879 bytes  sha256 89a78579a5721b37458fe106f0a0dd5444d6162aea11414f47cabdcb7eb65d0f
tui_dialog.exe  20,955 bytes  sha256 624323c8c4ec3c272b2fa141a19b46dadfb2a41c2f7d1a463e0489ab0b797e38
```

KonaCommander menu movement, measured on the production image.  The control
is the same final source built with `console_render()` overridden to return
`-KOS_ENOTSUP`, which exercises the ANSI fallback; the production binary uses
the RENDER path.  Both runs move Right 100 times after F1 focuses the menu bar:

```text
fallback control (83b8d9cf...):  3,400 console bytes, 0 render calls
                                 800 glyph/text cells, 23,380,356 T-states
final production (f0e75e46...):  3,000 render bytes, 100 RENDER calls
                                 200 LMMV/EOR operations
                                 0 glyph/text cells, 0 cursor-SAT writes
                                 36,120,304 T-states
```

The production move stream is two INVERT spans plus the final STATE record;
neither complete menu labels nor the whole menu bar are sent as TEXT.  The
T-state count rises because the CPU waits for each V9958 command to present;
WORK explicitly allows raw throughput not to improve, and the visual work
(glyph/text redraws and console bytes) is lower.

Driver placement after the final build:

```text
driver hot used   30,642 / 32,768 bytes
driver hot free    2,126 bytes
```

The package-65 baseline used 29,180 bytes, so this feature consumes 1,462
bytes of the driver hot tier.  The owner accepted that larger delta; the
final set still keeps more than 2 KiB free and the host backfill plan passes
its overlap and embedded-base checks.

SDK package:

```text
kos-sdk-0.2.0.tar.gz  55 files
sha256                a148bbced7294707cace6d9ed884f100d0052a1a75e350bf0d9cb11d76a2187a
```

Acceptance artifacts:

```text
build/konaos.bin
be2ab1867b574bd2282dcfa2662098a2c1fad7626a2df509919dc21eff8a3ca4

build-console-serial-selftest/konaos-console-serial-selftest.bin
88345fe4ab564620432a9ef50f2fa473a302424f8c086f5b969235ea036be19e

UserSoftware/KonaCommander/build/user/konacmd.exe
f0e75e46cda88dbf540e99015d5dc67b47267742b9d24f8efb6fa887e2035592
```

## Physical acceptance

PENDING.  No physical V9958/HID keyboard or serial terminal was available.
The simulator proves the render streams, LMMV/EOR rectangles, cursor/SAT
synchronization and both backend screens; it does not prove the visual
row-rate behavior.

Owner steps:

1. Copy `build/konaos.bin` to the card and place
   `UserSoftware/KonaCommander/build/user/konacmd.exe` on the card.
2. Run KonaCommander, press F1 and move Left/Right across the menu bar.
   Confirm the old and new selections change as one visual action, glyph
   shapes remain stable and the whole menu bar is not repainted.
3. Close the menu and confirm cursor visibility and position; exercise
   ordinary drawing, reverse text, scrolling and exit restoration.
4. Run the serial image and verify the same menu contents and selection state
   through the ANSI fallback; no RENDER bytes may reach the terminal.

## Warnings and limitations

- The hot-tier delta is 1,462 bytes, above the owner's normal ±256-byte
  guideline; it was explicitly accepted for this feature.
- The render stream validates all headers, record lengths, coordinates and
  attributes before I/O.  Payload bytes are covered by the descriptor length;
  the execution pass copies them in bounded chunks.
- The full serial TUI replay is run after rebuilding the serial image because
  the clean gate intentionally skips missing acceptance images.

## Supervisor review

Correction required on 2026-10-20 (source review of commit `f40cb6d`; nothing
rebuilt or rerun). The ABI header, operation numbers, console forwarding,
two-pass validation, TEXT/STATE execution, LMMV/EOR rectangle and the TUI
invert-bit classification match `WORK.md`. The owner reports the production
build works on the board. Findings:

1. **Must — the VDP is touched while a program holds it exclusively.**
   `v9958_sprites_off`/`v9958_sprites_restore` run in all three entry
   wrappers (`_v9958_char_putc`, `_v9958_char_write`,
   `_v9958_render_transaction`) before the worker checks `exclusive`, so any
   console byte during a hold rewrites R#8 (the holder's TP/sprite bits are
   replaced by `08h`/`0Ah`; sprites stay off while the console cursor is
   hidden). The RENDER path also runs `v9958_render_finish_worker` →
   `v9958_term_sync` during a hold (a SAT write when the cache is invalid)
   and does not count the dropped bytes, unlike WRITE/PUTC.
2. **Must — the measurement's explanation contradicts the simulator.** The
   record attributes the +12.7 M T-states (+127 k per menu move) to V9958
   command waits, but `V9958Peer` holds every command busy for a fixed
   400 T-states and a move issues two LMMV commands. The cost is somewhere
   else (`libtui` building and walking the stream, the driver's ten
   `copy_in` calls, the wrappers); it is unmeasured.
3. **Must — required coverage is source greps, not behaviour.** Circular-Y
   splitting is asserted only by the word `wrapped` in the source, and "one
   final cursor/SAT synchronization for a multi-record transaction" only by
   source order. `WORK.md` tests 2 require simulator evidence for both.
4. **Should — `0Bh` is not tied to the renderer's colours.**
   `V9958_COLOR_NORMAL`/`REVERSE` are new literals beside
   `V9958_CLEAR_COLOR` (`44h`) and `V9958_FILL_COLOR_REVERSE` (`FFh`), and
   the assembly repeats `44h`/`FFh` again; no `_Static_assert` relates them.
5. **Should — `libtui` caches RENDER support for good.** After one success
   (`render_support = 1`) a later `-KOS_ENOTSUP` is returned to the caller on
   every flush instead of falling back to ANSI. Harmless while a console's
   answer is fixed; the console serial tee makes it change at run time.

Accepted as is: the hot-tier delta (+1,462 bytes, 2,126 free, within the
2 KiB rule), the KonaCommander path naming, and the serial fallback. Physical
acceptance stays PENDING until the owner's menu run.

Correction: `work/74-console-render-transactions/correction-01/WORK.md`.

# Correction 01 — exclusive holds, measured cost, behavioural coverage

Implemented 2026-10-21 from `work/74-console-render-transactions/correction-01/WORK.md`
(the five supervisor findings above).  Baseline: `de3bf64`.

## Files

- `drivers/v9958/v9958_io.asm` - hold-aware bracket helpers
  (`v9958_hold_off` / `v9958_hold_restore` / `v9958_hold_finish`, gated on
  `V9958_ST_EXCLUSIVE = 20`): the R#8 sprites-off write, its restore and the
  transaction's finish worker (flush, cursor SAT, command wait) are all
  skipped while a program holds the VDP.  The three entry wrappers bracket
  the workers with them.
- `drivers/v9958/v9958_proto.c` - the RENDER worker drops and counts the
  whole stream length through `v9958_overtaken` and only sets
  `render_active` after the hold check.
- `drivers/v9958/v9958.c`, `v9958_driver.h` - `v9958_overtaken` shared with
  the worker; `_Static_assert`s tie `V9958_CLEAR_COLOR` /
  `V9958_FILL_COLOR_REVERSE` to the nibble-doubled normal/reverse colours;
  the `exclusive` offset pin for the assembly.
- `user/sdk/tui/src/tui_flush.c` - the fallback transition now lives in
  `tui_flush` (on `-KOS_ENOTSUP`: mark every cell dirty when support was 1,
  switch to ANSI for good, return the ANSI result).  The two-pass scan keeps
  the bitmap byte and the cell's bit mask in step with the cell, so a whole
  clean byte skips eight cells.
- `tests/device/devtest.c`, `tests/test_device_release.py` - the holder
  writes a distinctive R#8 last in its takeover; a held program submits one
  10-byte RENDER stream; both replays assert zero V9958 port traffic after
  that write (register, status, indirect, palette, command and VRAM).
- `tests/tui/tui_test.c`, `tests/test_tui_sim.py` - `invertwrap`,
  `rendersync` and `renderflip` modes with replay assertions on both
  backends.  `invertwrap` scrolls with 56 plain newlines (25 advances from
  the home position plus 31 scrolls: no ANSI in the test program).
- `tests/test_v9958.py` - the hold-aware wrapper order pins, the colour
  pin, and the deleted `wrapped` source grep.

## Requirement results

1. **Hold**: no R#8, SAT or command wait during a hold; RENDER answers the
   stream length and counts it (`dev: took ... 10`; `TAKEN_TOTAL` 69
   including `RENDER_LENGTH` 10).  `assert_no_console_vdp_traffic` runs in
   both the claim and the release replay.
2. **Colours**: the header asserts compile; the assembly's fill equates are
   pinned to the header by `test_v9958.py`.
3. **Fallback**: 1 → `-KOS_ENOTSUP` → full ANSI repaint (`renderflip`:
   renders `[l1, l2]`, max WRITE ≥ 90, FLIP/TAIL/SGR/Z on both lanes);
   support 0 also flips, repainting only the pending cells.
4. **Cost**: measured, dominated phase fixed, before/after recorded below.
5. **Coverage**: `invertwrap` pins the two 0x83 commands (DY=248, NY=8,
   CLR=0Bh, one per direction - a cell that ends on scanline 255 never
   straddles the page boundary, and the split branch's page-zero half is
   the whole cell) and decodes the screen in both directions; `rendersync`
   pins exactly one cursor SAT write (VRAM 0x1F200) and one final command
   wait.  Both are simulator behaviour, not source greps.

## Cost of one KonaCommander Right menu move (production image)

| phase | before | after |
|---|---|---|
| libtui flush scan + stream build | 331,078 | **28,650** |
| `console_render` IPC | 848 | 848 |
| console forwarding | 422 | 237 |
| driver validation | 2,491 | 2,676 |
| execution + finish + return | ~5,551 | **1,774** |
| flush entry → next getkey | ~340,390 | **34,185** |

The scan was 97% of the move; the byte-skip brings one move to ~34 k
T-states, ~3.4 M per 100 moves against the 23.4 M ANSI control.

## Budgets

| figure | before | after |
|---|---|---|
| driver hot tier | 31,031 used / 1,737 free | **31,027 used / 1,741 free** (−4 ≤ 64) |
| console-v9958-hid hot | 773 | **773** (module byte-identical, `9534a607...`) |
| `tui_flush.rel` (userland) | 18,448 | **20,861** (+2,413; KonaCommander still links with STACK=896 and exepack validates) |

## Validation

```sh
make && python3 -m unittest tests.test_v9958 tests.test_tui tests.test_tui_sim tests.test_console_serial tests.test_iocfat tests.test_source_layout tests.test_device_release
make console-serial-selftest
make sdk && make -C UserSoftware/KonaCommander test
make clean && make check
git diff --check
```

- `make clean && make check`: **873 tests, 116 expected skips, 0 failures**,
  `make check: OK`.  Reproducible production image `f3e9e579...`.
- Focused suites: `test_v9958` + `test_device_release` 39 OK (1 skip);
  `test_tui` 29 OK; `test_console_serial` + `test_iocfat` +
  `test_source_layout` 78 OK; the full `test_tui_sim` **47 OK** on both
  backends.
- `make console-serial-selftest`: OK; `console-serial.mod` byte-identical
  (`1150f41f...`).
- KonaCommander: host, project and UI replay all passing; `konacmd.exe`
  37,637 bytes, sha256 `cfdbb4f6...`, exepack OK.
- `git diff --check`: clean.

## Owner checklist (PENDING)

- KonaCommander: F1, Left/Right across the menu bar (one visual action, no
  repaint), close the menu, cursor correct.
- A game holding the VDP that prints to the console: its sprites stay on.

## Supervisor review — correction 01

Reviewed on 2026-10-21 (source diff against `de3bf64` and the evidence
above; nothing rebuilt). Accepted: the hold bracket, the RENDER drop count,
the colour asserts, the fallback switch on any `-KOS_ENOTSUP` with a full
repaint after a RENDER success, the behavioural `invertwrap`/`rendersync`/
`renderflip`/hold replays, and the cost finding: the libtui scan was 97% of
a menu move, and the byte-skip walk brings it from ~340 k to ~34 k T-states,
a seventh of the ANSI control. Findings, to fix before physical acceptance:

1. **Must — the hold check reads a pointer RENDER never sets.**
   `v9958_hold_off`, `v9958_hold_restore` and `v9958_hold_finish` read the
   flag through `_v9958_alt_state`, which only `_v9958_char_putc` and
   `_v9958_char_write` store. `_v9958_render_transaction` does not, so a
   RENDER that is the first entry after boot reads offset 20 of whatever
   the slot holds; nonzero skips sprites-off and the final sync. The module
   has one state, so the helpers read `_v9958_state+V9958_ST_EXCLUSIVE`
   directly, as `v9958_sprites_restore` reads `cursor_visible`.
2. **Should — the 1 → 2 switch keeps the RENDER backend's physical state.**
   `phys_attr`, `phys_cursor_visible`, `phys_x` and `phys_y` describe the
   V9958 after RENDER; the newly teed terminal has seen none of it, so the
   first ANSI repaint can omit the SGR, the cursor visibility or the first
   cursor position. The transition also marks them unknown (a value no
   cell or flag takes), so the repaint emits all three.
3. **Record:** give full hashes (production image, `konacmd.exe`); the
   `tui_flush.rel` figure is object-file text, not code: report
   `tui_flush`'s code bytes from the link map.

Physical acceptance remains PENDING (owner checklist above).
