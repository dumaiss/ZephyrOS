# Validation - snd voice engine

Date: 2026-10-25

## Result

The manual voice tick path uses sixteen fixed 16-byte descriptors and a
voice-order walk. Register changes write through the descriptor directly in
DIRECT mode or append to the bounded BATCH buffer. The changed-slot queues,
run/wait lists, `min_due`, and tick-end register flush walk are absent. The
public API and voice-program format are unchanged. No OS source changed.

The idle hard limit passes. The active-write and full-rewrite design targets
remain missed; their measured profiles are recorded below as required. All
functional and repository validation passes.

## Implementation

- `user/sdk/snd/src/snd_voice.asm` owns 16 descriptors of 16 bytes each:
  flags, wait, cursor, port, register and attenuation latches, and four
  precomputed desired/shadow pointers. Descriptor RAM is 256 bytes.
- The engine walks logical voices 0 through 15. Its opcode dispatch uses a
  jump table. WAIT ends a logical voice tick, and elapsed catch-up consumes at
  most 16 logical ticks while publishing only the last register state reached.
- The one-tick waiting-tone path is an unrolled descriptor countdown. The
  general descriptor walk handles due programs, noise work and catch-up.
- `user/sdk/snd/src/snd_out.asm` provides the internal IY-descriptor ABI
  `snd_put_period`, `snd_put_atten` and `snd_put_noise`. Each primitive updates
  desired state, compares and updates the shadow, then emits or batches only
  when required; forced noise emits even when equal.
- Invalid shadow suppresses intermediate descriptor writes and is restored by
  one 44-byte card-order rewrite. Tick-end output otherwise only sends a BATCH
  buffer. The 60-pair buffer sends before an append that would overflow it.
- Manual byte order is voice 0 through 15; within a voice, period precedes
  noise and attenuation. The invalid-shadow rewrite alone uses card order.
- `snd_close` consumes pending voice silences through the engine before the
  final flush. ZVG reservation and decoding behavior is preserved.

## Files

Added:

- `tests/snd/sndtest_put.asm` - test-only direct calls of the internal output
  primitives.
- `docs/validation/2026-10-25-snd-voice-engine.md`.
- `work/100c03-snd-voice-engine/progress.md`.

Changed:

- `user/sdk/snd/src/snd_voice.asm`, `snd_out.asm`, `snd.c`,
  `snd_private.h` - descriptor engine, write-through output, initialization
  and internal ABI documentation.
- `tests/snd/sndtest.c`, `tests/test_snd.py`, `tests/test_source_layout.py`,
  `Makefile` - primitive, stagger, catch-up, ordering and symbol-based timing
  coverage.
- `docs/sdk.md`, `docs/snd-sdk.md` - descriptor RAM, wait/catch-up semantics,
  write-through behavior, order and measured costs.

## Functional coverage

- The existing tone, ADSR, noise, output-mode, close, catch-up, ZVG,
  ZVG-note and timed-song tests pass.
- Twelve reverse-installed tone voices with staggered envelopes and waits run
  for 200 ticks. Every tick equals the Python descriptor model in DIRECT and
  BATCH mode, including voice-order writes.
- One `snd_tick(5)` reaches the same descriptor and desired-register state as
  five `snd_tick(1)` calls, while emitting only the last state per register.
- Direct primitive coverage proves equal period/attenuation/noise values are
  suppressed and forced equal noise emits.
- BATCH and full-rewrite paths retain their bounded send behavior, and all ZVG
  functional fixtures remain byte-exact against their goldens.

## Budgets

CPU figures are Z80 T-states with interrupts out. The simulator attributes
assembly ranges from the final `sndtest.map` symbols rather than fixed
addresses.

| figure | before | measured | target/result |
|---|---:|---:|---|
| idle tick, 12 waiting voices | 190 | 546 | <= 600, met |
| one waiting voice decrement | not pinned | 33 instruction-path T | <= 50, met |
| 12 voices changing attenuation | 19,215 | 27,245 | <= 4,000, missed |
| one voice step + one DIRECT byte | 1,260 | 6,090 | <= 400, missed |
| full rewrite, four chips DIRECT | 15,632 | 23,096 | <= 3,500, missed |
| `snd_put_atten`, changed DIRECT | not pinned | 298 instruction-path T | <= 80, missed |
| BATCH tick, 12 voices | 8,135 | 11,488 | report |
| descriptor RAM | none | 256 bytes | report |
| OS bytes | 0 | 0 | 0, met |

The 546-T-state waiting path is 12 unrolled 33-T-state decrements plus entry,
due detection and return. The changed-attenuation primitive's 298-T-state
instruction path includes desired/shadow pointer loads, chip-valid check,
comparison, shadow update and a DIRECT descriptor emit; caller and opcode
dispatch are excluded. The end-to-end active figures include descriptor
dispatch and marker-attributed assembly ranges. They remain explicit timing
pins rather than being represented as meeting the design targets.

The corrected symbol-based ZVG profile reports a 416-T-state wait-only whole
tick, a 546-T-state manual-engine baseline (the incremental subtraction is
-130 because the two workloads take different engine paths), a 1,099-T-state
command loop, 224 marginal T-states per written byte and 478 for service. The
per-byte design target of 50 is therefore missed; ZVG functional traces and
the no-reader-in-tick assertion still pass.

## Validation

Final sources were frozen before these commands.

- `make && make sdk && make -C UserSoftware/VGMPlayer test` - passed. The SDK
  packed 67 files; VGMPlayer's four API tests passed. `sndtest.exe` was 21,834
  bytes, SHA-256
  `402aed0a3977a8d925754d62963351cd67838e3fad214b149d862a4b1b38386d`;
  `vgmplay.exe` was 21,992 bytes, SHA-256
  `05380d0a25b2ec61755635949da92c32c5c9888c25ce2f5b63248e99183f6462`.
- `python3 -m unittest tests.test_snd tests.test_snd_oracle
  tests.test_reader tests.test_sdk_package` - 54 tests passed in 54.656 s.
- `make clean && make check` - 989 tests passed in 395.255 s, with 119
  configuration/acceptance-image skips; final gate printed `make check: OK`.
- The clean rebuild produced identical `build/konaos.bin` and
  `build/zephyr80.bin`, SHA-256
  `0c940491f7383cf9ef993bbb3703144c2c9d1594d33c4d7e003a57485ce9bb11`.
- `git diff --check` - passed.

The skips are the suite's expected absent optional acceptance images after
`make clean`; this package names no additional image target. Existing Python
`ResourceWarning` messages for unclosed temporary test files remain visible
and do not fail the suite.

## Pins and preservation

- The Python sound reference changed from per-chip flush grouping to the
  required voice-order write-through behavior. Tone period remains before its
  dependent attenuation, and ZVG golden streams did not change.
- Timing attribution changed from stale absolute PC windows to symbols in the
  final program map. Thresholds retain the measured active-path overruns with
  their design targets in assertion messages and this record.
- Existing public sound headers, the bytecode format and public API did not
  change. The sound behavior suites and the standalone oracle verify their
  preservation.
- The working tree was clean before implementation; no unrelated changes were
  present or discarded.

## Hardware

PENDING: no board was available. Using the production image above, the owner
checklist is:

1. Run `sndtest tones`, `sndtest adsr` and `sndtest noise`; confirm they sound
   as before.
2. Run `sndtest zvg /fs/night.zvg 2`; confirm clean playback on chip 2.
3. Run `vgmplay /fs/night.zvg`; confirm clean playback.

The simulator validates byte order, state, batching and timing accounting; it
does not prove analog audio, board wiring or interrupt interaction.
