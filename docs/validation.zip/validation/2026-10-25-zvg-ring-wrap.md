# Validation - zvg-ring-wrap (package 100c02)

Date: 2026-10-25. Implemented by the supervisor.

## Defects (board: stray beeps, missed beats; sndtest 4-6x fast)

1. Ring wrap: the decoder stepped a command's bytes with `inc hl` from
   `&ring[head]`, reading past the 256-byte ring when a command
   straddled its end. NIGHT.ZVG: 259 corrupted places in 56,709 writes,
   one per 256 stream bytes. Fixed: the ring is 256-byte aligned in a
   512-byte area (`snd_zvg_ring_page`), bytes are page:index, stepped
   with `inc l`.
2. The first tick: the first flush's card rewrite followed the
   decoder's tick-0 writes and silenced the chip. Fixed: `snd_zvg_play`
   sends the pending rewrite before PLAYING.
3. Found on the way: `snd_tick(n)` ran the ZVG decoder once whatever n
   (NIGHT: 11,672 events -> 11,522 ticks, the song dragging). Fixed:
   the decoder runs the bounded count.
4. Found on the way: BATCH appends were unbounded under catch-up. Fixed:
   a full batch is sent first (`snd_batch_send`).
5. sndtest zvg is timer-paced by default (`snd_timer_period`, `notify`,
   `snd_tick(count)`, `snd_service`, `idle()`, a key stops); `step`
   keeps the unpaced replay loop.

## Tests

- `wraps.zvg` (generator, 600 ticks, 3,317 bytes) + golden, in the
  oracle test and TestSndZvg (chips 0 and 2, DIRECT and BATCH); tick 0
  now equals the oracle's exactly.
- `zvg_trace`: the 6 KB first-buffer limit lifted (256 KB).
- TestSndZvgTimed: NIGHT.ZVG through sndtest on the timer: byte-
  identical to the oracle, events == ticks (11,522), 0 underruns.
- TestVgmplayTimed: the same through vgmplay (skipped unless built).
- `make clean && make check`: 986 tests, OK (skipped 119).

## Jitter (Should)

NIGHT.ZVG on the timer: tick starts 15-18 ms apart (period 16.7 ms);
gaps of ~33 ms (events coalesced while a refill runs) fell from 72 to
~29 with 100c01's stdio fast path. Each is one late tick, replayed
exactly by the count.

## Budgets

ZVG tick figures unchanged in shape (the decoder is shorter: page:index
instead of an add). OS bytes: 0.
