# systemgen: one system file per image (work package 49a)

Work package: `work/49a-systemgen/WORK.md`.  The package replaces the
scattered per-image build composition - the Makefile's image `ifeq`
blocks, `config/system.mk`, each image's hand-written ROMFS store
manifest (`recovery/manifest.json`, `tests/*/manifest*.json`,
`user/helloworld/manifest.json`) and the class-number dependency wiring
inside the driver manifests - with one `systems/<name>.json` per image and
one generator, `tools/systemgen.py`, that derives the build inputs from
it.  The working log with the per-step evidence is
`work/49a-systemgen/progress.md`.

## 1. Supervisor decisions this record is judged against

The acceptance rules were updated by the supervisor on 2026-10-12 before
the final pass; they replace the original byte-identity requirement:

- the byte-identity requirement is **dropped**; acceptance is
  `make clean && make check` green, the image matrix green and production
  booting to the monitor in the simulator replay;
- the store has a **canonical order**: the driver images in load order,
  then `drivers.man`, then the system file's `store` files;
- **KRFS** (the ROMFS magic `ZRFS` → `KRFS`) lands in the same pass;
- `systemgen` does **not** take over packing.  It writes `system.mk`, the
  ROMFS store manifest, the boot manifest `drivers.man` and one
  **resolved copy** of every selected driver manifest
  (`$(BUILD)/drivers/<id>.json`); `modpack.py` keeps the endpoint
  numbers, the tier plan, the in-container publication table and the plan
  report (its `drivers` command becomes `plan`, report only);
- driver ids: a bare id resolves under `drivers/`, a test-only driver is
  named by its repo-relative path without `.json`, the id is the
  basename, and the manifest's `name` must equal the id;
- symbolic `depends` (`"INPUT"`, `"VIDEO:1"`, `"#16"`, trailing `?` for
  optional), resolved by endpoint class against the selected set; a
  missing or ambiguous name is an error naming the system, the driver and
  the entry;
- the system file's flag field is `cflags` (raw flags, never a `.exe`
  path), and the FS publication type is spelled `FS` again;
- the store-order changes are recorded here, not treated as a stop
  condition.

## 2. What the tree looks like now

```
systems/<image>.json     12 image descriptions (production, subsystem,
                         nucleus, console-integration, console-serial,
                         console-serial-missing, console-init-fail, fs,
                         ns, ipc, xmem, helloworld)
tools/systemgen.py       the generator and the schema/entry validator
```

A system file carries the driver ids in load order, the boot program, the
store's own files and the image's C flags:

```json
{
  "schema": "kos-system-1",
  "name": "fs",
  "drivers": ["sio", "ioc", "console-serial", "iocfat"],
  "boot": "/system/fs_selftest.exe",
  "store": ["monitor.exe", "fs_selftest.exe", "fs_child.exe"],
  "cflags": []
}
```

`tools/systemgen.py <system.json> <build-dir>` validates the system
schema, resolves every driver id to its `kos-driver-1` manifest, resolves
the symbolic dependencies against the selected set, validates the boot
program against the store it just wrote (the rule absorbed from the
retired `tools/bootprogram.py`) and then writes:

| generated input | contents |
| --- | --- |
| `$(BUILD)/system.mk` | `KOS_DRIVERS`, `KOS_BOOT_PROGRAM`, `KOS_SYSTEM_CFLAGS`, `KOS_DRIVER_OBJECTS`, `KOS_STORE_FILES` |
| `$(BUILD)/store.json` | the ROMFS manifest: driver images, `drivers.man`, the store's own files |
| `$(BUILD)/modules/drivers.man` | one 24-byte name record per selected driver, in load order |
| `$(BUILD)/drivers/<id>.json` | the driver's manifest with `depends` resolved back into `{class, instance}` rows (and `optional`) |

The Makefile keeps the wiring it needs (the image-name suffix table, the
test-object rows, the rule generator that emits one pack rule per
selected driver) and includes the generated `system.mk`; `include`
restarts make after the generator ran, which is what brings `KOS_DRIVERS`
into the build.

## 3. Files

Added:

| path | what |
| --- | --- |
| `tools/systemgen.py` | the generator |
| `systems/*.json` (12) | one description per image |
| `tests/test_systemgen.py` | the generator's tests: schema rejections, id and dependency resolution, boot-setting rules, the generated manifests' shape and the golden production `drivers.man` |

Removed:

| path | replaced by |
| --- | --- |
| `config/system.mk` | `systems/*.json` + `$(BUILD)/system.mk` |
| `tools/bootprogram.py` | the boot validation in `tools/systemgen.py` |
| `recovery/manifest.json` | `systems/production.json` |
| `tests/subsys/manifest.json` | `systems/subsystem.json` |
| `tests/console/manifest-{integration,serial,serial-missing,init-fail}.json` | `systems/console-{integration,serial,serial-missing,init-fail}.json` |
| `tests/fs/manifest.json` | `systems/fs.json` |
| `tests/ipc/manifest.json` | `systems/ipc.json` |
| `tests/ns/manifest.json` | `systems/ns.json` |
| `tests/xmem/manifest.json` | `systems/xmem.json` |
| `user/helloworld/manifest.json` | `systems/helloworld.json` |
| `tests/ns/manifests/{sio,console-serial}.json` | the `drivers/` manifests they duplicated |

Moved: the IPC acceptance drivers' containers are `<id>.mod` in the
image's own module directory (the `ipc-` prefix and `ipc-modules/` are
gone), and their objects carry an `ipc_` prefix so they can never collide
with a production driver's objects in one module directory.  The
`nucleus` image has no manifest of its own: it carries the same 32-entry
fixture store as `subsystem`, now as `systems/nucleus.json`.

## 4. The store-order changes

The canonical order moved `drivers.man` after the driver images, and the
IPC image's drivers moved ahead of its programs.  These are the only
images whose packed store differs in order from before:

| image | before | after | why |
| --- | --- | --- | --- |
| production | `... console-v9958-hid.mod, drivers.man, iocfat.mod, monitor.exe ...` | `... console-v9958-hid.mod, iocfat.mod, drivers.man, monitor.exe ...` | canonical order |
| fs | `... console-serial.mod, drivers.man, iocfat.mod, monitor.exe ...` | `... console-serial.mod, iocfat.mod, drivers.man, monitor.exe ...` | canonical order |
| ipc | `sio.mod, console-serial.mod, ipccopy.exe, ipc.exe, drivers.man, ipc-ioc.mod, ... ipc-irqx.mod` | `sio.mod, console-serial.mod, ioc.mod, fat.mod, vfs.mod, echo.mod, con.mod, irqx.mod, drivers.man, ipccopy.exe, ipc.exe` | canonical order and the `<id>.mod` names |

The other nine images (subsystem, nucleus, console-integration,
console-serial, console-serial-missing, console-init-fail, ns, xmem,
helloworld) already packed in canonical order; `console-serial-missing`
still packs exactly the store it did before, because its one deviation -
the required console image left out - is the `--omit-image` setting.

## 5. The one setting that is not a system-file field

`console-serial-missing` is the `console-serial` image with
`console-serial.mod` left out of the store while its name stays in
`drivers.man` (the loader's lookup then fails and the boot must stop on
the early console, architecture 36.11).  The image target passes it as
`SYSTEM_OMIT.console-serial-missing := --omit-image console-serial`; the
generator refuses an omit name that is not a selected driver.

## 6. The ROMFS magic: `ZRFS` → `KRFS`

The four-byte magic was retracted in the same pass: `tools/romfspack.py`
(`MAGIC` and the `bad magic ... (expected KRFS)` message),
`formats/include/romfs.h` (the header comment and
`ROMFS_MAGIC_0..3`), the `kernel/main.c` comment, `docs/romfs-format.md`
and every fixture that builds a stream by hand
(`tests/test_pack_image.py`, `tests/test_romfs.py`,
`tests/test_validation_cli.py`).  `tests/test_pack_image.py` also asserts
that the packer copies the store's first byte through, so a silent
mismatch between the tool and the kernel header cannot survive.  The
retired token is scanned for by
`tests/test_source_layout.py::TestNoStaleRemovedPaths::test_no_live_file_carries_the_retired_romfs_magic`.

## 7. Acceptance

### 7.1 Baseline (before)

Captured on the tree with the package's new files present but no other
edit, from a clean build (`make clean && make check` plus the full image
matrix): every target exited 0 and the suite was green.

| image | sha256 (before) |
| --- | --- |
| production | `8a4f4067eede87ac48caeef908d2a5ee041e4b09094f7ab1a0acbedfc4f1d468` |
| subsystem | `f5f6da45d5ea96d4f5467c7acf79bdeba80feb1bb557a3815dfd64393637ea6b` |
| console-integration | `a597ed6203e8890289dba68501568364ee1db5bb9e62901dee9cd6b3b3563b38` |
| console-serial | `26b48dd21608eecc63d186e0d87b98d5d612bf654554df776deb5b14b4b67d16` |
| console-serial-missing | `e654c2ba9918ea9ed056183c5508e43c7055b726fa4bf9e87510e773842fc510` |
| console-init-fail | `9235384e8abb6995e8f28c2b15f7a96e9a2d1e89394147e9e920ec833b3dba8b` |
| fs | `9b3a94daa6ef17ba375d77cc687b1df37e7d529a61c18bd369426bb8fd5df3f8` |
| ipc | `0b5b510eaab9dcd11bb37f0b292eab092adf955bd4d44b25c16006f353d1a6de` |
| ns | `30b6d09f6b8ba3f974105da17bc97654ac188a9dc5913ecb298880dda3b12a86` |
| nucleus | `4bf8525ce76403605414525e2825890c3d8e092a5485cbff5a40794f100ac3a6` |
| xmem | `ab9df3f1d0120c73d76a21ddc264b9877b8ba488a498c6fc04614383ad85645e` |
| helloworld | `b9e76862a674a6d796150be7dbf0d45716cc2de54105296e0358e5301349dd7e` |

### 7.2 After

The acceptance run below is a single session on the final tree:
`make clean && make check` (exit 0 - the check builds twice and compares
the production image) followed by the whole image matrix, every target
exit 0, plus the production simulator replay inside the check.

| image | sha256 (before) | sha256 (after) |
| --- | --- | --- |
| `production` | `8a4f4067eede87ac48caeef908d2a5ee041e4b09094f7ab1a0acbedfc4f1d468` | `91f3ac3b798dfc739ec455811bf42276c9c2f857f1fb103195b7d2b0ee60b9cc` |
| `subsystem` | `f5f6da45d5ea96d4f5467c7acf79bdeba80feb1bb557a3815dfd64393637ea6b` | `f6f2358ebdbb82355473ce2bdb996294098905aa106aa5307b9a601eb92866ee` |
| `nucleus` | `4bf8525ce76403605414525e2825890c3d8e092a5485cbff5a40794f100ac3a6` | `7b5ba99b4031abfc0078b991a51a940b64f5ac8c41750d52a5fef32de0d9fad0` |
| `console-integration` | `a597ed6203e8890289dba68501568364ee1db5bb9e62901dee9cd6b3b3563b38` | `fa83700a9b1a62dc6d61bc5b551b97f3f9e2d55d68950dad68daf42ff19e4247` |
| `console-serial` | `26b48dd21608eecc63d186e0d87b98d5d612bf654554df776deb5b14b4b67d16` | `cc18336a2dec601e74d7d9a67bfb109f757758f5fc0e246d94b389ea128325dc` |
| `console-serial-missing` | `e654c2ba9918ea9ed056183c5508e43c7055b726fa4bf9e87510e773842fc510` | `9352aee964117a31924b34a2007155fd436f77e73317eb650b1e981283d99ec4` |
| `console-init-fail` | `9235384e8abb6995e8f28c2b15f7a96e9a2d1e89394147e9e920ec833b3dba8b` | `465a2e13f521bb32982c8770119aee72831de9b7a7cafdef16dbcae8f6a9e8ee` |
| `fs` | `9b3a94daa6ef17ba375d77cc687b1df37e7d529a61c18bd369426bb8fd5df3f8` | `393321a504304ed51486264052601b93525af2015aab58ecf22bbf9bfcfbace9` |
| `ns` | `30b6d09f6b8ba3f974105da17bc97654ac188a9dc5913ecb298880dda3b12a86` | `c95dc18091d2e56e032cda8d6c74e203269d98322afd884328d4d2d2ea51041a` |
| `ipc` | `0b5b510eaab9dcd11bb37f0b292eab092adf955bd4d44b25c16006f353d1a6de` | `f40956372004314f6f374afd2993fc6cec3e50bd7bb48f4b4471e32cec4d03e7` |
| `xmem` | `ab9df3f1d0120c73d76a21ddc264b9877b8ba488a498c6fc04614383ad85645e` | `9a2b0815c6ea1a58ad90ce56a62b6e5bafddd2745bf104918bd7d0465e1335d6` |
| `helloworld` | `b9e76862a674a6d796150be7dbf0d45716cc2de54105296e0358e5301349dd7e` | `f7313f9993b66b7c0c3aa1e2673adbb5bbfe1f20874695a1ead61c6e8a6e31d3` |

Test suite: `Ran 649 tests ... OK (skipped=104)` inside `make check`; the
skips are the acceptance images' replays, which run inside their own
targets with the packed artifacts present (subsystem 4 + 26 tests,
console-integration 7 + 2, and one suite each for fs, xmem, ns, ipc and
nucleus), all green.

Two checks are worth naming because they are what the rework is about:

| check | where | result |
| --- | --- | --- |
| the fail image really omits the console | `test_console_serial.py::TestRequiredConsoleFailure::test_boot_fails_explicitly_on_the_missing_console` | the image halts on the early console (36.11); its store carries seven files against the serial image's eight (the `--omit-image` setting) |
| the IPC store boots its six synthetic drivers | `test_ipc_selftest_sim.py` | every boot segment ran exactly once, the loader's report matches the packer's plan, `con`'s slow buffer stays out of the driver I/O range |

### 7.3 The production boot

`make check` runs the production image through the simulator replay
(`tests/test_console_acceptance.py`): the monitor banner, the command
surface, the IOC lane serving the filesystem driver, the driver ledgers
and the store payload identities.  The replays of the other images run in
their own targets (`test_subsys_sim.py`, `test_ipc_selftest_sim.py`,
`test_ns_selftest*.py`, `test_xmem_selftest*.py`, `test_fs_selftest*.py`,
`test_nucleus_sim.py`, `test_console_serial.py`).

## 8. Notes and unmapped items

- `--omit-image` is the only image setting that does not fit a system
  file; it stays in the image target (section 5).
- Two pre-existing dead artifacts were kept, because removing them is not
  this package's business: `TEST_FIXED_OBJS` (referenced, never defined,
  in the Makefile) and the `KOS_VFS_WS_GUARD` variable the `ns` image
  used to set (the flag itself still reaches the acceptance images through
  the wiring table).  Both behave exactly as before the package.
- `KOS_SMOKE_HOST_SYNC` moved out of the Makefile into the `cflags` of
  the four images the smoke targets drive; the flag, its use in
  `kernel/main.c` and `tools/serial_smoke.py` are unchanged.
- No host test existed for `tools/bootprogram.py` before this package
  (searched `git grep` and `tests/`); its three rules - under `/system`,
  in the store, and naming an EXE - are covered by `TestBootSetting` in
  `tests/test_systemgen.py`.
- The boot path's `KOS_PATH_MAX - 1` length check is kept as a guard, but
  it cannot fire before the store's 23-character ROMFS name rule: a name
  the store accepts is at most 23 bytes and `/system/` adds 8, so a valid
  boot path is at most 31 bytes.  The generator test asserts the
  reachable rule.
- `docs/sdk.md`'s `fardemo` paragraph describes the build as a system
  file whose `boot` differs from the helloworld image's; no `fardemo`
  system file was added, because the demo is built on demand from the
  helloworld image's description.
- The driver manifests keep their `endpoints`, `publishes` and `objects`
  rows and gain `schema: kos-driver-1` and the symbolic `depends`; the
  packer's `--set` input is unchanged, so its unit tests keep the
  `{class, instance}` form and pass apart from the command rename.

## Supervisor review (2026-10-12)

**Accepted.**

- **Delivered as decided:**
  - 12 system files and `tools/systemgen.py`;
  - resolved manifest copies feed `modpack`'s unchanged `--set`;
  - the canonical store order;
  - `KRFS`;
  - `FS` uppercase again;
  - the duplicate ns manifests are deleted;
  - IPC containers are `<id>.mod`, with an `ipc_` object prefix against
    object-name collisions (a sound addition).
- **Tests:** `make check` passes (649 tests) and every matrix target
  passes; production boots in its replay.
- `--omit-image` as the one per-target setting outside the system files
  is the right call for a negative-test variant.
- **Not reported:** the nucleus ledgers. They are unchanged by
  construction: no kernel code changed beyond a comment, and the magic
  constants are the same size. The next record must include them.
- **Supervisor fix, made in the review:** `tests/test_source_layout.py`'s
  stale-token scans (`SCAN_ROOTS`, `SCAN_TOP_FILES`) also read `docs/`
  and `README.md`. That broke the owner rule that the test suite never
  tests documentation. They now scan code only. `tests.test_source_layout`
  passes (67 tests).
- **Dead items left, noted for a cleanup:** `TEST_FIXED_OBJS` (referenced,
  never defined) and the `KOS_VFS_WS_GUARD` variable.
