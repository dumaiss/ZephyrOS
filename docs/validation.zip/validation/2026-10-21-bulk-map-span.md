# Bulk-map span and mapped segments

## Result

A resident driver can map bank 6's first 8 KiB into `0000h-1FFFh`
(latch bank field Q = 6) and read and write its own **mapped segment** at
its linked address, as architecture 5.2, 5.4, 4.5, 4.9 and section 9
state. No production driver uses the span yet; the V9958 renderer is the
first client.

Validated with targeted builds and suites; the full `make clean && make
check` is deferred by the owner to the end of the renderer work.

## Files

- `kernel/ipc/ipc_asm.asm` - `ipc_bulk_map`/`ipc_bulk_unmap` inside the
  audited page-select extent (`_ipc_domain_enter`..`ipc_domain_switch_end`),
  the one-byte span state `ipc_bulk_open` (0 closed, 80h | the replaced Q
  open) and the fault word `ipc_bulk_faults`.
- `kernel/ipc/ipc.c` - `api_bulk_map` (refused in interrupt context), the
  two table entries, the refusals in `api_copy`, `api_call`,
  `api_bulk_read`, `api_bulk_write`, `api_event_post` (ignored only
  outside interrupt context), and `ipc_span_close` on all three endpoint
  return paths.
- `drivers/include/driver.h` - `bulk_map`, `bulk_unmap` at the end of
  `struct driver_api`.
- `formats/include/mod.h`, `kernel/driver/driver_loader.c` - role 5
  (`MOD_SEGMENT_MAPPED`), its 0100h-2000h bound, the plan report and the
  `driver mapped:` evidence line.
- `tools/modpack.py` - role `mapped`, `place_mapped` (from 0100h in load
  order, 7,936 bytes), boot placed after the mapped run, the cross-role
  overlap check for the boot/bulk tier, the ledger fields and the plan's
  `mapped_base`; `tools/pack_image.py` - the `driver mapped:` ledger line.
- `tests/target/ipc/` - `echo_map.c`, `irqx_map.c`, the ECHO_SPAN,
  ECHO_LEAK and IRQX_SPAN probes, four client checks; `Makefile` rule
  `ipc_%_map.rel`; `tests/target/include/ipc_test.h`.
- `tests/test_driver_images.py`, `tests/test_ipc_selftest_sim.py` - see
  the pins below and the new tests.
- `docs/architecture.md` (5.2), `docs/devices.md` (13),
  `docs/module-format.md`, `docs/memory.md`.

## Requirement results

1. **Primitives.** `bulk_map` 142 T-states (wrapper 27 + primitive 115),
   `bulk_unmap` 93, counted from the compiled listings (limit 150).
   Nested: `-KOS_EBUSY`, nothing changed (ECHO_SPAN `NEST`).
2. **Refusals.** `call`, `copy_in`, `bulk_read` answer `-KOS_EBUSY` inside
   a span and `copy_in` works after it (ECHO_SPAN `CALL`, `COPY`, `BULK`,
   `AFTER`); `copy_out`/`bulk_write` share the same checks.
3. **Leak closure.** ECHO_LEAK returns with a span open; the replay reads
   `_ipc_bulk_faults == 1` and `_ipc_bulk_open == 0` after the run, and
   the next call succeeds. The counter is a fixed-data word, not a
   `SYS_DIAG_SYSTEM_INFO` field: that record is 13 bytes and existing
   programs pass 13-byte buffers (shell banner, ColecoGo), so growing it
   would overrun them.
4. **Interrupts.** IRQX_SPAN takes a CTC0 delivery inside a span; after it
   the bank field is still 6 and the mapped pattern reads back
   (`span-irq`). A handler cannot open a span (`api_bulk_map`), because
   the interrupt's exact-latch return would leave the state open.
5. **Mapped role.** Plan: `echo` mapped 0100h (32 + 32 BSS), `irqx` 0140h
   (32); boot segments follow from 01C0h. Host tests: load order, boot
   above the mapped run, 7,936-byte limit, plan ledger.
6. **Ledger.** `driver mapped: <bytes> of 7936` from the packer, the image
   ledger and the loader (IPC image: 96 bytes).
7. **Docs.** As listed above.

## Budgets

| figure | before | after |
|---|---|---|
| nucleus fixed room | 6,108 | 5,950 (+158 bytes, budget 200) |
| common | 3,067 used | 3,067 (unchanged) |
| driver hot | 31,027 used / 1,741 free | unchanged |
| driver mapped | - | 0 of 7,936 (production) |

## Pins changed, with their sources

- `test_driver_images.TestDriverSet.test_boot_and_bulk_share_the_lower_tier`:
  boot base 0000h -> 0100h. Source: architecture 5.2 and `WORK.md`
  requirement 5 (bank 6's `0000h-00FFh` stays free).
- `test_ipc_selftest_sim.TestIpcDriverImages.test_loader_reports_the_packer_plan`:
  the expected placement line gains `mapped <addr>` and the mapped ledger
  line. Source: `WORK.md` requirements 5 and 6.

## Validation

```sh
make
python3 -m unittest tests.test_mod tests.test_driver_images tests.test_pack_image tests.test_source_layout tests.test_monitor tests.test_device_release
python3 -m unittest tests.test_console_acceptance tests.test_iocfat tests.test_timer tests.test_sound
make ipc-selftest
git diff --check
```

- First batch: 203 tests OK (2 skips: images not built).
- Production replays: 52 tests OK (the production image boots with the
  boot segments at 0100h).
- `make ipc-selftest`: client `ipc: 58/58 checks`, `ipc: PASS`; replay and
  host suites 41 tests OK.
- `git diff --check`: clean; the history-word check prints nothing.
- Production image after the change:
  `ed3bb9b3a9578c9d956b949b48a79fee516ddb5b489955679d90c60d0c6580b5`.
- Not run: `make clean && make check` (deferred by the owner to the end of
  packages 78-79).

## Found

- An address taken into a stack local compiles to two byte stores
  (`ld -2(ix),#<sym` / `#>sym`), relocation mode 0Bh, which the packer
  refuses. Drivers keep such addresses in statics set at init. Not a
  defect; a constraint worth knowing for the renderer.

## Final gate

Run with package 79: see the "Final gate" section of
`docs/validation/2026-10-22-v9958-direct-renderer.md` (`make check: OK`,
877 tests; `make ipc-selftest` 58/58, 41 OK).
