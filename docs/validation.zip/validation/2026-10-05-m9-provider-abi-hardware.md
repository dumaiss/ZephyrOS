# M9 writable-provider / driver ABI v3 (package 26): validation record

Work package: `work/26-m9-provider-abi-cache`.  Dates: host/simulator
2026-10-04, physical 2026-10-05.
Host toolchain: SDCC 4.5.0 (`sdcc`/`sdldz80`/`sdasz80`).

## 1. Result

Driver ABI v3 (`fs_register`), the loader's provider-registration
transaction, the completed kernel file/directory API (32-bit seek, root
merge, mountpoint error rules) and the test-only writable `ramfs`
provider are implemented and validated.

* Host/simulator: `make clean && make check` OK; `python3 -m unittest
  discover -s tests` 539 tests OK (skipped=120); the M9 subsystem targets
  `m9-vfs-selftest`, `m9-required-mount-selftest` and the new
  `m9-provider-selftest` all pass.
* Physical: production boot reaches the monitor with HID and V9958
  bound — confirmed on the V9958 display (section 4).  See the caveat in
  section 5: the serial `normal` smoke mode cannot observe a
  V9958-bound production boot.

## 2. Ledger (architecture section 32.39)

```text
before (package 25b):
bank7: code 21689 bytes end 74B9h | arena 49 granules (20 boot, 29 free) | data 1309 bytes at D800h | isr 256 | slack 483 bytes

after (package 26):
bank7: code 23526 bytes end 7BE6h | arena 46 granules (20 boot, 26 free) | data 1501 bytes at D800h | isr 256 | slack 291 bytes
```

New kernel C: 304 lines, +1837 `_CODE` / +192 `_DATA` bytes (about 6.7
bytes per line).  Per-object deltas are in `docs/memory.md` section
2.2.1.  The 32-granule production floor and the boot-set arena plan both
still hold; remaining slack is 291 bytes, which the supervisor checkpoint
weighs before package 27.

## 3. Host/simulator artifacts

Consumed build set (`make check`, reproducible; `build/zephyros.bin` ==
`build/zephyr80.bin`):

```text
build/zephyros.bin                        sha256 03f776a970192ab3c6b655899ee8241c222898e7ffe80b9ece99bccb3d959cec
build/modules/sio.zmod                    sha256 bf435bcacd42bc93148b3d84b5896463884ff304c56b40a90da6578321388159
build/modules/ioc.zmod                    sha256 3f1e3fa26b2d1635d2457876276c8be935fe662560eda004b8c3668b53004b5d
build/modules/hid.zmod                    sha256 7513af162fde691780a6e853be0916dd0ec46fbbd024ee124e92c0601d2174d7
build/modules/v9958.zmod                  sha256 a978e7a0b83c269de5a67ac5f0413fa526d1191eeb13e2eaf636f9a1d24891f3
build/modules/ramfs.zmod                  sha256 2010f8bc4a0923025fc5efb99434200879fc40ec87b83b031036e1973c0a2506
build-m9-provider-selftest/zephyros-m9-provider-selftest.bin
                                          sha256 89dd1ad155ac08e586b1a747604ddb3857741477259218e1dbda04b0903144d4
```

## 4. Physical acceptance: production boot (HID + V9958 bound)

Image flashed (identical bytes to the host build; the `make
smoke-hardware` preflight prints the same hash):

```text
build/zephyros.bin   sha256 03f776a970192ab3c6b655899ee8241c222898e7ffe80b9ece99bccb3d959cec
```

Command:

```sh
make smoke-hardware SERIAL_PORT=/dev/ttyUSB0
```

Serial transcript (65 bytes captured before the 15 s timeout):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
```

V9958 display, same boot (operator photograph, transcribed):

```text
console: dynamic sio0.b OK
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

Interpretation: the production boot loaded its full module set (no
`unavailable` diagnostic), `console_bind_defaults()` bound HID input +
VIDEO output, the console acceptance line was rendered by the V9958
output, and the monitor reached its prompt.  That is exactly the package
requirement: "the boot must reach the monitor with HID and V9958 bound".

## 5. Caveat: `normal` smoke mode and a V9958-bound console

`tools/serial_smoke.py --mode normal` (`_production_result()`) requires
`console: dynamic sio0.b OK`, the monitor banner and `Z80> ` **on the
serial transcript**, so it reports FAIL/timeout on any bench where the
console-capable module is resident — the established architecture-30.9
binding policy (recorded in
`docs/validation/2026-10-03-m8-console.md`: "with the console-capable
module loaded, the boot acceptance line is rendered by the V9958 output
rather than reaching the SIO port").  `--mode normal` is therefore only
applicable to an SIO-fallback bench.  The production hardware gate for
package 26 is closed by the serial early-banner transcript plus the
V9958 photograph above, not by a `serial_smoke: OK` line.

Related contract defects reported to the supervisor:

1. `work/26-m9-provider-abi-cache/WORK.md` validation says "Flash
   production and run `make smoke-hardware-m8`", but `smoke-hardware-m8`
   preflights `build-m8-selftest/zephyros-m8-selftest.bin` (the M8
   integration image), not production.  The production target is
   `make smoke-hardware`.
2. `--mode normal` cannot gate the HID+V9958-bound production boot it
   exists for (section 5 above).

One USB-bridge drop occurred during the capture ("multiple access on
port?"); close picocom while the tool runs for a clean transcript.

## 6. M8 acceptance re-run (all module bytes changed)

Because driver ABI v3 changes every module container, the M8 serial smoke
modes were re-run on the new bytes (operator-supplied transcripts,
2026-10-05):

| Mode | Marker | Result |
| --- | --- | --- |
| `smoke-hardware-m8-ioc` | `m8 ioc: transport level 08`, `controller level 4A`, `ping x4 OK`, `bulk write 1/128/512 OK`, `done x3 OK`, `bulk read 1/128/512 OK`, `cleanup OK 0x34`, `hid status 00`, `m8 ioc selftest: OK` | OK |
| `make smoke-hardware-m8` | `m8 selftest: input hid.keyboard0 class 04`, `output v9958.0 class 02`, `devices 04`, `ioc level 4A`, `rejected calls OK`, `m8 selftest: OK` | OK |
| `smoke-hardware-m8-console` | `m8 selftest: visible console marker` + native monitor prompt on the V9958 display | OK |

## 7. Not re-run

* `make check` reproducibility of the acceptance images (host) is
  covered; physical re-runs of the remaining M8 fallback modes
  (`m8-fb-*`) and of the M9 acceptance images were not requested.
* No SD/IOC media write test was performed (none is required by this
  package).
