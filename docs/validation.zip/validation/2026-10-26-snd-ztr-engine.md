# libsnd ZTR engine — validation record

Date: 2026-10-26

## Scope

Package 102 completes ZTR playback in `libsnd`: the assembly queue
consumer, event/effect/macro/notation engine, channel renderer and
underrun mute; the C controls and automatic foreground recovery;
SNTracker as an SDK 0.2.0 streaming client; and package 101's deferred
producer acceptance.

The preserved C oracle now lives under `tests/snd/oracle/`.  The target
engine owns aligned channel pages and runs entirely in assembly from
`snd_ztr_tick` to the PSG ports.  DIRECT/valid output compares and
writes inline after one `_snd_fast` test; BATCH and invalid-shadow
output use the shared primitives.

## Semantic results

- The literal Phase 1 port matched both oracle channel state and every
  ordered PSG write for 3,000 ticks of Night Market and RunawayCircuit.
- Each Phase 2 transform was gated against state and writes: work flags,
  cached macro bounds, inline DIRECT writes, the fused channel walk,
  zero-work skips, literal bind/reset behavior and cached initial delay.
- The permanent test repeats the 3,000-tick gate for both songs in both
  DIRECT and BATCH output modes.
- Pause holds silent ticks and resume restores state; stop releases the
  mask.  A manual note inside the mask returns `-KOS_EBUSY`, while one
  outside succeeds.
- A stalled reader drains the queue, mutes the audible voice, records one
  underrun, automatically restores through `snd_service`, and consumes
  the exact due row on the next tick.
- A generated short song with native effect 6 reaches `DONE` on its
  third tick at order 0, row 1.
- Night Market also reaches its natural end in `DONE` after 11,518 ticks.

## Producer and reader results

- `snd_ztr_open` now performs the documented forward pass: strings,
  orders, instruments, macro data, pattern directory, pattern streams
  and divisors are visited in order.  Resident sections use bounded
  256-byte reads.  The counting host reader reports no backward offset
  during open for either song.
- Normal reads and forced three-byte short reads produce identical rows;
  a transient error cleanly returns `-KOS_EIO`.
- All malformed ZTR fixtures are refused by the SDK loader.
- Host producer rows equal `ztr_trace --rows` for every order of both
  songs.  Per-order target checksums equal the host from raw card files
  and from sealed KRES resources.
- Interrupt-excluded application-mapped producer profiles: Night Market
  `snd_ztr_open` is 25,801,339 T-states; one bounded `snd_service` call
  after freeing a queue slot is 60,072 T-states.  Open validates the
  complete song; service remains foreground-only.

## Tick budgets

The simulator charges every conditional branch its taken cost.  Sampled
profiles before the full gate measured:

| song | start/bind tick | later row ticks | active steady ticks |
|---|---:|---:|---:|
| Night Market | 15,757 | 6,719–8,486 | 3,426–6,016 |
| RunawayCircuit | 15,670 | 7,791–7,799 | 4,498–5,240 |

The full DIRECT gate measured:

| song | 3,000-tick median | worst tick | worst index | `snd_tick` stack |
|---|---:|---:|---:|---:|
| Night Market | 17,123 | 54,861 | 1,668 | 26 bytes |
| RunawayCircuit | 10,433 | 100,522 | 2,628 | 26 bytes |

The initial samples exceed the 15,000 target by 757 and 670 T-states,
and the full-song medians and worst ticks also exceed their 6,000 and
15,000 targets.  Profiles are led by row application, macro reset/bind,
due macro work and the fused walk.  The overruns are reported as required
rather than trading away oracle semantics.

No OS source is changed.

## Client

SNTracker links SDK 0.2.0 with `LIBS=snd`, wraps its `FILE *` in the
stdio reader, calls `snd_tick(count)` from the timer handler and
`snd_service()` in foreground.  Its private ZTR/player/PSG sources are
removed, while the old implementation remains available only as the
test oracle.  The compiler's default ZTR limit is the format limit,
65,535 bytes.

## Final validation

The required block passed on 2026-10-26:

- `make && make sdk && make -C UserSoftware/SNTracker test`: PASS;
  SNTracker's four client tests pass and `sntrack.exe` validates at
  31,946 bytes, SHA-256
  `1a70d91682f7b789d8749cf1e1ab4cac948a5e0728b7e92090f26896f9877a03`.
- `python3 -m unittest tests.test_snd tests.test_snd_oracle
  tests.test_sdk_package`: PASS, 53 tests.
- `make clean && make check`: PASS, 996 tests with 119 expected skips;
  reproducible production image SHA-256
  `48275a3aa624f6e633c002dc177c828bfed3b518d8e431b05d4f87617644e828`.
- `git diff --check`: PASS.

After recording the final measured costs in `docs/sdk.md`, `make sdk`,
all 14 `tests.test_sdk_package` tests and `git diff --check` were rerun
and passed.

## Board checklist

Still manual: play `sntrack night-market.ztr` and
`sntrack RunawayCircuit.ztr` from a physical card, compare audibly with
the old binary, and confirm Q returns silently.
