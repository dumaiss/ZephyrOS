# M10 consoles selected per build (work package 42e)

Work package: `work/42e-m10-console-builds/WORK.md` (M10 step 8,
architecture 36.11/36.12).  The console driver's runtime choice between
V9958+HID and serial is replaced by two build-selected CONSOLE drivers,
each host-wired to its dependencies and each publishing `/dev/console`;
the HID readiness probe and the fallback branches are gone.  A required
driver that fails to load or initialize is now an explicit boot failure
on the early console, and a tiny `/SYSTEM` program makes the V9958
display reset (ESC `c`) checkable on the board.  The working log is
`work/42e-m10-console-builds/progress.md`.

## 1. Files added, moved, removed and materially changed

Added:

| file | content |
| --- | --- |
| `services/manifests/console-v9958-hid.json` | the production CONSOLE: endpoint 6.0, publishes `/dev/console`, requires HID (4.0) and VIDEO (2.0), no optional flag |
| `services/manifests/console-serial.json` | the serial CONSOLE: same endpoint/publication, requires SERIAL (1.0) |
| `tests/console/manifest-serial.json` | the serial variant's production-like store (same set, `console-serial`) |
| `tests/console/manifest-serial-missing.json` | the boot-failure store: the same set and `services.man` without `console-serial.zmod` |
| `tests/console/escc.c` | the ESC `c` display-reset check program (writes ESC `c` + a line, then execs the monitor) |
| `tests/test_console_serial.py` | replays the serial variant (monitor prompt, typed line and relaunch on the serial lane) and the required-console boot-failure image |
| `tests/ns/manifests/console-serial.json` | the namespace image's serial-console manifest (replaces `console.json`) |

Removed:

| file | reason |
| --- | --- |
| `services/manifests/console.json` | replaced by the two build-selected manifests (its optional-dependency composition was the runtime fallback) |
| `tests/console/manifest-fallback-nohid.json`, `tests/console/manifest-fallback-nohid-nov9958.json` | the runtime-fallback stores; a subset store can no longer express a console composition |
| `tests/target/console/fallback_test.c`, `tests/target/include/console_fallback_selftest.h` | the fallback diagnostic; its subject (runtime composition) is removed |
| `tests/test_console_fallback.py` | the fallback matrix; replaced by `tests/test_console_serial.py` |
| `tests/ns/manifests/console.json` | replaced by `console-serial.json` |

Materially changed:

- `services/console/console_service.c` is now one shared source compiled
  twice: `console-v9958-hid.rel` (HID input / VIDEO output) and
  `console-serial.rel` (`-DZOS_CONSOLE_SERIAL=1`; SERIAL both
  directions).  The init probes nothing and never falls back; it reads
  the two host-resolved dependency numbers and refuses a zero one.  The
  dispatch forwards each console operation to the selected endpoint with
  the protocol's own op number.
- `include/zephyros/ipc.h`, `kernel/memory/upcall.asm`,
  `kernel/memory/upcall.h`: the init entry's `uint8_t` status is
  published by the upcall shim (`zos_upcall_ret_a`, the target's A at
  return).
- `kernel/service/service_loader.c`: refuses an image whose init returns
  non-zero (`invalid`); its header documents the status contract.
- `kernel/main.c`: `kernel_boot_services` returns the loader's failure
  and the boot stops on the early console (`console: service failed` and
  the halt loop) instead of continuing into the launcher.
- Every service init (`sio`, `ioc`, `hid`, `v9958`, both console images,
  `iocfat`, `nsdev`, the six IPC synthetic services) returns its status,
  0 in every normal case.  `hid_service_init` also fails on a missing
  required IOC number; its down-link policy stays soft (the link is
  recoverable, so the serial-console build boots without the MCU).
- The Makefile: `ZOS_CONSOLE ?= console-v9958-hid` selects the console;
  every subset image that has no HID+VIDEO pair selects `console-serial`;
  the fallback machinery (`ZOS_CONSOLE_FALLBACK*`, the two fallback
  targets, the smoke modes and their images) is deleted and replaced by
  `console-serial-selftest` (the serial variant plus the required-console
  boot-failure image).  The console integration image now boots
  `/SYSTEM/escc.zex`.
- Every image manifest that carried `console.zmod` carries
  `console-v9958-hid.zmod` (production, helloworld, integration) or
  `console-serial.zmod` (subsystem, IOC, HID, video, FS, IPC, namespace).
- The target diagnostics' comments, the sim tests that pinned the old
  names/lanes, `tools/serial_smoke.py` (a `console-serial` mode replaces
  the two fallback modes) and the docs listed in section 5.

## 2. The two drivers

| image | dependencies (host-resolved) | forwarded ops | hot bytes |
| --- | --- | --- | --- |
| `console-v9958-hid` | HID 4.0, VIDEO 2.0 (both required) | HID READ_TEXT/GETC/POLL, VIDEO WRITE/PUTC | 223 (219 + 4 BSS) |
| `console-serial` | SERIAL 1.0 (required) | SIO READ/GETC/POLL/WRITE/PUTC | 222 (218 + 4 BSS) |

The old console image was 416 bytes; the production console is 223, so
the driver itself shrinks by 193 bytes.

## 3. The five ledgers, before (42c) and after (42e)

All figures are the production `make` ledgers.

| ledger | before (42c) | after (42e) |
| --- | --- | --- |
| fixed core | `code end 3C9Bh, 8179 required + 2 overflow + 768 stacks, room 7435` | `code end 3C9Eh, 8183 required + 2 overflow + 768 stacks, room 7431` |
| cold code | `17845 bytes end A5B5h` | `17850 bytes end A5BAh` |
| cold data | `1241 bytes at A600h, room 13607` | unchanged |
| common | `used 2358 of 7424 (code 1511, data 847), ceiling 3072, m10 512, limit 2560` | unchanged |
| bank-6 workers | `driver hot 22013 / boot-bulk 2170` | `driver hot 21846 / boot-bulk 2170` |

Per-image production sizes (`image + BSS`, from the pack reports):

| image | 42c | 42e | delta | why |
| --- | --- | --- | --- | --- |
| sio | 937 | 938 | +1 | init status return |
| ioc | 5059 | 5060 | +1 | init status return |
| hid | 1717 | 1722 | +5 | init status return + missing-dep refusal |
| v9958 | 7150 | 7151 | +1 | init status return |
| console | 416 | 223 | -193 | one source, no probe, no fallback, one endpoint |
| iocfat | 8904 | 8922 | +18 | init status return path |

The service loader is **1,986 bytes** (1,985 code + 1 data, measured from
`build/service_loader.rel` as in 42c) - the init-status check costs no
net bytes against the 42c figure, and the 2,000-byte review target still
holds.

## 4. Result

- Two CONSOLE drivers are selected per build; the production build packs
  `console-v9958-hid`, the variant packs `console-serial`, and neither
  probes or falls back at run time.
- Both builds boot to `/dev/console`; the serial variant's whole dynamic
  console (boot line, monitor banner/prompt, typed answers) is on
  SIO0/B, and the production build's is on the V9958.
- A required driver that fails to load or initialize is an explicit
  boot failure: the loader names it, the nucleus prints the manifest
  failure and halts before the launcher (replayed from the real bytes by
  `tests/test_console_serial.py`).
- The console integration image writes ESC `c` through the production
  console before the monitor; the replay proves the V9958 bring-up
  sequence ran twice (boot + reset) and the follow-up line reached the
  display.
- The M9-era runtime fallback machinery (images, target diagnostic,
  manifests, Makefile switches, smoke modes, test module) is deleted
  with its reasons (section 1).

## 5. Docs

`docs/devices.md` section 8 is rewritten for the two build-selected
drivers (table, no-probe/no-fallback contract, the failure row, the ESC
`c` boot program, the serial smoke mode); sections 4-7's boot-integration
paragraphs and 12.3/12.5 no longer describe the runtime composition.
`docs/module-format.md` documents the init status and the explicit boot
failure; `docs/abi.md` section 13 drops the retired lookup path from the
console client description; `docs/architecture.md`, `docs/boot.md` and
`README.md` point at the new targets and the serial variant.  The
`test_docs_evidence` citation check passes.

## 6. Validation

All commands were run on the frozen source (after the last source edit
and the last test fix):

```sh
make clean && make check                                                 # exit 0, 93 s
make console-integration-selftest console-serial-selftest ipc-selftest   # exit 0, 1177 s
git diff --check                                                         # exit 0, no output
```

`make check` built the production image, rebuilt it after a clean and
compared the hashes (`check: reproducible rebuild
(6e437af55c436c3d4a95275c098beea6da79cc5783c5879f374d4f7ccc5b9c20)`),
ran the host suite (**562 tests, 0 failures, 0 errors, 112 skipped**),
then repacked and compared the production image (`make check: OK`).

| target | wall | replay tests | image sha256 |
| --- | --- | --- | --- |
| `console-integration-selftest` | 75 s | 7 OK (36.3 s): ESC `c` program, monitor, typed line, V9958 bring-up twice | `cc4376684a57dc1a6c38f659b35a2eac4ad1b0921d78cff0f9a75e79673c15e9` |
| `console-serial-selftest` | 81 s | 4 OK (9.8 s): serial console boot/monitor/typed line; required-console halt image | serial `83531ecb5845cefaea0d7f4aff832bc94bfc70ff4121cd6ca57237b7cfcacece`, fail `a700148edb85c5f204d851c2b2b9a081f650d6d0bfc022fdc4dd3c4e9dffacbd` |
| `ipc-selftest` | 1021 s | 53 OK (981.8 s): IPC images, clients, counters, ledgers | `668f42ff046dc156044692282f823b260d0fc74d2952ebcfe48de4646de0bd51` |

The production image hash is identical before and after the batch.

### Findings outside this package (reported, not fixed)

Probing the full target list surfaced two pre-existing gaps, both on the
42c tree and neither reached by `make check`:

- `romfs-corrupt-selftest` fails to build: its config selects
  `ZOS_SERVICES := sio console-serial` while `ROMFS_MANIFEST` is the
  production `recovery/manifest.json`, so packing stops at `input not
  found: ioc.zmod` - the boot set and the store no longer describe the
  same image (42c changed the two sides independently).
- `tests/test_romfs_sim.py::_derive_scratch` still reads
  `arena.plan.json`, which 42c deleted; nothing reaches it only because
  the image above never builds.  The stale dependency will surface as
  soon as the corrupt image is repaired.

A repair was attempted in this package and reverted: it is 42c/42d
work, and this package's contract does not include that image.

## 7. Hardware (owner)

- production: the USB keyboard, the V9958 and the ESC `c` program (the
  console integration image boots `/SYSTEM/escc.zex`);
- the `console-serial` variant: the monitor prompt on `/dev/ttyUSB0`
  (`make smoke-hardware-console-serial`) and typing on serial.

**Hardware: pending.**  The simulator and image evidence above is what
this package can close.

## Supervisor review (2026-10-10)

**Accepted** on the record's evidence, with hardware pending (owner).
- Production `6e437af5…`.
- Two build-selected consoles from one source, and the console driver
  shrank from 416 to 223 bytes.
- Required-driver failure is an explicit boot halt, tested from real
  bytes.
- ESC `c` is checkable; the fallback machinery is deleted.

The two out-of-scope findings (the broken `romfs-corrupt-selftest` and
`test_romfs_sim`'s stale `arena.plan.json` dependency) and the
1,021-second `ipc-selftest` replay go to package 42d.

### Hardware (owner, 2026-10-10)

`build-console-integration-selftest/…bin` `cc437668…`:
- **ESC `c`: PASS.** The display reset and the follow-up line
  `escc: display reset` is drawn, then the monitor banner and the `Z80>`
  prompt.
- **Keyboard input through `console-v9958-hid`: PASS.** The owner typed
  at the monitor prompt.
- **The `smoke-hardware-console-integration` script: FAIL, a test defect
  rather than a product defect.**
  - The image's self-check printed `console integration: FAIL read`: the
    read check expects input to be ready immediately, which only the
    simulator guarantees.
  - `tools/serial_smoke.py --mode console-integration` also still expects
    M8-era strings (`hid.keyboard0 input class 04`, device count, `PING`).

  → Package 42d fixes both.

Still pending (owner): production `make smoke-hardware` with and without
a FAT card, and `smoke-hardware-console-serial`.
- **Production `make smoke-hardware` (`6e437af5…`): PASS**, owner
  2026-10-10. It boots to the monitor and accepts keyboard input. Still
  open: the card-absent boot and `smoke-hardware-console-serial`.
- **`smoke-hardware-console-serial` (`83531ecb…`): PASS**, owner
  2026-10-10. The `console-serial` variant boots six drivers and prints
  `console: service OK`; the monitor prompt, `r` and `h` work on the
  serial lane (script and interactive picocom). Only the card-absent
  boot remains open.
