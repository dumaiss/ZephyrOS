# M13 read-ahead and cache (package 60)

Implemented by the supervisor (owner request). Drivers, the nucleus copy
primitives and driver API, the simulator. No IOC firmware change; no bank
outside bank 6; the memory model and the copy-path architecture unchanged.

## Change

| area | change |
|---|---|
| `kernel/runtime/fastcopy.inc` | `KOS_FASTCOPY`: an in-place unrolled `LDI` copy (BC mod 16 singly, then 16 per `JP PE`; 16.6 T/byte against `LDIR`'s 21; BC = 0 copies nothing; no stack) |
| `kernel/ipc/ipc_common.asm`, `ipc_asm.asm`, `kernel/memory/user_copy.asm`, `window_copy.asm` | path B and path A copies and both path-C bank gates use it (the ROM-access stub, the small stack and event-frame copies keep `LDIR`) |
| `drivers/runtime/sdcc_indirect_calls.asm` | `kos_block_copy` is the same unrolled loop, written out (drivers include no kernel file) |
| `kernel/ipc/ipc.c`, `drivers/include/driver.h`, `tools/mapcheck.py` | `bulk_write`, the mirror of `bulk_read` (same owner binding and bounds) |
| `drivers/iocfat/iocfat.c`, `iocfat_cache.asm`, `iocfat.json` | a 16 KiB block cache (32 slots plus 8 path records) in the driver's bulk segment, keyed by path and open size, LRU; a 4-block ring in `DRIVER_IO` that the bulk receive fills, with one `copy_out` per run of consecutive blocks and read-ahead when a read continues the previous one; the ring is also the write and enumeration staging; any change through the driver or a stale answer drops the cache |
| `abi/kos/protocol.h`, `tests/perf/readphase.c` | `KFILE_OP_PHASES` control bits (measurement build only): COLD drops the cache, SINGLE turns read-ahead off, so every pass measures one transfer per missed block |
| `tests/z80sim.py` | `LDI` |
| `Makefile` | the cache object; `fastcopy.inc` and `driver.h` dependencies (the IPC test drivers had none on `driver.h`: a stale object called the API table one slot off after `bulk_write` was added) |
| tests | `test_readpath.py`: a re-read stays off the card until a write (behavioural); `test_iocfat.py`: the cache geometry equals the packed bulk segment; manifest pins; the fs-selftest slot layout |
| docs | the devices, architecture and memory pages |

## Not done, by measurement

- **Pipelined fill (requirements 3-4).** After dispatch the controller
  waits 200 us (`EXTSYNC_REPLY_GUARD_US`) and clocks the reply at ~8-10
  us/byte with no host handshake, into a three-byte FIFO, so the host has
  ~25-30 us from the first byte. The nucleus IRQ path costs ~1200 T
  (~120 us) to reach a driver handler, and the work to overlap (the
  caller copy, the cache store) is nucleus copies whose call cost alone
  exceeds the budget. Not achievable without a firmware change.
- **One IOC call per block.** Worth ~0.3-0.4 ms per block (2-3%) and it
  would run the bulk before IOC-FAT validates READY; left out.
- **Compiler flags.** `--fomit-frame-pointer` on the drivers produces the
  byte-fragmented relocations the packer refuses; on the nucleus it cost
  1.6 KiB of fixed room and 5.6 KiB of cold room (521 bytes left) and the
  image did not complete the measurement run. Left to the SDK (61).

## Measurement (simulator, phase image, cold, read-ahead off)

| | before (59) | after |
|---|---|---|
| 512-byte miss, path B (`timer`) | 13.59 ms | 13.70 ms |
| `caller` (copy out, 512 B) | 1.66 ms | 1.43 ms |
| 512-byte miss, path C | 16.74 ms | 16.54 ms |

The miss now also stores the block in the cache (`bulk_write`, inside
`copy`). Cache hits (the earlier phase run without COLD): 128-byte read
5.1 ms, 512-byte read 5.8 ms door to door, of which ~1.7 ms is the
driver; the rest is the syscall, VFS and SDK path (package 61).

## Board (owner)

Pending: SDBENCH (cold), a small file or program read twice, `hwtest`,
`fs_selftest`, `timer card`, `vgmplay`, keyboard during a long read.

## Validation

```
make clean && make check                OK (reproducible rebuild d92b7443...; 779 tests, 115 image tests skipped)
make ipc-selftest                       OK (40 tests)
make phase-image                        OK (15 tests)
make fs-selftest                        OK (3 tests, plus the image's follow-on suites)
git diff --check                        OK
```

The first full check failed three source-layout rules: the copy macro sat
in `platform/` (constants only), and the IOC-FAT directory's file list did
not name `iocfat_cache.asm`. The macro moved to `kernel/runtime/`, the
drivers' copy writes the loop out, and the pin names the new file.
