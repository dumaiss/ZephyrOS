# KonaOS rename (work package 48)

Work package: `work/48-konaos-rename/WORK.md`, owner decision 2026-10-12.
A rename only: the OS is **KonaOS**, with the `kos` code prefix, the EXE
executable container (`KEX2`) and the MOD module container (`KMOD`); the
hardware keeps the Zephyr-80 name.  The working log is
`work/48-konaos-rename/progress.md`.  Baseline: the accepted 46 tree
(HEAD `676924c`, production image `c4b407ee...`).  Runs after 46 and
before 47.  **No commit was made** (owner instruction).

## 1. What changed

Rules R1-R5 of the WORK.md, applied in order as case-sensitive substring
replacements over every tracked file except `work/` and
`docs/validation/`, plus the two stored header magics:

| rule | replacement |
| --- | --- |
| R1 | `ZephyrOS`/`zephyros`/`ZEPHYROS` -> `KonaOS`/`konaos`/`KONAOS` |
| R2 | `zos`/`ZOS`/`Zos` -> `kos`/`KOS`/`Kos` |
| R3 | `zex`/`ZEX`/`Zex` -> `exe`/`EXE`/`Exe`; magic `ZEX2` -> `KEX2` (`4B 45 58 32`), version stays 2 |
| R4 | `zmod`/`ZMOD`/`Zmod` -> `mod`/`MOD`/`Mod`; magic `ZMOD` -> `KMOD` (`4B 4D 4F 44`) |
| R5 | the public families `ZFS_`/`zfs_` -> `KFS_`/`kfs_`, `ZFILE_`, `ZCONSOLE_`, `ZVIDEO_`, `ZHID_`/`zhid_`, `ZSIO_`, `ZIOC_`/`zioc_`, `ZCAP_`, `ZREL_` -> `K*`, and `zlibc`/`ZLIBC_` -> `klibc`/`KLIBC_` (directories included) |

Tree moves (all `git mv`; 4 directories, 18 files):

```text
abi/zos/                              -> abi/kos/
user/sdk/include/zos/                 -> user/sdk/include/kos/
user/sdk/include/zlibc/               -> user/sdk/include/klibc/
user/sdk/src/zlibc/                   -> user/sdk/src/klibc/
docs/zex-format.md                    -> docs/exe-format.md
formats/include/zex.h                 -> formats/include/exe.h
formats/include/zmod.h                -> formats/include/mod.h
tests/subsys/gen_zex2_segments.py     -> tests/subsys/gen_exe2_segments.py
tests/subsys/gen_zex_fixtures.py      -> tests/subsys/gen_exe_fixtures.py
tests/target/process/zex2big.c        -> tests/target/process/exe2big.c
tests/target/process/zex2probe.c      -> tests/target/process/exe2probe.c
tests/target/process/zex2seg.c        -> tests/target/process/exe2seg.c
tests/target/process/zextest.c        -> tests/target/process/exetest.c
tests/target/process/zextest_sp.asm   -> tests/target/process/exetest_sp.asm
tests/test_zex.py                     -> tests/test_exe.py
tests/test_zmod.py                    -> tests/test_mod.py
tools/zexmanifest.py                  -> tools/exemanifest.py
tools/zexpack.py                      -> tools/exepack.py
tools/zmodpack.py                     -> tools/modpack.py
user/sdk/include/zos.h                -> user/sdk/include/kos.h
user/sdk/src/zos_internal.h           -> user/sdk/src/kos_internal.h
user/sdk/zex.mk                       -> user/sdk/exe.mk
```

308 paths differ from the baseline: 59 renamed (all with content edits),
248 modified, 1 removed (`tests/test_docs_evidence.py`, below).  No file
was added.  The rename script and its line-level change report are kept
with the session artifacts (`files/rename.py`, `files/changes.txt`).

## 2. Two build fixes the rename forced

**The boot path no longer travels through `-D`.**  SDCC 4.5.0's driver
aborts when any argument contains `.exe` (`SDCCutil.c`
`setPrefixSuffix` asserts `strstr (arg, ".exe") == NULL` over the whole
preprocessor command line), and every `KOS_BOOT_PROGRAM` is an EXE.  The
setting is now written by the build into the generated header
`$(BUILD)/boot_program.h`, which `kernel/main.c` includes; the compiled
string, the `tools/bootprogram.py` validation and the manifest
dependency are unchanged.  A minimal reproduction:

```text
$ sdcc -mz80 -c -DFOO=x.exe t.c -o t.rel
at 1: error 9: FATAL Compiler Internal Error in file 'SDCCutil.c' line
number '1170' : strstr (arg, ".exe") == NULL
```

**Program link layout.**  `sdld` pulls library members in
symbol-hash-table order (`sdas/linksrc/lklibr.c`, `library()` iterates
`symhash`); renaming the SDK symbols `_zos_*` -> `_kos_*` changes that
order, so the linked user programs (`fs_child.exe`, `hwtest.exe`, the
`xmem` programs) differ in layout even where no string changed.
Controlled experiment: the same three objects link `fs` before `args`
against the old `libzos.lib` and `args` before `fs` against the new
`libkos.lib`; the two archives differ only in the renamed symbols.  This
is the one end-check item reported as an "other change" (section 5).

## 3. End check against the baseline (`c4b407ee...`)

Production image: `c4b407ee6a2cc0f1a885686c0547a911a2718d75b03df83e44ee0a7dd7570a08`
-> `8a4f4067eede87ac48caeef908d2a5ee041e4b09094f7ab1a0acbedfc4f1d468`,
524288 bytes both (`build/konaos.bin`, byte-identical to
`build/zephyr80.bin`).

Ledgers (manifest `nucleus`), before -> after:

| ledger | before | after |
| --- | --- | --- |
| fixed core required + overflow + stacks | 8335 + 2 + 768, room 7279, end `3D2Ch` | unchanged |
| cold half code | 23347, end `BB33h` | **23345, end `BB31h`** |
| cold half data | 1527 at `BC00h`, room 7689 | unchanged |
| driver hot | 21910 of 32768 | unchanged |
| driver boot/bulk | 2170 of 24576 | unchanged |
| common | used 2358 of 7424 (code 1511, data 847), ceiling 3072 | unchanged |
| gate stack | 384 reserved (`E5F0h-E770h`) | unchanged |

Region-by-region (page 1 is the bank-7 OS image, page 0 holds the
common region):

- **page zero, reset copier, fixed core size**: identical.
- **fixed core `2000h-5FFFh`**: two operands relocated by the cold
  half's two-byte shrink, nothing else: `2007h` `CD 79 69` -> `CD 77 69`
  (a call into the cold half), `203Ch` `D6 33` -> `D6 31`.
- **cold half `6000h-E000h`**: the boot path string at `630Ch`
  (`/system/monitor.zex` -> `/system/monitor.exe`, three bytes in place,
  same length) and the banner at `65FBh` (`ZephyrOS 0.0` -> `KonaOS 0.0`,
  two bytes shorter); every byte after the banner shifts down by two,
  which is the whole difference.  The cold data base stays at `BC00h`
  (the 512-byte alignment absorbs the shrink).
- **common `E000h-FD00h`**: one relocated call target at `E474h`
  (`CD 40 A3` -> `CD 3E A3`); the gate stack (`E5F0h-E770h`) is
  byte-identical.
- **pages 4-7**: identical; pages 0/1 and the store pages 2/3 carry the
  changes above.

Driver images: every container is identical except offset 0, the magic
first byte (`5Ah` -> `4Bh`); sizes unchanged (`sio` 934, `ioc` 4468,
`hid` 1733, `v9958` 6700, `console-v9958-hid` 283, `iocfat` 7847), so
the driver hot and boot/bulk tiers are byte-identical.

## 4. Re-pinned artefacts

- `tests/test_console_acceptance.py`: `MONITOR_SIZE` 6068 -> **6066**;
  `MONITOR_SHA256`
  `41430a5f...` -> **`4d27328bd1ca820f156594ef47b5691e0c69369cc33f7da06cbf1772ccca7d18`**
  (the monitor banner is two bytes shorter and the program relayouts).
- `tests/test_v9958.py` `PINNED_FONT_SHA256` is unchanged: the font
  asset edit is its header comment, and the parsed 2048-byte payload is
  still `6db207e0...`.
- No other pinned hash or size moved.

Tests added (rule 3, one negative test per format; the old magic is
written as hex bytes so the final grep stays empty):

- `tests/test_exe.py::TestFixtureBoundaries::test_old_magic_is_rejected`
  with `tests/subsys/gen_exe_fixtures.old_magic_container()` (bytes
  `5A 45 58 32`), asserting the ordinary `EXE_EXEC_ERR_MAGIC` boundary;
- `tests/test_mod.py::TestContainerValidation::test_old_magic_is_rejected`
  (bytes `5A 4D 4F 44`), asserting the ordinary "bad magic" error.

Fixtures build their containers through `exepack.MAGIC`/`modpack.MAGIC`,
so every fixture switched to the new magic with the tools.

Dropped, by the owner decision of 2026-10-12 ("no test depends on
documentation"): `tests/test_docs_evidence.py` (its subject is
documentation/evidence integrity; the citations of the frozen
`docs/validation/` records cannot follow the rename because the rules
are not applied in that directory) and the documentation-reading
assertions of
`tests/test_iocfat.py::test_the_residency_keeps_the_path_in_the_workspace`
(the source-residency assertion stays; the method was renamed).
`tests/test_sdk.py`'s expected program list was re-ordered (`exe2*` and
`exetest` sort before `fardemo` now; same set, no weakening).

## 5. Unmapped

Left unchanged, per WORK.md rule 1:

- the private prefixes: `zt_`, `ZT_`, `zrt_`, `ZRT_`, `zn_`, `zs_`,
  `zout`, `zxmem_`, `ZDRIVER_`;
- the hardware and the CPU/toolchain names: `Zephyr-80`, `zephyr80`,
  `ZEPHYR80`, `platform/zephyr80/`, `z80`, `z80sim.py`, `sdldz80`,
  `sdasz80`;
- the ROMFS container magic `ZRFS` and the ROMFS media model (no rule
  covers them);
- protocol constants that happen to share the old 5Ah value or the IP
  names: `IPC_STREAM_MAGIC` (`5Ah`), `IPC_BOOT_MAGIC`, `NS_MAGIC`,
  `KOS_NS_STUB_MAGIC`, the process-selftest 4-byte mark `5A 69 A5 C3`;
- the excluded trees: `work/`, `docs/validation/`, the repository
  directory and the git remote (out of scope).

Reported as "other change" with its cause (the end check): the user
programs in the store are not byte-identical to package 46's; the SDK
symbol renames change `sdld`'s library-pull order (section 2).  The
linked code, sizes and behaviour are unchanged; monitor is additionally
two bytes shorter (its banner).

Documentation note: the two live-doc citations of the frozen record
`docs/validation/2026-10-03-m6-zex.md` follow the rename and now spell
`docs/validation/2026-10-03-m6-exe.md`; the record file itself keeps its
name.  Package 47 rewrites the docs.

## 6. Store before and after

| entry | before | after | change |
| --- | --- | --- | --- |
| the 6 drivers (`sio.zmod` ...) | 934/4468/1733/6700/283/7847 | same, `.mod` | magic byte 0 (`5Ah`->`4Bh`) |
| `drivers.man` | 144 | 144 | 24 name bytes (`zmod` -> `mod`) |
| `monitor.zex` -> `monitor.exe` | 6068 | **6066** | magic, banner string, layout |
| `hwtest.zex` -> `.exe` | 12082 | 12082 | magic, embedded `/system/*.exe` paths, layout |
| `xmem_selftest/_child/_far` | 12032/7797/8353 | same | magic, paths, layout |
| `fs_selftest/fs_child` | 11376/8052 | same | magic, paths, layout |

Stream: 88389 bytes, sha `2d2f8f3c...` -> **88387 bytes**, sha
`bdc6eb4f904289ffb7795062bf12b32e7ddc3dccd47a7bc6290a5e950318a4b8`.
The directory holds the same 14 entries; every payload offset before the
monitor is unchanged, the two-byte shift follows it (hwtest `28697` ->
`28695`, ...).  The name table carries the renamed entries (`zmod` ->
`mod`, `zex` -> `exe`), and the header's `image_size` low byte is the
only other header byte changed (`45h` -> `43h`).  The image manifest's
`romfs` placement is pages 2 (`49152` bytes) and 3 (`39237` ->
`39235`).

## 7. Validation (once, at the end, on the frozen source)

```sh
make KOS_JOBS=16 clean && make KOS_JOBS=16 check
#   exit 0, 3m50s; reproducible rebuild 8a4f4067...; 607 tests OK,
#   104 skipped (the image replays build in their own targets);
#   mapcheck: OK (18 areas, 362 symbols) [production];
#   cmp build/konaos.bin build/zephyr80.bin byte-identical
make -j16 all subsystem-selftest nucleus-selftest \
     console-integration-selftest console-serial-selftest \
     fs-selftest ns-selftest ipc-selftest xmem-selftest \
     helloworld-image
#   exit 0, 10m31s; 163 tests, no failure, no skip
git diff --check
#   exit 0, no output
grep -rIl -e zos -e ZOS -e zex -e ZEX -e zmod -e ZMOD -e ZephyrOS \
  --exclude-dir=.git --exclude-dir=work --exclude-dir=validation \
  --exclude-dir='build*' .
#   no output
```

The batch log interleaves the targets under `-j16`, so the matrix was
re-run once with `make -Otarget -j16` (6m09s, builds up to date) to
attribute the counts; all 13 replays are green:

| target | tests | wall |
| --- | --- | --- |
| `subsystem-selftest` | 30 (4 + 26) | 99.2 s |
| `nucleus-selftest` | 6 | 0.2 s |
| `console-integration-selftest` | 15 (7+2+2+4) | 139.2 s |
| `console-serial-selftest` | 6 | 15.6 s |
| `fs-selftest` | 3 | 67.1 s |
| `ns-selftest` | 27 | 18.9 s |
| `ipc-selftest` | 40 | 368.8 s |
| `xmem-selftest` | 8 | 311.4 s |
| `helloworld-image` | 28 | 12.0 s |
| **total** | **163** | — |

Image hashes (post-rename names):

```text
8a4f4067eede87ac48caeef908d2a5ee041e4b09094f7ab1a0acbedfc4f1d468  build/konaos.bin (= build/zephyr80.bin)
bdc6eb4f904289ffb7795062bf12b32e7ddc3dccd47a7bc6290a5e950318a4b8  build/recovery.romfs
f5f6da45d5ea96d4f5467c7acf79bdeba80feb1bb557a3815dfd64393637ea6b  build-subsys-selftest/konaos-subsys-selftest.bin
4bf8525ce76403605414525e2825890c3d8e092a5485cbff5a40794f100ac3a6  build-nucleus-selftest/konaos-nucleus-selftest.bin
a597ed6203e8890289dba68501568364ee1db5bb9e62901dee9cd6b3b3563b38  build-console-integration-selftest/konaos-console-integration-selftest.bin
26b48dd21608eecc63d186e0d87b98d5d612bf654554df776deb5b14b4b67d16  build-console-serial-selftest/konaos-console-serial-selftest.bin
e654c2ba9918ea9ed056183c5508e43c7055b726fa4bf9e87510e773842fc510  build-console-serial-fail-selftest/konaos-console-serial-fail-selftest.bin
9235384e8abb6995e8f28c2b15f7a96e9a2d1e89394147e9e920ec833b3dba8b  build-driver-init-fail-selftest/konaos-driver-init-fail-selftest.bin
9b3a94daa6ef17ba375d77cc687b1df37e7d529a61c18bd369426bb8fd5df3f8  build-fs-selftest/konaos-fs-selftest.bin
30b6d09f6b8ba3f974105da17bc97654ac188a9dc5913ecb298880dda3b12a86  build-ns-selftest/konaos-ns-selftest.bin
0b5b510eaab9dcd11bb37f0b292eab092adf955bd4d44b25c16006f353d1a6de  build-ipc-selftest/konaos-ipc-selftest.bin
ab9df3f1d0120c73d76a21ddc264b9877b8ba488a498c6fc04614383ad85645e  build-xmem-selftest/konaos-xmem-selftest.bin
b9e76862a674a6d796150be7dbf0d45716cc2de54105296e0358e5301349dd7e  build-helloworld/konaos-helloworld.bin
```

Skips and warnings:

- `make check` 104 skips: the image-replay tests whose acceptance images
  build only in their matrix targets (the same skips as package 46).
  The matrix itself has no skip.
- The host run prints the pre-existing Python `ResourceWarning`s
  (unclosed test/tool files, e.g. `tools/modpack.py`); no compiler
  warning and no new one.
- No new test-only hook was added; no behaviour change beyond the
  stored header bytes.

Uncertainties / deviations, in full: the program relayout of section 2
(reported, not a defect); the documentation-dependent tests dropped by
owner decision (section 4); the boot-program header (section 2); the
renamed citations of the frozen M6 record (section 5).  The tree was
clean at the start; no pre-existing unrelated change was present, so
nothing had to be preserved.  Handoff: package 47 (documentation pass)
follows, with the final KonaOS names in place.

## Supervisor review (2026-10-12)

**Accepted.**

- **End check holds:**
  - the fixed core is unchanged except two relocated operands;
  - the cold half is −2 bytes (the banner);
  - common is unchanged except one relocated call;
  - the gate stack, driver hot and driver boot are byte-identical;
  - the driver images differ only in the magic byte.
- **Grep gate:** empty. All 163 matrix tests pass, and both negative
  magic tests were added.
- **Program relayout:** the `sdld` library-pull order, explained by a
  controlled experiment. It is accepted as a reported change, not a
  defect.
- **The SDCC `.exe` assertion** is an important finding: no compiler
  argument may contain `.exe`. Passing the boot path through a generated
  header is the right fix. Packages 49a and later must keep stored paths
  out of `-D` flags (added to 49a).
- **Dropped documentation-evidence tests:** an owner decision recorded in
  progress.md ("no test depends on documentation").
- **Left for 47:**
  - the live-doc citation `docs/validation/2026-10-03-m6-exe.md` does not
    exist; the file keeps its `zex` name;
  - mechanical grammar ("a EXE").
- **The ROMFS magic `ZRFS`** stays as unmapped. Renaming it is an open
  owner question.
