# TUI caller-buffered save/restore: validation

## Result

`tui_saved_size`, `tui_save` and `tui_restore` live in the separately
pullable `tui_region.rel` member.  Rectangles are clipped once by the common
clipping layer; the size is the clipped row-major cell count times
`sizeof(struct tui_cell)`.  There is no allocator, pool, flush, cursor move,
style change or window change.  Restore copies character and attribute and
dirties only cells whose value changes.

The `region` mode saves a 20 x 8 mixed-style rectangle, draws a 12 x 4 popup
over it, restores the exact character/attribute map, restores the same buffer
again with no cell run, and checks short/null buffers, zero-area clips, a
null size pointer and a nested-window relative save.  Serial writes were
`[103, 27, 118, 79, 18]`; restoring identical cells emitted no cell run.

`tui_region.rel` is 4,962 bytes.  `tui_core_probe.exe`, which never calls the
region API, has no `tui_region` member and no `_tui_save`/`_tui_restore`/
`_tui_saved_size` symbol.  Its image is 7,581 bytes with 5,129 bytes BSS, the
same BSS as the render-only widget probe; the 320-byte test region buffer is
test-only and the modal member's 1,920-byte buffer is in the widget archive.

## Validation

```sh
make build/user/tui_test.exe build/user/tui_core_probe.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_sdk_package
git diff --check
```

The combined package 68-72 run completed 173 tests with 171 passed and 2
environmental skips; `git diff --check` was clean.

## Supervisor acceptance

Accepted on 2026-10-18. Direct review confirmed that clipping happens before
size/copy work, short and null buffers cannot partially copy, restore dirties
only changed cells, and the region member remains absent from the core-only
probe. The worker's combined 173-test result is accepted; the supervisor also
observed the static/link-map checks and both focused region simulator routes
pass before stopping duplicate validation at the owner's request.

The public header and architecture comment were aligned with the implemented
contract: required storage is the clipped area times `sizeof(struct tui_cell)`,
as returned by `tui_saved_size()`.
