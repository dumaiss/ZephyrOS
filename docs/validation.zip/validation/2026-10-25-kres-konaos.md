# KRES KonaOS edition (package 92) — validation record

2026-10-25.  The package's contract: `work/92-kres-konaos/WORK.md`.

## What shipped

- **libkres.lib** in the SDK (`LIBS=kres`), ten members split so a
  sealed-container reader links only the read path, the adapter's read
  side and the cache.  `kres_zero_page` (512 bytes) lives in the
  mutation member.
- **The KonaOS adapter** (`kres_io_konaos` / `kres_io_konaos_read`):
  the SDK file API, 8.3 swap names, zero-record extension, and the
  65,535-record refusal (the header parser enforces
  `next_record > 65,535`).
- **The XMEM catalog cache**: one 2 KiB object per open container,
  xalloc at open, xfree at close on every path.
- **krestest** (build/edit/edit2/read/compact/extract/readonly) and
  **kresread** (read-only install, the link-split proof).
- **The `call()` refusal check**: `fs_selftest`'s truncate tail sends
  an op the FILE gate does not forward (0xEE) and requires
  `-KOS_EINVAL` back.

## Validation

```sh
make && make sdk && make kres-host
python3 -m unittest tests.test_kres tests.test_kres_native \
    tests.test_truncate tests.test_sdk tests.test_sdk_package \
    tests.test_source_layout
make clean && make check
git diff --check
```

- `make`, `make sdk` (64 SDK files with libkres.lib) and
  `make kres-host` clean.
- The unittest block: 115 tests, OK (one pre-existing skip).
- `make clean && make check`: reproducible (the image hashes match
  across the clean rebuild) and the discovery suite passes.
- The fs-selftest image was rebuilt after the clean and
  `tests.test_truncate` + `tests.test_fs_selftest_sim` pass with the
  new check (CHECKS 14).
- `git diff --check` clean; the worker discipline grep prints nothing.

### The `call()` refusal check discriminates

With `user/sdk/src/ipc.c`'s `call()` temporarily reverted to
`return (int)kos_ipc_call_block.status;`, the truncate replay fails at

```
fs-selftest: FAIL trunc-call-refusal
```

(the kernel refuses before the provider, so the reply status reads 0
and the refusal would be lost).  Reverted back, the replay passes;
the change is permanent.

## Sizes (SDCC .rel areas, bytes)

| member | _CODE | _DATA |
|---|---|---|
| kres_util | 1,740 | 522 |
| kres_read | 2,884 | - |
| kres_adapter | 1,487 | 10 |
| kres_cache_xmem | 1,716 | 16 |
| **read-only link** | **7,827** | **548** |
| kres_mut | 7,901 | - |
| kres_build | 1,582 | 65 |
| kres_compact | 1,711 | 320 |
| kres_verify | 1,630 | - |
| kres_extract | 230 | - |
| kres_adapter_mut | 173 | - |
| **full link** | **21,054** | 933 |

Programs: krestest.exe 31,321 bytes, kresread.exe 15,191 bytes;
libkres.lib 156,498 bytes.

### The read-only target (report)

The package targets <= 3 KiB of code for a sealed-container reader;
the measured read-only link is 7,827 bytes of `_CODE` — an overrun of
4,755 bytes, to report rather than chase in this package.  Where the
bytes go:

- kres_util 1,740: `kres_header_parse` 470, `kres_entry_info` 248,
  `kres_find` 182, the entry get/emit codecs, the install.
- kres_read 2,884: `kres_open` 690, `kres_read` 687,
  `kres_read_records` 622, the iterator and the seek/read paths.
- kres_adapter 1,487: `kres_kona_map_swap_name` 712,
  `kres_kona_open` 311, the size/seek wrappers.
- kres_cache_xmem 1,716: the two-slot XMEM object manager and the
  four-record moves.

What package 92 did: `kres_zero_page` moved out of the read path
(-512), the header parser's fixed fields became one 32-bit compare per
pair (-31), and a reader links nothing mutation-side.  What remains is
the core itself: the read path and header code is plain C for
portability, and SDCC's Z80 codegen for the bounds-checked accessors
is the bulk of it.  Assembly versions of the hot functions, or a
smaller dedicated reader path, would be needed to approach 3 KiB;
recorded here as a known overrun.

### The zero-init fix (found by the replays)

The card programs' EXE v2 image has no initialized writable statics,
so the adapter's and cache's two-slot arrays zero-initialize - and
`handle == 0` read as "slot occupied".  Both slot allocators now keep
an explicit `open` flag.  The replays caught this on the first native
run (`krestest: edit-open -4`).

### The swap-name character fix (found by the replays)

Compaction's temporary suffix `~` is rejected by the card's 8.3
codec (the IOC-FAT driver follows the FatFs character set, which
excludes `~`).  The adapter spells the temporary `~` as `$` on the
card (the recovery `#` passes through).  Host files keep the core's
`~`/`#` spellings.

### The open-with-create fix (found by the replays)

`kres_open` no longer passes `KRES_OPEN_CREATE` to the adapter: an
adapter that creates on demand returns a zero-length file the header
check rejects, and the create-on-missing hook never runs.  It probes
without the flag and only a reported miss goes through the hook.

## Native replays (tests/test_kres_native.py)

All five green on the production image in the simulator:

- host-packed container read by `krestest read`, checksums matching;
- `krestest build` verified byte for byte by the host tool;
- `krestest edit` verified and extracted byte for byte by the host
  tool; the header facts (area B active, generation 1, next_record
  16, B at extent 10) pin the growth and commit;
- the two-slot rule: a container opens beside a direct file, a second
  container is refused (`-KOS_EMFILE`);
- compact shortens the file to 9 records + 1,000 bytes, B survives and
  the swap names are gone;
- an `edit2` replay stopped after the second catalog-area write still
  verifies with the previous catalog;
- the sealed container refuses writes (`-KOS_EINVAL` on the
  read-opened resource, `-KOS_EROFS` on the container) and is
  unchanged;
- kresread's map links only kres_util, kres_read, kres_adapter and
  kres_cache_xmem - pinned by `test_read_only_link_splits_the_members`.
