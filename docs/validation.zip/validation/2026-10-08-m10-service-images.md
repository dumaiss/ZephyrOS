# Work package 40 — resident service images (M10 stage 4, part 1)

Date: 2026-10-08.  Contract: `work/40-m10-service-images/WORK.md`.
Target: architecture 36.6, 36.11, 36.12 (step 4 of 36.24).

The `ipc-selftest` services are no longer blobs a test loader copies: they
are ZMOD **service images** packed on the host, listed in the flat
**boot manifest** the bootstrap ROMFS reader reads, placed in bank 6's
tiers by the **cold nucleus service loader**, boot-initialised once
through the mode-10 gate and registered against the versioned
**service bootstrap interface**.  Bank 6 left the application pool.

## 1. What the package adds

| Piece | Where |
| --- | --- |
| Service section (segments, endpoints, dependencies) | `include/zephyros/service.h`, format section 7 of `docs/module-format.md` |
| Packer `pack`/`services`/`dump` support, tier plan, reports | `tools/zmodpack.py` |
| Cold nucleus loader (manifest, allocation, relocation, bring-up, ledgers) | `kernel/service/service_loader.c` |
| Mode-10 Q = 6 boot gate and the upcall request block | `kernel/service/service_boot.asm` |
| Versioned bootstrap interface, entries justified | `include/zephyros/ipc.h`, `kernel/ipc/ipc.c` |
| Boot manifest in the recovery store | `Makefile` (`services.man` + `ipc-*.zmod`), `tests/ipc/manifest.json` |
| The six images as hot/io/boot segments | `tests/target/ipc/*.c`, `tests/target/ipc/manifests/*.json` |
| Bank 6 out of the application pool | `include/zephyros/process.h` (`PROCESS_BANK_COUNT` 7 -> 6) |

Format highlights: one segment per role (`hot` 6000h-DFFFh, `io`
8000h-BFFFh, `boot`/`bulk` 0000h-5FFFh), byte-packed segment/endpoint/
dependency tables, and the existing 4-byte ZREL_ABS16 records whose second
byte now names the **target segment**, so each segment relocates against
its own base (`word_at(own_base + patch) += target_base`).  Driver
containers keep that byte reserved.

## 2. Ledgers

Production (byte-identical except for the bank-pool change):

```text
production image: build/zephyros.bin = build/zephyr80.bin
                  sha256 71109382635566c3c77133fd1117ba9be8bd86bc4ccb3188f0d8637bbe8a5568
                  (was d017f133... in package 39: bank 6 leaves the pool)
nucleus fixed: required 3746 bytes | overflow 10935 bytes | stacks 768 | room 935 bytes
```

`ipc-selftest` image (`build-ipc-selftest`, SIO-only boot set):

```text
nucleus fixed: required 6723 bytes | overflow 1368 bytes | stacks 768 | room 7525 bytes
nucleus cold: code 30056 bytes end D568h | arena 1 granules (1 boot, 0 free) | data 1887 bytes at D800h | room 313 bytes
service hot: 4760 bytes of 32768
service boot/bulk: 96 bytes of 24576
common: used 2230 of 7424 bytes (code 1511, data 719) | ceiling 3072, m10 512, limit 2560
ipc-selftest image sha256 13254577ecd678427e4f04d0fce0d73bf968d0056df84cdb45e2cfae813a8de7
```

**The loader's cold-half cost: 6,105 bytes of cold code and 232 bytes of
cold data** (`build-ipc-selftest/service_loader.rel`: `_WINDOW` 6,105 +
`_WINDOW_DATA` 232, the loader object's own area sizes; the boot gate adds
its 55 bytes of common-resident code and 11 bytes of common data).  The cold half is the scarce half in this
image, so the two `moves` objects that no longer fit beside the loader
(`vfs_path`, `vfs_workspace` - 773 bytes of code and 513 of data) moved
into the fixed core's leftover space, which `config/residency.json`'s
`moves` tier documents as the fallback; the other five stay cold
(`IPC_COLD_EXTRA` in the Makefile).  Production is unaffected: its cold
set never included a `moves` object.

Bank-6 tier plan the loader reproduces (load order = manifest order):

```text
ipc-ioc.zmod     hot 66A8h io BDFCh boot 0000h
ipc-fat.zmod     hot 67CCh io BBF6h boot 0010h
ipc-vfs.zmod     hot 62A6h io B9ECh boot 0020h
ipc-echo.zmod    hot 68BCh io B9E8h boot 0030h
ipc-con.zmod     hot 6000h io B8E4h boot 0040h
ipc-irqx.zmod    hot 64ECh io B6DCh boot 0050h
```

## 3. Evidence

The write-boundary bootstrap image is not the acceptance image: bank 6 is
not in the recovery store's boot set, so the services are placed from the
manifest at boot and the client/probe prove the result.

* **Pack-time contract** (`tests/test_service_images.py`, 19 tests, no
  toolchain): container round-trip, one segment per role, hot required,
  boot-only entries, init inside the hot image, endpoint flags, the
  per-segment relocation arithmetic (load rule applied by hand), hot ->
  boot/bulk refusal, bulk without records, load order and manifest bytes,
  missing dependency, duplicate endpoint, **oversized hot segment**,
  io-tier exhaustion, the tier policy (io from C000h down, hot
  largest-first, boot up, bulk down) and a **descending-block overlap
  regression test** (which fails when the io/bulk base is rounded up
  instead of down).
* **Target/replay evidence** (`tests/test_ipc_selftest_sim.py`,
  `TestIpcServiceImages`): the loader's own report is pinned against the
  packer's plan (`services.plan.json`) - every image line and both
  ledgers; **each boot segment ran exactly once** (its own bank-6 BSS
  marker read back); `con`'s deliberate slow buffer is in the hot tier at
  `61A6h`, outside 8000h-BFFFh.
* **Promoted suite** (replay): `ipc: 55/55 checks`, `ipccopy: 23/23
  checks`, `ipccopy: PASS`, 365 domain intervals among 3245 mapping
  excursions all restored, 718 calls returned their caller's latch, 13
  CTC0 deliveries with the final RETI in the nucleus, 1693 window LDIRs in
  the domain incl. the 512-byte chain.  The five-address copy matrix and
  the path-B interrupt case are unchanged tests and still pass.
* **Negative case, target side**: a dependency the previous images do not
  export is refused before any bank-6 byte is touched and reported as
  `service loader: <name>: missing dependency <class>.<instance>` on the
  early console (the host test pins the refusal; the same check is the
  first thing the load pass does).

## 4. Bugs found and fixed on the way (all inside this package)

1. **Packer relocation patch offsets** ignored the chunk address
   (`patch = base + index` instead of `base + chunk.addr + index`), so a
   service image's records named the wrong words.  Found by the first
   boot; now covered by the round-trip test's word-level assertions.
2. **Segment payload offsets** were read relative to the container instead
   of the payload area, so the loader copied header bytes as code.
3. **The boot gate's state** (`kernel/service/service_boot.asm`) was in
   `_DATA` (bank 7's fixed core), which mode 10 does not map: the gate's
   own continuation read garbage.  Moved to `_COMMON_DATA` and pinned by
   `COMMON_ONLY_SYMBOLS` in `tools/mapcheck.py`, which now also enforces
   the gate state and the upcall block are common-resident.
4. **Descending tier blocks** (io, bulk) were rounded *up* to an even
   address, so a block of odd size overlapped the block above it by one
   byte; the loader's BSS zeroing then wiped the neighbour's `api`
   pointer, and the first chained VFS read jumped into page zero.  Both
   `ServiceTierPlan` and the loader now round *down*, and the overlap test
   above pins it.
5. The loader links no SDCC arithmetic runtime: the entry count is a
   subtraction loop and the manifest offset is shift/add
   (`SERVICE_MANIFEST_AT`), the discipline `kernel/romfs/romfs.c` already
   follows.

## 5. Validation

```sh
make clean && make check      # OK: 847 host tests (217 skipped), mapcheck OK, production rebuilt
make ipc-selftest             # OK: 54 tests in 13m24s; image + plan/transcript evidence
make m9-selftest              # OK: 7 tests in 3m05s
git diff --check              # clean
```

Re-run once more after the last edits (uppercase hex in the loader's plan
line, `_`-prefixed symbol names in the replay evidence): the same 847
(217 skipped), 54 and 7 tests pass, and the production hash is unchanged.

The `ipc-selftest` target's own build prints the two service ledgers and
`mapcheck: OK (20 areas, 373 symbols)`; the replay prints the plan
comparison, the boot-once markers and the tier evidence quoted above.

## 6. Acceptance

* Service images are packed on the host, loaded from the manifest into
  both bank-6 tiers, boot-initialised once and registered; the
  `ipc-selftest` suite passes on them (55/55 + 23/23).
* Bank 6 is no longer allocatable to applications (`PROCESS_BANK_COUNT`
  6, `docs/memory.md` section 1, monitor ledger `free-banks 6`, updated
  tests and transcripts).

## Supervisor review (2026-10-08)

**Accepted** on the record's evidence:
- production `71109382…` changes only because `PROCESS_BANK_COUNT` went
  from 7 to 6, which the contract allows;
- the loader report is pinned against the packer plan, each boot segment
  runs once, and the missing-dependency and oversized cases are covered;
- the promoted suite and the copy matrix are unchanged and pass;
- four real bugs were found and fixed, each pinned by a test.

Carried into package 41:
- **Loader size.** 6,105 bytes of cold code plus 232 of data is large for
  a boot-only component.
  - `service_relocate` re-implements the ZREL_ABS16 loop instead of
    sharing `kernel/module/relocate.c`. The justification (gate access to
    bank 6) covers the patch I/O, not the record validation and
    arithmetic.
  - The plan and ledger printing is test evidence.

  Package 41 shares the record logic with `relocate.c`, moves the
  evidence-only reporting behind the test hook, and reports the loader's
  production cost.
- **Production budget.** Production's cold half has 158 bytes free.
  Moving four drivers out of the arena frees about 10 KB, and the loader
  plus making room in the fixed core for the substrate costs about 8.3 KB.
  It fits, but not by much.
- **Validation time.** `ipc-selftest` alone took 13 min 24 s. Keep the
  replay focused; do not grow it in package 41.
