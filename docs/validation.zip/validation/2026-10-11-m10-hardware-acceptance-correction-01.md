# M10 hardware acceptance correction 01: running programs from `/FS`

Date: 2026-10-11.  Contract:
`work/45b-m10-hardware-acceptance/correction-01/WORK.md`.  Corrects
`docs/validation/2026-10-11-m10-hardware-acceptance.md` (work package
45b) at the two points its hardware run found: the exec path and the
card-absent answer.

## Result

`X /FS/<name>.zex` runs.  `SYS_EXEC` used to stage the caller's path in
`zos_process_path_scratch`, cold-half `_DATA` at `C0DDh` - inside the
`6000h-DFFFh` region a bank-6 provider's window replaces - so the `/FS`
driver read bank-6 bytes instead of the path and the monitor answered
`ERR: 02` (`ZOS_EINVAL`) without a single FS2 command.  The syscall now
stages the path in the VFS workspace's path view in the fixed core,
exactly as `SYS_BIND` stages its own, and the retired buffer is gone.

The card-absent run is consistent with the bench.  `/FS` with no media
answers **one documented error, `ZOS_ENODEV` (`03h`)**, for `bind`,
`stat`, `ns_enum` and `chdir` below `/FS` alike.  The driver decides the
card state from the command that *reads* the medium (the root directory
open and its first read), because the deployed firmware answers
`OPENDIR` for the root from its mount context after the card is gone;
`ZFS_OP_STAT` on the root proves it the same way before answering
"directory", so `chdir("/FS")` cannot pass on the bench while `mkdir`
below `/FS` fails.

Measured (reproducible rebuild):

- Production image `build/zephyros.bin`, 524288 bytes,
  `5a731321687636e8a7c26a1ccbadb545209621429e3577bbbafd13a647c395d2`
  (work package 45b: `874e05b8…`).
- `iocfat.zmod` 7847 bytes, `b6c1a7a4…` (45b: 7812 bytes) - the media
  probe and the root `STAT` shared one helper.
- `hwtest.zex` 12461 bytes,
  `8f45ab3b899b56f22c44180fe9f5a5dc53faa16988dfa82dd550b5f0eb920b56`
  (45b: 12175 bytes `0479b977…`) - the failure-detail reporting.
- `monitor.zex` 6053 bytes, `5f6a0d35…` (unchanged: comment only).
- Recovery store **88 687 of 294 912 bytes** (45b: 87 840).
- Nucleus ledgers unchanged from 45b: `fixed: required 8335 | overflow 2
  | stacks 768 | room 7279`, `common: used 2358 of 7424 (code 1511, data
  847) | ceiling 3072`, `driver hot 21910 of 32768 | boot/bulk 2170 of
  24576`.  The cold half is `+128` bytes lighter than the 45b plan
  expected (it held the scratch): `code 23352 end BB38h | data 1527 at
  BC00h | room 7689`.

## 1. The fix

`kernel/syscall.c`, `kernel/process/exec.c`, `kernel/process/process.c`,
`include/zephyros/process.h`, `kernel/process/launch.asm`:

- `syscall_exec()` copies the caller's path into `VFS_WS_IN_A` inside
  `vfs_ws_enter(VFS_WS_VIEW_PATH)` / `vfs_ws_leave()` and calls
  `process_prepare()` there.  No new buffer is introduced.
- `process_prepare()` holds the path view around the one call that hands
  the address to a provider (the `vfs_ns_bind()` of the executable).
  Nothing after the bind reads the path: the loader streams the bound
  FILE through descriptors and the common staging block, and the startup
  tail copy happens later, when the workspace is free again.
- `zos_process_path_scratch` is retired from `kernel/process/process.c`,
  `include/zephyros/process.h` and the `launch.asm` comment that named
  it, i.e. the cold-half `_DATA` block (128 bytes) is gone rather than
  left unused.

Behavioural evidence (simulator, production image): the monitor's
`X /FS/FS_CHILD.ZEX tail-42` produces two `fs-child:` lines,
`fs-child: PASS` and `exec: exit status 0x002A`, with FS2 traffic
`ROOT`, `OPEN_RO`, `READ` x16, `CLOSE` for the load and the child's own
`OPEN_RW`/`SYNC`/`CLOSE`.  Before the fix the same line answered
`ERR: 02` with an empty request log.  `tests/test_hwtest_sim.py` pins
both the transcript and the traffic.

## 2. The guard (requirement 3)

- `config/residency.json` already classifies `vfs_workspace` as
  `fixed-required` with the reason the contract asks for ("the path view
  a resident service reads: the frame handed to a bank-6 dispatch names
  the path by address"), so no classification changed.
- `tools/mapcheck.py`: the obsolete M9 requirement that reserved a
  bank-7 window block for the `SYS_EXEC` path buffer is deleted (it
  failed the build) and `_vfs_workspace` joins `REV13_FIXED_SYMBOLS`, so
  `check_rev13_window()` fails the build if the workspace ever links in
  the cold half.  Both the residency tier and the symbol check are
  pinned by `tests/test_ns_selftest.py`.

## 3. The audit (requirement 2)

Every nucleus path that hands a buffer, a path or a descriptor to a
provider or driver, and where that memory lives:

| Path | Provider-facing memory | Placement |
| --- | --- | --- |
| `SYS_BIND` (`bind` on any root) | `VFS_WS_IN_A` copy-in | fixed core `5848h` |
| `SYS_EXEC` (this correction) | was `zos_process_path_scratch` | **was cold `C0DDh` - the defect**; now `VFS_WS_IN_A` |
| `stat`, `mkdir`, `rmdir`, `unlink`, `rename` (`/FS` via the router) | path copied into the call frame's payload | nucleus stack `5D00h-5F00h`, fixed core |
| `ns_enum` on `/FS` (in: path, out: entries) | path as above; entries through the call descriptor | fixed core + the caller's array |
| `chdir` / `vfs_ns_dir_check` | path as above (`ZFS_OP_STAT` on the root) | fixed core |
| loader FILE reads during `exec` | `_zos_user_copy_staging` through `ipc_nucleus_call_common` | common (always mapped) |
| monitor `X` | `SYS_EXEC` only (no buffer of its own) | fixed core after this fix |
| nucleus console writes (boot diagnostics, kernel console, lane) | frame payload on the nucleus stack | fixed core |
| service loader (boot/hot segments, dependency and publication records) | `_zos_user_copy_staging` through the common call | common |
| `/SYSTEM` ROMFS reader | in-process, no bank-6 window at all | bank 7, cold half, no window involved |

The retired scratch was the only violation; every other site was already
either fixed core, an always-mapped common buffer, or a descriptor into
the caller's own window.

## 4. Card-absent consistency (requirement 5)

- **One documented error:** `/FS` with no media answers `ZOS_ENODEV`
  (`03h`) to `bind`, `stat`, `ns_enum`, `chdir` below `/FS` and the FILE
  protocol.  Stated in `fs/iocfat/iocfat.c`'s header, in
  `docs/devices.md` section 1 and pinned by
  `tests/test_iocfat.py::TestNoMediaContract`.
- **The probe reads the medium:** `iocfat_init()`'s probe now opens the
  root *and* reads one entry (`iocfat_media_readable()`).  The deployed
  firmware's `handler_fs2_opendir` answers `OPENDIR` for the root from a
  cached mount context (`MCU` `fs2.c` -> `need_fs()` -> FatFs
  `f_opendir("/")`, which reads no directory data), so a card that was
  pulled still opened a root: on the bench the old probe passed, the
  driver became ready and `chdir("/FS")` - answered by the driver from
  its own knowledge - returned 0 while `mkdir` below `/FS` correctly
  failed.  The first `READDIR` is what fails there
  (`FR_NOT_READY` -> `FS2` `NO_MEDIA` -> `ENODEV`, `sdfs_invalidate()`).
- **The root `STAT` proves it too:** `iocfat_stat_path()` runs the same
  probe for the filesystem root before answering `ZFS_TYPE_DIR`, so a
  card removed *after* boot still turns `chdir("/FS")`/`stat("/FS")`
  into `ZOS_ENODEV` instead of 0.  A directory slot that is already open
  means an enumeration is reading the medium - that escapes the probe
  and answers the root normally.
- **The simulator's IOC model now answers like the hardware:**
  `tests/z80sim.py`'s FS2 dispatch answers `CAPS`/`GENERATION`/`ROOT`
  and `OPENDIR` (root open) with no card, and `NO_MEDIA` to `READDIR`
  and every other command, so the replay proves the strengthened probe
  instead of hiding it.
- **`hwtest` reports the code it saw:** the exerciser's namespace rows
  compare codes through `hw_check_status()` (`FAIL <row> got 02 want
  03`), the accepted-call rows through `hw_check_accepted()` (`FAIL
  <row> got 03`) and the enumeration rows through `hw_check_enum()`
  (`FAIL <row> got 03` or `not listed`); a wrong object type reports
  `type 02 want 04`.  `tests/test_hwtest.py` pins the contract.
  Measured with an injected fault (the emulated card refuses every
  `MKDIR` while its files still work, so the runner classifies the run
  "card not writable" and then takes the absent-style row against a card
  that answers): `hwtest: namespace+handles FAIL bind-card-enodev got 05
  want 03`, `hwtest: files FAIL status 0x0001`, `hwtest: 1/3 FAIL (card
  not writable)` - the row, the observed code and the expected one on the
  lane, where 45b printed only the row's name.

## 5. Console glitch (requirement 6): explained, not changed

The stray `=` before `fs-selftest: console-write OK` on the V9958 is the
check's own byte: `tests/fs/fs_selftest.c` runs
`check("console-write", zos_console_write("=", 1u) == 1)`, so the row
deliberately writes one `=` through the console handle and the display
shows it before the row line.  Nothing in the console driver, the
terminal parser or the store is involved; the row's comment now says so.

## 6. Regression coverage (requirement 4)

| Where | What it holds |
| --- | --- |
| `tests/test_hwtest_sim.py` (new `TestMonitorRunsAProgramFromTheCard`) | the store's `fs_child.zex` payload placed on the emulated card, `X /FS/FS_CHILD.ZEX tail-42` -> `fs-child: PASS`, `exec: exit status 0x002A`, FS2 `OPEN_RO`/`READ`/`CLOSE` in the request log, no `ERR: 02`, and the card left as found |
| `tests/fs/fs_selftest.c` (`exec-card-copy`, `exec-card-status`) | the acceptance image copies the child onto the card (`/FS/CHILD.ZEX`, or `/FS/HWTEST/CHILD.ZEX` under the exerciser's `stage` tail) and execs it; 35 -> 37 checks with a card (the absent branch stays 8) |
| `tests/hwtest/hwtest.c` (files stage) | the same rows through the production exerciser, with `HW_PROGRAM` removed by `hw_scratch_remove()` so the card keeps no trace |
| `tests/test_fs_selftest_sim.py` | the two new outcomes and the new count, with and without a card |
| `tests/test_ns_selftest.py` | `SYS_EXEC` stages in the workspace path view, `process_prepare` holds it around the bind only, the scratch is gone from source and header, and `mapcheck` names `_vfs_workspace` |
| `tests/test_iocfat.py` | the media probe reads the directory, the root `STAT` proves the media, `ENODEV` is the one no-media answer |

## 7. Validation

```sh
make clean && make check
make fs-selftest xmem-selftest ns-selftest console-integration-selftest
git diff --check
```

- `make clean && make check`: green - the rebuild is byte-identical
  (`5a731321…`), and the suite reports `606 tests, OK (104 skipped)` in
  136.1 s; the skips are the acceptance images a plain `make check` does
  not build.
- The four acceptance targets: green (6m36.7s: namespace 24 tests, the
  filesystem image 3 tests with and without a card, console-integration
  with its video/console replays, and the xmem image's own 8-test replay
  with its 63-check row).
- `tests/test_hwtest_sim.py` (the three production replays plus the
  monitor's store-program row): green, 114.7 s - the card replay is the
  one that would have caught this defect.
- Focused during the work: `tests/test_fs_selftest_sim.py` (3 tests),
  `tests/test_iocfat.py` (21), `tests/test_hwtest.py` (19),
  `tests/test_ns_selftest.py` (24), `tests/test_docs_evidence.py` (5).
- `git diff --check`: no whitespace errors.
- No commit was made by this correction (owner instruction); the working
  tree also carries packages 45/45b's uncommitted changes.

## 8. Files

- Kernel: `kernel/syscall.c`, `kernel/process/exec.c`,
  `kernel/process/process.c`, `include/zephyros/process.h`,
  `kernel/process/launch.asm`.
- Guard: `tools/mapcheck.py` (retired requirement, `_vfs_workspace`).
- Driver: `fs/iocfat/iocfat.c` (probe, root `STAT`, header contract).
- Simulator model: `tests/z80sim.py` (FS2 no-media answers).
- Programs: `tests/fs/fs_selftest.c`, `tests/hwtest/hwtest.c`,
  `user/monitor/monitor_exec.c` (comment).
- Tests: `tests/test_hwtest_sim.py`, `tests/test_hwtest.py`,
  `tests/test_fs_selftest_sim.py`, `tests/test_ns_selftest.py`,
  `tests/test_iocfat.py`, `tests/maptools.py` (retired symbol).
- Documentation: `docs/devices.md`, `docs/monitor.md`,
  `docs/architecture.md` (36.5 buffer rule, 26.2/29),
  `docs/abi.md` (section 11), `docs/memory.md` (2.2.1, 2.3),
  `docs/vfs.md` (workspace),
  `docs/validation/2026-10-11-m10-hardware-acceptance.md` (owner
  checklist: image hash, the two file counts and the card step).

## 9. Owner checklist (what the bench should do now)

`docs/validation/2026-10-11-m10-hardware-acceptance.md` section 7 was
updated: flash the image above, then

1. `X /SYSTEM/hwtest.zex` with a card -> `fs-selftest: 37 checks, 0
   failures`, `hwtest: 3/3 PASS`;
2. the same with no card -> `hwtest: 3/3 PASS (card absent)`, which now
   includes the `chdir-card-enodev` row that failed on 2026-10-11;
3. the card program itself: copy the store's `fs_child.zex` (the build
   tree's `build/modules/fs_child.zex` is byte-identical to the store
   payload) to the FAT card as `FS_CHILD.ZEX` and run
   `X /FS/FS_CHILD.ZEX tail-42` -> `fs-child: PASS`, `exec: exit status
   0x002A`.  Before this correction that line answered `ERR: 02`.

## Hardware and supervisor review (2026-10-12)

**Owner, production `5a731321…`:** `X /SYSTEM/hwtest.zex` gives
**`3/3 PASS`** with a card and **`3/3 PASS (card absent)`** without. With
a card, the files stage includes the new run of a child from the card,
so running from `/FS` is proven on hardware. The `=` on the V9958 is the
`console-write` check's own byte.

**Accepted:** package 45b and correction 01.
- The exec path now uses the fixed-core VFS workspace; the audit found
  no other cold-half buffer handed to a driver.
- One `ENODEV` answer for `/FS` with no media.
- The monitor's `X` runs programs from `/SYSTEM` and `/FS`.

Hardware items still open for the M10 sign-off: `ipc-selftest` (real
interrupts into driver calls) and `subsystem-selftest` (nucleus probes).
