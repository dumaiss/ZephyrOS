# Validation - snd-ztr-crc (package 105)

Date: 2026-10-29

## Scope

Package 105: `snd_ztr_open` stops walking every pattern stream. The
header's reserved u16 at `16h` becomes a content CRC-16 (CCITT-FALSE,
poly `1021h`, init `FFFFh`) over `[0,16h)` + `[18h, pattern-data
offset)` + `[note-table offset, +192)`, stamped by the producers.
Open checks magic, fixed layout and capacities, feeds the CRC from the
reads it already performs, and verifies it (nonzero stamp only) before
any remap. The deleted structural validation lives on, with
diagnostics, in a new `UserSoftware/ZTRCheck/` program (Z80 + host
twin). No engine (`snd_ztr_dec.asm`), ABI, `kos/snd.h` signature or
`kos_reader_t` contract change.

## Files

Added:

- UserSoftware/ZTRCheck/ztrcheck_core.c, ztrcheck_core.h - the
  structural checks (header fields, layout, CP/M padding, CRC first
  when stamped, strings, instruments, macro area, pattern placement,
  pattern streams, note divisors), reader-based, each reporting a
  diagnostic enum + file offset
- UserSoftware/ZTRCheck/ztrcheck.c - the Z80 program (`ztrcheck
  FILE.ZTR`: OK summary or `FAIL <check> at <offset>: <detail>`)
- UserSoftware/ZTRCheck/ztrcheck_host.c, host/include/kos/types.h - the
  host twin and its fixed-width type shim
- UserSoftware/ZTRCheck/Makefile, README.md - shaped like SNTracker's
- UserSoftware/ZTRCheck/tests/test_ztrcheck.py - both stamped songs
  OK + `crc=ok`, covered-byte flip -> MISMATCH, unstamped -> `crc=none`
  OK, truncated -> FAIL with its offset
- tests/snd/oracle/make_ztrcheck.py, tests/snd/golden/ztrcheck.md - the
  host ztrcheck verdict per malformed fixture, pinned
- docs/validation/2026-10-29-snd-ztr-crc.md

Changed:

- user/sdk/snd/src/snd_ztr.c - validation removed (`validate`,
  `pattern_streams_ok`, `resident_macro_ok`, the `zs_*` walkers, the
  `1Ah` padding content check); table-driven CRC (split hi/lo byte
  tables); open order header -> magic/capacity -> resident reads
  feeding the CRC -> verify -> remap/compact/split ->
  mask/loudness/largest-order; the largest-order scan bucketed by
  channel. 1171 -> 1009 lines.
- user/sdk/include/kos/snd.h - `snd_ztr_open` comment only
- docs/ZTR-Format.md - `16h` content CRC row, "Content CRC" section,
  reader contract
- docs/snd-sdk.md - open contract (sections 4.2, 6.1, 6.2, file list)
- UserSoftware/SNTracker/tools/fur2ztr.py - `encode_ztr` stamps `16h`
  after assembly (zero, `crc_hqx`, store); `decode_ztr` verifies a
  nonzero stamp. csmc.py inherits the stamp through `encode_ztr`.
- UserSoftware/SNTracker/tools/test_fur2ztr.py - the stamp asserted
- UserSoftware/SNTracker/songs/*.ztr - rebuilt stamped from their
  `.csm` with csmc.py (same sizes)
- tests/snd/fixtures/gen_fixtures.py - stamps the good fixtures;
  malformed fixtures keep `16h = 0000h`; `values-reserved` targets
  byte 55 (`16h` is the CRC field)
- tests/snd/fixtures/{night-market,RunawayCircuit}.ztr - stamped (0C3Ah,
  734Fh); tests/snd/fixtures/malformed/values-reserved.ztr regenerated
- tests/snd/oracle/ztr.c - accepts a nonzero `16h` (no verification)
- tests/snd/golden/malformed.md - one row (`values-reserved`)
- tests/test_snd.py, tests/test_snd_oracle.py - see Pins
- UserSoftware/SNTracker/ztrdoc.c (104 tree, user-authorized) - drops
  the `16h/17h` reserved-zero rejection and verifies a stamped CRC
- UserSoftware/SNTracker/tests/test_sound_api.py - one-line repair of a
  failure present at HEAD (see Found outside scope)
- work/105-snd-ztr-crc/progress.md, openprof.py (scratch)

## Results

Final commands, one batch on the final sources:

| command | result |
|---|---|
| `make && make sdk` | green |
| `make -C UserSoftware/SNTracker test` | 4/4 OK; sntrack.exe, sntview.exe pack |
| `make -C UserSoftware/ZTRCheck test` | 4/4 OK; ztrcheck.exe packs (22,970 B) |
| `python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_sntrack_view` | 51/51 OK (204 s) |
| `git diff --check` | clean |
| WORKER history-words grep (tracked diff + untracked files) | nothing printed |
| `make clean && make check` | 1010 tests, 4 failures, 119 skipped (761 s wall); the 4 fail identically on a clean build of untouched HEAD (see Found outside scope) |
| `make check` after adapting those 4 pins | 1010 tests OK, 119 skipped (681 s wall); `make check: OK` |

- Production image byte-identical to HEAD: after `make clean`,
  `build/konaos.bin` == `build/zephyr80.bin` sha256
  `5881b667192a97128e84cd84db2ca1b50f3d106c36f5a8869ae58492714293bc`,
  equal to a clean build of untouched HEAD (8dc1af2) in a separate
  worktree. The pre-change hash recorded at the start
  (work/105-snd-ztr-crc/image-before.sha256, `8243d62a...`) came from an
  incremental build that predated 8dc1af2's driver change; every
  incremental build during the work reproduced that stale value, so it
  confirmed only that libsnd edits never reached the image. The clean
  comparison above is the authoritative check.
- Golden playback traces unchanged: `TestSndZtr.test_both_songs_match_
  state_and_writes_for_3000_ticks` and `TestSndZtrClient.test_sntrack_
  plays_both_songs_clean_and_on_tempo` green on the stamped songs.

## Budgets (CPU T-states, production image)

| figure | before | after | target |
|---|---|---|---|
| `snd_ztr_open`, RunawayCircuit | 36,735,928 (10.3 s) | 7,122,458 (1.99 s), 5.16x | >= 5x: met |
| `snd_ztr_open`, night-market | 13,963,420 (3.9 s) | 6,098,990 (1.70 s) | informational |
| `snd_ztr_open`, RunawayCircuit unstamped | - | 4,933,173 (1.38 s) | resident loads only: met |
| production image | HEAD | byte-identical | met |
| ztrcheck on target, RunawayCircuit | - | 129,817,939 (36.3 s), command to report | informational |

Method: `work/105-snd-ztr-crc/openprof.py` drives `sndtest ztrbudget`,
which brackets `snd_ztr_open` / `snd_ztr_prepare` / one `snd_service`
with marker-port writes; each figure is the elapsed T-states between
markers (includes ~100 T of marker overhead and the background timer
events). The baseline was taken with an address breakpoint on
`_snd_ztr_open`; that method stopped working once the function moved
to an address the shell also executes in the same app mapping (false
entry hits during command handling), so all "after" figures use the
markers. The two methods agree within the marker overhead.

Final open profile, RunawayCircuit (module-local PC attribution from
`build/user/sdk/snd/snd_ztr.lst`; static functions are absent from the
linked map): largest-order scan ~2.34M, CRC feed ~2.08M, section loads
~0.36M, remap/split ~0.10M, mask/loudness ~0.04M; the rest is the
kernel's FS2 reads (~1.57M, 512 B-block granular, near floor) and
timer events.

Measurement history, RunawayCircuit open: 36.74M (HEAD) -> 30.39M
(validation removed) -> 11.46M (largest-order scan channel-major) ->
10.34M (CRC byte tables, 1 KiB read windows) -> 9.69M -> 8.73M
(directory bucketed by channel) -> 7.12M (channel-outer mask scan,
remainder-walk loudness page, inline directory copy, unused channels
skipped).

## Pins changed, with sources

- tests/snd/golden/malformed.md: `values-reserved` row (byte 55, the
  `16h` field is the CRC) - WORK.md requirement 6.
- tests/snd/golden/ztrcheck.md (added): host ztrcheck verdict per
  malformed fixture - WORK.md requirement 7.
- `test_sdk_loader_refuses_every_malformed_ztr` ->
  `test_sdk_loader_open_partition_of_the_malformed_ztr`: open refuses
  only the magic/layout/capacity fixtures (the `OPEN_REFUSED` set) and
  opens the rest; the structural verdicts pin through
  `test_host_ztrcheck_verdicts_match_the_golden` - requirement 7.
- Added to tests/test_snd.py: `test_a_covered_byte_flip_fails_open_
  with_einval`, `test_a_pattern_data_byte_flip_passes_open`,
  `test_a_computed_zero_crc_opens_unprotected`, `test_ztrcheck_exe_
  reports_a_defect_on_target`, `test_ztrcheck_exe_summarizes_a_stamped_
  song_on_target` - requirement 7.
- tests/test_snd_oracle.py: `test_the_ztr_songs_are_the_zephyr80_sources`
  -> `test_the_ztr_songs_are_the_stamped_zephyr80_sources` (fixture ==
  the Zephyr-80 source stamped, stamp nonzero) - requirement 4.

## Deviations

- WORK.md requirement 7 names `test_malformed_streams_refused_or_
  stopped` for "drop the content-refusal arm". That test is ZVG-only
  (`TestSndZvg`): the ZVG loader is outside this package and keeps its
  checks, so there is no ZTR arm to drop. The test is unchanged; the
  required ztrcheck.exe simulator check is added.
- ztrcheck on target takes 36.3 s on RunawayCircuit, longer than the
  10.3 s the in-open validator took: it does more (diagnostic per
  check, string and note-divisor checks, offsets), all in C. It is an
  offline tool and has no budget; noted for the owner.

## Found outside scope

- `make check` fails 4 tests at HEAD (8dc1af2 "fixes to keyboard
  polling"), reproduced on a clean build of untouched HEAD:
  - `test_hid.TestHidSourceDiscipline.test_stuck_penalty_applied_and_cleared`:
    the source pin expects `state->backoff = KHID_STUCK_PENALTY;`;
    drivers/hid/hid.c now doubles the backoff up to
    `KHID_STUCK_PENALTY_MAX`.
  - `test_iocfat.TestIocFatManifest.test_packed_driver_keeps_the_hot_tier_room`,
    `test_pack_image.TestNucleusLedgers.test_ledger_lines_match_the_built_image`,
    `test_sound.TestSoundContract.test_the_driver_tier_keeps_its_reserve`:
    the driver hot tier has 1,500 bytes free against the 1,536-byte
    reserve (the HID change spent 36 bytes of it).
  The owner flashed the current ROM and programs on the board and
  confirmed everything works, and asked for the tests to follow the
  code. Adapted (driver code untouched):
  - tests/test_hid.py: the pin asserts the one-expression backoff
    `(uint8_t)((state->backoff << 1) | KHID_STUCK_PENALTY)` (same
    behaviour: first failure KHID_STUCK_PENALTY, doubling to the max);
    the stale `(uint8_t)(state->backoff << 1)` literal dropped.
  - Driver hot-tier reserve 1,536 -> 1,472 bytes (the reserve is
    headroom for planned drivers and the HID change used 36 bytes of
    it; 1,500 free leaves 28 bytes over the pin): tests/test_iocfat.py,
    tests/test_pack_image.py, tests/test_sound.py, docs/architecture.md
    (production image ledger table).
- `make -C UserSoftware/SNTracker test` failed at HEAD: commit 04a65b6
  changed sntracker.c to `if (!(pollnow++) && console_poll() > 0)` and
  the source-grep test in test_sound_api.py still asserted the literal
  `if (console_poll() > 0)`. The owner confirmed the pacing change is
  intentional; the assertion now matches `console_poll() > 0`.

## Preserved

- 104 tree (`sntview.c`, `view.c/h`, `ztrdoc.h`, `docs/sntrack-ui.md`,
  `tests/test_sntrack_view.py`, the SNTracker Makefile/README sntview
  hunks): untouched; `tests.test_sntrack_view` 4/4 green. `ztrdoc.c` is
  the only 104 file changed, on the owner's instruction.
- The Zephyr-80 tree: read only (gen_fixtures.py copies its songs and
  stamps the copies).
- `snd_ztr_dec.asm`, `kos/snd.h` signatures, `kos_reader_t` contract:
  `git diff` shows no change to the asm or any prototype.
- Unrelated changes were preserved.

## Owner checklist (hardware)

- `sntrack` plays both stamped songs; `ztrcheck /fs/night-market.ztr`
  prints the OK summary; a host-corrupted copy prints MISMATCH; an
  unstamped copy prints `crc=none` and validates. Simulator equivalents
  are green; the owner ran the current ROM and programs on the board:
  all works.

## Notes

- The CRC tables are two `uint8_t[256]` pages: the ABI's `uint16_t` is
  32 bits on the host build, `uint8_t` is a byte on both, so the host
  twin and the card agree with no masking.
- The host producer shim is rebuilt after `make` with
  `cc -O2 -DHOST_ZTR -D_BITS_STDINT_INTN_H -include build/kos-sdk-0.2.0/include/abi/kos/types.h -I tests/snd/host/include -I build/kos-sdk-0.2.0/include -I build/kos-sdk-0.2.0/include/abi -I user/sdk/snd/src -o tests/snd/host/host_ztr tests/snd/host/host_ztr.c`.
- SNTracker and ZTRCheck build against their own unpacked SDK copy:
  after a libsnd change, rerun `make -C UserSoftware/SNTracker` before
  the sntrack trace test, or it runs a stale binary.
