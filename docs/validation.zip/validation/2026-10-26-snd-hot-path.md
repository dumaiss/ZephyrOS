# libsnd hot path (100c04) — validation record

Date: 2026-10-26. Implementer: supervisor (direct).

## Result

All functional tests pass, unchanged in meaning: voice order, staggered
voices, catch-up, the primitives, the ZVG goldens and the timed NIGHT.ZVG
replays. The ZVG budgets are met. The manual-engine figures improved by 2.4x to
3.4x, but four of them are still above their targets (reported with a
profile, as the package allows). OS bytes are unchanged:
`build/konaos.bin` sha256 `48275a3a…e828` is the same as in 100c03's
record.

## Changes

**`snd_voice.asm`**
- Descriptors and a copy of the level table sit on two aligned pages (a
  768-byte area). The ATTEN op is `ld c,level / ld b,h / inc b / ld a,(bc)`.
- Flags are zero for a voice with nothing to do, so the walk skips idle
  voices on a single test. The chip bits are gone; the forced noise write
  is flag bit 2 on the chip's noise descriptor, which replaces the
  `snd_noise_force` arrays.
- The current level lives in descriptor +5. C reads it through
  `snd_voice_level()`, which replaces the `snd_voice_level[]` array.
- Touched bits are kept only for the period and the noise, in one global
  byte. The attenuation always compares desired against shadow at commit,
  inline when the output is DIRECT and the shadow valid (`_snd_fast` is
  computed once per walk).
- The countdown update is inlined. A program installed since the last walk
  runs with this call's tick count only: before this fix, ticks accumulated
  while waiting leaked into a fresh program and broke ADSR tick 10.

**`snd_out.asm`**
- `_flush_all` has a DIRECT path: one `ldir` copies desired to shadow (the
  arrays are contiguous), then each chip's 11 bytes go out with the port
  held in C.
- `snd_put_period` DIRECT holds the port across its two bytes.
- `snd_noise_apply` and `snd_shadow_invalidate` use the flag bit.

**`snd_zvg_dec.asm`**
- The port is loaded once per command tick. The run loop is
  `ld a,(hl) / inc l / out (c),a / djnz`, with a separate BATCH loop.
- The head, `consumed` and `writes` move once per command.
- Fixed: `ticks`, `consumed`, `writes` and `error_offset` are `uint32_t`
  but were only updated in their low 16 bits. They are now 32-bit.

**`tests/test_snd.py`**
- The budget loops attribute time only while the application mapping is in
  (`app_mapped`: latch mode 10). An interrupt runs OS code at the same
  addresses; that was the 709 T-state "ZVG wait tick" outlier at tick 24.
  The dispatch-count test still watches the OS PC.
- Ceilings were re-pinned at the new figures +10%, with the targets in the
  messages. The twelve-voice phase is split into "starting" (the first pair,
  which carries 12 period writes) and steady state.

**Other files**
- `docs/sdk.md`: the costs.
- `docs/snd-sdk.md` §4.3, §4.5 and §7.1: the layout and the paths.
- `snd_private.h`: the layout, the ABI and `SND_BATCH_MAX` set to 60 to
  match the assembly.

## Budgets (sim T-states, interrupts out)

The simulator charges every conditional branch its taken cost (JR cc 12,
CALL cc 17), so these figures run slightly high against hardware.

| figure | 100c03 | now | target | status |
|---|---|---|---|---|
| idle tick (12 waiting) | 546 | 207 | <= 600 | met |
| 12 voices changing attenuation, steady | - | 9,987 | <= 4,000 | over |
| 12 voices, first tick (+12 periods) | 27,245 | 18,594 | - | pinned 20,500 |
| one voice step + one changed byte, over idle | 6,090 | 1,772 | <= 400 | over |
| full-refresh pair (rewrite + 4 fresh voices) | 23,096 | 12,351 | - | pinned 13,600 |
| of which the 4-chip rewrite (`snd_output_flush`) | - | ~4,550 | <= 3,500 | over |
| ATTEN+WAIT voice step, all in | - | ~830 | <= 250 | over |
| ZVG per written byte in a run (DIRECT) | 224 | 27 | <= 50 | met |
| ZVG wait-only tick (over the idle baseline) | 416 | 231 | <= 300 | met |
| OS bytes | - | unchanged | 0 | met |

## Profile (12 voices, steady pair, `_snd_engine` per instruction)

The total is 9,938 T-states in the engine, with a flat profile: no single
instruction exceeds 3% of the total. For one ATTEN+WAIT voice, the costs are
about:

| part | T-states |
|---|---|
| head and flags | 45 |
| wait check against elapsed (16-bit, through memory) | 140 |
| cursor load | 43 |
| two dispatches | 50 |
| ATTEN | 85 |
| WAIT8 with the wait/cursor store | 150 |
| countdown | 85 |
| inline commit | 110 |
| next | 32 |

The remaining cost is the relative-wait model itself: every walk reads and
writes each due voice's 16-bit wait, plus the `remaining` and `countdown`
words, through memory. Reaching about 250 per voice needs a different
model, such as absolute due ticks with the walk's clock held in a register
pair, or a due list instead of a full walk. That is a structural change and
is not done here.

## Validation

- `make && make sdk && make -C UserSoftware/VGMPlayer test`: OK.
- `python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_reader
  tests.test_sdk_package`: Ran 54, OK.
- `make clean && make check`: OK (Ran 989, skipped 119).
- `git diff --check`: clean.

## Owner checklist (board)

- `sndtest tones`, `adsr`, `noise`.
- `sndtest zvg /fs/night.zvg 2` and `vgmplay /fs/night.zvg` play as before.
