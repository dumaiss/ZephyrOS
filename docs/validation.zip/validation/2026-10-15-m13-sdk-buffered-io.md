# Package 56 — m13 SDK buffered I/O

The SDK's I/O becomes buffered wherever calling costs more than the bytes:
console output collects a line at a time in libkos, file I/O gets the ISO
C stream calls over the SDK's own `open`/`read`/`write`/`seek`, and
`kos/stream.h` adds the measurement and planning arithmetic a consumer
uses to pick a refill size.  The bench
(`tests/bench/iobench.c`) measures what a program's ordinary I/O costs
before and after, and the figures are in section 5.

The contract implemented here is `work/56-m13-sdk-buffered-io/WORK.md`:
six requirements, plus its tests and validation list.  Requirement 0 (the
console-integration image retires) and requirement 1 (the 49d
correction-01) touch the tree outside the SDK; section 6 records what
covers them.

## 1. Files

Added:

| file | part |
|---|---|
| `user/sdk/src/console_proto.c` (rewritten) | the 128-byte output buffer, `console_flush`, the buffered `console_write`/`putchar`, the exit flush, the stream-flush hook |
| `user/sdk/include/klibc/stdio.h` | the stream calls, the pool size, `SEEK_*`, `EOF` |
| `user/sdk/src/stdio.c` | the pool, `fopen`/`fclose`, `kos_stream_refill`/`kos_stream_push`, `kos_stdio_flush_all` |
| `user/sdk/src/fread.c`, `fwrite.c`, `fseek.c`, `feof.c` | `fread`/`fgetc`/`getc`/`fgets`, `fwrite`/`fputc`/`putc`/`fputs`, `fseek`/`ftell`/`rewind`/`fflush`, `feof`/`ferror` |
| `user/sdk/src/stdio_internal.h` | the stream type, the slot check, the two buffer primitives |
| `user/sdk/include/kos/stream.h`, `user/sdk/src/stream.c` | `fmeasure`, `fstats`, `stream_plan` |
| `tests/bench/iobench.c` | the bench (`/system/iobench.exe`, card copy) |
| `tests/io/iomix.c`, `tests/io/iomix_child.c` | the console-order program and its nested-exec child |
| `tests/io/iostream.c` | the stream session program |
| `tests/test_stdio.py` | the host-Z80 probes: the console flush rules, the streams, the plan |
| `tests/test_io_sim.py` | the replays: `iomix`, `iostream`, the bench rows |
| `docs/validation/2026-10-15-m13-sdk-buffered-io-sim-{before,after}.txt` | the two bench transcripts |

Changed:

| file | change |
|---|---|
| `user/sdk/src/console_io.c` | `getchar`/`console_readline` flush before they read |
| `user/sdk/src/klibc/printf.c` | one `putchar` per byte (the 32-byte sink is gone) |
| `user/sdk/src/exec.c` | `run` flushes before the child starts |
| `user/sdk/src/gate.asm` | `_exit` calls `kos_exit_flush` |
| `user/sdk/include/kos/console.h` | `console_flush`, the flush points, `putchar`'s rule |
| `user/sdk/exe.mk`, `user/sdk/include/kos.h` | the five new members, the two new headers |
| `Makefile`, `systems/fs.json` | the four programs, the store rows |
| `user/sdk/src/kos_internal.h` | the stream layer's exit hook |
| `systems/production.json`, `tests/test_far_data.py`, `tests/test_romfs_sim.py` | the 49d correction: the far-data files in the `fs` store, the scratch rule |
| `tests/test_sdk.py`, `tests/test_source_layout.py`, `tests/test_iocfat.py` | the program, store and directory pins |
| `tests/test_systemgen.py` | the store rows the generator makes |
| `tests/replay.py`, `tests/target/support/target_test.c`, `tools/serial_smoke.py` | requirement 0: the integration input driver, the `KOS_*_SELFTEST` groups it carried, the smoke mode |
| `tests/test_console_acceptance.py` | the monitor image's size and hash pin (every program relinked) |
| `tests/test_shell.py`, `tests/test_shell_sim.py` | the buffered console stubs, the store names 49d moved |
| `tests/test_events.py` | the delivery measurement's handler entry/return stamps (section 6) |
| `tests/test_ioc.py`, `tests/test_hid.py`, `tests/test_v9958.py` | the driver artifacts the integration image ran, now covered by the acceptance replay |
| `docs/sdk.md` 2, 5, 6.1, 6.10, 7, 8, 9 | the include rules, `klibc/stdio.h`, the console rules, the stream model and the batching paragraph, the memory notes, the link table, the tests |
| `docs/architecture.md` 7.5 | the 512-byte read row and the amortisation paragraph |
| `docs/boot.md`, `docs/devices.md`, `README.md` | the acceptance images, the removed image's targets, the command list |

Removed (requirement 0):

| file | covered by |
|---|---|
| `systems/console-integration.json`, the Makefile target and its `hardware-images` row | the acceptance images that remain (`subsystem`, `fs`, `ipc`, `nucleus`) |
| `tests/target/console/integration_test.c`, `tests/target/include/console_integration_selftest.h` | the production image's console acceptance replay |
| `tests/target/ioc/`, `tests/target/hid/`, `tests/target/video/`, their `*_selftest.h` | `tests/test_console_acceptance.py` (the card, the HID engine) and the hardware exerciser's replay |
| `tests/console/escc.c` (`escc.exe`) | nothing else used it |
| `tests/test_ioc_sim.py`, `tests/test_hid_sim.py`, `tests/test_v9958_sim.py` | `tests/test_ioc.py`, `tests/test_hid.py`, `tests/test_v9958.py` keep the artifact checks; the behavior replays are the acceptance and `hwtest` ones |
| `tools/serial_smoke.py`'s console-integration mode, every `KOS_*_SELFTEST` flag only it set | the mode's own refusal is now "no such image" |

## 2. The console buffer

One 128-byte buffer per program lives in `console_proto.c`, the console
client every program that writes links anyway, so no archive cycle is
introduced and `hello.exe`'s linked-member set is unchanged.  `putchar`,
`console_puts` and `printf` append to it; a `console_write` longer than
the free space flushes it first and then sends its bytes directly.

It is written out at a `'\n'`, when it fills, before every console read
(`getchar`, `console_read`, `console_poll`, `console_readline`), before
`run`, and at exit (`_exit` calls `kos_exit_flush`, which flushes the
console and then the stream hook).  The order a program's output appears
in therefore does not change: `tests/test_io_sim.py`'s `iomix` replay
asserts the whole transcript against the unbuffered shape, including the
prompt-before-echo, marker-before-child and exit-flush cases.

A write error is returned by the call that flushed; `putchar` keeps
returning its byte and the failed bytes are gone (the buffer never
replays them), which is what `kos/console.h` now says.

The stream layer registers its exit flush through a function pointer in
the console client (`kos_stream_flush`), so `exit` flushes open streams
while a program that never calls `fopen` still links none of the stream
code.

## 3. The streams

`klibc/stdio.h` is the ISO C subset: `fopen` (`"r"`, `"w"`, `"a"`, a `b`
accepted and ignored), `fclose`, `fread`, `fwrite`, `fgetc`/`getc`,
`fputc`/`putc`, `fgets`, `fputs`, `fflush` (`NULL` flushes every stream
and the console), `feof`, `ferror`, `fseek`, `ftell`, `rewind`.  The
pool is four streams with a 512-byte buffer each; the fifth `fopen`
returns `NULL`.

- reads pull a buffer at a time; a read of a buffer or more goes straight
  into the caller's memory (one copy, not two), chunked to the one
  descriptor a call can carry (4,096 bytes);
- writes collect and leave at a full buffer, at `fclose`, at `fflush` and
  at exit; a write of a buffer or more flushes first and then goes out
  directly;
- `fseek` flushes pending writes, drops the read buffer, seeks
  (`SEEK_SET`/`SEEK_CUR`/`SEEK_END`) and clears EOF; `ftell` is the
  logical position, buffered bytes included; `rewind` seeks to 0 and
  clears the error flag;
- a call whose ISO result cannot carry the error returns the negated
  native code (`fclose`, `fflush`, `fseek`).

Two implementation notes worth keeping:

- **`kos_stream_push` sends only dirty streams.**  A read stream's buffer
  holds bytes *from* the file; before that check, `fseek` (which pushes
  first, to get the pending writes out) sent them back through `write`.
  The `iostream` replay caught it: ten of its thirty-seven outcomes
  failed.  `tests/test_stdio.py` now has a `seek-no-write` case (the file
  provider counts write calls) for the same bug.
- **No multiply.**  SDCC turns a variable or 32-bit product into
  `__mulint`/`__mulong`, and no `libkos` member defines one, so a program
  that writes such a product does not link (the old tree already had
  this: only division and modulo entries exist).  `fread`/`fwrite`
  therefore walk items one at a time instead of computing `size * nmemb`,
  and the plan arithmetic keeps its products in a 16-iteration shift-add
  helper (`mul16` in `stream.c`); products by powers of two stay shifts
  and are fine.  `docs/sdk.md` section 5 now warns about it.

## 4. The plan (`kos/stream.h`)

`fmeasure(stream, timer)` opts a stream into TIMER timing of its refills;
`fstats` reports count/min/mean/max in 25.6 µs counts.  `stream_plan` is
pure arithmetic on a need (rate B, period T, chunk C, mean and worst
refill times, safety factor, default 2) and reports b = B·T (milli-bytes
per tick), n = floor(C/b), P = safety·B·t_worst + C rounded up to whole
chunks, the start-up delay P/R with R = C/t_mean, the utilisation
U = B/R in percent and `feasible` = U < 50 %.

The two documented fixtures (t_mean 18.5 ms and t_worst 150 ms from the
512-byte card figures, T = 782 counts = 20 ms):

| consumer | B | b (milli-B/tick) | n | P | U | start-up |
|---|---|---|---|---|---|---|
| 100 KiB / 180 s | 568 B/s | 11 370 | 45 | 1 024 B | 2 % | 37 ms |
| 100 KiB / 30 s | 3 413 B/s | 68 325 | 7 | 1 536 B | 12 % | 55 ms |

`WORK.md`'s fixture table reads `P = 2 KiB` for the second consumer.  The
stated formula (P = safety·B·t_worst + C, safety 2) gives 2·511 + 512 =
1 534, rounded up to 1 536 B; 2 048 B is what the same formula gives at
a 200 ms worst refill (2·682 + 512 = 1 876 → 2 048).  The code, the test
and `docs/sdk.md` all use the stated formula and the stated 150 ms
fixture; the table's `B ≈ 3.4 KB/s` and `U ≈ 13 %` round the same way
(3 413 and 12 %).

`tests/test_stdio.py` pins both fixtures and an infeasible consumer
(20 000 B/s: U = 72 %, P = 6 656 B) by executing the real member.

## 5. The bench (requirements 2 and 6)

`tests/bench/iobench.c` runs one line per row with per-call min/mean/max
and the mean per byte, all in T-states, timed with the TIMER driver
(25.6 µs counts).  The readings are themselves IPC calls, so the bench
measures its own cost first and subtracts the two a batch spends - and a
batch has to span enough counts to be read at all, which is why the
console and ipc rows run as one batch (the row's total) and the file rows
keep eight.

Before: the same bench, with the `file.getc` row removed (the old SDK has
no stdio), linked against the HEAD SDK.  After: the finished tree.  Both
in the `fs-selftest` image from the monitor's `X`, card peer present;
transcripts in
`docs/validation/2026-10-15-m13-sdk-buffered-io-sim-{before,after}.txt`.

| row | ops / bytes | before (T-states) | after (T-states) |
|---|---|---|---|
| `ipc.null` | 100 polls | 16 486 per call | 16 683 per call |
| `con.putchar` | 2 000 chars | 16 686 per byte | 1 330 per byte |
| `con.printf` | 1 call, 2 000 chars | 4 263 952 per call (2 131/byte) | 3 164 432 per call (1 582/byte) |
| `con.write` | 8 writes, 2 000 bytes | 188 578 per write (754/byte) | 189 442 per write (757/byte) |
| `file.byte` | 32 768 one-byte reads | 29 048 per byte | 29 040 per byte |
| `file.getc` | 32 768 getc | — (no stdio yet) | 2 598 per byte |
| `file.block` | 64 512-byte reads | 597 382 per read (1 166/byte) | 599 518 per read (1 170/byte) |

Requirement 6's two expectations hold:

- **`con.putchar` is close to `con.printf`**: 1 330 against 1 582
  T-states per byte, both dominated by the same console call per 128-byte
  line (two flushes per 2 000 bytes of `printf`, sixteen of `putchar`).
  Before, they were 16 686 against 2 131: the per-byte call was the whole
  cost.
- **`file.byte` through `getc` is close to `file.block`**: 2 598 against
  1 170 T-states per byte, against 29 040 for the same file read one byte
  per `read`.  The buffered byte loop is 11× cheaper than the unbuffered
  one and 2.2× the cost of reading whole 512-byte blocks - the difference
  is the per-byte buffer copy and call, with one card read per 512 bytes.

The rows that do not touch the new paths (`ipc.null`, `con.write`,
`file.byte`, `file.block`) are unchanged within the clock's resolution,
which is what the two runs being the same image otherwise say.

## 6. Validation

Run from a clean tree (the frozen-tree hashes are in section 7; the
commands are `WORK.md`'s list, in order):

```sh
make                       # production and every program build
python3 -m unittest tests.test_sdk tests.test_source_layout \
    tests.test_stdio tests.test_io_sim
python3 -m unittest tests.test_console_acceptance tests.test_shell_sim \
    tests.test_hwtest_sim tests.test_device_release
make fs-selftest
make subsystem-selftest    # blocked, see section 9
git diff --check
```

| command | result |
|---|---|
| `make` | image `konaos.bin` 524 288 B, romfs 132 548 B; mapcheck OK |
| `tests.test_sdk tests.test_source_layout tests.test_stdio` | 82 tests, OK (1 skip) |
| `tests.test_io_sim` | 3 tests, OK (`iomix` transcript, `iostream` 37 checks, the bench rows) |
| `tests.test_console_acceptance tests.test_shell_sim tests.test_hwtest_sim tests.test_device_release` | 23 tests, OK (969 s) |
| `make fs-selftest` | 39 tests, OK (3 fs-selftest, 26 `test_events`, 7 `test_far_data`, 3 `test_io_sim`) |
| `make subsystem-selftest` | blocked by the pending 53b split; not this package's change (section 9) |
| `git diff --check` | clean |

**Requirement 0 (the console-integration image retires).**  The files,
Makefile rows and `KOS_*_SELFTEST` flags are gone; the images and the
replays that remain cover what they did: the driver/source-layout tests
(124 tests), the SDK tests, the console acceptance image, the shell
replays, the hardware exerciser's replay and the device-release replay.
`tests/test_source_layout.py`'s tracked-file list and
`tests/test_sdk.py`'s program list no longer name any of them.

**Requirement 1 (the 49d correction-01).**  The scratch rule moved to
`_derive_scratch` in `tests/test_romfs_sim.py`; `far_data.exe`,
`banks.exe` and `known.bin` moved from `systems/production.json` to
`systems/fs.json` (storage sizes before 145 070 B, after 131 310 B, with
`iobench.exe` added later), and `tests/test_far_data.py` replays
`build-fs-selftest` through the monitor's `X`.  The addendum is in
`docs/validation/2026-10-12-far-data.md`.

**The 53b delivery reading.**  `tests/test_events.py` measures the event
mechanism's cost per delivery from the return-path stamps, and the
console buffer moved what it saw: its second span ran from the handler's
last syscall, and `events watch`'s handler ends in a console write - one
call per byte before this package, buffered now - so the span took in the
handler's own formatting and copy (14,068 T-states per delivery, 7.0% at
50 Hz, and the 5% share assertion failed on the relinked image).  The
harness now stamps the handler's entry and its return (the return address
the trampoline pushes, read off the stack) and pairs the stamps by
nesting depth, so the figure is the mechanism's round trip less the
handler's own body - its three spans are the frame build and the hand-off
(1,710), the trampoline's entry with its argument-block snapshot (2,568)
and the restore with the return gate and the unwind (4,129): 8,407
T-states per delivery on the deadline machine (4.2% at 50 Hz), 8,486 on
the card-peer one.  That is the complete mechanism, where the 53b reading
was 948 T low - it had left the trampoline's entry side out and carried
the app's own tail - so the bound moved with it (the measurement plus a
tenth, 9,250; the peer machine's 12,000 is unchanged), and
`docs/devices.md`, `docs/memory.md` and the 53b record carry the
corrected figure.  The delivery itself is untouched: this package changed
no kernel code, the deadline grid and the card-peer outcomes read as they
did.

## 7. Ledgers and hashes

| item | before | after |
|---|---|---|
| `libkos.lib` | 110 796 B | 159 150 B |
| `hello.exe` | 5 457 B (BSS 163) | 5 551 B (BSS 295) |
| `iobench.exe` | — | 15 724 B (BSS 5 266) |
| `iomix.exe` / `iomix_child.exe` | — | 6 333 B / 2 479 B |
| `iostream.exe` | — | 16 879 B |

`hello.exe` grows by the console buffer and its flush code only (+94
bytes of image, +132 of BSS): it links no stream member; `libkos` grows
by the whole stream layer and the plan arithmetic, which a program that
never calls `fopen` or `stream_plan` never links.

The store grew by the four programs: the `fs` image's romfs is 110 179
bytes over 17 files, and the four are 15 724 (`iobench.exe`), 6 333
(`iomix.exe`), 2 479 (`iomix_child.exe`) and 16 879 (`iostream.exe`) of
them - 41 415 bytes the same image without them does not carry
(`romfspack.py dump build-fs-selftest/recovery.romfs`).  The 49d
correction's three files moved the other way: `far_data.exe` 12 336,
`banks.exe` 2 480 and `known.bin` 64.

The two images and the store, from the runs above:

| item | sha256 |
|---|---|
| `build/konaos.bin` (524 288 B) | `0a7dde343991515c9c9ff77c7b2f84e8d55bcb2160b45a4180b8fb6e10e5a42e` |
| `build/konaos.bin`'s romfs, 132 548 B | `629cd6d528a6583145b95793dd8464f1aba5adeb3a610fa76a87e2c492ecb39f` |
| `build-fs-selftest/konaos-fs-selftest.bin` (524 288 B) | `410ed1776f017689fbbd1cc29c510c9db9bc5f20726a453388e524faa5e654f0` |

(`mapcheck: OK (18 areas, 400 symbols) [production]`, and the `fs` build's
`OK (18 areas, 405 symbols)`; the transcripts of the runs above are the
things the replays regenerate, and the two bench ones are in the
`-sim-*.txt` files beside this record.)

## 8. Board (owner)

Pending, hardware side of requirements 2 and 6:

1. boot the `fs` image from the card, run `X /system/iobench.exe`, and
   keep the transcript (a card copy of `iobench.exe` is built beside the
   other card programs);
2. the two expectations to check on the machine: `con.putchar` close to
   `con.printf` per byte, `file.getc` close to `file.block` and far below
   `file.byte`;
3. run `X /system/iomix.exe` and confirm the transcript is the unbuffered
   one, then `X /system/iostream.exe` (needs a writable card: it removes
   `/fs/IOSTREAM.TMP` at the end).

### Board result (owner, 2026-10-15)

`iobench` from the card on the production image (V9958+HID).  The console
rows scroll off the screen they measure; the rows that stayed visible:

| row | board, per byte | simulator, per byte |
|---|---|---|
| `con.write` (8 x 256 B) | 5,551 T | 757 T |
| `file.byte` | 28,374 T | 29,040 T |
| `file.getc` | 2,630 T | 2,598 T |
| `file.block` | 1,214 T | 1,170 T |

The file rows match the simulator within 4 %, and `getc` is 10.8x cheaper
than one-byte reads on the machine, as measured in the simulator.  The
console row is 7x the simulator's: the V9958 draws at about 1,800
characters per second on the board, while the video model has no VDP wait
states, so on the machine screen drawing, not the call, is the console's
cost.  The bench prints its console rows to the screen it reports on; an
SDBENCH port (owner) is the card benchmark going forward.

## 9. Open

- **`make subsystem-selftest` is blocked before this package's changes**:
  its geometry derivation fails at HEAD (`cold code ends at DC52h and the
  1735 data bytes do not fit 6000h-DFFFh`), and the block is tracked as
  `work/53b-m12-device-events/correction-01`.  Reproduced in a pristine
  HEAD worktree and again on this package's tree (the same message), so
  it is not this package's.  The 49d package's own consequence (the
  scratch rule `tests/test_romfs_sim.py` now carries) is in place and
  cannot be exercised until that split lands.  This package does not
  touch the derivation.
- The hardware rows of section 5 and the hardware `iomix`/`iostream` runs
  are the owner's (section 8).
