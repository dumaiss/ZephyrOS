# M10 design spike (package 33) — report, 2026-10-06

All five spike scope items are implemented as real, minimal mechanisms and
verified in the Z80 simulator.  The measurement answers the package's
question: **M10 does not fit the end-of-M9 residency; verdict (c)** — the
kernel-residency decision is required before M10 implementation.  The gap
is quantified in section 6.

**Production is unchanged**: `build/zephyros.bin` is byte-identical to the
pre-spike baseline; every kernel change is inside
`#if defined(ZOS_M10_SPIKE)`.  The spike has its own configuration and its
own image (`build-m10-spike-selftest/`).

## 1. Scope item 1 — ZEX v2 container and `zexpack` v2 (host): COMPLETE

- `include/zephyros/zex2.h` — a fixed 40-byte header (32-bit file
  geometry), a 20-byte auxiliary-segment table, a 4-byte far-entry table
  and sorted `u16` relocation patch offsets; every field offset pinned.
- `tools/zexpack.py` — v2 `pack` / `validate` / `dump` (v1 path
  unchanged).  Segments are linked at logical `0000h` through
  `tools/zmodpack.py`'s SDCC `.rel` parser and symbol resolver, applying
  every relocation and recording each patch site.
- `tools/zexmanifest.py --v2 --segments` wraps a program's derived primary
  geometry into a zex-v2 manifest.
- `tests/test_zex_v2.py` — 16 host tests.
- `docs/zex-format.md` section 8 documents the format.

## 2. Scope item 2 — resident ZEX v2 loader: COMPLETE

`kernel/process/exec.c` under `ZOS_M10_SPIKE` replaces the v1 loader:
reads the v2 header, streams the primary payload and every auxiliary
segment through the existing VFS file API and `zos_bank_copy` gate,
applies each relocation as a one-byte high-byte add, allocates segments
through the unified bank map (`kernel/process/bankmap.{c,h}`), records the
segment/far tables (`kernel/process/zex2prog.h`), and rolls back through
`process_slot_release()` on failure.  `process_exit()` and the rollback
path release the auxiliary slots, the runtime objects and the program
state; `process_alloc_bank()` will not hand out a bank carrying an
auxiliary allocation.

## 3. Scope item 3 — unified bank ownership + `SYS_XMEM_*`: COMPLETE

`kernel/syscall/xmem.c` implements `SYS_XMEM_ALLOC` / `_FREE` / `_READ` /
`_WRITE` / `_INFO` and `SYS_ZEX_SEGMENT_INFO` (numbers 20h-25h, blocks in
`abi/zos/xmem.h`).  Objects are process-owned, zero-initialized,
read/write and non-executable; ranges are checked in 32 bits before any
transfer; the record writes go through the copy gate.  `bankmap` gives
FREE / PRIMARY / AUXILIARY with 8-KiB slot ownership and packs an existing
auxiliary bank before taking a new one.

## 4. Scope item 4 — `SYS_FAR_CALL` + auxiliary low window: COMPLETE

`kernel/process/far.asm` (common-resident gate) +
`kernel/syscall/far.c`.  One cross-bank far call at a time; a recursive
call returns `ZOS_EBUSY` and `SYS_EXEC` from far context is refused.  The
gate reuses the package-28 continuation idea — it saves the dispatcher's
gate-stack frame, shadows the single-depth syscall transition state —
so ordinary syscalls issued by far code work.  The auxiliary low window
(page zero, RST 30h vector, far stack at `1F00h`, bounded in/out frame at
`0100h`) is prepared per call.

## 5. Scope item 5 — execution-bank audit: FINDING + FIX

**Finding.** `kernel_syscall_dispatch()` derived the copy bank from
`process_current_bank()` (the process's **primary** bank), not from the
bank the caller was executing in.  Every family that receives that bank
was affected: `SYS_CONSOLE_WRITE`/`_READ`, `SYS_EXEC`, the whole `FS_*`
family, and the M10 additions.  Two related observations from the same
audit:

- `SYS_DIAG_MEM_READ`/`_WRITE` are **not** affected: their blocks carry an
  explicit `{bank, ...}` selector, so they do not use the dispatcher's
  bank.
- `SYS_DIAG_BANK_INFO` (`kernel/syscall/diag.c:176`) **is** affected in
  the same way: it reports `process_current_bank()`, so far code asking
  which bank it is running in is told the primary bank.  The fix below
  does not change its ABI (it keeps reporting the process's primary bank,
  which is what the existing acceptance test asserts); the audit records
  it as a follow-up for the M10 implementation, where far code needs a
  way to name its own execution bank.

**Fix.** Under `ZOS_M10_SPIKE`, the dispatcher takes the bank from the
syscall gate's saved latch via `zos_exec_bank()` (new common-resident
routine in `kernel/process/far.asm`).  Identical for a primary caller;
correct for far code.  Proven: the spike program issues an ordinary
`SYS_CONSOLE_WRITE` and an `FS_READ` from far code and both read the
auxiliary bank correctly (section 7).

## 6. Measurements and verdict

### Per-object resident cost (SDCC 4.5.0, `--opt-code-size`)

| object | v1 (production) | spike | net |
|---|---:|---:|---:|
| `exec.c` `_CODE` | 1730 | 2830 | **+1100** |
| `exec.c` `_DATA` | 0 | 143 | **+143** |
| `process.c` `_CODE` | 785 | 884 | **+99** |
| `process.c` `_DATA` | 187 | 187 | 0 |
| `bankmap.c` `_CODE` | — | 474 | **+474** |
| `bankmap.c` `_DATA` | — | 14 | **+14** |
| `xmem.c` `_CODE` | — | 2032 | **+2032** |
| `xmem.c` `_DATA` | — | 80 | **+80** |
| `far.c` `_CODE` | — | 993 | **+993** |
| `far.c` `_DATA` | — | 1 | **+1** |
| `far.asm` `_COMMON` | — | 195 | **+195** |
| `far.asm` `_COMMON_DATA` | — | 63 | **+63** |
| `syscall.c` `_CODE` | 1391 | 1432 | **+41** |
| `syscall.c` `_DATA` | 7 | 7 | 0 |

Summing the bank7-resident deltas gives +4739 code and +238 data; the
linked ledger shows +4737 and +238, the 2-byte code difference being
shared-constant folding at link time.  The common delta is +195 code and
+63 data (the far gate only).

### Ledger (both images reproducible by a make target)

```text
production (build/, `make check`):
  bank7: code 27990 bytes end 8D56h | arena 36 granules (33 boot, 3 free)
         | data 2241 bytes at D600h | isr 256 | slack 63 bytes
  common: used 2104 of 7424 bytes (code 1410, data 694) | ceiling 3072,
          m10 512, limit 2560
spike (build-m10-spike-selftest/, `make m10-spike-selftest`):
  bank7: code 32548 bytes end 9F24h | arena 26 granules (1 boot, 25 free)
         | data 2479 bytes at D400h | isr 256 | slack 337 bytes
  common: used 2362 of 7424 bytes (code 1605, data 757) | ceiling 3072,
          m10 512, limit 2560
```

The arena *total* is a build-time function of the resident image
geometry, so it is comparable even though the two images boot different
programs: **36 granules down to 26, i.e. 10 granules (5120 bytes)**.

The per-object table accounts for that delta mechanism by mechanism:

| M10 mechanism | bank7 code+data | granules |
|---|---:|---:|
| ZEX v2 loader + unified bank map | `exec` 1100+143, `bankmap` 474+14, `process` 99 | 3.6 |
| xmem / segment service | `xmem` 2032+80 | 4.1 |
| far call + gate + exec-bank fix | `far.c` 993+1, `syscall.c` 41 (gate 195+63 in common) | 2.0 |
| **total** | **4977 bytes in bank7, 5235 bytes overall** | **9.7** |

so the attribution closes to within one granule of the measured 10.

### Projection to full M10

The spike implements the mechanisms minimally, so full M10 is projected
from the measured density (5235 bytes for the loader, the bank map, the
xmem family and the far-call path, ~10 granules):

| item | low | high |
|---|---:|---:|
| spike mechanisms (measured) | 5235 B | 5235 B |
| complete validation / error paths (+25-50 %) | +1300 B | +2600 B |
| segment & container validation in the loader (overlap, flags, bounds, far-table sanity) | +200 B | +500 B |
| acceptance-test hooks (target surface) | +200 B | +600 B |
| v1 loader deletion (credit) | −1730 B | −800 B |
| **full M10 resident cost** | **~5200 B (10 granules)** | **~8100 B (16 granules)** |

Against M10's 3-granule allowance the projection is a **7-to-13-granule
gap**, and even the low end stays below the 32-granule floor.  The gap
does not shrink with a more complete implementation; it grows.

End-of-M9 production baseline for reference
(`docs/validation/2026-10-04-m9-bank7-budget.md`): the same production
image as the ledger above (code 27990 end 8D56h, arena 36 granules with
**3 free**, slack 63, `common: used 2104 ... limit 2560`).

### Verdict: **(c) — kernel-residency decision required**

- **Arena.** The derived arena falls from 36 granules (production) to
  **26** with the full spike.  The production floor is **32 granules**, so
  the shortfall is **6 granules = 3072 bytes**, twice M10's entire
  3-granule budget.  Verified directly: `tools/mapcheck.py
  --min-granules 32` on the spike map fails with

  ```text
  mapcheck: derived driver arena is 13312 bytes, below the 16384-byte minimum
  ```

- **Even the loader alone breaks the budget.** The loader + bank map
  attribution above is 1830 bytes = **3.6 granules**, over M10's 3-granule
  allowance before a single service is added.
- **Data.** +238 bytes over production, 337 bytes of end slack remaining
  (the derivation absorbed it); not the binding constraint.
- **Common.** +258 bytes, using half of M10's 512-byte reservation;
  2362 <= 2560 limit, so the common budget holds.  (The far gate is the
  only new common mechanism, 195 code + 63 data.)
- **Gate stack.** Worst case **151 bytes** (limit 240), measured in the
  simulator — the far-call path and the far-code syscalls both fit.

**The gap, stated both ways.**

- Against the **32-granule acceptance floor**: 26 vs 32 = **6 granules,
  3072 bytes** short (the `mapcheck` failure quoted above).
- Against M10's **3-granule allowance** (the production arena's 3 free
  granules): the measured need is ~10 granules, i.e. **~7 granules,
  3584 bytes** over budget.

**Why not verdict (b).** (b) requires fitting the 3-free-granule
allowance through *named* adaptations, so the candidate adaptations and
their savings were enumerated.  Each one is a reduction of the services
this spike already keeps minimal:

| candidate adaptation | estimated saving | effect on the target |
|---|---:|---|
| drop `SYS_ZEX_SEGMENT_INFO` (deferred, report-only) | ~150-250 B | loses the introspection syscall the M10 spec lists |
| drop `SYS_XMEM_INFO` (report-only) | ~100-150 B | loses xmem introspection |
| limit a program to one auxiliary segment | ~60-120 B | target becomes one-segment-per-program |
| one far entry per segment (drop the 5-entry table) | ~40-80 B | target becomes one entry point per segment |
| shrink the bounded in/out frame | ~0 B | the window is already the minimum the gate needs |

The sum of every optional saving is well under **1 granule (512 bytes)**,
against a required **7** — and none of the three large items is optional:
the loader + bank map (1830 B), the xmem service (2112 B) and the far call
(1293 B) are the target's core, and this implementation already omits
complete validation/error paths.  Verdict (a) is excluded by measurement
(10 > 3); verdict (b) is excluded because no combination of the named
adaptations closes the gap without abandoning a mechanism the target
requires.

**Conclusion.**  **The project owner should take the kernel-residency
decision (for example a second kernel bank, or relocating a resident
mechanism) before M10 implementation**, per architecture section 36.18.

### Relocation finding

High-byte-only patching is exact for **every** legal slot base: a slot base
is a multiple of 256, so `value + base` never carries into the low byte,
whatever the low byte is.  Real SDCC patches have non-zero low bytes
(`37 0F 37 37 00 13`), so the reference note's "low byte is
base-independent" premise is true but not load-bearing.

**Additional finding (host packer limitation).** SDCC emits a
**byte-fragmented relocation** (mode `R_BYTE`) when a const-symbol
address is stored directly into a stack/struct field, which
`tools/zmodpack.py`'s mini-linker rejects ("use a static descriptor
initializer").  The spike works around it (copy to a stack buffer first),
but the minimal relocation set actually required by generated Z80 far
code therefore includes byte-granular patches for that data form: the low
byte needs no change and the high byte needs the same high-byte add.  A
production packer must either encode and apply those byte relocations or
reject the form; this spike rejects it, and the report records the
data form that produces it.

### Spike container and program

Container 7016 bytes: primary image 6358 + 183 BSS; segment 1 image 112 +
2 BSS (3 relocations); segment 2 image 426 + 2 BSS (7 relocations); 5 far
entries; 2 slots.

## 7. What the simulator proves (`tests/test_m10_spike_sim.py`, 7 tests)

The spike image boots the ZEX v2 program; the program reports
`m10 spike: 17/17 checks` and `m10 spike: PASS`:

- both auxiliary segments land on their 8-KiB slots in one bank, byte-for-
  byte equal to the packed image with every relocation applied; the low
  byte of every patch is unchanged; the rest of each slot is zero (BSS);
- `SYS_XMEM_ALLOC` of 9000 bytes spans two slots; a write at offset 8188
  crosses the slot boundary and reads back exactly; the object is
  zero-initialized; `SYS_XMEM_INFO` reports requested 9000 and allocated
  16384; free then stale-handle rejection;
- `SYS_ZEX_SEGMENT_INFO` for both segments (present, image size > 0) and
  `ZOS_ENOENT` for a missing id;
- far calls into segment 1 and segment 2 with an in/out frame;
- an ordinary `SYS_CONSOLE_WRITE` and an `FS_READ` **from far code**
  (the read gets the container's `ZEX2` magic from the auxiliary bank);
- a recursive far call returns `ZOS_EBUSY`;
- after exit the auxiliary owner map, slot bitmaps, ZEX v2 program state
  and `process_running_pid` are back to baseline.

Gate-stack worst case over the run: **151 bytes**; 391,515 simulated
instructions.

## 8. Deliberate deviation (reported, not silent)

The production arena floor is **32 granules** and the spike's derived
arena is **26**, so the full spike cannot link under the production floor
gate.  Per the package's own rule ("if the spike does not fit, measure
anyway and report by how much") the *shortfall is the result*.  So that
the mechanisms can be *proven*, the spike image is built with the
acceptance-image floor (`ZOS_ARENA_MIN_GRANULES=16`, the same floor every
other acceptance image uses) and the exact gap is reported here.  The
production floor, the common ceiling and the gate-stack limit are
unchanged; no production configuration was touched.

## 9. Package sequence

1. **33a — ZEX v2 host toolchain** — done.
2. **33b — resident ZEX v2 loader** — done (measured).
3. **33c — bank ownership + `SYS_XMEM_*` + `SYS_ZEX_SEGMENT_INFO`** — done.
4. **33d — `SYS_FAR_CALL` + auxiliary low window + execution-bank fix** — done.
5. **33e — report and verdict** — this record.

**Next (not this package):** the project owner takes the residency
decision.  Then the M10 implementation packages follow: ZEX v2 conversion
of every first-party program and v1 deletion; the xmem and far-call
services promoted out of the spike guard; a production packer that
handles or rejects byte-fragmented relocations; the on-target far-code
toolchain wrappers.

## 10. Validation

```sh
make clean && make check                            # production unchanged
make m10-spike-selftest                             # spike image + ledger + sim
python3 -m unittest tests.test_zex_v2 tests.test_m10_spike_sim -v
git diff --check
```

Result: all pass, re-run in full on 2026-10-06.

- `make clean && make check` — **773 tests, OK (183 skipped)**, 66.7 s of
  test time / 2 min 3 s wall.  Production ledger exactly the end-of-M9
  baseline: `bank7: code 27990 bytes end 8D56h | arena 36 granules
  (33 boot, 3 free) | data 2241 bytes at D600h | isr 256 | slack 63`,
  `common: used 2104 of 7424`.  Production image
  `build/zephyros.bin` = `f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7`,
  identical to the pre-spike hash.
- `make m10-spike-selftest` — builds the spike image, passes `mapcheck`
  and runs the 7 simulator tests, **OK in 5.8 s**.  Ledger as in section 6
  (code 32548, arena 26 granules, data 2479, common 2362).
- `python3 -m unittest tests.test_zex_v2 tests.test_m10_spike_sim` —
  **23 tests, OK in 6.0 s**.
- `git diff --check` — clean.

### Artifact hashes (SHA-256)

| artifact | SHA-256 |
|---|---|
| `build/zephyros.bin` (production) | `f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7` |
| `build-m10-spike-selftest/zephyros-m10-spike-selftest.bin` | `69b54674bd79d2f299d422e02c7f9e047721ef58b29087dc289338d6f6ec60ce` |
| `build-m10-spike-selftest/user/spike/spike.zex` | `47a3ae1b4390f1551cdb714d0a4f32c127bdde7ca2f39b2ad476c76e7480f526` |

Hardware: not run.  Bank switching and far-call return are
hardware-authoritative (target 3); the spike image and its simulator
transcript are the evidence, so a board run is `PENDING (spike)` and can
be reproduced with `make m10-spike-selftest` (image
`build-m10-spike-selftest/zephyros-m10-spike-selftest.bin`, SIO0/B
38400 8N1).

## Supervisor acceptance note (2026-10-06)

Package 33 is accepted (host and simulator; hardware `PENDING (spike)`).
Production is byte-identical (`f4da0496…`), and verdict (c) stands.

**Projection correction.** The "Projection to full M10" table subtracts a
v1-loader deletion credit (−800 to −1730 bytes). In the spike build,
`kernel/process/exec.c` compiles the v1 loader only under
`!ZOS_M10_SPIKE`, so the measured `exec.c` delta (+1100) is **already net of
removing v1**, and the credit is counted twice. Without it, full M10 is
about **6.9-8.9 KB resident, roughly 14-18 granules**, not 10-16. The
conclusion (verdict (c), a residency decision before M10) is unchanged and
stronger. Later packages should use this corrected range.
