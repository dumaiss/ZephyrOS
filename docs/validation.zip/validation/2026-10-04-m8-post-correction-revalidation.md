# M8 Post-Correction Re-validation (Packages 21-24) — 2026-10-04

**Status: accepted (supervisor decision, 2026-10-04) — the corrected
production image boots to the interactive monitor on physical hardware.
That boot is accepted as evidence the corrections are sane; re-smoking the
earlier milestone acceptance images is not required.**

Packages 21-24 changed the production ROM
(`build/zephyros.bin`
`e6eaabc7fcb092bbd31721b21ade9e7ff48c0e39f476e5abc1925571be58e330`)
by removing acceptance-only CTC code from the production link (package
23).  All production ZMODs are byte-identical to the pre-correction
baseline.  Because the ROM changed, prior physical evidence no longer
applies and the corrected image must be re-flashed and re-validated
(package 23 validation).

## Operator-reported physical boot (2026-10-04)

The operator reported that the corrected production image booted on the
Zephyr-80 and reached the native monitor.  Observed display output
(transcribed from a photograph of the V9958 console):

```text
console: dynamic sio0.b OK
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> h
D addr len        dump monitor bank (16-byte rows)
DB bank addr len  dump bank 0-6
M addr value      set byte in monitor bank
MB bank addr value set byte in bank 0-6
I port            input port (10-FF)
O port value      output port (10-FF)
Q                 quit
H or ?            help
Z80> r
system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02
process: pid 0 bank 0 flags 0001
bank: current 00 mask 7F
```

Interpretation:

* the production boot path completed the ordered SIO/IOC/HID/V9958 module
  load and the console bind (the `console: dynamic sio0.b OK` line);
* the monitor launched through the unchanged M6 process path, and its
  `h`/`r` commands produced the expected output; the interactive session
  exercises both input (keyboard) and the V9958 output;
* `system: abi 01` is the diagnostic `SYS_DIAG_SYSTEM_INFO` structure ABI
  (`ZOS_DIAG_SYSTEM_INFO_ABI`), independent of driver ABI v2;
* `kernel-bank 07` and `romfs 02` match the production layout.

This is operator-reported evidence, not a tool-captured transcript, and
the flashed image hash was not independently read back.

## Supervisor decision

The operator/supervisor accepted the successful production boot as
sufficient evidence that the packages 21-24 corrections are sane, and
waived the requirement to re-smoke the earlier milestone acceptance
images.  No further per-image physical re-validation is required for this
correction.  The corrected production image hash and the changed
acceptance-image hashes are recorded below for reference.

## Reference hashes (recorded, not individually re-smoked)

| Image | SHA-256 |
| --- | --- |
| Production `build/zephyros.bin` | `e6eaabc7fcb092bbd31721b21ade9e7ff48c0e39f476e5abc1925571be58e330` |
| IRQ | `fdb480f6d9b34e937585060829fc18a14d7514e157c60bdef37e0c036d5dd9dc` |
| M3 | `0916ee70bbb0b6c7aef124cd566900aba72b7a32db807c5114ca1b653de11989` |
| M4 IRQ | `00da4f54cfa19f25c69ebeaf507c1bca034b2f4fcf172ef350ce977337352796` |
| M4 shifted | `17097769d3b01b9c078983be676cdd8110a4f91916252a26ef7de1dc4a604fb4` |
| M4 failure | `e5835d58951f99547cace42db97f11122f21d1f90af886e34f3ace3e35c0a8f7` |
| M8 integration | `5beed6bbcc1e9d35573abc44a6149246d57d8fc93326ef70df313ea464380c22` |
