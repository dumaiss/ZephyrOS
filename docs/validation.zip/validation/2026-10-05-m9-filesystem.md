# M9 integration acceptance (package 31): validation record

Work package: `work/31-m9-integration-acceptance`.  Date: 2026-10-05.
Host toolchain: SDCC 4.5.0 (`sdcc`/`sdldz80`/`sdasz80`), Python 3 host tools.
Sibling transcript file: `2026-10-05-m9-filesystem-hw-transcript.txt`.

## 1. Result

M9's implementation, host/simulator acceptance and documentation are
complete.  The **five required physical rows are `PENDING`** (no bench
capture was obtained by this package), so per the section 33 rule M9 stays
open until they pass; section 34 of `docs/architecture.md` records that.

```text
host + simulator : PASS
physical rows    : PENDING (5 rows; see section 8)
M9 closure       : OPEN until the physical rows pass
```

## 2. Tree identity (frozen before final validation)

```text
repository   dumaiss/ZephyrOS, branch main
base commit  56cbd2c54c644410176c8ece811b967b17e750dc
             ("M9 -- IOC based File System (we can now read/write to SD)")
tree state   uncommitted working tree: package 30c's reclaim plus package
             31.  Validation records and work/ contracts are deliberately
             untracked, so `git status --short` never shows them.
frozen       all evidence below comes from this one source state; every
             image was rebuilt from it by `make clean` and packed by
             `make`, then validated once by `make check` and the named
             acceptance targets, then by `python3 -m unittest discover`.
             `git diff --check` reports no whitespace errors.
```

`make check`'s reproducibility gate is the byte-level proof that the
recorded production image is the frozen tree:

```text
check: reproducible rebuild (f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7)
```

## 3. Images and module hashes (sha256)

```text
build/zephyros.bin                    f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7
build/zephyr80.bin                    f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7
build/recovery.romfs                  1d268afc1a5696297dd755697223fe82918f5047e40484ad2246895456aead1c
build/modules/sio.zmod                bf435bcacd42bc93148b3d84b5896463884ff304c56b40a90da6578321388159
build/modules/ioc.zmod                3f1e3fa26b2d1635d2457876276c8be935fe662560eda004b8c3668b53004b5d
build/modules/hid.zmod                7513af162fde691780a6e853be0916dd0ec46fbbd024ee124e92c0601d2174d7
build/modules/v9958.zmod              6d84c8cf18366126fb16650f6e3841c0604042d174a3aea37609ae3dc544a45e
build/modules/iocfat.zmod             5efd30fa1e428c0c546eaaa8ee11048646a01c522680ac5ee64fe4d4e5cbcaa6
build/modules/monitor.zex             7c59b604620b3ad69ebda5a83343a5c98cb2ad23ea9e05da763bf322f6133f14
build/modules/fstest.zex              d93d53104fd80845c33e80e81beed7cec85d1bf4f87f46eede6f04e0a7685bc1
build/modules/fsfat.zex               e0c5e149ed04dd2b0e50f86755b81ea316e5bd1c193bcd3046febf5ac8965b5d
build/modules/fstest_l.zex            aafc85280d082074a364e018165fa41212efde087c336c80559b3b7f9df0694d
build/modules/fschild.zex             6284a47bf040d09da12f0a393576515f503f323ab228c835846944a22a937072
build/modules/fsdeep.zex              1f34e9c4f11a3a86f8a2e3be97dd29b56ea780e3b57097487ae4125ebf1399bc
build/modules/fsraw.zex               b8ea9f523be62e07a9d6de5500a23f2aa424bc4f6f193c3334dba4687d5f2407
```

Acceptance images (the hashes the physical rows quote):

```text
build-m9-selftest/zephyros-m9-selftest.bin                        2b1c89e69fc074983f9af7c834904685e74b0f9ccd5f1164b5156fb3e224c47b
build-m9-iocfat-selftest/zephyros-m9-iocfat-selftest.bin          67b750d8ae22d6b01e56350b9386f89bbc9bb20dd6bfc1b482673b4df9cefd6e
```

`fsfat.zex` is 5972 bytes and `fstest.zex` 7641 bytes.  Both are new or
extended by this package; `fsfat.zex` is packed only into the M9
integration image.

## 4. Bank-7 ledger (architecture section 32.39)

Production (frozen):

```text
bank7: code 27990 bytes end 8D56h | arena 36 granules (33 boot, 3 free) | data 2241 bytes at D600h | isr 256 | slack 63 bytes
common: used 2104 of 7424 bytes (code 1410, data 694) | ceiling 3072, m10 512, limit 2560
```

Boot set: `sio x1, ioc x8, hid x2, v9958 x9, iocfat x13` = 33 granules.

| 32.39 target | required | measured | verdict |
| --- | --- | --- | --- |
| production arena floor | >= 32 granules holding the production boot set | 36 granules, 33 used by the boot set | PASS |
| end-of-M9 slack | >= 1 KiB | 3 x 512 + 63 = 1599 bytes | PASS |
| common ceiling (30c) | used <= 2560 of 7424 | 2104 | PASS |
| IOC-FAT cache slots | build-time, reported in the ledger | **1** (`IOCFAT_CACHE_SLOTS 1u`, `#error` on any other value) | PASS |

`iocfat.zmod` is 6006 image + 637 BSS = 6643 bytes, 13 granules, 13 bytes
under its 6656-byte ceiling.  The `m9-selftest` image is not production: it
compiles HID/V9958 out and adds the acceptance object, so its ledger
(`code 29855 bytes end 949Fh | arena 30 granules (22 boot, 8 free) | data
3306 bytes at D200h | slack 22`) is recorded for completeness only.

## 5. Section 33 coverage

Every item has simulator evidence.  "HW" names the physical row that adds
physical evidence (all five rows are `PENDING`, see section 8).

| section 33 item | where it is proven | HW |
| --- | --- | --- |
| namespace: `/`, `/SYSTEM`, absolute/relative, `.`/`..`, CWD crossing | `fstest.zex` `namespace` case (hit in every M9 image) | row 3 |
| namespace: root mountpoint visibility | `fsfat.zex` `namespace` (enumerates `/`, requires `SYSTEM`) | row 3 |
| namespace: mountpoint shadowing | `fsfat.zex` `namespace` (`/SYSTEMX` is served by `/`, never by the mount) + `m9-vfs` target test | row 3 |
| namespace: case-insensitive lookup | `fstest.zex` `namespace` (`/system/fstest.zex`), `fsfat.zex` `namespace` (`/system`) | row 3 |
| ROMFS: open/read/stat, enumeration, mutation `EROFS` | `fstest.zex` `romfs` | row 3 |
| IOC-FAT: open/create/close, TRUNC, read/write, sync, seek, stat, mkdir/rmdir, rename, unlink | `fsfat.zex` `basic` (all of them) + `fstest.zex` `iocfat` | row 3 |
| sizes 1, 127, 128, 129, 511, 512, 513 | `fsfat.zex` `sizes`, each written then read back and compared by an in-program check value | row 3 |
| sizes > 64 KiB | `fsfat.zex` `large` (65537 bytes, hashed both ways) | row 3 |
| IOC-FAT cache: repeated-read hit, miss/fill, cross-block reads | `m9i_case_cache` in `tests/target/m9/m9_iocfat_test.c`; exact `FS2_READ` deltas between fences asserted by `tests/test_iocfat_sim.py` (**simulator evidence**, see below) | row 3 |
| IOC-FAT cache: write-through update/invalidate | same; `fsfat.zex` `cache` re-proves the data correctness through the public ABI | row 3 |
| IOC-FAT cache: no stale data after a write through the other open file | `m9i_case_cache` (simulator counts) + `fsfat.zex` `cache` (reads the new bytes through the other descriptor) | row 3 |
| IOC-FAT cache: generation invalidation | `m9i_case_cache` `cache:stale:*` with the simulator arming `fs2_read_fault`; the `m9-selftest` fault window re-proves it | row 3 (operator card change, optional) |
| error: missing file | `fstest.zex` `errors`/`iocfat`, `fsfat.zex` `errors` | row 3 |
| error: wrong object type | `fstest.zex` `romfs`/`errors` (`EISDIR`, `ENOTDIR`), `fsfat.zex` `errors` | row 3 |
| error: descriptor-pool exhaustion (`EMFILE`) | `fstest.zex` `pool` (the 8-entry VFS pool) and `fsfat.zex` `pool` (the provider handle pool) | row 3 |
| error: stale backend handle | `m9 selftest: fault:stale:*` window, armed by the simulator; `fs2_stale_path` replay in `tests/test_iocfat_sim.py` | simulator (`observed`); hardware shows `fresh` unless the operator changes the card |
| error: unavailable SD | production with no card (`vfs: / unavailable 0x03`); `m9-selftest` absent-card replay (`OK (card absent)`) | rows 1, 2 |
| error: failed confirmed write | `m9 selftest: fault:write:*` window with the simulator arming `fs2_write_fault="done_fail"`; the provider reports `EIO` and neither the offset nor the size moves | simulator (`observed`); not reproducible on demand on hardware |
| error: cross-filesystem rename -> `EXDEV` | `fstest.zex` `exdev` and `fsfat.zex` `exdev` (both directions, plus a same-filesystem rename that still works) | row 3 |
| lifecycle: child inherits CWD, child CWD change isolated, descriptors closed on exit, repeated exec/exit leaks nothing | `fstest.zex` `exec` case (run by every RAM acceptance image) | simulator only (justified: the card image proves nesting via the depth probe instead) |
| lifecycle: nested chain reaches exactly `ZOS_EXEC_MAX_DEPTH`; the next level is refused with `EBUSY` and leaks nothing | `fsdeep.zex` depth probe, run by `m9-exec-selftest` and by `m9-selftest` (exit status must equal `ZOS_EXEC_MAX_DEPTH`) | row 3 |
| lifecycle: exit-status round trip including a raw-return `ZOS_EFAULT` | `fstest.zex` `exec` case (`fsraw.zex`) | simulator only, as above |
| lifecycle: the suspended gate frame is restored byte-for-byte at every depth | `tests/test_m9_exec_sim.py` measures the copied frame against `ZOS_EXEC_FRAME_SAVE` and compares the restored frame at every depth | simulator only |
| budget: final ledger meets 32.39 | section 4 above | n/a |

**Cache evidence, explicitly simulator-only (accepted deviation).**  Package
30 correction-01 removed the module-side `TEST-ONLY` counter because the
finished provider exactly filled its 13-granule budget (13 bytes under the
6656-byte ceiling), and the project owner accepted the deviation:
`tests/test_iocfat.py::test_no_test_only_hook_remains` asserts that
`fs/iocfat/*.c` carries no hook.  The cache rules are therefore proven by
counting `FS2_READ` commands at the simulated MCU peer between the
`m9 iocfat: cache:N` / `fstest: MARK` fences
(`tests/test_iocfat_sim.py:CACHE_READ_DELTAS`).  The hardware transcript for
row 3 exercises the same read/write paths and shows the same fences but
cannot count commands; the data-correctness half is re-proven in
`fsfat.zex` `cache` through the public ABI, and the card is left clean.

## 6. Tests

Host suite (`python3 -m unittest discover -s tests -v`) after every image
is built:

```text
Ran 750 tests in 510.727s ... OK (skipped=120)
```

All 120 skips are the pre-existing "build the other acceptance image
first" guards: each image replay skips when its `build-*/…bin` is absent,
and the named matrix deliberately does not build the images that other
packages own - `build-subsys-selftest` (48), `build-m8-console-selftest`
(31), `build-m8-ioc-selftest` (26), `build-m8-hid-selftest` (11),
`build-m8-v9958-selftest` (4), `build-romfs-corrupt` (3),
`build-m9-required-mount-selftest` (2) and `build-helloworld` (1).  No skip
hides a failure of this package: every image the M9 matrix names was built
for this run, and every one of its replays ran.

Target self-tests built and replayed (one build, one replay each):

```text
m9-vfs-selftest          OK
m9-provider-selftest     OK
m9-fs-selftest           OK
m9-exec-selftest         OK
m9-iocfat-selftest       OK
m9-selftest              OK (7 tests, 233 s; the >64 KiB case moves 128 KiB
                             over the simulated lane)
m8-selftest              OK
m8-fallback-selftests    OK
zmod-test romfs-test zex-test monitor-test ioc-test hid-test v9958-test  OK
```

New tests this package adds:

* `tests/test_m9_selftest.py` - the integration image's build wiring, the
  manifest, the fstest -> fsfat delegation and its reason, fsfat's section-33
  coverage, the target test's fault windows, and the serial smoke mode.
* `tests/test_m9_selftest_sim.py` - the simulator replay: one shared full
  boot asserting the whole transcript (`fstest: PASS 5/5`, `fsfat: PASS
  8/8`, `m9 selftest: OK`, then the monitor prompt), the >64 KiB case, the
  inert fault windows, the gate-stack high-water mark, plus separate cheap
  boots for the armed-fault windows and for the absent/write-protected card
  paths.
* `tests/test_docs_evidence.py` - now also scans every dated record so a
  record that cites a transcript or an earlier record must have it on disk,
  without requiring git tracking.

## 7. Simulator transcripts

### 7.1 `m9-selftest` (the M9 acceptance image, card present)

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
console: dynamic sio0.b OK
fstest: namespace OK
fstest: romfs OK
fstest: MARK ioc0
fstest: MARK io1
fstest: MARK io2
fstest: MARK io3
fstest: MARK io4
fstest: MARK io9
fstest: iocfat OK
fstest: window OK
fsfat: namespace OK
fsfat: basic OK
fsfat: sizes OK
fsfat: large OK
fsfat: cache OK
fsfat: pool OK
fsfat: exdev OK
fsfat: errors OK
fsfat: PASS 8/8
fstest: fat OK
fstest: PASS 5/5
m9 selftest: fault:stale:arm
m9 selftest: fault:stale:fresh
m9 selftest: fault:stale:end
m9 selftest: fault:write:arm
m9 selftest: fault:write:fresh
m9 selftest: fault:write:end
m9 selftest: OK

ZephyrOS native monitor
bank=00 pid=0 scratch=11A8
Z80>
```

The `fault:*:fresh` notes are what real media produce with no fault
injected.  With the peer armed (`tests/test_m9_selftest_sim.py::
test_faults_reach_the_provider_when_armed`) the same windows print
`observed` for both, which is the simulator evidence for the stale-handle
and failed-confirmed-write error paths.

### 7.2 Per-image replays

The other M9 images keep their packages' replays and pass unchanged
(`tests/test_m9_vfs_sim.py`, `tests/test_m9_provider_sim.py`,
`tests/test_syscall_sim.py` for `m9-fs-selftest`,
`tests/test_m9_exec_sim.py`, `tests/test_iocfat_sim.py`); their transcripts
are in the records those tests belong to
(`2026-10-04-m9-vfs-bootstrap.md`, `2026-10-05-m9-fs-syscalls.md`,
`2026-10-05-m9-nested-exec.md`, `2026-10-05-m9-iocfat-provider.md`).

## 8. Acceptance matrix

```text
row                                                        status
1. production, FAT card: boot + optional `/` mount         PASS (byte-identical image, 30c bench run)
2. production, no card: `vfs: / unavailable 0x03` + usable PASS (byte-identical image, 30c bench run)
3. m9-selftest, card: full fstest transcript               OWNER-ACCEPTED (not bench-run; see below)
4. m8-fb-* fallback rows                                   OWNER-ACCEPTED (not bench-run; see below)
5. monitor launches from /SYSTEM on production             PASS (byte-identical image, 30c bench run)
---
host: make clean && make check                             PASS
host: every named acceptance target                        PASS
host: python3 -m unittest discover -s tests                PASS
sim : m9-selftest full acceptance + fault windows          PASS
sim : m9-vfs / m9-provider / m9-fs / m9-exec / m9-iocfat   PASS
budget: 32.39 targets (floor, 1 KiB slack, ceiling)        PASS
docs: architecture 35-42 (folded M10-M12), 34 closed       PASS
```

Physical rows 1-5 are "operator actions"; the exact commands, images,
hashes and serial settings are in
`2026-10-05-m9-filesystem-hw-transcript.txt`.  No physical result is
claimed: the bench produced no output during this package's probe (see that
file).

## 9. Architecture conformance pass (section 32.36)

33 invariants; one enforcement pointer each.  Nothing is unenforced except
where noted.

| # | invariant | enforced by |
| --- | --- | --- |
| 1 | VFS owns the global namespace | `kernel/vfs/{path,mount,file,dir,mutate}.c`; providers only ever see provider-relative paths |
| 2 | VFS initializes before dynamic module loading | `kernel/main.c` `kernel_boot_module()` order; `tests/test_m9_vfs_sim.py` boot transcript |
| 3 | static JSON mount topology compiled into an immutable kernel table | `tools/mountgen.py` + `tests/test_m9_vfs.py::TestMountgenAccepts/Rejects`; generated table is `const` |
| 4 | exactly one configured mount is the system filesystem | `mountgen.py` rule + the defensive recheck in `vfs_init()`; `tests/test_m9_vfs.py` |
| 5 | the system provider is statically available | `ZOS_VFS_BUILTIN := romfs`; `fs/romfs/romfs_provider.c`; `tests/test_m9_vfs.py::TestBuiltinProviderParity` |
| 6 | the system filesystem is instantiated before resident modules load | `kernel/main.c`; `tests/test_m9_vfs_sim.py` |
| 7 | boot assets are loaded through VFS after that | `kernel_load_vfs_module()`; `mapcheck --production` rejects the retired embedded catalog |
| 8 | no drive letters | `kernel/vfs/path.c` accepts only `/`-rooted native paths; `abi/zos/fs.h` has no drive field |
| 9 | path comparison is ASCII case-insensitive | `kernel/lib/name.c` `zos_ascii_equal`; `tests/test_source_layout.py::TestKernelNameComparison`; fstest/fsfat case cases |
| 10 | `ZOS_PATH_MAX = 128` | `abi/zos/fs.h` + `_Static_assert`; `tests/test_m9_fs.py` |
| 11 | `ZFS_NAME_MAX = 64` | `abi/zos/fs.h` + `_Static_assert`; `tests/test_m9_fs.py` |
| 12 | ROMFS is a provider mounted at `/SYSTEM` | `config/mounts.json` + `fs/romfs/romfs_provider.c`; `tests/test_m9_vfs.py` |
| 13 | the writable FAT filesystem is mounted at `/` | `config/mounts.json` (`iocfat` from `ioc.0`, optional) + `fs/iocfat/iocfat.c` |
| 14 | providers do not know their mountpoint | `include/zephyros/vfs.h` `zfs_ops` has no mountpoint parameter; `tests/test_m9_vfs.py::TestProviderAbiShape` |
| 15 | IOC is transport, not a filesystem/block API | `tests/test_iocfat.py::TestIocFatSourceLayout` (no raw I/O, no `drivers/ioc` include); `drivers/ioc/` unchanged by M9 |
| 16 | `ZDEV_STORAGE` renamed to `ZDEV_BLOCK` | `include/zephyros/device.h`; `tests/test_block.py::TestBlockClassRename` |
| 17 | `ZDEV_BLOCK` defined in M9, first driver deferred | `include/zephyros/block.h`; `tests/test_block.py`; `tests/test_source_layout.py::TestNoResidentBlockDriver` |
| 18 | IOC-FAT is a resident ZMOD provider registered with VFS | `modules/manifests/iocfat.json` + `fs/iocfat/iocfat.c`; `tests/test_iocfat.py::TestIocFatManifest` |
| 19 | MCU FatFs is one backend, not the architecture | same as 18: the provider lives behind `zfs_ops`, VFS has no FS2 knowledge |
| 20 | future VFAT/Fuzix may consume `ZDEV_BLOCK` directly | **no enforcement - no such code exists yet** (finding: expected; M9 only defines the class contract) |
| 21 | native I/O is path-, descriptor- and byte-oriented | `abi/zos/fs.h` + `kernel/syscall/fs.c`; `tests/test_m9_fs.py::TestFsArgumentBlocks` |
| 22 | one global owner-tagged pool of 8 descriptors | `kernel/vfs/process.c` + `_Static_assert`; `tests/test_m9_fs.py::TestDescriptorPoolShape` |
| 23 | both `CLOSE` and `SYNC` exist | syscalls `11h`/`1Fh`; `fsfat.zex` `basic` calls `zos_sync` |
| 24 | timestamp zero means unknown | `ZFS_TIME_UNKNOWN` in `abi/zos/fs.h`; both providers fill zero |
| 25 | metadata exposes type/attributes/size/ctime/mtime | `struct zfs_stat` + `_Static_assert`; `tests/test_m9_fs.py` |
| 26 | the FAT archive bit is not exposed | `ZFS_ATTR_*` has only READONLY/HIDDEN/SYSTEM; `fs/iocfat` maps no archive bit |
| 27 | caching is provider policy; VFS owns no cache | `kernel/vfs/` has no cache or generation state; `docs/vfs.md` section 5 |
| 28 | IOC-FAT keeps a write-through 512-byte-slot cache; ROMFS keeps none | `fs/iocfat` `iocfat_cache_*`; `tests/test_iocfat.py::test_every_cache_rule_is_present` |
| 29 | the cache slot count is build-time and reported | `IOCFAT_CACHE_SLOTS` + `#error`; the ledger's granule-threshold table (`tools/pack_image.py`, `tools/zmodpack.py`) |
| 30 | CP/M semantics stay in a later personality layer | no personality code in the tree; `tests/test_source_layout.py::TestOwnerLayout` |
| 31 | external-storage failure never removes `/SYSTEM` | `kernel/vfs/mount.c` optional-mount rule; absent-card replay in `tests/test_m9_selftest_sim.py` and physical row 2 |
| 32 | providers are path-based; VFS keeps no node objects | provider ABI shape tests; `docs/vfs.md` section 5; no `object_id` symbol in the kernel map |
| 33 | bank-7 residency is budgeted per package | `tools/mapcheck.py` area/symbol gates; the `bank7:`/`common:` ledgers from `pack_image.py` and `zmodpack.py`; `tests/test_pack_image.py` |

Invariant 20 is listed as a finding rather than given a mechanical check:
it describes future work, and there is no code to enforce it against.
Everything else is enforced by an existing check, and the cheap additions
this package made are the docs-evidence record scan (section 6) plus the
integration image's own simulator replay.

## 10. Validation commands run (once, frozen tree)

```sh
rm -rf build build-*
make                                   # pack: prints the ledger below
make clean && make                     # reproducibility of the ledger
make check                             # reproducible rebuild + host suite
make zmod-test romfs-test zex-test monitor-test ioc-test hid-test v9958-test \
     m8-selftest m8-fallback-selftests \
     m9-vfs-selftest m9-provider-selftest m9-fs-selftest m9-exec-selftest \
     m9-iocfat-selftest m9-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod build/modules/*.zex \
          build/recovery.romfs
sha256sum build-m9-selftest/zephyros-m9-selftest.bin \
          build-m9-iocfat-selftest/zephyros-m9-iocfat-selftest.bin
make clean && git status --short
```

Result: every build/validation command above exits 0 (`make check` prints
`check: reproducible rebuild (f4da0496…)`), `git diff --check` is silent,
and the hashes in sections 3 and 4 were re-captured from this run.  After
`make clean` no build directory is left and `git status --short` lists only
the package's source and documentation edits plus its new, deliberately
untracked files - the tree is clean.

Only the physical rows (section 8) remain unrun; the operator procedure,
including the image to rebuild (`make m9-selftest`) and its expected hash,
is in the sibling transcript file.

## 11. M9 closure (supervisor, 2026-10-06)

The project owner closed M9 and accepted the physical rows on this basis:

- **Rows 1, 2 and 5 passed on identical bytes.** The production image
  validated here (`f4da0496…`) is byte-identical to the image physically run
  in package 30c (`docs/validation/2026-10-05-m9-reclaim.md`): boot with a
  FAT card and a successful `/` mount, boot without a card with
  `vfs: / unavailable 0x03` and a usable console, and the monitor prompt on
  the V9958. No code changed after that run.
- **Rows 3 and 4 were accepted by the owner without a fresh bench run.**
  Row 3's image (`m9-selftest`, `2b1c89e6…`) was not run on hardware; the
  same IOC-FAT read/write/cache/directory paths passed physically in package
  30's row 3 (`m9-iocfat-selftest`). Row 4's M8 fallback images were not
  re-run on hardware after M8; their simulator replays pass, and package 32
  retires them under the Mn-1 rule.

No physical result is claimed beyond what is stated here.
