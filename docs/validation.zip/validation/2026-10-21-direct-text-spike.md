# Direct-text spike

## Result

What a direct-write text renderer (font in CPU RAM, glyph bytes written
to VRAM through the data port, the SymbOS method) would gain over the
console's HMMM renderer, on the same realistic text.  Four renderers
were written as a user program (so their size is free here) and
measured in the simulator beside the console baseline; each renders
the `con.mixed` text (2,000 characters of `ls -l`-style lines) from a
cleared screen at home, with the full text model (CR, LF, wrap at 85,
scrolling exactly as the console does it).  After every direct row the
page-zero bitmap equals the `txt.console` row's screen, cell for cell
(checked on the production image by a structural test).  No production
code changed; the production image is byte-identical.

Simulator CPU-only, T-states per character:

| row | T/char | vs console |
|---|---:|---:|
| txt.console (baseline) | 4,646 | - |
| txt.glyph1 | 3,367 | 0.72x |
| txt.glyph6 | 2,798 | 0.60x |
| txt.run1 | 2,792 | 0.60x |
| txt.run6 | 2,392 | 0.51x |

The direct rows cost 28-49% less CPU than the console row.  The gap is
the console's command setup and CE-wait path (package 76 profile:
3,318 of 3,782 T-states on `con.mixed`); a direct renderer replaces
those with three plain `OUT (A0h)` per glyph scanline.

## Files

- `tests/bench/textbench.c` - the program, built as
  `/system/textbench.exe` beside `iobench.exe`.  The same mixed-text
  generator and timer instrument as `iobench`, console-exact
  clear/scroll helpers in C, and one row per mode.  One-row mode
  renders (measured, still holding the VDP), then waits for a key in
  `console_read` before unbinding and printing its row line - the
  replay snapshots the still-held clean screen at that entry; the
  no-argument run does all five rows and prints the closing summary.
- `tests/bench/textbench_render.asm` - the four renderers plus the
  shared model block (text pointer and count, newline/scroll through
  the C helper, the working address cell, and the page-aware address
  set: the V9958's 17-bit address splits across R#14 (A16:A14) and the
  command-port pair (A13:A0), so the page `y >> 6` is written to R#14
  when it changes).
- `tests/bench/font2c.py` - generates the font header for the program
  from the pinned `font_cp850_6x8.inc` through `fontpack` (single
  source of truth).
- `tests/test_textbench.py` - the acceptance test on the production
  image: splices `textbench.exe` into the store, boots once, runs each
  row, compares pixels and checks the sizes and row-line shapes.
- `Makefile` - the `textbench` build rule and the generated-header
  rule.

## How it was measured

- The simulator (`V9958Peer`) models neither the V9958's WAIT nor its
  access slots, and its command busy is 400 instructions.  Its
  CPU-side figures are exact; the board supplies the wait.  The bench
  subtracts its own instrument: each row's two clock readings, minus
  the calibration loop's reading cost (11,686 T-states for two
  readings, as in package 76).
- `textbench.exe` is 12,034 bytes (sha256
  `d82da3a6f48d8906a31be47c8e8ce8bf8d41119e735297e6d53f92b458f156902`);
  it loads in the production image (the replay runs it).
- The console row reports its eight 256-byte writes (`ops 8`); the
  direct rows report their 2,000 characters.  Per-character figures
  below are the row total divided by the row's bytes.

## Per-row table

| row | simulator CPU T/char | board T/char | wait (board - sim) | chars/s at 10 MHz (sim) | full 85 x 26 screen at 10 MHz |
|---|---:|---:|---:|---:|---:|
| txt.console | 4,646 | 3,782 (package 76 `con.mixed`) | -844 | 2,152 | 1.027 s |
| txt.glyph1 | 3,367 | PENDING | PENDING | 2,970 | 0.744 s |
| txt.glyph6 | 2,798 | PENDING | PENDING | 3,574 | 0.618 s |
| txt.run1 | 2,792 | PENDING | PENDING | 3,582 | 0.617 s |
| txt.run6 | 2,392 | PENDING | PENDING | 4,181 | 0.529 s |

The board column is PENDING until the owner runs `textbench` on the
board (checklist below); `txt.console` is the same text through the
same path as package 76's `con.mixed`, whose board figure is quoted as
the baseline.  The negative wait on the baseline row says the
simulator's flat 400-instruction command-busy charge overestimates the
real HMMM/HMMV command time for these fills; the direct rows carry no
commands, so their board cost will be the sim figure plus the real
data-port wait.

## Renderer sizes (link map)

What the driver tier would carry if one renderer moved in:

| part | bytes |
|---|---:|
| glyph1 renderer code | 56 |
| glyph6 renderer code | 56 |
| run1 renderer code | 125 |
| run6 renderer code | 125 |
| shared model block (any renderer) | 117 |
| font image (CPU RAM) | 2,048 |
| expand table (BSS, built at run time) | 192 |
| pre-coloured font (BSS, built at run time) | 6,144 |

Per renderer: glyph1 = 2,413 bytes (code + shared + expand + font),
glyph6 = 6,317 (code + shared + pre-coloured font), run1 = 2,482,
run6 = 6,386.  The expand table and the pre-coloured font are built at
run time (the `_GSINIT` trap, package 76 record); only the 2,048-byte
font image is a static image.

## Same-pixels evidence

`tests/test_textbench.py` splices `textbench.exe` into the production
store and, per row, snapshots the page-zero VRAM at the row's
`console_read` wait.  The peer records HMMM commands but does not
apply them to VRAM, so the console row's screen is decoded from its
command stream (with a fixed final R#23 origin - the peer does not
model content scrolling during rendering); the direct rows' screen is
the peer's VRAM itself, which their data-port writes and HMMV fills
executed into.  Both sides expand to pixels through the console's pair
table (44/4F/F4/FF) and are compared cell for cell across the full
85 x 26 screen.  All four direct rows equal the console row exactly.

Two renderer bugs surfaced in this check and were fixed before it
passed: glyph6 kept its OUTI source pointer in HL, which the shared
address-set helper clobbers (raw text bytes landed in VRAM) - now
preserved across the helper; the run flushes zeroed the run length
before reading it as the glyph count (B=0, `djnz` 256 times) - the
length now survives the flush.

## Production unchanged

- Baseline: HEAD `de3bf64` at start, unchanged (no commit).
- `git diff --stat` shows only the `Makefile` build rule, `tests/`
  and this record (packages 74 and 76 files are also dirty in the
  tree, uncommitted by instruction).
- The production image hash is unchanged:
  `f3e9e5796e841955c76419550a93d4a2957ee8989c918754e5cf30576404521d`.
- Validation: `make` then
  `python3 -m unittest tests.test_textbench tests.test_io_sim
  tests.test_source_layout` - 57 tests, 0 failures; `git diff --check`
  clean.  `make clean && make check` was waived by the owner
  (production code is unchanged).

## Owner checklist

- Copy the image and `textbench.exe` to the card; run `textbench` at
  the shell prompt; photograph the summary.  Run it twice.  The board
  column of the per-row table is PENDING until then.

## Board results and supervisor review (2026-10-21)

Owner's board summary, T-states per character:

| row | simulator CPU | board | wait (board − sim) | chars/s (board) |
|---|---:|---:|---:|---:|
| txt.console | 4,646 | 3,583 | (model) | 2,790 |
| txt.glyph1 | 3,367 | 4,094 | 727 | 2,440 |
| txt.glyph6 | 2,798 | 3,589 | 791 | 2,790 |
| txt.run1 | 2,792 | 3,357 | 565 | 2,980 |
| txt.run6 | 2,392 | 2,976 | 584 | 3,360 |

Accepted as a measurement. The V9958 wait is now measured: 565-791
T-states per character (24 data writes, about 24-33 T-states each), the
hardware floor of any direct renderer. The CPU side is not the method's:
`flush_run6` recomputes `font6 + ch*24 + scan*3` for every glyph on every
scanline (about 300 T-states per glyph-scanline, 8 per character, which is
the 2,392 measured). A font laid out scanline-major in 256-byte pages (one
page per output byte per scanline, so the glyph code is the low address
byte) removes the arithmetic: about 100 T-states per glyph-scanline, about
800 per character, before the wait.
