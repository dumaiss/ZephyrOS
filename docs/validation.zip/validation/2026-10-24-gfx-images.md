# GFX images (streaming upload, palette, KIMG v1, kimg.py, pview)

## Result

The image pieces are in: `gfx_upload_begin`/`gfx_upload_write`/
`gfx_upload_end` (direct data-port streaming, the position kept across
calls, one VRAM address per row or one for a full-width rectangle, the
exact byte count enforced, not nestable), `gfx_set_palette` (8-bit RGB
to the V9958's 3-bit values under WAIT, `-KOS_ENOTSUP` outside the
16-colour mode), the KIMG v1 header (`kos/kimg.h`, shipped), the host
converter `tools/kimg.py` (Pillow: scale/crop, G6 median-cut palette
and nibble packing, G7 RGB332, YJK against Y = 24), committed
`tests/gfx/fixtures/` (the two parrot PNGs and their 64x32 G6/G7/YJK
conversions), and `UserSoftware/PView` (the standalone-SDK viewer that
reads in 4 KiB blocks and refuses a bad header without touching the
display).  Two backend bugs found and fixed in the replay work: the
stream's remainder path returned without writing (a stale Z flag), and
`set_vram` read the offset from the wrong register pair (the
sdcccall(0) (u8, u16) convention is A, DE).

Validated with the package's named batch, then `make clean && make
check` (reproducible rebuild, the full 912-test suite, mapcheck, pack
checks) — all green.  The board runs are PENDING: no hardware in this
session; the full-screen G7/YJK parrot conversions for the owner's
board sit in `work/84-gfx-images/` (Parrot-full-g7.kimg,
Parrot-full-yjk.kimg).

## Files

- `user/sdk/gfx/src/gfx_upload.c` - the upload engine: geometry
  validation (y 0-511, G6 x/width even), `bytes(width, height)` in the
  mode's packing, one address per row (one for full-width), the
  short/overlong refusals with no half state, the nested-begin refusal.
- `user/sdk/gfx/src/gfx_palette.c` - `gfx_set_palette`: handle/mode
  checks, `-KOS_ENOTSUP` outside G6, count 0 as a no-op, range checks.
- `user/sdk/include/kos/gfx.h` - `struct gfx_rgb`,
  `gfx_set_palette`, `gfx_upload_begin`/`write`/`end` declarations.
- `user/sdk/include/kos/kimg.h` - the KIMG v1 header: the field
  table, the magic/version/flags/size constants, `struct kimg_header`
  with SDCC `_Static_assert`s (16 packed bytes, the offsets).
- `user/sdk/gfx/src/gfx_internal.h` - the upload state fields
  (active, full-width, addressed, page, row, column byte, row bytes,
  row left, remaining), the port externs, `GFX_V9958_REG_R16` and the
  YJK luminance constants.
- `user/sdk/gfx/src/backends/v9958/v9958_io.asm` - `set_vram` (R#14 =
  A16..A14, the two address bytes; offset in DE per the ABI),
  `stream_vram` (256-byte blocks, WAIT-paced OUTs; the remainder path
  tests L with `or a` before its return), `palette_byte`; the four
  ports in BSS.
- `user/sdk/gfx/src/backends/v9958/v9958_gfx.c` - the YJK mode's
  shared luminance in palette entry 0, `v9958_set_palette`
  ((R3 << 4) | B3 then G3 per entry, R#16 selection).
- `user/sdk/exe.mk` - `gfx_upload.c` and `gfx_palette.c` as libgfx
  members.
- `tools/kimg.py` - the converter (g6/g7/yjk packing, `convert` and
  `info`, `--size`); Pillow is not a build dependency.
- `tools/sdkpack.py` - `kimg.py` in `TOOL_FILES`.
- `Makefile` - `tools/kimg.py` in `SDK_INPUTS`.
- `UserSoftware/PView/` - the standalone-SDK viewer: `Makefile`
  (KonaCommander pattern, `LIBS=gfx`, `test` builds the host
  `test_kimg`), `src/pview.c` (open, read/validate the header first -
  a bad one prints and exits before `gfx_open` - mode, palette,
  centred upload in 4 KiB blocks, display on, key, close),
  `src/pview_kimg.h`/`src/pview_kimg.c` (the raw-byte header
  validator shared with the host test), `tests/test_kimg.c` (the
  validator over raw header bytes: magic/version/flags/mode/geometry/
  payload-size cases).
- `tests/gfx/gfxtest.c` - `upload` (four rectangles in chunk sizes 1,
  7, 256 and 4096, the short/overlong/nested refusals, each failure
  printed after the release) and `palette` (three G6 entries, a key,
  the G7 refusal, a key).
- `tests/gfx/fixtures/` - `Parrot_VGA_256_palette.png`,
  `Parrot_VGA_mono_palette.png`, and their 64x32 conversions
  `parrot-64x32-g6.kimg` (16-entry palette, 1024-byte payload),
  `parrot-64x32-g7.kimg` and `parrot-64x32-yjk.kimg` (2048-byte
  payloads), all converter-produced and deterministic.
- `tests/test_gfx.py` - the host pins (the public surface declares the
  upload/palette API, exe.mk builds the members, the asm exports the
  port helpers) and the production replays: the upload (the four
  rectangles' VRAM bytes checked at the release, the refused streams'
  traces, the result line, the restored console), the palette (the
  three peer entries while held, no palette-port write for the G7
  refusal), and pview (the g7 and g6 pictures centred on the peer's
  VRAM with the g6 palette applied, the restored console after each,
  and a bad header leaving only console WRITE renders - no ACQUIRE,
  DIRECT_INFO or RELEASE).
- `tests/test_kimg.py` - the header pins (layout, constants, static
  asserts), the fixture parse, and the Pillow-gated converter tests
  (RGB332, YJK J/K, G6 palette + packed indices, determinism, bad
  geometry, the `info` subcommand).
- `tests/test_sdk_package.py` - `include/kos/kimg.h` and
  `tools/kimg.py` in the golden layout.
- `tests/test_source_layout.py` - the new gfx sources, `kos/kimg.h`,
  `tools/kimg.py`, `tests/test_kimg.py` in `OWNER_FILES`.
- Docs: `docs/sdk.md` (the upload/palette API, KIMG and the converter,
  the gfx layout entries, the what-links-what rows, the standalone
  SDK's tools line).  `docs/gfx-sdk.md` is the design and is
  unchanged.

## Requirement results

1. **Upload.** The replay streams chunk sizes 1, 7, 256 and 4,096
   across four rectangles (a full-width page-1 strip, two partial
   rows, a full-width page-0 strip): every VRAM byte equals the
   payload, including the off-screen page (y 256-511).  A short
   stream (`end` with bytes missing) and a write past the end are
   `-KOS_EINVAL` (`gfxtest: upload -2 -2 -2`), the overlong chunk is
   refused whole, and a nested `begin` is refused; the nested/refused
   streams leave no half state (the VRAM traces are pinned).
2. **Palette.** The replay reads the peer's entries while the display
   is held: (00,00,FF) -> [07,00], (FF,00,00) -> [70,00],
   (00,80,00) -> [00,04], with R#16 ending on the last entry.  In G7
   the call is `-KOS_ENOTSUP` (`gfxtest: palette -7`) with no palette
   port write at all.
3. **KIMG v1.** `kos/kimg.h` pins the 16-byte layout (`_Static_assert`
   size and offsets), the magic/version/flags constants; it ships in
   the SDK.
4. **Converter.** `tools/kimg.py` converts PNG to g6/g7/yjk: the tests
   parse the output byte for byte (RGB332, YJK J/K against Y = 24, the
   G6 palette and nibble packing), conversions are deterministic, bad
   geometry refuses, and `info` reports the header.  The tests skip
   without Pillow.
5. **Fixtures.** The two PNGs and the three 64x32 conversions are
   committed under `tests/gfx/fixtures/`; `tests/test_kimg.py` parses
   them against the format.
6. **pview.** `make -C UserSoftware/PView test` builds the viewer from
   the repacked SDK and runs the host `test_kimg` (PASS).  The
   production replay runs pview on card copies of the fixtures (the
   card is 8.3, so the on-card names use the .img extension): the
   centred picture lands on the peer's VRAM with the g6 palette
   applied, a key restores the console, and a bad header prints the
   error with no VIDEO dispatch beyond the console's own renders.
7. **Docs.** As listed; `git diff -U0` writing check prints nothing.

## Budgets

Package 84 changes no driver code: the v9958 driver hot image stays
6,468 bytes (ledger 30,995 / 32,768, 1,773 free), the reserve held.
The new port code is libgfx's user-side backend, paid by programs that
call the upload/palette entry points.

## Validation

```sh
make && make sdk && make -C UserSoftware/PView test   # test_kimg: PASS
python3 -m unittest tests.test_gfx tests.test_kimg tests.test_sdk_package tests.test_source_layout
# 87 tests, OK
make clean && make check   # once, at the end
git diff --check
```

`make check`: reproducible rebuild confirmed (image sha256
`813aba6fc8bfc380ca0510fb50525a630208afef7c35207c20b047abeaf57519`,
unchanged - package 84 adds no OS bytes), the full suite ran 912 tests
in 290.0 s, OK, mapcheck and the pack checks passed, and the
konaos.bin/zephyr80.bin copies compare equal.  Zero failures, zero
errors.

Artifacts: `build/user/gfxtest.exe` sha256
`415b6126424c52bdbdd6e1713693f5796610eee2eb72e88e6d8d9c2ee4677b4b`;
`UserSoftware/PView/build/user/pview.exe` sha256
`61ee08ff037457b858fe808b0dbee8fcec05ee636abaeb0a8701166b7a45b249`.

## Pins changed

- `tests/test_sdk_package.py`: the golden `SDK_FILES` set gains
  `include/kos/kimg.h` and `tools/kimg.py` (source: the package's own
  sdkpack change).
- `tests/test_source_layout.py`: the new gfx sources, `kos/kimg.h`,
  `tools/kimg.py` and `tests/test_kimg.py` in `OWNER_FILES` (source:
  the package's own files).
- `tests/test_gfx.py`: the new replay tests and host pins; the
  existing mode/info/leak tests are unchanged and still pass.

## Found outside scope

- `UserSoftware/KonaEdit/` files were modified by parallel work in the
  shared tree; they are preserved untouched and unclassified here.
- `docs/kres-sdk-design.md` is an untracked unrelated draft; left as
  is.

## Preserved

- The mode register sets, the clear, the release path and the console
  restore are untouched; the package 83 tests all pass.
- The console, TUI, tee, sound and vblank replays all pass unchanged.
- The reproducer: `make clean && make check`'s rebuild hash matches.

## Pending

- Hardware: run `pview` on the board with the full-screen pictures
  (`work/84-gfx-images/Parrot-full-g7.kimg` and
  `Parrot-full-yjk.kimg`, copied to the card under 8.3 names):
  `pview /fs/<picture>.img`, a key, the console back.  Optionally
  `gfxtest upload` and `gfxtest palette` (a key each, the console
  back).

## Correction 1 (supervisor review and board findings)

Two converter defects, plus a `pview` defect from the board. None could
fail a test: the simulator stores VRAM bytes without decoding colour,
and the converter tests checked the converter against its own
conventions.

- **G7 packing:**
  - **The defect:** `tools/kimg.py` packed red in bits 7-5. The V9958's
    GRAPHIC 7 byte is green 7-5, red 4-2, blue 1-0, as the board showed:
    fill 1Ch is red. Package 84 said "RGB332", the source of the error.
  - **The fix:** the converter packs green-red-blue.
- **YJK encoding:**
  - **The defect:** `kimg.py` encoded J/K in every byte against a fixed
    Y = 24, and the backend wrote palette entry 0 as a "shared
    luminance". The real format:
    - each byte's bits 7-3 are its pixel's own 5-bit Y;
    - each four-pixel run shares K (bits 2-0 of bytes 1-2) and J (bytes
      3-4), signed 6-bit;
    - the chip shows R = Y + J, G = Y + K, B = (5Y - 2J - K) / 4.
  - **The fix:** the converter encodes J/K from each run's average
    colour and fits each pixel's Y. The palette write and the Y
    constants are gone.
  - **Alignment:** YJK uploads require x and width in multiples of 4,
    `pview` centres to that, and its header check refuses a YJK width
    that isn't one.
- **pview cleared nothing:**
  - **The defect:** on the board the console's bitmap showed around the
    picture.
  - **The fix:** `pview` clears both pages before the upload, to byte 0
    (black) in G7/YJK and to the palette's darkest entry in G6.
- **Simulator model** (found by the new clear check): `V9958Peer`'s
  HMMV/HMMM divided dots by two in every mode. They now use the mode's
  dots per byte from R#0's M5-M3: one in GRAPHIC 7, two in GRAPHIC 6
  (V9958 Technical Data Book, the high-speed commands). Package 83's
  clear test had checked only half a G7 row; it checks the full 256
  bytes.
- **Tests:**
  - `tests/test_kimg.py` decodes the converter's output with the chip's
    formulas (its own decoder): the G7 byte, YJK solid colours within
    one 5-bit step, a YJK gradient round trip, and the YJK width rule;
  - `tests/test_gfx.py` asserts that the whole visible page around each
    `pview` picture holds the clear value. It fails without the clear
    ("g7: row 0 not cleared");
  - `UserSoftware/PView/tests/test_kimg.c` refuses a 62-wide YJK header.
- **Fixtures:** `parrot-64x32-g7.kimg` and `-yjk.kimg` are regenerated;
  G6 is unchanged, byte for byte. The full-screen board pictures in
  `work/84-gfx-images/` are regenerated too. Their decodes were viewed
  as PNGs and look right.
- **Docs:** `docs/sdk.md` gives the three packings; `kos/gfx.h` gives the
  YJK alignment.
- **Validation:**
  - `tests.test_gfx` / `test_kimg` / `test_sdk_package` /
    `test_source_layout`: 89 OK;
  - PView `test_kimg`: PASS;
  - `make clean && make check`: 914 OK, 119 skipped, the rebuild hash
    unchanged (`813aba6f...`).
