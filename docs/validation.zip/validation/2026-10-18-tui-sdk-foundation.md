# TUI SDK foundation: validation

## Result

The TUI SDK is a separately linked component.  `user/sdk/include/tui.h`
carries the complete v1 core surface with the architecture's key, style and
frame values.  `libtui.lib` holds the foundation members `tui_state`,
`tui_lifecycle` and `tui_flush`; `LIBS=tui` links the archive after the
program objects and before `libkos`.  The standalone SDK ships the header and
the archive, and the package tooling pins both.

`tui_test.exe` passed on the production V9958/HID console and on the
`console-serial` build in the simulator.  On the serial lane the exact
lifecycle bytes were:

```text
ESC[0m ESC[2J ESC[H ESC[?25h  tui: foundation
ESC[0m ESC[?25h               (shutdown)
ESC[0m ESC[2J ESC[H ESC[?25h  (restart)
ESC[0m ESC[?25h               tui: PASS
```

The production run reached `tui: PASS` through the same library.

## Files

Added:

- `user/sdk/include/tui.h`
- `user/sdk/tui/src/tui_internal.h`
- `user/sdk/tui/src/tui_state.c`
- `user/sdk/tui/src/tui_lifecycle.c`
- `user/sdk/tui/src/tui_flush.c`
- `tests/tui/tui_test.c`
- `tests/tui/out_of_tree/Makefile`
- `tests/tui/out_of_tree/out_of_tree.c`
- `tests/test_tui.py`
- this record

Changed:

- `Makefile`: the `tui_test` program and the TUI archive in the SDK package.
- `mk/kos.mk`: the generic `LIBS=` option and its link order.
- `user/sdk/exe.mk`: the in-tree `libtui` object and deterministic archive
  rules.
- `tools/sdkpack.py`: `include/tui.h` and `lib/libtui.lib` in the tree.
- `tests/test_sdk.py`, `tests/test_sdk_package.py`,
  `tests/test_source_layout.py`: the program inventory, package layout,
  archive metadata and owner list.
- `docs/sdk.md`: the `LIBS=` option and the shipped tree.

`docs/konaos-tui-sdk-architecture.md` is an untracked user file and is
unchanged.  No unrelated working-tree changes were present.

## Library and program sizes

```text
libtui.lib                 3,788 bytes
  tui_state.rel              456 bytes
  tui_lifecycle.rel        1,768 bytes
  tui_flush.rel            1,084 bytes

tui_test.exe               5,704 bytes (EXE file)
  image_size               5,668 bytes
  bss_size                   299 bytes
  stack_size                 256 bytes
  entry_offset                93 bytes

hello.exe                  4,846 bytes (EXE file)
  image_size               4,810 bytes
  bss_size                   295 bytes
```

`hello.exe` links no `tui_*` member or symbol and has no TUI BSS.  The
`tui_test.exe` BSS is 4 bytes above `hello.exe`: the static `tui_state`
object.  `libtui.lib` is packed with `sdar -rcD`; every member carries a zero
date and zero uid/gid.

Hashes:

```text
7860a3bb555b6a0a5d29ee6685b719116534fccf6d215c8178c63eed336ca56f  build/user/sdk/libtui.lib
d72e56dbe29efde75335dddabfa29574571463ee5b81a674ca8cbab6c799cee2  build/user/tui_test.exe
786ccf9719cffbf9aa7983008e8a9a365b88a8bf4a67519f210cee52d2a9ec7d  build/user/hello.exe
```

## Commands

```sh
make build/user/tui_test.exe build/user/hello.exe sdk
python3 -m unittest tests.test_tui tests.test_sdk tests.test_sdk_package -v -v
git diff --check
```

Results:

- The build produced `build/user/tui_test.exe`, `build/user/hello.exe` and
  `build/kos-sdk-0.1.0.tar.gz` (48 files) with no warnings.
- The suite ran 49 tests in 56.678 s: 48 passed, 1 skipped, 0 failed.  The
  skip is `tests.test_sdk.TestHelloWorldImage`, whose `build-helloworld`
  image is outside this package's build set.
- `git diff --check` reported nothing.

A clean-room build with `BUILD=build-tui-check` produced the same programs
and tarball, proving the new archive rule does not depend on incremental
state.  The directory was removed afterwards.

Extra check, because the package edits the owner lists:
`python3 -m unittest tests.test_source_layout -v` ran 52 tests, all passed.

## Simulator acceptance

`tui_test.exe` was injected into the recovery store of both existing console
images and run as `/system/tui_test.exe` from the shell:

- `build/konaos.bin` (V9958/HID): reached `tui: PASS`.
- `build-console-serial-selftest/konaos-console-serial-selftest.bin`
  (`console-serial`): the serial lane carried the init, foundation marker,
  shutdown, restart and final shutdown sequences, then `tui: PASS`, followed
  by the shell prompt.

Both replays were ad-hoc checks; the package test file remains the host and
static suite, and the replay suite belongs to the screen-engine package.

## Deviations and pending work

None.  The screen map, text drawing, cursor/window operations, key decoder,
save/restore and widgets remain unimplemented declarations, as required; the
header exists before its later archive members.

## Supervisor review

Accepted 2026-10-18. The supervisor independently ran:

```sh
make build/user/tui_test.exe build/user/hello.exe sdk
python3 -m unittest tests.test_tui tests.test_sdk \
    tests.test_sdk_package tests.test_source_layout
git diff --check
```

The combined suite ran 101 tests: 100 passed, the pre-existing helloworld
image test skipped because that optional image was not built, and none failed.
The supervisor also injected the final `tui_test.exe` into both existing
console images. The production V9958/HID route reached `tui: PASS`; the serial
route emitted both init sequences and both normal/show-cursor shutdown
sequences, then reached `tui: PASS`.
