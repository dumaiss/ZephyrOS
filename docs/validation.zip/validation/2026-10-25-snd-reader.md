# Validation - snd-reader (package 99)

Date: 2026-10-25

## Scope

Package 99: the shared read-at view `kos/reader.h` and its four
adapters, in libkos (memory, handle, stdio, read_full) and libkres
(kres_reader).  No OS change.

## Files

Added:

- user/sdk/include/kos/reader.h - `kos_reader_t` (context, read_at,
  size), the source descriptors and the four constructors plus
  `kos_reader_read_full`
- user/sdk/src/reader.c - the memory adapter (own member)
- user/sdk/src/reader_full.c - complete-range reads with retry (own
  member)
- user/sdk/src/reader_handle.c - the OS handle adapter (seek + read,
  size from a seek to the end)
- user/sdk/src/reader_stdio.c - the `FILE *` adapter (fseek + fread,
  size from fseek/ftell)
- user/sdk/kres/src/kres_reader.c - the KRES adapter in libkres
  (kres_seek + kres_read, size = used_bytes)
- tests/reader/readertest.c - the card program: the same fixture
  through all four adapters, matching checksums, 128 random probes
  including past the end, the sources alive after the readers are
  dropped, and the framed per-call timing report
- tests/reader/readermap.c - the memory-adapter-only link proof
- tests/reader/host/host_reader.c and host/include/* - the host test
  of the memory adapter and read_full against a fake reader
- tests/reader/fixtures/card.dat (1,024 bytes, sha256
  8ab783947bae918d01b74448625dfd0fef119e16e97d6fc9fdf15e310c87cb01) and
  reader.kpr (sealed container holding card.dat, sha256
  3fabfac55a61e22c5321beaf35405cbd9ce21eedb4690f464fa6f3dc202164f6)
- tests/test_reader.py - the package's test module (8 tests)
- docs/validation/2026-10-25-snd-reader.md

Changed:

- Makefile - the readertest and readermap exe_program declarations
- user/sdk/exe.mk - the four libkos members, kres_reader in
  KOS_KRES_C_SRC, kos/reader.h in KOS_KRES_PUBLIC
- docs/sdk.md - the reader section (ownership, per-adapter linking)
- docs/snd-sdk.md - 3.4 now describes the shipped interface, and the
  header lines drop "proposed"
- tests/test_source_layout.py - the new files in OWNER_FILES and
  tests/reader in REQUIRED_DIRS
- tests/test_sdk_package.py - reader.h in the pinned layout

## Results

- `make`: readertest.exe (24,328 bytes) and readermap.exe (5,481
  bytes) pack and validate.
- `python3 -m unittest tests.test_reader`: 8/8 - fixture digests and
  the sealed container's byte identity, the host fake-reader test,
  the four adapters' matching checksums and probes, one FS2 open per
  source with none by an adapter, the sources alive after use, the
  memory-only link proof, and the framed timing report.
- `python3 -m unittest tests.test_sdk_package`: 14/14.
- `python3 -m unittest tests.test_source_layout`: 52/52.
- `git diff --check`: clean.

## Budgets

| figure | this package | note |
|---|---|---|
| OS bytes | 0 | no kernel, driver or OS change |
| adapter member sizes | memory 150h, read_full 15Ch, handle C8h, stdio C1h, kres 98h bytes of CODE | report |
| read_at per call (T-states) | handle 38,942; stdio 156,048; kres 45,251; memory 2,640 | measured with the framed timing run, an empty-loop baseline subtracted; the file-backed numbers are dominated by the provider round trips, the memory adapter is the bounds check and the memcpy |

## Notes

- The FS2 provider serves two open files, so readertest runs in two
  phases (handle+stdio+memory, then KRES after the card slots free);
  the open-count test pins exactly the exe, two CARD.DAT opens and one
  READER.KPR open.
- The 8.3 card names are RDRTEST.EXE and RDRMAP.EXE (the build targets
  keep their long names).
- Unrelated changes (UserSoftware/DonkeyKong Makefile and its SDK
  tarball, docs/snd-sdk.md) were preserved.
