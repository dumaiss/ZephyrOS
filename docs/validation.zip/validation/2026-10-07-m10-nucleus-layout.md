# M10 nucleus layout (package 38): validation record

Date: 2026-10-07.  Work package:
[WORK.md](../../work/38-m10-nucleus-layout/WORK.md).

Scope: link the production nucleus as a **fixed core** (`2000h-5FFFh`,
16 KiB) plus a **cold half** (`6000h-DFFFh`, 32 KiB) under decoder
revision 13, make every gate normalize the page field P, add the fixed
**upcall shim**, replace the M9 `bank7:` budget with the five ledgers of
architecture 36.20, and enforce the placement in `tools/mapcheck.py`.  No
feature is added: the same boot, console and filesystem as M9.

## 1. Result

**Accepted.**  The production image builds reproducibly, every placement
rule and every ledger is emitted and within budget, the gates normalize P
and restore the latch exactly, the upcall shim exists and is exercised,
and the M9 acceptance set (M9 filesystem, console integration) plus the
resident-service spike still pass.

| item | value |
|---|---|
| production image | `build/zephyros.bin` = `build/zephyr80.bin`, `sha256 d017f133b43d8821b20d1547b3c2c7c0a1713b936b5eb41b8df8a467c3e7d33f` |
| M9 baseline image (HEAD) | `sha256 f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7` (`build/zephyros.bin` of a HEAD worktree) |
| geometry | fixed code end `53DEh`, fixed data base `5600h` (1359 B), service stack `5D00h-5F00h`, ISR stack `5F00h-6000h`, cold code end `99E6h`, arena `9A00h-DBFFh` (33 granules), cold data base `DC00h` (892 B) |

The image bytes change (the code layout, the derived bases and the
upcall shim are new); the M9 behaviour is unchanged.

## 2. The five ledger lines

Production (`tools/pack_image.py`; the same lines come from
`tools/zmodpack.py plan`, and both carry them as `manifest["nucleus"]` /
`arena.plan.json["nucleus"]`):

```text
nucleus fixed: required 3746 bytes | overflow 10891 bytes | stacks 768 | room 979 bytes
nucleus cold: code 14822 bytes end 99E6h | arena 33 granules (33 boot, 0 free) | data 892 bytes at DC00h | room 158 bytes
service hot: 0 bytes of 32768
service boot/bulk: 0 bytes of 24576
common: used 2106 of 7424 bytes (code 1412, data 694) | ceiling 3072, m10 512, limit 2560
```

- `nucleus fixed:` 3,746 required + 10,891 overflow + 768 stacks =
  15,405 of 16,384 bytes, 979 bytes of room.  `required` is the linked
  content of the `fixed-required` objects, `overflow` everything else
  that had to link there (the objects stages 4-5 will move to bank 6),
  `stacks` the service stack (512) plus the ISR stack (256).
- `nucleus cold:` 14,822 code + 892 data + 33 arena granules (16,896) =
  32,610 of 32,768 bytes, 158 bytes of room.  The boot set (sio 1, ioc 8,
  hid 2, v9958 9, iocfat 13) fits with 0 free granules.
- `service hot:`/`service boot/bulk:` the bank-6 tiers of 36.6.  Nothing
  is placed there before stage 4, so both are 0 against their 32 KiB and
  24 KiB capacities; the lines exist so the budget cannot be lost.
- `common:` 2,106 of 7,424 bytes against the 3,072-byte ceiling with the
  512-byte M10 reservation held back (limit 2,560).  The gate-stack worst
  case is still reported per image (213 of 256 bytes for the M9 image).

Acceptance images, same format, showing the overflow moving into the test
objects:

```text
# build-nucleus-selftest
nucleus fixed: required 3746 bytes | overflow 11225 bytes | stacks 768 | room 645 bytes
nucleus cold: code 15544 bytes end 9CB8h | arena 31 granules (1 boot, 30 free) | data 892 bytes at DC00h | room 460 bytes
# build-m9-selftest
nucleus fixed: required 3746 bytes | overflow 10931 bytes | stacks 768 | room 939 bytes
nucleus cold: code 16648 bytes end A108h | arena 27 granules (22 boot, 5 free) | data 1956 bytes at D800h | room 340 bytes
# build-rsvc-spike-6000 (its own package-36 evaluation placement)
nucleus fixed: required 7335 bytes | overflow 0 bytes | stacks 768 | room 8281 bytes
nucleus cold: code 27046 bytes end C9A6h | arena 6 granules (1 boot, 5 free) | data 2174 bytes at D600h | room 476 bytes
```

The 32-granule production floor is retired: the arena only has to hold the
declared boot set, which `zmodpack plan` and `pack_image.py` enforce (the
production boot set happens to need 33 granules, the M9 count).

## 3. Placement enforcement

`tools/mapcheck.py --residency config/residency.json --boot-plan
build/arena.plan.json` fails the build when an object is missing from the
classification, when a `fixed-required` object lies at or above `6000h`,
when a linked area disagrees with its region, when either derived base
moves, or when the declared boot set does not fit the derived arena.
`config/residency.json` classifies all 41 production objects
(`fixed-required` 20 including the new `upcall`, `cold` 11, `moves` 10 with
their stage), and the cold-half codegen (`--codeseg WINDOW --dataseg
WINDOW_DATA`) is driven from it.  `make check` also re-derives the geometry
twice and compares the images byte-for-byte.

`tests/test_driver_abi.py::TestResidency` pins the rules: the production
classification must cover `linker/zephyr80.lk`'s object list exactly, the
linked production objects must agree with it, a `fixed-required` object
compiling into the cold areas fails, a `cold_half` object compiling into
the fixed areas fails, an object compiling cold without being in
`cold_half` fails, a `moves` entry needs its stage, and a cold-tier object
left in the fixed core is allowed (it is the ledger's `overflow`).

## 4. P-normalizing gates and the latch writers

Revision 13 gives the latch a page field (D5-D7).  Every writer in the
nucleus and in common now either preserves P or sets it deliberately:

| writer | file | P behaviour |
|---|---|---|
| syscall gate | `kernel/syscall/entry.asm` | saves the whole latch (`zos_gate_saved_latch`), writes `(latch & BANK_MASK) | MODE_OS` so P = 0 for the whole dispatch, restores the saved latch exactly |
| IRQ gate | `kernel/irq/entry.asm` | saves the whole latch in `irq_saved_latch`, writes `(latch & (MODE_MASK|BANK_MASK)) | MODE_OS` so handlers run with P = 0, restores the saved latch exactly (an interrupted window call keeps its page selection) |
| banking gates | `kernel/memory/banking.asm` (`zos_enter_os_mode`, `zos_leave_os_mode`, `__zos_mode_fault` continuations) | mode-only transitions from the saved latch; no page bits |
| `platform_bank_set()`/`platform_memctl_write()` | `kernel/memory/banking.asm` | `platform_bank_set` keeps D7-D3 (P and mode preserved); the raw writer is restricted by the audit below |
| bank-copy gate | `kernel/memory/user_copy.asm` | mode transitions only, restored exactly |
| ROM access | `kernel/romfs/rom_access.asm` | mode 00 window: the stub restores the exact entry latch |
| process launch | `kernel/process/process_launch.asm` | mode transitions only, restored exactly |
| boot entry | `boot/start.asm` | selects mode 11 over bank 0 with P = 0, then the CRT runs |
| **upcall shim** | `kernel/memory/upcall.asm` | the one audited fixed-core writer: saves the latch, sets the requested page (0-1), calls, restores exactly |
| spike primitives | `tests/target/rsvc/rsvc_asm.asm` (evaluation image only) | `rsvc_domain_enter/set/exit`: save, select the service page, restore |

`tools/pack_image.py` audits the linked bytes: a latch write in the cold
half is always rejected (the half is only mapped while P = 0), and in the
fixed core it is rejected unless it lies inside the upcall shim
(`_zos_upcall`..`zos_upcall_end`) — a production-placement rule, so the
evaluation images keep their own placement (the self-test caller blob is
the one further allowance, because it runs in an application bank).

## 5. Evidence that the gates and the shim work

`make nucleus-selftest` builds an SIO-only image whose target test
(`tests/target/nucleus/`, replayed by `tests/test_nucleus_sim.py`, 6
tests) drives the three cases the old code got wrong:

1. **syscall with P != 0**: the caller selects the service page in mode 10
   and issues `SYS_DIAG_SYSTEM_INFO` (a cold-half body).  Only a gate that
   clears P can dispatch it; the caller then checks the deterministic
   record and that its own latch — page field included — came back exactly.
2. **IRQ with P != 0**: the caller enables interrupts with the service page
   selected.  The cold-half handler records what it saw (P = 0, mode 11,
   the interrupted bank) and where it ran (the fixed-core ISR stack); after
   `RETI` the caller's latch is again exactly what it selected.
3. **upcall shim**: a fixed-core helper writes a stub into bank 6 through
   the window, the cold test driver calls `zos_upcall`, and the bank-6 stub
   takes a CTC0 delivery *while the window shows bank 6 in mode 11*
   (mode 11, P = 1 — the case the old IRQ gate mishandled) and proves the
   page it was called with was restored exactly.

The replay also asserts that the bank-6 bytes at the stub address differ
from the stub (so the window really shows another bank) and that both
copied routines linked below `s__WINDOW`.

Mutation testing (each mutation applied alone, image rebuilt and replayed,
then reverted):

| mutation | expected effect | observed |
|---|---|---|
| IRQ gate back to the M9 mode-10-only normalization | the in-domain delivery breaks | crash: `unsupported ED 22 at 5FF6`, 6 test errors |
| syscall gate keeps P when entering OS mode | dispatch reaches the wrong half | hang, all tests fail |
| shim restores a fixed latch instead of the saved one | the interrupted caller's page is lost | hang, all tests fail |

Restoring each mutation returns the image to the recorded hash.

## 6. The upcall shim

`kernel/memory/upcall.asm` (+ `upcall.h`) is the fixed primitive of
architecture 36.5: a request block (`page`, `entry`, `args`, `result`) is
validated (page 0-1, entry at or above `ZOS_REV13_WINDOW_BASE`), the latch
is saved, the requested page selected, the entry called with the argument
block in HL, and the latch restored exactly; a bad request returns 0 in HL
with `ZOS_EINVAL`.  Nothing in production calls it yet: stage 3's loader
streaming and process-exit notification are its consumers.  It is a
`fixed-required` member of `config/residency.json`.

## 7. Build fix (package 37 finding 2)

`user/sdk/zex.mk` now lists header prerequisites for every program object
(`ZEX_HEADERS` — the public ABI plus the SDK include root — and each
program's own headers), so a stale client object can no longer mask a real
failure.  Verified by touching `user/sdk/include/zos/console.h` and
observing the program objects recompile and relink.

## 8. Validation commands (this run)

| command | result | wall clock |
|---|---|---|
| `make clean && make check` | OK, reproducible rebuild `d017f133…`, 792 host tests, ledgers and mapcheck rules printed | 2 m 18 s |
| `make m9-selftest` | OK (`m9: worst-case gate-stack depth 213 of 256 bytes`) | 3 m 9 s |
| `make console-integration-selftest` | OK | 1 m 54 s |
| `make rsvc-spike-selftest` | OK, `rsvc: 49/49 checks`, 11 replay tests | 1 m 1 s |
| `make nucleus-selftest` | OK, 3,911 steps, 2 CTC0 deliveries, 6 replay tests | 17 s |
| `python3 -m unittest discover -s tests` (all images built) | OK, 792 tests, 167 skipped | 5 m 6 s |
| `git diff --check` | clean | — |

An incremental full build is 27 s; the acceptance images are 16-187 s each.

## 9. Notes, deviations and follow-ups

- **Spike placement.**  The resident-service spike keeps its package-36
  evaluation placement (`SPIKE_COLD_OBJS`) instead of the production
  classification: its substrate loads the service containers *while the
  window shows bank 6*, so the loader it links must stay in the fixed
  region — which is exactly the stage-3 problem the M10 layout solves with
  the upcall shim.  The production cold flags are therefore not applied to
  it, `mapcheck --residency` and the fixed-core latch audit skip it, and it
  keeps passing (`rsvc: 49/49`).  Package 39 promotes the substrate and
  retires the spike.
- **Spike expectations updated to the new contract.**  `irq-in-domain`
  now asserts the P-normalizing contract (entry latch with the page field
  cleared, the handler's own page selection taking effect) instead of the
  M9 behaviour (handler entered with the interrupted page bits), and two
  layout assertions read the derived fixed code end from
  `build*/geometry/memory.inc` because `__kernel_code_end` now means the
  *cold* code end (the derived arena start).
- **HDL moved out of the OS.**  The decoder PLD and its WinCUPL simulation
  vectors now live in the hardware project (the owner moved them after the
  spike), so this package removed the OS-side references: the
  `platform/zephyr80/hdl/` directory and its layout pin,
  `tools/rev13_vectors.py`, `tools/pld_terms.py`, `tools/wincupl_build.sh`
  and the `make rev13-pld` target.  `tests/test_decoder_rev13.py` keeps the
  simulator-model pins (P = 0 equivalence across every mode, region and
  bank, the mode-10 aperture rule, the mode-11 window) and
  `tests/z80sim.py` records that the vectors live with the hardware.
- **Stray working-tree file.**  `abi/zos/console.h` existed as an empty
  untracked file in this working tree and shadowed
  `user/sdk/include/zos/console.h` for `-I abi`, breaking any from-scratch
  SDK build (reproduced at HEAD).  It is not part of the repository (no
  tracked ABI header of that name) and was moved to the session workspace,
  not committed.
- `tests/m10/two-bank-classification.json` is kept: it is the spike's
  evaluation classification, consumed by `tools/rev13_layout.py` in
  `make rsvc-spike-selftest`, and the production source of truth is
  `config/residency.json` (the spike entry for `upcall` was added with a
  reason).
- **Hardware**: `make smoke-hardware` is owner-run; bank switching is
  hardware-authoritative.  Nothing in this package changes the programmed
  ROM's behaviour under revision 13 (P = 0 is revision 12 in every mode).

## Supervisor review (2026-10-08)

**Accepted.** The clean `make check` reproduces production `d017f133…`.
The ledgers, mapcheck enforcement, gate and shim evidence (including the
mutation tests) and the latch-writer audit are convincing.

- **HDL removal is confirmed by the owner:** the HDL belongs in the
  hardware project. Architecture 36.2 now says so.
- **Bank 7 is full** (cold room 158 bytes, arena 0 free granules, fixed
  room 979 bytes). The production switch-over to the IPC substrate and the
  service loader is therefore resequenced to package 41, when the arena
  drivers leave. Packages 39-40 build into test images only.
- **Minor deviation:** an extra `unittest discover` run after all images
  were built, which `00-WORKER.md` advises against. It is harmless here and
  noted only.
