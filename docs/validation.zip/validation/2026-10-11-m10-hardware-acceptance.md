# M10 hardware acceptance: the production feature exerciser (work package 45b)

Date: 2026-10-11.  Contract: `work/45b-m10-hardware-acceptance/WORK.md`.
Checklist this package serves: `docs/validation/2026-10-11-m10-acceptance.md`
section 7 (M10 step 12).  Baseline: the package-45 tree, production
`fd4436710e3fae940cee619bbf87831a0aa939bdf9e39328c74f928845f6e91d`.

## Result

**Most of the M10 hardware checklist now runs on the flashed production
image.**  `build/zephyros.bin` gains a feature exerciser in its recovery
store - `/SYSTEM/hwtest.zex` plus the six outcome programs its stages run
- and the monitor gains `X <path> [tail]`, so the owner starts it with
one typed line: no acceptance flash, no test-only nucleus code, no
rebuild.  The runner's stages and its verdict are pinned twice: by a new
production replay in `make check` (with a card and without one) and by
`make smoke-hardware-hwtest SERIAL_PORT=...` on the bench.

Production changed in exactly the two places the contract allows - the
monitor and the store; the nucleus and every driver are untouched.

- Production image `874e05b8cb4bb428880b4bc011d780aed759a37d3f65442552656f05e87b543c`
  (package 45: `fd443671…`).
- `monitor.zex` 6053 bytes, `5f6a0d355c47d441bd12d9a36da6ba7cc43bbe791a3399acbbb8b670b12134ae`
  (package 45: 4977 bytes).
- `hwtest.zex` 12175 bytes, `0479b9778f97d358ac482ff6257754d112506b969127aad61b6b0b44a9eed28d`.
- Recovery store **87 840 of 294 912 bytes** (package 45: 27 326); free
  207 072, i.e. 70 % of the store unused (section 4).

## 1. What shipped

| Piece | Where | What it does |
| --- | --- | --- |
| `X <path> [tail]` | `user/monitor/monitor_exec.c` | runs a stored ZEX with the launcher's own `SYS_EXEC` path, prints `exec: exit status 0xssss`, prompts again (card executables: section 5.5, fixed by correction 01) |
| Serial command lane | `user/monitor/monitor.c` | binds `/dev/serial/0` when a SERIAL object is published there and polls it beside the console, so a host tool can type monitor commands on the production image |
| The runner | `tests/hwtest/hwtest.c` → `/SYSTEM/hwtest.zex` | three stages, one line each, plus a verdict; mirrors every line to the console and the lane |
| `stage` option | `tests/fs/fs_selftest.c`, `tests/fs/fs_child.c`, `tests/xmem/xmem_selftest.c` | one tail option per reused program: card writes confined to `/FS/HWTEST`, pool rows stated against the banks this context can open |
| Store | `recovery/manifest.json`, `Makefile` | the exerciser and its six programs are packed into the production recovery image |
| Smoke mode | `tools/serial_smoke.py --mode hwtest` | types the command over the lane with a per-byte echo handshake and checks the stage lines and the verdict |
| Replays | `tests/test_hwtest_sim.py`, `tests/test_hwtest.py` | the production outcome replay (`make check`) and the static/source pins |

The monitor change is a **command-input path**, not an output path: the
monitor writes nothing to the lane on its own, so the production boot
transcript (the four early-console lines) is byte-identical and the
existing production replay still pins `sio.count(b"\n") == 4`.

## 2. The exerciser's transcript

With a card (`IocCommandPeer(fs2_media=True)` with one keep-file on it,
the replay's card), typed on the serial lane:

```text
Z80> X /SYSTEM/hwtest.zex
hwtest: begin
hwtest: xmem+far PASS
hwtest: files PASS
hwtest: namespace+handles PASS
hwtest: 3/3 PASS
exec: exit status 0x0000
Z80>
```

Without a card (`fs2_media=False`), typed on the USB keyboard at the
V9958 console:

```text
hwtest: begin
hwtest: xmem+far PASS
hwtest: files card absent
hwtest: namespace+handles PASS
hwtest: 3/3 PASS (card absent)
exec: exit status 0x0000
```

On the console the stage programs' own rows appear between the runner's
lines (the runner's are on both sinks, the children's on the console):

- xmem stage: `xmem-selftest: 61 checks, 0 failures`, `xmem-child: PASS`
  three times (latches `13`), `xmem-far: 19 checks, 0 failures`
  (`far-exec-status OK`), `xmem-selftest: PASS`, `xmem-far: PASS`;
- files stage: `fs-selftest: 35 checks, 0 failures` with a card (8 checks
  and `fs-selftest: card absent: /FS not served` without one),
  `fs-child: PASS` / `fs-child: card absent` - 37 checks since correction
  01 added the card-exec pair (`exec-card-copy`, `exec-card-status`);
- namespace stage: no per-row output, only the stage line (a failing
  check names itself in the verdict line, e.g.
  `hwtest: namespace+handles FAIL table-emfile`).

Every stage line is preceded by releasing the runner's own lane handle,
so a nested exec always starts from a clean table; the runner also takes
whole-bank counts around each stage program, which is its evidence that a
child's exit returns every bank, object and segment it held.

## 3. Replays

`tests/test_hwtest_sim.py` boots **the production image** twice and injects
the same line both ways:

- card present, command on the serial lane: the lane must start with the
  echo of the typed line, carry `begin` + three stage lines + the verdict,
  the console must carry the stage programs' evidence rows and the
  monitor's `exec: exit status 0x0000`, and afterwards the emulated card
  must hold exactly the keep-file it started with - no `/FS/HWTEST`, no
  stray file (requirement 2's "never touch other files on the card");
- card absent, command on the HID keyboard lane: the lane's first byte is
  `hwtest: begin` (the keyboard echo stays on the console), the files
  stage reads `card absent`, the verdict carries ` (card absent)`, the
  console shows the absent-card rows, and the card holds nothing.

A third replay (8.9 s) pins the command's own contract end to end on the
production image: `X /SYSTEM/fs_child.zex tail-42` must run a *stored*
program with a nonzero exit status - the console shows the child's
`fs-child: PASS` and `fs-child: tail "tail-42" argc 1`, then
`exec: exit status 0x002A`, and the prompt returns.  The monitor's
argument and lookup errors (`X` with no argument -> `ERR: ARG`,
`X /SYSTEM/nosuch.zex` -> `ERR: 05`) are pinned by
`tests/test_console_acceptance.py` alongside the existing monitor session.

Cost: 99.6 s for the 18 exerciser tests (the replays are ~96 s of that)
on the development machine - most of the plain `make check` suite's
121.8 s, because the exerciser's stages and their nested programs run for
tens of millions of emulated steps and this is now the longest replay in
the suite.  `tests/test_hwtest.py`
(15 tests) pins what a replay cannot see: the runner's source surface (one
`stage` tail per program, no second copy, every card path below
`/FS/HWTEST`, console before lane), the reused programs' option, the
monitor's command surface, the production manifest entries and the smoke
mode's contract.

## 4. Store ledger

`python3 tools/romfspack.py dump build/recovery.romfs`:

| Entry | Bytes | Offset |
| --- | --- | --- |
| `sio.zmod` | 934 | 520 |
| `ioc.zmod` | 4468 | 1454 |
| `hid.zmod` | 1733 | 5922 |
| `v9958.zmod` | 6700 | 7655 |
| `console-v9958-hid.zmod` | 283 | 14355 |
| `services.man` | 144 | 14638 |
| `iocfat.zmod` | 7783 | 14782 |
| `monitor.zex` | 6053 | 22565 |
| `hwtest.zex` | 12175 | 28618 |
| `xmem_selftest.zex` | 12018 | 40793 |
| `xmem_child.zex` | 7783 | 52811 |
| `xmem_far.zex` | 8341 | 60594 |
| `fs_selftest.zex` | 10866 | 68935 |
| `fs_child.zex` | 8039 | 79801 |

Capacity 294 912 bytes; used **87 840** (29.8 %), free 207 072.  The
package adds 59 222 payload bytes plus 216 bytes of directory entries for
the six programs, and 1076 bytes to the monitor (the lane input path and
the `X` command): 27 326 + 59 438 + 1076 = 87 840.  The programs fit with
five times the room they need, so the "stop and report" branch of
requirement 4 did not apply.

## 5. Findings that shaped the implementation

1. **The production console has no command input on the serial lane**
   (requirement 5's contradiction).  Production's console is
   `console-v9958-hid`: bytes arriving on SIO0/B reach the SIO service and
   nothing reads them as input, so `--mode hwtest` could not have sent
   `X ...` at the prompt.  Reported to the supervisor, who chose (over
   targeting the console-serial variant or a capture-only mode) to give
   the production monitor a polled serial command-input path.  The
   monitor binds the *namespace name* `/dev/serial/0` when a SERIAL object
   is published there - no port I/O, no driver symbol, no protocol
   knowledge - polls the console first (so the serial-console build still
   renders every byte once), and echoes each byte to the source it came
   from.
2. **The kernel's exec chain is four deep** (`ZOS_EXEC_MAX_DEPTH`), and
   monitor(1) → runner(2) → stage(3) → grandchild(4) is already the
   limit: the far program's own nested exec would be the fifth and returns
   `ZOS_EBUSY`.  The **runner therefore invokes `xmem_far.zex` directly**
   instead of below `xmem_selftest` (a deviation from requirement 2's
   "including its far program"), and `xmem_selftest`'s two far rows
   (`far-program-status`, `far-program-released`) move to the runner as
   `hw_stage_xmem`'s own exit-status check and whole-bank brackets.  No
   row is lost and no check is weakened; the acceptance image's own row
   (63 checks) is unchanged.
3. **A bank held by a live process is closed to auxiliary placement**, so
   the exerciser cannot see the acceptance image's five banks: with the
   monitor and the runner live it measures **three** (the replay prints
   the rows the xmem program derives from that count, e.g.
   `exhaustion-16k-count` 6 and `xmem-child: latch 13` where the
   acceptance image reads 10 and 11/12).  This is why the pool rows are
   parameterized on a measured bank count instead of the
   `free-banks 6` report, and why the xmem program's stage run prints
   **61 checks** instead of the acceptance image's 63.
4. **The descriptor pool is global** (`VFS_FD_MAX` = 12 for every owner):
   the monitor holds three slots (two standard handles plus the lane) and
   the runner two, so the namespace stage gets **7** and its first bound
   handle is `3`, not `1`.  The stage therefore pins the *behaviour*
   (fill ends on `-ZOS_EMFILE` = `-23`, every slot returns, the same
   capacity is available again, the next bind succeeds and unbinds) rather
   than a count the monitor would decide.
5. **`X` cannot run a program from a card: `SYS_EXEC`'s path buffer is
   invisible to a bank-6 provider.**  Requirement 1 asks for `X` on
   "any ZEX on `/SYSTEM` or `/FS`"; `/SYSTEM` works (exerciser, tails,
   exit statuses, section 2) and `/FS` does not:

   ```text
   Z80> X /SYSTEM/fs_child.zex tail-42
   fs-child: PASS
   exec: exit status 0x002A          # the child's status, as required
   Z80> X /FS/FS_CHILD.ZEX tail-42
   ERR: 02                           # ZOS_EINVAL, no child at all
   Z80> X /FS/nosuch.zex
   ERR: 02                           # ENOENT would be correct here
   ```

   The same names resolve correctly through a program's ordinary bind
   (the exerciser's namespace stage pins `ZOS_ENOENT` for an absent card
   name), and the emulated MCU peer records **no FS2 command at all** for
   either `X /FS/...` attempt, so the failure happens before the provider
   does any work.  The cause is where the kernel stages the path:
   `zos_process_path_scratch` is bank-7 `_DATA` at `0xC0DD`, and in mode
   11 with `P != 0` the region `6000h-DFFFh` is the *window* (the
   driver's own bank), while every working provider bind passes a path
   from the VFS workspace at `0x5848`-`0x5FFx`, inside the always-mapped
   `2000h-5FFFh` nucleus region (`docs/memory.md` section 1.1).  `/SYSTEM`
   is unaffected because the ROMFS reader is in-process.  M9 had card
   executables because its provider was in-process too, so this is an
   M10 regression from the 42b/42c provider move.
   The minimal fix is one kernel change - copy the exec path into a
   driver-visible buffer (a VFS workspace path slot, or a fixed-core
   array) before `vfs_ns_bind` in `process_prepare` - which this package
   may not make: the contract freezes the nucleus and the drivers, and
   the supervisor confirmed that choice on 2026-10-11.  **Correction 01
   made exactly that change** (the path is staged in `VFS_WS_IN_A`, the
   scratch is retired, `mapcheck` guards the workspace and a production
   replay runs a card program through the monitor):
   `docs/validation/2026-10-11-m10-hardware-acceptance-correction-01.md`.  `user/monitor/` and `docs/monitor.md` now state
   the verified behaviour instead of promising `/FS`, and nothing the
   exerciser does depends on card execution (its stages run from the
   store).
6. Three defects the new replay caught and this package fixed:
   `fs_child`'s startup-tail length check still compared the old tail's
   length, `xmem_selftest` hard-coded `big[4]` (an uninitialized free once
   the pool count drops to 3), and `xmem_selftest` initialized a
   `static` (`= 5u`) - ZEX v2 has no initialized writable data, so
   `zexpack` rejected the object; it is zero-initialized and assigned in
   `main` now.

## 6. What the exerciser covers of the M10 checklist

| 45-record row | Covered by `X /SYSTEM/hwtest.zex`? |
| --- | --- |
| 7.1 bank switching and the aperture | yes, as mechanism evidence on the production image (61 checks, 3 child runs); the acceptance image's row stays canonical (all six banks) |
| 7.2 driver IRQs on real sources | no - `ipc-selftest` needs test-only nucleus code |
| 7.3 both console builds, ESC `c` | no - separate images and a human display pass |
| 7.4 production with/without a FAT card, files under `/FS` | yes, both halves (37 checks with a card, 8 without, `card absent` in the verdict; correction 01 added the card-exec rows) |
| 7.5 nested exec | yes - `fs-child`/`xmem-child` tails, exit statuses, released handles |
| 7.6 xmem and far code | far-code mechanism yes (`xmem_far`: 19 checks, `far-exec-status OK`); the `fardemo` row stays separate |
| 7.7 CP/M still boots | not affected (no CP/M-side change) |
| 7.8 subsystem acceptance and the production smoke | no - `subsystem-selftest` needs test-only nucleus code; the production smoke is unchanged and still required |

## 7. Owner checklist

### 7.1 Getting it onto the board: nothing goes on the SD card

The exerciser and the six programs its stages run are inside the **ROM
image's recovery store** (ROM pages 2-3), so one flash delivers
everything.  There is no file to copy to the card, no card boot, and no
second medium: `X /SYSTEM/hwtest.zex` resolves from the same store the
monitor itself is loaded from.

1. `make` (the recorded build, if you are not rebuilding).  The artifact
   is `build/zephyros.bin`, exactly 524288 bytes,
   `5a731321687636e8a7c26a1ccbadb545209621429e3577bbbafd13a647c395d2`
   (work package 45b's `874e05b8…` plus correction 01);
   `build/zephyr80.bin` is the same bytes under the tool's name
   (`make` prints both sha256 and `cmp`s them).
2. Program `build/zephyros.bin` into the 512 KiB EPROM/flash in the
   Zephyr-80 ROM socket.  The physical procedure, the programmer
   prerequisites and the record-keeping are
   [`docs/boot.md`](../boot.md) section 10 ("Physical-ROM test
   checklist"); the serial lane is SIO0/B, 115200 8N1.
3. **The card is optional and carries nothing this package added.**  Use
   the ordinary FAT card the system already serves at `/FS` - the same
   medium CP/M calls `B:` (`A:` there is the read-only ROM rescue disk).
   The files stage creates `/FS/HWTEST`, exercises it and removes it
   again, and asks for nothing else on the medium; leaving the card out is
   the checklist's second half, not a failure.

### 7.2 The two runs

1. **With a FAT card fitted.**  Either
   `make smoke-hardware-hwtest SERIAL_PORT=/dev/ttyUSBx` (the tool prints
   the image and its sha256, types the line on the lane and checks every
   line) or type it at the V9958 prompt with the USB keyboard:

   ```text
   Z80> X /SYSTEM/hwtest.zex
   ```

   Expect the five `hwtest:` lines above with `files PASS` and
   `3/3 PASS` (no note), and `exec: exit status 0x0000` back at the
   prompt.  On the display, between them: `xmem-selftest: 61 checks,
   0 failures`, `xmem-child: PASS` three times, `xmem-far: 19 checks,
   0 failures`, `fs-selftest: 37 checks, 0 failures` (35 before
   correction 01, which added the card-exec rows), `fs-child: PASS`,
   then `xmem-selftest: PASS` and `xmem-far: PASS`.
   Correction 01 also makes the card itself runnable: copy the store's
   `fs_child.zex` (the build tree's `build/modules/fs_child.zex`, byte
   for byte) onto the FAT card as `FS_CHILD.ZEX` and type
   `X /FS/FS_CHILD.ZEX tail-42` - expect `fs-child: PASS` and `exec: exit
   status 0x002A`, where 45b answered `ERR: 02`.
   To look at the medium itself afterwards, boot CP/M and `DIR B:` (or
   read the card on a PC): no `HWTEST` directory is left and no other file
   changed.
2. **Without the card** (power off, remove it, boot again, repeat the
   line).  Expect `hwtest: files card absent`, `hwtest: 3/3 PASS (card
   absent)`, `fs-selftest: 8 checks, 0 failures`, `fs-child: card absent`,
   and `/FS` still refused (`fs-selftest: card absent: /FS not served`).
   This run's `chdir-card-enodev` row is the one that failed on
   2026-10-11; correction 01 makes `/FS` answer `ZOS_ENODEV` for every
   operation with no media (section 4 of the correction record).
3. **Capturing the result.**  The lines above appear on the V9958 display.
   For a transcript the owner can attach, run the lane from a host
   terminal: `make smoke-hardware-hwtest SERIAL_PORT=/dev/ttyUSBx` (or
   `tools/serial_smoke.py --mode hwtest --port /dev/ttyUSBx`) prints the
   echoed command and the same lines and exits non-zero unless the stages
   and the verdict match.  The typed-speed handshake restarts the line at
   most four times if a byte is lost, so a partial line is never executed.
4. The rows this does **not** cover are still separate flashes: the xmem
   acceptance image (7.1, canonical), `ipc-selftest` (7.2), the console
   images and the ESC `c` display pass (7.3), `fardemo` (7.6), the
   subsystem image (7.8) - and the human pass on the V9958 remains part of
   acceptance.

## 8. Validation

```sh
make clean && make check        # reproducible rebuild + the whole suite
make xmem-selftest fs-selftest ns-selftest console-integration-selftest
git diff --check
```

- `make check`: green - the rebuild is byte-identical
  (`874e05b8…`), and the suite reports `593 tests, OK (104 skipped)` in
  121.8 s; the skips are the acceptance images a plain `make check` does
  not build.
- The four acceptance targets: green (6m27.7 s: namespace 23 tests,
  filesystem 3, console-integration 8 with its video/console replays, and
  the xmem image's own replay with its 63-check row).
- Extra, because this package edited a pin that a plain `make check`
  skips: `make subsystem-selftest` (green, 1m57s, its own
  `test_subsys_sim.py`/`test_romfs_sim.py` replays) and then
  `tests/test_monitor.py` (30 tests, green) - the monitor's help row and
  the `exec: exit status 0x` marker are now checked against the linked
  subsystem image, not only the production one.
- `git diff --check`: no whitespace errors.
- No commit was made by this package (owner instruction); the working
  tree also carries package 45's uncommitted changes.

## 9. Files

- Monitor: `user/monitor/monitor.c`, `user/monitor/monitor.h`,
  `user/monitor/monitor_exec.c` (new).
- Exerciser: `tests/hwtest/hwtest.c` (new).
- Reused programs: `tests/fs/fs_selftest.c`, `tests/fs/fs_child.c`,
  `tests/xmem/xmem_selftest.c`.
- Store and build: `recovery/manifest.json`, `Makefile`.
- Smoke: `tools/serial_smoke.py`.
- Tests: `tests/test_hwtest_sim.py` (new), `tests/test_hwtest.py` (new),
  `tests/test_monitor.py`, `tests/test_console_acceptance.py`,
  `tests/test_hid.py`, `tests/test_v9958.py`, `tests/test_sdk.py`.
- The three tests the new store entries or pins invalidated were updated,
  not weakened: the production store's entry list (HID and V9958 artifact
  tests) and the SDK's one-rule-per-program list now carry the seven
  programs.
- Documentation: `docs/monitor.md`, `README.md`.

## Hardware (owner, 2026-10-11)

On the production image, with a FAT card: `X /SYSTEM/hwtest.zex` →
`hwtest: xmem+far PASS`, `files PASS` (`fs-selftest: 35 checks, 0
failures`, including the nested child with its tail, exit status and
released handles), `namespace+handles PASS`, **`hwtest: 3/3 PASS`**,
`exec: exit status 0x0000`, then back at `Z80>`. The serial lane and the
V9958 agree.

This closes the following package-45 checklist items on hardware: 7.1
(bank switching and the aperture), 7.4 (files under `/FS` with a card),
7.5 (nested exec) and 7.6 (xmem and far code).

Still open: the card-absent run of `hwtest`, `ipc-selftest`,
`subsystem-selftest`, and running from `/FS` (45b correction 01, which
this record's section 7 checklist now covers).

### Hardware (owner, 2026-10-11): card absent

`X /SYSTEM/hwtest.zex` with no card:
- `xmem+far PASS`;
- `files card absent` (`fs-selftest: card absent: /FS not served`; the
  `/SYSTEM` checks and the nested child pass, 8/8);
- **`namespace+handles FAIL chdir-card-enodev`**, so `hwtest: 2/3 FAIL
  (card absent)`, exit status `0x0001`.

The card-absent `chdir` into `/FS` returns a code other than the
`ENODEV` the check expects, while the simulator's card-absent replay
passes. The real IOC's no-media answer reaches `chdir` differently from
`bind`. A stray `=` was also printed before
`fs-selftest: console-write OK` on the V9958.

**Both are closed by correction 01** (2026-10-11):
`docs/validation/2026-10-11-m10-hardware-acceptance-correction-01.md`.
The `chdir` failure was the driver answering the root from its own
knowledge after a probe the firmware can satisfy from a cached mount;
`/FS` now answers `ZOS_ENODEV` for every operation with no media, and the
exerciser's rows print the code they saw.  The `=` is the
`console-write` row's own byte (the check writes one `=` through the
console handle), so nothing changed there.
