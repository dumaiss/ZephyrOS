# V9958 direct renderer

## Result

The V9958 console draws glyphs straight into VRAM from a 1-bit font in the
driver's mapped segment, as architecture 5.6 states. VRAM holds no font
any more; fills, scrolling, line insertion and deletion and the LMMV/EOR
inversion stay on the command engine. The production image boots, every
console, shell, TUI, tee and takeover replay passes on a VRAM-based screen
decoder, and the simulator's CPU cost per character falls from 4,780 to
1,792 T-states on realistic text (`con.mixed`).

Validated with targeted builds and suites; the full `make clean && make
check` is deferred by the owner to the end of packages 78-79. The board run
is PENDING.

## Files

- `drivers/v9958/v9958_io.asm` - `_v9958_out_flush` rewritten: CE wait
  first, one bulk-map span per run, R#14 once, then per scanline one VRAM
  address and three data-port bytes per glyph (character code -> font page
  -> row byte -> expansion page). The expansion set's page is patched into
  the loop once per run (no register is left for it). The glyph command
  block, its template and the fill equates are gone. The hold helpers read
  `_v9958_state+V9958_ST_EXCLUSIVE` directly (they read it through
  `_v9958_alt_state`, which the RENDER entry never sets).
- `drivers/v9958/v9958_font.asm` - the mapped segment: `_v9958_font_pages`
  (2,048, generated) and `_v9958_expand` (1,536 BSS).
- `drivers/v9958/v9958.c` - `v9958_span_open/close`, `v9958_expand_init`
  (three pages per colour pair from the pair tables); the atlas upload, the
  font reader and the row expander are gone; the bring-up has no upload.
- `drivers/v9958/v9958_proto.c` - the init builds the expansion pages; the
  bulk-read probe is gone. `v9958_boot.c` - no font base.
  `v9958_driver.h` - atlas and font-chunk constants gone, mapped externs.
- `drivers/v9958/v9958.json` - `bulk` -> `mapped` with `"align": 256`.
- `tools/fontpack.py` - `paged` (the scanline-major layout as an assembler
  include). `tools/modpack.py` - a mapped segment's `align` (a power of two
  up to 256). `Makefile` - the paged-font and mapped-segment rules.
- `tests/z80sim.py` - `V9958Peer` executes HMMM (byte by byte, DIX/DIY),
  records `writes_at` per command and optional VRAM snapshots.
- `tests/replay.py` - the cell table (font + pair tables), `v9958_screen`,
  and `ConsoleReplay.pump` on the data-port write stream.
- Tests moved to the VRAM decoder: `test_tui_sim.py`, `test_shell_sim.py`,
  `test_device_release.py`, `test_textbench.py`, `test_v9958.py`,
  `test_driver_images.py`; `tests/console_profile.py` retargeted.
- Docs: `docs/devices.md` (V9958: terminal, glyph drawing, RENDER, bring-up,
  font; the takeover table), `docs/memory.md`,
  `docs/konaos-tui-sdk-architecture.md`. The architecture roadmap item stays
  for package 80.

## Requirement results

1. **Layout.** Font pages and expansion pages are page-aligned
   (`"align": 256`; plan: v9958 mapped at 0100h). The container test pins
   the image as `fontpack.paged(font)` and the BSS as 6 x 256.
2. **Renderer.** As above. Spaces are drawn as glyphs: one rule for every
   byte, and an HMMV per blank run would put the command engine's per-
   command cost back on ordinary text (package 76: an HMMV fill costs about
   as much as a glyph copy). No VRAM read, no copy inside the span.
3. **Removal.** Atlases, their uploads, the bulk font and every consumer
   are gone; VRAM page one is free except the cursor tables.
4. **Unchanged contracts.** The console, shell, TUI (both lanes), tee,
   takeover/release and KonaCommander replays pass; INVERT is the same
   LMMV/EOR over the drawn pixels.
5. **Tests follow the subject.** Screens decode from VRAM; the HMMM-command
   decoders and the atlas tests are gone. `V9958Peer` mirrors the V9958
   HMMM (high-speed move, whole bytes, DIX/DIY) and keeps its fixed
   400-instruction command time; it models no WAIT and no access slots.
6. **Docs.** As listed.

## Measurements (simulator CPU, T-states per character)

| row | before (76) | after |
|---|---:|---:|
| con.putchar | 5,368 | 2,171 |
| con.printf | 3,603 | 2,453 |
| con.write | 2,919 | 1,724 |
| con.mixed | 4,780 | 1,792 |
| con.space | 2,943 | 1,724 |
| con.held | 155 | 155 |

Glyph drawing is 917-957 per character (the estimate was about 900); the
CE wait falls to 41-117. Board estimate: these plus the measured V9958
wait (565-791 per character, package 77), about 2,300-2,400 for
`con.mixed` against 3,782 today. The `Should` (board `con.mixed` and
`con.write` <= 2,300) is PENDING.

## Budgets

| figure | before | after |
|---|---|---|
| driver hot | 31,027 used / 1,741 free | 30,471 / 2,297 (-556) |
| driver boot/bulk | 19,598 | 21,128 (+1,530, limit +1,792) |
| driver mapped | 0 | 3,584 of 7,936 (limit 3,840) |
| v9958 hot image | - | 5,987 |

## Pins changed, with their sources

All test artifacts against the retired atlas path (architecture 5.6, this
package's requirement 3) unless noted:

- `test_v9958`: manifest roles and `align`; the container pins the paged
  font; `bulk_read` pins removed; `test_asm_fill_colours_are_the_header_colours`
  deleted (the assembly has no fill bytes); the upload step and atlas lines
  removed; the pair-coalescing pins replaced by the flush's structure.
- `test_tui_sim`: the batch test's 12-pixel HMMM-pair count deleted (pairing
  is gone); "no glyph repaint" and "no drawing" are data-port write counts;
  invertwrap decodes VRAM snapshots.
- `test_shell_sim.assert_logo`: counts the logo's 46 row addresses, because
  text is data-port writes too.
- `test_device_release.assert_restored`: the atlas re-upload and the
  4,096-write floor became "the reset rewrote the cursor pattern"; the
  cleared-field sample moved from VRAM line 8 (text row 1, which holds text
  now that glyphs reach the modelled VRAM) to line 160.

Implementation fixes found by the tests, not pins: the shell logo's own
data-port writes were read as text (the pump only takes bursts that start
on a cell boundary); a reverse space and a normal full block (DBh) are the
same 24 bytes (printable codes win in both attributes).

## Validation

```sh
make
python3 -m unittest tests.test_v9958 tests.test_driver_images tests.test_source_layout tests.test_iocfat
python3 -m unittest tests.test_shell_sim tests.test_tui_sim.TestTuiV9958Screen
python3 -m unittest tests.test_device_release tests.test_textbench tests.test_console_acceptance tests.test_vblank
make console-serial-selftest
python3 -m unittest tests.test_tui_sim.TestTuiSerialScreen tests.test_console_tee tests.test_console_serial
make -C UserSoftware/KonaCommander test
python3 tests/console_profile.py
git diff --check
```

- `test_v9958` 26 OK (1 skip); `test_driver_images` 35 OK.
- Shell replay 3 OK; V9958 TUI replays 24 (3 failed once, fixed, rerun OK).
- device_release/textbench/console_acceptance/iocfat/source_layout/vblank:
  92 run, 4 failed once (the pins above), fixed, rerun OK.
- `make console-serial-selftest` 6 OK; serial TUI + tee + serial console
  36 OK.
- KonaCommander: host 10, project 7, UI replay 1 OK (see Found).
- Profiler: every row within 1% (worst 0.11%).
- `git diff --check` clean; the history-word check prints nothing.
- Production image `8496477cfaf8fd3439273d20711afb2d3e8b29e07754d907612d6c017dc780e6`;
  `iobench.exe` 17,877 bytes, `94b97691d2fcdad397dc93822b1b841022d0ed4229121e74810d8bdb9d666768`.
- Not run: `make clean && make check` (deferred by the owner).

## Found

- `UserSoftware/KonaCommander/tests/test_ui_sim.py` counts glyphs and cells
  from HMMM commands, so those counters now read 0 and its "no glyph
  redraw" checks pass vacuously. It should count page-zero data-port
  writes (24 per glyph). Not changed: the owner's tree.
- After a TUI program exits, its pass line prints in reverse video (the
  RENDER STATE leaves the console's attribute at the program's last one).
  Pre-existing; the old decoder ignored attributes.

## Owner checklist (PENDING)

- Boot: banner and logo, shell prompt; `ls` of a long directory (scrolling).
- KonaCommander: F1, Left/Right across the menu (one visual action), a
  panel listing, exit restoration.
- A TUI example; reverse text; `ESC c`.
- Donkey Kong (exclusive hold): sprites and screen intact, the console back
  after exit.
- `iobench`: photograph the summary (con.write, con.mixed, con.space).

## Board results (owner, 2026-10-22)

`iobench` on the board with this image, T-states per character:

| row | before (76) | after | change |
|---|---:|---:|---:|
| con.putchar | 3,479 | 2,817 | -19% |
| con.printf | 3,737 | 3,549 | -5% |
| con.write | 3,083 | 2,866 | -7% |
| con.mixed | 3,782 | 3,226 | -15% |
| con.space | 2,682 | 2,885 | +8% |
| con.held | 147 | 148 | - |

The `Should` (con.mixed and con.write <= 2,300) is missed. Board minus
simulator CPU is 1,142 (write) to 1,434 (mixed) per character, twice the
wait package 77 measured: its renderers spent about 300 T-states per glyph
scanline, so the V9958's access slots kept up; this loop spends 114, so the
CPU now waits for a slot on almost every write. Glyph drawing costs about
2,100 per character on the board (87 per VRAM byte) against the port-only
ceiling `vdp.direct.off`, 1,623 per glyph (67 per byte): the renderer is
within 1.3 times of the V9958's CPU access rate in GRAPHIC 6 with the
display on. Blank runs got slower because each space is now 24 data-port
writes instead of a share of a two-cell HMMV.

## Final gate (2026-10-22, packages 78 and 79 together)

- `make clean && make check`: 877 tests, 2 failures, 118 skips (2,059 s).
  Both failures were package 77's `textbench`, not 78/79:
  `test_sdk.TestSdkBoundary.test_every_program_is_declared_once_by_the_generic_rule`
  (the pinned program list lacked `textbench`; class: test artifact,
  source: package 77 declared the program) and
  `test_every_quoted_include_resolves_inside_the_sdk_boundary`
  (`textbench.c` included a header generated into the build tree; class:
  implementation). Fixed: the font is an assembler `.include` of the
  pinned asset in `textbench_render.asm`, `textbench.c` declares it
  `extern`, `tests/bench/font2c.py` is removed; the program list names
  `textbench`. `tests.test_sdk tests.test_textbench`: OK
  (`textbench.exe` 12,034 bytes, unchanged size).
- `make ipc-selftest`: `ipc: 58/58 checks`, 41 tests OK.
- `make console-serial-selftest`: 6 OK.
- `make check` again after the fix: **877 tests, `make check: OK`**
  (2,022 s); reproducible rebuild
  `cb14238045ef6451b84bfb48df1d5b7352cb53b73a4f49d4d646a3d4c2902456`
  (the build date in the shell banner changed the hash from the earlier
  build); `build/konaos.bin` `cb14238045ef6451b84bfb48df1d5b7352cb53b73a4f49d4d646a3d4c2902456`.
