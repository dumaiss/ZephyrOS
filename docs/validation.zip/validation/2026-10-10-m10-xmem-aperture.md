# M10 extended memory and the far aperture (work package 43)

Work package: `work/43-m10-xmem-aperture/WORK.md` (M10 step 9, target
architecture 36.15-36.17, 36.8 and 36.20).  Recorded 2026-10-10.

## Scope

- **Application bank map** (36.15): every application bank is FREE,
  PRIMARY(process) or AUXILIARY; an auxiliary bank carries seven 8 KiB
  slots over `0000h-DFFFh`; a bank with a live slot can never become a
  primary bank.
- **Extended-memory objects** (36.16): `SYS_XMEM_ALLOC/FREE/READ/WRITE/
  INFO/MAP`, 8 KiB slot rounding, contiguous in one bank, 32 KiB maximum,
  `MAPPABLE` at most 16 KiB in the aperture slice, contents **undefined**
  (36.19), ranges checked before any copy.
- **Map tokens and the mode-10 aperture** (36.17): `MAP` returns the token
  *and* the object's aperture address; tokens exist only for the caller's
  own objects in banks 0-5; the SDK opens the aperture with `OUT` and
  closes it by restoring the previous latch.
- **Buffer identity** (36.8): a caller address in `8000h-BFFFh` under a
  saved nonzero page resolves to bank 7 - P, in the syscall copies and in
  descriptor capture (path C).
- **Lifetime**: exit releases every object after the process's handles are
  unbound; a suspended parent keeps its objects; a child inherits none;
  exec starts the child with P = 0 and restores the parent's latch exactly.
- **Common limit (5b)**: `tools/mapcheck.py` and the packer enforce the
  3,072-byte ceiling; the 512-byte M9 reservation (`ZOS_COMMON_M10_
  RESERVATION`) is gone from platform files, tools, the ledger line and the
  docs.
- One new image: `xmem-selftest` (44b extends it with far code).  No ZEX
  v2, no far-code segments, no sub-agents.

Pins: `abi/zos/xmem.h` (numbers, blocks, static assertions),
`user/sdk/include/zos/xmem.h` (SDK face), `docs/abi.md` section 14.
`kernel/memory/window_copy.asm` is the new fixed-core copy primitive for
slots 3-6 (mode 11, P = 7 - bank); slots 0-2 keep using the mode-10
`zos_bank_copy` gate.

## Validation (run once, serially, at the end)

```sh
make clean && make check
make xmem-selftest fs-selftest subsystem-selftest
git diff --check
```

All three commands completed with exit status 0; `git diff --check`
reported nothing.  The three image targets were one serialized chain after
`make check` (the makefile parallelizes the three independent target
builds internally, each in its own `build-*` directory).

### Production build (`make check`)

- `check: reproducible rebuild
  (8886f15494383474c4214d0fb45e0668b115f088f1a2d730f83ad4c750e3a57f)`
- 545 tests, `OK` (97 skipped: acceptance images build in their own
  targets).
- `mapcheck: OK (18 areas, 340 symbols) [production]`
- `pack_image.py: 524288 bytes,
  sha256 8886f15494383474c4214d0fb45e0668b115f088f1a2d730f83ad4c750e3a57f`
- `build/zephyros.bin` and `build/zephyr80.bin` byte-identical (`cmp`).

### Ledgers (bytes, no raises)

| ledger | production | xmem-selftest | fs-selftest | subsystem-selftest |
| --- | --- | --- | --- | --- |
| nucleus fixed required / overflow / stacks, room | 8335 / 2 / 768, 7279 | 8335 / 2 / 768, 7279 | 8370 / 2 / 768, 7244 | 8370 / 1012 / 768, 6234 |
| nucleus cold code end, data at, room | 20346 `AF7Ah`, 1443 `B000h`, 10845 | 20352 `AF80h`, 1443 `B000h`, 10845 | 21170 `B2B2h`, 1457 `B400h`, 9807 | 26042 `C5BAh`, 1651 `C600h`, 5005 |
| driver hot | 21846 / 32768 | 1113 / 32768 | 15035 / 32768 | 1113 / 32768 |
| driver boot/bulk | 2170 / 24576 | 47 / 24576 | 107 / 24576 | 47 / 24576 |
| common used, ceiling | 2358, 3072 | 2358, 3072 | 2358, 3072 | 2523, 3072 |

Every ledger is inside its budget: the fixed core keeps 7,279 bytes of
room in production, the cold half 10,845, the driver arenas are far from
full, and common memory uses 2,358 of the 3,072-byte ceiling (2,523 in the
subsystem image, which links the acceptance surface).  **Common use is
unchanged from the M9 baseline** - the only new common tenant the
package could have added, the window copy, links into the fixed core
(`_CODE`) instead, and the M9 reservation was released rather than spent:
the ledger line now reads `common: used <n> of <n> bytes (code <n>,
data <n>) | ceiling <n>` with no `m10`/`limit` field.

The only growth against the M9 baseline is the cold half (20,362 bytes at
`AF8Ah` now vs. `A5BAh` before: the xmem syscall bodies and the object
table) and the fixed core (8,335 required vs. 8,183: the 152-byte window
copy in the fixed core, where code that runs with the window showing
another bank has to live).

### `xmem-selftest` (simulator)

`build-xmem-selftest/zephyros-xmem-selftest.bin`, mapcheck
`OK (18 areas, 340 symbols)`; five replay assertions in
`tests/test_xmem_selftest_sim.py` all pass:

- the production boot lanes and the verdict: `xmem-selftest: 61 checks,
  0 failures` and `xmem-selftest: PASS`, with every one of the 61 outcome
  labels present exactly once and in the program's order;
- the nested exec from far context: `xmem-child: latch 11` (mode 10 over
  application bank 1, page 0), `xmem-child: PASS`, `exec-latch-restored`
  (the parent's token comes back exactly) and `exec-child-released` (the
  child's leaked objects are gone: capacity before == capacity after);
- the launcher's report `monitor: exit status 0x0000 active 0
  free-banks 6`: all six application banks are free again after exit, so
  the program's two live anchor objects (bank 5, slots 4-5) were released
  - the end-to-end exit-release proof.

Outcome coverage (the architecture 37 xmem and non-ZEX far-data rows):
sizes and slot rounding (1/8191/8192/8193), boundary and whole-object
transfers, range rejection (offset, length, straddle, buffer, end), stale
and foreign handles (free, read, info, reused index), the largest 32 KiB
object, no pre-zeroing, multiple objects per bank, fragmentation, both
exhaustion paths with release-refill, the token/address pair and its page
field, the non-mappable refusal, direct aperture access, aperture reads
through `SYS_XMEM_READ`, buffer identity in both directions, exec from a
path inside the aperture with P = 0 in the child, and exit release.

### `fs-selftest` and `subsystem-selftest` (no regression)

- `fs-selftest`: mapcheck `OK (18 areas, 345 symbols)`, 3 replay tests
  `OK`; the filesystem outcomes, the child lifecycle and the card-absent
  path are unchanged.
- `subsystem-selftest`: mapcheck `OK (18 areas, 389 symbols)`, 4 replay
  tests `OK` plus the 26 ROMFS replay tests `OK`; the boot-path
  acceptance groups, the process selftest (`process selftest: OK`,
  including `two-bank OK`, `raw return EFAULT`, `malformed rejected` and
  `corrupt entry rolled back`) and the monitor session are unchanged.

## Resolved during the package (two shared-tool defects, one test defect)

1. **Simulator: `DD/FD`-prefixed `ADD IX/IY,rr`.**  The first full replay
   ran away into the syscall gate: the program's `big[i] = handle` store
   landed on `E0E4h` (common code).  `tests/z80sim.py` decoded the
   prefixed opcodes with the unprefixed register table, so `ADD IY,IY`
   (`FD 29h`, SDCC's index doubling) added **HL** instead of IY.  Fixed:
   the prefixed forms answer the index register where the unprefixed
   encoding names HL.  Every image replay benefits; no image asserted the
   old (wrong) behaviour.
2. **Program test:** the exhaustion checks asserted `-ZOS_ENOSPC` after
   the fill helper had already freed the objects; the objects now stay
   held for the refusal and a `*-refill` outcome follows the release, so
   the refusal is observed while it exists and release is proven to
   return the capacity.
3. **Program test:** the buffer-identity checks wrote at offset `2000h`
   of an 8 KiB anchor (correctly `-ZOS_EINVAL`); rewritten in range and
   made sharper - the far-bank destination is verified twice, through the
   aperture and by handle, so a copy that resolved to the program's own
   bank at that address fails the check.  The child's `%02X` became
   `%02x` (the SDK printf has no `%X`).

`process_free_banks()` in `kernel/process/process.c` was also scoped to
the architecture 36.15 bank states (a bank is not free while a process
holds it as primary or while any of its slots is live): the M6
reservation used by the process acceptance test is a hold for a *future*
primary allocation, not a bank state, so it does not subtract from the
report - the M6 `process_idle_ok` two-bank check stays valid unchanged.

## Deferred (not this package)

- ZEX v2 and far-code segments (packages 44a/44b); `xmem-selftest` is
  structured to grow with them (the far-data rows that need no ZEX v2 are
  already covered).
- Hardware: the aperture is hardware-authoritative; the owner runs
  `build-xmem-selftest/zephyros-xmem-selftest.bin` on the board.  The
  simulator replay is the only automated evidence in this record.

## Supervisor review (2026-10-11)

**Accepted**, with hardware pending (owner: run
`build-xmem-selftest/zephyros-xmem-selftest.bin` on the board, since the
aperture is hardware-authoritative).
- Production `8886f154…`.
- `xmem-selftest` passes 61/61 outcome checks; fs and subsystem show no
  regression.
- Common memory is unchanged at 2,358, with the 3,072 ceiling enforced
  and the reservation field removed. The fixed core has 7,279 bytes free
  and the cold half 10,845.
- The simulator's `DD/FD` `ADD IX/IY,rr` decoding was fixed.

Open: objects are capped at **32 KiB**, while architecture 36.16 only
requires an object to be contiguous in one bank (up to 56 KiB across
slots 0-6). The record gives no reason. Package 45 justifies the cap in
the record or lifts it.
- **The 32 KiB cap is justified (2026-10-11).** It is derived from 36.16:
  slots 4-5 are reserved for mappable objects and far-code segments, and
  objects are contiguous, so a plain object's longest run is slots 0-3
  (32 KiB). This limit applies **per object** (one far block). It is
  not an application limit: a program may hold many objects. The mappable cap of 16 KiB is the aperture. Accepted as is;
  the numbers are written into 36.16 at M10 close (package 45).
