# M9 filesystem syscalls — validation (package 27)

**Package:** `27-m9-fs-syscalls` (2026-10-05)
**Scope:** expose the VFS to native programs: the global owner-tagged
descriptor pool, per-process CWD, the pinned `FS_*` syscall family
(`10h-1Fh`), the user runtime wrappers, and the `fstest.zex` acceptance
program (architecture sections 32.21–32.31, 32.32.5, 32.39 and 33;
`work/M9-REFERENCE.md`).

## What was implemented

- `include/zephyros/{errno,fs,syscall}.h`: the eight M9 errno values
  (already present from package 26) and the packed `zfs_*_args` syscall
  blocks plus the `FS_*` numbers, all pinned by `_Static_assert`.
- `kernel/vfs/process.c` (new): the 8-entry global descriptor pool and the
  4-slot 128-byte CWD pool; `vfs_process_start`/`vfs_process_exit`
  (idempotent, closes every owned descriptor), `vfs_chdir`/`vfs_getcwd`.
- `kernel/vfs/{path,mount,mutate}.c`: CWD-relative normalization
  (`vfs_path_normalize_at`); path resolution and `rename` resolve against
  the caller's CWD.
- `kernel/process/{process,exec}.c`: CWD allocation at launch (clean
  failure when the pool is full) and `vfs_process_exit` on every exit path
  (`SYS_EXIT`, raw-return `ZOS_EFAULT`, failed-launch rollback via
  `process_slot_release`).
- `kernel/syscall/fs.c` (new) + `kernel/syscall.c`: the 16 service bodies,
  the READY gate (`ZOS_EBUSY` before READY), complete argument/window
  validation, the 512-byte bank-7 staging buffer and the 64-byte common
  copy-gate bridge.
- `user/runtime/{zex_fs_runtime.asm,zex_fs_runtime.h,zos_fs.c}` (new): the
  gate stub and the `zos_*` C wrappers (local 127-byte path guard).
- `tests/target/m9/fstest/` (new): `fstest.zex` (suite) and `fstest_l.zex`
  (second-exec cleanup check); `tests/target/m9/m9_fs_test.c` launches both.

## Host and simulator validation

```text
make clean && make check                 OK (reproducible rebuild,
                                         production mapcheck OK)
make zmod-test                           43 tests OK (fixture prerequisite)
make zex-test monitor-test \
     m8-selftest m9-vfs-selftest \
     m9-provider-selftest m9-fs-selftest OK
python3 -m unittest discover -s tests -v 559 tests OK (141 skipped:
                                         image-dependent tests)
git diff --check                         clean
```

`tests/test_m9_fs.py` pins the syscall numbers (ABI header, kernel
dispatcher, runtime C and asm stub), the eight errno values, every
argument-block size/field offset, the runtime wrapper surface and the
build wiring.  `tests/test_syscall_sim.py` replays the linked
`m9-fs-selftest` image:

```text
fstest: namespace OK
fstest: romfs OK
fstest: ramfs OK
fstest: errors OK
fstest: pool OK
fstest: stale OK
fstest: writefail OK
fstest: exdev OK
fstest: window OK
fstest: PASS 9/9
fstest: launcher OK
m9 fs selftest: OK
```

The suite also asserts the descriptor pool is FREE and the CWD released
after both programs, and that the worst-case kernel gate-stack depth is
**151 of the 256 bytes** (`m9 fs: worst-case gate-stack depth 151 of 256
bytes`).

## Bank-7 ledger (section 32.39)

```text
before (package 26): code 23526 end 7BE6h | arena 46 granules (20 boot, 26 free)
                     | data 1501 | isr 256 | slack 291
after  (package 27): code 27636 end 8BF4h | arena 35 granules (20 boot, 15 free)
                     | data 3049 at D200h | isr 256 | slack 279
package delta:       +4110 _CODE, +1548 _DATA
m9-fs image:         code 27828 end 8CB4h | arena 34 granules (1 boot, 33 free)
                     | data 3050 at D200h | isr 256 | slack 278
```

The production arena clears the 32-granule floor (35) and holds the
20-granule production boot set; the slack target is re-checked after
package 28.

## Correction-01: one bank-7 VFS workspace

Package 27 shipped about 0.94 KB of avoidable bank-7 runtime data as six
separate pathname buffers plus a formatting buffer; under the derived data
base that came straight out of the module arena.  Correction-01 replaces
them with the single 512-byte `vfs_workspace` (`kernel/vfs/workspace.c`,
declared kernel-only in `kernel/vfs/vfs.h`) with a staging view and four
128-byte path slots, and removes the `chdir` build buffer, the boot-path
buffer and the required-mount formatting buffer.

Per-symbol `_DATA` removed (declared sizes):

```text
_fs_staging          512  kernel/syscall/fs.c    transfer staging
_fs_path1            128  kernel/syscall/fs.c    user-path copy-in A
_fs_path2            128  kernel/syscall/fs.c    rename copy-in B
_vfs_cwd_canonical   128  kernel/vfs/process.c   chdir build buffer
_vfs_norm            128  kernel/vfs/mount.c     normalized path A
_vfs_rename_target   128  kernel/vfs/mutate.c    normalized path B
_kernel_boot_path    128  kernel/main.c          /SYSTEM/<name>.zmod
_vfs_required_diag   168  kernel/vfs/mount.c     panic line format
                     ----
                     1448  removed
_vfs_workspace       512  kernel/vfs/workspace.c added
                     ----
net                        -936 bytes
```

Per-object `_DATA` sizes for the touched objects (`A _DATA size` in the
production `.rel` files, before -> after):

```text
kernel/syscall/fs.c   fs.rel           768 ->    0   (-768)
kernel/vfs/mount.c    vfs_mount.rel    357 ->   61   (-296)
kernel/vfs/process.c  vfs_process.rel  780 ->  652   (-128)
kernel/vfs/mutate.c   vfs_mutate.rel   128 ->    0   (-128)
kernel/main.c         main.rel         143 ->   15   (-128)
kernel/vfs/workspace.c vfs_workspace.rel  0 ->  512   (+512)
                                        ----
net                                            -936 bytes
```

`vfs_process.rel` keeps its 652 bytes of descriptor pool and CWD pool;
`vfs_mount.rel` keeps `vfs_mount_state` and the phase, `main.rel` keeps
`kernel_boot_file`.  The two accounting figures differ by the same two
bytes before and after: the packed bank-7 `data` line is
`l__DATA + l__INITIALIZED` (`tools/pack_image.py`), so `3049 -> 2113`
(`-936`) while the map `_DATA` area is `3047 -> 2111` (`-936`).

The `chdir` build buffer and the boot path buffers are gone rather than
replaced: `chdir` normalizes into workspace path slot 1, verifies with the
non-normalizing `vfs_stat_norm()` (so the slot is never read and written at
once) and copies once into the caller's CWD slot; the boot loader assembles
`/SYSTEM/<name>.zmod` in workspace path slot 0; the required-mount panic
line is written piecewise to the early console, byte-identical to
`panic()`'s output for the same text.

Ledger after correction-01:

```text
production:   code 27759 end 8C6Fh | arena 36 granules (20 boot, 16 free)
              | data 2113 at D600h | isr 256 | slack 191
              (_DATA 3049 -> 2113, -936; arena 35 -> 36 granules)
m9-fs-selftest:        code 28253 end 8E5Dh | arena 35 granules (1 boot, 34 free)
                       | data 2115 at D600h | isr 256 | slack 189
m9-provider-selftest:  code 31535 end 9B2Fh | arena 26 granules (1 boot, 25 free)
                       | data 3552 at D000h | isr 256 | slack 288
m9-required-mount-selftest: code 27791 end 8C8Fh | arena 36 granules
                       (20 boot, 16 free) | data 2113 at D600h | isr 256
                       | slack 191
```

`_CODE` rises by 56 bytes (the non-normalizing resolve/stat split and the
piecewise panic); only `_DATA` was constrained.  Production `_DATA` drops by
936 bytes (packed bank-7 data 3049 -> 2113; map `_DATA` area 3047 -> 2111)
and the arena gains a granule, both above the correction's 900-byte /
one-granule requirement.  Behavior is unchanged: `fstest` still prints
`PASS 9/9` and `launcher OK`, the required-mount panic text is
byte-identical, and the worst-case gate-stack depth *improves* from 151 to
**147 of 256 bytes** — the `READ`/`WRITE` handler releases the staging view
at a single `out:` exit and `READDIR` releases it inline, so neither needs a
bracketing wrapper frame on the deepest path.

The view guard is compiled in for the acceptance/simulator builds
(`-DZOS_VFS_WS_GUARD=1`, shared with the M8 acceptance images) and off for
production, so it costs the production image nothing.  Every claim site
brackets its use with `vfs_ws_enter()`/`vfs_ws_leave()`, the module-phase
boot loader included (`kernel/main.c`, path view), and a guarded image
panics with `vfs: workspace view overlap` on a nested claim.  Because
`tests/test_syscall_sim.py` replays the guarded `m9-fs-selftest` image, its
`test_workspace_views_are_released_and_never_overlap` is itself the
assertion that the invariant holds end to end: the replayed transcript
carries no `PANIC` and the `vfs_ws_view` counter is back at `0` when the
acceptance marker appears, which proves every claim site released and no two
views were ever live together during the whole run.

Validation runs for this correction:

```text
make clean && make check                                  564 tests OK
make m9-vfs-selftest m9-provider-selftest m9-fs-selftest \
     m9-required-mount-selftest                           all four OK
python3 -m unittest tests.test_m9_fs tests.test_syscall_sim \
     tests.test_m9_vfs tests.test_m9_vfs_sim \
     tests.test_m9_provider_sim -v                        70 tests OK
git diff --check                                         clean
```

The guard flag sits in the shared acceptance `CFLAGS` block, so the M8
acceptance images are rebuilt with it too; `make m8-selftest
m8-fallback-selftests` was re-run to confirm the M8 images and their
transcript replays still pass (12 tests OK, no ledger or transcript
change beyond the correction's own `_DATA` reduction).

`tests/test_m9_fs.TestVfsWorkspace` pins the correction: the header
declares one 512-byte workspace with the two views; the deleted buffers are
absent from every kernel source; the guard is off by default, on for the
`m9-fs-selftest` image, balanced at every claim site; the production map
carries exactly one workspace symbol, no pathname-shaped buffer and no
deleted symbol; and the production `_DATA` area is at least 900 bytes below
the package-27 baseline (the deleted buffers were file-local statics, so
their absence is asserted at source level while the map pins the one global
workspace symbol).

### Correction-01 hardware (production boot) — ACCEPTED (banner + display)

Image flashed: `build/zephyros.bin`, sha256
`1b3a31387035c4abafac33bc01e6b2e866ab35e15fa4cc2a3d5a2a53f7d9a006` (the
value `make smoke-hardware` preflights against), run by the operator on
Zephyr-80 hardware, 2026-10-05, with `picocom -b 115200` on the FTDI bridge
(`/dev/serial/by-id/usb-FTDI_FT230X_Basic_UART_DN03WYSA-if00-port0`) and the
V9958 display in view.  The correction's hardware gate is the production
boot only.

Serial transcript (RESET, exactly the early banner, 65 bytes):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
```

V9958 display, same boot (operator photograph, transcribed):

```text
console: dynamic sio0.b OK
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

The serial transcript is byte-identical to the accepted package-26 and
pre-correction package-27 boots.  The production image binds its console to
the V9958 output (architecture section 30.9), so `console: dynamic sio0.b
OK`, the monitor banner and the `Z80> ` prompt are rendered on the display
and never reach SIO — which is why the operator's console/monitor evidence
is the display, and why `make smoke-hardware` (`--mode normal`) always
reports FAIL on this V9958-bound bench (see the package-27 section below).

Interpretation: the full production boot set loaded with the consolidated
workspace (no `unavailable` diagnostic, no `PANIC`, no fault from the view
guard, which is compiled out of production anyway), `console_bind_defaults()`
bound HID input + VIDEO output, and the monitor reached its prompt.  The
`scratch=0F19` figure is identical to the pre-correction boot, so the
correction changed neither the monitor's view of the arena nor the boot
outcome.  This closes the correction's hardware gate; the traceable
behaviour evidence remains the simulator set above (guarded `m9-fs-selftest`
replay with the view counter back at 0, byte-identical required-mount panic,
unchanged `fstest` transcript, gate-stack depth 147).

The acceptance image (`build-m9-fs-selftest/zephyros-m9-fs-selftest.bin`,
sha256 `fa82baa83682d2e8a4a416bb16d429e13e0d587615f757156dec83654fc79030`)
was not reflashed for this correction; the correction's gate does not
require it and its guarded replay is covered by the simulator above.

## Physical acceptance

The two boots below were flashed and accepted for package 27; their hashes
are the pre-correction values, and the correction's own production boot is
recorded immediately above.

### Production boot (`make smoke-hardware`) — ACCEPTED (banner + display)

Image flashed: `build/zephyros.bin`, sha256
`2ebaf3488910f58309734795f4c7aeefd072afbb2b261cd4bb167584729ea20f`
(identical to the host build; the target preflight prints the same hash).

```sh
make smoke-hardware SERIAL_PORT=/dev/ttyUSB0
```

Serial transcript (65 bytes, exactly the early banner):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
```

V9958 display, same boot (operator photograph, transcribed):

```text
console: dynamic sio0.b OK
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

Interpretation: the full production boot set loaded (no `unavailable`
diagnostic, no `PANIC`), `console_bind_defaults()` bound HID input + VIDEO
output, the console acceptance line was rendered by the V9958 output, and
the monitor reached its prompt — the package requirement.

**`serial_smoke` reports FAIL here by design, not because of a package-27
regression.**  The transcript is byte-identical to the accepted package-26
result (`docs/validation/2026-10-05-m9-provider-abi-hardware.md` sections 4
and 5): the production image binds its console to the V9958 output
(architecture section 30.9), so `console: dynamic sio0.b OK`, the monitor
banner and `Z80> ` are rendered on the display and never reach SIO.
`--mode normal` requires those three lines *on the serial transcript*, so it
can only pass on an SIO-fallback bench.  Package 26 reported this as
"contract defect 2" and closed its production gate on the banner transcript
plus the V9958 photograph; this package follows the same accepted
convention.

Package 27 does not change that pass/fail contract (its own validator and
its `TestProductionSmokeMode` expectations are untouched).  It only adds an
actionable hint: on this failure the tool now prints to stderr that the
console is V9958-bound and points the operator at the display check
(`tools/serial_smoke.py`, `_explain_wrong_image`, mode `normal`), so the
next operator is not left with a bare `FAIL`.

### M9 FS acceptance image (`make smoke-hardware-m9-fs`) — PASS

Run by the operator on Zephyr-80 hardware, 2026-10-05.  The image is
SIO-only (`ZOS_IOC_BOOT=0`, `ZOS_HID_BOOT=0`, `ZOS_V9958_BOOT=0`), so its
console *is* SIO-bound and the whole acceptance transcript is
serial-visible.

Image flashed: `build-m9-fs-selftest/zephyros-m9-fs-selftest.bin`, sha256
`0900c04630c377aeabab7abcf7c3a39e35085b0c1274091e4b499821d8214784`
(the target preflight printed the same hash).

```sh
make smoke-hardware-m9-fs SERIAL_PORT=/dev/ttyUSB0
```

Serial transcript (323 bytes, 0 USB-bridge drops):

```text
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
console: dynamic sio0.b OK
fstest: namespace OK
fstest: romfs OK
fstest: ramfs OK
fstest: errors OK
fstest: pool OK
fstest: stale OK
fstest: writefail OK
fstest: exdev OK
fstest: window OK
fstest: PASS 9/9
fstest: launcher OK
m9 fs selftest: OK
serial_smoke: OK (the banner, 'fstest: PASS n/n' from the native suite,
'fstest: launcher OK' from the second-exec cleanup check, and
'm9 fs selftest: OK' with no FAIL/PANIC marker)
```

This closes every package-27 acceptance criterion on real hardware: the
whole pinned `FS_*` family works through the gate, `fstest.zex` passes, the
pool and CWD are released after the first program (proved by the
second-exec `fstest_l.zex`), and the boot still reaches the monitor.

### Recommended follow-up (supervisor decision)

`--mode normal` still cannot gate the HID+V9958-bound production boot it
exists for (confirmed a second time).  The clean fix is to make the
production serial contract the observable one (banner present, no `PANIC`,
no console-failure marker) and move the console/monitor evidence to an
explicit operator display check — which would require updating
`TestProductionSmokeMode` (its `test_banner_alone_is_not_enough` encodes the
current, unachievable-on-hardware expectation).  That is a cross-package
change to deliberately pinned behavior, so it is left for the supervisor to
authorize rather than made silently here.


## Note: build-order prerequisite

The documented sequence begins `make zex-test ...`; on a freshly cleaned
tree the `zex-fixtures` stamp needs the loader fixtures
`build/modules/m4_{probe,fail,filler}.zmod`, which `make zex-test` does not
declare as prerequisites (a pre-existing latent dependency, unrelated to
this package).  Running `make zmod-test` first (which builds them) makes
the documented sequence pass; no Makefile behavior was changed.

## Note: test-fixture arena retune

Package 27 adds about 5.9 KiB of resident kernel code and data, so the
derived data base moves down and every image's arena shrinks (production
`46 -> 35` granules).  The test-only writable provider `ramfs`
(`tests/modules/ramfs.c`) allocates 29 granules at 4096 bytes of file data
per instance, which no longer fit the `m9-provider-selftest` arena
(`25 granules`, short by four).  Its bounded storage is therefore reduced
to 2048 bytes per instance, which still covers the largest case any
acceptance program uses (`fstest` writes up to 513 bytes; the provider
test's cumulative `/SIZES` set peaks at 1921 bytes because its unlink does
not reclaim bump-allocated data).  No assertion, expected output or test
was weakened; `make m9-provider-selftest` passes again (`ramfs` now
21 granules, exactly filling the four free granules with SIO and the three
registration fixtures).
