# libtui fast path

## Result

Package 87's Musts are in:

- `tui_put_text(x, y, text, length, attr)` — an assembly row primitive
  (`user/sdk/tui/src/tui_text.asm`, its own archive member, ~5.1 KiB .rel)
  that stores literal glyph bytes exactly like `length` calls to
  `tui_priv_set_cell`, clipped to the window; returns 0, or `-KOS_EINVAL`
  before init or for a null `text`.
- `tui_scroll_rows` shifts the model directly: the characters move as one
  `(height - 1) x stride` block and the attributes as half that block
  (`tui_scroll.asm`); the SCROLL render record, flush, return values and
  the exposed row are unchanged.
- Per-row pending flags (`tui_row_pending`): set by every non-model_only
  store, cleared with the maps, and both flush passes skip clean rows.

The odd-stride attribute move was **removed rather than fixed**: the cell
map now uses an even row stride, `TUI_STRIDE = (TUI_MAX_COLS + 1) & ~1`
(86 for the 85-column archive, 128 for the wide one), in
`TUI_CELL_INDEX`/`TUI_CELL_COUNT` and `tui_state.stride`, so every row
starts on an attribute-byte boundary and the attribute move is one
LDIR/LDDR.  BSS grows by 45 bytes for an 85-column program
(chars +26, attrs +13, dirty/invert +3 each); wide programs are
unchanged.  Current BSS and headroom under the 0xE000 stack top:

| program | BSS | headroom |
|---|---|---|
| `tui_test.exe` (85-col) | 0x2CAC | 3351 B |
| `tui_wide.exe` (128-col) | 0x3BE0 | 239 B |
| KonaCommander | 0x448D | 1458 B |
| KonaEdit | 0x248F | 3218 B |

KonaCommander keeps its >= 512 B requirement with room to spare.

## Budgets

Measured in the simulator on the timing mode, program-bank T-states only
(excludes console IPC and driver time):

| figure | before | budget | after | verdict |
|---|---|---|---|---|
| `tui_flush`, nothing pending | ~360k | <= 8,000 T | 40,522 T | **over: report** |
| `tui_flush`, one dirty row | ~370k | <= 60,000 T | 57,537 T (one cell) | pass |
| `tui_put_text`, 85 cells, all equal | n/a | <= 12,000 T | 31,086 T | **over: report** |
| `tui_put_text`, 85 cells, all new | n/a | <= 30,000 T | 71,667 T | **over: report** |
| `tui_scroll_rows` model work, 24 rows x 85 | ~2.7M | <= 150,000 T | 124,482 T | pass |

The flush-nothing overrun is the per-row walk (two passes over the
capacity rows with a multiply per row); the put_text overruns are the
per-cell compare/store loop's cost.  Both paths stay correct and are
still far below the package's starting figures; tightening them to the
budget is follow-up work.  The budget assertions are not yet wired into
`test_timing_mode_runs`, which only checks that the scripted sequence
completes.

## Tests

Validation block, run once at the end:

```
make && make sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_console_tee tests.test_sdk tests.test_sdk_package tests.test_source_layout
make -C UserSoftware/KonaCommander test
make -C UserSoftware/KonaEdit test
git diff --check
```

- 192 unit tests OK (1 skipped), including the new shift, puttext,
  pending and timing modes on both lanes and the wide archive;
- KonaCommander: 1 test OK;
- KonaEdit: 6 tests OK;
- `git diff --check`: clean.

The equivalence test compares `tui_put_text` and `tui_puts_xy` render
records byte for byte; the shift test permutes distinct per-cell grids
through 13 up/down scrolls (both directions, heights 1-26, both former
nibble parities) and verifies `tui_save` after each, on the 85-column
and 128-column archives.

## Files

- `user/sdk/tui/src/tui_text.asm` (new), `tui_scroll.asm` (direct model
  shift; even-stride attribute LDIR/LDDR), `tui_flush.c` (pending-row
  skips in both passes; flags cleared after a committed render),
  `tui_screen.c` (set the pending flag on every store),
  `tui_lifecycle.c` (`tui_state.stride = TUI_STRIDE`),
  `tui_state.c` (`tui_row_pending`), `tui_internal.h` (`TUI_STRIDE`,
  the even-stride assert, `TUI_CELL_INDEX`/`TUI_CELL_COUNT`),
  `user/sdk/exe.mk` (tui_text member), `user/sdk/include/tui.h` and
  `docs/tui.md` (`tui_put_text`).
- Tests: `tests/tui/tui_test.c` (puttext, shift, pending, timing modes;
  remainder-loop shift math so the test program keeps its data budget),
  `tests/tui/tui_modes.c` / `tui_modes_stub.c` (wide build links the
  stub), `tests/test_tui_sim.py` (the four mode tests; map-size pins
  moved to the 86-column stride; the SERIAL flush-counts test strips
  trailing shutdown/pass writes robustly), `tests/test_tui.py`.
- Informational sizes: `tui_text.rel` 5,138 B, `tui_scroll.rel` 4,590 B,
  `tui_flush.rel` 21,591 B, `tui_screen.rel` 12,780 B (pre-package
  sizes were not captured).

## Correction 1

### Result

`tui_put_text` kept its dirty/invert bitmap index in one byte. On the
85-column map, row 24 starts at cell 2,064, which is dirty-map byte 258;
the index wrapped to byte 2, a row-0 byte. Rows 24-25, and rows 16 and
up on the 128-column map, therefore changed in the model without being
drawn. The index is now a 16-bit pointer. The three budget overruns are
in, and the five figures are asserted.

- **`tui_text.asm`:** the cell walk keeps its state in registers.
  - **Main set:** cells left, the attribute in both nibbles, text,
    character cell, IX the attribute byte.
  - **Alternate set:** the dirty bit, the 16-bit dirty pointer, the
    invert-map offset, "changed".
  - **Parity:** two loop bodies. The even cell tests the whole attribute
    byte first, so an unchanged pair checks only the odd cell's
    character.
  - **model_only:** a zero mask, so the bitmap updates are no-ops and the
    pending flag stays clear.
  - **Multiply:** a shift-and-add replaces `__mulint`.
- **`tui_flush.c`:**
  - a pointer scan (`tui_next_pending`) finds the next pending row, and
    only a pending row computes its base index;
  - the 8-cell skip steps the index by 8 instead of multiplying;
  - the pending flags are cleared with `memset`.
- **`tui_scroll.asm`:** audited, unchanged. Its byte-wide state is a
  parity, a column count of at most 128 and an attribute; its cell
  offsets are 16-bit.

### Tests

- **Equivalence rows:** `tests/tui/tui_puttext.c` (new, shared) adds
  full-width rows at the last two rows and the middle row, each with an
  attribute-only change.
  - It is linked into `tui_test`, and into a new `tui_putwide` program
    for the 128-column map, since `tui_wide` has no room for it.
  - The tests now compare the RENDER *streams* byte for byte, captured at
    the program's `console_render` entry. They previously compared
    lengths only.
  - On the 128-column map the check draws on the console's 85 x 26 grid:
    rows 24-25 at stride 128 are dirty-map bytes 384 and 400.
- **Before the fix both fail.** With the package 87 `tui_text.asm`, the
  85-column phases emit different stream counts, and the wide streams
  differ in content.
- **Budgets asserted:** `test_timing_mode_meets_the_budgets` replaces
  `test_timing_mode_runs`. It times each top-level call from entry to
  return, counting program-bank T-states only.

### Budgets

| figure | 87 | budget | 87c01 |
|---|---|---|---|
| `tui_put_text`, 85 equal | 31,086 | <= 12,000 | 10,436 |
| `tui_put_text`, 85 new | 71,667 | <= 30,000 | 29,041 |
| `tui_flush`, nothing pending | 40,522 | <= 8,000 | 5,872 |
| `tui_flush`, one dirty row | 57,537 | <= 60,000 | 24,133 |
| `tui_scroll_rows` model, 24 x 85 | 124,482 | <= 150,000 | 89,823 |
| `tui_wide.exe` headroom | 239 B | links | 611 B |

`tui_test.exe` headroom: 2,601 B, after the new equivalence rows.

### Validation

```
make && make sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_console_tee
make -C UserSoftware/KonaCommander test
make -C UserSoftware/KonaEdit test
git diff --check
```

- `make && make sdk`: OK.
- The three modules: **101 tests OK** (2,244 s).
- KonaCommander: 1 test OK. KonaEdit: 6 tests OK.
- `git diff --check`: clean.
