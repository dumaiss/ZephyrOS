# libtui storage and capacity

## Result

Every TUI program has room again and chooses its grid capacity:

- the cell map is one byte per character plus a 4-bit attribute per cell
  (two cells per byte), 1,105 bytes less static storage at 85 x 26;
- `console_info` zeroes the request once instead of field by field;
- `tui_init` clamps the reported grid to the capacity (only a zero
  dimension is refused), so a program on a larger console uses the
  top-left part;
- `TUI_GRID=<cols>x<rows>` in a program's rule options selects the libtui
  archive: `85x26` (`libtui.lib`, the default) or `128x35`
  (`libtui_128x35.lib`, built and shipped in the SDK); any other grid
  stops the build.

KonaCommander, which package 80 left 188 bytes over its stack, links again
with **868 bytes** of headroom.

## Files

- `user/sdk/tui/src/tui_internal.h` (capacity from `TUI_GRID_COLS/ROWS`,
  default 85/26; the attribute store and its accessors), `tui_state.c`
  (`tui_chars`, `tui_attrs`, `tui_priv_attr`, `tui_priv_store`), and
  every access in `tui_flush.c`, `tui_screen.c`, `tui_window.c`,
  `tui_region.c`, `tui_lifecycle.c` (also the clamp). `struct tui_cell`
  stays the save/restore format. `tui_append_dec` takes three digits (a
  128-column grid's columns).
- `user/sdk/src/console_info.c` - `memset` + op + call + copy.
- `user/sdk/exe.mk` (`libtui_128x35.lib`), `mk/kos.mk` (`TUI_GRID`,
  `KOS_TUI_GRIDS`), `tools/sdkpack.py` (`--libtui-wide`), `Makefile`
  (the tarball rule; `tui_wide`, the outcome program built with
  `TUI_GRID=128x35`).
- `tests/tui/tui_test.c` (`gridsize` mode), `tests/test_tui_sim.py`
  (clamp and wide-build tests, `tui_wide.exe` in the replay store),
  `tests/test_tui.py`, `tests/test_sdk.py`, `tests/test_sdk_package.py`.
- Docs: `docs/tui.md` (capacity, clamp, memory table), `docs/sdk.md`
  (the rule option, the archive), `docs/architecture.md` 5.6.

## Requirement results

1. **Attribute store.** Link map of `tui_core_probe`: `_tui_chars` 2,210,
   `_tui_attrs` 1,105, `_tui_dirty` 277, `_tui_invert` 277 (was one
   4,420-byte `tui_cells`); pinned by
   `test_tui.TestTuiLink.test_one_cell_map_and_two_classification_bitmaps`.
2. **console_info.** Built with `memset`; KonaCommander's code grew 129
   bytes over package 80's baseline while its BSS fell 1,105.
3. **Clamp.** 90 x 30 reported: `tui: grid size 85x26`, the fill stays in
   85 x 26 (both lanes).
4. **TUI_GRID.** `tui_wide` (TUI_GRID=128x35): 128 x 35 reported ->
   `screen 128x35`, 90 x 30 -> `screen 90x30`; checked with the shipped
   SDK too: `85x26` links `libtui.lib`, `128x35` `libtui_128x35.lib`,
   `99x9` stops with "TUI_GRID=99x9 is not one of 85x26 128x35". Wide
   drawing is not checked: no console displays 128 columns.
5. **Docs.** As listed.

## Budgets

| figure | before | after |
|---|---|---|
| KonaCommander BSS end vs stack base (DC80h) | 188 over | 868 under (DD3Ch -> D91Ch) |
| `konacmd.exe` | does not link | 37,884 bytes |
| `tui_dialog.exe` | 21,300 | 21,378 |
| `tui_test.exe` | 37,647 | 38,012 (with `gridsize`) |

## Pins changed, with their sources

- `test_tui.TestTuiLibrary.test_flush_groups_runs_by_attribute_and_emits_both_sgr_forms`
  and `test_tui.TestTuiLink.test_one_cell_map_and_two_classification_bitmaps`:
  the 2-byte `tui_cells` became `tui_chars` + `tui_attrs` (`WORK.md`
  requirement 1).
- `test_sdk.TestSdkBoundary.test_every_program_is_declared_once_by_the_generic_rule`:
  the list gains `tui_wide` (requirement 4).
- `test_tui_sim` 90 x 30: "fails init" became "clamped to 85x26"
  (requirement 3).
- `test_sdk_package`: the file list and the repack call gain
  `libtui_128x35.lib`.

## Validation

```sh
make && make sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_sdk tests.test_sdk_package tests.test_console_tee tests.test_source_layout
make console-serial-selftest
make -C UserSoftware/KonaCommander test
make clean && make check
git diff --check
```

- Batch: 185 run, 3 failed (the pins above), retargeted; `test_tui` +
  `test_sdk` 56 OK; the replay suites passed.
- `make clean && make check`: **882 tests, `make check: OK`** (2,375 s);
  reproducible rebuild (0cea638a5526ef9e10b00d8f847fc2f9fc8a7c2266ba6435178c0b8f25ac76a2).
- `make console-serial-selftest`: OK.
- KonaCommander: host 10, project 7, UI replay 1 OK.
- `git diff --check`: clean.
