# M9 — VFS bootstrap and the ROMFS provider (`25-m9-vfs-bootstrap-romfs`): validation record

Date: 2026-10-04 (work package 25, worker pass)

Status: **host validation and simulator acceptance passed** on a clean
tree (frozen sequence in section 4; every target exit 0, final discovery
647 tests, 0 failures, 185 skips).  **Physical acceptance: PENDING** — no
Zephyr-80 bench session was available in this pass; section 5 records the
exact image and hashes to replay.

## 1. Delivered change

- `include/zephyros/fs.h` — M9 native metadata ABI: `ZOS_PATH_MAX` 128,
  `ZFS_NAME_MAX` 64, `ZFS_TYPE_*`, `ZFS_ATTR_*`, `ZFS_TIME_UNKNOWN`,
  `struct zfs_stat` (16 bytes), `struct zfs_dirent` (80), `struct
  zfs_statfs` (12), `ZFS_O_*`, `ZFS_SEEK_*` (all `_Static_assert`-pinned).
- `include/zephyros/vfs.h` — module-facing provider ABI
  (`struct zfs_open_info`, `struct zfs_ops` with the 20 section-32.12
  operations, `struct zfs_provider`).
- `kernel/vfs/mount_config.h` — kernel-private generated-table contract
  (`VFS_MAX_MOUNTS` 4, `VFS_MOUNT_*`, `struct vfs_mount_config`).
- `kernel/vfs/` — `path.c` (normalization, case-insensitive compare),
  `mount.c` (registry capacity 4, runtime state, longest-match
  resolution, the four lifecycle phases, `vfs: <path> unavailable 0xNN`
  diagnostics), `file.c` (resolve-node, kernel file API, `zmod_source`
  adapter), `dir.c` (directory API, root enumeration), `vfs.h`
  (kernel-only API).
- `fs/romfs/romfs_provider.{c,h}` — ROMFS provider over the unchanged M5
  reader: case-insensitive lookup, `object_id` = entry index + 1,
  READONLY, `ZFS_TIME_UNKNOWN`, statfs, `ZOS_ENOTDIR`/`ZOS_EROFS`/
  `ZOS_EISDIR`/`ZOS_EMFILE`, `source == "recovery"`.
- `kernel/romfs/romfs.c` / `include/zephyros/romfs.h` — added
  `romfs_lookup_ci`, `romfs_entry_at`, `romfs_count`,
  `romfs_total_bytes`; **removed `romfs_load_zmod()`** and its source
  adapter (`romfs_load_zmod` no longer exists anywhere in the tree).
- `tools/mountgen.py`, `config/mounts.json`, `tests/m9/mounts-*.json` —
  the generated, host-validated static mount table.
- `kernel/main.c` — `vfs_init()` + system mount before any module load,
  `kernel_load_vfs_module()` for `/SYSTEM/<name>.zmod`, `vfs_mount_all()`,
  monitor launch through `/SYSTEM/monitor.zex`.
- `kernel/process/exec.c` / `include/zephyros/process.h` — `process_exec()`
  takes a VFS path and reads through the kernel file API; the kernel-only
  `VFS_O_EXEC` hint preserves the M6 `ZEX_EXEC_ERR_TYPE` rejection.
- `tools/romfspack.py` — rejects `/` in names and case-insensitive name
  collisions.
- `tools/mapcheck.py` / `tools/pack_image.py` — `--min-granules`
  override, `_vfs_`/`_romfs_provider` bank-7 placement checks.
- `Makefile`, `linker/zephyr80.lk` — VFS objects, the generated-table
  rule, `ZOS_ARENA_MIN_GRANULES`, `m9-vfs-selftest`,
  `m9-required-mount-selftest`.
- `tests/test_m9_vfs.py`, `tests/test_m9_vfs_sim.py` (optional *and*
  required mount outcomes), `tests/target/m9/m9_vfs_test.c`,
  `tests/target/include/m9_selftest.h`.
- Documentation: `docs/vfs.md` (new), `docs/{boot,romfs-format,memory,
  devices,module-format,architecture,filesystem}.md`, `README.md`.

## 2. Requirement coverage

| Requirement | Evidence |
| --- | --- |
| `/SYSTEM` mounted before any module load | `tests/test_m9_vfs_sim.py` boot transcript |
| every boot ZMOD + the monitor loaded by VFS path | `tests/test_m9_vfs_sim.py`, `tests/test_m6_sim.py`, `tests/test_m7_sim.py` |
| `romfs_load_zmod()` removed, no parallel loader | source/layout tests, `tools/mapcheck.py` |
| mount-config validation rejects every 32.5.1 case | `tests/test_m9_vfs.py` (mountgen negatives, all `tests/m9` manifests) |
| M5-M8 acceptance output unchanged | M5/M6/M7/M8 target replays (section 4) |
| normalization, CI resolution, per-entry read byte-compare, root enumeration, `stat("/")`, `stat("/SYSTEM")`, ENOENT/ENOTDIR/EROFS | `tests/test_m9_vfs_sim.py` + `m9-vfs-selftest` target transcript |
| optional-mount failure tolerated and diagnosed | `vfs: /DATA unavailable 0x03`, boot continues (`tests/m9/mounts-optional-fail.json`) |
| required non-system mount failure is fatal | `m9-required-mount-selftest`: same line, then `PANIC: vfs: mount failed`, monitor never runs (`tests/m9/mounts-required-fail.json`) |
| production arena gate | `tools/mapcheck.py --production`: 32 granules, `__kernel_code_end` `7EE6h` |

## 3. Budget report (M9-REFERENCE requirement)

```text
production _CODE                2000h..7EE3h (area size 24291 bytes)
production __kernel_code_end    7EE6h
production _DATA                C000h..C4BAh (1210 bytes) + _INITIALIZED 2 bytes
production _COMMON              E000h..E411h (1041) + _COMMON_DATA 503 bytes
derived arena                   8000h..C000h = 16384 bytes = 32 granules (gate)
boot set                        21 granules used, 11 free (sio 1, ioc 8, hid 2, v9958 10)
acceptance images               26..32 granules, boot set 21 (docs/vfs.md section 10)
```

Production headroom to the gate is small: `__kernel_code_end` is `7EE6h`
and the arena drops to 31 granules at `8000h`, i.e. **154 bytes**.  This
is inherent to linking the M9 VFS core into a bank-7 image that must
still hold a 21-granule boot set, and it is the number the later M9
packages (26-31) have to work against.

## 4. Validation sequence

```sh
make clean && make check
make romfs-test zex-test monitor-test m5-selftest m5-corrupt-selftest \
     m6-selftest m7-selftest m8-selftest m8-fallback-selftests m9-vfs-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod build/modules/monitor.zex
make clean && git status --short
```

Observed results (final revision, clean tree): `make check` reports a
reproducible rebuild (`6602cd97...c72b8`), `mapcheck --production` OK with
`__kernel_code_end` `7EE6h` and 32 granules, and 654 host tests with 0
failures (187 skips without the acceptance images built).  A standalone
`python3 -m unittest discover -s tests -v` with every acceptance image
present reports 649 tests, 0 failures, 45 skips (the skips are the
M4/M5 image replays whose images are not part of this package's target
list).  Every target in the list above exits 0, as do the extra targets
below.

Unrequested but run for completeness: `m6-failure-selftest`,
`m8-ioc-selftest`, `m8-hid-selftest`, `m8-hid-noioc-selftest`,
`m8-hid-badioc-selftest`, `m8-v9958-selftest`,
`m8-v9958-fontfail-selftest`, `m8-console-selftest`,
`m9-required-mount-selftest`, and the pre-M5 images
(`syscall-selftest`, `irq-selftest`, `m3-selftest`,
`m4-loader-selftest`, `m4-selftest`, `m4-placement-selftest`,
`m4-failure-selftest`).

## 5. Physical acceptance (PENDING)

Image to flash: `build/zephyros.bin` (524288 bytes, SHA-256
`6602cd975104cdc9ccc27830d86a0c4d5588031c12e37148e72a8a4e966c72b8`).

Replay: `make smoke-hardware-m8 SERIAL_PORT=/dev/ttyUSB0` (the serial
transcript must match the accepted M8 boot) plus the human HID/V9958
monitor pass.  No bench session was available in this pass, so the
physical gate is recorded **PENDING**; production ROM bytes changed
relative to M8, so the M8 hardware evidence does not carry over.

## 6. Artifacts

```text
build/zephyros.bin            6602cd975104cdc9ccc27830d86a0c4d5588031c12e37148e72a8a4e966c72b8
build/modules/sio.zmod        bf9a638517488b72e1621c495f098905f73e157fd20dcc9467d465298786877d
build/modules/ioc.zmod        808b6d5e986b7abbc06b943264a8ef277b60b9f288d5ebb66b5e186a27d77ca3
build/modules/hid.zmod        bd7e3933f669f544e6d5b9fb3f1ff6670d773545041545a8fa7619915193ef11
build/modules/v9958.zmod      6d35c218ff2c8f65b58bd2cdfbe0c5db5bc7302a4827074d062933d62f8897c8
build/modules/monitor.zex     67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed
build/modules/fakeioc.zmod    b16e203966aa555fb4fdb9a8ac900a0466d77f8c24f92783e6bf779d3e074aa4
build/modules/m8regfill.zmod  5582938adefd91f6cb18153e852b2f350cde86363ffc1121a0c8e70f1f041494
build/recovery.romfs sha256   184fbb7e74bf666202ab552d0bbbea392e48d8abfc4a91fb7f7adccab61bbfdb
build-m9-vfs-selftest/              kernel end 8AB1h, 26 granules
build-m9-required-mount-selftest/   kernel end 7F06h, 32 granules (production gate)
build-m8-selftest/                  kernel end 8B69h, 26 granules
build-m4-placement-selftest/        kernel end 6E9Bh, fixed arena 9E00h-BDFFh (legacy)
build-m4-failure-selftest/          kernel end 5B82h, fixed arena A000h-BFFFh (legacy)
```

`monitor.zex` is byte-identical to the M7 oracle
(`67574d57...a643ed`, 3546 bytes); the four ZMOD hashes are unchanged
from M8.

Every figure in this block and in section 3 was re-measured in the
correction-01 pass.  The two M9 lines originally carried
`8B2Eh`/`7F83h` from a build taken before the last
`kernel_load_vfs_module()` simplification of this same pass, and the two
M4 lines carried `909Ch`/`7D83h` from a build that still linked the dead
VFS code that correction-01 removed (section 9).  Production (`7EE6h`,
`6602cd97...`) and `build-m8-selftest` (`8B69h`) are unchanged between
the measurements.

## 7. Deviations from the package contract

1. **M9 error codes added early to `include/zephyros/errno.h`.**  The
   eight M9 codes (`ZOS_EEXIST` 0x10, `ZOS_ENOTDIR` 0x11, `ZOS_EISDIR`
   0x12, `ZOS_ENOTEMPTY` 0x13, `ZOS_EROFS` 0x14, `ZOS_ESTALE` 0x15,
   `ZOS_EXDEV` 0x16, `ZOS_EMFILE` 0x17) are nominally package
   `27-m9-fs-syscalls`' ownership; the VFS core cannot compile without
   them.  Package 27 must extend, not redefine, the list.  `ZOS_ENODEV`
   (0x03) is reused for "no filesystem at `/`".
2. **Acceptance-image arena floor relaxed to 16 granules.**  The M9 VFS
   core plus a target test hook cannot hold the 32-granule gate on top of
   the 21-granule boot set.  `ZOS_ARENA_MIN_GRANULES` is 16 when
   `TARGET_TEST_OBJS` is non-empty and stays 32 for production and for
   the hook-free required-mount image.  The safety net is unchanged:
   `tools/zmodpack.py plan` must fit the boot set and
   `tools/pack_image.py` reconciles the manifest against it.
3. **`make m9-required-mount-selftest` is a new target.**  WORK.md asks
   that required non-system mounts already work (attempt, tolerate *or
   panic*) and names only the optional-mount proof; the required path is
   the fatal one, so it is proven from real linked bytes by a hook-free
   image that keeps the production arena gate.
4. **M8 v9958 simulator scratch moved out of the arena.**
   `tests/test_v9958_sim.py` placed its 4-KiB host payload at `A000h`
   ("free arena above the boot set").  The shrunken derived arena now
   reaches `B200h`, so that payload overwrote a loaded module and the
   long-block test hung.  The scratch moved to `C500h` (the bank-7
   runtime tail between the kernel `_DATA`/BSS end and the `DF00h` ISR
   stack), which no allocator owns.  No assertion, image or transcript
   changed.
5. **Pre-M5 `ZOS_ROMFS_BOOT=0` images linked the VFS core as dead
   code, which the correction below removed.**  `git diff --check` is
   clean and `make clean && git status --short` shows only the intended
   source/config/doc changes (no generated artifacts).  A later package
   that needs these historical images literally free of VFS bytes should
   gate `$(VFS_OBJS)` and `exec.c` on `ZOS_ROMFS_BOOT=1` and gate the
   mapcheck M6/VFS presence checks the same way; package 25 keeps the
   shared object set to avoid changing the historical entries.
6. **Files touched outside the WORK.md `Files` list** (minimal):
   `include/zephyros/errno.h` (deviation 1), `tools/pack_image.py`,
   `linker/zephyr80.lk`, `kernel/module/{loader,embedded}.c` (comments),
   `tests/target/include/m9_selftest.h`,
   `tests/target/support/target_test.c`, `tests/target/m6/m6_test.c`,
   `tests/test_{romfs_sim,m1,romfs,ioc,hid,v9958,v9958_sim}.py`,
   `tests/test_docs_evidence.py` (live-document set now includes
   `docs/vfs.md`), `docs/{devices,module-format,filesystem}.md`,
   `README.md`.

## 8. Open items for the supervisor

- Production headroom to the 32-granule gate is 154 bytes (section 3).
  Packages 27 (syscall family), 29 (block class) and 30 (IOC-FAT
  provider) add bank-7 code; the gate is a stop-and-report condition, so
  the M9 budget strategy needs a decision before those land.
- The legacy fixed-arena images (`m5-selftest` `A000h-BFFFh`,
  `m4-placement-selftest` `9E00h-BDFFh`) have the same growth pressure
  and no derived-arena mechanism of their own.
- Hardware: M9 package 25 is `PENDING`; the production image hash is in
  section 5.

---

# 9. Correction-01 — the embedded-catalog images must stay VFS-free

Date: 2026-10-04 (work package 25, correction pass 1)

Package 25 linked the M9 VFS core, the generated mount table and the ROMFS
provider into *every* image, including the `ZOS_ROMFS_BOOT=0`
embedded-catalog images (M1-M4 acceptance), where the code can never run.
That contradicted the package contract ("Keep the embedded-catalog path for
`ZOS_ROMFS_BOOT=0` untouched and VFS-free") and cost those historical
images ~7.8 KiB of dead code.  Correction-01 removes it.

## 9.1 Delivered change

- `Makefile` — the M9 object group is now the named variable
  `M9_VFS_OBJS` (`vfs_mounts`, `vfs_path`, `vfs_mount`, `vfs_file`,
  `vfs_dir`, `romfs_provider`), referenced once from `C_OBJS` and removed
  again by `C_OBJS := $(filter-out $(M9_VFS_OBJS),$(C_OBJS))` inside the
  existing `ifeq ($(ZOS_ROMFS_BOOT),0)` selection block.  The variable
  stays where it was, so the ROMFS-boot link order is unaffected and the
  `filter-out` keeps every remaining object in order.
- `kernel/process/exec.c` — `process_exec()` keeps its package-25 path
  signature, but the VFS body is compiled only when `ZOS_ROMFS_BOOT=1`;
  the `#else` branch restores the M6 direct-ROMFS-reader body verbatim
  (and includes `zephyros/romfs.h` instead of the kernel VFS header), so
  an embedded image references no VFS symbol.
- `kernel/romfs/romfs.c` — the M9-only additions (`romfs_name_match_ci`,
  `romfs_lookup_ci`, `romfs_entry_at`, `romfs_count`,
  `romfs_total_bytes`) are compiled only when `ZOS_ROMFS_BOOT=1`.  An
  object-list change cannot split one translation unit, so this is the
  narrowest available mechanism; the guard is a plain `#if`/`#endif`
  around the two adjacent blocks and changes nothing for ROMFS-boot
  builds.
- `tools/mapcheck.py` — the checker classifies a map by its embedded
  catalog symbols (the catalog is linked exactly when
  `ZOS_ROMFS_BOOT=0`) and then applies one of two exclusive rule sets:
  a ROMFS-boot image must define the whole VFS list plus the M9 ROMFS
  accessors (`VFS_BANK7_ROUTINES`, `ROMFS_M9_ROUTINES`), and an
  embedded-catalog image must define **none** of
  `VFS_FORBIDDEN_PREFIXES` (`_vfs_`, `_romfs_provider`, `_romfs_op_`,
  `_romfs_dir_`, `_romfs_node_` and the four M9 accessors).  The
  classification is derived from the map itself, so no build flag can
  silently disable it.
- Tests — `tests/test_romfs.py` gains a coherent embedded-catalog fixture
  (`embedded_catalog_map()`, which drops VFS-only symbols through
  mapcheck's own prefix list), a positive control, and
  `test_embedded_catalog_image_rejects_vfs_symbols` covering the kernel
  VFS, the generated table, the provider and every M9 accessor;
  `tests/test_m4.py` sweeps every real embedded image map for VFS symbols;
  `tests/test_m9_vfs.py` (`TestVfsObjectGating`) asserts on the Makefile
  itself that the group is defined once, used once and dropped for
  `ZOS_ROMFS_BOOT=0`, and that the three shared sources keep their
  compile-time selection.  `tests/test_m1.py`'s synthetic map fixture is
  now a coherent ROMFS-boot image (its default no longer carries catalog
  symbols) and grew a `drop_prefixes` option for the embedded fixture.
- `docs/vfs.md` (sections 6, 10.1, 11) records the rule and the measured
  geometry.

## 9.2 Baseline comparison

Baseline worktree: `3dedd09` ("Correction packages"), built with the same
`make` targets.  Byte comparison, SHA-256:

| Image | Corrected SHA-256 | Baseline SHA-256 |
| --- | --- | --- |
| `zephyros-selftest.bin` | `96d036a8078bd9ce…` | `967c4beaee7ff902…` |
| `zephyros-irq-selftest.bin` | `9d74ce67c39749db…` | `fdb480f6d9b34e93…` |
| `zephyros-m3-selftest.bin` | `bee9fb0ec34f8c4f…` | `0916ee70bbb0b6c7…` |
| `zephyros-m4-loader-selftest.bin` | `fd0730d378cbabbc…` | `6abe5d1964f36a35…` |
| `zephyros-m4-selftest.bin` | `ea77b5782057b392…` | `00da4f54cfa19f25…` |
| `zephyros-m4-placement-selftest.bin` | `e548ba53a9177c8c…` | `17097769d3b01b9c…` |
| `zephyros-m4-failure.bin` | `0b3af50bebe84322…` | `e5835d58951f9954…` |

(First 16 hex digits of the full SHA-256, which is what section 9.3's
attribution accounts for.  Byte identity was not expected: see 9.3.)

`_CODE` end (`_irq_kernel_code_end`), corrected vs baseline:

| Image | Corrected | Baseline | Delta |
| --- | --- | --- | --- |
| syscall-selftest | `5BE0h` | `5CA4h` | -196 |
| irq-selftest | `60F6h` | `61BAh` | -196 |
| m3-selftest | `6AC3h` | `6B87h` | -196 |
| m4-loader-selftest | `6E9Bh` | `6F5Fh` | -196 |
| m4-selftest | `701Dh` | `70E1h` | -196 |
| m4-placement-selftest | `6E9Bh` | `6F5Fh` | -196 |
| m4-failure | `5B82h` | `5C46h` | -196 |

VFS symbols in any corrected embedded image: **none** (checked by symbol
prefix across all seven maps, and enforced by mapcheck on every build).

## 9.3 Difference attribution, by symbol and section

The correction removes 7.8 KiB of VFS dead code that package 25 had added,
and the *only* remaining difference against the baseline is package 25's
contract-mandated removal of `romfs_load_zmod()` / `romfs_source_read()`.
That is proven exhaustively, not argued: every symbol and area delta is one
of

```text
removed symbol   _romfs_load_zmod                    (all seven images)
_CODE            -196 bytes = romfs_load_zmod 157 + romfs_source_read 39
_DATA            -10 bytes  = the static romfs_file_t romfs_load_zmod owned
added symbols    none
other symbol deltas: exactly -196, -39 or -10 (the -39 group is the
                     romfs object's own symbols placed after the deleted
                     adapter; the -10 group is the _DATA/BSS symbols)
```

and the counterfactual confirms it: re-adding those two functions in the
`ZOS_ROMFS_BOOT=0` branch of an otherwise-identical tree rebuilds all seven
images **byte-identical to the baseline** (`cmp` clean for every one).
Page 0 and pages 2-7 of the corrected images differ from the baseline only
inside the CRT/launch literals derived from the shrunk `_DATA`/`_CODE`
(the `__zos_crt0_init` copy parameters and one shifted loadable address
immediate), which is the same -10/-196 arithmetic.

So the embedded images are, apart from the mandatory deletion, exactly
their accepted pre-M9 bytes — and 196 bytes smaller than the baseline,
which carried the same dead loader.

## 9.4 Regression coverage

| Requirement | Evidence |
| --- | --- |
| No VFS symbol in any `ZOS_ROMFS_BOOT=0` image | `tools/mapcheck.py` `vfs_image` classification + `VFS_FORBIDDEN_PREFIXES` (runs on every build), `tests/test_m4.py` per-image sweep, symbol check over all seven corrected maps |
| The check fires (negative fixture) | `tests/test_romfs.py::TestRomfsMapcheck::test_embedded_catalog_image_rejects_vfs_symbols` (11 symbols, including `_romfs_op_`/`_romfs_dir_` prefixes) |
| The object group cannot be re-added unconditionally | `tests/test_m9_vfs.py::TestVfsObjectGating` |
| ROMFS-boot images keep the full VFS | unchanged `make check`, M5-M9 suites (section 9.5) |

## 9.5 Validation

```sh
make clean && make check
make romfs-test zex-test monitor-test m5-selftest m5-corrupt-selftest \
     m6-selftest m7-selftest m8-selftest m8-fallback-selftests \
     m9-vfs-selftest
make syscall-selftest irq-selftest m3-selftest m4-loader-selftest \
     m4-selftest m4-placement-selftest m4-failure-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean && git status --short
```

Results (clean tree, `make clean` first): **every target exits 0**;
`make check` reports the reproducible rebuild
`6602cd975104cdc9ccc27830d86a0c4d5588031c12e37148e72a8a4e966c72b8`, 654
host tests with 0 failures (187 skipped), and
`mapcheck --production` accepts `__kernel_code_end` `7EE6h` with 32
granules.  The pre-M5 targets build and replay as before
(`syscall-selftest`, `irq-selftest`, `m3-selftest`,
`m4-loader-selftest`, `m4-selftest`, `m4-placement-selftest`,
`m4-failure-selftest`, 19 tests each).  A standalone
`python3 -m unittest discover -s tests -v` with every image present also
passes, including after building the four extra M8 acceptance images
(`m8-ioc`, `m8-hid`, `m8-v9958`, `m8-console-selftest`): 654 tests, 0
failures, **0 skips**.  `git diff --check` is clean and
`make clean && git status --short` lists only the intended
source/config/doc changes (no generated artifacts; the temporary
baseline worktree and counterfactual tree used for section 9.3 were
removed).

Test count moved 649 -> 654: +3 `tests/test_m9_vfs.py`
(`TestVfsObjectGating`) and +2 `tests/test_romfs.py` (the embedded
fixture's positive control and the VFS-symbol rejection).

## 9.6 bank-7 ledger (section 32.39)

Production, before and after correction-01 (unchanged, same image hash):

```text
bank7: exec 24291 B (23.72 KiB) + data 1212 B (1.18 KiB)
       + boot set 10752 B (10.50 KiB, 21 granules)
       = 36255 B (35.41 KiB) of 48896 B (47.75 KiB)
       arena 16384 B (32 granules, gate), free 11 granules (5632 B)
       slack 12641 B (12.34 KiB)
```

Correction-01's own contribution to that ledger: **0 bytes** for
production and every ROMFS-boot image (identical object list and byte
sources).  In the seven embedded-catalog images it *removes* 196 B of
`_CODE` and 10 B of `_DATA` each (section 9.3); it adds nothing:

```text
bank7 (m4-selftest, ZOS_ROMFS_BOOT=0): exec 20509 B (was 20705 B),
       data 1833 B (was 1843 B), fixed legacy arena A000h-BFFFh
```

---

# 10. Correction-02 -- path-based providers and one ROMFS lookup

Date: 2026-10-04 (work package 25, correction pass 2)

The architecture was trimmed on 2026-10-04 (sections 32.8, 32.12, 32.13,
32.33.5, 32.39).  Package 25 had implemented the original node-based design:
a 20-operation `zfs_ops` with lookup/release, `zfs_open_info.object_id`,
per-component VFS traversal, longest-match mount resolution, and
`statfs`/`truncate`/`syncfs`/`unmount`; and it kept the M5 case-sensitive
ROMFS lookup beside a second, case-folded provider lookup.
Correction-02 replaces those interfaces in place (there is no
backward-compatibility obligation).

## 10.1 Delivered change

- **Provider ABI** (`include/zephyros/vfs.h`) -- `struct zfs_ops` is now
  the 14 path-based operations of architecture 32.12, in order:
  `mount, open, close, read, write, sync, stat, opendir, readdir,
  closedir, mkdir, rmdir, unlink, rename`.  `open` reports the size
  through `uint32_t *size`.  `zfs_open_info`, `object_id`, and the lookup,
  release, unmount, syncfs, truncate and statfs operations are gone.
- **Native ABI** (`include/zephyros/fs.h`) -- `zfs_statfs` and
  `ZFS_STATFS_READONLY` are removed; there is no `statfs` in M9.  The
  remaining layouts and their `_Static_assert`s are unchanged.
- **VFS core** (`kernel/vfs/`):
  - `path.c` keeps normalization and the ASCII case-folded compare
    (against the `/` base until package 27 adds the CWD);
  - `mount.c` replaces longest-match resolution with **flat selection**
    (section 32.8): the first component is folded against the mounted
    root-level mountpoints, otherwise `/` owns the path.  Node objects,
    `vfs_lookup_rel`, `vfs_release_node`, `vfs_resolve_node`, `vfs_statfs`
    and the mount-path component helpers are deleted.  One 128-byte shared
    pathname scratch buffer; no dynamic allocation;
  - `file.c` calls providers with the provider-relative path, adds
    `vfs_write`/`vfs_sync`, and answers `stat("/")` and `stat(mountpoint)`
    itself as directories;
  - `dir.c` opens a mountpoint through its own filesystem's `/` and
    enumerates the root from the mounted root-level entries;
  - `mutate.c` (new) holds the mutation entry points, which give the
    read-only rule one home: a null provider operation is `ZOS_EROFS`, and
    a cross-mount rename is `ZOS_EXDEV`.
- **ROMFS** -- exactly one lookup, ASCII case-folded:
  - `kernel/romfs/romfs.c` deletes the case-sensitive `romfs_lookup` and
    its comparison helper, folds the surviving lookup in place
    (`romfs_lookup_ci`, and the `index` out-parameter is gone), routes the
    module resource imports through it, and drops `romfs_count`/
    `romfs_total_bytes`.  ROM-access primitive, whole-image validation,
    bounded reads, indexed entry access and the corrupt-image diagnostics
    are unchanged;
  - `fs/romfs/romfs_provider.c` is rewritten path-based: `/` is the only
    directory, `/<name>` is a file, `/<file>/x` is `ZOS_ENOTDIR`,
    `/<unknown>/x` is `ZOS_ENOENT`; every mutation pointer is null; the
    handle pool is reset at mount so the instance never depends on the C
    runtime having zeroed `_DATA`.  Every symbol it defines is
    `romfs_provider` or a `romfs_pv_*` private.
- **`process_exec()`** keeps its package-25 VFS path signature; its
  embedded-catalog (`ZOS_ROMFS_BOOT=0`) body now uses the single folded
  lookup.
- **Tests** -- `tests/test_m9_vfs.py` gains `TestProviderAbiShape`, which
  checks the 14-operation list, each signature against section 32.12,
  `ZFS_OPS_COUNT`, and the absence of every removed name;
  `tests/test_m9_vfs_sim.py` gains a direct kernel-API replay proving
  `/SYSTEMX` does not select `/SYSTEM`, ENOTDIR below a file, deeper-path
  ENOENT, case-folded resolution and a per-case FAIL-marker check;
  `tests/target/m9/m9_vfs_test.c` is reworked for the path-based contract
  and adds the FLAT, DEEPER and MUTATE cases (result codes 0x0F-0x11);
  `tests/test_romfs_sim.py` drives the single folded lookup and asserts
  case variants resolve.
- **Enforcement** -- `tools/mapcheck.py` now requires `_romfs_lookup_ci`
  (the single lookup) and forbids only the M9-only `_romfs_entry_at` plus
  the VFS/provider namespaces in embedded-catalog images; the Makefile's
  `M9_VFS_OBJS` group gains `vfs_mutate.rel`.
- **Docs** -- `docs/vfs.md` rewritten for the path-based contract;
  architecture 32.38.1 replaced with an accurate account of the reworked
  implementation (and the superseded-notice paragraph removed);
  `docs/romfs-format.md`, `docs/memory.md` and section 24.5 updated.

## 10.2 Measured saving

Per-object bank-7 sizes (each object linked alone, so these are exact
`_CODE`/`_DATA` areas, not spans):

| Object | `_CODE` | `_DATA` |
| --- | --- | --- |
| `kernel/vfs/path.c` | 826 | 0 |
| `kernel/vfs/mount.c` | 1975 | 170 |
| `kernel/vfs/file.c` | 1549 | 0 |
| `kernel/vfs/dir.c` | 991 | 0 |
| `kernel/vfs/mutate.c` | 525 | 128 |
| `fs/romfs/romfs_provider.c` | 1644 | 50 |
| `kernel/romfs/romfs.c` | 3119 | 7 |
| generated mount table | 32 | 0 |
| **total** | **10661** | **355** |

Removed (the correction contract's own measurements of the superseded
functions):

```text
vfs_lookup_rel            544
vfs_release_node          512
vfs_resolve_node          115
vfs_statfs                284
romfs_lookup              312   (case-sensitive duplicate)
romfs_lookup_ci (old)     395   (folded, with index out-parameter)
                        ----
                        2162
```

Linked-image result:

```text
_CODE   24291 -> 23490 bytes   (-801)
        __kernel_code_end 7EE6h -> 7BC5h
_DATA    1210 ->  1294 bytes   (+84)
arena    32 -> 34 granules     (unchanged 32-granule floor; 2 spare)
```

**The saving is below the 1.5 KB threshold, so here is where the bytes
went.**  The rework did not only delete; it added the pieces the trimmed
architecture requires and the superseded design did not have in that form:

- `vfs_write` + `vfs_sync` (264 bytes) and the four mutation entry points
  (~390 bytes) -- the mutation family is the single home of the null
  `EROFS` rule that correction-02 explicitly requires ("VFS turns a null
  mutation operation into `ZOS_EROFS`"), and the required test case for it
  can only exercise linked bytes through these entry points;
- flat selection (`vfs_mount_is_root_level`, `vfs_mount_is_root`,
  `vfs_is_mountpoint`, the first-component fold -- ~245 bytes) plus
  `vfs_resolve_path`/`vfs_mount_resolve` (~1013 bytes) -- the old
  `vfs_mount_resolve` was a longest-match scan and the old
  `vfs_resolve_node` a node walk, so roughly half of this is new;
- the provider's path parsing, deeper-path rule and handle pool inside the
  1644-byte `romfs_provider` object (the old object was 20 operations with
  twelve one-line `EROFS` stubs and a `(void *)(index + 1)` node encoding,
  which cost no per-open state at all);
- `_DATA` grew because the provider needs real per-open state (26-byte
  pool + 64-byte component buffer) and `vfs_rename_target` (128 bytes) is
  new; the deleted `static romfs_file_t` saved 10.

Deleting the two duplicated ROMFS lookups (707 bytes) and the node
machinery (1455 bytes) did land; the additions above consumed all but 801
bytes of it.  If the mutation entry points are judged premature -- they
have no consumer until package 27 wires `SYS_FS_*` -- deferring them
recovers about 650 bytes of the gap; that is a supervisor decision, not a
correction-02 requirement, so they are kept here.

## 10.3 Validation

```sh
make clean && make check
make romfs-test zex-test monitor-test m8-selftest m8-fallback-selftests \
     m9-vfs-selftest m9-required-mount-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean && git status --short
```

Results: every command exits 0, re-run at the frozen revision.
`make check` reports the reproducible rebuild
`ebd8362c0e68997a5ff8c349a7664ae9131a1a4a32bcb8e99d4c94ca6bd8d796`
(two clean builds byte-identical), 660 host tests with 0 failures, and
`mapcheck --production` accepts `__kernel_code_end` `7BEEh` with 34
granules.  A standalone `python3 -m unittest discover -s tests -v` with
every M8/M9 image present passes: 660 tests, 0 failures, 101 skips.  The
M8/M9 acceptance targets (`m8-selftest`, `m8-fallback-selftests`,
`m9-vfs-selftest`, `m9-required-mount-selftest`, all exit 0; the
production image is `ebd8362c...d796`, the arena `7C00h-C000h` with 34
granules, 21 boot / 13 free) are unchanged from the package-25 M8
behavior apart from the intended VFS rework.  `git diff --check` is
clean and `make clean && git status --short` lists only the intended
source/config/doc changes.

The pre-M8 acceptance images are **not** rebuilt or replayed by this pass
(package 25a retires them), per the supervisor's instruction.  Their
sources were compile-checked instead (`tests/target/m2..m7` all compile
against the new headers), and `tests/test_m3_sim.py`'s production-boot
replay exercises the changed path.

Two regressions were found and fixed during validation, both in the same
area:

1. `romfs_pv_reset()` -- the new provider handle pool was read from
   uninitialized `_DATA` in replays that call `kernel_main()` without
   `__zos_crt0_init()` (the M3 production-boot replay), so the first
   module load failed with `-ZOS_EMFILE`.  The pool is now cleared at
   `mount`, which is the only way to obtain an instance; the provider no
   longer depends on the runtime startup having run.
2. `struct vfs_mount_runtime` lost the `generation` field (8 bytes), so
   the required-mount test's hardcoded stride was wrong.  The size and the
   `last_error` offset are now pinned by `_Static_assert` in
   `kernel/vfs/vfs.h`, and the host test reads the number from there.

## 10.4 Hardware

Unchanged from package 25: production bytes changed again, so the physical
gate remains `PENDING` (see section 5).
