# Package 53b — m12 device events

Device events: an application subscribes to the events of a device handle
(`NOTIFY`), and the nucleus delivers them signal-style, at a point where
the process is running its own code again, **only while that process is
running**.  The driver keeps the interrupt; the application never claims
one.  The first source is the timer driver's CTC channel-3 event timer
with exact deadlines.

The contract implemented here is `work/53b-m12-device-events/WORK.md`'s
rules table, byte for byte: a delivery while the owner's own code runs, a
*held* event while it is inside a syscall or an IPC call (delivered when
that call returns), a *held* event while its own handler runs (never
nested), a dropped event - counted in `missed` - while a child it started
is the running process, and the subscription gone when it exits or
unbinds.  Held events coalesce: the handler receives `count` and
`missed`, both since its last delivery, and nothing queues.

The delivery is a 24-byte frame on the program's own stack
(`latch, 0, HL', DE', BC', AF', IY, IX, HL, DE, BC, AF, PC`) built by two
checks that run in common memory at every interrupt and every syscall
return (`_kos_event_irq_exit`, `_kos_event_syscall_exit`): the check is
one compare on the interrupted PC against `E000h` and, for the syscall
path, the saved IFF - so the cost of paying attention is two instructions
per return (measured below).

## Files

Added:

| file | part |
|---|---|
| `kernel/event/event.h` | the table's C view: 4 rows × 12 bytes, the offsets, the saturating post rules, the teardown hooks |
| `kernel/event/event.c` | fixed core: `kos_event_post` (the driver API entry, ISR-safe), `kos_event_init` |
| `kernel/event/event_common.asm` | common memory: the pick scan, the frame builders, the two exit checks, the delivery entry and the unwind, the table and the delivery state |
| `kernel/event/event_syscall.c` | cold half: `kos_event_notify`, `kos_event_return`, `kos_event_handle_release`, `kos_event_process_exit` |
| `user/sdk/include/kos/event.h`, `user/sdk/src/event.c`, `user/sdk/src/event_entry.asm` | `notify`, `timer_event`, the trampoline and the `EVENT_RETURN` return, in libkos |
| `tests/events/events.c` | the acceptance program `/system/events.exe` (`watch`, `loop`, `run`, `exit`) |
| `tests/beat/beat.c` | the board check `/system/beat.exe` |
| `tests/test_events.py` | 24 host and replay tests |

Changed (the whole change is in this table; nothing else in the tree is
touched):

| file | change |
|---|---|
| `kernel/irq/entry.asm`, `kernel/syscall/entry.asm` | the one call each into the two exit checks, after the interrupted latch is restored |
| `kernel/syscall.c` | `KOS_SYSCALL_NOTIFY` (0Dh) and `KOS_SYSCALL_EVENT_RETURN` (0Eh); the reboot path now stops every CTC channel |
| `kernel/main.c` | `kos_event_init()` before `irq_init()` (the table must be valid before the first interrupt) |
| `kernel/irq/ctc.c`, `kernel/irq/irq_private.h` | `platform_ctc_quiesce_all()` - all four physical channels by their ports |
| `kernel/ipc/ipc.c` | the `api_*` entries of `struct driver_api` are exported globals so the map carries them (placement pinned by the map checker) |
| `kernel/vfs/handles.c` | the handle release hook |
| `drivers/timer/timer.c`, `timer_io.asm`, `timer_proto.c`, `timer.json` | the channel-3 event timer: `KTIMER_OP_EVENT`, `KOS_OP_SUBSCRIBE`, `KOS_OP_RELEASE`, the second claimed source, the anchor rule and the chunk floor |
| `drivers/include/driver.h`, `abi/kos/protocol.h`, `abi/kos/syscall.h`, `formats/include/mod.h` | `event_post` in the bootstrap table, the two syscall numbers, `MOD_EP_EVENTS`, `KOS_OP_SUBSCRIBE` |
| `tools/mapcheck.py` | the driver-API entry rule (below) |
| `tools/modpack.py` | the endpoint flag's decoding |
| `config/residency.json` | `event_common` and `event` are fixed-required (they run under the driver's window and the application's latch); `event_syscall` stays cold |
| `Makefile`, `systems/fs.json`, `systems/production.json` | the two programs, the fs image's timer driver and `events.exe`, the production store's `beat.exe` |
| `docs/architecture.md` 4.10, `docs/abi.md` 6.7/5.5, `docs/sdk.md` 6.9, `docs/devices.md` 9, `docs/memory.md` | the rules, the two syscalls, the handler's restrictions, the timer event, the ledgers |
| `tests/test_pack_image.py`, `tests/test_timer.py`, `tests/test_sdk.py`, `tests/test_sdk_package.py`, `tests/test_iocfat.py`, `tests/test_source_layout.py`, `tests/test_hid.py`, `tests/test_systemgen.py`, `tests/test_v9958.py` | the pins this package moved (page 1's derived boundary, the timer manifest and BSS, the new program, the new header, the fs image's driver/store lists, the timer directory listing, the production store's `beat.exe`) |

## The event timer (channel 3)

Same control word as the tick, prescaler 256, so a count is 25.6 µs.

- **Exact deadlines.**  The driver keeps an absolute deadline in counts
  and loads the next chunk (`≤ 256` counts, the remainder last) at every
  expiry; the handler's reading of the channel is ambiguous by one tick,
  so `timer_event_anchor()` takes the nearer of the two candidates that
  the read can mean and never moves the tracked count backwards, counting
  the times it keeps the chain in `timer_event_anchor_kept`.  A rearm
  never leaves a chunk shorter than 64 counts - a shorter one expires and
  reloads while the handler is still masked, and the carry cannot see the
  reloads it missed - so a period of 782 counts arms as
  `256 + 256 + 135 + 135`.
- **One subscriber.**  A second arm is `-KOS_EBUSY`; an arm with no
  subscription is `-KOS_EINVAL`; `period = 0` stops the channel and is
  valid whenever it arrives (the release and the unsubscribe both stop
  the source through it).
- **Release.**  The timer manifest declares `"events": true` and
  `"release": true`, so the handle's release stops the channel through
  `KOS_OP_RELEASE`; the driver stops it itself on the program's exit
  path, and `platform_ctc_quiesce_all()` is the reboot's backstop.

The driver's own posts sit on the deadline grid (measured below); the
nucleus's delivery adds the interrupt return's own lateness, which the
handler measures as `late`.

## Findings and corrections

1. **A delivery clobbered the interrupted call's argument blocks.**  The
   frame is built *below* the interrupted SP, i.e. exactly where libkos
   keeps its 93-byte low argument-block area, so a handler invoked from a
   console write returned into a call whose arguments had been
   overwritten.  Fixed by the trampoline's snapshot/restore
   (`_kos_event_block_save`), which is why the frame is entered through
   libkos rather than a page-zero vector.
2. **The boot after a warm reboot hung.**  Two real defects, both named
   by the owner and both fixed:
   `syscall_reboot` quiesced only `IRQ_CTC0` - a channel no image
   programs - so the tick (channel 2) and the event timer (channel 3)
   kept counting and kept a request latched *into the next boot*; and
   `kernel_main` cleared the event table *after* `irq_init()` had already
   enabled interrupts (`_irq_arch_init` ends in `ei`).  The common region
   arrives as `FFh` (the ROM image carries no `_COMMON_DATA` bytes), so a
   stale request delivered at that first `ei` made every row look bound,
   pending and deliverable with an `FFFFh` handler.  Fixed by
   `platform_ctc_quiesce_all()` in the reboot path and by clearing the
   table before `irq_init()`, with the order stated where it matters.
3. **The stop path sat behind the subscription check.**  `events exit`
   left the channel armed and the next arm returned `-EBUSY`; the stop is
   now first and unconditional.
4. **`count`/`missed` are per-delivery backlogs.**  The acceptance
   program overwrote instead of accumulating them, and its `run` mode
   judged a comparison it cannot observe (the parent's own posts are held
   while it is inside `run` and delivered - coalesced - at its resume).
   Both fixed; the replay now asserts the mask-tolerant properties.
5. **The card-peer harness cannot assert deadlines.**  Its emulated lane
   is paced per byte, so a masked stretch can outlast a period and move a
   delivery's own reading without the driver's deadlines moving.  The
   replay is split: the peer machine asserts what survives any masking
   (no lost or doubled delivery, `count + missed` accounts for every
   post, monotonic deadlines, the cost), and the machine without the peer
   asserts the exact-deadline bounds.
6. **`test_pack_image` probed page 1 at a literal `C000h`.**  Page 1
   carries the bank-7 loadable content up to the *derived* cold data
   base, so the probe went stale the moment the event objects grew the
   cold half.  The test now reads `KOS_WINDOW_DATA_BASE` from the build's
   geometry and asserts page 1 is `FFh` from there to `E000h`; the
   `C000h-FFFFh` rule it misread belongs to the store's recovery pages
   2-7, and the earlier attempt to move `event_syscall` out of the cold
   half was reverted (the supervisor's correction).
7. **The driver API had no placement rule.**  Everything a resident
   driver calls from its own window must be in the fixed core or in
   common memory; the entries now travel in the map as exported globals
   and `tools/mapcheck.py` fails the build when one of them links in the
   `6000h` window.  `event_post`'s chain as linked: `_api_event_post`
   `3C0Ah` → `_kos_event_post` `3D5Ch` → `_kos_event_post_bank` `E39Ch`
   (with the table and the exit checks beside it in `_COMMON`).  The
   syscall and teardown bodies link cold (`BD99h`-`C138h`), which is
   sound: every caller of theirs runs with bank 7 mapped.
8. **`PYTHONHASHSEED` does not decide a replay's outcome.**  No
   hash-ordered iteration exists in the simulator or the peer: the two
   sets there are membership-only (`IntegrationInputs.done`) or feed a
   `sorted()` result (`IocCommandPeer.fs2_dirs`), and dict iteration is
   insertion-ordered.  A fingerprint of one clean replay run under seeds
   0 and 1 is byte-identical (boot transcript, the 804-entry delivery
   log, the RAM banks, the metric line `50 50 0 9 16 0 38318`).

## Validation

```text
make
  mapcheck: OK (18 areas, 400 symbols) [production]
  mapcheck: fixed core 2000h-5FFFh end 3EBEh (8760 required + 2 overflow
  + 768 stacks, 6854 room) | cold half 6000h-DFFFh end C198h | data
  5800h/C200h
  pack_image.py: 524288 bytes, sha256
  693e3ace1a57cf4b5273c06d7ffb2d265848d41a0efced24efda233b6947963c

make check
  check: reproducible rebuild (693e3ace1a57cf4b5273c06d7ffb2d265848d41a0efced24efda233b6947963c)
  Ran 765 tests ... (the last complete run)

make fs-selftest            # OK, and the 24 device-event tests inside it
make console-serial-selftest  # OK
git diff --check            # clean
```

The full suite's last complete run ended with four failures, all of them
stale pins this package moved - `test_hid`, `test_sdk`, `test_systemgen`
and `test_v9958` each listing the production store or the program set
without the new `beat.exe`, and `test_source_layout`'s `drivers/timer`
listing without the pinned `timer_io.asm` (that one fails at the base
commit too).  All five are updated; the four store modules then ran green
(108 tests, 2 skipped) and `tests/test_source_layout.py` 52 tests green.

The suite was *stopped* during its final complete re-run on the owner's
instruction, because the OS itself had not changed since the board
validation: what had run was green (57 tests plus the reproducible
rebuild above), and the only edits after the board run were to the
user-mode program `beat.exe` and its pins - no kernel, driver, platform,
ABI, linker or residency change.  The modules that read the store or the
image were re-run green after `beat.exe` entered the store
(`tests.test_hid`, `test_systemgen`, `test_v9958`, `test_sdk` 108 OK;
`test_iocfat` 21 OK; `test_pack_image` 34 OK; `test_events` 24 OK;
`test_shell`, `test_shell_sim`, `test_hwtest_sim`, `test_boot_policy`,
`test_device_release` 58 OK, 9 skipped).

## Ledgers

Against the package's base (`5b16f3a`, `package 53 (timer)`):

| ledger | base | now |
|---|---|---|
| fixed core code end | `3D48h` | `3EBEh` |
| fixed required / room | 8363 B (+2 overflow +768 stacks) / 7251 B | 8760 B / 6854 B |
| cold half code end | `BD35h` (23861 B) | `C198h` (24984 B) |
| cold data | 1527 B at `BE00h` | 1527 B at `C200h` |
| driver hot | 22578 of 32768 B | 23944 of 32768 B |
| driver boot/bulk | 2186 of 24576 B | 2186 of 24576 B |
| common | 2373 of 7424 B (code 1526, data 847) | 2893 of 7424 B (code 1967, data 926), ceiling 3072 |
| production store | 20 entries, 132420 B | 21 entries (`beat.exe`), 145332 B, sha256 `75459c9b2bbdc981766d7bddf0658231867bd394202154e4985f2745bca55ab8` |
| image | sha256 `4d0aa750...` | sha256 `693e3ace...` |

The fixed core's bytes are the post path, the event object's init and the
eleven exported `api_*` entry symbols; the common region's +41 code is
the two exit checks with their frame primitives and the pick scan (its
data was already inside the 926); the cold half's +1123 is the syscall
and teardown bodies, which moved the window-data base from `BE00h` to
`C200h` (the base follows the linked code end).  The driver's hot tier
grew by the event timer's handler, arm/stop bodies and state.

## Measurements

The replay that carries the deadline assertions (`TestEventDeadlineReplay`
in `tests/test_events.py`, the same image without the card peer):

```text
events: watch 50 deliveries counts 50 missed 0 drift 9 late 16 intervals 0 elapsed 38318
```

- **The deadline grid holds.**  50 periods of 782 counts, one delivery
  each, the signed interval errors summing to 0 (`intervals 0`), and the
  handler's own worst reading 9 counts off the grid with 16 counts of
  lateness on one delivery - the interrupt that arrived late, which the
  absolute deadlines do not accumulate.
- **The driver's posts are the far end of that grid**: median error at or
  below 1 count, worst 16, one post per period.
- **The mechanism's cost: 7,459 T-states per delivery**, 3.7% of the CPU
  at 50 Hz, with the trampoline's 93-byte argument-block snapshot inside
  the measured window; the restore half is another ~1,970 T-states, so
  the whole round trip is ~9,400 T (4.7%).  The bound pinned by the
  replay is the measured figure plus a tenth (8,205 T).  *(Corrected by
  the addendum at the end of this record: 8,407 T (4.2%), bound 9,250 -
  the reading above carried the handler's own tail and left the
  trampoline's entry side out.)*
- On the card-peer machine the same run shows what any masking keeps: no
  lost or doubled delivery, `count + missed` covering every post, and
  posts monotone.

## Board

The owner's hardware run:

- the **production build boots and runs on the Zephyr-80**: the kernel,
  the driver set and the store (the same image whose ledgers are above);
- **`/system/beat.exe` does not pass.**  Two runs of the card copy
  (`756c2f04...`, the first attempt) and two of the diagnostic copy
  (`25d95206...`, which prints the tick clock and marks a second with no
  delivery):

```text
/> beat                      (copy 756c2f04)
2 4 6 8 10 12 13 13 13 13    deliveries stop after the 6.5 s event
/> beat ls /fs 10
2 4 6 8 10 12 14 17 19 21    off-grid, 21 events where 500 ms/10 s gives 20
/> beat                      (copy 25d95206)
0/0 clock 39089 gap ... 0/0 clock 390655 gap
                             no delivery in ten seconds; the tick clock is
                             perfect (390,655 counts = 10.00 s)
/> beat ls /fs 10
2 4 6 8 10 12 15 16 19 21    2/s for six seconds, then +3 +1 +3 +2
```

  Two distinct findings, both board-only:

  1. **The first arm after boot made no interrupt at all** (`0/0` for ten
     seconds while the tick clock ran perfectly, so the CPU was taking
     interrupts and CTC2 was exact).  The second arm, seconds later,
     delivered at once.  CTC3 is untouched before the first arm
     (`timer_boot.c` programs channel 2 only, and the CTC receives no
     reset), so the channel's state at the first arm - and whether the
     control-word/constant pair it writes is accepted there - is the
     suspect; the delivery path itself is proven alive by the second run.
  2. **Subsequent arms deliver, but the chain loses its advance** when a
     request is serviced later than one chunk (256 counts = 6.5 ms: the
     console and the card lanes mask for far longer on a board).  The
     anchor accepts a reading only within half a tick (125 counts) of the
     chain and otherwise keeps the chain, so a lost advance is never
     recovered from the clock; the catch-up loop then posts in bursts
     (+3, +1, +3, +2) and a ten-second run can end at 21 instead of 20.
     This is the rule the owner set, and the board is the evidence that
     its premise - "the board loses no ticks across card I/O" - holds for
     the tick *counter* but not for the event channel's *servicing*.

  The clean replay cannot see either: its console writes are microseconds
  and it has no first-arm hardware state.  Recorded as the open item;
  nothing was changed to make the model agree.

The checklist's "then run it while `ls /fs` repeats" cannot be typed
while the program runs - the monitor's `X` run is synchronous - so the
program supplies the traffic itself: `beat ls <dir> <seconds>` enumerates
the directory in a loop while the beat continues, and `beat run
<seconds>` is the same check for a shorter run.

The simulator is not the instrument for this program: a production replay
never shows its console output at all (its first print never appears,
while the same harness runs `fs_child` from the store), so the host test
pins only what a silent edit would break - the declaration and the stack,
the store entry, the 500 ms subscribe and arm, the accumulated counters,
the PSG port, and the silence on every exit path.  Reported, not worked
around: the replay's blind spot is a harness limitation.

Nothing is committed: the package's tree stays uncommitted as the work
order asks.

## Addendum: supervisor completion (2026-10-15)

The worker stopped on the board findings (progress issue 11a); the
supervisor finished the package.  Three changes, and the board run that
accepts them.

### 1. The event timer reads the clock instead of counting chunks

The chunk chain counted time on channel 3 and anchored it to the clock
within half a tick.  On the board the console and card paths mask longer
than one 256-count chunk, whole chunks reloaded unseen, the chain fell
more than half a tick behind and the anchor rule then refused to
resynchronise: bursts and a 21st event in a ten-second `beat ls` run.
Replaced, not tuned:

- the clock (channel 2) is the only time reference: the tick handler
  reads it exactly and, when the next deadline is within 256 counts,
  loads channel 3 once with the counts left;
- channel 3's handler stops the channel, reads the clock (a reading below
  the deadline is one tick stale and is lifted by 250) and posts; for a
  period shorter than 256 counts it loads the next stretch itself;
- nothing is counted on channel 3: a masked stretch makes a post late,
  never lost, doubled or early, and the next deadline is exact;
- every load is reset + control word + constant (`KOS_CTC3_CONTROL_LOAD`),
  and the boot segment resets channel 3: the first arm after power-on is
  no longer silent (progress 11a.1).

Removed: the chunk chain, the carry, the anchor rule, the 64-count floor,
`timer_event_now`/`_chunk`/`_anchor_kept`, `KOS_CTC3_CHUNK_MAX`.  The hot
segment's BSS is 17 bytes (26 before).  `tests/test_events.py`'s chunk
tests are replaced by `TestEventTimerDeadlines`, a count-by-count model
(one request per channel, masked stretches, the tick winning a tie):
every deadline posted once, never early, late only by the mask in force
(+1 count for a tie), the next one exact.  The model also shows the
clock's own limit: a mask that spans two tick expiries loses a tick.

### 2. `EVENT_RETURN` masks before it reads the latch

The body ran with the caller's interrupt state, and every interrupt exit
check rewrites `kos_event_latch`; an interrupt between loading the
frame's latch and the unwind or re-entry could hand the program the
nucleus's mapping and leave `in_handler` set, after which no delivery is
possible while the clock runs on.  That was the board's stalling plain
`beat` (its tight `timer_now` loop keeps syscalls in flight).  The body
now takes `irq_arch_lock()` before it clears `in_handler`; the enter and
the unwind leave with `EI`.  Pinned by
`TestEventRules.test_the_return_is_masked_before_it_reads_the_latch`.
The simulator never reached the window (a replay of the unfixed build
delivered every period), so the pin is the guard.

That race was real but was not the whole stall: see 3.

### 3. Every IFF2 read is repeated (the `LD A,I` behaviour, on the board)

With 2 fixed, plain `beat` still stalled now and then with `gap di`: its
own main loop was running masked.  A probe in `beat` (count the masked
returns, and whether a delivery happened during that call) showed 2-3
per ten-second run, every one after a plain `timer_now` call with **no**
delivery in it, while the simulator, replaying the same program (8
deliveries, 6 of them at the interrupt exit), never saw one.  The gate
captures the caller's interrupt state with `LD A,I`; when an interrupt is
accepted right after that instruction the read reports IFF2 = 0, so the
gate hands the program back masked and every later syscall preserves it.
That is the documented `LD A,I` behaviour, usually ascribed to NMOS parts
only; the board's CMOS Z84C0020 shows it.  Fix: every capture site (the
syscall gate, `irq_arch_lock`, the copy primitives, ROM access, process
launch, the driver boot gate, the IOC and timer helpers - ten sites)
reads IFF2 up to three times and takes any "enabled": after a false 0 the
interrupt's own `EI`/`RETI` makes the next read true.  With it, plain
`beat` and `beat ls` ran clean on the board with the probe in place (no
masked return).  Pinned by `TestEventRules.test_every_iff_read_is_repeated`;
architecture 4.5 states the rule.  Common memory: 2,953 of the 3,072
ceiling (+60).  The simulator cannot model the behaviour, so the board
and the pin are its guard.

### 4. Docs and history

`docs/devices.md` describes the new event timer and states the clock's
masking limit correctly (a mask spanning two tick expiries loses one; any
mask over 6.4 ms can).  Package, correction and validation-record
references the 53/53b work left in source, tests and docs are removed.
`tests/test_events.py`'s deadline replay bounds the program's own clock
readings by the drift figure (32): the driver's posts are asserted on the
grid directly, and the readings carry the handler's clock-call jitter.

### Validation (the frozen tree, image sha256 `1a500bea...`)

```text
make fs-selftest              3 + 26 tests OK (the event replays and pins)
make ipc-selftest             40 tests OK
make console-serial-selftest  6 tests OK
python3 -m unittest tests.test_timer tests.test_device_release \
    tests.test_hwtest_sim tests.test_console_acceptance tests.test_shell_sim \
    tests.test_source_layout tests.test_pack_image tests.test_sdk
                              156 tests OK (3 skipped: images not built)
git diff --check              clean
```

Measured on the timer replay: one tick delivery costs 1,987 T (gate 303,
dispatch and trampoline 806, handler 132, return 746), 3.11 % of the CPU
at 156.25 Hz; the event-exit check on every interrupt return is most of
the growth over the 1,343 T the timer package measured.

### Board (owner, 2026-10-15)

- `beat` (repeated, after a power cycle): 19-20 events in 10 s, `missed`
  0, no gap, no `di`, and with the masked-return probe in place no masked
  return (image `2c740090...`);
- `beat ls /fs 10`: 20 events, `missed` 0;
- `beat reboot` five times: back at the shell prompt every time (warm
  reboot with channel 3 armed and channel 2 ticking);
- `hwtest`: 4/4 PASS.

### Open

- The subsystem acceptance image no longer links (cold code `DC52h`, its
  data does not fit below `E000h`): the event code's cold growth.  The
  owner chose to split it: `work/53b-m12-device-events/correction-01`.

## Addendum (2026-10-15, `work/56-m13-sdk-buffered-io`)

The mechanism's own cost per delivery is **8,407 T-states (4.2% of the CPU
at 50 Hz)**, not 7,459 (3.7%): in its three spans, the frame build and the
hand-off into the trampoline (1,710), the trampoline's entry with its
argument-block snapshot (2,568) and the restore with the return gate and
the unwind (4,129).

The replay above measured the return side from the handler's last syscall,
so the app's own code from that syscall's exit to the handler's return
(about 1,620 T-states there) was in the figure while the trampoline's
entry side was not: 7,459 + 2,568 - 1,620 = 8,407.  The two nearly
cancelled at the time, and then package 56 buffered console output: the
handler's tail grew to about 8,300 T-states per delivery and the reading
went to 14,068 (7.0%), failing the 5% share assertion.  The harness now
stamps the handler's entry and its return (the return address the
trampoline pushes, read off the stack) and pairs the stamps by nesting
depth, so the figure is the mechanism's round trip less the handler's own
body - the entry side and the snapshot inside it, as the paragraph above
intended.  The deadline grid, the posts, the handler's readings and the
card-peer outcomes all read as they did.

The bound the replay pins is the measurement plus a tenth (9,250 T,
asserted in `tests/test_events.py`); the card-peer replay's 12,000 T
bound is unchanged.  `docs/devices.md` and `docs/memory.md` carry the
corrected figure.
