# TUI windows and clear/line operations: validation

## Result

`libtui` now has absolute logical windows with a four-deep push/pop stack,
whole-window and line clear operations, and in-window insert/delete line.
Every coordinate and drawing path goes through the common screen-member
clipping and translation helpers; nothing is sent to the console by these
operations.  The `windows` replay mode exercises sentinels outside the active
window, the right and bottom edges, nested windows, stack overflow/underflow,
invalid windows that leave the cursor and window unchanged, `clreol`,
`clrline`, insert/delete line, and a separate cleared window.

The final serial and V9958 models are identical:

```text
row 0  END
row 1  S1
row 2    ABCDEFGHIJR2
row 3    KLMNOPQRXY
row 4    UVINYZ0123
row 7  S7
```

Row 2/3/4 are the post-insert/delete window contents; `R2` and `S1`/`S7` are
outside sentinels.  The separate 8 x 4 clear window leaves no cells behind.
The serial route used two console WRITE dispatches, `[110, 19]`; no cell was
sent through an individual write.

## Files

Added:

- `user/sdk/tui/src/tui_window.c`
- `tests/tui/tui_core_probe.c`
- this record

Changed:

- `user/sdk/include/tui.h`: `tui_get_window()` read-only window query used by
  the widget layer that must own an active window's top/bottom row.
- `user/sdk/tui/src/tui_internal.h`: window stack, style field, common clipped
  cell/fill helpers.
- `user/sdk/tui/src/tui_screen.c`: the shared clipping and cell-writing layer.
- `user/sdk/tui/src/tui_lifecycle.c`: window-depth and style reset.
- `user/sdk/exe.mk`, `Makefile`: window member and probe program.
- `tests/tui/tui_test.c`: `windows` mode.
- `tests/test_tui.py`, `tests/test_tui_sim.py`, `tests/test_source_layout.py`,
  `tests/test_sdk.py`: member, screen, link and owner checks.

## Validation

```sh
make build/user/tui_test.exe build/user/tui_core_probe.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk_package tests.test_console_acceptance
git diff --check
```

The combined package 68-72 run completed 173 tests with 171 passed and 2
environmental skips; `git diff --check` was clean.  Packages 66-67 outcomes and
both console backends remain unchanged.

## Supervisor review

Accepted on 2026-10-18. The supervisor reproduced the complete 169-test union:
167 passed and the same two missing generated-artifact cases skipped. Serial
and V9958/HID window replays matched, sentinels outside the active windows were
preserved, and `git diff --check` remained clean.

Review also resolved the public-surface discrepancy around `tui_get_window()`.
The query is required for a separately linked widget library to own the active
window's top or bottom row without private-core access. It is therefore retained
and now declared by the v1 architecture and shared implementation reference.
