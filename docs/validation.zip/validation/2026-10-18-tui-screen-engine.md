# TUI screen engine: validation

## Result

The logical screen engine is implemented with one static 85 x 26 cell map and
one static dirty bitmap.  Cursor, text, control bytes, clipping, dirty/run
flushing, cursor visibility synchronization and formatted text are in place.

A whole 85-character row drawn through 85 `tui_putc` calls leaves one console
WRITE of 91 bytes: a 6-byte cursor position plus the 85 cells.  The unchanged
redraw after it emits nothing.  The serial byte trace and the decoded V9958
screen agree with the same logical model on both console backends.

## Files

Added:

- `user/sdk/tui/src/tui_screen.c`
- `user/sdk/tui/src/tui_printf.c`
- `tests/test_tui_sim.py`
- this record

Changed:

- `user/sdk/tui/src/tui_internal.h`: the cell map, dirty bitmap, run buffer,
  window, cursor and physical-state layout.
- `user/sdk/tui/src/tui_state.c`: the static map, bitmap and run buffer.
- `user/sdk/tui/src/tui_lifecycle.c`: blank model initialization, auto-wrap
  control, and reset.
- `user/sdk/tui/src/tui_flush.c`: dirty/run scan, SGR/cursor/visibility
  synchronization and error retention.
- `user/sdk/exe.mk`: the screen and formatter members.
- `tests/tui/tui_test.c`: `batch` and `screen` modes.
- `tests/test_tui.py`: members, map/bitmap layout, formatter separation, ANSI
  confinement and attribute-run checks.
- `tests/test_sdk_package.py`: the out-of-tree fixture's member set.
- `tests/test_source_layout.py`: the new owners.

`docs/konaos-tui-sdk-architecture.md` remains unchanged.  Package 66's files
and behavior are preserved.

## Sizes

```text
libtui.lib                31,518 bytes (was 3,788)
  tui_state.rel              700 bytes
  tui_screen.rel           7,295 bytes
  tui_lifecycle.rel        2,785 bytes
  tui_flush.rel            9,976 bytes
  tui_printf.rel           9,865 bytes

tui_test.exe              12,707 bytes (was 5,704)
  image_size              12,671 bytes (was 5,668)
  bss_size                 5,199 bytes (was 299)
  stack_size                 256 bytes
  entry_offset                93 bytes
```

The BSS increase is 4,900 bytes:

```text
cell map          85 * 26 * 2 = 4,420
dirty bitmap      2,210 bits   =   277
run buffer                     =   101
tui_state growth               =    12
test 90-byte row buffer        =    90
```

The link map has exactly one `_tui_cells` and one `_tui_dirty`; their address
distance is 4,420 bytes.  `_tui_run` follows the bitmap at 277 bytes.

## Console write counts

Counted at the console driver's WRITE dispatch entry in the simulator (PC
equals the plan's dispatch address, bank 6 is mapped, op is
`KCONSOLE_OP_WRITE`; no production hook):

```text
batch:  91, 7, 17, 15
screen: 91, 91, 124, 7, 127, 9, 61, 15, 57, 13, 18, 15
```

`91` is the full row: `ESC[1;1H` plus 85 cells.  The next batch entry is the
marker cursor sync, then the PASS line and shutdown; the unchanged redraw
between the row and the marker has no dispatch.  The screen mode draws 365
cells in 12 dispatches.

## Commands

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_console_serial \
    tests.test_source_layout -v
git diff --check
```

Results:

- The build and SDK package completed with no warnings; the package still
  holds 48 files and `KOS_SDK_VERSION` remains `0.1.0`.
- The suite ran 120 tests in 259.565 s: 119 passed, 1 skipped, 0 failed.
  `tests.test_sdk.TestHelloWorldImage` skipped because
  `build-helloworld/konaos-helloworld.bin` is outside this package's build
  set.
- `git diff --check` reported nothing.

## Replay evidence

`tests/test_tui_sim.py` injected `tui_test.exe` into the recovery stores of
`build/konaos.bin` (V9958/HID) and
`build-console-serial-selftest/konaos-console-serial-selftest.bin`
(`console-serial`).  Each backend ran the foundation, batch and screen
modes.

- The serial byte trace was decoded through its CSI/SGR stream.
- The V9958 trace was decoded from the HMMM glyph copies and HMMV fills,
  with the scroll origin derived from R#23 (`origin = (R23 + 4) & FFh`).
- Both decoders matched the same expected 21-row model, including the
  90-byte clipped row, the controls, the bottom-row right-edge cases and the
  formatted rows.
- Cursor hide/show sequences appeared in the serial lane.

The rebuilt artifact hashes are:

```text
b47b19c0d571246a9317d39e69e207cd00f13159a9d4cff7f7243ba714c6c7d0  build/user/sdk/libtui.lib
10fcc18a64796fc09cdda88fcf0b9be017f754ba0816c27a39b4121f51fc675b  build/user/tui_test.exe
```

### Correction 01

`tui_shutdown()` now calls `tui_flush()` before it emits the normal-
rendition, auto-wrap and visible-cursor restoration sequence.  Both calls are
best effort: a flush failure does not suppress restoration, and the library
is uninitialized and idempotent afterwards.

The target program's `shutdown` mode draws a full row, `dirty two` on the
next row and `xy` at row 2 column 5, moves the cursor to row 22, and calls
`tui_shutdown()` twice without an explicit `tui_flush()`.  Both backends
emitted the dirty screen in one 126-byte WRITE, then the 15-byte restoration
and the 20-byte PASS line:

```text
shutdown: 126, 15, 20
```

The serial test also asserts the `dirty`/`two` runs occur before the
restoration bytes, so the old shutdown (restoration only) fails the
regression.  The out-of-tree SDK fixture now links `tui_flush` through
shutdown, while the screen and formatter members stay out.

The corrected artifact hashes are:

```text
c1d19a1430cb14e8d2049a489bef6f33fcc5b0fce8eb67339f68d3cebf9cda2a  build/user/sdk/libtui.lib
684a7358c8e4813e8067a3626a10329a087972b89ca56a84776db5039d9a78bc  build/user/tui_test.exe
```

## Decisions

- Auto-wrap is disabled during the library's ownership (`ESC[?7l`) and
  restored at shutdown (`ESC[?7h`), so a full row can never wrap or scroll
  the terminal while the model refuses to.
- `tui_gotoxy` rejects a position outside the active window with
  `-KOS_EINVAL` and leaves the cursor unchanged.
- The `_xy` text forms use a local draw cursor and leave the application
  cursor unchanged.
- The formatter mirrors the SDK printf conversions and width rules and writes
  through the same text path; it keeps no output buffer.
- A failed flush retains every dirty bit and does not commit the tracked
  physical state.

## Supervisor review

Package 67 and correction 01 are accepted on 2026-10-18. The initial review
reproduced the build, packaging, static/linkage checks, and both simulator
backends: 118 tests ran, 117 passed, and the pre-existing missing
`build-helloworld` image case skipped. It found the missing shutdown flush and
issued correction 01.

For the correction, the worker's 120-test gate passed with the same expected
skip. The supervisor independently replayed the serial and V9958/HID dirty-
shutdown cases, the changed standalone-SDK linkage assertion, and all
`tests.test_tui` checks: 18 passed. Both corrected artifact hashes matched the
record, and `git diff --check` remained clean.

The correction demonstrates that dirty cells are emitted before the terminal
restoration sequence, shutdown remains idempotent, and the lifecycle-only SDK
fixture pulls the flush member without pulling the screen or formatter
members. Package 68 may proceed.

## Pending

None for package 67. Windows, clear/line operations, the key decoder,
save/restore, styles and widgets remain for their own packages.
