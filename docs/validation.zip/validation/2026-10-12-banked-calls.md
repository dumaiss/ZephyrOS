# Banked calls: `__banked` far functions as plain C (work package 49b)

Work package: `work/49b-banked-calls/WORK.md` ("Far calls as plain C").
The package makes a far function a plain C call: a program marks it
`__banked` (or builds the file into a far segment with the `FAR<n>=`
options), SDCC emits the banked-call sequence, and the SDK supplies the
trampoline SDCC's convention names - `___sdcc_bcall_ehl` - on top of the
existing far-code mechanism (segment tokens, the mode-10 aperture).
`farcall` stays as the primitive.  The working log, including the spike,
is `work/49b-banked-calls/progress.md`.  49a is the preceding commit
(`3ce127b`); this package is **not committed**.

## 1. Part 1: the spike (stop gate) - findings

Measured with the shipped toolchain (SDCC 4.5.0 #15242, `-mz80`) and the
SDK's own flags (`-mz80 -c --nostdinc --Werror -I abi -I
user/sdk/include`), samples in `/tmp/spike49b`.  The gate: a trampoline
that cannot preserve the convention in at most 64 bytes, arguments that
cannot pass through unchanged, or a linker that cannot place several far
areas at `8000h` would have stopped the package.

1. **The call sequence** a caller emits for a `__banked` function:

   ```asm
   	ld	e, #b_<fn>	; the bank number, an immediate
   	ld	hl, #_<fn>	; the function address
   	call	___sdcc_bcall_ehl
   ```

   with `E` the segment id and `HL` the far entry (a tail call uses
   `jp`).  `b_<fn>` is emitted by the **defining** module only when that
   module is compiled with a bank: `-bo <n>` or `#pragma bank <n>`; a
   later `--codeseg FAR<n>` renames the area, so `sdcc -bo <n> --codeseg
   FAR<n>` (bank first) yields area `_FAR<n>` **and** `b_<fn> = <n>`,
   while `#pragma bank` alone lands in `_CODE_<n>`.  The definition must
   itself be `__banked`.

2. **Arguments and returns.**  All parameters travel on the stack (the
   caller clears them) whatever their width.  At the far entry the frame
   is `SP+0..1` the address the callee's `RET` pops, `SP+2` one reserved
   byte and `SP+3..4` two more, so the first argument is at `SP+5`
   (packed, first argument lowest, no padding): the trampoline must spend
   **exactly three bytes** between its entry and the transfer.  Results
   come back in `A` (8 bits), `DE` (16) and `DEHL` (32); callers spill
   everything else to the stack, so only `A`, `DE` and `HL` must survive
   the far call.

3. **Several far areas at one base.**  `sdldz80` links `_FAR1`..`_FAR4`
   all based at `8000h` in one link without an error or a warning (each
   stays its own `REL,CON` area, one IHX record stream each).  A `-b`
   base for an area no module defines is a warning plus exit 2, and an
   area left unplaced is silently placed after the placed ones.

**No stop-gate condition holds.**  `make helloworld-image` and
`make xmem-selftest` then booted with the real trampoline (section 4).

## 2. Part 2: the trampoline

`user/sdk/src/bcall.asm` (`___sdcc_bcall_ehl`; **68 bytes of `_CODE` and
4 bytes of `_DATA`**), added to the SDK's assembly list:

- E is the segment id, HL the far entry.  HL is saved, the id is looked
  up in a per-program token cache (4 slots, ids 1-4: one slot per far
  segment, filled with `segmap` on first use and reused after - so only
  the first call of a segment spends a `SYS_SEG_MAP`);
- `aperture_open(token)` keeps the previous latch in the one-byte slot
  the callee expects, the transfer's return address is the two-byte slot
  (`call` + `jp (hl)`), so the far code sees exactly the frame section 1.2
  describes;
- on return the slot is dropped, `aperture_close(previous)` restores the
  caller's mapping exactly (a far function may make banked calls itself,
  into its own or another segment) and `A`, `DE`, `HL` come back as the
  far function left them;
- an id outside 1-4, or a refused `segmap`, calls the shared runtime-error
  path (`exe_runtime_error`) with the new SDK-level code `KOS_RT_EFARMAP`
  (`0x30`, in `user/sdk/include/kos/seg.h`, outside the syscall-visible
  `KOS_E*` range) and returns `DE`/`A` = `-0x30` without running
  anything.

Implementation finding, worth keeping in mind: the cache test was first
written as `ld a,(hl)` + `ret nz`, but **`ld a,(hl)` does not set the
flags**, so an empty slot read as a hit with token 0 and every banked call
took the error path.  `or a` after the load fixed it.  It was found by
running the trampoline in the host Z80 (`tests/test_bcall.py`), before
booting an image; the byte-index add also now carries into `H` when a
program's cache address crosses a page.

## 3. Build, packer and ports

- **`FAR1=`..`FAR4=`** (`user/sdk/exe.mk`) take `:`.separated source
  lists per segment; one shell-loop recipe compiles each with
  `-bo n --codeseg FAR<n>` (bank first) into
  `$(OBJDIR)/far<n>/<base>.rel`, behind a stamp target; the link bases
  every used `_FAR<n>` at `8000h`; without `SEGMENTS=` the rule declares
  one `FAR_CODE` row per option used (id n, area `_FAR<n>`).  `FAR=` is
  deleted; `user/helloworld/Makefile`, `Makefile` (`xmem_far`, now
  `FAR1=` + `FAR2=`) and `docs` name `FAR<n>=` instead.
- **Segment ids:** a far segment's id is the number its `__banked`
  definitions emit (`b_<fn>` = n), and the loader numbers rows `1..N` in
  order, so the far segments are the container's first rows (ids `1..k`)
  and `DATA` rows from `SEGMENTS=` follow them.  `tools/exepack.py`
  enforces it: a `FAR_CODE` row's area must be `_FAR<id>` and its id must
  be the row's position.  (The kernel is unchanged: it already requires
  `id = row + 1`.)
- **Several far areas at `8000h`:** `tools/pack_image.py`'s
  `parse_ihx(text, multi=True)` keeps every value of an address in record
  order; `exepack` maps the n-th value of an address to the n-th covering
  area (ascending id, the link order), so the old "far areas must not
  overlap" refusal is gone and each area's payload comes from its own
  record stream.  A stream/area count mismatch (a hole in one area's
  stream would make the byte ambiguous) is refused, naming the segment.
- **Ports (WORK.md 2.3):** `fardemo` calls its far entry as plain C
  (`FAR1=fardemo_far.c`, `fardemo_far_main` is `__banked`); `xmem_far`
  keeps `farcall` for segment 1's plain entries - the primitive stays
  covered there - and calls `__banked` entries as plain C; the new
  `tests/xmem/xmem_far_code2.c` is segment 2 (`FAR2=`): its plain entry
  keeps 44b's two-bank coverage (`far-call-2`, `far-banks-differ`) and
  its `__banked` entry `xmem_bk2` calls back into segment 1, which is
  what proves the trampoline restores its caller's bank (the literal and
  the latch it reads after the inner call are segment 2's).

## 4. Tests

- **`tests/test_bcall.py` (new, host).**  The spike's findings are
  asserted on a real SDCC build (the `ld e,#b_<fn>` / `ld hl,#_<fn>` /
  `call ___sdcc_bcall_ehl` sequence, `b_<fn> = n` from `-bo n --codeseg
  FAR<n>`, the first argument at `SP+5` of the far definition, and two
  far areas at `8000h` as two IHX streams), and the *shipped*
  `user/sdk/src/bcall.asm` is assembled and run in the host Z80 with the
  SDK members stubbed: results in `A`/`DE`/`DEHL`, `SP` restored, one
  `segmap` for three banked calls (the token cache), and a `__banked`
  definition in the primary bank (`b_` = 0) reporting `0xFFD0` without
  running.
- **Simulator (`tests/xmem/xmem_far.c`, `tests/test_xmem_selftest_sim.py`).**
  The far program grows 18 checks: 0-3 arguments of 8, 16 and 32 bits
  with results, a mixed call, a recursion inside segment 1 (the aperture
  is already open onto the same segment), segment 2's banked entry
  calling back into segment 1, the invalid segment, and "the caller's
  latch is restored" afterwards.  The far program's verdict is now
  `xmem-far: 37 checks, 0 failures`, and the replay also counts
  `SYS_SEG_MAP` (RST 30h with A = 27h) by segment id: exactly
  `{0:1, 1:2, 2:2, 3:1}` - the program's own `segmap(1)`, `segmap(2)`,
  `segmap(0)` and `segmap(3)` plus one cache fill per far segment
  (ids 1 and 2), however many banked calls run.  *(Superseded: the
  committed tree measures `{0:1, 1:5, 2:3, 3:1}`; see the correction-01
  addendum at the end of this record.)*
- **Host rules:** `tests/test_sdk.py` pins the `FAR<n>=` rules (the
  `-bo n --codeseg FAR<n>` order, one `_FAR<n>` base per option, the
  generated one-row-per-option declaration, no `#pragma bank` in far
  sources), `tests/test_exe.py` covers the far-area/id naming, the id
  order, the per-stream split and the stream/area count rule next to the
  16 KiB aperture limit that names the segment.

## 5. Size and cycles

- Trampoline: **68 bytes** of `_CODE`, 4 bytes of `_DATA` (BSS, so the
  SDK's fixed low-data area does not grow).
- Cycles of one banked call (Z80 T-states from the assembled listing; the
  far function's own time excluded):
  - cached path: **310** - `push hl`/`ld c,e`/`call` 32, token lookup hit
    65, `aperture_open` 65, transfer 21, return block 89;
  - first call of a segment: 310 **+ 85** (the cache miss) **+ one
    `SYS_SEG_MAP`**.

## 6. Validation

SDCC 4.5.0 #15242, `git diff --check` clean:

```sh
make clean && make check
make xmem-selftest helloworld-image
git diff --check
```

- `make clean && make check`: **exit 0** (2026-10-12 14:57-15:00),
  `Ran 660 tests ... OK (skipped=105)` - 11 more than 49a's 649 (7 in
  `tests/test_bcall.py`, 4 in `tests/test_exe.py`) - with the image
  replays inside it (production boot, the hwtest card replay, the xmem
  selftest and the far program);
- `make xmem-selftest helloworld-image`: **exit 0** (2026-10-12
  14:40-14:48), `Ran 9 tests ... OK (skipped=2)`.  Both images build (the
  xmem one links `FAR1=` *and* `FAR2=`), `mapcheck` passes, and the xmem
  replays pass with `xmem-far: 37 checks, 0 failures` and the
  `SYS_SEG_MAP` counter (`{0:1, 1:2, 2:2, 3:1}`).  `make
  helloworld-image` also builds and links `fardemo` (the banked-call
  demo, `FAR1=fardemo_far.c`); its own replay runs on demand with
  `BUILD=build-fardemo SYSTEM=<that system>`, and the mechanism the demo
  uses is what the xmem replays and `tests/test_bcall.py` drive in full;
- `git diff --check`: clean (24 files: 3 new, 21 modified).

**Provenance note.**  After the second command ran, two comment lines
were added to `user/sdk/exe.mk` (the far-code rules' explanation of what a
far `.asm` source must do itself).  They are top-level `#` comments, so
`make`'s parse is unchanged: `make -n -B` over a sandbox include of the
file with and without them prints byte-identical command sequences (all
81 commands, the far-code loop and the link included).  The two commands
were therefore not repeated for the edit - no artifact can differ.

## 7. Notes and risks

- **The id convention is the loader's.**  The kernel requires a
  container's segment rows to carry ids `1..N` in order, so "ids 1-4 are
  the far code segments" means "the far code rows come first" rather than
  "`DATA` rows start at 5": a program that builds far code *and* declares
  `DATA` segments lists the far rows first (`1..k`) and the `DATA` rows
  after them.  `exepack` refuses anything else, naming the row.
- **Per-area IHX attribution** relies on the linker writing one record
  stream per area in link order (ascending id), which the rule's link
  order and the spike's measurement agree on; the packer refuses a count
  mismatch rather than silently guessing, so a future linker change would
  fail loudly.
- **The trampoline is in every program's link** (the SDK archive's one
  assembly member, 68 bytes of code).  It is only *entered* by programs
  that make banked calls; the cost to the others is the 68 bytes.
- **`KOS_RT_EFARMAP` (0x30) is SDK-level**: `exe_runtime_error` carries it
  like a kernel errno, so it must stay outside the syscall-visible
  `KOS_E*` values in `abi/kos/errno.h`.
- 44b's "one far area per program, declared twice for two banks" layout
  is gone (the renumbering makes `_FAR2` segment 2), and the mappable
  object that used to prove "same bank as the far segment" now accepts
  either far bank, because the program has two.

## Supervisor review (2026-10-12)

**Accepted.**

- **The spike is thorough**, and the findings are pinned as tests on a
  real SDCC build: the call sequence, `b_<fn>` from `-bo n --codeseg
  FAR<n>`, arguments on the stack with the first at `SP+5`, results in
  `A`/`DE`/`DEHL`, and several `_FAR<n>` areas at `8000h`.
- **Trampoline size:** 68 bytes against the gate's 64. The gate was a
  feasibility bound, and the extra bytes are the error path and the page
  carry. The overrun is accepted, not a stop.
- **Coverage:** it is tested both on the host Z80 (`tests/test_bcall.py`)
  and in the xmem replay (37 checks). The replay includes a cross-segment
  call back into segment 1, recursion, the invalid segment, and the
  `SYS_SEG_MAP` count proving one cache fill per segment.
- **Segment ids:** "far rows first (1..k), then DATA" is the correct
  reading of the loader's `id = row + 1` rule, and `exepack` enforces it.
- **Section 7's "the trampoline is in every program's link" is
  incorrect.** `bcall.rel` is a library member, linked only on reference.
  The monitor and `hello` maps contain no `bcall` symbol. Programs that
  make no banked call pay nothing.
- **Coverage moved, not lost:** the xmem "mappable object in the far
  segment's bank" check now accepts either far bank because the program
  has two. 44b's two-bank coverage is kept by segment 2's checks.
- `make check`: 660 tests pass; production boots in its replay.

## Correction 01 (2026-10-12): the token-cache test's SYS_SEG_MAP count

Work package `work/49b-banked-calls/correction-01/WORK.md`, from the
finding 49c reported in `docs/validation/2026-10-12-sdk-package.md`
section 5.  With the image built,
`tests.test_xmem_selftest_sim.TestXmemSelftest.
test_the_token_cache_costs_one_segmap_per_segment` failed: the image
issues `{0:1, 1:5, 2:3, 3:1}` (10 calls) against the expected
`{0:1, 1:2, 2:2, 3:1}` (6).  Segment 1's fifth call was the open
question: `farcall` maps on every call, and the trampoline was suspected
of filling its cache twice.

### Attribution

Every `SYS_SEG_MAP` (RST 30h with A = 27h) is attributed in the replay:
the program is the one whose gate stub holds the RST address (each
program links its own `_kos_ipc_raw_call`; the RST sits at +10), and the
caller is the first stack frame above the SDK's marshalling chain
(`SP+2` is the return address of the call to `segmap` - today `segmap`
and `kos_ipc_raw` both tail into the stub, so the chain collapses into
that one frame, and the walk skips `_segmap`/`_kos_ipc_raw`/
`_kos_ipc_raw_call` if it ever does not).  Frames are labelled through
each program's own map,
`build-xmem-selftest/user/<name>/<name>.map`.  The ten calls:

| # | program | caller | id | latch | the call |
| --- | --- | --- | --- | --- | --- |
| 1 | `xmem_far` | `_main+233` | 1 | 11 | `segmap(1u)` |
| 2 | `xmem_far` | `_main+335` | 2 | 11 | `segmap(2u)` |
| 3 | `xmem_far` | `_main+417` | 0 | 11 | `segmap(0u)`, refused |
| 4 | `xmem_far` | `_main+431` | 3 | 11 | `segmap(3u)`, refused |
| 5 | `xmem_far` | `_farcall+16` | 1 | 11 | `farcall(1, xmem_far_entry, ...)` |
| 6 | **`xmem_child`** | `_main+391` | 1 | **12** | the child's foreign-segment probe |
| 7 | `xmem_far` | `_farcall+16` | 2 | 11 | `farcall(2, xmem_far_entry2, ...)` |
| 8 | `xmem_far` | `___sdcc_bcall_ehl+58` | 1 | 11 | the token cache's first fill |
| 9 | `xmem_far` | `___sdcc_bcall_ehl+58` | 2 | 11 | the token cache's second fill |
| 10 | `xmem_far` | `_farcall+16` | 1 | 11 | `farcall(1, xmem_far_exit, ...)`, exit from far context |

By caller class: the trampoline `{1:1, 2:1}`, `farcall`
`{1:2, 2:1}`, the far program's own `_main` `{0:1, 1:1, 2:1, 3:1}`
(its four explicit `segmap` calls, the two refusals included), and
`xmem_child`'s `_main` `{1:1}` - whose sum is the measured
`{0:1, 1:5, 2:3, 3:1}`.

### Cause: the child's probe, not the trampoline

The fifth segment-1 call is row 6: `tests/xmem/xmem_child.c`'s
foreign-segment check (`segmap(foreign_seg)`, reached when the tail names
a segment).  The far program execs the child from far context with the
tail `"<handle> 1"` (`tests/xmem/xmem_far.c`'s `make_tail`), so the child
probes id 1 once and prints no failure - the probe is a *refusal* check.
The other child run, from `xmem_selftest`, passes segment 0
(`tests/xmem/xmem_selftest.c`'s `child_tail`: "This program declares no
segments, so the field is 0") and makes no `SYS_SEG_MAP` at all.  The
counter was image-wide, so another program's call was counted against the
far program's expectation.

**The trampoline is clean: no fix was needed and `user/sdk/src/bcall.asm`
is unchanged.**  The run enters `___sdcc_bcall_ehl` **22** times (the
banked matrix, the recursion, segment 2's call back into segment 1, and
the invalid-segment call) and spends exactly **2** `SYS_SEG_MAP` calls,
one per far segment: the cache reads
`[0, 0, 0, 0]` → `[113, 0, 0, 0]` after the first fill and
`[113, 145, 0, 0]` after the second, and the cross-segment return reuses
slot 1 with no syscall.  The supervisor's other candidates (a store lost
on one path, an entry cleared) do not occur either: with the cache-hit
path temporarily disabled (`ret nz` → `nop; nop`) and the image rebuilt,
the count becomes `{1:20, 2:1}` for 22 entries - 21 fills plus the one
refused call - which is the negative check that the corrected test fails
on exactly the defect it exists to catch.

### The test now

`tests/test_xmem_selftest_sim.py`: `SegMapCallCounter` attributes instead
of counting (program by gate stub, caller by frame, and `unattributed`
for anything it cannot place), and
`test_the_token_cache_costs_one_segmap_per_segment` asserts the four
caller classes above, plus `unattributed == []`.  The old image-wide
expectation is gone; nothing is loosened - the classes pin all ten calls,
including the two refusals and the child's probe that the old count
missed.

### The earlier pass was stale

Section 6 of this record reports `make xmem-selftest helloworld-image` at
14:40-14:48 with the counter at `{0:1, 1:2, 2:2, 3:1}`, and section 4
quotes that count.  The committed far program and test pair measures
`{0:1, 1:5, 2:3, 3:1}`, so that value cannot come from the committed
pair: it was recorded before the last edit that made the child probe its
parent's segment id (the counter was never re-measured after it).  The
package's last `make clean && make check` (14:57-15:00) began with
`make clean`, which removes `build-xmem-selftest`, so its 105 skips
included these replays - the same skip set 49c reproduced.  Hence the
pass: a stale run, not a passing test.

### Validation (correction)

2026-10-12, SDCC 4.5.0 #15242:

```sh
make xmem-selftest                     # rebuilds the image, runs its 9 replays
python3 -m unittest tests.test_bcall
git diff --check
```

- `make xmem-selftest`: **exit 0**, `Ran 9 tests in 283.298s`, `OK` - the
  token-cache test passes with the four-class table, and the image's
  other 8 replays are unchanged.
- `python3 -m unittest tests.test_bcall`: **exit 0**, `Ran 7 tests ...
  OK` (the host trampoline test; unchanged, since the trampoline did not
  change).
- `git diff --check`: clean.  The only file the correction changes is
  `tests/test_xmem_selftest_sim.py`; `user/sdk/src/bcall.asm` was
  restored byte-identical to HEAD after the negative check.

### Supervisor review of correction 01 (2026-10-12)

**Accepted.**

- **Every one of the ten calls is attributed:** program by gate stub,
  caller by stack frame, labelled through each program's own map.
- **The unexplained fifth segment-1 call** is `xmem_child`'s
  foreign-segment probe: the counter was image-wide and counted another
  program's call.
- **The trampoline is clean:** 22 entries, 2 fills, one per segment.
- **The negative check is convincing:** with the cache-hit path disabled,
  the count becomes 21 fills plus the one refused call. So the corrected
  test fails on exactly the defect it exists to catch.
- **The test now pins all ten calls by caller class,** with nothing
  unattributed, so nothing is loosened. `bcall.asm` is unchanged.
- **The stale-pass mechanism is explained:** the counter value was
  recorded before the last test edit, and the final `make clean` removed
  the image, so the replay was skipped. The lesson goes to the workers: a
  replay that `make clean` skips must be re-run explicitly after the last
  edit.
