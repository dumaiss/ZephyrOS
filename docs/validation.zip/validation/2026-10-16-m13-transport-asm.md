# M13 transport in assembly (package 61)

Implemented by the supervisor (owner request). Drivers only: the IOC
driver and IOC-FAT. No firmware, nucleus or architecture change.

## Change

| area | change |
|---|---|
| `drivers/ioc/ioc_io.asm` | `ioc_io_exchange`: the whole command exchange - the request packet built from the caller's fields and DATA pointer, its CRC, COMMAND_READY, the masked send, the reply's capture and validation (length bound, CRC, sequence, type binding) and its delivery into the caller's reply frame (DATA, then zeros) |
| `drivers/ioc/ioc.c` | `ioc_command_inner` keeps the guard, the sequence, the lane flags, the DONE interlock and the READY admission, and calls the exchange; the C packet builder, buffers and reply copy are gone; `ioc_admitted_read` |
| `drivers/ioc/ioc_driver.h`, `ioc_proto.c` | `struct ioc_request` names its DATA in place, and the staged reply frame is the reply: no copy layer on the IPC side; `KIOC_OP_COMMAND_READ` |
| `abi/kos/protocol.h` | `KIOC_OP_COMMAND_READ` (6): the command and the bulk receive its READY admits, in one call, into the hot-tier buffer `payload[22..23]` names |
| `drivers/iocfat/iocfat.c` | reads use the one call per block (the READY checks run on the reply after it; a failed one is EIO as before); the read loop's 32-bit divisions and multiplication are shifts and 16-bit ring offsets; the measurement build's ring is two blocks (it reads one block per miss) |
| `tests/test_ioc.py` | the busy-guard pin counts one release per path |

CRC is unchanged and is what CP/M does: the bulk lane bypassed on both
ends, the command request computed and the reply verified, with the same
table-less routine.

## Measurement (simulator, phase image, cold 512-byte miss, path B)

| step | `timer` |
|---|---|
| after 60 | 13.70 ms |
| C copy loops and copy layers removed, 16-bit read loop | 13.21 ms |
| one IOC call per block | 12.98 ms |
| the exchange in assembly | 12.70 ms |

The test file fits the cache, so each miss also stores its block
(~0.5 ms inside `copy`); a large file (SDBENCH's) skips that.

## Board (owner, production image)

SDBENCH, KonaOS logical read, checksum PASS:

| request | 59 | 61 | CP/M |
|---|---|---|---|
| 128 B | 20.59 KiB/s | 21.54 | |
| 256 B | 25.71 | 27.12 | |
| 512 B | 29.10 (17.10 ms) | 31.22 (15.95 ms) | ~39 (12.8 ms) |
| 1024 B | 30.89 | 33.67 | |
| 2048 B | 31.66 | 35.03 | |
| 4096 B | 32.23 | 35.59 (13.9 ms per block) | |

`fs_selftest` 37/0 (card exec included), `hwtest` 4/4.

## Remaining gap

At 512 bytes per call the ~3 ms left is per call: the syscall, VFS and
IPC path (~1.8 ms) and the nucleus copy API's overhead around the bytes
(~0.5 ms). Large requests spread it over their blocks (4 KiB reads are
within ~9% of CP/M). That is nucleus work, outside this package.

## Validation

```
targeted replays (iocfat, readpath, hwtest, console, shell, device release)  OK (59 tests)
make clean && make check                OK (reproducible rebuild 9caf0955...; 779 tests, 115 image tests skipped)
make ipc-selftest                       OK (40 tests)
make phase-image                        OK (15 tests)
make fs-selftest                        OK (3 tests, plus the image's follow-on suites)
git diff --check                        OK
```
