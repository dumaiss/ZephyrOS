# GFX primitives (batch, fill_rect, copy_rect, visible-page clear)

## Result

The primitives are in: `gfx_begin`/`gfx_end`/`gfx_flush` (a
process-local queue of 32 16-byte records, nested begin/end counted
like libtui's transaction depth, flushed in order when full and at the
outermost end, a call outside a batch executing at once),
`gfx_fill_rect` (HMMV) and `gfx_copy_rect` (HMMM whose DIX/DIY come
from the rectangles' overlap, so all four overlap directions copy
exactly, with either page as source or destination).  `gfx_clear`
is the visible page's fill.  A drawing call with the context closed,
an out-of-bounds rectangle, or an odd x/width in the 16-colour mode
is `-KOS_EINVAL` and queues nothing; a zero width or height is a
silent no-op.  `gfx_set_mode` and `gfx_upload_begin` flush a pending
batch first; `gfx_close` discards the queue.  The outcome program
`gfxtest prims` proves the batch and the primitives on the card.

Validated with the package's named batch, then `make clean && make
check` (reproducible rebuild, the full 916-test suite, mapcheck, pack
checks) - all green.  The board run (`gfxtest prims`: a pattern of
fills and copies) is PENDING: no hardware in this session.

## Files

- `user/sdk/include/kos/gfx.h` - the batch declarations
  (`gfx_begin`, `gfx_end`, `gfx_flush`), `gfx_fill_rect`,
  `gfx_copy_rect`, the visible-page clear contract.
- `user/sdk/gfx/src/gfx_internal.h` - `GFX_BATCH_ENTRIES` (32) and
  `GFX_BATCH_DEPTH_MAX` (8), the 16-byte `struct gfx_cmd` (opcode,
  flags, sx, sy, dx, dy, width, height, color, reserved; SDCC
  `_Static_assert`ed), `GFX_OP_FILL`/`GFX_OP_COPY`, the queue and
  depth fields in `gfx_state`, the backend's `v9958_run_batch`, the
  HMMM code and the DIX/DIY and block-offset constants.
- `user/sdk/gfx/src/gfx_batch.c` - begin/end/flush (the depth count,
  the outermost-end flush) and `gfx_batch_submit` (immediate outside a
  batch, queued inside, the full queue flushing itself first).
- `user/sdk/gfx/src/gfx_draw.c` - `gfx_clear` (the visible page's
  fill), `gfx_fill_rect` and `gfx_copy_rect` with the bounds and
  evenness validation; a refusal queues nothing.
- `user/sdk/gfx/src/backends/v9958/v9958_gfx.c` - `v9958_run_batch`
  (one command per record, in order, each started and waited for),
  the HMMV block builder (G6 packing) and the HMMM block builder
  (DIX/DIY from the overlap, the far-edge coordinates in the block).
- `user/sdk/gfx/src/gfx_mode.c` - flushes a pending batch before the
  register state changes.
- `user/sdk/gfx/src/gfx_upload.c` - flushes a pending batch before
  the stream begins (the package 84 placeholder).
- `user/sdk/gfx/src/gfx.c` - `gfx_close` discards the queue.
- `user/sdk/exe.mk` - `gfx_batch.c` as a libgfx member.
- `tests/gfx/gfxtest.c` - `prims`: the ordering batch, the 33-fill
  batch with a key at the auto-flush boundary, the uploaded 4x4
  pattern copied to the four overlap directions, page 1->0 and
  page 0->1 copies with a second key, then the G6 odd-x refusal
  beside a valid fill in one batch, the zero-size no-ops and the
  result codes.
- `tests/test_gfx.py` - the host pins (the batch API, the 32-record
  16-byte queue, the opcodes, `gfx_batch.c` in exe.mk, the port
  discipline over the new source) and the prims replay (below); the
  mode tests' clear pins now the visible page's 212 rows.
- `UserSoftware/PView/src/pview.c` - the clear comment says the
  visible page (the clear itself follows libgfx).
- `tests/test_source_layout.py` - `gfx_batch.c` in `OWNER_FILES`.
- Docs: `docs/sdk.md` (the gfx layout rows, the primitives and batch
  paragraph, the what-links-what rows).  `docs/gfx-sdk.md` is the
  design (sections 8 and 9) and is unchanged.

## Requirement results

1. **Batch.** The replay runs two batches: two fills in order (the
   second on top of the first, both commands and the VRAM outcome
   pinned) and a 33-fill batch whose 33rd queued fill flushes the
   first 32 - the replay stops at the 34th peer command with the hold
   intact (no RELEASE dispatched), proving the auto-flush runs inside
   the batch, and the 33rd executes at `gfx_end`.  Nested begin/end
   counting follows libtui (depth counted, outermost end flushes);
   `gfx_flush` executes the queue wherever the depth stands.  A call
   outside a batch executes at once (the copies and page fills).
2. **fill_rect / clear.** Every fill is one HMMV with the pinned
   block; `gfx_clear` is the visible page's fill - the mode replays
   pin one HMMV (0, 0, W, 212, colour) and every visible row's bytes
   (the PICTURES correction's whole-row model, 256 bytes a row in
   both modes).
3. **copy_rect.** The replay pins the four overlap copies' HMMM
   blocks: (204,22) DIX|DIY with SX/SY/DX/DY at the far edges
   (203, 23, 207, 25), (196,22) DIY, (204,18) DIX, (196,18) neither;
   every destination byte equals the uploaded source pattern and the
   source stays intact.  The page copies (page 1 row 10 to page 0
   row 60, and page 0 row 40 to page 1 row 40) land across the page
   boundary, the 9-bit coordinates pinned in the blocks.
4. **Bounds.** In the 16-colour mode `gfx_fill_rect(1, 0, 2, 2, 1)`
   is `-KOS_EINVAL` inside a batch and queues nothing: exactly one
   command follows (the valid even fill beside it), and the zero
   width/height calls return 0 with no command at all
   (`gfxtest: prims -2 0 0 0`).
5. **Docs.** As listed; `git diff -U0` writing check prints nothing.

## Budgets

Package 85 changes no driver code: the v9958 driver hot image stays
6,468 bytes (ledger 30,995 / 32,768, 1,773 free), the reserve held.
The new code is libgfx's user-side backend and the queue (512 bytes
of a program's BSS when it uses the batch), paid only by programs
that link the drawing entry points.

## Validation

```sh
make && make sdk && make -C UserSoftware/PView test   # test_kimg: PASS
python3 -m unittest tests.test_gfx tests.test_kimg tests.test_sdk_package tests.test_source_layout
# 91 tests, OK
make clean && make check   # once, at the end
git diff --check
```

`make check`: reproducible rebuild confirmed (image sha256
`813aba6fc8bfc380ca0510fb50525a630208afef7c35207c20b047abeaf57519`,
unchanged - package 85 adds no OS bytes), the full suite ran 916
tests in 286.8 s, OK (119 skipped - the acceptance images `make
clean` removes), mapcheck and the pack checks passed, and the
konaos.bin/zephyr80.bin copies compare equal.  Zero failures, zero
errors.

Artifact: `build/user/gfxtest.exe` (13,001 bytes).

## Pins changed

- `tests/test_gfx.py`: the mode tests' clear pins (212 visible rows);
  the new host pins and the prims replay (source: the package's own
  code).
- `tests/test_source_layout.py`: `gfx_batch.c` in `OWNER_FILES`
  (source: the package's own file).
- `tests/test_kimg.py` and `tests/test_gfx.py`: the fixture names the
  PICTURES correction introduced (parrot6.img, parrot7.img,
  parroty.img); no expected output changed.

## Found outside scope

- `UserSoftware/KonaEdit/` files remain modified by parallel work in
  the shared tree; preserved untouched and unclassified here.
- `docs/kres-sdk-design.md` is an untracked unrelated draft; left as
  is.

## Preserved

- The mode register sets, the upload, the palette and the console
  restore are untouched; every package 83/84 test passes.
- The console, TUI, tee, sound and vblank replays all pass unchanged.
- The reproducer: `make clean && make check`'s rebuild hash matches.

## Pending

- Hardware: `gfxtest prims` on the board (a pattern of fills and
  copies, two keys, the console back).  Card program `gfxtest.exe`
  run from the shell as `/fs/gfxtest.exe prims`.

## Correction 1 (supervisor review)

- **The defect:** fills and copies refused only odd x and width in the
  16-colour mode. In YJK, four pixels share one J/K pair (package 84's
  correction), so a rectangle whose x or width isn't a multiple of 4
  splits the runs, and a copy would pair pixels with another run's
  colour. Package 85's spec predated the YJK rule.
- **The fix:** `gfx_draw_ready` (`gfx_draw.c`) refuses a YJK x or width
  that isn't a multiple of 4. The `kos/gfx.h` drawing-call comment says
  so.
- **Test:** `gfxtest prims` ends in YJK, where a fill at x 2 and a copy
  to x 6 are refused (`-2 -2`) and the fill at x 4 runs. The replay
  pins the result line (`prims -2 0 0 0 -2 -2 0`) and that the aligned
  fill is the 45th and last command.
- **Validation:**
  - `tests.test_gfx` / `test_kimg` / `test_sdk_package` /
    `test_source_layout`: 91 OK;
  - PView `test_kimg`: PASS.

## Correction 2 (board finding)

- **The finding:** on the board, `gfxtest prims` showed a black screen
  throughout, though the result line was right (`prims -2 0 0 0 -2 -2 0`
  PASS).
- **The cause:** `prims` never called `gfx_display_enable`, so the mode
  set left the display off while it drew. The replay checked VRAM only.
- **The fix:** after its first mode set, `prims` clears the visible page
  to black and enables the display.
- **Test:** the replay pins that clear as the first command after the
  hold, and R#1's display bit set while the batches draw.
- **Validation:** `tests.test_gfx`: 15 OK.
