# Standalone SDK package (work package 49c)

Work package: `work/49c-sdk-package/WORK.md`.  Working log:
`work/49c-sdk-package/progress.md`.

`make sdk` now produces `build/kos-sdk-0.1.0/` and
`build/kos-sdk-0.1.0.tar.gz`: the headers, the prebuilt `libkos.lib` and
`crt0.rel`, the standalone tools, the program rules, the template, the
examples and the docs, with nothing that refers to the OS tree.  A
developer unpacks the tarball, runs `make`, copies the `.exe` to the card
and runs it with `X /fs/<name>.exe` (or, later, from the shell).

## 1. Files

**Added**

- `tools/ihx.py` - `LayoutError`, `parse_ihx(text, multi=False)` and the
  map parsing (`parse_map_symbols`), moved out of `tools/pack_image.py`;
  imported by `pack_image.py`, `tools/exepack.py`, `tools/exemanifest.py`
  and the tests, and shipped inside the SDK (Python 3 standard library
  only).
- `mk/kos.mk` - the generic `exe_program` rules (the file the SDK ships
  as `mk/kos.mk`), with no OS-tree variable: `KOS_SDK_ROOT`, `KOS_BUILD`,
  `KOS_PYTHON`, `KOS_TOOLS`, `KOS_INCLUDE`, `EXE_ABI_ROOT`, `KOS_LIB`,
  `KOS_MODULES`, `KOS_RULES` all default and are overridden by each user.
  Each declaration also defines a `NAME` target, so an SDK Makefile lists
  its programs in `all` and `make` packs them.
- `config/sdk.mk` - `KOS_SDK_VERSION := 0.1.0`.
- `tools/sdkpack.py` - assembles the tree: resolves the header closure,
  reads `EXE_ABI_VERSION` from `formats/include/exe.h` into `VERSION`,
  copies the library, tools, rules, template, examples and docs, and
  refuses any copied file (outside `docs/`) that names `abi/`,
  `user/sdk` or the repository path.  With `--tar` it also writes the
  `.tar.gz`, with pinned member order, mtimes and ownership.
- `tests/test_sdk_package.py` - the 10 package tests (below).
- `user/sdk/template/Makefile` - the standalone Makefile for the
  template; `user/sdk/template/hello.c`'s header now describes the
  unpack-make-run flow.
- `user/sdk/examples/{Makefile,hello.c,fardemo.c,fardemo_far.c,files.c}`
  - the SDK's example programs (and the in-tree home of the demo
  sources); `files.c` is new (open/read/list).

**Moved**

- `user/helloworld/{hello.c,fardemo.c,fardemo_far.c}` →
  `user/sdk/examples/` (the SDK's examples are the demo image's
  programs).  `user/helloworld/` keeps `Makefile` (now declaring the
  examples from their new home) and `README.md` (rewritten).

**Materially changed**

- `user/sdk/exe.mk` is now the thin in-tree wrapper: sets the in-tree
  roots (`KOS_*`, `EXE_ABI_ROOT := abi`, `KOS_RULES`), builds
  `libkos`/`crt0`/`runtime` from `user/sdk/src`, and includes
  `mk/kos.mk`.  It also builds `build/user/sdk/libkos-sdk.lib`, the
  archive the SDK ships (the same members with `runtime.rel` appended),
  packed with `sdar -rcD` so the shipped library is reproducible.
- `Makefile` - `include config/sdk.mk`; the `sdk` target (`build/kos-sdk-<version>/`
  + tarball, both written by `tools/sdkpack.py`); help text, `.PHONY`.
- `tools/pack_image.py`, `tools/exepack.py`, `tools/exemanifest.py` - the
  parse functions come from `ihx`; `exepack`'s private `parse_symbols`
  is gone (the stricter variant now lives in `ihx`; both parsers produce
  identical output on all 15 built maps).
- `docs/sdk.md` - layout (wrapper/rule, template, examples), build-rule
  section, new section 11 "Using the standalone SDK", `CODEBASE` default
  corrected to `0x015D`.
- `docs/architecture.md`, `README.md`, `user/helloworld/README.md`,
  `abi/kos/{fs,ipc,seg,syscall,xmem}.h` and
  `user/sdk/include/kos{,/console,/ipc,/seg,/xmem}.h` (comments only).
- `tests/test_sdk.py`, `tests/test_source_layout.py`,
  `tests/test_ipc_selftest.py`, `tests/test_ns_selftest.py` - the rule
  properties now point at the file that owns them (`mk/kos.mk` vs the
  wrapper); `OWNER_FILES` follows the moved demo sources.
- `tests/test_bcall.py`, `tests/test_pack_image.py`, `tests/test_sdk.py` -
  import `ihx` directly.

No kernel or driver change.  Unrelated pre-existing changes were
preserved; the only outside-contract files touched are the comment lines
listed above and `mk/`, `config/sdk.mk` (the package's own new owners).

## 2. Result

The package is implemented and validated: the standalone SDK builds a
program with no OS source, that program runs in the simulator through the
(unmodified) production image's monitor, and a copy with a changed ABI
byte is refused.  In-tree builds are **byte-identical** to the baseline.

## 3. Validation

Commands, in order, on 2026-10-12 (SDCC 4.5.0 #15242, 20 cores):

```sh
make clean && make check     # 3:56 wall (the machine builds fast)
make sdk
make sdk                     # again, after forcing the SDK library and
                             # crt0 to rebuild: same tarball bytes
git diff --check
```

- `make clean && make check`: **exit 0**, `check: reproducible rebuild
  (1d5ce5e647ceb45462aca2b89229bc6bb5438b1885d5a406f4b65002ac56ad1b)`,
  `Ran 670 tests in 151.652s`, `OK (skipped=105)`, `make check: OK`.
  The 670 include the 10 new tests; the 105 skips are the
  acceptance-image replays whose images `make clean` removed (the same
  count the 49b record reports).
- The new module's tests all pass in that run:
  `test_the_tarball_holds_the_pinned_layout`,
  `test_the_header_closure_is_complete`,
  `test_version_matches_the_config_and_the_abi_header`,
  `test_the_standalone_tools_use_the_standard_library_only`,
  `test_nothing_in_the_sdk_names_the_os_tree`,
  `test_template_and_examples_build_outside_the_tree`,
  `test_the_packed_program_runs_in_the_simulator`,
  `test_a_changed_abi_byte_is_refused_with_the_existing_error`,
  `test_the_shipped_library_carries_no_build_dates`,
  `test_the_tarball_is_reproducible`.
- `make sdk`: **exit 0**; `build/kos-sdk-0.1.0/` holds **37 files,
  290571 bytes** (283.8 KiB); the tarball is 78368 bytes,
  sha256 `51d674bcbc4224907f86db856ba698fb0365fe802d4e697eb7f00dad1ce3998b`.
- Repacking is deterministic: with `make -B build/user/sdk/libkos-sdk.lib
  build/user/sdk/crt0.rel` between two `make sdk` runs (which recompiles
  every library member and the C startup, so their build dates differ)
  the tarball is byte-identical, sha256
  `51d674bcbc4224907f86db856ba698fb0365fe802d4e697eb7f00dad1ce3998b` both
  times (`cmp` clean).
- `git diff --check`: clean.

Extra runs (reason in brackets):

- Targeted modules while developing (`tests.test_sdk_package`,
  `test_sdk`, `test_pack_image`, `test_bcall`, `test_exe`,
  `test_source_layout`, `test_ipc_selftest`, `test_ns_selftest`) and one
  full `unittest discover -s tests` pre-check (447.7 s, 672 tests, the
  single xmem finding below).
- A clean worktree of the baseline commit `fa31085` in `/tmp` built the
  pre-change artifacts and the same programs for the byte-identity proof
  (section 4).  The worktree was removed afterwards.

## 4. Hashes and transcripts

In-tree artifacts, baseline worktree (`fa31085`) vs this tree - identical
in both:

| artifact | sha256 |
| --- | --- |
| `build/konaos.bin` | `1d5ce5e647ceb45462aca2b89229bc6bb5438b1885d5a406f4b65002ac56ad1b` |
| `build/konaos.ihx` | `bd1390df993892331aade000bddbeb18226eb3280a7feffec969a3b3261d7b5e` |
| `build/user/hello.exe` | `b7bf0ae799e1eb249cbd41ee7b976e8ed04bc03ab1072ba725aa964b8db80979` |
| `build/user/fardemo.exe` | `08e65caaa3084fc3ea88e3add12e87b70058cd377bdcc308c5625c39cf16b948` |
| `build/user/monitor.exe` | `4d27328bd1ca820f156594ef47b5691e0c69369cc33f7da06cbf1772ccca7d18` |

The SDK tree (`build/kos-sdk-0.1.0/`, 37 files, work/49c layout):

```text
VERSION                    f9cf381d8e8c744624eaff884e30f65c4ec60aa3e51997ee9fadd624b684d8cb
docs/exe-format.md         84bb1f03863b93794c069fc789c092b4f2c149db1ce0992c706b71741b929ecd
docs/sdk.md                2247c26f4f81b6e7255afaff3d8899908c453d4fcb19ff828c02ecf4774998d6
examples/Makefile          0702c6901ce65761930c41eb802893ef7065ac8ba57af9386edb7a4c277dcedb
examples/fardemo.c         81a744eae376d9ccd3a9ef8d574898699d8f1d2114f15ea20af8579d8fc9bf74
examples/fardemo_far.c     86aa49cdae6a281f40134d0ca4d01bf4dae5a0c6753bc506d1f1a9d5dc1ca291
examples/files.c           4c13e0d235d35f14e8862f669a02c58700e1042152ae760d4236dfd70324df96
examples/hello.c           327505bf597e973b3fc48f8eab196ea96d24c1c6339a871e2063a9d4c74752e3
include/kos.h              3d68a89720ea93b92efedd88ea7d4630a862e6c3e59873a23ce9f429e31ef00b
include/abi/kos/diag.h     df344f2805666f5315dc0816f8fc7ff9b6dcc8304362ce7e0cc6b209a32d6f61
include/abi/kos/errno.h    9f1f39d6a81cf4c1dc4347df5fdf32b88388f9684607c8a91f7098e7cf5b03a7
include/abi/kos/fs.h       4ae9529d2a2441754f2fb9af726864f827f52a376462600bf25c5687d674352b
include/abi/kos/ipc.h      6e91ecb942293476f03f73fe66cd8bcd006c28f6547aadafdc576568be85f90a
include/abi/kos/object.h   b52aba03d1ba6f554306f01498a2c96cf568a293902f8bdd23b70078d411d3a7
include/abi/kos/process.h  2ef8aa6df438d216cf05a4bf435396c72efd44b7513864256d26931a106053db
include/abi/kos/seg.h      304fe480e953fa4e0222fb89e2b25fe1e04008bb6cd69be0a9e56f1e932d3f00
include/abi/kos/syscall.h  6a590623e832281f9fdfa9f021d6843c11e9cefde8aac84633fe2e632cf12336
include/abi/kos/types.h    c61d995515906ddcb4a78c888597c8a263e30be650dd7b3fd5fb16ba11990d8b
include/abi/kos/xmem.h     bddf46cd050356b7626dfb5a107ce825c25f33aa934bbc8ac8dd797f7e11da1f
include/klibc/fmt.h        9590e8ad1baef2ed17add9b13849ac415f45cc4f0a33d2f6617e7077c9cfc713
include/klibc/stdarg.h     17c4a3a91e5ce66568189d6a5b731e18faf514043533fd8504bf34a386e1fd36
include/klibc/string.h     c1806e8cf1f5429daf3cc97d0e9cfdfd10fe4a38fd4860310fd2e63b3a0a5d7b
include/kos/console.h      7f77073e915d40351450d1b0eddbf46e399667c12f5155502436ec375a3db7aa
include/kos/diag.h         a8aa437e1ac5a50d0873ee3db51db915e63747bdc3ce60f2f0fb945706c8ebf6
include/kos/fs.h           0fba9f024d4a2d44c50749f860dc2279ca0050e31b64850acfa89f932d66b5b2
include/kos/ipc.h          275da9dc6d991d73eb8f7a85538930247a204f94822b6d377dd0517036399ba3
include/kos/process.h      7bfb9cafdb41e187b93f50d4798feb993aa0e53bbe23354a8cd3c8883d7a517d
include/kos/seg.h          3205215c6687f7ccd05bf9ec2709b4f3c0d2aaa06549cb4a12ab9d7af22529b6
include/kos/xmem.h         afdf4780d3d17f144080eb1118248d38b5f460342c2767443f000506ce65c01a
lib/crt0.rel               9c9c5f0a61da341370e3695083f5cdb382b29cad9aba1eee588d84bc84b66fa9
lib/libkos.lib             627ec8887b96c893eeaa38f7bf84a2ca54b049eae43891037222f49c072edd0a
mk/kos.mk                  2cecd966d9c754ecaeee5f5c6a6b27e0aa08091c90709d458ce27101322bdf1f
template/Makefile          12ec389f903657603a919740b2c96fa6402e51685a949428095908005cf3c677
template/hello.c           243361fc203e8672a974ec69142cb9629577f00a098d5ca69a1013c75bdbf1c8
tools/exemanifest.py       da69a3fb2a94280eb6d981b002448f896f0ee12f9b5c6ccfa595c260465aceab
tools/exepack.py           d12c93c943eaae155cfb04656ed0d7771bc29ec0decbe718c50c8dc13072636c
tools/ihx.py               9c9165c3ecf43ad452411ae67b26bb1cdcc8d4daeed94a4ca3e644f5656880a2
```

`VERSION` is `0.1.0 abi 1`.  `lib/libkos.lib` is the `sdar -rcD`
archive: every member's date and ids are zero, so the shipped library
does not record when it was built.

Out-of-tree transcript (the accepted run of
`tests/test_sdk_package.TestSdkPackage`, the assertion each test makes):

- the tarball member set is exactly the 37-file layout and the unpacked
  tree matches it;
- every `#include` inside the tree resolves inside it, and the closure
  reaches exactly the 10 ABI headers the golden list carries;
- `VERSION` equals `config/sdk.mk`'s version plus the ABI number read
  from `formats/include/exe.h`;
- the three shipped tools import only the standard library (and each
  other);
- no file outside `docs/` names `abi/`, `user/sdk` or the repository
  path;
- `make` in `template/` and `examples/` (path-free environment) packs
  `hello.exe`, `fardemo.exe` and `files.exe`, each validating as EXE v2,
  and no build line names the OS tree;
- the production image with a test store (the production store plus the
  out-of-tree `hello.exe`) boots to the monitor prompt, and
  `X /system/hello.exe` prints `Hello, KonaOS!`;
- the same store's `abi-probe.exe` (the built hello with byte 05h, the
  ABI version, changed to 2) is refused: the monitor answers `ERR: 02`
  and the program's line never appears, while the unchanged copy in the
  same store runs;
- `lib/libkos.lib` carries zero member dates and ids (the `sdar -rcD`
  archive), and repacking the shipped tree with `sdkpack.pack_tar`
  reproduces the shipped tarball byte for byte (order, mtimes,
  ownership, gzip header).

## 5. Findings, warnings, deviations

- **Pre-existing (not this package):** with the xmem acceptance image
  present (`make xmem-selftest`), that target fails:
  `tests.test_xmem_selftest_sim.TestXmemSelftest.
  test_the_token_cache_costs_one_segmap_per_segment` expects
  `{0:1, 1:2, 2:2, 3:1}` SYS_SEG_MAP calls but the image makes
  `{0:1, 1:5, 2:3, 3:1}`.  Reproduced at the baseline commit `fa31085`
  in a clean worktree with the identical image
  (`3361cb34351fe2c3624b08a6fee3ae36e705b2626dc7d9b0a95142ca081c54dc`)
  and in a fresh `make xmem-selftest` there, so it is not a 49c
  regression.  The counter also counts the program's own
  `segmap`/`farcall` calls, so the expectation predates the final
  `xmem_far.c`; 49b's record reports a pass from before the test's last
  edit, and its `make check` had the image cleaned.  Not fixed here
  (another package's acceptance test; changing its expectation would
  weaken it).  `make clean && make check` skips these replays (the image
  is removed).  **Corrected by `work/49b-banked-calls/correction-01`:**
  the extra id-1 call is the child program's foreign-segment probe
  (`tests/xmem/xmem_child.c`), not a trampoline miss; the test now
  attributes every call to its caller and the trampoline spends one
  `SYS_SEG_MAP` per far segment (see the addendum in
  `docs/validation/2026-10-12-banked-calls.md`).
- **Deviations from a literal reading of the layout**, both recorded in
  `docs/sdk.md` section 11:
  - the ABI headers are copied to `include/abi/kos/` rather than
    flattened into `include/kos/` (the SDK's own headers of those names
    live there), and the compile line keeps the tree's root order,
    `-I include/abi -I include`, so every header keeps the include path
    its text names (`kos/…`, `klibc/…`) and the closure still resolves
    inside the tree;
  - `lib/` is pinned to two files, and every program links the shared
    runtime object, so the SDK's `libkos.lib` carries `runtime.rel` as
    its last member.  It is a second artifact
    (`build/user/sdk/libkos-sdk.lib`) so the in-tree archive and program
    bytes stay unchanged.
- **Reproducible package, one archive left with dates:** the tarball
  pins its own metadata (`tools/sdkpack.py --tar`) and the shipped
  library is archived with `sdar -rcD`, so relinking and repacking
  unchanged sources reproduces the package byte for byte (section 3).
  `sdar` keeps every member's date by default, so the *in-tree*
  `libkos.lib`, which this package does not own, still records its build
  time; the linker ignores those dates (the baseline comparison in
  section 4 rebuilt every library and left every program and the image
  byte-identical), and only the archive the SDK ships needed the fix.
- **ABI-refusal error wording:** `SYS_EXEC` maps every loader refusal
  (`EXE_EXEC_ERR_* <= -20h`, the ABI check included) to `KOS_EINVAL`
  (`kernel/syscall.c`), so the monitor's existing error for a malformed
  container is `ERR: 02`.  The test pins that, plus "the refused program
  never ran" and the same store's unchanged copy running.
- **Template fix:** `user/sdk/template/hello.c` did not compile (SDCC
  error 196, a conditional mixing `char *` with a string literal, twice)
  - it had no in-tree build line.  It is fixed so the template builds at
  all; the examples got the same treatment where they used the idiom.
- Warnings: none from the new code.  The suite's `ResourceWarning`s come
  from `tools/modpack.py` (pre-existing).
- Hardware: none required.  The package changes no kernel, driver or
  image; production booting is covered by `make check`.
- Semantics of the SDK archive member order: `sdar` archives are scanned
  to a fixpoint by sdldz80 (verified while building the template and all
  three examples out-of-tree).

## Supervisor review (2026-10-12)

**Accepted.**

- **The SDK:** 37 files and a reproducible tarball (`sdar -rcD`, pinned
  tar metadata). The out-of-tree build of the template and the three
  examples works; `hello.exe` from the SDK runs on the unmodified
  production image; the changed ABI byte is refused.
- **In-tree builds unchanged:** production, `hello`, `fardemo` and
  `monitor` hashes match the baseline.
- **Both layout deviations are sound:** `include/abi/kos/` keeps every
  header's own include path, and `runtime.rel` is carried inside the
  shipped `libkos.lib`.
- **The template now compiles:** it never had an in-tree build line, so
  the old one was broken.
- **The section 5 xmem finding is a 49b defect,** not 49c's. The
  expectation forgot that `farcall` calls `segmap` each time, which
  accounts for segment 2 (3). Segment 1 has one unexplained extra call
  (5 against 4). 49b's pass came from a stale run.
  `work/49b-banked-calls/correction-01` attributes every call, fixes the
  trampoline if it fills its cache twice, and tightens the test to one
  trampoline fill per segment.
- **Timing:** `make clean && make check` took 3 min 56 s on this machine,
  for 670 tests.
