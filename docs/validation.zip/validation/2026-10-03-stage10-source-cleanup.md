# Stage 10 — production/test driver layout cleanup (2026-10-03)

Host validation for work package `10-production-test-driver-layout`:
production drivers, module packaging/runtime support, and milestone
acceptance code were separated, and the M3 static-driver mechanism was
retired.  Removing the linked static scaffolding changes kernel layout,
so **physical Zephyr-80 smoke validation must be re-run** (see below).

## Host validation (all green)

```sh
make clean
make check
make syscall-selftest
make irq-selftest
make m3-selftest
make zmod-test
make m4-loader-selftest
make m4-selftest
make m4-placement-selftest
make m4-failure-selftest
python3 -m unittest discover -s tests -v     # 232 tests, 0 skips
```

- `mapcheck.py --production` proves the production map (166 symbols) has
  no `_driver_init_static`, `_boot_drivers`, `_driver_static_*`, `_m3_*`,
  `_zos_run_*`, `_m4_selftest*`, `_z4_fixture*`, `_sio_module_irq*`,
  `_sio_irq_module`, `_sio_fail_module`, or `_target_test` symbol.
- The production image print path is unchanged (`console: dynamic sio0.b
  OK`); all simulator replays of the real linked bytes pass.

## ZMOD byte identity

| Artifact | SHA-256 | Note |
| --- | --- | --- |
| `build/modules/sio.zmod` | `2543e08e529f190c9812a15af1d4f513f9e99a83a2a5d39d782f1c1278d36dd5` | **unchanged** (production entry split without byte changes) |
| `build/modules/sio-irq.zmod` | `88e128f7bd58048056afac66a64905535664d88d476a7954dde188b10d358113` | **unchanged** |
| `build/modules/sio-fail.zmod` | `a48046f8cc6367e94e749a8edab8e7f2686b5e63704826d8ba64709874678870` | changed: test entry `sio_fail_module.c` replaces the old conditional branch |
| `build/modules/m4_probe.zmod` | `150c054eaed06b4ec19a05de9497c2147c25dc6d4b12652785bf156d1b650bdf` | unchanged |
| `build/modules/m4_fail.zmod` | `e760505bc4d1aa3d3cf4b044e3171769a2cd9f688335ba0ae8eb0166af060975` | unchanged |
| `build/modules/m4_filler.zmod` | `fb7aca3336ceac01ac03773b88069e12c23d6113cfdc9d265c4fd2f9e87d7e37` | unchanged |

## New ROM image hashes (old hashes invalidated by the layout change)

| Image | SHA-256 |
| --- | --- |
| `build/zephyros.bin` (production) | `b0e143c1b0058b76a9ed7770544293143167affefab2299b675b439844b03378` |
| `build-selftest/zephyros-selftest.bin` | `313bb189d08fe444f297e53558b11407bea8760e83e38bafc7ddccb126a36bd9` |
| `build-irq-selftest/zephyros-irq-selftest.bin` | `76b31f243caefff038e251df1cc4a82c4ca3f622db22fba87cba33038d4d56b9` |
| `build-m3-selftest/zephyros-m3-selftest.bin` | `d4a76b99f560a22e82c1f70b683e528c403372af15dcbe136bafda7326a3aaea` |
| `build-m4-loader-selftest/zephyros-m4-loader-selftest.bin` | `f5dce6b043b4e636b8c66ebc8ca4c744ddd8e53fd6a0e598dda99ef5801ac19f` |
| `build-m4-selftest/zephyros-m4-selftest.bin` | `c831309409f7cd2a9d86f3b389c27d225c270ee1d96db159d432aa96bead9418` |
| `build-m4-placement-selftest/zephyros-m4-placement-selftest.bin` | `8d6990a7f7b8cc21926502363c54d4faa8dbf1dc2fa14887c0001278bba536c5` |
| `build-m4-failure/zephyros-m4-failure.bin` | `878f73278673cf72f21ebf441caf25bd528e2423af7702cb1688d7deed3e39e2` |

A complete `.bin`/`.zmod` hash list was captured at
`/tmp/zephyros-10-post.sha256` (regenerate with the `find build* ...`
command in `work/09-source-tree-architecture-alignment/WORK.md`).

## Pending physical validation (NOT yet run)

Removing the linked static scaffolding changed kernel layout, so the
previous 2026-10-02 hardware acceptance does not automatically carry
over.  Flash and smoke each image:

| Image | Command | Expected transcript |
| --- | --- | --- |
| `build/zephyros.bin` | `make smoke-hardware SERIAL_PORT=...` | banner only |
| `build-m4-selftest/...bin` | `make smoke-hardware-m4 SERIAL_PORT=...` | banner + `console: dynamic sio0.b OK` + `m4 loader selftest: OK` + `m4 selftest: sio at 0xA000` + `m4 selftest: OK` |
| `build-m4-placement-selftest/...bin` | `make smoke-hardware-m4 SERIAL_PORT=...` | same, `sio at 0x9E00` |
| `build-m4-failure/...bin` | `make smoke-hardware-m4-failure SERIAL_PORT=...` | banner + `console: dynamic driver failed` + `m4 failure selftest: OK` |

Do not claim physical acceptance until the transcripts are captured.
