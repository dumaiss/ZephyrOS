# M10 stage 3 — IPC substrate (work package 39)

Promoted the package-35 resident-service IPC spike into the nucleus:
`kernel/ipc/` (endpoints, the 32-byte frame, descriptor capture and the
copy primitives, nesting and re-entrancy, the fixed service stack, IRQ
ownership), the pinned `SYS_IPC_LOOKUP`/`SYS_IPC_CALL` pair in
`abi/zos/ipc.h`, libzos client support, a cold loader that places the six
synthetic services in bank 6, and the `ipc-selftest` acceptance image.  The
spike configuration (`ZOS_RSVC_SPIKE`, `tests/target/rsvc/`,
`tests/test_rsvc_spike*.py`, `tools/rev13_layout.py`,
`tests/m10/two-bank-classification.json`) is retired.

Simulator and host evidence only: the hardware pass is the owner's
(`make ipc-selftest` on the bench plus `make smoke-hardware`; the
IRQ-during-a-call case is hardware-authoritative).

## 1. Validation batch

| Command | Result |
| --- | --- |
| `make clean && make check` | OK, reproducible rebuild `d017f133…`, 807 host tests |
| `make ipc-selftest` | OK, 34 tests (19 host + 15 replay), `ipc: PASS`, 55/55 checks |
| `make m9-selftest` | OK, 7 tests, `m9 selftest: OK` |
| `git diff --check` | clean |

Production image: `d017f133b43d8821b20d1547b3c2c7c0a1713b936b5eb41b8df8a467c3e7d33f`
(byte-identical to package 38; the substrate links only into the
acceptance image).  `ipc-selftest` image:
`07eb6952eff440db5a96f055ce3fab2b70080de0a19238301928571ecc51d3af`.

## 2. The five ledgers (`build-ipc-selftest`, SIO-only boot set)

```text
nucleus fixed: required 6468 bytes | overflow 2489 bytes | stacks 768 | room 6659 bytes
nucleus cold: code 25906 bytes end C532h | arena 8 granules (1 boot, 7 free) | data 2168 bytes at D600h | room 598 bytes
service hot: 0 bytes of 32768
service boot/bulk: 0 bytes of 24576
common: used 2106 of 7424 bytes (code 1412, data 694) | ceiling 3072, m10 512, limit 2560
```

`service hot`/`boot-bulk` stay 0 because the synthetic services are
acceptance fixtures placed directly by the cold loader, not service images
through the stage-4 registry (package 40).  Their 2,454 linked bytes are
part of this image's fixed core (the spike did the same); the loader
itself is 1,186 bytes of cold code, so no loader stays in the fixed core.

Production is unchanged in every ledger field (fixed core end `53DEh`,
979 bytes of room; cold half end `99E6h`).

## 3. Substrate cost against package 35

| Object | Code | Data |
| --- | --- | --- |
| `kernel/ipc/ipc.c` (`ipc`) | 2,298 | 264 |
| `kernel/ipc/ipc_asm.asm` (`ipc_asm`) | 141 | 19 |
| **total** | **2,439** | **283** |
| package 35 (spike core + asm) | 3,900 | 343 |

−37 % code, −17 % data.  The cold half additionally carries
`kernel/syscall/ipc.c` (143 bytes) and the loader (1,186 bytes).  The
512-byte service stack is an ABS reservation (`ZOS_SERVICE_STACK_BASE`,
5D00h-5EFFh), so it costs no linked bytes.

## 4. Cycles against package 35

Measured by the same instrument (the package-34 T-state table and the
spike's marker-segment method: 8 warm-up calls, 24 measured calls per
phase, per-call = measured segment):

| Phase | This package (T) | Package 35 (T) | Δ |
| --- | --- | --- | --- |
| null call | 15,546 | 9,858 | +58 % |
| 256-byte `con.WRITE` | 107,436 (420 T/B) | 129,260 (505 T/B) | −17 % |
| 512-byte chain, direct | 89,992 (175.8 T/B) | 84,787 (165.6 T/B) | +6 % |
| 512-byte chain, staged | 114,450 (223.5 T/B) | 110,987 (216.8 T/B) | +3 % |
| today's direct `FS_READ`, 512 B | 306,757 (599 T/B) | 300,952 (587.8 T/B) | +2 % |
| today's direct console write, 256 B | 166,751 | 165,532 | +1 % |

The kernel-side share (gate entry to gate return) is 8,397 T of the
15,546-T null call, 100,132 T of the `con.WRITE`, 82,513 T of the direct
chain and 106,968 T of the staged chain; the rest is the client's own
marshalling through libzos.

The chain is 3.4× cheaper than today's direct filesystem read of the same
chunk (chain/direct ratio 0.29), and `con.WRITE` beats the direct console
write above the same break-even the spike found.  The null call is the one
figure that grew: the promoted path is production-shaped (the SDK wrapper
copies the frame through the exported low-window block and the syscall
body is cold-half code), where the spike's dispatcher ran in the fixed
core with the evaluation client's own stub.  It remains one crossing per
call and is dominated by the per-call frame copies, not by the substrate.

## 5. Interrupt delivery, stacks and latch discipline

* Three CTC0 deliveries (one per `SPIN`, including the unclaimed one the
  executive quiesces) land at `8DEEh`, inside the service domain; each
  runs on the ISR stack and the nucleus executes the final `RETI` at
  `E1D7h` (common), never inside the domain.
* 229 service-domain intervals: every one closes on the latch value that
  was in force before it opened, and every SYS_IPC_CALL return restores
  the *caller's* whole latch (mode 10, bank 0, page bits clear).  The
  interrupted call's interval closes on its own entry latch, so the
  package-36 trampoline bug does not reappear.
* Stack high-water marks: service stack `5E08h` (248 of 512 bytes), ISR
  stack `5FF4h` (12 of 256), gate stack `E5FAh` (147 of 256, common).
* 1,153 window `LDIR`s inside the domain (121,817 bytes, largest 512) —
  the descriptor copies really run in the service mapping.
* Lookup census: nine SDK lookups produce eight `SYS_IPC_LOOKUP` syscalls
  (the libzos cache answers the repeat), all through one marshalling block
  inside the caller window, plus one refused out-of-window block.

## 6. Deviations and notes

* **Syscall dispatch.** Production must stay byte-identical and therefore
  links neither the substrate nor the cold bodies, so the two pinned
  numbers are routed to those bodies from the acceptance seam
  (`#if ZOS_TARGET_TEST_BUILD` hook in `kernel/syscall.c`, implementation
  and per-image selection in `tests/target/support/target_test.c`).
  Production returns `ZOS_ENOSYS` for `06h`/`07h` until package 41 moves
  the routing into the dispatcher proper.
* **Argument-block placement.** The gate leaves only `0100h-1FFFh` of the
  caller's bank visible, so an IPC argument block must live in a
  low-window scratch.  libzos' IPC blocks are exported
  (`zos_ipc_lookup_block`, `zos_ipc_call_block`, `zos_ipc_raw_req`) and
  the acceptance tests prove their placement; the client program's whole
  image+BSS ends at `1FBEh`, 66 bytes below `2000h`.
* **Found and fixed while promoting:** the SDK's IPC gate stub returned
  the error-flag pointer instead of the primary result (`ipcgate.asm`),
  and the SDK object rules did not depend on the installed headers, so a
  header change silently kept the previous archive (fixed in
  `user/sdk/zex.mk`).
* **mapcheck** learned the `test_link` placement model (objects production
  does not link yet, held to the placement it will have in package 41) and
  rejects a `cold_half` list naming a `fixed-required` object.
* The `ipc_gate_latch` accessor (two instructions in `ipc_asm.asm`) exists
  because a C unit cannot name an assembly global without the C
  underscore prefix; the spike used the same indirection.

## 7. Hardware

PENDING (owner): run the `ipc-selftest` image on the bench and
`make smoke-hardware`.  The simulator injects the CTC0 deliveries, so the
IRQ-during-a-call cycle count and the exact latch restore inside the
interrupt are only hardware-authoritative; everything else in this record
is a deterministic replay of the linked bytes.  Section 8 is the same
statement for correction 01's copy paths: the mode-10 window's timings,
the deferred interrupt in the aperture stub and the common-resident push
it relies on are all simulator truths until the bench run.

# Correction 01 — copy paths for every caller-buffer location

Contract: `work/39-m10-ipc-substrate/correction-01/WORK.md`.  It supersedes
architecture 36.8's single-`LDIR` claim: the promoted primitive was only
valid for a caller buffer in `0000h-1FFFh`, and the five-address matrix
below is what closes that gap.  Architecture 36.6/36.8 are amended by the
supervisor after this package; the headers, `docs/abi.md` section 12 and
`docs/sdk.md` already carry the corrected contract.

## 8. What changed

* `kernel/ipc/ipc.c` picks a path per request.  A: caller buffer in the
  caller window or in common - one `LDIR` in mode 11, as before.  B: the
  service buffer is in bank 6's `8000h-BFFFh` and the caller buffer is in
  the caller's bank clear of that range - one `LDIR` in mode 10 with
  Q = the caller's bank and P = 1, the aperture showing bank 6 at the
  service's own address.  C: everything else, including a service buffer
  outside `8000h-BFFFh` - chunked through the existing common
  `zos_bank_copy` gate and counted as slow.  A fixed-core bounce buffer
  was not used: the fixed core is not mapped in mode 10 at all, so it
  cannot bridge the two sides, and a common bounce would have needed
  supervisor approval.  **Fixed-core bytes of any bounce buffer: 0.**
* `kernel/ipc/ipc_common.asm` (new) is the path-B primitive: 44 bytes of
  common code and 14 bytes of common data (`ipc_ap_req`, the saved latch
  and SP, and a 4-byte reservation an interrupt taken in the window pushes
  onto).  It moves SP into common for the length of the window, installs
  the mode-10 latch, runs one `LDIR` and restores the latch before it
  touches the stack again.  `tools/mapcheck.py` now requires
  `_ipc_ap_copy` to be common-resident.
* Descriptors capture the full latch as before; capture now also accepts
  the common window (`E000h-FFFFh`), and `desc_bank()`'s aperture rule
  carries the package-43 hook: a nonzero-page aperture descriptor resolves
  to the far bank `7 - P` and lands on path C; no token mechanism is
  implemented here.
* Three fixed-core counters (`ipc_copy_window`, `ipc_copy_aperture`,
  `ipc_copy_slow`) record the resolver's decision per request, so the
  replay attributes every case from outside the program.
* The six service containers compile with `--dataseg SERVICE_IO`: the data
  area the rule talks about is now named, the manifests list it as
  `_SERVICE_IO`, and the cold loader refuses a container whose image+data
  would leave bank 6's `8000h-BFFFh`.  `con` gains the deliberate
  out-of-range target at `0x7000` (`IPC_FRAME_SLOW_IO`), and `irqx` gains
  the copy op that arms CTC0 on a short time constant so a delivery lands
  inside a path-B window.
* `tests/target/ipc/ipccopy.c` (new) is the image's boot program.  It is
  linked `NO_CRT0` with `CODEBASE=0x0300` (`user/sdk/zex.mk` gained the
  option), which leaves `0100h-02FFh` as a plain 512-byte buffer - the
  only way a ZEX can name the caller window itself - and starts the
  promoted client with `zos_exec`, folding its verdict into
  `ipccopy: PASS`.  Its image is 4,067 bytes + 140 BSS (ends `116Fh`).

## 9. The five-address matrix (chained 512-byte read + single `copy_out`)

| Caller buffer | Path | Read T/call | Read T/B | Single T/call | Single T/B |
| --- | --- | --- | --- | --- | --- |
| `0100h` (window) | A | 92,244.5 | 180.2 | 81,896.5 | 160.0 |
| `3000h` | B | 92,908.5 | 181.5 | 82,560.5 | 161.3 |
| `7000h` | B | 92,908.5 | 181.5 | 82,560.5 | 161.3 |
| `C000h` | B | 92,877.5 | 181.4 | 82,529.5 | 161.2 |
| `9000h` | C | 121,544.5 | 237.4 | 111,196.5 | 217.2 |

Package 35's single figure (165.6 T/B) was the spike's window path;
correction 01's window path measures 180.2 T/B (+9 %, the same code plus
the counters and the stricter service-side check) and paths B measure
181.4-181.5 T/B (+1 % over the window path).  M9's baseline on the same
chunk is 587.8 T/B, so every case is well under today's direct path; path
C pays 237.4 T/B because it is chunked through the copy gate, which is the
documented cost of a caller buffer the aperture cannot show.

The service-side slow case (`con.WRITE` from a window caller buffer with
the service target deliberately outside `8000h-BFFFh`) takes path C at
30,752.8 T/call for 16 bytes (1,922 T/byte: the per-chunk gate switch
dominates at that size), and the IRQ case (four path-B copies per call)
runs 163,554.4 T/call, 79.9 T/byte.

Bytes arrive intact in every case: the probe checks the IOC pattern after
each chained read and single copy, the irqx service sums what landed in
its own buffer and the probe compares it with its own sum, and the replay
checks the slow case's 16-byte pattern on the console wire.

## 10. Path evidence (replay)

* Path census from the resolver's counters, per case, matching the table
  above exactly: `window` for `0100h`, `aperture` for `3000h`/`7000h`/
  `C000h`/the IRQ case, `slow` for `9000h`/the service-side case.
  Totals across the probe: `ipc_copy_window` +20, `ipc_copy_aperture`
  +100, `ipc_copy_slow` +30 - exactly 10 calls per case.
* 100 latch installs inside the aperture stub's common range, each one
  followed by a write restoring the latch that was in force immediately
  before it, and 100 aperture `LDIR`s (512 bytes each) executed with the
  mode-10 latch live.
* Forged-descriptor refusal is proved at every one of the five caller
  addresses (the copy is refused before any path is chosen).

## 11. Interrupt during path B

* Ten CTC0 deliveries are taken *inside* a path-B window: `latch = 30h`
  (mode 10, Q = 0, P = 1) with `SP = E874h`, inside the 4-byte common
  reservation the primitive installs.
* Each one is followed by the IRQ gate's exact restore of the interrupted
  latch (`30h`) and a `RETI`; the interrupted copy still completes and
  every install in the run restores exactly.  The probe's own check sees
  the deliveries in the op's reply (`apcopy-irq >= 1`).
* Deliveries in the mode-11 domain are still three (one per `SPIN`), so
  the model's timer profiles are disjoint: the short correction profile
  only delivers in the window.

## 12. Ledgers and common bytes after correction 01

```text
nucleus fixed: required 6722 bytes | overflow 2989 bytes | stacks 768 | room 5905 bytes
nucleus cold: code 25925 bytes end C545h | arena 8 granules (1 boot, 7 free) | data 2168 bytes at D600h | room 579 bytes
service hot: 0 bytes of 32768
service boot/bulk: 0 bytes of 24576
common: used 2164 of 7424 bytes (code 1456, data 708) | ceiling 3072, m10 512, limit 2560
```

**Common bytes added by the B stub: 58** (44 code + 14 data), taking the
packed common run from 2,106 to 2,164 of the 2,560 limit; the stub is the
first tenant of the 512-byte `ZOS_COMMON_M10_RESERVATION` that work
package 30c held back for exactly this.  Six service containers end at
`922Fh`, 11,729 bytes inside the `8000h-BFFFh` service I/O range; the
fixed core's `ipc` object grew by 48 bytes (the path selection and the
counters) and the cold half by 19 (the loader's range check).

## 13. Correction-01 validation batch

| Command | Result |
| --- | --- |
| `make clean && make check` | OK, 824 tests (17 new, 214 skipped for want of their images), production byte-identical |
| `make ipc-selftest` | OK, mapcheck 20 areas / 377 symbols, 51 tests (30 host + 21 replay), `ipccopy: PASS` 23/23, `ipc: PASS` 55/55 |
| `make m9-selftest` | OK, 7 tests |
| `git diff --check` | clean |

Production image: `d017f133b43d8821b20d1547b3c2c7c0a1713b936b5eb41b8df8a467c3e7d33f`
(unchanged: production links none of the substrate, and the aperture
reservation is a platform constant the production geometry never reads).
`ipc-selftest` image:
`df2a6f5aabbcae4e543637dda6e963ce6809ae0be942ad4788b7f97abfe118da`
(sections 9-12 measured exactly this image; no source moved after it was
built, so the correction's batch rebuilt nothing).

Repairs to the pre-existing replay suite (`tests/test_ipc_selftest_sim.py`),
all evidence-side rather than substrate-side:

- the latch write trace is a save/restore *tree*, not a sequence: the copy
  gate opens a mode-10 identity excursion inside the service domain once
  per staged chunk, so a flat "domain open/close" model read those chunks
  as the end of the call.  The tracer now matches every mapping write
  against the innermost open node, and the discipline test checks what a
  call promises: no call returns with anything but its caller's latch,
  and no domain outlives the call that opened it (the loader's own
  intervals, opened without a syscall around them, close the same way);
- the marker census covers both programs' phase codes (the client's in
  lower case, the probe's in upper case), and the SDK-cache census is
  anchored on the client's banner line, which precedes its first lookup -
  the probe looks five classes up before it boots the client;
- the CTC0 test is scoped to the platform profile's three deliveries; the
  probe's ten short-profile deliveries inside the aperture window are
  `TestIpcCorrection01`'s `test_irq_during_path_b_restores_the_window_exactly`.

Hardware: PENDING, as in section 7 - the aperture window, the deferred
interrupt inside it and the common push it lands on are simulator facts
until the bench run.

## Supervisor review (2026-10-08)

**Accepted, including correction 01**, on the record's evidence:
- production stays byte-identical at `d017f133…`;
- the five-address matrix with per-path counters, an interrupt inside
  path B, and forged descriptors on every path;
- 58 common bytes, all from the M10 reservation.

The decision not to use a fixed-core bounce buffer is correct: the fixed
core is not mapped in mode 10.

The results are folded into architecture 36.6, 36.7, 36.8 and 36.20:
paths A/B/C, the `SERVICE_IO` rule, and the null-call cost.

Carried forward:
- **Package 40** formalizes `struct ipc_service_api`
  (`include/zephyros/ipc.h`) as the service bootstrap interface, and the
  `SERVICE_IO` area in the service-image format.
- **Package 41** moves the `SYS_IPC_*` routing from the test seam in
  `kernel/syscall.c` into the dispatcher, and removes that seam.
- **Watch item:** the null call rose from 9.9k to 15.5k T, dominated by
  the frame copies. It stays acceptable while hot paths are batched.
  Revisit it if the console protocol in package 41 shows it.
