# M4 Module Loader Hardware Validation — 2026-10-02

## Status

- **Host validation: PASS.** 187 host tests (0 skipped with all milestone
  images present), reproducible clean rebuild, ZMOD tooling verified
  byte-for-byte against `sdldz80`, and a linked-byte simulator replay of
  the complete M4 target self-test plus every loader rejection class.
- **Physical Zephyr-80 validation: PASS (2026-10-02).** The M4 loader
  self-test image was programmed into the board; the captured transcript
  below shows the complete expected output. **Stage `07-m4-module-loader`
  is hardware-validated.** Full M4 acceptance (dynamic SIO driver) remains
  stage `08-m4-dynamic-driver-acceptance`.

## Implemented (stage 07)

- Linker-reserved `A000h-BFFFh` bank-7 driver arena: 16 contiguous
  512-byte granules, exported as `__driver_arena_start` /
  `__driver_arena_end`; kernel loadable sections restricted below
  `A000h`; mapcheck/pack_image/manifest enforce and report the region.
- ZMOD v1 container (packed 28-byte little-endian header, `ZREL_ABS16`
  relocation records) and its kernel contract in
  `include/zephyros/module.h`.
- Deterministic first-fit granule allocator and transactional loader:
  validation before any arena write, copy/BSS/relocation, relocated init
  with driver API v1, optional fini cleanup, device + IRQ claim rollback
  with module owner tokens, zero/release of failed allocations, and
  RESIDENT modules that cannot be unloaded.
- IRQ registry claim serials/checkpoints and handler-address validation
  accepting linked bank-7 code or committed/active module images.
- Embedded name/blob/size catalog (empty in production builds; synthetic
  fixtures in the self-test build).
- Host tooling `tools/zmodpack.py` (`pack`, `validate`, `dump`,
  `emit-asm`) and synthetic fixtures proving relocation at two arena
  addresses, failed-init rollback, BSS zeroing, IRQ rollback, and
  exhaustion.

See `docs/module-format.md` for the format and loader lifecycle.

## Physical validation

Artifacts validated on hardware:

```text
build-m4-selftest/zephyros-m4-loader-selftest.bin
  sha256 31e1474980587b4dae08bb41db83f1b6d69c0e8ba77fd96d7802c447131bd65b

embedded fixtures:
  m4_probe.zmod   sha256 150c054eaed06b4ec19a05de9497c2147c25dc6d4b12652785bf156d1b650bdf
  m4_fail.zmod    sha256 e760505bc4d1aa3d3cf4b044e3171769a2cd9f688335ba0ae8eb0166af060975
  m4_filler.zmod  sha256 fb7aca3336ceac01ac03773b88069e12c23d6113cfdc9d265c4fd2f9e87d7e37
```

Command and transcript (`make smoke-hardware-m4 SERIAL_PORT=/dev/ttyUSB0`,
115 bytes captured):

```text
serial_smoke: listening on /dev/ttyUSB0 at 115200 8N1 (mode=m4, timeout=15s)
serial_smoke: captured 115 bytes
ZephyrOS 0.0
platform: Zephyr-80
kernel entry: OK
serial: OK
HALT
console: sio0.b OK
m4 loader selftest: OK
serial_smoke: OK (the banner, the console service line, and 'm4 loader selftest: OK')
```

### What the hardware run proves

- `A000h-BFFFh` is usable bank-7 RAM in mode `11`; the arena survives the
  real address decoder and SRAM.
- The ZMOD containers embedded in ROM load, relocate, and initialize at
  the loader-chosen addresses (identical probe bytes at two addresses).
- BSS is zeroed over real SRAM: the reset copier fills bank 7 from the
  ROM page (arena bytes are `FF`), so a missed BSS clear would fail the
  filler's 600-byte pad check; it passed.
- Failed module initialization rolls back its device registration and IRQ
  claim; claims made by resident modules register correctly (no delivery
  is attempted — interrupts stay disabled).
- Filling the arena with 2-granule modules ends in a clean `ZMOD_ENOSPC`
  rejection; all earlier modules remain intact.
- The early console and the M3 console service are unaffected (banner and
  `console: sio0.b OK` unchanged).

No new hardware dependencies are introduced: the test exercises only the
already-accepted memory/banking hardware and SIO0/B; it programs no CTC
and enables no interrupts.

## Host validation

```sh
make clean                         PASS
make                               PASS
make test                          PASS
make check                         PASS  reproducible rebuild + full
                                         validation stack
make zmod-test                     PASS  35 tests; includes sdldz80
                                         byte-for-byte image comparison
make m4-loader-selftest            PASS  14 simulator tests
make syscall-selftest              PASS
make irq-selftest                  PASS
make m3-selftest                   PASS
make m3-fallback                   PASS
final full unittest discovery      PASS  187 tests, 0 skipped
```

Notes:

- `build-m4-selftest/zephyros-m4-loader-selftest.bin` itself is
  reproducible via `make check`.
- The M0–M3 images were rebuilt in this stage (the loader is linked into
  every image and the IRQ registry gained claim bookkeeping), so their
  binaries changed while their transcripts and simulations stayed
  identical; e.g. `build-m3-selftest` is now
  `54aedf5335c95528b0a8ef3507dbfb5d2669258ed5b5e65763a4a27226ddf84f`
  and remains host-validated.  Re-capture the M3 hardware transcript if
  that image is re-flashed.
- The production image remains
  `540697ef9a9136ed9294a0b43686b13b5edd171e24ae263edb6021769d7e1d5b`
  with an empty catalog and unchanged boot behavior.
