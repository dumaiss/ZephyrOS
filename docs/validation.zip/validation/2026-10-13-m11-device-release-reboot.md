# Package 51b — m11 device release and reboot

Restoring device state after a program.  Three layers: drivers hear about
a released handle (`KOS_OP_RELEASE`), a program that reprograms a device
holds it through an exclusive bind (`KOS_BIND_EXCLUSIVE`,
`KOS_OP_ACQUIRE`), and a console reset plus a warm reboot catch everything
else.  The Z80 cannot stop a program from writing to ports, so the
exclusive handle is a contract, not a fence: `docs/devices.md` section 12
states it, and the recovery paths make it survivable when a program
ignores it.

## Files

Added:

| file | part |
|---|---|
| `tests/device/devtest.c` | the outcome program the replays place on the card: `claim`, `release`, `busy`, `poke`, `creset`, `write` |
| `tests/test_device_release.py` | the host checks and the replays |
| `work/51b-m11-device-release-reboot/progress.md` | the package's progress note (untracked: `work/` is ignored) |

Changed:

| file | change |
|---|---|
| `formats/include/mod.h` | `MOD_EP_RELEASE` (bit 1) |
| `tools/modpack.py` | the `"release"` manifest key: validated as a boolean, ORed into the packed endpoint flags, accepted by the container check |
| `abi/kos/protocol.h` | `KOS_OP_ACQUIRE` (`FEh`), `KOS_OP_RELEASE` (`FFh`), `KVIDEO_OP_RESET` (3), `KCONSOLE_OP_RESET` (5) |
| `abi/kos/object.h` | `KOS_BIND_EXCLUSIVE` (`8000h`) |
| `abi/kos/syscall.h` | `KOS_SYSCALL_REBOOT` (`0Ch`) |
| `kernel/ipc/ipc.c`, `ipc.h` | `ipc_endpoint_flags()` |
| `kernel/vfs/dev.c` | `vfs_device_notify_release()`, `vfs_device_acquire()`, the exclusive-aware DEVICE bind |
| `kernel/vfs/handles.c` | the release notification in `vfs_ns_release_entry()` |
| `kernel/vfs/vfs.h` | `VFS_HANDLE_EXCLUSIVE`, the notify declaration |
| `kernel/main.c` | `kernel_console_reset()` before every start of the boot program |
| `kernel/syscall.c` | `syscall_reboot()` and its dispatch case |
| `kernel/memory/banking.asm`, `banking.h` | the common-resident `_platform_reboot_now` |
| `drivers/v9958/v9958.json` | `"release": true` |
| `drivers/v9958/v9958.c` | `v9958_display_reset()`, the drop-and-count path, `KVIDEO_RESET` on the shared reset |
| `drivers/v9958/v9958_driver.h` | `exclusive`, `dropped`, the reset declaration |
| `drivers/v9958/v9958_proto.c` | `KOS_OP_ACQUIRE`, `KOS_OP_RELEASE`, `KVIDEO_OP_RESET` |
| `drivers/console/console_proto.c` | `KCONSOLE_OP_RESET`: drain the input queue; the video build forwards `KVIDEO_OP_RESET`, the serial build answers 0 |
| `drivers/iocfat/iocfat.c` | the FS2 `RESET` in init (the audit fix) |
| `user/sdk/src/gate.asm`, `user/sdk/include/kos/process.h` | the `reboot()` gate and its declaration |
| `user/monitor/monitor.c` | the `B` command |
| `user/shell/builtin.c` | the `reboot` built-in, in `help` too |
| `Makefile` | the `devtest` program rule |
| `tests/z80sim.py` | the MCU peer answers FS2 `RESET` (`32h`) the way the deployed firmware does |
| `tests/test_sdk.py` | `devtest` in the declared-program list |
| `tests/test_source_layout.py` | `tests/device/devtest.c` in `EXE_FILES` |
| `tests/test_shell_sim.py` | `reboot` in the `help` row |
| `tests/target/include/driver_client.h` | the `docs/devices.md` section reference follows the new section |
| `docs/architecture.md` | the reboot in 3.1 and 3.3, the exit release in 4.7, the release and exclusive rules in 4.10, the syscall in 6.2 |
| `docs/abi.md` | the syscall, the bind flag, the release on unbind, the console reset, section 5.5 |
| `docs/devices.md` | section 12 (the takeover contract) and the V9958/console operations |
| `docs/vfs.md`, `docs/boot.md`, `docs/filesystem.md`, `docs/module-format.md`, `docs/monitor.md`, `docs/sdk.md` | the release, the launcher reset, the IOC-FAT bring-up reset, the `release` key, `B`, `reboot()` |

Removed: none.

## Result

Every requirement of `work/51b-m11-device-release-reboot/WORK.md` is
implemented and validated.

| requirement | where |
|---|---|
| 1 release notification, `MOD_EP_RELEASE`, manifest `"release"`, `KOS_OP_RELEASE` with `arg1` = exclusive, result ignored, cold-half only | `mod.h`, `modpack.py`, `ipc.c`, `dev.c`, `handles.c` |
| 2 `KOS_BIND_EXCLUSIVE`, `KOS_OP_ACQUIRE`, `-KOS_EBUSY`, `-KOS_ENOTSUP` for an unflagged endpoint, the contract written down | `object.h`, `dev.c`, `docs/devices.md` §12 |
| 3 the video driver's flag, dropped-and-counted output while held, the full re-init on release, `KVIDEO_OP_RESET` (3), init from any state | `v9958.json`, `v9958.c`, `v9958_proto.c` |
| 4 `KCONSOLE_OP_RESET` (5): terminal state, `KVIDEO_OP_RESET` on the video dependency, empty input queue; the serial console resets only its own | `console_proto.c` |
| 5 the launcher resets before every start/restart, ordinary console path | `kernel/main.c` |
| 6 `KOS_SYSCALL_REBOOT` (`0Ch`), `reboot()`, mask + quiesce + latch `00h` + `JP 0`, no peripheral hardware reset, the init audit, monitor `B`, shell `reboot` | `syscall.h`, `syscall.c`, `banking.asm`, `gate.asm`, `process.h`, `monitor.c`, `builtin.c`, the audit below |

## The boot-init audit

Nothing receives a hardware reset, so every init must program its device
fully from any state.  Audited one by one:

| init | state it could inherit | outcome |
|---|---|---|
| SIO (`drivers/sio/`, and the early console) | a programmed channel, bytes in the receiver, hunt mode, a pending interrupt | the boot segment's first step is a full channel reset plus complete write-register programming: any-state safe, no fix |
| CTC (`kernel/irq/ctc.c`) | channel control words, a time constant, a count in progress | the kernel only quiesces it (`platform_irq_quiesce`); no image programs a channel before that point, and the quiesce leaves the counters stopped: no fix |
| V9958 | the whole register file, the palette, both VRAM pages, the display mode | the bring-up rewrites every owned register (R#0-R#11, R#14, R#15, R#23, R#25-R#27, R#46), the selectors, all 16 palette entries, both font atlases, the bitmap clear and the cursor; a program's leftovers cannot survive: no fix |
| IOC | both lanes, the sequencing, a stale reply, an unacknowledged request | the boot path resets both lanes and re-runs the link-sync handshake: no fix |
| HID | its own input ring only (the MCU owns the queue) | RAM-only state, and the console reset drains the ring before the next program: no fix |
| IOC-FAT | **the MCU's file and directory slots, which outlive the Z80 side: an open transfer left by a rebooted machine** | **fix:** the driver now sends FS2 `RESET` (`32h`, the command a media change answers: every context closed, the generation advanced, the resolver reset) before it reads `CAPS` |
| Console | terminal attributes, the escape parser, the cursor, queued input | the launcher's `KCONSOLE_OP_RESET` before every start, and the video build's display reset behind it: no fix needed |

The reboot also exercises the ROM-to-RAM copier a second time
(`docs/architecture.md` 3.1), which the replay proves: the copy runs from
ROM page 0 with the RAM the program left in place, and the machine reaches
the prompt again twenty times in a row.

## Validation

```text
python3 -m unittest tests.test_device_release -v
  Ran 12 tests ... OK                            (4m54s)

make clean && make check
  check: reproducible rebuild (d4b4172f41bc57f3a9d0222f1fa0d2953b71a994a3a9301965da27f62ebff95e)
  Ran 695 tests in 549.556s
  FAILED (failures=2)
  real 10m35.212s
  # the two are tests.test_hid and tests.test_v9958
  # test_system_file_and_boot_order, the pair this contract accepts

make console-serial-selftest
  Ran 6 tests in 11.624s
  OK

git diff --check                                 (clean)
```

`make check` rebuilds the tree from clean and its image bytes are
reproducible, so the ledgers above are the validated ones.  The two
accepted failures are the production store list package 56 owns: the
serial image, which the second command builds and replays, passes on the
same tree, so the console reset the launcher now issues is a no-op-safe
call for the serial build as well.

Ledgers of the validated image (`build/`):

| ledger | value |
|---|---|
| fixed core code end | `3D3Fh` (the fixed core is unchanged) |
| fixed required / room | 8354 B (+2 overflow) / 7260 B |
| cold half code end | `BD52h` (48466), data 1527 B at `BE00h`, room 7177 B |
| driver hot | 22168 of 32768 bytes |
| driver boot/bulk | 2170 of 24576 bytes |
| common | 2366 of 7424 bytes (code 1519, data 847), ceiling 3072 |
| recovery romfs | 106088 bytes, sha256 `4053bfcb02a6c6c4a8c8e83fcf6c96253e182af798f62df141a43c1a489b0402` |
| image | sha256 `d4b4172f41bc57f3a9d0222f1fa0d2953b71a994a3a9301965da27f62ebff95e` |

`make check`'s only failures are the two the contract accepts
(`tests.test_hid` and `tests.test_v9958`
`test_system_file_and_boot_order`, the production store list that package
56 owns); nothing else fails, including the two checks this package's
change moved (`tests/test_console_acceptance.py`'s pinned monitor
identity and `tests/test_v9958.py`'s manifest shape, both updated with
the artifact).

## Notes

- **The keyboard reset requirement was dropped by the owner.**  The IOC
  already resets the machine on its own key combination, and that
  combination is the MCU's: the Z80 side never sees a modifier channel, so
  the console cannot turn a key combination into `REBOOT` without new
  input plumbing.  `reboot` is reachable from the monitor's `B`, the
  shell's `reboot` built-in and any program's `reboot()`; the keyboard
  escape stays where the hardware already puts it.
- **The reboot loop's shape.**  The replays drive twenty reboots: the
  first through the shell's built-in (`X /fs/SHELL.EXE`, `reboot`), the
  other nineteen through the monitor's `B`.  Both call the same syscall
  from a running program, and each iteration starts the machine again and
  must reach a prompt; driving all twenty through the shell would cost a
  full shell start per iteration for the same coverage.  The card is read
  again (shell `ls`, `cat`) after the loop and after the mid-transfer
  reboot.
- **The console reset drains input before every start**, so a line typed
  for the program that is going away never reaches its successor; the
  replay asserts it by typing `Q` and a following command in one burst.
- **The handoff grep.**  `git diff -U0 | grep -E '...'` prints only the
  three shell-location comments the shell packages' own contract states
  (the Makefile's two lines and the packer's one); this package adds no
  hit, and its new files carry no package or milestone name.
- **Hardware checklist (owner).**  Run the takeover program and exit for a
  clean text prompt; `reboot` ten times, `B` once; reboot while a copy is
  running and check that the card still mounts.  Nothing here was run on
  the board.

## Addendum: owner hardware run (2026-10-13)

The owner ran the checklist on the Zephyr-80 (V9958+HID production, with
`DEVTEST.EXE` and a large file on the card): every row passes.

- `devtest claim`, `devtest release`, `devtest poke` (then `exit` and the
  relaunch): each ends at a clean text prompt.
- `reboot` ten times and the monitor's `B` once: each reaches the shell
  prompt, and the card reads afterwards.
- Ctrl-Alt-Esc (the I/O controller's hard reset) during `cp` of a large
  file: the machine boots and the card mounts and reads.
