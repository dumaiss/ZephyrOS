# Documentation first version (work package 47)

Work package: `work/47-m10-docs-first-version/WORK.md`, implemented by
the supervisor session (owner: "47 is for you"), 2026-10-12.  Working log:
`work/47-m10-docs-first-version/progress.md`.  Baseline: HEAD `81f80cd`
(49d committed).  **No commit was made** (owner instruction).

## 1. What changed

Documentation (requirements 1-5):

- `docs/architecture.md` rewritten by subsystem as the first version of
  KonaOS: 1 purpose, principles, tree, toolchain; 2 hardware; 3 boot;
  4 nucleus (4.1-4.11); 5 drivers; 6 ABI; 7 programs and far memory;
  8 build; 9 ledgers; 10 protection; 11 portability; 12 boundaries;
  13 glossary; 14 roadmap (shell, device release/reboot, timer,
  diagnostics, personalities); Appendix A far calls with another
  toolchain.
- Rewritten: `README.md` (one entry point per audience), `docs/abi.md`,
  `boot.md`, `devices.md`, `filesystem.md`, `memory.md`, `monitor.md`,
  `sdk.md`, `vfs.md`.  Edited: `exe-format.md`, `module-format.md`,
  `romfs-format.md`.  Removed: `docs/m10-m12-target-architecture.md`.
- Docs diff: 14 files, +3300 / -13670 lines.

Build history out of the tree (requirement 6): 230 files outside `docs/`
and `work/` (+1343 / -2416 lines): abi 10, boot 1, config 2, drivers 20,
formats 3, kernel 47, Makefile, mk 1, platform 5, tests 92, tools 10,
user 37.

- Old architecture section numbers remapped everywhere (map in section
  3); every `architecture N.N` reference in the tree resolves to a
  heading, and every `docs/<x>.md section N` reference resolves.
- Package numbers, milestone numbers, correction numbers, `work/` and
  `docs/validation/` paths removed from comments, docstrings, assertion
  messages, JSON reasons and tool messages; each rewritten in the
  present tense (reason kept) or deleted.
- Identifiers renamed: `tools/mapcheck.py` milestone tables
  (`M3_BANK7_PREFIXES` -> `REGISTRY_BANK7_PREFIXES`, `M4_*` ->
  `LOADER_*`, `M6_*` -> `PROCESS_*`, `M7_*` -> `DIAG_*`,
  `ROMFS_M9_ROUTINES` -> `ROMFS_ENUM_ROUTINES`), test classes and methods
  (`TestIpcCorrection01Layout` -> `TestIpcCopyPathLayout`,
  `..._no_milestone_selftests` -> `..._no_selftests`).
- Production source: comments only.  Two tool messages changed text
  (`tools/exepack.py` FAR_CODE id error, `tools/serial_smoke.py` hint);
  neither is in an image.

Tests that only guarded history were removed (18 tests; the Mn-1 rule
"restated or removed"): the removed-path tombstones, the retired
acceptance targets / boot modes / smoke modes / milestone directories,
the Mn-1 retention window, the EXE v1 and old ROMFS/EXE/MOD magic checks
(the generic bad-magic tests stay), the legacy name-comparison and static
driver symbol checks, the block-device registration token, and the
system-composition tombstone tokens.  Current rules in the same tests were
restated without numbers.  One test pinned comment text in
`abi/kos/ipc.h` ("Copy paths (correction 01"); it now pins
"Copy paths (architecture 4.9)".

Stale facts corrected while rewriting (code is the authority): one
descriptor per call; applications call `call(handle, ...)`; standard
handles are bound fresh per process; the console is selected per build
with no fallback; 16 extended-memory objects system-wide;
`kernel/lib/name.{c,h}` list the two real callers; the IPC header's
"two IPC numbers"; the IPC test docstring's "production carries no
substrate symbol".

## 2. Checks

| check | result |
| --- | --- |
| requirement-6 grep over the scope | clean except the exceptions below |
| requirement-5 grep over the developer docs | clean |
| links in README and docs | all resolve |
| architecture / docs section references | all resolve |
| production ledgers (incremental build) | unchanged: fixed 8335 / room 7279, cold 23496 end BBC8h / room 7689, driver hot 21910, boot 2170, common 2358 |
| `make clean && make check` | production builds and boots in the replay; 659 tests, 2 failures (finding 1, the 49d store list), 105 skipped (images removed by `make clean`) |
| `git diff --check` | clean (after removing a whitespace-only line in `mk/kos.mk` the check found) |
| acceptance images with edited replays | all pass: console-integration (4 replay modules), console-serial, ipc (40 tests), ns, fs, hwtest replay; subsystem: `test_subsys_sim` passes, `test_romfs_sim` fails (finding 2) |

Requirement-6 exceptions:

- `.gitignore`: `work/` and `docs/validation/` stay ignored entries.
- `hardware.h`, `drivers/v9958/v9958.c`: `M5+M3` are V9958 mode bits.

## 3. Old -> new architecture section map

| old | new |
| --- | --- |
| 1 purpose | 1.1 (milestone list dropped) |
| 2 principles | 1.2 |
| 3, 3.1 source tree, ownership | 1.3 |
| 4 toolchain | 1.4 |
| 5.1-5.6 latch, boot, entry, early console, panic | 2.1, 2.2, 2.5, 3.1, 3.4 |
| 6, 7 memory model | 2.2-2.4 |
| 8 page zero | 4.3 |
| 9, 10 syscall ABI, common entry | 4.3, 4.4 |
| 11 stacks | 4.2, 4.3, 2.4 |
| 12 map validation | 8.2 |
| 13 asm/C boundary | 1.2 |
| 16 CP/M relationship, 16.1 emulator | 12, 8.2 |
| 17, 17.1 hardware reference | 2.1, 2.5 |
| 18 IRQ executive | 4.5 |
| 24 ROMFS, ROM access | 4.6 |
| 26 process, EXE | 4.7, 6.7, 6.8 |
| 28 monitor | 7.4 |
| 30 device stack | 5.6 |
| 32.1-32.31 namespace, providers, handles, errors | 4.10, 5.6, 6.5, 6.6 |
| 32.32 boot lifecycle | 3.2 |
| 32.35 personality boundary | 12 |
| 32.39 budget | 9 |
| 32.40 exec | 4.7, 6.8 |
| 35 completion sequence, 38-42 | 14 |
| 36.1 central rules | 1.2 |
| 36.2 rev 13 | 2.2 |
| 36.3 two-bank residency | 2.3 |
| 36.4 nucleus vs drivers | 4.1, 5.1 |
| 36.5 fixed core, cold half, buffer rule | 4.2 |
| 36.6 driver bank | 5.2 |
| 36.7-36.9 endpoints, descriptors, copy paths, nesting | 4.9 |
| 36.10 driver IRQs | 4.5 |
| 36.11 driver images | 5.3-5.5 |
| 36.12 boot | 3.2 |
| 36.13 VFS, exec, exit | 4.10, 4.7 |
| 36.14 syscall ABI | 6.1, 6.2, 6.4 |
| 36.15, 36.16, 36.19 banks, xmem, memory init | 4.8 |
| 36.17 aperture, far code | 7.2, 4.8 |
| 36.18 EXE v2 | 6.7, 4.11 |
| 36.20 ledgers | 9 |
| 36.21 portability | 11 |
| 36.22 protection | 10 |
| 36.23 non-goals | 12 |
| (new) far data, build, SDK | 7.3, 8.1, 8.3 |
| (new) toolchain appendix | Appendix A |

Dropped as history: sections 14-15, 19, 20-23 (registry, static drivers,
arena), 33-34, 36.24, 37 (acceptance and milestone records).

## 4. Findings (not changed by 47)

1. **49d: production store list vs two tests.**
   `tests.test_hid` and `tests.test_v9958`
   `test_system_file_and_boot_order` fail: `systems/production.json`
   (unchanged since `81f80cd`) carries `far_data.exe`, `banks.exe`,
   `known.bin`, which the tests do not list.  This is the deferred 49d
   correction (move the far-data files out of production).
2. **49d: the ROMFS replay no longer fits the subsystem image.**
   `make subsystem-selftest` builds, `test_subsys_sim` passes, and all 26
   `test_romfs_sim` tests fail: the subsystem image's cold data ends at
   DEC7h (code end D677h, data 1735 at D800h, room 313), so the replay's
   host scratch rounds to E000h, outside the window.  HEAD `81f80cd`
   builds the identical layout; there the replay skipped because the
   fresh tree had no production `build/modules/sio.mod`, which is how the
   49d check missed it.
3. `romfs_resource_size` / `romfs_resource_read` have no production
   caller: only the process acceptance test
   (`tests/target/process/process_test.c`) exercises them, yet they link
   into every image (possible dead code).
