# M13 read path, host cost (package 59)

Implemented by the supervisor (owner request). Scope grew past the
package text where measurement or a board failure showed the real cause;
every addition is listed below.

## Findings that shaped it

- **The lane is fast.** The controller firmware (`Zephyr-80/Code/MCU/
  IOController/src/bulk_channel.c`) waits 100 us after admission, sends
  the marker and header bytes at about 7 us each and the payload at its
  6 us target: 512 bytes is ~3 ms of wire, not the 12.8 ms the simulator
  had used (CP/M's whole read time). The rest of a read is controller
  time, shared with CP/M, and ours.
- **CP/M skips every CRC** (owner); the bulk lane already bypassed its
  data CRC here, the command frames did not.
- **Driver copy buffers were outside 8000h-BFFFh.** Every driver listed
  `_DRIVER_IO` as BSS of its hot segment, so its data landed after its
  code (IOC-FAT's at 7C5Ch-82xxh). The architecture's driver I/O rule
  was not enforced: every read reached its caller through the staged
  copy path C.
- **A board hang exposed a nucleus fault.** With the reads copied
  straight from the cache block, a read spanning two blocks makes two
  `copy_out` calls. Path C bounces through the common staging block, and
  the exec loader's buffer *is* that block: the second bounce overwrote
  the first piece, so a program run from the card loaded corrupted and
  hung (owner's `hwtest`, reproduced by `make fs-selftest`).

## Change

| area | change |
|---|---|
| `drivers/ioc/ioc_io.asm` | `ioc_crc16`: the command-frame CRC-16-CCITT byte-wise in assembly (~150 T/byte, was ~750 in C); the marker scan polls inline; header and payload are captured as one `INI` stream into the five bytes below the payload buffer (saved before admission, restored on every exit) and the header copied out after; the three in-receive stamps use A, H, L only (80 T) and `first` is taken at the marker |
| `drivers/ioc/ioc.c` | calls the assembly CRC |
| `drivers/iocfat/iocfat.c` | `KFILE_OP_READ` copies from the cache block straight to the caller (no `iocfat_batch` copy) |
| `drivers/*/*.json` | `_DRIVER_IO` in an io segment for every driver (placed in 8000h-BFFFh) |
| `tools/modpack.py` | refuses `_DRIVER_IO` outside the io segment |
| `kernel/ipc/ipc.c` | path A takes any hot-tier driver buffer with a caller-window or common caller buffer, so a common caller buffer never bounces; `endpoint_for` direct-indexes host numbers; `desc_release_all` walks a pointer |
| `tests/z80sim.py` | the bulk lane follows the firmware's schedule (1000 T guard, 70 T per fixed byte, 60 T per payload byte) |
| `tests/perf/readphase.c`, `tests/test_readpath.py` | stamp shape and budgets follow the lane model |
| tests | manifest-shape pins follow the io segment; the fs-selftest leak check reads the io segment's base; a packer refusal test |
| `abi/kos/protocol.h`, `docs/architecture.md`, `docs/module-format.md` | phase meanings, copy path A, the enforced driver I/O rule, the manifest example |

## Measurement (simulator, firmware lane timing, 512-byte miss, path B)

| phase | ms |
|---|---|
| cache | 0.28 |
| sent | 1.36 |
| reply | 1.25 |
| admit (incl. 100 us guard) | 1.61 |
| first | 0.10 |
| last (wire) | 3.12 |
| copy | 0.44 |
| caller | 1.66 |
| return | 0.20 |
| **timer** | **13.59** |

`sent`/`reply` were 2.18/2.15 ms with the C CRC, `copy` 1.66 ms with
the staging copy. Path C (pass 2) 16.74 ms; 128-byte hit 4.9 ms.

## Board (owner, production image)

SDBENCH, KonaOS logical read, checksum PASS:

| request | 58 | 59 |
|---|---|---|
| 128 B | 16.48 KiB/s | 20.75 KiB/s |
| 256 B | 19.60 | 25.82 |
| 512 B | 21.66 (22.99 ms) | 29.19 (17.05 ms) |
| 1024 B | 22.57 | 30.94 |
| 2048 B | 22.97 | 31.80 |
| 4096 B | 23.22 | 32.36 |

CP/M: ~39 KiB/s. `fs_selftest` 37/0 (card exec included), `hwtest` 4/4,
`timer card` 60 s, `vgmplay night.zvg` 0 underruns (refill mean 1112
counts, was 1253). These ran on the image before the one-stream receive.
The final image (one-stream receive): `fs_selftest` 37/0, `hwtest` 4/4,
SDBENCH 128 B 20.59, 512 B 29.10 (17.10 ms), 4096 B 32.23 KiB/s, checksum
PASS - the same speed, as expected: the change buys bulk-lane timing
margin, not throughput.

## Validation

```
make clean && make check                OK (reproducible rebuild; 779 tests, 115 image tests skipped)
make ipc-selftest                       OK (40 tests)
make phase-image                        OK (14 tests)
make fs-selftest                        OK (3 tests, plus the image's follow-on suites)
git diff --check                        OK
```

The full check also caught pins the targeted runs had missed: the
manifest shapes in `tests/test_ioc.py` and `tests/test_iocfat.py`, and the
SDK layout in `tests/test_sdk_package.py`, whose `kos/stream.h` and
`klibc/stdio.h` rows had been missing since the buffered-I/O package.
