# Validation - snd-oracle (package 97)

Date: 2026-10-25

## Scope

Package 97: the libsnd behavioral oracles and the shared sound-series
harness.  No libsnd code, no OS change.

## Files

Added:

- tests/snd/README.md - the tools, the trace formats, regeneration
- tests/snd/fixtures/README.md - per-fixture provenance
- tests/snd/fixtures/gen_fixtures.py - checked-in generator (songs
  copied, VGMs written and compiled with the Zephyr-80
  compile_vgm.py, malformed fixtures by mutation)
- tests/snd/fixtures/night-market.ztr, RunawayCircuit.ztr - the two
  Zephyr-80 songs, byte for byte (sha256 pinned by the test against
  ../Zephyr-80)
- tests/snd/fixtures/run-shortwaits.zvg, wait16.zvg - ZVGC v2 streams
  from the generator (64 and 39 bytes)
- tests/snd/fixtures/malformed/* - 44 ZTR + 10 ZVG malformed fixtures,
  one per validation rule
- tests/snd/oracle/include/kos.h, kos/{console,event,sound,stream,timer}.h -
  host stubs, not the real SDK headers
- tests/snd/oracle/ztr_trace.c - host build of SNTracker's
  ztr.c/player.c/psg.c (unchanged) with a recording sound_write
- tests/snd/oracle/zvg_trace.c - host build of vgmplay.c's decoder
  (validate_header, ring, decoder_tick), fed whole files
- tests/snd/oracle/make_malformed.py - prints the outcomes table
- tests/snd/golden/{night-market,RunawayCircuit}.trace - 3,000 ticks
  each; {run-shortwaits,wait16}.trace - whole streams
- tests/snd/golden/malformed.md - the pinned outcomes table
- tests/snd_harness.py - replay, compare, timing
- tests/snd/sndprobe.c, tests/snd/sndprobe_delay.asm - the harness
  self-test program
- tests/test_snd_oracle.py - the package's test module
- docs/validation/2026-10-25-snd-oracle.md

Changed:

- Makefile - the sndprobe exe_program declaration
- tests/test_source_layout.py - the new files in OWNER_FILES and
  tests/snd in REQUIRED_DIRS

## Results

- `make` (incremental): up to date; sndprobe.exe packed and validated
  (5,747 bytes).
- `python3 -m unittest tests.test_snd_oracle`: 9 tests, all passed -
  fixtures provenance, the generator rebuilds the ZVGs, the oracle
  tools build and reproduce the four goldens byte for byte, the
  malformed table matches and all 54 malformed fixtures are refused,
  the harness replays sndprobe and decodes its writes, ticks and the
  two calibrated delays exactly (416 T-states apart).
- `python3 -m unittest tests.test_source_layout.TestOwnerLayout`: 3/3.
- `git diff --check`: clean.
- `make clean && make check`: deferred to the end of the series
  (packages 97-100 validate as one batch); the record will carry the
  full result.

## Budgets

- OS bytes: unchanged (no kernel, driver or SDK source touched).
- Host oracle run, both songs: ztr_trace 3,000 ticks x 2 and zvg_trace
  x 2 complete in well under a second on the development host.

## Notes

- The ZTR oracle's trace covers 3,000 ticks of each song (neither song
  ends within 6,000 ticks; the contract asks for at least 3,000 or the
  song's end).
- The malformed outcomes table reports the oracle's stage and result
  for every fixture; libsnd may tighten checks later (the format
  document wins) and each tightening will be listed in its package's
  record.
- The harness marker is the DAC port E4h with value A5h; the timing
  mode attributes by PC window (program code 0100h-1FFFh), excluding
  the interrupt path.
- Unrelated changes (UserSoftware/DonkeyKong Makefile and its SDK
  tarball) were preserved untouched.
