# M8 — final device-stack integration acceptance (`20-m8-integration-acceptance`): validation record

Date: 2026-10-03 (work package 20, worker pass)

Status: **host and simulator validation complete** (frozen clean-tree
sequence below: 25 steps, all exit 0; final discovery 604 tests, 0
failures; every M8 suite ran with zero skips).  **Physical acceptance:
COMPLETE — 2026-10-04 bench session.**  Observed and recorded: step 1
(flash), step 2 (`make smoke-hardware-m8` **PASSED**, transcript
preserved), the complete human HID/V9958 monitor pass (help, dump,
safe modify/readback, port read, `R` system/bank/process lines, all
three rejected inputs `ERR: ARG`, **two** identical `Q` exit/relaunch
cycles — photographed on the display), and all four fallback-matrix
smoke runs (**PASSED**, transcripts preserved: `0x05`/`0x0B`/both
`0x05`/`0x06` variants with their exact bindings, plus the operator's
display confirmation for the V9958-bound runs).  **M8 is complete.**
Exact commands, images and hashes: section 5 and the hardware
transcript `docs/validation/2026-10-03-m8-device-stack-hw-transcript.txt`.

## 1. Delivered change

- `kernel/main.c` — the optional-module failure path now reports the
  module name and the exact `ZOS_E*` code behind the failed load
  (`<name>: unavailable 0x<code>`): missing ROMFS entry `0x05`,
  arena/descriptor exhaustion `0x06`, malformed/truncated container
  `0x0A`, refused init `0x0B`.  The helper is compiled only when an
  optional boot load exists, so every pre-M8 acceptance image keeps the
  code it was accepted with.  The boot-order comment now states the
  frozen contract: `sio.zmod`, `ioc.zmod`, `hid.zmod`, `v9958.zmod`,
  then the single `console_bind_defaults()` and the unchanged
  `process_exec("monitor.zex")` launcher.
- `tests/m8/manifest-fallback-nohid.json`,
  `manifest-fallback-nohid-nov9958.json`, `manifest-fallback-arena.json`
  — failure-variant ROMFS descriptions (missing `hid.zmod`; missing HID
  and V9958; `v9958.zmod` mapped to the oversized allocation fixture).
  `manifest-hid-badioc.json` and `manifest-v9958-fontfail.json` are
  re-used by the matrix.
- `tests/modules/m8_regfill.c` / `m8regfill.json` — test fixture whose
  36-granule BSS image can never be allocated in the production arena;
  loaded as `v9958.zmod` by the arena-exhaustion variant (its init never
  runs).
- `tests/target/m8/m8_test.c` (+ `tests/target/include/m8_selftest.h`)
  — the package-20 integration target: four-module discovery and load
  order, default HID/V9958 binding, repeated PING exchanges with the
  pinned level and link bit, semantic status, the class-shape checks,
  the malformed/null/class/capability battery with exact codes, and the
  device-table/module-allocation/console invariants; all control lines
  on the direct early SIO.
- `tests/target/m8/m8_fallback_test.c` (+
  `tests/target/include/m8_fallback_selftest.h`) — the shared
  fallback-variant target: reports the bound input/output instance and
  class, the device count, reads back one invited serial byte where the
  input is SIO, writes one marker through the bound console output, and
  asserts the bound devices survived; it never claims a direction it
  cannot observe.
- `tests/target/support/target_test.c` — wires both tests into the late
  hook.
- `Makefile` — `m8-selftest` (`ZOS_M8_SELFTEST`, integration image +
  production-byte replay), `m8-fallback-selftests`
  (`ZOS_M8_FALLBACK_SELFTEST` + `ZOS_M8_FALLBACK=nohid|nohid-nov9958|
  badioc|arena`, builds the matrix plus the font-failure, no-IOC and
  malformed-IOC images and runs the matrix replay), the
  `smoke-hardware-m8` and `smoke-hardware-m8-fb-*` targets, the new
  target-object rules and the variant ROMFS selections.  The declared
  boot-set arena plan intentionally keeps the real `v9958.zmod` for the
  arena variant (the point of that image is the runtime allocation
  failure, which the plan cannot express); this is commented in place.
- `tools/serial_smoke.py` — new `m8` and `m8-fb-*` modes: exact marker
  sets, per-variant binding/diagnostic contracts (`M8FB_MODES`), the
  serial-input byte sent when the image invites it and the
  serial-versus-display marker rule (a V9958-bound marker must not
  appear on the link); the three `<name>: unavailable` constants became
  prefixes of the precise diagnostics.
- `tests/test_m8_acceptance.py` (new) — production `build/zephyros.bin`
  replay: boot order/handles/binding, the scripted monitor session with
  two Q exit/relaunch cycles, IOC command/status/repeated PING and the
  full /SHARED READY/DONE write/read/delete sequence with the frozen
  no-file cleanup status, transient CRC/sequence fault recovery, HID
  queue traffic with malformed-reply atomicity and the 64-call
  stuck-doorbell penalty, the malformed-call battery with table/granule/
  lane invariants and post-fault monitor recovery, the integration
  image target transcript and hand-off, and ROMFS payload identity
  against the packed artifacts and pinned hashes.
- `tests/test_m8_fallback.py` (new) — the five-row fallback matrix over
  the real images (see section 3).
- `tests/test_m8.py` — alignment/plan/manifest reconciliation
  (align_up(kernel end) → arena start, 16-KiB minimum, C000h end, plan
  versus packed containers, used/free totals), the M8 manifest
  content/type/order checks, the Makefile/runner wiring checks and the
  smoke-mode classification checks.
- `tests/test_monitor.py` — the monitor source purity sweep now also
  rejects V9958/HID/IOC references, completing the "no SIO, V9958, HID,
  IOC, early-console, CP/M or private kernel dependency" proof.
- Existing tests updated for the precise diagnostics
  (`test_ioc.py`, `test_hid.py`, `test_v9958.py`, `test_ioc_sim.py`,
  `test_hid_sim.py`, `test_v9958_sim.py`).
- Documentation: `docs/architecture.md` (30.8 status, section-31
  acceptance status, M8 milestone status), `docs/devices.md` (boot
  order/diagnostics, package-20 section 8.2 with the matrix table),
  `docs/memory.md` (plan/manifest reconciliation), `docs/module-format.md`
  (derived-versus-legacy arena, four-module boot set, M8 image rows),
  `README.md` (M8 status entry, new targets, expected output note,
  layout).

IOC firmware, MCU commands, monitor bytes, the native syscall ABI and
all M1-M7 artifacts were not touched.  No MAME acceptance was used.

## 2. Validation sequence (frozen source, clean tree)

| # | Command | Result |
| --- | --- | --- |
| 1 | `make clean` | OK |
| 2 | `make check` | OK; reproducible rebuild `build/zephyros.bin` sha256 `16307e15…` (identical across the clean rebuild); check-fast discovery 604 tests OK (183 skips: images not built yet at that point) |
| 3 | `make zmod-test` | OK (`test_zmod` 40 tests) |
| 4 | `make romfs-test` | OK (`test_romfs` 46, 5 fixture-dependent skips) |
| 5 | `make zex-test` | OK (`test_zex` 33, 5 fixture-dependent skips) |
| 6 | `make m6-selftest` | OK (`test_m6_sim` 7, 1 skip: m6-failure image not built) |
| 7 | `make monitor-test` | OK (`test_monitor` 22, 3 skips until the m7 image exists) |
| 8 | `make m7-selftest` | OK (`test_m7_sim` 6) |
| 9 | `make ioc-test` | OK (`test_ioc` 34) |
| 10 | `make hid-test` | OK (`test_hid` 32) |
| 11 | `make v9958-test` | OK (`test_v9958` 31; `test_v9958_console` 25 skipped here because it models the console image, which this sequence builds later and then runs: 0 skips in the final discovery) |
| 12 | `make m8-selftest` | OK; integration image built and `test_m8_acceptance` 10/10 (production-byte replay + target transcript) |
| 13 | `make m8-fallback-selftests` | OK; matrix images + font-failure/no-IOC/malformed-IOC images built, `test_m8_fallback` 2/2 (all six rows) |
| 14 | `make m8-ioc-selftest` | OK (`test_ioc_sim` 26) |
| 15 | `make m8-hid-selftest` | OK (`test_hid_sim` 13) |
| 16 | `make m8-v9958-selftest` | OK (`test_v9958_sim` 5) |
| 17 | `make m8-console-selftest` | OK (`test_m8_sim` 6) |
| 18 | package-20 sim transcript capture | OK; 8 early-SIO transcripts preserved in `docs/validation/2026-10-03-m8-device-stack-sim-transcript.txt` |
| 19 | `python3 -m unittest discover -s tests -v` | **Ran 604 tests … OK (skipped=76)**; no failures, no errors (skips are exactly the unbuilt M1-M5 / M4-variant / M6-failure milestone images, not this package's targets) |
| 20 | `git diff --check` | OK (no whitespace errors) |
| 21 | `sha256sum` modules + production | see below |
| 22 | `sha256sum` matrix images | see below |
| 23 | `sha256sum` rebuilt package-17/18 images | see below |
| 24 | `make clean` | OK; final `git status --short` lists exactly the intended change set (17 modified, 11 added files, no generated debris) |

Artifact hashes (as built from the frozen tree):

```text
build/modules/monitor.zex    67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed  (pinned M7 oracle, unchanged)
build/modules/sio.zmod       bf9a638517488b72e1621c495f098905f73e157fd20dcc9467d465298786877d  (unchanged)
build/modules/ioc.zmod       808b6d5e986b7abbc06b943264a8ef277b60b9f288d5ebb66b5e186a27d77ca3  (unchanged)
build/modules/hid.zmod       bd7e3933f669f544e6d5b9fb3f1ff6670d773545041545a8fa7619915193ef11  (unchanged)
build/modules/v9958.zmod     6d35c218ff2c8f65b58bd2cdfbe0c5db5bc7302a4827074d062933d62f8897c8  (unchanged)
build/modules/v9958-6x8.font 6db207e0466a05af42894d378261f876da51bb391240e1beda4f1d5f12ec442f  (pinned)
build/zephyros.bin           16307e15dfe5794c4a6987deddd540bc5b62af54fe1fbd173302d443a96706eb

build-m8-selftest/zephyros-m8-selftest.bin                  735514b35efdaa61e8e2688fc10f1eb3b20ae88c28a569251ca55cd86c5bad6b
build-m8-fb-nohid/zephyros-m8-fb-nohid.bin                  dab018cae3100f0cf9732f01467222d208d2e2b3ddb913553adda509e2024825
build-m8-fb-nohid-nov9958/zephyros-m8-fb-nohid-nov9958.bin  3faf77d016a7e76a7110f33005d644e2dd647097d3c28f647c7bfe80a86ba189
build-m8-fb-badioc/zephyros-m8-fb-badioc.bin                1e14ad04c51f98e0157d40fbb273a4ffe6c58fcb0a0c5c4f9141f67d0a5f6ab3
build-m8-fb-arena/zephyros-m8-fb-arena.bin                  607f61589579b02c6e96929f5d7c1f59005b20fc08cc2c681e383c7dd3565bc4

build-m8-v9958-fontfail-selftest/zephyros-m8-v9958-fontfail-selftest.bin  a9572d9e395976a3c17f76f00b6d4dcdd289680a8b5f104bd3f0891a1ccaeb26
build-m8-hid-noioc-selftest/zephyros-m8-hid-noioc-selftest.bin            40b32199dd63ea0222bc205494d9107172f33c77530e1bc0efcdaa744e0508c7
build-m8-hid-badioc-selftest/zephyros-m8-hid-badioc-selftest.bin         db72fdc95b513703a01ce0e452cb243b80dbf20a122759b86d74a4197957c250
```

Production arena report from the same build: static kernel end `5D6Eh`,
driver arena `5E00h-BFFFh` (25088 bytes, 49 granules), boot set
`21 granules (sio x1, ioc x8, hid x2, v9958 x10), 28 free`; the
integration image links at arena `6A00h-BFFFh` (43 granules, boot set
21/22 free) because the target objects are part of its kernel.  The
production ROMFS carries exactly the six required entries (17890
bytes); every `mapcheck` invocation in the sequence reported OK (28
runs).

### 2.1 Pre-M8 artifact identity

To separate this package's changes from the earlier accepted milestone
changes, the M6/M7 acceptance images and all module containers were
rebuilt from a pristine `HEAD` checkout (side worktree of commit
`72c4e92`, removed afterwards) and compared byte-for-byte with the
frozen-tree build:

```text
m6-selftest image   1e855297154bbbc5922f18a7492b44fab055c70d1f8da227a97fbd172f8f5e15  (identical)
m7-selftest image   6d87219b471a3e4971db0343679d3acd6e10384fa4541ce77510c511b3a2b5b8  (identical)
monitor.zex         67574d57…  sio.zmod bf9a6385…  ioc.zmod 808b6d5e…
hid.zmod bd7e3933…  v9958.zmod 6d35c218…                                             (all identical)
```

The M6/M7 image hashes differ from their original 2026-10-02/03
records, but they are exactly the pristine `HEAD` bytes: the drift
comes from the already-accepted packages 14-19 (shared constants such
as the gate-stack size), not from package 20.

## 3. Failure/fallback matrix (exact bindings asserted by
`tests/test_m8_fallback.py` and the matching smoke modes)

| Image | Injected failure | Early-SIO diagnostic | Binding | Observable direction evidence |
| --- | --- | --- | --- | --- |
| `build-m8-selftest` (all modules) | none | — | HID/V9958 | target transcript + monitor hand-off (sim); physical monitor pass OBSERVED 2026-10-04 (help/dump/modify/readback/port read, `R` lines, three `ERR: ARG` rejections, two Q cycles — section 5.1) |
| `build-m8-v9958-fontfail-selftest` | undersized font (init refused) | `v9958: unavailable 0x0B` | HID/SIO | fontfail target transcript (sim); package-18/19 hardware records |
| `build-m8-fb-nohid` | `hid.zmod` entry absent | `hid: unavailable 0x05` | SIO/V9958 | hardware smoke **PASSED** 2026-10-04 (302 B, input `0x52` read back); display confirmed by operator (started normally; no photo) |
| `build-m8-fb-nohid-nov9958` | HID and V9958 entries absent | both `unavailable 0x05` | SIO/SIO | hardware smoke **PASSED** 2026-10-04 (383 B; marker + console line on serial; input `0x52` read back) |
| `build-m8-fb-badioc` | malformed IOC interface rolls HID back | `hid: unavailable 0x0B` | SIO/V9958 | hardware smoke **PASSED** 2026-10-04 (302 B, input `0x52` read back); display confirmed by operator (started normally; no photo) |
| `build-m8-fb-arena` | `v9958.zmod` allocation cannot fit | `v9958: unavailable 0x06` | HID/SIO | hardware smoke **PASSED** 2026-10-04 (314 B; marker + console line on serial) |
| `build-m8-hid-noioc-selftest` / `-badioc-selftest` (package-17 images, rebuilt) | no IOC / malformed IOC | `hid: unavailable 0x0B` | SIO/SIO | package-17 target transcripts (sim) |

The early/panic SIO path is proven independent in every row: the
control transcripts above are produced on the serial link while the
bound output may be the V9958, and `tests/test_m8_sim.py` additionally
drives `panic()` with the console bound to HID/V9958.

## 4. Section-31 acceptance-criteria mapping

| Criterion | Evidence |
| --- | --- |
| arena start derived from the aligned linked-kernel end (not `A000h`) | `tests/test_m8.py` `test_generated_production_geometry_matches_manifest` (align_up relation), mapcheck/pack_image build output (validation log) |
| arena end `C000h`, 512-byte granules, `<16 KiB` is a build error | `ZOS_DRIVER_ARENA_MIN_*` in `platform/zephyr80/memory.inc`, `mapcheck.derive_geometry` negative tests (`test_m8.py`), manifest checks |
| build reports total/used/free and per-module allocations | `zmodpack.py plan` output + `build/arena.plan.json`, `pack_image` manifest, `test_production_plan_reconciles_with_packed_modules` |
| `C000h-DFFFh` outside the module arena | derived geometry end is pinned to `C000h`; `mapcheck` area ownership; loader granule bound; `docs/memory.md` 2.2 |
| driver ABI v2 32-bit caps, optional char/class ops | `tests/test_m8.py` `TestAbiV2Contract`, compile-time layout pins in `device.h`/`driver.h` |
| SIO is the dynamically loaded serial/character fallback | production-image registry replay (`test_m8_acceptance.py`), fallback rows bind `sio0.b`, M3/M4 replays |
| IOC registers `ZDEV_IOC`; command, bulk read/write, semantic status proven | `tests/test_ioc.py`/`test_ioc_sim.py` (full /SHARED READY/DONE lifecycle, faults, recovery), `test_m8_acceptance.py` production PING + bulk sequencing; physical: `docs/validation/2026-10-03-m8-ioc-command.md`, `-m8-ioc-bulk.md` |
| HID discovers IOC by class/capability, registers keyboard/text with CHAR_IN/CONSOLE_IN | `tests/test_hid.py`/`test_hid_sim.py`, `test_m8_acceptance.py` HID queue suite; the malformed-IOC fixture proves no symbol/name lookup; physical: `2026-10-03-m8-hid.md` |
| V9958 registers `ZDEV_VIDEO` with the VIDEO ops and `ZCAP_CHAR_OUT|CONSOLE_OUT` renderer | `tests/test_v9958*.py`, `test_m8_sim.py` live trace, `test_m8_acceptance.py` console marker rendered through the bound output; physical: `2026-10-03-m8-v9958.md`, `-m8-console.md` |
| native video ops not limited by the 16-byte ceiling | `test_v9958_sim.py` 200-byte `DATA_BLOCK` / 4096-byte block, `test_v9958_console.py` write chunking |
| normal console binding selects HID in / V9958 out when available | `test_m8_acceptance.py` boot binding, `test_m8_sim.py`, matrix all-modules row |
| every failure combination falls back cleanly without losing early SIO | `tests/test_m8_fallback.py` (this package) + `test_m8_sim.py` early/panic bypass |
| exact M7 monitor runs through HID/V9958 without SIO-specific changes | payload hash `67574d57…` in every image (reconciliation + acceptance tests), source purity sweep, scripted session; physical WP19 `2026-10-03-m8-console.md`; integrated monitor pass OBSERVED 2026-10-04 on hardware (help, dump, modify/readback, port read, `R` lines, three `ERR: ARG` rejections, two identical Q exit/relaunch cycles — section 5.1) |
| unsupported/malformed class calls fail predictably, no invalid pointers | integration target battery + `test_m8_acceptance.py` invariants (device table, granules, RTS/CTS and VDP idle state) + per-module sims |
| all production modules fit simultaneously; 16-KiB invariant | `test_production_plan_reconciles_with_packed_modules` (sio+ioc+hid+v9958 fit, non-negative free), build log |

## 5. Physical acceptance gate (COMPLETE — 2026-10-04)

Images and exact hashes: see section 2.  Procedure (unchanged from the
package contract), with the 2026-10-04 bench observations:

1. flash `build-m8-selftest/zephyros-m8-selftest.bin` — **DONE**
   (2026-10-04; the image's unique `m8 selftest` markers appear in the
   captured transcript, so the flashed build is the package-20
   integration image, deterministic sha256 `735514b3…`);
2. `make smoke-hardware-m8 SERIAL_PORT=/dev/ttyUSB0` (start before
   reset; the image waits for the host sync sequence) — **PASSED**
   (2026-10-04): 253 bytes, full transcript (banner; binding report
   `hid.keyboard0` input / `v9958.0` output; `devices 04`;
   `ioc level 4A`; `rejected calls OK`; `m8 selftest: OK`), one USB
   bridge drop reassembled by the tool (bench quirk).  Preserved in
   `docs/validation/2026-10-03-m8-device-stack-hw-transcript.txt`;
3. human USB-HID/V9958 pass on the same image: monitor help, `R`, dump,
   safe modify/readback, harmless port read, rejected latch write /
   bank 7 / bad syntax, two `Q` relaunches with stable counts —
   **OBSERVED** (2026-10-04, photographed display): the photos show the
   monitor banner/state/prompt after the boot, an interactive block
   covering the help list, a dump, a safe modify/readback
   (`m 8000 99` → `OK`, re-dump shows `99`), a harmless port read
   (`i 20` → `IN=FF`), the `R` screen
   (`system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02`,
   `process: pid 0 bank 0 flags 0001`, `bank: current 00 mask 7F`), all
   three rejected inputs (`O 00 18`, `DB 7 0100 1`, `D ZZZ` →
   `ERR: ARG`), and **two** `q`/`Q` exit cycles with identical
   `monitor: exit status 0x0000 active 0 free-banks 7` lines and
   identical relaunch state (section 5.1);
4. per fallback image (`build-m8-fb-*`, fontfail image), run the
   matching `make smoke-hardware-m8-fb-*` mode and record what was
   observed on the display (a V9958-bound console marker cannot be
   verified over serial) — **PASSED** for all four variants
   (2026-10-04, 0 USB drops each):
   - `fb-nohid`: 302 B, `hid: unavailable 0x05`, SIO input + V9958
     output, `input OK 0x52`, selftest OK;
   - `fb-badioc`: 302 B, `hid: unavailable 0x0B`, SIO input + V9958
     output, `input OK 0x52`, selftest OK;
   - `fb-nohid-nov9958`: 383 B, both `unavailable 0x05`, SIO/SIO, the
     console marker and dynamic console line in the serial transcript;
   - `fb-arena`: 314 B, `v9958: unavailable 0x06` (ZMOD_ENOSPC),
     HID input + SIO output, marker in the serial transcript.
   The display-only `m8 fallback: console output` marker on the
   `fb-nohid` and `fb-badioc` runs is recorded through the operator's
   display confirmation (2026-10-04: the display started normally on
   both runs; no photograph taken — the serial transcript by design
   cannot show it).  Transcripts in
   `docs/validation/2026-10-03-m8-device-stack-hw-transcript.txt`;
5. record each image hash and the observed results here; only then mark
   M8 complete — **done**: every item above is observed and recorded,
   and M8 is marked complete (2026-10-04).

### 5.1 Observed physical evidence (2026-10-04)

- `make smoke-hardware-m8 SERIAL_PORT=/dev/ttyUSB0` →
  `serial_smoke: OK`, 253 bytes.  The transcript proves on hardware:
  early-SIO banner; all four resident modules discovered (HID keyboard
  input, V9958 output, 4 devices); pinned IOC controller level `4A`;
  the malformed/null/class/capability battery with its device-table /
  arena / handshake invariants; no optional-module diagnostic; the
  integration selftest OK.  One FT230X drop during the bench reset was
  reassembled by the tool (documented bench quirk).
- V9958 display photo (`Video0`): `console: dynamic sio0.b OK` and
  `m8 selftest: visible console marker` rendered through the bound
  HID/V9958 console (absent from the serial transcript), followed by
  the unchanged monitor banner, initial state line and prompt — the
  split console binding is confirmed physically.
- Interactive monitor photo (`Video0`, second capture; full text in the
  hardware transcript): help block; `d 8000 10` → all-zero row;
  `m 8000 99` → `OK`; re-dump shows `99` with neighbours untouched;
  `i 20` → `IN=FF`; then `q` → `monitor: exit status 0x0000 active 0
  free-banks 7`, relaunch with identical `bank=00 pid=0 scratch=0F19`,
  `Q` → the same exit line, relaunch to the same state — two exit
  cycles with byte-identical stable counts and no process/bank leak.
- `R` screen and rejected inputs (photo, third capture; full text in
  the hardware transcript): `R` printed exactly
  `system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02`,
  `process: pid 0 bank 0 flags 0001`, `bank: current 00 mask 7F`;
  the three rejected inputs (`o 00 18`, `db 7 0100 1`, `d zzz`) each
  returned `ERR: ARG` with the prompt intact and no side effects; the
  console line and visible marker were again rendered through the
  bound V9958 output.
- Fallback display confirmations: the operator reports the display
  started normally on the `fb-nohid` and `fb-badioc` runs (no photo
  taken), so the V9958-bound console path was visibly live on both.
- Every item of this gate is now observed and recorded; **M8 is marked
  complete (2026-10-04)**.

### 5.3 Fallback-matrix hardware observations (2026-10-04)

All four observable failure variants booted the production load
sequence on the bench and matched their exact contracts (full
transcripts in the hardware evidence file):

| Run | Serial transcript (bytes, drops) | Diagnostic(s) | Binding | Direction evidence |
| --- | --- | --- | --- | --- |
| `fb-nohid` | 302, 0 | `hid: unavailable 0x05` | SIO/V9958 | input `0x52` read back; display confirmed by operator (started normally; no photo) |
| `fb-badioc` | 302, 0 | `hid: unavailable 0x0B` | SIO/V9958 | input `0x52` read back; display confirmed by operator (started normally; no photo) |
| `fb-nohid-nov9958` | 383, 0 | both `0x05`, exactly once | SIO/SIO | input `0x52`; marker + `console: dynamic sio0.b OK` on serial |
| `fb-arena` | 314, 0 | `v9958: unavailable 0x06` | HID/SIO | marker + `console: dynamic sio0.b OK` on serial |

These runs prove on hardware that a failed optional module never rolls
back an earlier resident (device counts 3/3/2/3 exactly as designed),
that the console binding policy degrades through its four states, and
that the early-SIO diagnostics carry the precise `ZOS_E*` codes.

### 5.2 Visible monitor pass — expected text (from the linked bytes' replay; observed 2026-10-04)

The simulator replays this exact session from the same
`build-m8-selftest` bytes (`tests/test_m8_acceptance.py`); the
operator's pass has now been observed and photographed (section 5.1).
The recorded session used `m 8000 99` / `d 8000 10` for the safe
modify/readback and `i 20` for the port read, with `R` and the three
`ERR: ARG` rejections exactly as below:

```text
Z80> H        Q              quit
              R              system/bank information
              DB bank addr len  dump bank 0-6
              I port         input port (10-FF)
Z80> R        system: abi 01 app 10 os 18 common E000 kernel-bank 07 romfs 02
              process: pid 0 bank 0 flags 0001
              bank: current 00 mask 7F
Z80> D 0100 20    rows `0100: ...` through `0110: `
Z80> M 0F19 A5    OK
Z80> D 0F19 1     0F19: A5
Z80> I 20         IN=<two hex digits>
Z80> O 00 18      ERR: ARG        (latch-aliased port, not executed)
Z80> DB 7 0100 1  ERR: ARG        (bank 7 masked)
Z80> D ZZZ        ERR: ARG        (bad syntax)
Z80> q            monitor: exit status 0x0000 active 0 free-banks 7
                  (banner and prompt return: the launcher re-execs the same monitor)
Z80> R            bank: current 00 mask 7F
Z80> Q            monitor: exit status 0x0000 active 0 free-banks 7
```

Exactly two exit lines and two banners with identical counting prove the
two exit/relaunch cycles leaked no process or bank state.

## Notes, warnings and deliberate deviations

- **Monitor size figure**: the work package quotes 3533 bytes for
  `monitor.zex`; the packed container is 3546 bytes (20-byte ZEX header
  + the linked image), exactly as recorded by packages 14-19.  The
  pinned SHA-256 `67574d57…` is the oracle and is verified unchanged in
  every M8 image; the size line above is the stale reference note.
- **Extra regression images**: `make m8-fallback-selftests` also
  rebuilds the package-17 no-IOC/malformed-IOC images and the
  package-18 font-failure image, and the sequence additionally builds
  and replays the package-15/17/18/19 acceptance images, so the
  diagnostics change is re-validated by every suite that pins it (the
  full discovery then skips only images this package does not build:
  M1-M5 milestone images and unrelated fixture-dependent tests).
- **Arena-variant plan**: the declared boot-set plan for the
  arena-exhaustion image keeps the real `v9958.zmod` bytes; the runtime
  allocation failure is injected by the variant's ROMFS manifest and is
  asserted from the linked bytes, not from the plan.
- **Warnings**: no compiler or linker warnings were produced.  The only
  warnings anywhere in the run are pre-existing `ResourceWarning:
  unclosed file` traces from long-standing test/tool helpers (e.g.
  `tools/zmodpack.py:346`, `tests/test_romfs.py:380`, `tests/test_zex.py`,
  `tools/mapcheck.py:102`); none reference the package-20 files, and
  the discovery still reports OK.  Recorded as a pre-existing
  housekeeping finding, not a regression.
- **Skips**: the final discovery skipped exactly 76 tests, all of them
  requiring milestone images this sequence deliberately does not build
  (M5 success/corrupt, M4 loader/placement/failure, M3/syscall/IRQ,
  M6-failure).  Every M8 suite ran with zero skips, including
  `test_v9958_console` (25 tests) once the console image existed.
- **Source freeze**: the sequence below ran on the frozen working tree
  whose complete change set is listed in section 1; no source file was
  modified after it started (the validation record and transcript are
  the only files written during it, both under the git-ignored
  `docs/validation/`).
- Unrelated worktree changes: none were present before this package
  (`git status` at freeze time listed exactly the package-20 change
  set); none were discarded.

