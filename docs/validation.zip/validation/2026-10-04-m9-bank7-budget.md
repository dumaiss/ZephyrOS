# M9 bank-7 budget (package 25b): validation record

Work package: `work/25b-m9-bank7-budget`.  Date: 2026-10-04.
Host toolchain: SDCC 4.5.0 (`sdcc`/`sdldz80`/`sdasz80`).

## 1. Result

Bank-7 space was recovered without changing the mode 10/11 memory model.
Three changes:

1. **Size-optimized compile** (`ZOS_SDCC_OPT := --opt-code-size
   --max-allocs-per-node 50000`) applied to the kernel `CFLAGS` and the
   resident-module `MOD_CFLAGS`.  `user/` and ZEX builds keep their flags.
2. **Derived data base**: the two-pass build now measures the runtime-data
   size and derives `data_base = align_down(DF00h - (l__DATA +
   l__INITIALIZED), 512)`, `arena_end = data_base`, `arena =
   [align_up(__kernel_code_end, 512), data_base)`.  The fixed
   `-b _DATA = 0xC000` is gone; the linker command and `arena.asm` consume
   the generated values.
3. **Single geometry, honest naming**: the probe link places no arena; the
   `A000h`/16-granule placeholder, `ZOS_DRIVER_ARENA_DERIVED` and every
   "legacy"/"fixed" arena reference are removed.

## 2. Ledger before/after

Before (package-25 correction-02, fixed `C000h` data base):

```text
bank7: code 23521 bytes end 7BE1h | arena 34 granules (21 boot, 13 free) | data 1294 bytes at C000h | isr 256 | slack 6642 bytes
```

After (size-optimized compile + derived data base; the boot-set split was
`21 boot, 28 free` before correction-01, which is section 7):

```text
bank7: code 21689 bytes end 74B9h | arena 49 granules (21 boot, 28 free) | data 1309 bytes at D800h | isr 256 | slack 483 bytes
```

Per measure:

* size-optimized compile alone: kernel code `7BE1h -> 74B9h` (1832 bytes
  smaller); ROMFS recovery store `17890 -> 17548` bytes (module image
  deltas `ioc -231`, `hid -9`, `v9958 -89`, `sio +11`); with the fixed
  data base the arena would be `7600h-C000h`, 37 granules.
* derived data base: runtime data moves `C000h -> D800h`, so the arena end
  becomes `D800h` and the arena grows `34 -> 49` granules (+12 granules),
  leaving 483 bytes of slack above the data and below the `DF00h` ISR
  stack.

The 32-granule production floor still holds, and the arena plan still
reconciles the 21-granule production boot set.

## 3. Timing-loop audit

`--opt-code-size` can only invalidate a timing assumption if a *C* loop's
bound or body was calibrated to instruction timing.  Every C loop in the
kernel and drivers was audited:

* `drivers/sio/sio.c` `sio0b_wait_tx_ready`, `kernel/early_console.c`
  `early_console_putc` -- poll the SIO RR0 TX-ready bit with
  `ZOS_SIO_TX_TIMEOUT = FFFFh`.  The bound is a liveness guard ("a missing
  terminal cannot hang the kernel"), not a calibrated interval; the loop
  exits when hardware asserts the status bit.
* `drivers/ioc/ioc.c` `ioc_link_bringup` -- `ZOS_IOC_LINK_BRINGUP_TRIES`
  retries of a full hardware exchange; a retry count, not a delay.
* `drivers/hid/hid.c` `hid_service` -- `ZHID_STUCK_PENALTY` bounded deferred
  polling; a policy count, not a delay.
* `drivers/v9958/v9958.c` initialisation loops iterate fixed register/font
  tables; the only software pacing is `v9958_io_bootstrap_delay`, which is
  implemented in `drivers/v9958/v9958_io.asm` (a `djnz` loop) and is
  therefore untouched by the C optimizer.
* `kernel/main.c` `kernel_serial_connect_delay` -- the ~1 s connect delay is
  inline assembly (`ld de,#0x0BA3` outer loop + `djnz` inner loop), so its
  documented 9,997,529-cycle budget is instruction-accurate regardless of
  the C flags.
* `drivers/ioc/ioc_io.asm` and `drivers/sio/sio_io.asm` own every port
  access and the wire timing; all streaming/timing loops there are
  assembly.

Conclusion: no C loop derives its bound from instruction timing.  No
recalibration or assembly move was required; the reasoning is recorded
here.

## 4. Validation

```text
make clean && make check
  check: reproducible rebuild (91db5917e65262f26bdeece1a423cc612773efa8f90b22826c378029e5989fd5)
  Ran 532 tests in 42.251s -- OK (skipped=141)
  make check: OK

make zmod-test romfs-test zex-test monitor-test ioc-test hid-test v9958-test \
     m8-selftest m8-fallback-selftests m9-vfs-selftest
  exit 0 (7 ": OK" targets)

make subsystem-selftest m9-required-mount-selftest               -> OK
make m8-ioc-selftest m8-hid-selftest m8-console-selftest romfs-corrupt-selftest -> OK
make m8-hid-noioc-selftest m8-hid-badioc-selftest m8-v9958-fontfail-selftest   -> OK
make m8-v9958-selftest                                           -> OK

python3 -m unittest discover -s tests -v
  Ran 532 tests in 95.374s -- OK (skipped=119)

git diff --check                                                 -> clean
```

Artifact hashes:

```text
91db5917e65262f26bdeece1a423cc612773efa8f90b22826c378029e5989fd5  build/zephyros.bin
383fca3d4365471b041d1f243589c38f10b3978e0c2a9a67a97d1be7ca4d172d  build/modules/sio.zmod
ba088dd35fe25cb5695cc9bbd2c8c5ec3a217b7d3947e71432562150b287197e  build/modules/ioc.zmod
0633fc594697eb23c63f4c0d3bdb7800bb6da21242da6a65b79f786c75d99b81  build/modules/hid.zmod
f073fefe15fe8a4fa436bc515a3496321d2ea2fe349760d960578f3a4130804d  build/modules/v9958.zmod
67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed  build/modules/monitor.zex
```

## 5. Hardware

Each M8 smoke mode needs its own acceptance image flashed.  The modes do
**not** build or flash anything, and they do not accept the production
image:

| smoke mode | image to flash |
| --- | --- |
| `make smoke-hardware-m8` | `build-m8-selftest/zephyros-m8-selftest.bin` (`bcb1e3efc2c339895cb19da9ee52a21173173dc370d63f343160461abbd513db`) |
| `make smoke-hardware-m8-ioc` | `build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin` (`fdfd95f4f828eaf3af2761a2c6dce9ee823679d32de109c906b8a6d83a7ef189`) |
| manual HID-typing / V9958-console check | production `build/zephyros.bin` (`91db5917e65262f26bdeece1a423cc612773efa8f90b22826c378029e5989fd5`) |

Build them first (`make m8-selftest m8-ioc-selftest`), flash the image,
then start the smoke tool; the M8 images wait for the host sync sequence,
which the tool sends once the port is open, so start the tool and
power-cycle/press RESET.

Serial signature per image (replayed in the host simulators):

```text
production         65 bytes  (4 banner lines only; monitor on V9958)
m8-selftest       247 bytes  (4 banner lines + 6 "m8 selftest:" markers)
m8-ioc-selftest   322 bytes  (4 banner lines + "console: dynamic sio0.b OK"
                              + the m8 ioc transcript + selftest OK)
```

Status: **PASSED on hardware (2026-10-04)**, with the correct images
flashed (for the pre-correction hashes; section 7.4 re-runs the V9958
visual check for the corrected driver and passes it):

```text
$ make smoke-hardware-m8-ioc SERIAL_PORT=/dev/ttyUSB0
  smoke: image to flash: build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin
         sha256: fdfd95f4f828eaf3af2761a2c6dce9ee823679d32de109c906b8a6d83a7ef189
  captured 324 bytes (0 USB bridge drop(s))
  ZephyrOS 0.0 / platform: Zephyr-80 / kernel entry: OK / serial: OK
  console: dynamic sio0.b OK
  m8 ioc: transport level 08
  m8 ioc: controller level 4A
  m8 ioc: ping x4 OK
  m8 ioc: bulk write 1/128/512 OK
  m8 ioc: done x3 OK
  m8 ioc: bulk read 1/128/512 OK
  m8 ioc: cleanup OK 0x34
  m8 ioc: hid status 00
  m8 ioc selftest: OK
  serial_smoke: OK

$ make smoke-hardware-m8 SERIAL_PORT=/dev/ttyUSB0
  smoke: image to flash: build-m8-selftest/zephyros-m8-selftest.bin
         sha256: bcb1e3efc2c339895cb19da9ee52a21173173dc370d63f343160461abbd513db
  captured 247 bytes (0 USB bridge drop(s))
  ZephyrOS 0.0 / platform: Zephyr-80 / kernel entry: OK / serial: OK
  m8 selftest: input hid.keyboard0 class 04
  m8 selftest: output v9958.0 class 02
  m8 selftest: devices 04
  m8 selftest: ioc level 4A
  m8 selftest: rejected calls OK
  m8 selftest: OK
  serial_smoke: OK
```

The human gate also passed: the integration image's V9958 display showed
`console: dynamic sio0.b OK`, `m8 selftest: visible console marker`,
`ZephyrOS native monitor`, `bank=00 pid=0 scratch=0F19` and the `Z80>`
prompt; on the production image (`91db5917…`) the monitor accepted typed
`r`/`h` and printed the system-info and help screens, confirming HID input
plus V9958 output on the real board.  The IOC command/bulk lanes (the most
timing-sensitive C path) passed with the size-optimized compile and the
derived data base.

A first attempt had flashed the production image for both M8 modes and
stopped at the 65-byte production signature (`ZephyrOS 0.0 / platform:
Zephyr-80 / kernel entry: OK / serial: OK`, monitor visible on the
display) -- that is the expected production output, not a fault: the
per-image serial signatures above were confirmed against the linked bytes
with the host simulators (`tests/test_m8_acceptance.py`,
`tests/test_ioc_sim.py`).

Following that attempt the procedure was made explicit: each `make
smoke-hardware-*` target now prints the image it checks and that image's
sha256 (and fails with the build command when the image is missing), `make
hardware-images` builds every smoke image, and the README hardware section
and `docs/boot.md` name the image per mode.

## 6. Deviations / supporting changes

* `___sdcc_enter_ix` (the SDCC z80 crtenter frame helper that
  `--opt-code-size` selects) is now provided by the freestanding runtime:
  `kernel/runtime/sdcc_helpers.asm` and
  `modules/runtime/sdcc_indirect_calls.asm`.
* `tests/modules/m4_probe.c` read `&m4_probe_state` directly; the size
  optimizer narrowed the address to a single byte, which is a
  byte-fragmented relocation the ZMOD format deliberately does not carry.
  The fixture now reads the relocated word out of its descriptor's `state`
  field through a volatile pointer, keeping the established word
  relocation and the same runtime value.
* `ZMOD_ARCH_END`/`ZMOD_MAX_GRANULES` (`include/zephyros/module.h`,
  `tools/zmodpack.py`) moved from the retired `C000h` boundary to the
  bank-7 window below the ISR stack (`DF00h`, 95 granules); the loader's
  arena bound likewise uses `ZOS_BANK7_RUNTIME_END`, so the derived arena
  is not wrongly rejected above `C000h`.
* Host simulators that used a fixed bank-7 scratch address now derive the
  first free arena granule above the packed boot set from
  `arena.plan.json` (`tests/test_m9_vfs_sim.py`, `tests/test_romfs_sim.py`,
  `tests/test_v9958_sim.py`).
* `tools/mapcheck.py` dropped the `_module_catalog_load_all` production
  guard (the source-layout retention test prevents its return) and now
  reads `ZOS_DATA_BASE`/`ZOS_ARENA_PROBE`.

## 7. Correction-01: V9958 granules and strict geometry

`work/25b-m9-bank7-budget/correction-01/WORK.md` carried two items.  Both
are implemented; sections 2-6 above record the pre-correction package-25b
state, and this section supersedes their figures where they differ.

### 7.1 V9958 font staging (10 -> 9 granules)

The driver read one 32-glyph font group (256 bytes) and staged a whole
96-byte atlas scanline at a time; 352 of the module's 724 BSS bytes were
those two init-only buffers.  The staging is now 8 glyphs (64 bytes) and
matching 24-byte atlas segments
(`drivers/v9958/v9958.c`: `v9958_upload_atlas_chunk()` with
`V9958_ATLAS_GLYPHS 8`, `V9958_ATLAS_SEG_BYTES 24`, `V9958_ATLAS_CHUNKS
32` and `V9958_FONT_CHUNK 64` in `drivers/v9958/v9958_driver.h`).  The
ROMFS DATA-only resource read, the 2048-byte size validation before any
port I/O, both precolored atlases and the `ZVIDEO_RESET` reload are
unchanged.

```text
module   image / BSS / total (before)   image / BSS / total (after)   granules
v9958     4008 /  724 / 4732             4038 /  460 / 4498            10 -> 9
```

The 30 extra image bytes are the chunk/segment loop; the 264 fewer BSS
bytes are the staging shrink.  Adjusted figures:

* production boot set `21 -> 20` granules (`sio x1, ioc x8, hid x2,
  v9958 x9`) in the unchanged 49-granule production arena, so the free
  count is `28 -> 29` and the ledger reads
  `bank7: code 21689 bytes end 74B9h | arena 49 granules (20 boot, 29 free) | data 1309 bytes at D800h | isr 256 | slack 483 bytes`;
* recovery ROMFS store `17548 -> 17578` bytes
  (`sha256 c297ecae6920654681a4e40e9b9da25560d5bb8dba3d9a1fbc73118e63298d7f`);
* the `build-m8-v9958-selftest` image keeps its arena (`7E00h-D800h`,
  45 granules; linked code end `7C35h`, data 1310 bytes) with the boot set
  `21 -> 20` and free granules `24 -> 25`; `sio`, `ioc` and `hid` sizes and
  hashes are untouched.

**VRAM identity.**  The expected bytes were captured from the
pre-correction implementation first: the two driver files were restored to
`HEAD`, `build-m8-v9958-selftest` rebuilt, the VRAM read out through the
simulator, and the correction restored byte-for-byte (`v9958.c`
`1e4a15edf474feebd094be78285fc6cffc48f1b3f9717e9cf4b01aa974a6a1ea`,
`v9958_driver.h`
`e06cd5d4d97b3de8e5d8b56894740d3bcf91dfe3ee1f16642d1018f2a971ef3a`), then
re-measured.  SHA-256 of the whole normal atlas area `10000h-13FFFh` and
reverse atlas area `14000h-17FFFh`:

```text
before  normal  1b3f000702050efcd55fb94e2901060ea9d68f4328ce37166fb9277dce68028d
before  reverse ce282ea4e8e63098256f674d42491994a15c6207d3e5823be3d00020c1e28819
after   normal  1b3f000702050efcd55fb94e2901060ea9d68f4328ce37166fb9277dce68028d
after   reverse ce282ea4e8e63098256f674d42491994a15c6207d3e5823be3d00020c1e28819
```

Both atlases are additionally asserted scanline-by-scanline against the
independently computed expansion of the pinned font asset
(`check_atlases`, `tests/test_v9958_sim.py`), so the identity holds against
the font oracle and not only against the previous driver build.  The
font-failure image still publishes no device and performs no VDP access
(`TestV9958FontFailure`).

### 7.2 Strict derived geometry (no `C000h` fallback)

`tools/mapcheck.py`, `tools/pack_image.py` and `tools/zmodpack.py` no
longer carry `DEFAULT_ARENA_BASE`/`DEFAULT_ARENA_END`/`DEFAULT_GRANULE_SIZE`
fallbacks; every derived value is required and a missing key names the key
and the include it was expected in:

* `mapcheck.apply_layout(values, source)` -- `require_key()`;
  `ZOS_DRIVER_ARENA_BASE`, `ZOS_DRIVER_ARENA_END`, `ZOS_DRIVER_GRANULES`
  and `ZOS_DATA_BASE` are mandatory (`MapError`).
* `pack_image.apply_memory_inc(path)` -- `require_value()`; the same four
  keys are mandatory (`LayoutError`).  The tool no longer applies
  `platform/zephyr80/memory.inc` when it is invoked without an include;
  synthetic callers pass their values explicitly, as they did before.
* `zmodpack.build_bank7_ledger(values, used, source)` -- requires
  `ZOS_KERNEL_CODE_END`, `ZOS_DRIVER_ARENA_BASE`, `ZOS_DRIVER_ARENA_END`,
  `ZOS_DRIVER_GRANULES`, `ZOS_DATA_BASE`, `ZOS_DATA_SIZE` and
  `ZOS_BANK7_RUNTIME_END` (`ZmodError`); `plan` always emits the ledger.

Negative tests (real `memory.inc` text with one declaration deleted, in
`tests/test_m8.py`):

* `TestDerivedGeometry.test_missing_arena_end_in_geometry_fails_loudly`
* `TestDerivedGeometry.test_pack_image_requires_arena_end_in_geometry`
* `TestBootSetPlan.test_plan_requires_the_geometry_ledger_inputs`
  (drops `ZOS_KERNEL_CODE_END`)

### 7.3 Validation

```text
make clean && make check
  reproducible rebuild: build/zephyros.bin == build/zephyr80.bin
  eac0b13f90a7860b285c1e62dd62578a8e3bcfd3c835682801d7630a571e7d51
  ledger  bank7: code 21689 bytes end 74B9h | arena 49 granules
          (20 boot, 29 free) | data 1309 bytes at D800h | isr 256 | slack 483 bytes
  python3 -m unittest discover -s tests -v   Ran 535 tests -- OK (skipped=141)

make v9958-test m8-v9958-selftest m8-v9958-fontfail-selftest
     m8-console-selftest m8-selftest                       -> OK

python3 -m unittest tests.test_v9958 tests.test_v9958_sim
     tests.test_v9958_console tests.test_m8_acceptance
     tests.test_m8 tests.test_pack_image -v   Ran 132 tests -- OK (no skips)

make zmod-test                                             -> OK
python3 -m unittest tests.test_zmod                        Ran  43 tests -- OK
python3 -m unittest tests.test_validation_cli tests.test_zmod
     tests.test_romfs -v                                   Ran 117 tests -- OK (skipped=13)

git diff --check                                           -> clean
```

The 141 skips of the discovery pass are all "artefact not built in that
order": `make check` starts with `make clean`, so no `build-*` acceptance
image and no `zmod-test` fixture exists while it runs (32
`build-subsys-selftest`, 31 `build-m8-console-selftest`, 26
`build-m8-ioc-selftest`, 11 `build-m8-hid-selftest`, 5 `build-subsys-selftest`
recovery store, 5 `sio-irq.zmod`, 4 `build-m9-vfs-selftest`, 4
`build-m8-v9958-selftest`, 3 `m4_probe.zmod`, 2
`build-m9-required-mount-selftest`, 1 each for the remaining M8 images,
`zextest.zex`, `process_expect.inc` and `build-romfs-corrupt/*`).  The
contract's suite list, run after the image targets, needed none; the same
13 artefacts explain the 13 skips of `tests.test_romfs` + `tests.test_zmod`
before `make zmod-test` (they disappear after it: 43/43 passed).
`make v9958-test` precedes `m8-v9958-fontfail-selftest` in the listed
command, so its font-failure subset reports `skipped=25` there; the
explicit unittest run below it executes all 132 tests.

Artifact hashes (current):

```text
eac0b13f90a7860b285c1e62dd62578a8e3bcfd3c835682801d7630a571e7d51  build/zephyros.bin
383fca3d4365471b041d1f243589c38f10b3978e0c2a9a67a97d1be7ca4d172d  build/modules/sio.zmod
ba088dd35fe25cb5695cc9bbd2c8c5ec3a217b7d3947e71432562150b287197e  build/modules/ioc.zmod
0633fc594697eb23c63f4c0d3bdb7800bb6da21242da6a65b79f786c75d99b81  build/modules/hid.zmod
4ef408bb2b1716349bf2a2e6a0a9d37258a7727409ac9cfc3ade0b570cd3a9a3  build/modules/v9958.zmod
67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed  build/modules/monitor.zex
07b50acb917909d24e8eb27e272a4d803a64c3a212b7bff901d100ab36960033  build-m8-selftest/zephyros-m8-selftest.bin
79ff02c64abb87dc44576d19782504c9cff9afd54a0ec92a125e9aaa08a9c9b9  build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin
30f4ec0e99e015da6b654ab654b3debb306fb80402edba6af4e69172ee54ed45  build-m8-v9958-selftest/zephyros-m8-v9958-selftest.bin
```

### 7.4 Hardware -- PASSED (2026-10-04)

The correction changes the V9958 driver, so the driver's display output was
re-checked on the board.  Two corrected images were flashed and confirmed
visually; every line below is a photograph of the physical V9958 output.

**(a) M8 integration image.** `make smoke-hardware-m8` with
`build-m8-selftest/zephyros-m8-selftest.bin` (`07b50acb917909d24e8eb27e272a4d803a64c3a212b7bff901d100ab36960033`)
captured the full 247-byte signature again (banner, the six `m8 selftest:`
markers, `serial_smoke: OK`) and the display showed:

```text
console: dynamic sio0.b OK
m8 selftest: visible console marker
ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

**(b) Console-acceptance image.** `build-m8-console-selftest/zephyros-m8-console-selftest.bin`
(`971920192f11c79c67735fecbdc76dd845465b99d98f49499429028460bbaa65`)
-- which performs a full `ZVIDEO_RESET` and then writes normal text plus
one reverse-video word -- showed:

```text
m8 console: renderer visible
m8 console: reverse SGR normal        <- only "SGR" is reversed
m8
m8 console: renderer visible

ZephyrOS native monitor
bank=00 pid=0 scratch=0F19
Z80> _
```

The serial link carried its 169-byte transcript, byte-identical to the
replay (`ZephyrOS 0.0` / `platform: Zephyr-80` / `kernel entry: OK` /
`serial: OK` / `m8 console: input hid.keyboard0 class 04` /
`m8 console: output v9958.0 class 02` / `m8 console selftest: OK`), and the
visible lines match the simulator's decoded screen model row for row, with
the reverse flag set on exactly the three `SGR` cells and on nothing else:

```text
 0 |m8 console: renderer visible|
 1 |m8 console: reverse [S][G][R] normal|
 2 |m8|
 3 |m8 console: renderer visible|
 4 ||
```

**The `ESC c` / `ZVIDEO_RESET` redraw is proven by absence.**  The
`console: dynamic sio0.b OK` line is written through the dynamic console
(`kernel/main.c`) *before* the target-test hook runs, and it is missing
from the physical screen above -- therefore the reset cleared the bitmap,
and every row drawn afterwards (including the monitor banner, the status
line and the `Z80>` prompt with its sprite cursor) landed at the right
position, so the renderer stayed usable across the reset.  The
`build-m8-selftest` photo above shows the same line present when no reset
intervenes.

The corresponding replay assertions are
`tests/test_m8_sim.py::TestConsoleBootAndSession` (V9958 glyph trace),
`tests/test_v9958_sim.py` (`check_atlases`, `check_cursor`) and
`tests/test_v9958_console.py::test_glyph_command_geometry_is_exact` (the
reverse byte comes from the `40h` atlas page).

Both checked images link the same corrected
`drivers/v9958/v9958.c` / `v9958_driver.h` bytes, so the rendering path
under test is production's; the physical production run recorded in
section 5 (typed `r`/`h` monitor session) predates the correction, and the
console/target-test hooks add no display code of their own.
