> Supervisor-implemented (owner request). Runs after 58. Drivers, the
> nucleus IPC/VFS hot path, the simulator's lane model; no ABI change.

# Task

Cut the host's own cost per card read. After 58 the board reads 512 B in
23.0 ms (21.7 KiB/s); CP/M on the same firmware takes 12.8 ms and skips
every CRC. The firmware paces the bulk lane at 6 us/byte
(`Zephyr-80/Code/MCU/IOController/src/bulk_channel.c`), so 512 B is
~3 ms of wire: the rest is controller time (shared with CP/M) and ours.

A T-state profile of the readphase passes (simulator, OS side only; 7
commands, 12 reads, 6 misses) names the host costs:

| item | per | cost |
|---|---|---|
| `ioc_crc16`, C bitwise, 2 frames | command | 2.25 ms |
| `ioc_command_inner` + `ioc_build_request` | command | 1.2 ms |
| cache block -> `iocfat_batch` LDIR, then `copy_out` | read | 1.1 ms per 512 B |
| syscall + IPC + VFS (`ipc_syscall_call_object`, `endpoint_for`, `vfs_handle_find`, descriptor capture/release, event pick) | call | ~1 ms |

## Requirements

1. **The simulator's bulk lane runs at the firmware's rate**: 60 T per
   byte (6 us), not 250 (which was CP/M's whole read time). The FIFO
   budget tests keep holding at that rate; the phase table's `last` row
   becomes the board's wire time.
2. **Command-lane CRC in assembly**: CRC-16-CCITT (1021h, preset 0,
   MSB-first), byte-wise without a table (`x = hi ^ b; x ^= x >> 4;
   crc = (crc << 8) ^ (x << 12) ^ (x << 5) ^ x`), in the driver runtime
   or `ioc_io.asm`. Same results; a host test pins the routine's
   algorithm against the bitwise reference. Validation stays on.
3. **No staging copy on read**: `KFILE_OP_READ` copies from the cache
   block straight to the caller (`copy_out` from the slot); the batch
   staging remains only where a caller needs it (enumeration).
4. **Nucleus call path**: with 1-3 in, re-profile; fix the top self-time
   items of the syscall/IPC/VFS path (no struct copies by byte loop, an
   O(1) endpoint lookup for host numbers, no repeated handle scans in
   one call). Stop when no single item exceeds 0.1 ms per call.
5. **Measure**: `make phase-image` before and after (with 1 in, so both
   tables use the board's lane rate), the profile's top rows, and the
   door-to-door per read. Target: 512-byte miss host overhead (door to
   door minus `last`) halved; board SDBENCH 512 B >= 30 KiB/s.
6. No behaviour change: same bytes on the wire, same errors.

## Owner checklist (production image)

1. SDBENCH: 128 B ... 4 KiB rows; checksum PASS.
2. `hwtest` 4/4; `fs_selftest` 37/37; `timer card`; `vgmplay night.zvg`
   with 0 underruns.

## Validation (targeted)

```sh
make && make phase-image && make fs-selftest
python3 -m unittest tests.test_ioc tests.test_iocfat tests.test_readpath tests.test_hwtest_sim tests.test_console_acceptance tests.test_shell_sim tests.test_device_release tests.test_ipc
git diff --check
```

Kernel IPC changes also take `make ipc-selftest`.

Record: `docs/validation/<date>-m13-read-path-host.md`.
