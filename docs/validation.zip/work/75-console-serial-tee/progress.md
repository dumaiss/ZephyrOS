# Package 75: console serial tee — progress (working memory, present tense)

Status: ESC-lead fix applied and verified; final validation pending.

## Owner finding (2026-10-20, from the user's hardware run)

Serial-side VT100 key sequences lost their ESC lead-in (left arrow
rendered `[[D`, F1 `OP`): the scan consumed every 1Bh byte into the
gesture count.  Fixed per ZSDOS `sercon_rx_sink`: only the third
consecutive ESC is consumed; the first two of a partial match are data
and are delivered while SERIAL owns input.  Regression test:
`test_serial_key_sequences_keep_their_lead_in` (tui_keys via serial,
`ESC [ D` -> LEFT, `ESC O P` -> F1, teed to both lanes).  The shell's
`[[D`/`OP` echo at a prompt is pre-existing line-editor behaviour (ESC
is a control byte; the SDK readline ignores it).

## Before numbers (captured before any edit)

- Driver hot tier: capacity 32768, used 30642, **free 2126** (reserve 2048).
- console-v9958-hid.mod: hot 390 image + 0 bss; io 0 image + 4 bss.
- console-serial.mod (build-console-serial-selftest/): hot 377 + 0; io 0 + 4.
- Idle POLL (iobench `ipc.null`, unarmed, old image): **15,368** T-states.

## After numbers (fixed source)

- Driver hot tier: free **1737**; reserve lowered to **1536** in
  test_iocfat.py and the architecture ledger (WORK.md overrun rule;
  growth 383 <= 590).
- console-v9958-hid.mod: hot **773** image + 0 bss (+383 <= 400);
  io 0 image + **10** bss (+6).
- console-serial.mod: byte-identical, sha256
  1150f41f29a4c3ab77660564b984fe28bcb348b05447613a1ccc76f1c8d3d690.
- Idle POLL: **19,121** T-states (+3,753; the serial drain is one more
  call per poll).

## Verified green (post-fix)

- tests.test_console_tee (7), test_console_acceptance, test_shell_sim,
  test_iocfat, test_source_layout: 87 tests OK.
- make console-serial-selftest: 6 tests OK; serial module hash unchanged.
- test_tui_sim: re-running in background after the fix (41 expected).

## Still to do

- Read the test_tui_sim result; then once:
  `make clean && make check` (wall clock), then write
  docs/validation/2026-10-20-console-serial-tee.md.
- Do not commit.

## Failure entry (make check, final validation)

- Command: `make clean && make check` (wall clock 48m6s).
- One-line failure: check-fast died (Error 1) during the full
  `python3 -m unittest discover -s tests`; last stdout lines are
  fontpack's usage docstring (from test_v9958's usage check, which
  passes on its own: 25 tests OK, 1 skip).
- Class: unknown until the failing test is identified
  (full discover re-run to /tmp/checkfast.log, in progress).
- Hypothesis: a pin I did not update (plan/deps/font?), or a slow-sim
  step-budget flake; the reproduction `make` before check rebuilt
  everything from clean.
- Next action: read /tmp/checkfast.log for FAIL/ERROR lines, classify,
  then fix or report.

## Failure classification (both)

- test_pack_image.TestNucleusLedgers.test_ledger_lines_match_the_built_image
  and test_sound.TestSoundContract.test_the_driver_tier_keeps_its_reserve:
  class `test artifact` - both pinned the old 2,048-byte driver-hot
  reserve; the WORK.md budget rule lowers the reserve to 1,536 (growth
  383 <= 590).  Pins updated; the two tests pass on their own.  The full
  discover re-run (after the two fixes it is green apart from these two):
  exactly these two FAILs, no errors.  `make check` re-run pending.

## DONE

- `make clean && make check`: OK (45m31s), reproducible; production
  image sha256 0a9f74a7293023f522e15738619f3390956a9c7cd13eecc05ec44c11c0c3c537.
- `make console-serial-selftest` re-run after the clean: 6 tests OK;
  serial module hash unchanged.
- Final: console-v9958-hid hot 773 + 0, io 0 + 10; hot free 1737.
- Record written: docs/validation/2026-10-20-console-serial-tee.md.
- Not committed, as instructed.

## Hardware status

The owner tested the fixed build on the board (2026-10-20): the ESC
ESC ESC gesture, serial-side arrow/function keys, the switch-back and
the reboot clear all work on real terminals.  Record updated; the
hardware item is closed.  Still no commit.
