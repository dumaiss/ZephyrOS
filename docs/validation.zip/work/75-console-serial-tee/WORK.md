> Worker package. Baseline: the current tree, which carries package 74's
> console RENDER path (implemented, not yet reviewed; the production build
> works). Drivers and docs only: no ABI change, no firmware, no kernel.

# Task

A serial rescue path on the production console, as ZSDOS has: three ESCs
typed on the serial terminal arm a **tee** (console output also goes to
the serial line) and switch **input ownership** between the USB keyboard
and the serial line; three more switch it back.

## Current state

- `console-v9958-hid` (`drivers/console/console_proto.c`,
  `console_driver_dispatch`) forwards each op to one dependency:
  - input ops (`KCONSOLE_OP_READ`, `GETC`, `POLL`) to HID, `deps[0]`;
  - output ops (`WRITE`, `PUTC`, `RENDER`) to VIDEO, `deps[1]`;
  - `console_forward` copies the frame and calls through.

  Its manifest `drivers/console/console-v9958-hid.json` depends on
  `INPUT`, `VIDEO`. The console owns no buffer and no IRQ.
- `console-serial` is the same source built with `KOS_CONSOLE_SERIAL`
  (SERIAL for both directions). It refuses `KCONSOLE_OP_RENDER`
  (`-KOS_ENOTSUP`), and libtui then falls back to ANSI text through WRITE.
- The SIO driver (`drivers/sio/`) is polling-only and claims no IRQ. Its
  protocol is `KSIO_OP_PUTC/WRITE/POLL/GETC/READ` (`abi/kos/protocol.h`).
  `systems/production.json` already loads `sio`.
- ZSDOS's tee, the behaviour to match: the receive sink and the gesture
  in `Zephyr-80/Code/HOST/CPM2.2/src/common/sercon.asm`
  (`sercon_rx_sink`); CONST/CONIN in `src/drivers/console/sercon.asm`.

Read: `work/00-WORKER.md`; the files above; `docs/devices.md` (console);
architecture 5.5 and 5.6.

## Requirements

1. **Dependency** (Must): `console-v9958-hid.json` gains `SERIAL` as its
   third dependency, `deps[2]`. `console-serial` is unchanged, and none of
   this code is in its build.
2. **Gesture** (Must):
   - Three consecutive `1Bh` bytes from the serial line toggle input
     ownership and arm the tee. Any other byte resets the count.
   - The gesture's bytes are consumed, never delivered.
   - Detection is polled. Every input op (`READ`, `GETC`, `POLL`) first
     drains the serial line through `KSIO_OP_GETC` until `-KOS_EAGAIN`,
     counting ESCs. While the HID owns input those serial bytes are
     dropped, as ZSDOS drops them.
3. **Input ownership** (Must): with the serial line owning input, the
   input ops are served from it.
   - `READ` may return one byte per call (a short read): bytes are
     inspected for the gesture before delivery, through a one-byte
     `DRIVER_IO` buffer and `copy_out`.
   - HID input is not delivered while the serial line owns input.
4. **Tee** (Must): while armed, `WRITE` and `PUTC` go to VIDEO and to
   SERIAL (`KSIO_OP_WRITE` with the caller's same descriptor, `KSIO_OP_PUTC`),
   VIDEO first. A SERIAL error does not fail the call. The tee stays armed
   until reboot, `KCONSOLE_OP_RESET` included: it survives the launcher's
   reset before every boot program, so the rescue persists.
5. **RENDER** (Must): while the tee is armed, `KCONSOLE_OP_RENDER` returns
   `-KOS_ENOTSUP`, so libtui falls back to ANSI text, which the tee carries
   to both screens. Unarmed, RENDER is unchanged.
6. **State in one place** (Must, structural): the ownership flag, the tee
   flag and the ESC count are three bytes in the console driver, and
   `console_driver_dispatch` is the only reader and writer. The record
   names them.
7. **Docs**: `docs/devices.md` (console section) and architecture 5.6:
   the tee, the gesture, polled detection and its limit (a program that
   never calls the console's input ops does not see the gesture).

## Invariants

- `console_forward` stays the only path to a dependency: the tee is two
  `console_forward` calls, not a second call mechanism.
- Unarmed, every op behaves exactly as now. The record shows this with the
  existing console, shell and TUI replays passing unchanged.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot tier free / reserve (`test_iocfat`) | 2,126 / 2,048 | lower the reserve to 1,536: up to 590 bytes | stop and report |

Report the console image's hot and io bytes before and after.

## Criteria

- **Must:** requirements 1-6; the tests below; `make check` green;
  `make console-serial-selftest` green.
- **Should:** the console image grows by no more than 400 bytes (a finding
  if more, within the budget).
- **Informational:** the T-states one idle `POLL` costs, unarmed, before
  and after: the serial drain is one more call per poll.

## Simulator

The SIO0/B model in `tests/z80sim.py` (`sio_rx`, `sio_tx`) mirrors
`drivers/sio/` port use. It does not model baud timing, flow control
(CTS) or a terminal's own key sequences. The owner checklist covers them.

## Tests (`tests/test_console_tee.py`, production image)

- three ESCs on `sio_rx` arm the tee: later shell output appears on both
  `sio_tx` and the V9958 trace;
- a command typed on the serial line runs, and HID keys are ignored while
  the serial line owns input;
- three more ESCs return input to the HID; output stays teed;
- the gesture's bytes reach no program;
- two ESCs then another byte do nothing;
- RENDER is `-KOS_ENOTSUP` while armed (a probe or a TUI example), and
  unchanged unarmed.

## Owner checklist

- A real terminal (any baud the SIO is set to): ESC ESC ESC at the shell
  prompt, type commands, run a TUI example (ANSI fallback on both
  screens), ESC ESC ESC back, `reboot` (the tee is off again).

## Validation

```sh
make && python3 -m unittest tests.test_console_tee tests.test_console_acceptance tests.test_shell_sim tests.test_iocfat tests.test_source_layout
make console-serial-selftest
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-console-serial-tee.md`.
