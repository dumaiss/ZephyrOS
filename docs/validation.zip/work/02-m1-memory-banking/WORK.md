# Task

Build on accepted M0 to implement the M1 memory and banking foundation: make region ownership explicit in shared constants and linker placement, add safe low-level banking primitives, reserve native page zero and the common transition stack/state, and expose enough symbols for build-time validation without adding later kernel subsystems.

## Context

The hardware latch is readable/writable at port `00h`. Bits `D0-D2` select SRAM bank `0-7`; `D4:D3` select mode (`00h` ROM, `08h` flat SRAM, `10h` application, `18h` OS); bits `D7:D5` select ROM page. Runtime mode `10` maps selected bank `N` at `0000h-DFFFh` and physical bank 0 at `E000h-FFFFh`. Mode `11` preserves bank `N` at `0000h-1FFFh`, maps physical bank 7 at `2000h-DFFFh`, and preserves bank 0 common memory at `E000h-FFFFh`.

Retain the M0 linked layout and 128 KiB ROM format. The permanent common stack is `FF00h-FFFFh`, initial top `10000h` represented by `SP=0000h`. Kernel body/code/data belong in `2000h-DFFFh`; only reset/page-zero material belongs below `0100h`; only transition code, critical transition state, early fatal support, and the stack belong in common memory.

## Requirements

- Define every memory boundary and latch bit once for assembly and once for C, with an obvious parity check in host tests so the two representations cannot silently drift. Do not scatter numeric mode/port constants outside `platform/zephyr80/` and linker/validation files.
- Give linker areas explicit ownership for page zero/reset, bank-7 OS code/rodata/data/BSS, common code/data, and the common stack reservation. Export start/end symbols for each owned region and for the startup initializer/BSS operations.
- Reserve all of `0000h-00FFh` as ZephyrOS-owned native page zero. Preserve `0030h-0032h` for the three-byte M1 syscall jump implemented in the next stage; ensure no reset copier or linker area can consume it.
- Make startup deterministic: selected application bank 0, mode `11`, common stack active, initialized data copied, BSS zeroed, and interrupts disabled when `kernel_main()` is entered. Add a boot-time assertion or diagnostic for any latch state that can be checked safely.
- Implement assembly-backed internal platform primitives. The latch read,
  selected-bank read, and selected-bank update may be declared as ordinary
  internal C-callable helpers in `include/zephyros/platform.h`; bank update must
  preserve all non-bank latch bits and must reject bank 7 when the argument
  represents an application bank. Mode `10`/`11` transitions are assembly gate
  operations with explicit common-memory continuations, not ordinary C
  functions: a return address in `2000h-DFFFh` would disappear when leaving OS
  mode. Provide entry to OS mode and transfer back to application mode while
  preserving selected-bank identity.
- Keep any primitive that changes mappings, plus all instructions it must execute immediately afterward, in common memory. It must not use a stack or return address that becomes hidden by its own mapping change. Document register clobbers in assembly comments.
- Use a single common-memory state block for transition-critical M1 state. Reserve only what the next syscall-gate stage needs (saved caller SP/latch and a small kernel gate stack if separate from the boot stack); do not design process structures or nested entry support.
- Add a build-time/debug assertion that the kernel is in mode `11` before body code assumes bank 7 is visible. Failure must use the early console when safe and then halt.
- Extend `docs/architecture.md` only where an implementation choice is now fixed, and add a concise implemented memory table to `docs/boot.md` or a dedicated `docs/memory.md`.
- Add host tests for constant parity, expected section ranges, latch mask operations, bank-identity preservation across `10h`/`18h`, and rejection of application bank 7.

## Files

Likely files to inspect or modify:

- `include/zephyros/platform.h`
- `platform/zephyr80/hardware.h`
- `platform/zephyr80/hardware.inc`
- `platform/zephyr80/memory.inc`
- `platform/zephyr80/banking.asm`
- `platform/zephyr80/reset.asm`
- `boot/start.asm`
- `linker/zephyr80.lk`
- `tools/pack_image.py`
- `tests/`
- `docs/architecture.md`
- `docs/boot.md`

## Constraints

- Mode `10`/`11`, bank-7 OS body, bank-0 common memory, and preservation of the caller's low 8 KiB are invariants.
- Bank changes are platform mechanisms, not public stable ABI. Do not expose SDCC register/stack conventions as ZephyrOS ABI.
- Do not add a memory allocator, scheduler, process model, interrupt setup, dynamic driver layer, far-memory abstraction, or CP/M compatibility.
- Do not enlarge common memory usage merely for convenience. Default new kernel logic and state to bank 7.
- Continue to build and boot the accepted M0 path after every change.

## Validation

```sh
make clean
make
make test
make check
```

Inspect the generated map/symbol output and disassembly. Confirm every mapping-changing routine resides in `E000h-FEFFh`, no linked byte occupies the stack reservation, page zero remains within `0000h-00FFh`, and the M0 banner is unchanged in MAME.

## Acceptance criteria

- The documented and linked layout exactly implements mode `10`/`11` ownership.
- Kernel entry is deterministic and validated: bank identity 0, mode `11`, common stack, initialized C state, interrupts disabled.
- Banking primitives preserve unrelated latch fields and never execute hidden code or use a disappearing stack.
- Page zero and transition state are explicitly reserved for the syscall stage.
- Host tests and all M0 validation pass with no new banner or boot regression.
