# Task

Complete milestone M4 by converting the accepted M3 SIO0/B driver into a relocatable ZMOD, embedding it in the boot catalog, loading it at a runtime-selected driver-arena address, registering `sio0.b` through the unchanged M3 registry, binding the normal console service, proving a relocated module IRQ handler, and recording physical-hardware acceptance and failure fallback.

## Context

The preceding package provides the 512-byte-granule arena, ZMOD v1 tooling, loader, embedded-catalog abstraction, versioned driver API, owner-based rollback, and resident-code validation. M3's early console remains direct and common-resident. The default M4 build must not include the SIO driver in `boot_drivers[]`; its implementation and private state must come only from the module allocation.

The same `.zmod` bytes must work at different arena bases. Kernel variants may move the linker-defined arena in 512-byte increments, but must not rebuild or rewrite the module blob between placement tests.

## Requirements

- Refactor the SIO driver so its module image has no direct kernel-symbol references. Access device registration and IRQ ownership only through driver API v1. Keep raw SIO I/O code and module-private state inside the module image/BSS; preserve `sio0.b`, classes, capabilities, and ops semantics from M3.
- Add a dedicated module build/link/pack pipeline producing `build/modules/sio.zmod`, a dump report, and generated embedded-catalog data. The generated catalog must preserve exact bytes and size, be reproducible, and avoid handwritten byte arrays.
- Remove `sio_driver` from the default static driver table. Boot order becomes M2 IRQ init, empty M3 registry, embedded module loading, service binding, then normal console output. Assert in tests/map reports that no second static SIO implementation/state remains.
- Load the SIO ZMOD through the generic catalog/loader only. Do not special-case its name, size, load address, relocation list, init function, device, or arena position in kernel loader code.
- After init, verify `sio0.b` is registered through the unchanged registry and selected by capabilities. Print `console: dynamic sio0.b OK` through the normal console service. Keep all loader diagnostics before binding on `early_console_*`.
- Provide a deliberate failure build using a corrupted or init-failing SIO module. It must leave no SIO device/IRQ claim/resident allocation, restore all arena/registry ownership state, and print an actionable early-console diagnostic without depending on the failed driver.
- Add an alternate-placement build that changes the arena start by at least one 512-byte granule while using a byte-identical `sio.zmod`. Verify the reported load address changes and all relocations/device operations still succeed.
- Add a module self-test mode in which a relocated handler inside the SIO module claims `IRQ_CTC0` through the M2 API, counts repeated interrupts, and releases/quiesces the source. The handler must access its relocated private state correctly and return normally to the executive. Keep the production SIO data path polling unless IRQ-driven serial I/O is separately justified.
- Add host checks for catalog integrity, absence from `boot_drivers[]`, module hash identity across kernel-placement builds, relocated ops/state/handler pointers within the RESIDENT allocation, console binding, and complete failure rollback.
- Add `make m4-selftest`, `make m4-placement-selftest`, `make m4-failure-selftest`, and a physical serial smoke target. Keep host-only checks distinct from target evidence.
- Update `README.md`, `docs/module-format.md`, and implementation notes. Add a dated M4 validation record with tool versions, module/kernel hashes, dump report, chosen load addresses, rollback results, IRQ results, and exact physical serial output. Do not claim hardware success without observation.

## Files

Likely files to inspect or modify:

- `drivers/sio/sio.c`
- `drivers/sio/sio_io.asm`
- `drivers/sio/driver.c`
- `kernel/device/driver.c`
- `kernel/module/embedded.c`
- `kernel/module/loader.c`
- `kernel/main.c`
- `include/zephyros/driver.h`
- `include/zephyros/module.h`
- `tools/zmodpack.py`
- `Makefile`
- `tools/mapcheck.py`
- `tests/`
- `README.md`
- `docs/module-format.md`
- `docs/validation/`

## Constraints

- Preserve the M3 registry, capability model, console API, and driver API semantics. M4 changes code provenance, not the device model.
- No static SIO fallback in the normal console path. The independent early console is the diagnostic fallback.
- No runtime unload, reload, hot-plug, filesystem lookup, or fixed-slot module link address.
- Do not weaken arena, handler-address, relocation, ABI, or rollback validation to make the SIO module load.
- Preserve all M0–M3 hardware paths and acceptance tests.

## Validation

```sh
make clean
make
make test
make check
make m4-selftest
make m4-placement-selftest
make m4-failure-selftest
make smoke-hardware-m4 SERIAL_PORT=/dev/ttyUSB0
```

## Acceptance criteria

- Every criterion in `docs/architecture.md` section 23 passes.
- The default image contains no statically initialized SIO driver; the embedded SIO ZMOD is generically loaded and becomes RESIDENT.
- The same ZMOD bytes run at two allocator-selected addresses with correct relocation/BSS/private state.
- `sio0.b` registration and capability-based console binding are unchanged from M3, and physical normal-console output succeeds.
- A relocated module handler executes through M2, and deliberate load/init failure fully rolls back while early diagnostics remain available.
- All earlier milestone validations remain green.
