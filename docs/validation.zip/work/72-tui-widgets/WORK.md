# Task

Build the optional procedural widget library on the accepted core TUI: status
and menu bars, simple modal dialogs, labels, buttons, input, checkbox, list
box, and the small interaction helpers. It is a separate archive and adds no
object framework or OS dependency.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`, especially "Widgets";
- `docs/konaos-tui-sdk-architecture.md`, section 10 and WP-TUI-7;
- packages 66-71 and their accepted validation records;
- current `tui.h`, screen/key/region code, and `tests/tui/tui_test.c`.

## Requirements

1. Add `user/sdk/include/tui_widgets.h` with the architecture's v1 surface,
   `TUI_BUTTON(id)`, and comments that pin the mask, focus, commit/cancel, and
   result rules from `work/TUI-REFERENCE.md`.
2. Create `user/sdk/widgets/src/` and deterministic
   `libtui_widgets.lib`. It depends only on public `tui.h` calls and small
   klibc helpers; it may not include TUI-private headers or access the cell map.
3. Implement the render-only layer:

   ```text
   tui_statusbar tui_menubar
   tui_button tui_label tui_input tui_checkbox tui_listbox
   ```

   Clip every label/control, keep caller-owned values and list state, and
   redraw only cells the control owns.
4. Implement the interaction/modal layer:

   ```text
   tui_message_box tui_confirm
   tui_menu_run tui_input_run
   ```

   Follow the exact keyboard/navigation rules in the shared reference. Modal
   functions use the reference's separately linked, non-reentrant 60 x 16
   static save buffer, validate the derived `tui_saved_size`, restore their
   covered region on every exit path, and do not allocate.
5. Ship the widget header and archive in `make sdk`. Extend `LIBS=` coverage
   with `LIBS=tui_widgets:tui`, the exact dependency order. A core-only program
   has no widget member or data cost.
6. Extend the target program with a deterministic configuration form: menu,
   list, editable field, checkbox, buttons, confirmation, accept and cancel.
   Drive it with injected keys on both consoles and assert caller-owned state,
   selected IDs, restored background, focus drawing, and final transcript.
7. Cover empty lists, long labels/messages, word wrapping, the 60 x 16 cap,
   nested-modal refusal, minimal rectangles, empty/invalid button masks, input
   buffer boundaries, ESC cancellation, shortcuts, and every navigation key
   used by the widgets.
8. Extend package tests for the two deterministic archives, shipped layout,
   header closure, dependency direction, and absence from non-widget maps.

## Acceptance

- The configuration form completes entirely through public widget and core
  APIs on both console implementations.
- Widgets contain no terminal sequences, CP850 constants, OS calls, heap, or
  private-core access.
- Modal exit restores the exact saved screen on accept, cancel, and input
  error.
- Core-only and no-TUI program sizes/maps are unchanged by adding the archive.

## Constraints

- No object hierarchy, inheritance, callback framework, mouse, event loop,
  layout engine, theme engine, or graphical abstraction.
- No kernel, driver, firmware, protocol, or system-image change.
- Record `docs/validation/<date>-tui-widgets.md` with archive members and size
  deltas for no-TUI, core-only, and widget programs.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package
git diff --check
```

