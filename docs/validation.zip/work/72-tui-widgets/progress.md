# Progress

## Status

DONE — accepted by supervisor on 2026-10-18. Package 73 remains gated by
package 70 correction 01. No commit was made.

## Done

- `user/sdk/include/tui_widgets.h`: architecture v1 surface, `TUI_BUTTON`,
  pinned mask/focus/commit/cancel/result rules.
- `user/sdk/widgets/src/`: `widget_common`, `widget_render`, `widget_menu`,
  `widget_input`, `widget_modal`; deterministic `libtui_widgets.lib`.
- `user/sdk/exe.mk`, `Makefile`, `tools/sdkpack.py`,
  `tests/test_sdk_package.py`: archive build, `LIBS=tui_widgets:tui`, SDK
  header/archive packaging and out-of-tree widget probe.
- `tests/tui/tui_test.c`: `widgets` configuration form driven by injected
  keys; `tests/tui/tui_widget_probe.c`: render-only map proof.
- `tests/test_tui.py`, `tests/test_source_layout.py`, `tests/test_sdk.py`:
  archive members, public boundary, link order, sizes and owner checks.
- Report: `docs/validation/2026-10-18-tui-widgets.md`.

## Supervisor acceptance

- Reviewed the public-only dependency boundary, deterministic member split,
  caller-owned render state, keyboard policies, bounded word wrapping, modal
  save/restore cleanup paths, and the non-reentrant 60 x 16 buffer.
- Accepted the worker's combined 173-test gate (171 passed and 2 environmental
  skips) plus its dual-backend configuration-form replay and SDK packaging
  evidence.
- Independently observed the widget archive/header, SDK, and link-map checks
  pass before stopping duplicate validation at the owner's request.
- Package 70's outstanding defect concerns only zero-height titled frames;
  widget modals reject boxes smaller than 5 x 5, so correction 01 does not
  change package 72's accepted behavior.
