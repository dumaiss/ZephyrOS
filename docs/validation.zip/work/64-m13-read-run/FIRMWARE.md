# IOC firmware: `FS2_READ_RUN`

An added command. No existing command, reply, timing or default changes.
Hosts that never send it see the firmware exactly as before.
Implemented in `Code/MCU/IOController` (`src/fs2.c`, `src/main.c`).

## Why

Today every 512-byte FS2 read is a full command round trip: request
window, decode, `f_read` (card), READY reply, RTS wait, bulk packet. On a
sequential read, all of that except the card read and the bulk packet is
paid again for every block. A run pays the command once for up to four
blocks.

## Command

| | |
|---|---|
| request | `CMD_FS2_READ_RUN` = `45h` |
| reply | `RSP_FS2_READ_RUN` = `C5h` |
| CAPS flag | `IOC_FS2_CAP_READ_RUN` = `1000h` in `RSP_FS2_CAPS` flags |
| run limit | `IOC_FS2_RUN_MAX` = 2048 bytes (4 blocks) |

It's in `ioc_frame.h`, `dispatch.c` and `is_command_class()` in
`external_sync.c` (the FS2 range check ends at `CMD_FS2_READ_RUN`).

Request DATA: the same 8 bytes as `FS2_READ`: token (u16), offset (u32),
length (u16), little-endian.

Rejected with `IOC_STATUS_FS2_RANGE` and no bulk phase: length 0, length
over 2048, or offset not a multiple of 512. Token, generation and seek
errors are reported exactly as `FS2_READ` reports them.

## Reply and run

1. The handler seeks as `FS2_READ` does and reads the **whole run** into the
   shared bulk buffer (`fs_bulk_chunk`, now 2048 bytes; every other transfer
   uses its first 512) **before replying**. The card time is spent while
   the host waits for the reply, which it does with interrupts enabled.
   It's never spent while the host waits, masked, for a packet's
   admission.
2. A read error is the reply's STATUS, with no bulk phase.
3. End of file at the offset: READY with length 0 and no bulk phase (as
   `FS2_READ`).
4. Otherwise READY (the existing 8-byte payload) carries:
   - the transfer id;
   - direction MCU→Z80;
   - **LEN = the bytes read**, `min(length, size - offset)`;
   - the offset.

   The host derives the block count, `ceil(LEN / 512)`.
5. Then one bulk packet per 512 bytes, in order, each with the existing
   per-packet admission: RTS on channel A (500 ms bound), `/DCDA`, the
   100 µs guard, the common packet, the trailing `FFh`. Each packet has
   TYPE `C5h`, SEQ = the request's SEQ and STATUS OK; its DATA is that block
   (512 bytes, the last one possibly short). Bulk CRC is handled as today
   (bypassed).
6. Between two packets the firmware waits (500 ms bound) for the host to
   **release** RTS (`bulk_channel_wait_host_release`). RTS is a level the
   host holds until it has seen `/CTSA` close the phase, so starting the
   next phase while it is still asserted would re-assert `/CTSA` before the
   host saw it drop. Only then is the next packet armed (`fs2_run_next`)
   and admitted by the host's next RTS. A failed phase or wait ends the
   run; the file position stays where the read left it.

The host asserts RTS once per packet, so the controller never sends faster
than the host drains, and the host's interrupts run between packets.
Packets go out back to back: there is no card work between them.

The host also accepts a packet whose STATUS is an error (at the normal
length) as a failed run. This firmware never sends one, because all card
reads finish before READY.

## Rules

- The controller serves nothing else on the lanes during a run: the host
  sends no command until the last packet has arrived.
- Reads only: there is no write run.
- The run costs 1,536 bytes of RAM (data space 11,704 of 12,800). The SD
  block cache stays.

## Later (not implemented)

- **Longer runs:** the SD cache's 4 KiB of RAM could become the run buffer
  (4 KiB runs) now that both hosts cache on the Z80 side.
- **CMD18:** `f_read` of whole sectors calls `disk_read` with a count. A
  multi-block `sd_card` read (CMD18, CMD12) behind it would pay the
  card's access time once per run instead of per block.

## Measure (diagnostic build, `CMD_PROFILE`)

Before and after: `SDBENCH /S /P` (or the UPROF buckets read directly) for
a sequential read. Record DISPATCH and BULK_* per block.

## Acceptance

- CP/M (ZSDOS) behaves identically, since it never sends `45h`.
- KonaOS (package 64) reads with runs: `fs_selftest`, `hwtest` and SDBENCH
  checksums pass, and `ls`, `cat` and `cp` behave as before.
- The run's first block, its last short block, end of file at the offset,
  and a host timeout each leave the controller serving the next command
  normally.
