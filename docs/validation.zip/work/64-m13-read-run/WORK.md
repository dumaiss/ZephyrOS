> Supervisor-implemented (owner request). Needs IOC firmware with
> `FS2_READ_RUN` (`FIRMWARE.md`, owner) for the board; everything here is
> testable in the simulator first. No ABI or architecture change.

# Task

Read file runs with one IOC command: up to a ring of consecutive blocks
per `FS2_READ_RUN` (4 blocks, 2 KiB), one bulk packet per block, into
IOC-FAT's ring. When
the firmware lacks the command (CAPS flag clear), use the per-block
`FS2_READ` path unchanged.

Read: `work/00-WORKER.md`; `FIRMWARE.md` (the wire contract); the 59-61
records; `drivers/ioc/ioc_io.asm`, `ioc.c`, `ioc_proto.c`,
`ioc_driver.h`; `drivers/iocfat/iocfat.c` (`iocfat_transfer`,
`iocfat_ring_fill`); `tests/z80sim.py` (the IOC model and its firmware
schedule).

## Requirements

1. **Detect:** IOC-FAT reads `IOC_FS2_CAP_READ_RUN` (1000h) from CAPS at
   init and on every CAPS refresh; a clear flag means no runs.
2. **IOC driver: `KIOC_OP_COMMAND_READ_RUN` (7).** The command exchange,
   then one bulk receive per block into consecutive 512-byte slots of the
   caller's hot-tier buffer (the direct form of `KIOC_OP_COMMAND_READ`),
   each packet checked against TYPE `C5h` and the request SEQ. Returns the
   bytes received. An error packet ends the run: it returns the bytes
   before it and leaves its status in the reply frame. A missing packet is
   the existing bulk timeout. The transport stays owned for the whole run.
   In assembly, reusing the 61 receive (no per-packet C).
3. **IOC-FAT:** runs as long as the ring: 4 blocks (2 KiB) today; 8 only
   if the room below is found (worth ~5% more, so measure 4 first).
   `iocfat_ring_fill` groups the misses into runs:
   - an uncached file: one run per fill;
   - a cached file: blocks already in the cache split the runs.

   A short or error-ended run keeps the blocks received; an error with
   nothing received is reported as today. The measurement build keeps
   its ring of 2.

   **Layout limit:** the tier's free space is fragmented. The packer
   places hot segments largest first, below the io block or above C000h.
   Today the gap below the io block has ~290 bytes left, and above C000h
   ~3.8 KB. +2 KiB of ring in the io block pushes the IOC driver's hot
   segment (4.3 KB) above C000h, where it doesn't fit. So either:
   - find the room first: a smaller `DRIVER_IO` elsewhere (the bulk
     receive must land in the io block, so the bulk tier can't hold the
     ring);
   - otherwise stay at 4.

   Report both regions before and after.
4. **Fallback:** no CAPS flag, or `FS2_RANGE`/`RSP_UNKNOWN` to a run, means
   the per-block path for the rest of the mount. Both paths are tested.
5. **Simulator:** model `45h` exactly as `FIRMWARE.md` (stage 1 timing:
   the firmware schedule per packet, a card time per block). Add a CAPS
   flag switch. Cover: a full run, a last short block, end of file at the
   offset, an error packet at block 3, and old firmware.
6. **Measure:** the phase image, a cold 4 KiB read with and without runs
   (simulator), and the per-call profile. Board: SDBENCH (all sizes) on the
   new firmware, plus one row on the old firmware (fallback).
7. No behaviour change otherwise: every IOC, IOC-FAT, readpath and image
   test passes on both firmware models.

## Owner checklist

- New firmware: SDBENCH, `fs_selftest`, `hwtest`, `timer card`,
  `vgmplay night.zvg` (0 underruns), and typing during a large `type`
  (keys not lost).
- Old firmware: SDBENCH, `fs_selftest`.

## Validation

```sh
make && python3 -m unittest tests.test_ioc tests.test_iocfat tests.test_readpath tests.test_hwtest_sim tests.test_shell_sim
make phase-image && make fs-selftest
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-m13-read-run.md`.
