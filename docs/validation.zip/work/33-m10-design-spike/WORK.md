# Task

Measure, with working code, how much of the M10 target (ZEX v2, extended
memory, far calls) fits in the end-of-M9 bank-7 residency when it is built
resident-lean, with the host doing as much as possible. The spike builds
**real, minimal implementations** of each M10 mechanism (not stubs), in a
dedicated spike configuration. It measures their resident bytes, gate-stack
depth and common use, and projects the full M10. The project owner then
decides with numbers: proceed within the current residency, adapt the
target, or take the kernel-residency decision first (target 1 and 2.18).

## Context

Dispatch only after package 32 is accepted. Read `work/00-WORKER.md`,
`work/M10-REFERENCE.md` (decisions, budget, reuse table, host-side rules),
`docs/architecture.md` sections 35-37 (M10; "target 2.x" = 36.x, "target 3" = 37), `tools/zexpack.py`,
`tools/zexmanifest.py`, `user/sdk/zex.mk`,
`kernel/process/{exec,process,launch.asm}`, `kernel/memory/user_copy.asm`,
`kernel/syscall.c`, and `kernel/syscall/fs.c`.

The production configuration does not change in this package: production
keeps ZEX v1 and its bytes are identical to the package-32 image. All spike
code builds under one configuration (`ZOS_M10_SPIKE=1`, its own build
directory and its own acceptance image) so its cost can be measured against
the same production baseline. Code that proves to be the right design may
become the starting point of the implementation packages. Write it to
production quality, not as throwaway.

## Spike scope (each item real and measured)

1. **ZEX v2 container and `zexpack` v2 (host).**
   - A v2 format for the minimal case (primary segment only) and for
     auxiliary segments (code + data + BSS, one or more), with 32-bit file
     geometry.
   - The host-side precomputation in M10-REFERENCE: the up-front header
     feasibility fields; segments linked at `0000h`; relocations
     pre-encoded, sorted and delta-encoded; far entries pre-resolved; all
     container validation on the host.
   - **Determine from real SDCC output** whether every ABS16 relocation in an
     auxiliary segment can be a high-byte-only patch (segments on 8 KB slot
     boundaries, low byte base-independent). If any cannot, report which
     instruction or data form produces it and the minimal relocation set
     actually required.
   - `zex_program` gains a way to place a translation unit into an
     auxiliary segment and to declare its far entries. The SDK side of far
     calls is a generated near wrapper per far entry (target 2.13).
2. **Resident ZEX v2 loader** (in the spike configuration, replacing the
   v1 code path inside `process_prepare()`).
   - It reads descriptors and applies patches only.
   - It uses the existing kernel VFS file API (32-bit seek) and the
     `vfs_workspace` staging view, and writes segments through
     `zos_bank_copy`.
   - Its kernel-side checks are limited to the bounds that protect the
     kernel.
   - Rollback goes through the existing `process_prepare()` path.
   - **Measure the net change against the v1 loader it replaces** (the 30b
     audit estimated about 939 bytes of v1 code).
3. **Unified bank ownership + minimal xmem.**
   - Extend the existing bank map to FREE/PRIMARY(pid)/AUXILIARY with 8 KB
     slot ownership.
   - Implement `SYS_XMEM_ALLOC`, `SYS_XMEM_FREE`, `SYS_XMEM_READ` and
     `SYS_XMEM_WRITE`, with copies through `zos_bank_copy` and opaque
     handles.
   - Release everything at process exit through the existing exit path.
   - Measure `XMEM_INFO` and `SYS_ZEX_SEGMENT_INFO` by implementing them too,
     unless that is clearly trivial. In that case, implement one and report
     the other's estimated delta.
4. **`SYS_FAR_CALL` + auxiliary low window.**
   - One-deep far call (recursive calls return `ZOS_EBUSY`) **reusing the
     package-28 continuation stack** to preserve the caller's gate-stack
     frame across far code that issues syscalls.
   - The auxiliary low window: page zero and RST 30h vector reuse the
     existing page-zero construction; it holds the frame and the far stack.
   - Bounded in/out call frame, copied with `zos_bank_copy`.
   - Any new common code stays within the 512-byte M10 reservation.
5. **Execution-bank audit.** Determine whether the syscall entry and
   `zos_bank_copy` already copy from the **current execution bank** (saved
   latch) or from the process's primary bank. List every syscall family
   that copies user buffers and say what changes (if anything) when the
   caller is far code. Implement the minimal fix in the spike, and prove an
   ordinary syscall and an `FS_READ` from far code work in the simulator.

## Measurements and report

Write `docs/validation/<date>-m10-design-spike.md` with:

- **Per-mechanism resident cost:** kernel `_CODE`, kernel `_DATA` and common
  code/data, attributed per function and per object. Show the ZEX v1 code
  removed and the v2 code added (net).
- **The spike `bank7:`/`common:` ledger and granule-threshold table**
  compared with the production baseline, and the arena granules M10 would
  consume.
- **The gate-stack worst case** for `SYS_FAR_CALL`, for syscalls from far
  code, and for the v2 loader path.
- **The relocation finding** (high-byte-only or not), with evidence.
- **A projection to full M10** (the remaining target items the spike did
  not build, such as complete validation/error paths and acceptance-test
  hooks), with low/high ranges from the measured density.
- **A verdict and options:**
  - (a) full M10 fits in the 3 free granules and the common reservation;
  - (b) it fits only with named adaptations to the target (for example
    deferring `SYS_ZEX_SEGMENT_INFO`, limiting segments per program, or a
    smaller call frame), listed with their savings and their effect on the
    target's acceptance list;
  - (c) it needs the kernel-residency decision before M10 proceeds, with the
    size of the gap.
- **The proposed implementation package sequence** (ZEX v2 conversion of all
  programs and v1 deletion; xmem; far call; M10 acceptance), adjusted to
  the verdict.

## Constraints

- Production configuration unchanged: the production image hash is
  identical to package 32's. No ZEX v1 removal in production yet.
- No feature beyond the target, and no new resident mechanism where the
  reuse table names an existing one. A justified exception is reported, not
  silently added.
- Do not lower the arena floor, the common ceiling or the gate-stack limit,
  even in the spike configuration. If the spike does not fit, measure
  anyway and report by how much.

## Validation

At the efficiency defaults, run one formal batch:

```sh
make clean && make check                       # production unchanged
make m10-spike-selftest                        # spike image builds, ledger printed
python3 -m unittest tests.test_zex_v2 tests.test_m10_spike_sim -v
git diff --check
```

The spike image runs, in the simulator, a ZEX v2 program that:
- loads with two auxiliary segments (code+BSS, data);
- allocates, writes and reads xmem objects across a slot boundary;
- far-calls into both segments with an in/out frame;
- issues an ordinary syscall and an `FS_READ` from far code;
- gets `ZOS_EBUSY` from a recursive far call;
- exits from far code with full cleanup (bank map back to baseline).

Report:
- the spike ledger and the production ledger, side by side;
- the gate-stack worst cases;
- the formal run's wall-clock time;
- every skip in the listed suites, with its reason.

Hardware: optional. If the spike image is run on the board, record the
transcript, because bank switching and far-call return are hardware-
authoritative (target 3). Otherwise record `PENDING (spike)`.

## Acceptance criteria

- Every spike scope item works in the simulator, and its resident cost is
  measured and attributed.
- The report answers "how far can we push": a verdict (a), (b) or (c) with
  numbers, the relocation finding, the execution-bank audit result, and a
  proposed package sequence.
- The production image is unchanged.
