# Correction 03: the CTC's channel selects are swapped on the board

Runs after correction 02. Targeted validation, plus the owner's board run.

## Problem (found on the board)

With correction 02's timer-mode word the down-counter at port 42h runs,
but the driver's `timer_ticks` stays 0 (`DB 6 B726 4` → `00 00 00 00`):
the handler never runs.

The board wires the CTC's CS0 (pin 18) to A1 and CS1 (pin 19) to A0
(`../Zephyr-80/Code/HOST/CPM2.2/docs/ctc-and-real-time-programming.md`,
"Measured again on 2026-09-15" and "The BIOS resets the wrong channel").
So **port 41h is physical channel 2 and port 42h is physical channel 1**.
KonaOS programs port 42h (physical channel 1, vector 02h) and installed
the timer stub at vector 04h (physical channel 2): every tick vectors to
FD02h, the executive counts it as unexpected, and the handler never runs.
The CP/M BIOS fixed the same fault with a four-entry port table.

## Requirements

1. **Ports by physical channel.** In `platform/zephyr80/public/hardware.{h,inc}`
   name one port per physical channel: channel 0 `40h`, channel 1 `42h`,
   channel 2 `41h`, channel 3 `43h`, with a comment citing the wiring.
   Remove any `40h + n` arithmetic. Every CTC access goes through these
   names: the timer's boot and read paths, `platform_irq_quiesce`, the
   test CTC helper (`tests/target/support/ctc_test.c`), `irqx`, and any
   other user. The timer stays on **physical channel 2** (vector 04h,
   trigger 7.3728 MHz), so it now uses port `41h`; its constants and docs
   say "channel 2, port 41h".
2. **The model has the same wiring.** `tests/z80sim.py`'s CTC maps ports
   to physical channels with the swap, so a replay that programs the
   wrong port gets the wrong channel's vector. A host test pins the
   map, and one case shows that programming port 42h for the timer leaves
   the tick count at 0 (the board's symptom).
3. **Interrupt readout.** The board could not show why ticks were missing.
   Report the executive's counters (unexpected, unclaimed, last source)
   through the existing system-information
   diagnostic syscall, and print them in the monitor's `R` on one line.
   This is the smallest read-only addition; 54's `SYS_DIAG_ENUM` can
   absorb it later.
4. **Docs.** Architecture 2.x (hardware) and 4.5: the CTC port map, the
   timer on channel 2 at port 41h; `docs/devices.md` and `docs/monitor.md`
   (`R`).

## Tests

- The port-map pin and the wrong-port case (requirement 2).
- `tests.test_timer` replays pass with the model's swapped wiring.
- The monitor `R` line in its replay.

## Owner checklist (hardware)

1. `timer`: one line per second for 60 s, matching a stopwatch.
2. `hwtest`: `timer PASS`.
3. `timer card BIG.BIN` (card root, several hundred KiB): seconds match a
   stopwatch within 1 s.
4. Monitor `R`: the interrupt line shows `unexpected 0` after the above.

## Validation (targeted)

```sh
make
python3 -m unittest tests.test_timer tests.test_hwtest tests.test_hwtest_sim tests.test_monitor
make subsystem-selftest
make ipc-selftest
git diff --check
```

Record: a third addendum to `docs/validation/2026-10-13-m12-timer.md`.
