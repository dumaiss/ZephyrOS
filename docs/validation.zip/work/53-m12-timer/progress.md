# 53-m12-timer progress

## Done (analysis)
- Read WORK.md, 00-WORKER.md, architecture 4.5/5.2-5.6, irqx.c, ctc_test.c,
  Zephyr-80 CTC + clock docs, driver builds (sio/ioc), modpack/systemgen,
  replay.py/z80sim.py, hwtest (runner + tests + smoke), SDK layout.

## Key facts / decisions
- CTC2 vector byte = base(00h) + 2*2 = 04h. `kernel/irq/init.asm` installs
  only vector 00h today, so CTC2 delivery needs the 04h -> irq_ctc2_stub
  install (one line). Required by requirement 2; the constraint's "fixed
  core unchanged" cannot cover requirement 0's EI either. Flag in report.
- IOC masks interrupts across bulk reads (`ioc_io_irq_save_disable`/restore)
  - the masked-window measurement keys on `iff1 == 0` spans inside the ioc
  hot image range (from build/modules/ioc.report.json).
- The Z80 syscall gate masks interrupts for the whole call, so a driver-side
  read cannot be torn; the retry is still implemented as specified.
- T-state model: port the old per-instruction table (git 18beaf3:
  tests/test_ipc_selftest_sim.py ONE_BYTE_T/ED_T/DD_T + opcode_cost) into
  z80sim.py; add `Z80.tstates`; the CTC model counts CPU clocks (256 T per
  count at /256). This is what makes `now` real time in the simulator.
- Replay plan: `tests/test_timer.py` boots production (shell), types
  `timer stage`; CTC model attached via `z.ctc`; 10,000-read monotonic loop
  + 1 s wait inside `/system/timer.exe stage`; model delivery count compared
  with the program's ticks. Masked window measured on a `cat` of a 512+B
  card file (iocfat 512-byte cache read -> FS2 read + bulk lane).
- Add the driver to production.json and console-serial.json; console
  integration is retired in 56 (52's record), not touched.
- timer.exe source under tests/timer/ (store program like hwtest.exe).

## Progress
- [x] requirement 0: entry.asm EI + z80sim accept_interrupt IFF2
- [x] hardware.h/.inc CTC2 constants; ctc.c quiesce ch2; init.asm vector 04h
- [x] abi/kos/protocol.h TIMER class + ops
- [x] drivers/timer/* + Makefile rules + manifests
- [x] SDK kos/timer.h + src/timer.c + exe.mk + docs
- [x] tests/timer/timer.c program + stores (production, console-serial)
- [x] z80sim Ctc + tstates
- [x] hwtest timer stage + test updates (hwtest.py, hwtest_sim.py, smoke)
- [x] tests/test_timer.py (host + replay + masked window + interrupt cost)
- [x] docs (architecture, devices, sdk) + test pins
- [x] final validation batch + docs/validation record

## Findings while validating (reported in docs/validation/2026-10-13-m12-timer.md)
- Production boot hang with the CTC attached: not the timer.  The Z80 IM2
  gate saves 18 bytes at [irq_transition_stack_top-18, top) = FEEE..FEFF,
  and the boot-program / driver-loader chain lives at FEE9..FEFE - the
  reserve region (FE80..FF00) overlaps the boot's common stack.  Delivery
  #93 (t~20.6M, interrupted `_kos_bank_copy+29` at sp=FEED) clobbered live
  frames; the copy then ran with a garbage request struct.  Deep common
  stack use during boot is pre-existing (57k+ steps below FF00 at HEAD);
  the timer is only the first asynchronous source to expose it.
- Fix: transition stack moved to FE08..FE88 (state FE01..FE07 stays just
  below it, so an overrun can only reach the state cells), boot/common
  stack FE88..FFFF.  Platform headers/inc, entry.asm comment, mapcheck,
  pack_image, maptools fixture, docs architecture/boot/memory, banking
  comment.  Rebuilt; image bytes unchanged apart from reservation
  bookkeeping.  Confirmed in-sim both ways (patched operand FE88 boots).
- Driver: the syscall gate masks for the whole call, so a CTC rollover
  during `timer_counts_now` made `now` go backwards (stage printed
  `mono 10000 FAIL`, `now 118900`); the read now opens interrupts (`ei`)
  and masks again (`di`) for the arithmetic: the gate masked for the call
  and restores the caller's state, so "masked" is the state to hand back.
  First attempt saved IFF2 with `push af`/`pop af` around the loop - SDCC
  addresses temporaries from SP inside the loop (`ld hl,#6; add hl,sp`),
  so the shifted SP made every retry compare the wrong slot and the read
  spun forever (PC pinned inside `_timer_counts_now`).
- Tests: fixed a literal typo in the rate assertion, made `code_only()`
  collapse tabs, dropped the "IOC hot image" address probe (mode 11 P=0
  shows bank 7 cold half; kernel code spans dwarf the tick budget) for
  `MaskWindowProbe` (latch 0x38 + IOC-driver tagging) and report the
  longest IOC window, the longest operation window and the ticks lost to
  the CTC's single request latch instead of asserting a budget the model
  cannot settle.  `TimerSession.make_cpu` now fails a delivery that
  interrupts a common-memory sp in [E000h, IRQ top).
- More test work: delivery counts compare model and trace with the one
  in-flight delivery allowed for (the model counts an acceptance, the
  probe a `reti`); tick comparisons use deltas (an absolute count was
  compared against a delta and read as 290 unexplained ticks); the
  `mono`/`now` model gained the wrap sequence; the stage's 1 s advance is
  measured around the wait (the `mono` line's console work is ~24 ms of
  model time and landed in the bounded number); the `hwtest` no-card
  summary pin is now 4/4.

## Rejected
- Adding the timer to console-integration.json: that image is retired in 56
  (known not to fit its cold half); production + console-serial are the two
  console builds the owner runs.

## Validation (2026-10-13)
- `make`: mapcheck OK (18 areas, 366 symbols), fixed core end 3D48h,
  image sha256 4d0aa750...
- `tests.test_timer` 10 tests OK (advance 39249 counts; interrupt mean
  1343.1 T, share 2.10 %; 55 masked windows, longest IOC 351961819 T
  in-model, 11088 swallowed expiries); `tests.test_hwtest_sim` OK (4/4);
  `tests.test_hwtest` + `tests.test_shell_sim` OK; console acceptance OK.
- `make ipc-selftest` 40 tests OK; `make subsystem-selftest` 4 + 26 OK;
  `git diff --check` clean.
- Record: docs/validation/2026-10-13-m12-timer.md.  Not committed (as
  instructed).

## Correction 01 (syscall bodies run with interrupts enabled)
- Gate: `kernel/syscall/entry.asm` restores the caller's IFF2 for the body
  (after the stack switch and OS-mode selection, before the dispatcher)
  and masks again after the dispatch before writing the result cells.
- Audit (reported in the record's addendum): registry mutations are inside
  `irq_arch_lock`; the delivery's reads are single-instruction; the only
  production handler is the timer's, so only `timer_ticks` (read with the
  retry) is shared; the window/latch is the trampoline's save/restore; no
  new masking or lock was needed.
- `timer.exe card F`: 512-byte copy to `/fs/TIMERTMP.BIN`, delete, print
  `timer: card <counts> counts <s>.<t> s` (no 32-bit mul/div runtime).
- `tests/test_timer.py`: the probe records start PC + the IOC address
  range per window; `CountsProbe` brackets the program's readings; the
  guard knows the three declared common stacks (the gate stack is where
  bodies run now); `body_deliveries` counts deliveries inside a body
  (1,131 in `timer stage`, 200 in the 64 KiB copy, 6 in the small cat) -
  zero before the correction, so it is the regression guard.
- Measurements: interrupt cost unchanged 1,343.1 T (303/674/103/263),
  2.10 %; the longest masked window is the IOC bulk section
  (`ioc_io_irq_save_disable+3 .. ioc_io_bulk_write+314`), 351,566,743 T
  (35,156.7 ms) in the model, over budget -> reported with the code range
  (the hardware lane rate is the MCU's, External Sync x1); the clock's
  accounting is exact (printed = model - 250 x swallowed expiries, within
  two ticks: 398,836 counts vs 351,861,335 and 1,405,850 lost for 64 KiB).
- Docs: architecture 4.3/4.4/4.5 (cost 1,343 T, not 924), abi.md 2/3,
  devices.md 9, the program list in 7.4.
- Record: addendum in docs/validation/2026-10-13-m12-timer.md.

- Validation batch: `make clean && make check` green (731 tests, 114
  skipped, reproducible rebuild 7da60344...), `make ipc-selftest`,
  `make subsystem-selftest`, `make fs-selftest`, `git diff --check` all
  pass.
- Batch reds fixed: the SDK header's `abi/` mention (it hid the whole
  `test_sdk_package` class); the driver order (`timer` now loads before
  `iocfat`, as the FS-provider contract requires) with every order pin
  and the architecture 8.1 example; the two `test_sdk_package` rows that
  drove the monitor - they boot the shell now.
- Pre-existing drift fixed to let the batch pass (red at HEAD b343a70;
  revert if the shell package should own it): the `VFS_WS_IN_A` pin in
  test_ns_selftest, the store pins in test_hid/test_v9958.
- Reported, not fixed: a clean *parallel* build can flake with a phase
  error in bank7_end.asm - Makefile 346's two-target rule makes
  `mapcheck.py geometry derive` run twice and it rewrites both generated
  files unconditionally, racing the assembler.  One occurrence, four
  clean builds and the batch after it.

## Correction 02 (channel 2 is in counter mode on the board)
- Control word: `KOS_CTC2_CONTROL_TIMER` is composed from one
  `KOS_CTC_CTRL_*` constant per bit - interrupt enable, timer mode (D6
  clear), prescaler 256, falling edge, automatic trigger, time constant
  follows, control-word flag - so it is `A5h` now; `KOS_CTC_RESET` and
  the CTC0 test word are composed the same way and keep their values
  (`03h`, `A7h`).  No doc quoted the old value.
- Model (`tests/z80sim.py`): `Ctc` counts both modes.  Timer mode counts
  the CPU clock through the 16/256 prescaler; counter mode counts the
  channel's CLK/TRG input (1.8432/3.6864/7.3728/7.3728 MHz, on the
  T-state clock), the prescaler being a CPU-clock divider only; constant
  0 means 256.  `E5h` + 250 now reproduces the board's 29,491
  interrupts/s (189x), `A5h` + 250 stays 156.25 Hz, so the defect word is
  a host-test failure instead of a passing replay.
- `timer_counts_now` keeps the caller's interrupt state:
  `drivers/timer/timer_io.asm` (`timer_irq_save_enable`/`restore`, the
  `LD A,I` token), its Makefile rule and the manifest object; the
  tick/counter/tick retry is unchanged and the function keeps no inline
  `ei`/`di`.
- `timer_wait_us` returns a status: 0, the reading's error, or
  `-KOS_ETIMEDOUT` when a tick (250 counts) has not arrived within
  100,000 consecutive readings.  `timer.exe` (stopwatch run and stage)
  and `hwtest` report `FAIL wait <code>` instead of hanging.
- `hwtest`'s timer stage adds the rate probe: 32,000 iterations of the
  busy loop = 998,705 T-states (99.9 ms); the clock's advance must stay
  within a factor of two of 3,906 counts or the row is `FAIL rate
  <counts>`.  The loop reads no clock itself, and the card replay
  measures it against `TIMER_RATE_TSTATES` within 10 %.
- `tests/maptools.py`'s C-header parser joins `\`-continued `#define`s,
  so the host tools read the composed constants the compiler reads.
- Tests: the control word is pinned bit by bit (and its two rates), the
  model's modes are pinned as rates, the read's save/restore and the
  token helpers are pinned, the bounded wait has frozen/slow cases, and
  the stage's bounds and calibration are pinned.
- Batch: `make` OK; 69 tests OK (1 pre-existing skip: the helloworld
  image is not built); `make subsystem-selftest` OK; `make ipc-selftest`
  OK; `git diff --check` clean.  Replay: `advance 39,240` counts (bound
  39,062..39,312), interrupt 1,343.1 T = 2.10 %, card 399,044 printed
  counts against the model's 351,861,543 with 1,405,850 swallowed.
- Record: second addendum in `docs/validation/2026-10-13-m12-timer.md`.
  Nothing committed (as instructed).

## Correction 03 (the CTC's channel selects are swapped)
- Ports: `hardware.{h,inc}` now name one port per *physical* channel with
  the board's crossed wiring cited (CS0=A1, CS1=A0): ch0 40h, ch1 42h,
  ch2 41h, ch3 43h.  The timer is channel 2, so it programs 41h and
  vectors 04h; `platform_irq_quiesce` writes the port the interrupt
  vectors for; no code computes a port from a channel number.
- Model (`tests/z80sim.py`): ports map to physical channels with the
  swap (`Ctc.PORTS`, `channel_of_port`), so programming 42h for the timer
  arms channel 1 (vector 02h) and leaves channel 2 at zero expiries -
  the board's symptom, now a host case.
- Interrupt readout: `SYS_DIAG_SYSTEM_INFO`'s record grew 8 -> 13 bytes
  (unexpected, unclaimed, last source); the copy is a fixed-core helper
  (`irq_diag_counters`, masked snapshot) so the cold-half body only calls
  it, the SDK wrapper and the monitor followed, and `R` prints
  `irq: unexpected 0000 unclaimed 0000 last 07`.
- Docs: architecture 2.5 (the port map + trigger rates) and 4.5 (the
  counters' reporting), devices 9, monitor's `R`.
- Tests: the port map is pinned against the header and the model, the
  wrong-port case, the 13-byte record + offsets, the monitor identity,
  the `R` line in both console replays, and the nucleus selftest's
  platform-bytes comparison.
- Batch: `make` OK; 74 tests OK (the four modules); 87 tests OK with the
  console replays and the nucleus selftest added (2 skips: images not
  built); subsystem-selftest OK; ipc-selftest OK; git diff --check clean.
- Fallout fixed: test_console_serial's stale console-serial pins (the
  timer, `7 images in bank 6`) and `systems/console-serial-missing.json`'s
  driver list.
- Reported, pre-existing: `make console-integration-selftest` does not
  build at HEAD either (cold code ends D87Ch with 1871 data bytes; the
  512-byte data granule has no room) - the integration class of
  test_console_acceptance skips while the image is absent.
- Record: third addendum in `docs/validation/2026-10-13-m12-timer.md`.
  Nothing committed (as instructed).
