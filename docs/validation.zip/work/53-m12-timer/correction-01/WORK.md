# Correction 01: syscall bodies run with interrupts enabled

Runs after 53, before 53b. Nucleus change: full check at the end.

## Problem

The syscall gate (`kernel/syscall/entry.asm`) executes `DI` on entry and
restores the caller's interrupt state only on return. Every `EI` inside
the nucleus (`window_copy`, `user_copy`, `rom_access`, the IOC driver's
reply wait) is a conditional restore of the state it found, which inside
a syscall is "off". So **every syscall body runs masked**.

With the timer that is wrong in two ways:
- the CTC holds one pending request, so a syscall longer than two ticks
  (12.8 ms) loses ticks and `now` lags: a card write, an SD read with
  controller latency, a long console write;
- a benchmark that times one call (the 55 diagnostics) measures a call
  that loses its own ticks: a 100 ms write can report under 13 ms.

53's masked-window probe saw this as one 35 s window over a whole `cat`.

## Requirements

1. **Gate.** After the gate has switched to its stack and selected OS
   mode over the caller bank, and before the dispatcher runs, restore the
   caller's saved interrupt state (`kos_gate_saved_iff`): `EI` when it was
   1. The exit path masks again before it touches the gate's saved state
   and restores the caller state as today.
   - The entry sequence up to that point stays masked (it writes common
     gate state and switches SP and the latch).
   - Check every piece of nucleus state a syscall body touches that an
     interrupt handler also touches (the IRQ registry, `event`-style
     counters, the driver window). Handlers never call IPC or syscalls;
     confirm no shared state needs a new lock, and list what you checked.
2. **Masked sections stay explicit.** Code that must not be interrupted
   already masks and restores (the copy primitives, ROM access, the IOC
   frame exchange). Do not add masking elsewhere unless requirement 1's
   check finds a real race; report each one.
3. **Measure.** Re-run 53's masked-window probe over `cat` of a large card
   file: report the longest window and where it is (expected: the IOC
   frame exchange and bulk receive, milliseconds). Over 12.8 ms in the
   model → report it with the code range; the owner decides.
4. **Timing check.** `timer.exe` gains a `card` mode: copy a file given on
   the tail to `/fs/TIMERTMP.BIN` in 512-byte calls, delete it, and print
   the elapsed seconds from `now`. The owner compares it with a stopwatch
   on a large file (the check that catches lost ticks).
5. **Docs.** Architecture 4.3/4.4 (the gate) and 4.5: syscall bodies run
   with the caller's interrupt state; masking is explicit and bounded.
   4.5's delivery cost: the measured 1,343 T (gate 303, dispatch and
   trampoline 674, handler 103, return 263), not 924.

## Tests

- The timer replay's monotonic run and rate check still pass; add one
  replay row: `timer card` over a card file of at least 64 KiB, where the
  `now` elapsed matches the model's clock within 2 ticks.
- `tests/test_timer.py`'s stack check stays on for every replay.

## Owner checklist (hardware)

1. `timer card /BIG.BIN` with a file of several hundred KiB: the printed
   seconds match a stopwatch within 1 s.
2. `hwtest` with a card: PASS, every stage.

## Validation (once, at the end)

```sh
make clean && make check
make ipc-selftest
make subsystem-selftest
make fs-selftest
git diff --check
```

Record: an addendum to `docs/validation/2026-10-13-m12-timer.md`.
