> **DRAFT. Not dispatched.** Runs after 52, as the first package of M12.
> The diagnostics (54, 55) time everything with it.

# Task

A real **TIMER driver** on the CTC: a resident bank-6 driver that
publishes `/dev/timer` (type `KOS_TYPE_TIMER`, 10). It gives programs a
monotonic clock, so that the diagnostics can benchmark the SD card, the
IOC bulk lane and the IOC command lane. It is in production and in both
console builds.

Read:
- `work/00-WORKER.md`;
- the architecture's resident-driver and IRQ sections;
- `tests/target/ipc/irqx.c`: a driver claiming CTC interrupts through the
  bootstrap API (`irq_claim`), already proven on hardware;
- `tests/target/support/ctc_test.c`;
- the Zephyr-80 `Z80 Peripherals Controller.md` and `Clock
  Architecture.md`.

## Requirements

0. **Prerequisite fix: re-enable interrupts on IRQ exit.** Accepting a
   maskable interrupt resets **both** IFF1 and IFF2 on the Z80, and `RETI`
   does not set them again. The executive's exit
   (`kernel/irq/entry.asm`, `pop af` / `reti`) has no `EI`, so on hardware
   interrupts stay off after the first one until something executes an
   unconditional `EI` (today only the process launch). Fix both halves:
   - the exit becomes `pop af` / `ei` / `reti` (EI takes effect after
     RETI, so no nesting);
   - `tests/z80sim.py` `accept_interrupt` resets IFF2 as well as IFF1
     (today it models an NMI, which hid the bug in every replay).

   Then the existing interrupt replays (`subsystem-selftest`,
   `ipc-selftest`) must still pass; a replay that only passed through the
   old model is a finding, report it. The timer tests below prove the
   steady stream (10,000 reads with interrupts between them).

1. **Driver** `drivers/timer/` (`timer.c`, `timer_proto.c`,
   `timer.json`), built like the other drivers, with host-resolved
   endpoints.
   - Its boot segment programs the CTC.
   - The tick handler and the protocol live in the hot tier.
2. **Hardware (pinned):**
   - Channel 2 (port 42h); logical source `IRQ_CTC2`.
   - Timer mode, prescaler 256, time constant 250, interrupt enabled:
     10 MHz / 256 / 250 = **156.25 Hz** (a 6.4 ms tick).
   - Write the CTC vector base (`KOS_CTC0_VECTOR_BASE`, through port 40h,
     D0 = 0) before enabling. This does not change channel 0's mode,
     which stays free for the SIO0/A baud clock.
   - Add the channel-2 constants to `platform/zephyr80/public/
     hardware.h`.
   - The handler only increments a u32 tick count.
   - The platform quiesce (`kernel/irq/ctc.c`) also stops channel 2.
   - Leave channel 3 alone: 53b adds the event timer there.
3. **Unit: 1 count = 256 CPU clocks = 25.6 µs** (39,062.5 counts per
   second).
   - `now` = ticks × 250 + (250 − the channel-2 down-counter, read from
     port 42h).
   - Read ticks, then the counter, then ticks again; retry if the ticks
     changed. This makes `now` monotonic.
   - It wraps after about 30.5 hours. Elapsed values use unsigned
     subtraction.
4. **Protocol** (`abi/kos/protocol.h`, the TIMER class), descriptor-less:
   - `KTIMER_OP_NOW` 0: the reply's 32-bit `now`;
   - `KTIMER_OP_INFO` 1: the reply holds counts per 10 s (390,625) and
     counts per tick (250).
5. **SDK** `kos/timer.h`:
   - `int timer_open(void)` (binds `/dev/timer`, returns the handle or
     -errno);
   - `int timer_now(int h, uint32_t *now)`;
   - `uint32_t timer_us(uint32_t counts)` = counts × 25 + counts × 3 / 5
     (25.6 µs without overflow). It is valid for elapsed times up to 71
     minutes;
   - `void timer_wait_us(int h, uint32_t us)`, polling `now`.
6. **Composition.** Add the driver to the production manifest and to both
   console builds. Report the driver hot tier and boot tier before and
   after.
7. **Interrupt cost.**
   - Measure in the simulator the T-states per tick: the gate, the
     trampoline, the handler and the return. Report it, and the CPU share
     at 156.25 Hz (expected around 1%).
   - With the timer running, every IOC transfer must stay correct. The
     IOC lanes are polled, and an interrupt only delays a poll.
   - The production `hwtest` card replay (`tests.test_hwtest_sim`) passes with
     the timer on. That covers IOC transfers under timer interrupts.
   - **Masked windows:** the IOC driver masks interrupts across a frame
     exchange and a bulk receive (`drivers/ioc/ioc_io.asm`). The CTC holds
     one pending interrupt, so a masked window longer than **two ticks
     (12.8 ms)** loses a tick.
     - Measure the longest masked window (a 512-byte bulk read) in the
       simulator, and report it.
     - Over 12.8 ms → stop and report; the tick or the masking must
       change.
     - Below that, timing is exact, because `now` also reads the
       down-counter.

## Tests

- **Host:**
  - the `now` composition, including the retry case and the wrap;
  - `timer_us`;
  - the manifest and endpoint resolution.
- **Simulator replay:**
  - over 1 s of simulated clocks, `now` advances 39,062 ± 250;
  - `now` is monotonic over 10,000 reads with interrupts arriving between
    them;
  - the `IRQ_CTC2` delivery count matches the ticks.
- `hwtest` gains a `timer` stage: bind `/dev/timer`, check the INFO
  values, and check that `now` advances over 100 ms of
  `timer_wait_us`.

## Owner checklist (hardware)

1. Production boots; `hwtest` shows `timer` PASS.
2. At the shell, `timer` runs a tiny `/system/timer.exe` test program that
   prints elapsed seconds every second, for 60 s. Compare it with a
   stopwatch; it must be within 1 s.
3. Run `hwtest` and the file commands with a card: no IOC errors.

## Constraints

- Nucleus: only the quiesce addition (channel 2). The fixed core is
  unchanged otherwise. Record every ledger and the production hash.
- Record: `docs/validation/<date>-m12-timer.md`.

## Validation (targeted: no `make clean && make check`)

Put the tests in `tests/test_timer.py` (host and replay). Use these same commands while developing,
and once at the end:

```sh
make                                              # production builds: store fits, mapcheck passes
python3 -m unittest tests.test_timer tests.test_hwtest_sim   # IOC transfers with the timer running
python3 -m unittest tests.test_console_acceptance # production still boots
make ipc-selftest                                 # requirement 0: IRQ replays (irqx)
make subsystem-selftest                           # requirement 0: IRQ group
git diff --check
```

Known, not yours: `make subsystem-selftest` ends in `test_romfs_sim`
failures (`scratch E000 does not fit the window`, a 49d test issue fixed
in 56). `test_subsys_sim` in the same target must pass.
