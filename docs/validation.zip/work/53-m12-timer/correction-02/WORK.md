# Correction 02: channel 2 is in counter mode on the board

Runs after correction 01, before 53b. Targeted validation, plus the
owner's board run.

## Problem (found on the board)

`timer` printed `1 s` to `16 s` in a burst, then the machine hung.
`KOS_CTC2_CONTROL_TIMER` is `0xE5` = `1110 0101`: **D6 = 1 selects
counter mode**. Channel 2 then counts its CLK/TRG input, which the
Zephyr-80 drives at 7.3728 MHz (`../Zephyr-80/Z80 Peripherals
Controller.md`, CTC trigger table), not the 10 MHz clock / 256. With the
constant 250 that is ~29,491 interrupts/s instead of 156.25: the clock
runs 189x fast, and at 1,343 T per delivery the CPU livelocks in the
handler. The simulator's CTC model ignores D6, so no replay saw it.

## Requirements

1. **Control word** `0xA5` = interrupt enable, **timer mode**, prescaler
   256, falling edge, automatic trigger, constant follows, control word.
   Spell the bits out in `hardware.h` (one named constant per bit,
   composed), and fix any doc that quotes the old value.
2. **The model honours the mode.** `tests/z80sim.py`'s CTC: timer mode
   counts CPU clocks through the prescaler (16 or 256, D5); counter mode
   counts its CLK/TRG input at the board's rates (channel 0 1.8432 MHz,
   1 3.6864 MHz, 2 and 3 7.3728 MHz, converted to T-states at 10 MHz);
   the time constant `0` means 256. A host test feeds `0xE5` to the
   model and checks it now interrupts at ~29.5 kHz, and `0xA5` at
   156.25 Hz: the mistake can no longer pass a replay.
3. **A host test pins the control word's decoded bits** against the
   architecture's timer contract (timer mode, prescaler 256, IE).
4. **`timer_counts_now` keeps the caller's interrupt state.** Since
   correction 01 a syscall body runs with the caller's state; the
   unconditional `ei` / `di` (and its comment) are wrong now. Save the
   state, open for the tick/counter/tick read as today, restore the saved
   state after. The retry stays.
5. **Bounded waits.** `timer_wait_us` returns a status: `0`, or
   `-KOS_ETIMEDOUT` when `now` has not advanced by one tick (250 counts)
   over 100,000 consecutive readings (a dead or frozen clock), or the
   `timer_now` error. `kos/timer.h` and `docs/sdk.md` say so. `hwtest`'s
   timer stage and `timer.exe` report `FAIL` with the reason instead of
   hanging. A host case covers the frozen-clock return.
6. **Rate sanity in `hwtest`'s timer stage**: also compare `now` against a
   CPU busy loop of known length (calibrated in T-states, about 100 ms):
   a clock more than 2x off either way is `FAIL rate`. This catches a
   wrong control word on the board even when the model is right.

## Tests

- The new model cases (requirement 2) and the control-word pin.
- `tests.test_timer` replays pass unchanged in rate (39,062 ± 250 counts
  per second) with the model honouring the mode.
- The frozen-clock case of `timer_wait_us`.

## Owner checklist (hardware)

1. `timer`: one line per second for 60 s, matching a stopwatch within 1 s;
   no hang.
2. `hwtest`: `timer PASS`.
3. `timer card BIG.BIN` (from the card root) with a file of several
   hundred KiB: the printed seconds match a stopwatch within 1 s.

## Validation (targeted)

```sh
make
python3 -m unittest tests.test_timer tests.test_hwtest tests.test_hwtest_sim tests.test_sdk
make subsystem-selftest              # the model change touches every IRQ replay
make ipc-selftest
git diff --check
```

Record: a second addendum to `docs/validation/2026-10-13-m12-timer.md`.
