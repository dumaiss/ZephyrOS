> Worker package. After 90. The portable KRES core, its host build,
> host tests and the host tool. No KonaOS adapter yet (package 92), no
> client (editor, KonaM2).

# Task

Implement KRES format v1 and its portable C core exactly as
`docs/kres-sdk-design.md` specifies, plus the host tool and a host test
suite. The core must also compile for the Z80 (SDCC), because package
92 links the same sources into the SDK.

## Current state

- **The design** is `docs/kres-sdk-design.md`: format §4, mutation §5,
  API §6, compaction §7, sealed containers §8, host utilities §9.2,
  verify §10, tests §11. It is the specification; where this package
  and the design disagree, stop and ask.
- **Host-side C pattern:** `UserSoftware/PView/tests/test_kimg.c` (a
  host test built with `cc -std=c99 -Wall -Wextra -Werror` from target
  sources) and the `make -C UserSoftware/PView test` target.
- **SDK layout:** optional libraries live under `user/sdk/<lib>/src/`
  with a public header in `user/sdk/include/kos/` (`libgfx`, `libtui`).
  The SDK archive rules are in `user/sdk/exe.mk`.
- **SDCC costs:** 32-bit arithmetic costs several times the code of
  16-bit (`docs/kres-sdk-design.md` §6.2). Record numbers are 16-bit in
  the core; 32-bit appears only for `used_bytes`, seek and resize.

Read: `work/00-WORKER.md`; `docs/kres-sdk-design.md` (whole);
`docs/sdk.md` (library layout); `user/sdk/exe.mk`.

## Requirements

1. **Sources** (Must):
   - the core in `user/sdk/kres/src/`;
   - the public header `user/sdk/include/kos/kres.h` (the API of design
     §6, with exact signatures; constants for the errors, `KRES_TIGHT`,
     `KRES_SEAL`);
   - a private header holding the on-disk layout. Parse and emit the
     format byte by byte (no struct overlay); `_Static_assert` the field
     offsets in the header.
2. **Adapter boundary** (Must). The core reaches storage only through
   `struct kres_io` (design §6.3), extended with open, close, rename,
   unlink and size. The catalog cache goes through a small cache
   interface (load, get entry, put entry, store): the host backs it with
   memory, package 92 with XMEM.
3. **Format** (Must):
   - header, two catalog areas of 4 records, 64-byte entries, names of
     1-48 bytes;
   - `next_record` allocation;
   - the commit order (§5.6);
   - sealed containers: the flag, one area, record-aligned tight
     resources;
   - the 32-resource limit and the 65,535-record limit, each a defined
     error.
4. **Operations** (Must):
   - every call in design §6;
   - the sealed builder;
   - compaction by rebuild and rename (§7.1, with `KRES_TIGHT` and
     `KRES_SEAL`), with no in-place variant;
   - `kres_extract`;
   - verify (§10).

   Descriptors and iterators are invalid after close; compaction
   refuses while any resource is open.
5. **Host tool** (Must). `tools/kres/`: `main.c` over the same core
   sources with a stdio adapter, built by `make kres-host` into
   `build/host/kres`. It implements the commands of design §9.2:
   - names are CP850 bytes, payloads byte for byte;
   - export refuses unsafe paths and case-insensitive collisions.
6. **Z80 build check** (Must): every core source compiles with the SDK's
   SDCC flags, with no warning. Report each source's code size.
7. **Docs** (Must):
   - `docs/sdk.md`: KRES (what it is, the API summary, the host tool);
   - the design keeps its status line, the format becoming v1 when 92
     passes.

## Tests

`tests/kres/` host C tests run by `tests/test_kres.py` (which builds them
with `cc`), on an instrumented in-memory adapter:

- **The §11 table, every row:**
  - create, open and list;
  - names;
  - independent cursors on one handle (the adapter counts opens);
  - contiguous allocation;
  - update in capacity;
  - growth at `next_record`;
  - resize;
  - delete and rename;
  - catalog full at 33;
  - buffered I/O across records;
  - verify refusals;
  - compaction policies;
  - sealed: build, seal, mutations refused.
- **Commit order:** fail the adapter at every write of a flush in turn,
  reopen, and find the previous committed catalog each time.
- **Fault injection:** short read/write, failed seek/sync. Every call
  returns an error, never crashes, never writes outside its extent.
- **Random mutation:** 10,000 random operations against an in-memory
  oracle (name to bytes), with a verify and an oracle comparison every
  100.
- **Golden fixtures:** committed small containers in
  `tests/kres/fixtures/` (one mutable, one sealed). The tool's `list`,
  `verify` and `extract` on them are pinned, and the header and first
  catalog record bytes are pinned against design §4.
- **Tool round trip:** `pack` a directory, `unpack` it, compare byte for
  byte. Unsafe names are refused on `unpack`.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| core code (SDCC, all members) | - | report per source | report |
| core BSS/stack (SDCC) | - | shared buffer <= 512 B; no per-resource buffer | stop and report |

## Criteria

- **Must:** requirements 1-7; the tests pass; the SDCC build is clean.
- **Should:** the code sizes. Design §6.2 asks for 16-bit record
  arithmetic; record where 32-bit operations remain and why.
- **Informational:** the tool's command list, the fixture sizes.

## Validation

Develop with the host tests (`python3 -m unittest tests.test_kres`, under
a second). Run the block once, at the end.

```sh
make kres-host
python3 -m unittest tests.test_kres tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-kres-core.md`.
