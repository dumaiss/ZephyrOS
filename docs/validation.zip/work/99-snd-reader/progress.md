# 99-snd-reader progress (present tense)

- Package 99 is complete: all 8 tests in tests/test_reader.py pass
  (fixtures, the host fake-reader test, the card run, the FS2 open
  count, the link proofs and the timing report).

- Shipped:
  - kos/reader.h: kos_reader_t {context, read_at, size}, the caller-
    owned kos_handle_source_t/kos_memory_source_t descriptors, the
    four constructors and kos_reader_read_full (retries short reads,
    -KOS_EIO at an early end).
  - libkos members reader.c (memory), reader_full.c, reader_handle.c
    (seek + read, size from a seek to the end), reader_stdio.c
    (fseek/fread, size from ftell).
  - libkres member kres_reader.c (kres_seek/kres_read, size =
    used_bytes), so the KRES adapter links only with LIBS=kres.
- Linking: readermap (the memory adapter alone) carries
  _kos_reader_from_memory and none of the other adapters, fs, stdio
  or KRES symbols; readertest carries all four.
- The FS2 provider serves two open files, so readertest runs in two
  phases (handle+stdio+memory, then KRES); the open-count test pins
  exactly the exe, two CARD.DAT opens and one READER.KPR open.
- Measured (report rows): adapter members 150h/15Ch/C8h/C1h/98h bytes
  of CODE; read_at per call handle 38,942, stdio 156,048, kres
  45,251, memory 2,640 T-states (framed, empty-loop baseline
  subtracted).
- Next: package 100-snd-zvg (snd_zvg_* over kos/reader.h, the
  VGMPlayer rework, zvgtest + test_zvg.py).
