> Worker package. After 98. `docs/snd-sdk.md` section 3.4, SND-2: the
> shared read-at reader and its adapters over OS handles, `FILE *`, KRES
> resources and RAM. libkos (not libsnd), so libgfx can use it later.
> Setup and foreground code, in C. No OS change.

# Task

`kos/reader.h`, with `kos_reader_t {context, read_at, size}`, and one
small adapter member per source:

- `kos_reader_from_handle`
- `kos_reader_from_stdio`
- `kos_reader_from_kres`
- `kos_reader_from_memory`

Every read is absolute, and every adapter borrows its source.

## Current state

- **No equivalent exists:** there is no read-at abstraction in
  `user/sdk/include/kos/` (checked: `stream.h` is the stream planner,
  `fs.h` the handle API). The KRES resource API is `kres_seek`/
  `kres_read` (`kos/kres.h`).
- **libkos members** live in `user/sdk/src/` and are listed in
  `user/sdk/exe.mk` `KOS_SDK_C_SRC`. A program links only the members it
  references.
- **KRES** is its own archive (`LIBS=kres`). The KRES adapter must live
  where linking it pulls libkres, but a program that never calls it must
  not: put it in libkres as a member (`kres_reader.c`), with the
  declaration in `kos/reader.h`.

Read: `work/00-WORKER.md`; `docs/snd-sdk.md` 3.3-3.4;
`kos/fs.h`, `klibc/stdio.h`, `kos/kres.h`; `user/sdk/exe.mk`.

## Requirements

1. **The contract** (Must). `kos/reader.h` exactly as section 3.4:
   - `read_at(context, offset, dst, requested)` returns 0 to `requested`
     bytes, 0 at the end, or a negative error. A short read is legal;
   - `size` is the exact logical length, captured at construction from
     the source's own metadata;
   - no adapter closes its source, and none adds a buffer:
     - handle: `seek` then `read`;
     - stdio: `fseek`/`fread` (the stream's own buffer);
     - KRES: `kres_seek`/`kres_read` on the borrowed resource (the
       container's one handle);
     - memory: bounds check and `memcpy`.
2. **The helper** (Must). `kos_reader_read_full(reader, offset, dst,
   length)` retries short reads until the range is complete. It returns
   the length, a negative error, or `-KOS_EIO` at an early end. It lives
   in its own member, used by libsnd.
3. **Linking** (Must). Including `kos/reader.h` links nothing; each
   adapter pulls only its own source library. Check it with a test
   program's map, for the memory adapter alone.
4. **Docs** (Must): `docs/sdk.md` (the reader, the adapters, ownership).
   `docs/snd-sdk.md` 3.4 drops "proposed".

## Tests

- **Host:** the memory adapter and `read_full`, against a fake reader
  that returns short chunks, transient errors and an early end.
- **Target:** `tests/reader/readertest.c` on the production image
  (simulator, card):
  - the same fixture through all four adapters, with random offsets and
    lengths, the end, and past the end;
  - the bytes are identical everywhere;
  - KRES opens no second file (the FS2 open count);
  - none closes its source (the source works after the reader is
    dropped).

## Budgets

| figure | measured | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | met |
| adapter member sizes | memory 150h, read_full 15Ch, handle C8h, stdio C1h, kres 98h bytes of CODE | report only | reported |
| read_at overhead per call, each adapter (T-states) | handle 38,942; stdio 156,048; kres 45,251; memory 2,640 | report | reported (framed, empty-loop baseline subtracted; the file-backed numbers are dominated by the provider round trips) |

## Owner checklist

- On the board: `readertest` prints matching checksums for the four
  adapters over a card fixture.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_reader tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-reader.md`.
