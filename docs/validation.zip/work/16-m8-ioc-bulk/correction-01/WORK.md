# Correction 01 — Disambiguate READY and make acceptance evidence truthful

## Outcome

Package 16 is not yet accepted. Correct the false-READY admission described
below, tighten the hardware PENDING result so it cannot be reported as a pass,
then repeat the complete package validation and physical gate. Do not modify
the IO Controller firmware or any file in the Zephyr-80 repository.

## Findings to correct

### 1. A successful non-bulk reply can be admitted as READY

`drivers/ioc/ioc.c` currently attempts READY admission for every successful
eight-byte reply. The byte-shape checks are necessary but not sufficient
because READY has no independent tag in the frozen protocol.

The immutable controller has successful non-bulk replies of the same length:

- diagnostic `CMD_PROFILE` page `IOC_PROFILE_PAGE_BULK_TX` has an eight-byte
  payload;
- `CMD_HID_INPUT` has a variable `2 + count` payload and therefore has an
  eight-byte reply when six translated bytes are returned.

There is a deterministic HID collision. If the caller requests six bytes while
seven are queued, the controller returns `queued=1`, `dropped=0`, then the six
bytes. If the first two returned bytes are `41h,01h`, the current IOC driver
interprets the payload prefix as transfer id 1, read direction, length 321 and
enters `IOC_PHASE_ADMITTED`, although the controller armed no bulk transfer.
The next ordinary command is then rejected as busy.

Gate READY recognition by both the verified byte shape and a request class
which the pinned firmware can actually use to arm the bulk lane. Keep these
protocol details private to `drivers/ioc/`. The complete frozen set is:

```text
04h CMD_BULK_TEST          diagnostic profile only
05h CMD_SD_READ_BULK       diagnostic profile only
07h CMD_SD_WRITE_BULK      diagnostic profile only
08h CMD_SD_READ_REC
09h CMD_SD_WRITE_REC
0Fh CMD_SD_READ_BLOCK
23h CMD_FS_READ
24h CMD_FS_WRITE
36h CMD_FS2_READ
3Eh CMD_FS2_WRITE
```

Do not weaken the existing status, length, id, direction, response-type or
sequence checks. A successful non-bulk eight-byte response must be returned to
its caller normally while the IOC remains idle; a following command must work,
and a following bulk call must fail before touching either lane. Real READY
responses from every supported production class must continue to admit the
correct phase. The diagnostic classes may remain supported even though M8
acceptance must not invoke their destructive/raw paths.

Add simulator/host regressions for at least:

- the exact `CMD_HID_INPUT` collision above;
- an eight-byte non-bulk response whose prefix otherwise satisfies every
  current READY shape check;
- each production bulk-producing command class, including both directions;
- a malformed/failed response from a bulk-producing command, which must not
  admit a phase.

### 2. The hardware PENDING path currently hides failures and exits success

The target fixture treats every nonzero `RSP_FS_OPEN` status as proof that the
firmware lacks writable `/SHARED` commands. Those statuses also report real
media, mount, name and filesystem failures. Conversely, firmware which does not
implement `CMD_FS_OPEN` returns `RSP_UNKNOWN_COMMAND`, which the fixture rejects
before reaching its PENDING branch. `tools/serial_smoke.py` then treats a
PENDING transcript as complete success and ultimately prints `serial_smoke:
OK` with exit status zero.

Make the outcomes unambiguous:

- a verified `RSP_UNKNOWN_COMMAND`/unknown-command status for the writable
  service may produce the documented PENDING result;
- an expected `RSP_FS_OPEN` with a nonzero filesystem/media status is a
  failure, not PENDING, unless the wire status uniquely proves an unsupported
  write feature (the current frozen `FS_ERROR` status does not);
- the target must not print the final M8 selftest `OK` marker after PENDING;
- the serial smoke tool must identify PENDING explicitly and return nonzero,
  distinct from a passed physical gate. It must never print its final `OK`
  result for PENDING;
- add unit tests covering pass, PENDING, wrong response class, unknown command,
  and representative filesystem/media failures.

The accepted physical run is expected to take the full write/read/DONE path.
PENDING remains only an honest operator-visible outcome for an older deployed
firmware, never acceptance evidence.

### 3. The validation record does not reproduce the literal command sequence

The record says the final discovery run completed `461 tests OK, 0 skipped`.
An independent run of the literal package sequence completed 461 tests with 94
image-dependent skips. It also emitted numerous `ResourceWarning` messages,
including warnings from package-owned IOC tests. The worker rules require exact
skip/warning reporting and forbid summarizing them as an unqualified pass.

Update the validation record with the exact output produced by the settled
tree. Either build the stated complete image matrix with recorded commands
before claiming zero skips, or report the actual skips and why each category is
expected/already exercised by the preceding targets. Report warnings rather
than omitting them; close file handles introduced or owned by the package where
practical. Do not expand this correction into unrelated legacy warning cleanup.

## Required validation

Run from a clean tree, in this order, and preserve exact counts, skips,
warnings, hashes and artifact names:

```sh
make clean
make check
make zmod-test
make ioc-test
make m8-ioc-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/modules/ioc.zmod \
          build/modules/sio.zmod \
          build/modules/monitor.zex \
          build/zephyros.bin \
          build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin \
          build-m8-ioc-selftest/recovery.romfs
make clean
```

Because the IOC module and acceptance image will change, flash the newly
hash-pinned `build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin` and rerun:

```sh
make smoke-hardware-m8-ioc SERIAL_PORT=...
```

Preserve the complete transcript and prove the dedicated `M8IOCTST.BIN` was
deleted. Record PENDING rather than PASS if the writable service is genuinely
unsupported. Hardware remains authoritative; simulator output does not replace
this rerun.

## Acceptance criteria

- No successful non-bulk command response can change the IOC bulk phase,
  including the exact HID collision above.
- Every pinned bulk-producing command retains correct READY/data/DONE behavior,
  invalid phases still fail before lane I/O, and post-fault recovery remains
  covered.
- Hardware PASS, PENDING and FAIL are mutually exclusive in target output,
  smoke-tool output and exit status; ambiguous filesystem/media errors fail.
- The settled validation record matches the commands actually run, including
  skip and warning counts, and all artifact hashes match the tested/flashed
  files.
- The physical command, 1/128/512-byte write, matching DONE, 1/128/512-byte
  read-back and cleanup gate passes with the corrected image.
- The IO Controller firmware and Zephyr-80 repository remain unchanged.

