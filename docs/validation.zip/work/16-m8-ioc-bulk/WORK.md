# Task

Complete `ioc.zmod` with the SIO1/A bulk-read and bulk-write lane, strict
READY/data/DONE state ownership, and proven recovery while preserving the
accepted command lane byte-for-byte except where shared state/API expansion is
required.

## Context

Start only after package 15 is physically accepted. Read `work/00-WORKER.md`,
architecture section 30.6, and `work/M8-REFERENCE.md`; reread the complete
`IOCBULK`/`IOCBULKW` implementations and `bulk_channel.h` named there. The MCU
firmware remains immutable. The deployed pair has bulk CRC bypass enabled on
both sides; this package must match it explicitly rather than “fix” one side.

## Requirements

- Add only the remaining platform facts for SIO1/A and the deployed bulk mode:
  ports `30h/31h`, register/status values, 512-byte maximum, scan/FIFO/admission
  limits and `ZOS_IOC_BULK_CRC_BYPASS=1`. C/assembly parity tests must reject a
  one-sided or accidental default change.
- Initialize SIO1/A once and leave its receiver enabled. Track command and bulk
  sync separately, but explicit link recovery clears/re-establishes both as one
  generation. Never reset/reinitialize a synchronized lane during normal use.
- Recognize a READY only when a successful command reply has the exact READY
  payload shape: nonzero transfer id, known direction, length 1-512, and
  response TYPE/sequence already verified. Store those fields privately.
  Reject another command while a bulk phase is admitted.
- `bulk_read(dst,length)` and `bulk_write(src,length)` require a matching pending
  direction and exact admitted length. Null, zero, overlength, wrong direction,
  duplicate and no-READY calls fail without I/O. Bind the common bulk header to
  stored TYPE/sequence/status and validate every field after capture.
- Port the proven read discipline exactly: preserve IFF; clear errors; enter
  Hunt only before first verified bulk packet; bounded FIFO drain; assert RTS;
  reset/sample DCD admission; bounded full-marker scan; capture all five header
  bytes at wire speed before validating; INI-shaped payload loop; consume the
  two-byte trailer plus required pipeline byte(s); release RTS/TX; confirm CTS
  deassertion; then validate READY metadata. Never accept FIFO byte zero as the
  payload start.
- Port the proven write discipline exactly: build header before lane entry;
  keep RX enabled; program AAh WR6/WR7 fill and arm the SIO TX CRC generator;
  preload disposable `00h`; assert RTS; reset/sample CTS admission; send
  `A5 5A`, header and payload with the OUTI-shaped bounded loop; issue EOM reset
  only after the final payload byte, wait for transmitter underrun, retain the
  measured 128-iteration CRC completion guard, then disable TX/release RTS.
  Restore interrupts before the potentially long completion wait. The MCU
  currently ignores this generated trailer, but the host wire/timing remains
  identical to the proven implementation.
- Mask interrupts only while the MCU's unpausable stream is active and restore
  exact entry IFF on every success/error. All timeout and malformed-packet exits
  unwind RTS, busy and admission state deterministically. A transport fault
  leaves no stale READY; the next operation performs bounded whole-link
  recovery before normal traffic.
- A completed read returns to idle (DONE is optional for a read). A completed
  write enters DONE_REQUIRED; only `CMD_XFER_STATUS` is accepted, and success
  requires matching DONE response, transfer id and controller status. A failed
  DONE remains an error/recovery state; it must never report the write complete.
- Extend the simulator peer for both directions, persistent pipeline residue,
  delayed DCD/CTS, midstream stall, header mismatch, stale sequence/type,
  underrun, missing deassertion, and CRC-bypass trailers. Assert exact memory
  canaries, lane state, RTS, IFF, and subsequent command recovery.
- Add safe target acceptance. Bulk read uses an existing non-destructive
  production `/SHARED` file command. Pass the separator-free basename
  `M8IOCTST.BIN` (the controller itself confines it to `/SHARED/`), create or
  truncate that dedicated file, and write deterministic 1-, 128-, and 512-byte
  patterns,
  requires matching DONE, reads it back, then deletes it. Use the frozen
  `CMD_FS_*` layouts in the pinned `ioc_frame.h` only inside the target fixture;
  this is transport acceptance, not a ZephyrOS filesystem API. Never use
  diagnostic-only `CMD_BULK_TEST`/raw-SD commands, a raw LBA, or alter a user
  file. If the deployed build lacks writable shared-folder commands, record the
  bulk-write hardware criterion `PENDING`; do not alter firmware or substitute
  a destructive write.

## Files

- `include/zephyros/ioc.h`, `platform/zephyr80/hardware.{h,inc}`
- `drivers/ioc/`, `modules/manifests/ioc.json`
- `tests/test_ioc*.py`, `tests/target/m8/`, `tests/z80sim.py`
- `Makefile`, `tools/serial_smoke.py`, `docs/{devices,architecture}.md`
- `docs/validation/<date>-m8-ioc-bulk.md`

## Constraints

- No IOC firmware edits, new MCU commands, raw storage driver, filesystem
  implementation, WAIT/DMA optimization, or SIO1 interrupt path.
- The build must state bulk CRC bypass visibly; header/admission validation is
  never bypassed.

## Validation

```sh
make clean
make check
make zmod-test
make ioc-test
make m8-ioc-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean
```

Flash the named IOC selftest image and run
`make smoke-hardware-m8-ioc SERIAL_PORT=...`. Preserve its command/read/write,
DONE, recovery and cleanup transcript. Hardware is authoritative.

## Acceptance criteria

- IOC registers all four IOC capabilities and rejects every invalid phase
  transition before touching hardware.
- Command, 1/128/512-byte read, 1/128/512-byte write, DONE matching, timeout
  cleanup and post-fault recovery are demonstrated without firmware changes or
  destructive media access.
- The previously accepted command transport and SIO fallback remain intact.
