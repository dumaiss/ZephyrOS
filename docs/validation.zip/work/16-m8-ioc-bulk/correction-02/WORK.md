# Correction 02 — Reject ambiguous PENDING and cleanup statuses

## Correction

Correction 01 fixed the driver state bug and the target's initial writable-open
classification, but the final acceptance classifier still accepts ambiguous
filesystem/media errors:

- `tests/target/m8/m8_ioc_test.c` reports cleanup success for any nonzero
  status returned by the post-delete reopen. Only the frozen
  `IOC_STATUS_FS_NO_FILE` value (`34h`) proves that `M8IOCTST.BIN` is absent.
- `tools/serial_smoke.py` accepts any two hex digits in both the cleanup marker
  and the PENDING marker. Consequently, a transcript containing `PENDING 0x38`
  is classified as PENDING and one containing `cleanup OK 0x38` plus the other
  success markers is classified as PASS. `38h` is the real `FS_ERROR` status,
  not proof of an unsupported command or successful deletion.

This violates correction 01's requirement that ambiguous filesystem/media
errors fail and that cleanup be proven. Package 16 remains unaccepted until
these cases are rejected. Do not modify the IO Controller firmware or any file
in the Zephyr-80 repository.

## Required changes

- Pin `IOC_STATUS_FS_NO_FILE = 34h` privately in the M8 target fixture, with a
  parity/static test alongside the other frozen fixture-only command facts.
- After deleting the dedicated file, accept the reopen only when transport is
  successful, the response class is `RSP_FS_OPEN`, status is exactly
  `IOC_STATUS_FS_NO_FILE`, and the reply has the frozen empty failure shape.
  Any other status or shape must emit the existing cleanup failure and must not
  reach the final OK marker.
- Make the smoke parser accept exactly `cleanup OK 0x34`, not an arbitrary
  status.
- Make both PENDING markers accept exactly `0xFE`, the response class printed
  by the target after it has verified `RSP_UNKNOWN_COMMAND` plus status `02h`.
  A transcript using `0x38`, mismatched marker values, or any other code must be
  FAIL, never PASS or PENDING.
- Extend host tests to assert the exact marker values and to reject at least:
  `PENDING 0x38`, one correct and one incorrect PENDING marker, cleanup `0x33`,
  cleanup `0x38`, and cleanup success with a nonempty failure reply.
- Extend the real-image simulator fixture so the post-delete reopen can return
  an injected media/filesystem error. Prove that exact `34h` reaches cleanup
  and final OK, while the injected error produces FAIL and no cleanup/OK
  marker.
- Update the validation record honestly with the new counts and hashes. Keep
  the existing correction-01 READY fix and tests unchanged.

## Validation

Run from a clean tree:

```sh
make clean
make check
make zmod-test
make ioc-test
make m8-ioc-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/modules/ioc.zmod \
          build/modules/sio.zmod \
          build/modules/monitor.zex \
          build/zephyros.bin \
          build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin \
          build-m8-ioc-selftest/recovery.romfs
make clean
```

The target comparison changes the acceptance image even if the IOC module is
byte-identical. Flash the newly hash-pinned image and rerun:

```sh
make smoke-hardware-m8-ioc SERIAL_PORT=...
```

Preserve the transcript. It must contain `cleanup OK 0x34`, the complete
write/read/DONE path and the final OK marker. Do not reuse the previous image's
hardware evidence unless the complete image is byte-identical.

## Acceptance criteria

- Only `RSP_UNKNOWN_COMMAND`/status `02h`, represented by both exact
  `PENDING 0xFE` target markers, is classified PENDING; every ambiguous or
  mismatched marker is FAIL and the smoke tool exits nonzero.
- Only an exact empty `RSP_FS_OPEN` failure with status `34h` proves cleanup;
  filesystem, mount, media and malformed replies fail before the OK marker.
- The correction-01 READY admission tests, all original package-16 tests, the
  clean validation sequence and the newly hash-pinned physical smoke pass.
- The validation record reports exact counts, warnings, skips and hashes.
- The IO Controller firmware and Zephyr-80 repository remain unchanged.

