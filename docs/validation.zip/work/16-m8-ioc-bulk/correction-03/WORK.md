# Correction 03 — Align the validation record with the settled map

## Correction

Corrections 01 and 02 pass code review, focused regression, the complete clean
validation sequence, artifact hash verification and the recorded physical gate.
One documentation-only inconsistency remains: the settled correction-02 build
reports `__kernel_code_end = 67C7h`, while
`docs/validation/2026-10-03-m8-ioc-bulk.md` still records `67F7h` in its M8
acceptance-image geometry paragraph. The derived arena is correctly unchanged
at `6800h-BFFFh` (44 granules).

Package 16 is otherwise complete. Correct only this evidence-record mismatch.
Do not modify production source, tests, build rules, firmware, or Zephyr-80.

## Required changes

- Change the validation record's M8 acceptance-image static kernel end from
  `67F7h` to `67C7h`.
- Recheck the surrounding geometry, artifact sizes and hashes against the
  settled build. Do not change any value that already matches.
- State in the handoff that this correction is documentation-only and that the
  accepted correction-02 image remains byte-identical.

## Validation

```sh
make m8-ioc-selftest
rg -n "kernel end|derived arena" \
    docs/validation/2026-10-03-m8-ioc-bulk.md \
    build-m8-ioc-selftest/geometry/arena_geometry.inc \
    build-m8-ioc-selftest/zephyros.map
sha256sum build/modules/ioc.zmod \
          build/modules/sio.zmod \
          build/modules/monitor.zex \
          build/zephyros.bin \
          build-m8-ioc-selftest/zephyros-m8-ioc-selftest.bin \
          build-m8-ioc-selftest/recovery.romfs
git diff --check
make clean
```

The image must remain `365250f6e637efd58e1506f1599d6430cdcd69ccf46114bf1faa5222ab2ca411`.
If it does, the existing physical transcript remains applicable and must not be
replaced. If any artifact differs, stop and report rather than claiming this is
documentation-only.

## Acceptance criteria

- The validation record, generated geometry and linked map all agree on kernel
  end `67C7h` and arena start `6800h`.
- All six artifact hashes remain exactly those already recorded for correction
  02, including the physically tested image hash above.
- `git diff --check` and final cleanup pass.
- No source, test, build, firmware or Zephyr-80 file changes.

