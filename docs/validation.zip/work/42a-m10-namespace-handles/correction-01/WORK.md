# Correction 01: 42a builds into a test image; production switches in 42b

Your stop report is accepted. Production bank 7 cannot hold the namespace
code (+5,758 bytes) while the M9 `FS_*` front end, the M9 VFS machinery
and the IOC-FAT arena are still linked; those leave in 42b. The same
squeeze was handled in packages 39 and 40 by building into test images
first.

## Changes to `../WORK.md`

1. **Production stays byte-identical** (`11a9bd2b…`). The root router,
   the DEVICE and ROMFS providers, the handle-table extension,
   `bind`/`call`/`unbind`, `ns_enum` and the standard handles are built
   only into an acceptance image: extend `ipc-selftest`, or add one
   `namespace-selftest` with a small boot set. Use the
   `config/residency.json` placement that production will use (as package
   39 did with `test_link`).
2. **`SYS_IPC_LOOKUP` stays in production** until 42b. In the acceptance
   image it is absent, and the SDK built for that image uses
   `bind`/standard handles.
3. **Measurements for 42b.** Report, from the acceptance image and the
   production map:
   - the namespace code's bytes, fixed and cold, per object;
   - the bank-7 bytes that 42b frees: the arena (16 granules), `fs`, each
     M9 VFS object that the router and providers replace (mount table,
     provider registration, path/mount resolution, workspace views,
     descriptor kinds), and the registry;
   - the projected production ledgers after 42b.

   State which M9 VFS objects the new code **reuses** (path
   normalization, CWD storage), so that 42b deletes only the rest.
4. Everything else in `../WORK.md` stands: the requirements, the tests and
   the report.

Validation: as in `../WORK.md`, plus the acceptance image you use.
Production must reproduce `11a9bd2b…`.
