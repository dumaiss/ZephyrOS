# 42a-m10-namespace-handles — checkpoint status

Contract: [WORK.md](./WORK.md).  Baseline is the committed 41b tree
(`2bc4969 41b`), which is clean.

## Plan (design decisions taken, in contract order)

1. **Protocol types** (`abi/zos/object.h`, new): 8-bit types reuse the pinned
   device class numbers where they coincide:
   `SERIAL 1, VIDEO 2, BLOCK 3, INPUT 4, IOC 5, CONSOLE 6, FILE 7, FS 8,
   SOUND 9, TIMER 10`.
2. **Syscall numbers** (pinned in `abi/zos/syscall.h`, documented in
   `docs/abi.md`): `06h SYS_BIND` (replaces `SYS_IPC_LOOKUP`),
   `07h SYS_CALL` (same number, block now carries a bound handle),
   `08h SYS_UNBIND`, `09h SYS_NS_ENUM`.  Blocks in `abi/zos/object.h`
   (bind/unbind/ns_enum) and `abi/zos/ipc.h` (call, frame unchanged).
3. **One handle table:** the M9 pool (`kernel/vfs/process.c`) grows to
   `VFS_FD_MAX 12` and each entry gains `number` (per-process handle
   number), `endpoint`, `object`, `flags`, and a `vfs_ns_file` union arm
   (ROMFS FILE instance inline: `romfs_file_t` + offset + flags).  The M9
   `FS_*` descriptors keep using the pool by index.
   - Fixed numbers: `ZOS_HANDLE_STDOUT 1`, `ZOS_HANDLE_STDIN 2`; binds
     hand out the lowest free number >= 3 for the owning pid.
   - `vfs_process_start()` gives the child its two new `/dev/console`
     entries (absent when no console driver published it);
     `vfs_process_exit()` unbinds every owned handle (existing loop
     extended).
4. **Root router** (`kernel/vfs/ns.c`, new, cold): case-insensitive first
   component to FS / SYSTEM / dev.  `/FS` (and below) is `ZOS_ENODEV`
   here (42b).  Path normalization reuses `vfs_path_normalize_at` against
   the caller CWD and the VFS workspace path slots.
5. **DEVICE provider:** the packer emits a per-image publication table
   (service ABI 4: `publication_offset`/`publication_count` reuse the two
   section `reserved` fields; record `name[20], type, number, object`,
   24 bytes).  The loader validates and installs into
   `vfs_ns_install_publication()`; the provider derives `container`
   entries by prefix (grouping entries are a table view, not objects).
   `/dev/input` and `/dev/serial` are containers, not bindable.
6. **ROMFS provider:** `bind("/SYSTEM/...")` resolves with
   `romfs_lookup_ci`, creates an inline FILE instance in the handle
   entry, and returns type FILE with the nucleus FILE endpoint number.
   The dispatch lives in `kernel/vfs/ns_file.c` and is installed as a
   **nucleus endpoint** in the IPC endpoint table
   (`ipc_install_nucleus_endpoint()`, kind flag, numbers from
   `IPC_ENDPOINT_NUCLEUS_BASE 0x80u`); `ipc_call_endpoint` invokes it in
   place (no bank switch) with the caller's handle so the dispatch finds
   its instance.  Descriptor data moves through a new
   `ipc_nucleus_copy()` (same capture table, chunked through
   `zos_bank_copy`).  FILE ops pinned in `abi/zos/protocol.h`:
   `ZFILE_OP_READ 0` (desc OUT), `ZFILE_OP_SEEK 2`, `ZFILE_OP_META 3`
   (`struct zfs_stat` in the payload).  Write is 42b.
7. **ns_enum:** `{path, length, cookie, out, out_size, count}`, batched
   `struct zos_ns_entry {type, flags, name_length, name[20]}` entries
   written to the caller buffer through the copy gate; `HL = count`,
   cookie updated in the block.  Implemented for `/`, `/dev`,
   `/dev/input`, `/dev/serial`, `/SYSTEM`; `/FS` is ENODEV.
8. **SDK:** `zos_ipc_bind/unbind/call` + `zos_ns_enum`; the lookup cache
   and `zos_ipc_lookup*` are removed.  `console.h` uses the standard
   handles.  Typed device clients added: `zos/video.h`, `zos/input.h`,
   `zos/serial.h`, `zos/ioc.h` (+ `src/`), bind `/dev` names, check the
   returned type, fill the frame.
9. **Tests:** the IPC probe binds `/dev/test/*` names (synthetic
   services gain publications); lookup/discovery tests deleted; new
   outcome tests for bind of a `/dev` object and a `/SYSTEM` FILE read,
   bad path/handle, exhaustion, returned type, `ns_enum` cookie paging
   and standard handles across nested exec.
10. **Ledgers:** the five lines before (41b) and after, in the report.

## Status

- [x] Reconnaissance and baseline sources recorded (41b committed tree).
- [ ] ABI headers
- [ ] Kernel namespace + handles + IPC
- [ ] Packer + manifests + loader
- [ ] SDK + console + device clients
- [ ] Tests + docs
- [ ] Validation and report

## Budget finding (2026-10-09): 42a does not fit bank 7

Measured the baseline (41b, committed tree, rebuilt in a clean worktree) and
the current implementation object by object:

| object | area | baseline | 42a | delta |
|---|---|---:|---:|---:|
| `ipc.rel` | fixed code | 2,851 | 3,396 | +545 |
| `ipc.rel` | fixed data | 190 | 198 | +8 |
| `vfs_process.rel` | fixed code | 1,128 | 1,563 | +435 |
| `vfs_process.rel` | fixed data | 652 | 768 | +116 |
| `syscall.rel` | cold code | 767 | 790 | +23 |
| `vfs_mount.rel` | fixed code | 2,172 | 2,182 | +10 |
| `fs.rel` | cold code | 2,727 | 2,735 | +8 |
| `ipc_syscall.rel` | cold code | 143 | 160 | +17 |
| `vfs_ns.rel` (new) | cold code+data | 0 | 2,569+275 | +2,844 |
| `vfs_ns_file.rel` (new) | cold code | 0 | 1,202 | +1,202 |
| `object.rel` (new) | cold code | 0 | 550 | +550 |

Totals: cold +4,644, fixed +1,114 = **+5,758 bytes**.

Free by 36.20 after the package-41b build:

* fixed core: 909 (code+data+stacks; aligned code room 646)
* cold half: 2,033 (arena slack 1,536 + data room 498)
* **total free: 2,949**

The production boot set still needs the 13 IOC-FAT arena granules
(6,656 bytes) until 42b, and the M9 VFS machinery (fs, vfs_file,
vfs_mount, vfs_dir, vfs_mutate, vfs_path, vfs_process, vfs_workspace,
romfs_provider, mounts) stays linked until 42b/42c.  The namespace code
cannot be placed anywhere else: bank 6 is the driver domain (the
architecture rejects the VFS as a bank-6 service) and the common window
has only 842 bytes free.

`make` therefore fails in the geometry probe: "linked fixed code ends at
575Fh, past the derived fixed data base 5600h".

Shortfall: ~2,800 bytes.  Even an aggressively slimmed namespace
implementation (router + DEVICE + ROMFS FILE + handles + 4 syscalls +
IPC glue) lands at roughly 3.3-3.6 KB of Z80 code and data, so the
package as contracted cannot fit while the M9 machinery and the arena are
linked.

Candidate, measured remedies:

* the M8 device registry (`kernel/device/registry.c`, 1,316 cold bytes)
  is **dead in production** ("production no longer populates" it, per
  kernel/module/loader.c); only the M4/M8 module-ABI fixtures use it.
  Removing it from the production link frees 1,316 and is 42b/42c
  scheduled work.
* moving IOC-FAT out of the bank-7 arena into bank 6 frees 6,656 cold
  bytes; that is package 42b's core change.
* aggressive slimming of this package's code (planned, ~1.5 KB).

### Not in scope, rejected as self-directed fixes

* Deleting or excluding `registry.rel` (1,316 cold bytes; dead in
  production but used by the M4/M8 module-ABI fixtures) is 42b/42c work.
* Moving IOC-FAT out of the bank-7 arena into bank 6 frees 6,656 bytes
  but is 42b's core change.
* Dropping the ROMFS `/SYSTEM` FILE provider from this package weakens
  requirement 3.
* Placing namespace code in the common window (842 bytes free) is
  technically safe but the window is reserved for transition paths.

Worker contract `work/00-WORKER.md`: "a choice would materially change
scope or the ABI" -> stop and report; "`make check` must be green at
handoff".  Waiting on the owner's decision between: prune the dead
registry + hard slimming; pull 42b's arena release forward; trim the
package; or hand back the measured blocker.

## Correction 01 (owner, 2026-10-09): build into an acceptance image

Accepted.  Production bank 7 cannot hold the namespace code while the M9
`FS_*` front end, the M9 VFS objects and the IOC-FAT arena are linked;
42b deletes those.  The package therefore builds the *whole* contract
into one `namespace-selftest` image, exactly as packages 39/40 did, and
production stays byte-identical (`11a9bd2b…`).

Decisions taken:

* One new image, `make ns-selftest` (`build-ns-selftest/`), not an
  extension of `ipc-selftest`: the IPC image measures the stage-3 pair
  that must stay untouched, and the namespace image needs its own
  service set and store.
* `SYS_IPC_LOOKUP`/`SYS_IPC_CALL` stay in production; in the image 06h-09h
  route to `zos_object_dispatch` and the SDK variant marshals
  bind/unbind/ns_enum.  One macro, `ZOS_NS_HANDLES`, defaults to 0 in
  `abi/zos/object.h` and every production-visible edit is behind it.
* Placement is the one production will use: `vfs_ns`, `vfs_ns_file` and
  `object` are `cold` in `config/residency.json` and listed in
  `test_link` (the image reaches them through its own `--cold-extra`,
  production's `cold_half` and linker script are untouched).
* The image adds no kernel object to the production link: `NS_OBJS` is
  empty unless `ZOS_NS_SELFTEST=1`, and `nsgate.asm` joins the SDK
  archive as a member no production program references (so the production
  image hash is unchanged and `ZMOD`/SDK inventories stay honest).
* Service publications are a new container ABI (4) rather than a new
  section: the section header's reserved bytes carry the table, and a
  container without publications is ABI 3 byte for byte, so the
  production store is untouched.

### What the image is

`ZOS_NS_SELFTEST=1`: SIO + console services (their manifests, under
`tests/ns/manifests/`, carry the publications `/dev/serial/0` and
`/dev/console`), the synthetic publisher `nsdev` (class 30, publishing
`/dev/input/keyboard` and `/dev/video` with object ids 1 and 2), boot
program `/SYSTEM/ns.zex` and the child it execs, `/SYSTEM/nschild.zex`.
No arena modules, so the derived arena belongs to the test objects.

### Acceptance client findings

* `/` is a directory of provider roots, not a provider: the router
  refuses a root-level name (`/services.man`) with `-ZOS_ENOENT`.  The
  first client revision bound root-relative names and read the failure as
  a provider bug; the fix is the client's paths (`/SYSTEM/services.man`)
  plus an explicit `file-root-refused` check.  All 76 checks pass.
* `vfs_ns_init()` installs the ROMFS FILE endpoint as a *nucleus*
  endpoint before the loader runs, so the loader's
  "number == count + 1" install test had to become a uniqueness check
  (guarded `ipc_install_endpoint`).
* sdasz80 has no `-D`, so the SDK variant is a separate `nsgate.asm`
  rather than `.if` in `runtime.asm`; the kernel links no 32-bit
  arithmetic helpers, so the README-size `ns_room` loop is 8-bit.

### Measurements (final source)

`make ns-selftest` ledgers (`build-ns-selftest/`, production placement):

```text
nucleus fixed: required 7250 bytes | overflow 5829 bytes | stacks 768 | room 2537 bytes
nucleus cold:  code 30256 bytes end D630h | arena 1 granules (0 boot, 1 free)
               | data 1421 bytes at DA00h | room 579 bytes
driver hot: 0 bytes of 32768      (services pack through the service ledger)
driver boot/bulk: 0 bytes of 24576
common: used 2230 of 7424 bytes (code 1511, data 719) | ceiling 3072, m10 512, limit 2560
```

The image's cold-code end is *higher* than production's (`D630h` vs
`B997h`) because the M9 machinery and the arena are still linked: this
is not a production projection, it is the same source set with the
family added.

The five ledgers before/after are in
`docs/validation/2026-10-09-m10-namespace-handles.md`, with the
per-object itemization of the namespace code (4,735 cold bytes of new
objects plus the guarded growth of shared objects) and of what 42b frees
(`fs` 2,727, `vfs_mount` 2,235 fixed, `vfs_file` 2,484 fixed,
`vfs_dir` 1,576, `vfs_mutate` 553, `romfs_provider` 1,563, `registry`
1,624, the generated mount table 55, the arena's 13 IOC-FAT granules =
6,656 bytes) and reuses (`vfs_path`'s whole `vfs_path_normalize_at`,
`vfs_process`'s CWD slots and handle pool, `romfs.rel`'s reader,
`ipc`'s endpoint/copy machinery, `fs.rel`'s argument helpers).

### Validation state

* `make` (production) exit 0; `build/zephyros.bin` sha256
  `11a9bd2b68c7473eab6b624de4155a45ac738f668033b493c965a92fb7016c2e`,
  reproduced after every edit (`make clean && make check`, twice).
* `make clean && make check`: 823 tests, OK (183 skipped).
* `make ns-selftest`: image builds, mapcheck OK, `tests/test_ns_selftest.py`
  (20 tests) and `tests/test_ns_selftest_sim.py` (3 tests) pass; the
  transcript ends `ns: 76/76 checks` / `ns selftest: OK` /
  `monitor: exit status 0x0000`.
* The four other acceptance images
  (`make console-integration-selftest console-fallback-selftests
  ipc-selftest m9-selftest`), re-run on the final source (2026-10-09):
  all pass - `test_console_fallback.py` (3 tests, OK, 1 skipped),
  `test_console_acceptance.py` (6, OK), `test_m9_selftest_sim.py` (7, OK)
  and `test_ipc_selftest*.py` (53, OK); every target printed its image
  line and `make` exited 0.  `git diff --check` is clean and
  `build/zephyros.bin` still hashes `11a9bd2b…`.
* Last source edit before the final runs: `user/sdk/include/zos/ipc.h`
  now guards the `zos_ipc_lookup`/`zos_ipc_lookup_version` *declarations*
  the same way `ipc.c` guards their definitions, so the acceptance
  image's SDK no longer advertises wrappers it does not carry.  Because
  that is a source change, the whole gate was re-run afterwards:
  `make clean && make check` OK (823 tests, 183 skipped), all four
  neighbouring targets OK, `make ns-selftest` OK (23 tests), and all
  seven image binaries hash identical to the pre-edit run
  (`build/zephyros.bin` `11a9bd2b…`, `zephyros-ns-selftest.bin`
  `39048a98…`) - so the edit is provably inert for every image while
  fixing the header.
