# Task

M10 step 6 (architecture 36.24): **namespace and typed handles.**

- The VFS becomes the root router over the three static nucleus
  providers (36.13). Implement DEVICE (`/dev`) and ROMFS (`/SYSTEM`) here.
  `/FS` is routed in 42b.
- `bind`/`call`/`unbind` with 8-bit protocol types.
- One global owner-tagged handle table.
- `ns_enum`.
- Standard console handles.
- `SYS_IPC_LOOKUP` is removed.

The M9 `FS_*` file path keeps working, unchanged, until 42b replaces it.

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md` (decisions 11-16 and the rejected list);
- architecture 36.7, 36.11-36.14;
- `docs/vfs.md`, `kernel/vfs/` (`process.c` holds the M9 descriptor pool);
- `kernel/syscall/ipc.c`, `abi/zos/ipc.h`;
- the SDK IPC and console clients;
- the package-41b record.

**Before starting:** if 41b's record contradicts this contract, stop and
report.

## Requirements

1. **Root router** (36.13).
   - `/` routes case-insensitively by the first component to the `FS`,
     `SYSTEM` and `dev` providers.
   - The provider owns everything below its root; the VFS does not
     interpret it.
   - No mount table or provider registration is involved in the new path.
   - In this package, `bind` below `/FS` returns `ZOS_ENODEV` (42b).
2. **DEVICE provider** over the **host-built publication table**.
   - The packer emits it from driver metadata: name, 8-bit type,
     endpoint, object.
   - Publications (36.13): `/dev/console`, `/dev/input/keyboard`,
     `/dev/video`, `/dev/serial/0`, `/dev/ioc`.
   - `/dev/input` and `/dev/serial` are grouping entries in the table
     (`container`), not objects.
3. **ROMFS provider at `/SYSTEM`.** Binding a ROMFS file gives a `FILE`
   handle, served in-process by a nucleus endpoint through the same
   handle-call path as a bank-6 endpoint, with the one ROMFS reader.
   Support the FILE read, seek and metadata operations.
4. **Handles.** Extend the M9 descriptor pool; do not add a table.
   - Each entry records the owner PID, the 8-bit type, the endpoint, the
     provider object/instance, and flags/state.
   - The M9 `FS_*` descriptors share the pool until 42b.
   - Exit unbinds every handle the process owns (36.13).
   - A child gets new entries for the standard handles only.
5. **Syscalls** (36.14):
   - `bind(path, u16 flags)` returns a handle plus an 8-bit type, and
     takes no expected-type argument;
   - `call(handle, op, frame, descriptors)`;
   - `unbind(handle)`;
   - `ns_enum(path, cookie, out)`: batched entries of name, `container`
     flag and type, for `/`, `/dev`, `/dev/input` and `/SYSTEM`.

   Remove `SYS_IPC_LOOKUP` and the SDK lookup cache. Pin the numbers and
   document them in `docs/abi.md`.
6. **Standard handles.** Console input and output are bound to
   `/dev/console` at fixed handle numbers at process start, and inherited.
   `console.h` uses them.
7. **SDK.** Typed clients (`console.h`, `video.h`, input, serial, ioc)
   bind names where appropriate, check the returned type when they care,
   and fill the frame. There is no generic `handle_info`.
8. **Budget.** Report the five ledgers before and after.

## Constraints

- No changes to `FS_*`, IOC-FAT, the M9 mounts or exec; that is 42b.
- **Tests:** delete the lookup and discovery tests. Add outcome tests:
  - binding a `/dev` object and a `/SYSTEM` FILE (a read);
  - a bad path, a bad handle, table exhaustion;
  - the returned type;
  - `ns_enum` with its cookie paging;
  - inherited standard handles across nested exec.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-namespace-handles.md`.
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation (once, on the final source)

```sh
make clean && make check
make console-integration-selftest console-fallback-selftests ipc-selftest m9-selftest
git diff --check
```

Hardware (owner): `make smoke-hardware`, and the console on the keyboard
and the V9958.

## Acceptance criteria

- Programs reach every device through `/dev` names or the standard
  handles, and read `/SYSTEM` files through FILE handles.
- One handle table.
- Endpoint numbers are invisible to programs.
- The ledgers are within 36.20.
