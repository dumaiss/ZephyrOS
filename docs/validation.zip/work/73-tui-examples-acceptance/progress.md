# Progress

## Status

CORRECTION REQUIRED — correction 02 issued on 2026-10-19. A physical
V9958/HID run proved that `tui_dialog` rejects the valid Edit menu result
(`11`) because the example embeds its simulator script's expected File result
(`10`). The TUI implementation is not implicated. Correction 01 remains
accepted; physical V9958/HID and serial-terminal acceptance remain `PENDING`.

## Done

- Added `docs/tui.md` and linked it from `docs/sdk.md`; documented
  `LIBS=tui` and `LIBS=tui_widgets:tui`.
- Added the standalone examples `tui_demo.c`, `tui_keys.c` and
  `tui_dialog.c`, their SDK Makefile declarations and in-tree acceptance
  build declarations.
- Bumped `KOS_SDK_VERSION` to `0.2.0`; EXE ABI unchanged.
- Extended the SDK package to 54 files with both archives, both headers,
  `docs/tui.md` and all three examples; out-of-tree builds and simulator runs
  pass.
- Added both-backend simulator coverage for all three examples.
- Added `flushfull`, `flushsame` and `flushrow` measurement modes: full form
  7 dispatches, unchanged 0, changed row 1.
- Added the public-definition audit and kept core/render-only archive
  extraction proof.
- Forced scoped rebuild and validation: 150 tests, 149 passed, 1 skipped,
  0 failed; extended TUI/console acceptance: 183 tests, 181 passed, 2
  skipped, 0 failed; `git diff --check` clean.
- Record: `docs/validation/2026-10-18-tui-sdk-v1.md`.
- Correction 01: added `docs/tui.md` to `Makefile`'s `SDK_INPUTS` beside the
  other packed public documents; added
  `TestSdkSourceInputs.test_every_packed_document_is_a_sdk_prerequisite`;
  rebuilt only `sdk`; packed and source guides are byte-identical and retain
  the clarified ESC rule; 54-file layout unchanged; new tarball SHA-256
  `236f77c60b42f6f6d5fc65a0a9f7a3100b7ac4afcbe49c9e9e9631d77711f7b7`.

## Pending evidence

- Physical V9958/HID and serial 85 x 26 checklist: PENDING with executable
  hashes and owner steps in the report.

## Correction 02

- Physical finding: selecting Edit and completing the staged dialog reached
  confirmation, then printed `TUI DIALOG FAIL menu state 11`.
- ID `11` is the declared Edit ID and is a valid return from
  `tui_menu_run()`; the failure comes from the example's hard-coded acceptance
  oracle, not from `libtui_widgets`.
- See [`correction-02/WORK.md`](correction-02/WORK.md). The correction is
  limited to the example, focused tests, navigation guidance, packaging and
  evidence; it must not change TUI or OS implementation.

## Supervisor review

- The SDK 0.2.0 layout, examples, API audit, measurements, simulator evidence,
  and recorded artifact/image hashes were inspected and otherwise match the
  package report.
- The public guide overstated split-read decoding across the ESC boundary; the
  supervisor clarified that `[`/`O` must be immediately pending with ESC and
  only later CSI/SS3 bytes may span reads.
- Running `make sdk` after that source edit did not rebuild the tarball. The
  packed guide retained the old text because `docs/tui.md` is copied by
  `tools/sdkpack.py` but is not a prerequisite in `Makefile`'s `SDK_INPUTS`.
- See [`correction-01/WORK.md`](correction-01/WORK.md).

## Final supervisor acceptance

- Accepted the package-73 release/documentation/example evidence and the
  worker's scoped validation without repeating packages 66-72.
- Correction 01's dependency regression, pinned layout and reproducibility
  tests passed.
- Direct checks confirmed the current 54-file tarball, packed ESC wording,
  source guide hash, tarball hash and Make freshness.
- Physical checks remain explicitly pending and are not inferred from the
  simulator.
