# Correction 02 — Make `tui_dialog` an honest interactive example

## Finding

A physical V9958/HID run selected the declared **Edit** menu item and reached
the confirmation box.  After the box closed, the program printed:

```text
TUI DIALOG FAIL menu state 11
```

This is an example defect, not a widget-library defect.  `11` is Edit's valid
ID.  The example embeds the simulator script's one expected end state as
runtime assertions: File (`10`), committed input, the exact name `Adam`, Blue,
checked, and No.  Consequently legitimate manual choices are reported as TUI
failures.  The program also presents several controls together without saying
that v1 has no global focus manager: the application explicitly runs the menu
and input helpers, owns the list loop, and then opens the modal.

Correction 01 remains accepted.  This correction is confined to the public
example, its focused acceptance tests and the corresponding guide/evidence.
Do not change `libtui`, `libtui_widgets`, either public header, the OS, console,
HID, V9958, firmware or EXE ABI.

## Required changes

1. Remove the scripted-oracle assertions from `tui_dialog.c`.  After normal
   interaction, every declared menu ID (`10`, `11`, `12`) and
   `TUI_ID_NONE`, input commit or cancel, every in-range list selection, either
   checkbox value, and confirmation YES, NO or `TUI_ID_NONE` are valid user
   results.  Negative API results, impossible IDs/ranges and rendering errors
   remain failures.
2. Shut down normally and print one stable `TUI DIALOG PASS ...` transcript
   containing the state the user actually selected.  Keep the existing
   scripted transcript unchanged for the existing File/Adam/Blue/checked/No
   route; the simulator, not the program, owns that exact oracle.
3. Make the active stage and controls visible before each blocking step:
   menu (left/right or shortcut, Enter, Esc), input (edit, Enter/Esc), list
   (up/down, Enter/Esc), and confirmation (left/right or Tab, Enter/Esc).
   Do not imply that Tab moves freely among the form's render-only widgets.
4. Clarify `docs/tui.md`: v1 has no form-wide focus manager.  Render-only
   calls do not consume keys.  An application calls `tui_menu_run()` or
   `tui_input_run()` for one active control, owns loops such as a list or
   checkbox loop, and calls a modal separately.  Tab is handled by modal
   buttons only; it is not global next-widget navigation.
5. Keep the existing exact scripted-path test on both console backends.  Add
   a focused alternate path that selects Edit (`11`) and proves the example
   exits successfully with `menu=11`.  Exercise the SDK-packed example too,
   so source and packaged copies cannot diverge.  A cancellation-path test is
   welcome but not required if it adds substantial replay complexity.
6. Rebuild only `build/user/tui_dialog.exe` and `sdk`.  Update its executable
   hash, the SDK tarball hash, focused test result, and this physical finding
   in `docs/validation/2026-10-18-tui-sdk-v1.md` and package progress.  Do not
   claim physical acceptance from the corrected build until the owner reruns
   it on hardware.

## Focused validation

Run the existing and new dialog-example cases on both accepted simulator
backends, plus the SDK-built example case.  Do not rerun packages 66-72 or a
repository-wide OS suite.

```sh
make build/user/tui_dialog.exe sdk
python3 -m unittest \
  tests.test_tui_sim.TestTuiSerialScreen.test_dialog_example_runs \
  tests.test_tui_sim.TestTuiSerialScreen.test_dialog_example_accepts_edit \
  tests.test_tui_sim.TestTuiV9958Screen.test_dialog_example_runs \
  tests.test_tui_sim.TestTuiV9958Screen.test_dialog_example_accepts_edit \
  tests.test_sdk_package.TestSdkPackage.test_the_tui_examples_run_from_an_sdk_build
git diff --check
```

If the worker chooses a different descriptive name for the new test, adjust
the focused command accordingly.  Report the actual commands and counts.

## Physical recheck

Copy the newly hash-pinned `tui_dialog.exe` to the card as `tuidlg.exe`.
Select Edit, complete the remaining stages with any valid choices, and confirm
that the reported transcript contains `TUI DIALOG PASS` and `menu=11`.
Repeat the navigation checklist for File/Help, input cancel, list movement and
both confirmation choices.  Record physical V9958/HID and serial rows
separately; leave an unavailable row `PENDING`.

## Acceptance criteria

- A valid Edit result (`11`) can never produce `FAIL menu state 11`.
- Runtime failure means an API/rendering error or impossible state, not a
  legitimate user choice.
- The screen and guide clearly explain which stage owns input and that Tab is
  modal-button navigation, not form-wide focus traversal.
- The original scripted route and an alternate Edit route pass on both
  backends, and the SDK-packaged example carries the same behavior.
- No TUI implementation, public ABI, OS image or package 66-72 behavior
  changes.
