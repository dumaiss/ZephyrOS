# Progress

## Status

DONE — accepted by supervisor on 2026-10-19. SDK document prerequisites are
correct and SDK 0.2.0 is current. No commit was made.

## Result

- `docs/tui.md` added to `Makefile`'s `SDK_INPUTS`, alongside `docs/sdk.md`
  and `docs/exe-format.md`, covering every `sdkpack.DOC_FILES` entry.
- Added the static regression
  `TestSdkSourceInputs.test_every_packed_document_is_a_sdk_prerequisite`;
  it failed before the Makefile change and passes after it.
- Rebuilt only `sdk`: exactly 54 files, source and packed `docs/tui.md`
  byte-identical (`713df83677e6a6cb0279ba3a9afd5ccf4d86271d6e7c1f0e72ea74ec06030634`)
  and retain the clarified ESC rule.
- Freshness verified: `make -q <tarball>` was 0, became 1 after touching the
  guide, and `make sdk` republished it. New tarball SHA-256:
  `236f77c60b42f6f6d5fc65a0a9f7a3100b7ac4afcbe49c9e9e9631d77711f7b7`.
- Pinned-layout, reproducibility and new regression tests passed;
  `git diff --check` is clean.
- No implementation or full-suite rerun was performed, per scope.

## Worker handoff

- Implement only `work/73-tui-examples-acceptance/correction-01/WORK.md`.
- Preserve the supervisor's clarified ESC wording in `docs/tui.md`.
- Do not rerun packages 66-72 or any repository-wide clean/check/test gate.
- Rebuild only the SDK package, update its hash/evidence, and return a
  structured `TUI_REVIEW_REQUEST` naming package 73 correction 01.

## Supervisor finding

- `tools/sdkpack.py` includes `tui.md` in `DOC_FILES`.
- `Makefile`'s `SDK_INPUTS` names `docs/sdk.md` and `docs/exe-format.md` but
  omits `docs/tui.md`.
- After `docs/tui.md` changed, `make sdk` left the 2026-10-18 23:51 tarball
  untouched; direct extraction showed the stale pre-correction wording.

## Final supervisor acceptance

- Directly confirmed that all `sdkpack.DOC_FILES` entries are represented in
  `SDK_INPUTS` and that the tarball rule depends on `SDK_INPUTS`.
- Confirmed `make -q build/kos-sdk-0.2.0.tar.gz` reports the artifact current.
- Inspected the packed guide and confirmed it contains the clarified ESC rule.
- Confirmed the tarball contains exactly 54 files and has SHA-256
  `236f77c60b42f6f6d5fc65a0a9f7a3100b7ac4afcbe49c9e9e9631d77711f7b7`.
- Accepted the worker's three focused correction tests; no implementation or
  OS suite was rerun.
