# Correction

The SDK packer copies `docs/tui.md`, but the root `Makefile` does not include
that document in `SDK_INPUTS`. A public-guide edit therefore leaves
`build/kos-sdk-0.2.0/` and its tarball stale while `make sdk` reports success.

The supervisor also clarified the guide's ESC split-read wording in the shared
tree: `[` or `O` must already be available during ESC's immediate look-ahead;
only the remaining CSI/SS3 bytes may arrive on later reads. Preserve that edit.

## Required changes

- Add `docs/tui.md` to the SDK target's explicit source prerequisites. Keep
  every other packed public document represented as a prerequisite as well.
- Add a narrow static/package regression that fails if a public document named
  by `tools/sdkpack.py` is absent from the SDK build prerequisites.
- Rebuild only `sdk`; verify the packed `docs/tui.md` contains the clarified
  ESC policy and that the exact 54-file layout remains unchanged.
- Update the SDK tarball hash and correction result in
  `docs/validation/2026-10-18-tui-sdk-v1.md` and the package progress file.
- Preserve the accepted examples, libraries, tests, OS image hashes, EXE ABI,
  and all package 66-72 behavior.

Do not rerun the package 66-72 implementation suites or the full OS gates.

## Validation

```sh
make sdk
python3 -m unittest \
    tests.test_sdk_package.TestSdkPackage.test_the_tarball_holds_the_pinned_layout \
    tests.test_sdk_package.TestSdkPackage.test_the_tarball_is_reproducible
git diff --check
```

Also inspect the packed guide directly and record the new tarball SHA-256.

## Acceptance criteria

- An edit to `docs/tui.md` makes the SDK target out of date.
- `make sdk` republishes the current guide rather than retaining stale bytes.
- The tarball remains reproducible and contains the exact 54-file SDK 0.2.0
  layout.
- No TUI implementation, OS image, or EXE ABI change is introduced.
