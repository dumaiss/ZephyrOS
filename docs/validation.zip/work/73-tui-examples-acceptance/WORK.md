# Task

Finish and accept TUI SDK v1: publish user documentation and three standalone
examples, exercise the complete public surface out of tree, bump the SDK minor
version, run the scoped user-SDK/TUI regression suite from forced rebuilds, and
record simulator and physical console evidence. This package fixes integration
defects found by acceptance; it does not add features beyond the architecture.

Read:

- `work/00-WORKER.md`;
- all of `work/TUI-REFERENCE.md`;
- all of `docs/konaos-tui-sdk-architecture.md`;
- packages 66-72 and every accepted validation record;
- `docs/sdk.md`, `tools/sdkpack.py`, `tests/test_sdk_package.py`;
- existing `user/sdk/examples/` and its Makefile.

## Requirements

1. Create `docs/tui.md`, a public application guide, and ship it in the SDK.
   Cover lifecycle, 0-based coordinates, fixed queried geometry, text/control
   behavior, absolute windows and clipping, transactions/flush, styles and
   frames, exact key values and ESC behavior, save/restore storage, widgets,
   error/results, memory cost, and shutdown expectations. `docs/sdk.md` links
   it and documents `LIBS=tui` / `LIBS=tui_widgets:tui`.
2. Add flat standalone SDK example sources and build declarations:

   ```text
   tui_demo.c    panels, windows, styles, frames, status, key loop
   tui_keys.c    symbolic report for every decoded key
   tui_dialog.c  menu/list/input/checkbox/modal confirmation
   ```

   They use only shipped headers/libraries, contain no escape sequence or box
   byte, derive layout from `tui_get_size`, check errors, and always call
   `tui_shutdown` on normal exit.
3. Extend `tests/test_sdk_package.py` so the exact package list includes both
   archives, both headers, `docs/tui.md`, and the examples; build all examples
   from an unpacked SDK outside the repository. Run at least `tui_demo` and
   `tui_dialog` from an injected card in the simulator.
4. Bump `KOS_SDK_VERSION` from `0.1.0` to `0.2.0`. Do not change the EXE ABI.
   Reproducible packaging, header closure, archive metadata, and forbidden-path
   checks remain exact.
5. Audit the entire architecture section-9/10 API. Every declaration has one
   definition, every numeric constant matches, optional archive extraction is
   preserved, and no implementation entry is accidentally exported as public
   API.
6. Run complete simulator acceptance on production V9958/HID and
   `console-serial`: core screen/window/style/key/region outcomes, write-count
   batching, widget form, all three examples, malformed input recovery, and
   clean terminal restoration after every exit. Reuse the accepted OS/backend
   images as fixtures and record their hashes before and after; this package
   must not rebuild or change them merely to validate user-mode code.
7. Measure and record:
   - `libtui.lib` and `libtui_widgets.lib` archive/member sizes;
   - no-TUI `hello.exe`, core `tui_demo.exe`, and widget
     `tui_dialog.exe` image/BSS/stack totals;
   - first full-form flush WRITE count, unchanged flush count, and changed-row
     flush count;
   - any skipped or pending physical step.
8. Reconcile documentation with the final source. Do not turn the architecture
   document into history or add package/date language to public docs.

## Physical acceptance

Copy the standalone-SDK-built examples to the card and record:

1. V9958/HID: frames and reverse styles render correctly at 85 x 26; every
   listed key reports correctly; dialog edit/navigation/accept/cancel works;
   exit restores normal style and a visible cursor.
2. Serial: configure an 85 x 26 VT100-compatible terminal; run the same
   executables and key/dialog checklist; confirm no raw protocol text is shown
   and exit restores the terminal.

If hardware or a suitable serial terminal is unavailable, mark the individual
rows `PENDING` with executable hashes and exact owner steps. Never infer a pass
from the simulator.

## Acceptance

- Packages 66-72 and the scoped TUI/SDK suite pass after forced recompilation
  of the user libraries, probes, outcome program, and SDK package.
- An application author can build the examples with the tarball alone and can
  write a panel/menu application from the shipped headers and docs.
- The first useful core (`libtui`) and optional widget layer remain separable.
- No IOC, HID, console, V9958, kernel, firmware, or EXE ABI change was needed.

## Constraints

- Fix only TUI v1 integration/acceptance defects. New controls, colors,
  terminal discovery, mouse, graphical UI, or OS API work requires another
  architecture package.
- Do not add a TUI executable to the production ROM/store.
- Do not use the repository-wide `make clean`, `make check`, or `make test`
  gates for this user-mode-only package. They rebuild and validate unrelated
  kernel, driver, module, ROMFS, and system-image work that package 73 neither
  changes nor owns.
- Preserve unrelated and user-owned changes, including the architecture input.
- Record `docs/validation/<date>-tui-sdk-v1.md` with commands, hashes,
  measurements, simulator results, physical checklist, and pending items.

## Validation

Develop with focused commands. After the source is frozen, force a scoped
rebuild so no stale TUI/SDK object can satisfy the gate:

```sh
make -B build/user/tui_test.exe \
    build/user/tui_core_probe.exe \
    build/user/tui_widget_probe.exe \
    sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_source_layout
git diff --check
```

The two console images used by `tests.test_tui_sim` are accepted fixtures, not
package outputs. Record their pre/post hashes and require byte identity. If a
fixture is absent, build only that explicitly named image target; do not expand
the gate to the full OS suite. Capture final archive, executable, SDK tarball,
and fixture hashes after this scoped validation.

