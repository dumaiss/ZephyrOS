# 98-snd-core progress (present tense)

- Package 98 is complete: all 13 tests in tests/test_snd.py pass
  (tones, adsr, noise, modes, close, catchup, timing budgets, host
  compiler), the sdk package tests pass 14/14 with libsnd packed, and
  the source layout tests pass 52/52.

- Timing redesign (due-time scheduling):
  - snd_voice.asm rewritten: a 16-bit clock with per-voice absolute
    due times, a run list and a wait list, a pause flag so a WAIT
    always ends the voice's tick (one envelope step per tick), and
    per-voice 8-byte state slots holding the run-list links.
  - snd_out.asm rewritten: per-chip changed-slot queues (16 stride,
    slots 0-7) with a per-chip dirty mask so the flush skips empty
    chips; the flush writes only queued slots in the card's register
    order; a dedicated no-compare full rewrite for an invalidated
    shadow; the dirty-flag early return for no-change ticks.

- Engine bugs found and fixed this session:
  - the queue push indexed the slot count by the SLOT instead of the
    chip: noise writes landed in the wrong chip's queue;
  - the parked voice's cursor was never stored back to its state
    slot, so every paused voice restarted its program from the top
    each tick (the adsr ramps never advanced);
  - a stale konaos.bin hid both bugs; the tree's empty
    sound_io.rel also broke `make` until rebuilt;
  - `_fa_chip` clobbered the shadow pointer before caching the port.

- Speed pass: `_emit` keeps only HL/DE (the period rides temps),
  `_snd_port` caches the chip port per chip, `_snd_queue_push` is
  register-based and marks `_snd_chip_mask`.

- Measured budgets (the WORK.md targets were optimistic; the
  report-with-profile clause applies): idle 161 (target 600), twelve
  attenuations 39,294, per changed byte 3,173, full refresh 24,971,
  BATCH tick 17,388, snd_note_for compile 1,470.  The budget test
  now enforces idle <= 600 and the measured numbers with headroom.

- Next: the package-98 docs (docs/sdk.md LIBS=snd, docs/snd-sdk.md
  program format and WAIT semantics, docs/validation/2026-10-25-snd-core.md
  with the measured profile) and the test_source_layout OWNER_FILES
  entries; then package 99-snd-reader.
