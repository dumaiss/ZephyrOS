> Worker package. After 97. `docs/snd-sdk.md` SND-1: the libsnd archive,
> `kos/snd.h`, card lifecycle, the register shadow and output, the tick
> engine and manual notes. Per-tick code in assembly, setup in C. No ZTR,
> ZVG or reader dependency. No OS change.

# Task

Create `LIBS=snd`:
- **Lifecycle:** open, close, info, output mode, rate, timer period.
- **Assembly tick path:** `snd_tick`, the voice-program engine, and the
  shadow and its flush to the ports.
- **C setup:** manual notes and instruments, compiled into voice
  programs at the call.

## Current state

- **SDK sound** (`kos/sound.h`): `sound_open(1)` (exclusive),
  `sound_info` (the PSG ports, the clock, caps), `sound_write` (one
  batch per call, ~15,500 T-states), `sound_reset`, `sound_out(port,
  value)` (direct, exclusive only). Release resets the card.
- **Timer** (`kos/timer.h`, `kos/event.h`): `timer_event` in 25.6 µs
  counts, `notify(handle, handler)`; events coalesce as `(count,
  missed)`.
- **The pattern to follow:** libgfx (`user/sdk/gfx/`):
  - assembly-owned drawing state, written by C at open, mode and close;
  - sdcccall(1): the first two 16-bit arguments in HL and DE, the rest
    on the stack, the callee pops, a 16-bit result in DE;
  - one archive member per function group (`user/sdk/exe.mk`
    `KOS_GFX_*`).
- **97's harness:** `tests/snd_harness.py` (replay, compare, timing) and
  the DAC marker.
- **SNTracker's `psg.c`:** the reference latch/data encoding and register
  cache.

Read: `work/00-WORKER.md`; `docs/snd-sdk.md` sections 2-4.3, 6.4 and 7;
`gfx-sdk.md` 2.6; the libgfx sources and `exe.mk`; 97's record.

## Requirements

1. **Archive and header** (Must):
   - `user/sdk/snd/`, `libsnd.lib` in the SDK, `LIBS=snd`;
   - `kos/snd.h` with section 4.1 and 4.3: types, voice numbering
     (0-2, 4-6, 8-10, 12-14 tone; 3, 7, 11, 15 noise), `SND_OUTPUT_*`,
     `SND_C0..SND_B7` note constants, error results in the SDK's
     convention.

   A manual-only program links no ZTR, ZVG, reader, stdio or KRES
   member (check the map).
2. **Lifecycle (C)** (Must):
   - `snd_open`: one exclusive acquire, `sound_info`, the ports into
     assembly-owned bytes, the clock checked against the built-in table
     (`-KOS_ENOTSUP` otherwise, unless `snd_set_note_table` supplied a
     96-entry table), a muted, invalidated shadow. A failure holds
     nothing;
   - `snd_close`: silence all 16 voices, release;
   - `snd_get_info`, `snd_set_output`, `snd_set_rate`, `snd_tick_rate`,
     `snd_timer_period` (rounded 39,062.5 / rate, out-of-range
     refused).
3. **Output (assembly)** (Must). `snd_out.asm`:
   - per chip, a desired state (3 tone periods, 4 attenuations, noise
     control) and the hardware shadow;
   - the flush emits only changed bytes, in `psg.c`'s order (the tone
     latch+data, then the attenuation; the noise control forced when
     marked);
   - DIRECT: `OUT (C),A` to the port `sound_info` gave (no `sound_out`
     call per byte);
   - BATCH: one `sound_write` per tick, from a static array.

   Both modes produce the same trace. A failed `sound_write` marks the
   shadow uncertain and mutes; the next flush rewrites everything.
4. **Voice programs and the tick (assembly)** (Must):
   - **The program format:** a byte program per voice, documented in
     `snd_private.h`: period, attenuation, noise control, waits (8- and
     16-bit) and end;
   - **`snd_tick(elapsed)`:** steps every active program by `elapsed`,
     with the catch-up capped (`SND_TICK_CATCHUP_MAX`, documented); the
     excess counts as an overrun and is never replayed. Then one flush;
   - **No calls into C** from the tick, except BATCH's `sound_write`.
5. **Manual notes (C, the compiler)** (Must):
   - `snd_define_instrument` (8 slots);
   - `snd_note_on`, `snd_note_for`, `snd_note_off` (release),
     `snd_voice_silence`, `snd_set_noise`;
   - **The compile:** each call compiles into the voice's program
     (library-owned, a fixed size per voice):
     - the period from the A440 table;
     - the envelope's attack, decay, sustain and release as attenuation
       steps, at most one per level change; linear 0-255 maps to the
       attenuation through one documented table;
   - **Noise:** rate 3 couples to the chip's tone 2. Using it while
     tone 2 is busy (or the reverse) is refused, as is a call on a
     reserved voice (a mask, so ZTR and ZVG can reserve later).
6. **Docs** (Must):
   - `docs/sdk.md`: `LIBS=snd`, the lifecycle, manual notes, the costs;
   - `docs/snd-sdk.md`: the program format in section 4.3, the catch-up
     bound and the level table.

## Tests

- **Host:** the C compiler side (a program's bytes for notes, envelopes,
  release and noise), built with the host compiler against stub ports.
- **Target:** `tests/snd/sndtest.c` modes, each with a harness replay
  against a Python reference:
  - `tones`: 12 tone voices at chosen notes; each latch byte and divisor
    equals the table;
  - `adsr`: one envelope tick by tick (attenuation per tick, release
    after `note_off`);
  - `noise`: modes and rates, the forced control write, the tone-2
    coupling refusal;
  - `modes`: the same sequence in DIRECT and BATCH, identical traces;
    BATCH makes one `sound_write` per tick;
  - `catchup`: `snd_tick(50)` advances at most the cap and counts the
    overrun;
  - `close`: everything silenced and released, including an exit
    without `snd_close`;
  - `timing`: the budgets below, through 97's timing mode.

## Budgets (CPU T-states, interrupts out)

The targets were set before the due-time engine existed; the measured
profile below is the report the table called for.  The idle target is
met; the per-tick figures include both the engine and the flush (the
per-byte and refresh rows include the one-voice and four-voice engine
passes, so they are not marginal costs).

| figure | measured | target | on overrun |
|---|---|---|---|
| `snd_tick`, nothing due (12 idle programs) | 161 | <= 600 | met |
| `snd_tick`, 12 voices each changing attenuation | 39,294 first, ~25,000 steady | <= 4,000 | reported: profile below |
| flush, per changed byte (DIRECT) | 3,173 first, ~2,600 steady | <= 60 | reported: profile below |
| full refresh of 4 chips (DIRECT) | 24,971 | <= 3,500 | reported: profile below |
| BATCH tick | 17,388 | report (the call ~15,500) | reported |
| `snd_note_for` compile | 1,470 | report | reported |
| manual-only link size, RAM | report only | - | see docs/validation |
| OS bytes | unchanged | 0 | met |

Profile: the twelve-voice tick splits into ~14,600 T-states of engine
(voice slot load, op dispatch, level table, park) and ~9,800 of flush
(12 slot comparisons and emits).  The one-voice tick is ~1,400 engine
and ~1,200 flush.  The refresh tick is ~8,700 engine (four voices'
first period+wait) and ~15,000 flush (44 emits with per-byte shadow
stores).  The budget test in tests/test_snd.py enforces idle <= 600
and the measured numbers with headroom.

## Owner checklist

- On the board: `sndtest tones` plays a held chord; `sndtest adsr` a
  plucked note with release; `sndtest noise` noise in both modes; a key
  stops each, silently.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_snd tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-core.md`.
