> Worker package. After 85. Implements `docs/gfx-sdk.md` sections 12, 13
> and 14 (GFX-4), then the v1 completion criterion (section 23).

# Task

Text: the built-in font as a RAM copy, mutable glyphs, and the two-stage
renderer (expansion, then the opaque pixel sink) in G6 and G7.

## Current state

- The pinned font: `drivers/v9958/assets/font_cp850_6x8.inc` (packed by
  `tools/fontpack.py`); bits 7..2 of a row byte are the six pixels.
- The console's direct renderer shows the expansion approach:
  `drivers/v9958/v9958.c:v9958_expand_init`, `v9958_io.asm:_v9958_out_flush`
  (three 256-entry pages per colour pair, one VRAM address per scanline).
- Board figures: direct glyph write about 1,620 T-states, HMMM about 3,380
  (packages 76/77 records).

## Requirements

1. **Font** (Must): the built-in font as a `const` table in libgfx
   (generated from the pinned asset at build), copied at `gfx_open` into a
   2,048-byte RAM font; `gfx_font_set_glyph` (low six bits significant),
   `gfx_font_reset_glyph`, `gfx_font_reset`.
2. **Expansion** (Must): G6: three 256-entry tables per colour pair, a
   small cache of recent pairs (record the size); G7: one byte per pixel.
3. **Opaque sink** (Must): data-port writes, one VRAM address per glyph
   row; a string is one run.
4. **Separation** (Must, structural): the expansion and the sink are
   separate functions behind a sink interface, so a transparent sink
   (LMMC with TIMP, R#17 without auto-increment) is one more sink; state
   in the record how it plugs in. Not implemented here.
5. **Calls** (Must): `gfx_text`, `gfx_text_n`, `gfx_text_width`
   (`count x 6`); single line, byte-oriented, clipped at the right edge;
   G6 x even; YJK mode `-KOS_ENOTSUP`. Pending batch flushed first.
6. **gfxdemo** (Must): the section 23 demo (fills, copies, text in two
   colour pairs, a redefined glyph drawn, restored and drawn again),
   `UserSoftware/GfxDemo/`, like `pview`.
7. **Docs** (Must): `docs/sdk.md`; remove the graphics roadmap item from
   architecture section 14 when GFX v1 is complete.

## Tests

- Text decoded from the peer's VRAM in both modes and two colour pairs;
  a redefined glyph and its reset; the right-edge clip; G6 odd x refused.
- The gfxdemo replay and the console restored after it.

## Owner checklist

- `pview` (package 84) and `gfxdemo` on the board: the v1 completion
  criterion of `docs/gfx-sdk.md` 23.

## Validation

```sh
make && make sdk && make -C UserSoftware/GfxDemo test
python3 -m unittest tests.test_gfx tests.test_sdk_package
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-gfx-text.md`.
