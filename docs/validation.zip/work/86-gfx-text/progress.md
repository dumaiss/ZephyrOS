# Package 86: GFX text (font, expansion, opaque sink, gfxdemo)

## Contract

`work/86-gfx-text/WORK.md` — GFX-4, `docs/gfx-sdk.md` 12/13/14 + the v1
completion criterion (23).

1. **Font** (Must): const 2,048-byte table generated from the pinned
   asset at build; copied at gfx_open into the RAM font;
   gfx_font_set_glyph (low six bits significant) / reset_glyph / reset.
2. **Expansion** (Must): G6 three 256-entry tables per colour pair with
   a small cache of recent pairs (record the size); G7 one byte per
   pixel.
3. **Opaque sink** (Must): data-port writes, one VRAM address per glyph
   row; a string is one run.
4. **Separation** (Must, structural): expansion and sink are separate
   behind a sink interface; record how a transparent sink plugs in.
5. **Calls** (Must): gfx_text, gfx_text_n, gfx_text_width (count x 6);
   single line, byte-oriented, clipped at the right edge; G6 x even;
   YJK -KOS_ENOTSUP; pending batch flushed first.
6. **gfxdemo** (Must): section 23 demo, UserSoftware/GfxDemo/, like
   pview.
7. **Docs** (Must): docs/sdk.md; remove the graphics roadmap item from
   architecture section 14.

## Design decisions

- Font generation: `tools/fontpack.py table` emits
  `build/user/sdk/gfx/font_builtin.inc` (SHA-verified); gfx_font.c
  includes it inside the const array; exe.mk's gfx rule gains
  `-I $(EXE_SDK_BUILD)/gfx` and gfx_font.rel depends on the include.
- Pair cache: 2 entries x (active, fg, bg, 3x256 pages) = 1,542
  bytes BSS plus the 1-byte round-robin pointer, built on demand.
- RAM font: 2,048 bytes in gfx_state (BSS); gfx_open memcpy's the
  const table.
- Sink interface: `struct gfx_text_sink { void (*emit)(sink, col, y,
  row, row_bytes); }`; the opaque sink sets one VRAM address per glyph
  row and streams.  The transparent sink plugs in by replacing emit:
  it would start one LMMC with TIMP per string (R#46 code, R#17 with
  auto-increment off) and feed each expanded row through R#44, letting
  the chip skip colour-0 pixels; the font, the expansion and the text
  calls stay as they are (gfx-sdk.md 14).
- Text members: gfx_font.c (font calls) and gfx_text.c (expansion,
  sinks, text calls).
- Clip: whole glyphs only; a glyph whose right edge crosses the mode's
  width is not drawn.
- gfxdemo: G6 top/bottom bars, fills copied to two spots, text in two
  pairs, a redefined glyph drawn then reset and drawn again, a key.

## Status

- [x] read gfx-sdk.md 12-14/23, the font asset, the driver expand path
- [x] fontpack table mode + build wiring + gfx_font.c
- [x] gfx_text.c (expansion, sink, calls) + gfx.h + gfx_internal.h
- [x] gfxtest text mode + GfxDemo
- [x] tests (both modes, two pairs, redefined/reset, clip, odd x,
      YJK refusal, demo replay + restore)
- [x] docs (sdk.md, architecture roadmap item)
- [x] validation batch + record
