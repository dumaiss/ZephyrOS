# Correction 01: copy paths for every caller-buffer location

Applies to package 39. Read it with the package; where they differ, this
correction wins. It **supersedes architecture 36.8's "Copy paths" bullet and
the claim that data moves in a single `LDIR`.** The supervisor amends 36.6
and 36.8 after this package closes; do not edit the architecture.

## Why

The package-35 `rsvc_copy_run` is one `LDIR`. That is valid only because
every spike caller buffer was in `0000h-1FFFh`, the caller window that mode
11 shows while `6000h-DFFFh` shows bank 6. For any other caller buffer:

- `6000h-DFFFh` of the caller's bank, or bank N behind the aperture, needs
  the window, which then cannot show bank 6 at the same time;
- `2000h-5FFFh` of the caller's bank is never visible in mode 11.

So the measured 165.6 T/B covers only one case.

## Requirements

1. **Service buffer placement rule.** A service buffer that is the source
   or target of `copy_in`/`copy_out` (I/O buffers, caches, staging) lives in
   bank 6's **`8000h-BFFFh`**. Give the service images a linker area for it,
   and make the test services follow the rule. The validator rejects a
   copy from a service address outside that range only if the slow path
   (C) is unavailable. Otherwise it allows the copy and counts it as slow.
2. **The copy primitive picks a path per request**, all bounds-checked as
   now:
   - **A: caller window.** The caller buffer is in `0000h-1FFFh`, or the
     buffer is in common. One `LDIR` in mode 11, as today.
   - **B: aperture copy.** The service buffer is in bank 6's `8000h-BFFFh`
     and the caller buffer is outside `8000h-BFFFh` (in the caller's bank
     with P = 0 at capture). Switch to mode 10 with Q = the caller's bank
     and P = 1, so the aperture shows bank 6 and the rest shows the caller.
     Do one `LDIR` and restore the latch exactly.
     - The code that runs in mode 10 must be in common, since bank 7 is not
       mapped there. Keep that stub minimal and report its common bytes.
     - P = 1 here is nucleus-internal. Applications still never receive a
       token for bank 6.
   - **C: everything else.** Typical cases are a caller buffer in
     `8000h-BFFFh`, or a service buffer outside `8000h-BFFFh`. Use the
     existing `zos_bank_copy` gate, or, if it is clearly cheaper and small,
     a chunked two-hop copy through a fixed-core bounce buffer of at most
     256 bytes. Pick one, and justify it with bytes and T/B.
     - Correctness is required for every combination; speed only for A and
       B.
     - A bounce buffer in common needs the supervisor's approval first.
3. **Descriptors** capture the full latch (Q, mode, P). When a later
   package resolves an aperture buffer (P ≠ 0, address in `8000h-BFFFh`)
   to bank 7 − P, it lands on path C. Leave a clear hook for package 43;
   do not implement tokens.
4. **Interrupts.** A CTC0 interrupt during a path-B copy (mode 10, P = 1)
   must restore the latch exactly. Test it.

## Tests and measurements

Extend `ipc-selftest`. Run the chained 512-byte read (`app → vfs → fat →
ioc`, direct copies) and a single `copy_out`, with the caller buffer at:

- `0100h` (path A);
- `3000h` (B);
- `7000h` (B);
- `C000h` (B);
- `9000h` (C, primary bank, P = 0).

Run one case with the service buffer outside `8000h-BFFFh` (C). Report the
T/B for each case against package 35's 165.6 and M9's 587.8, and confirm
the bytes arrive intact. Also add a forged-descriptor case for each path.

Report:

- the common bytes added by the B stub (current common use is 2,106 of
  the 3,072 ceiling);
- the fixed-core bytes of any bounce buffer;
- the updated `ipc-selftest` ledgers.

## Constraints

Production stays byte-identical, as in package 39. Keep the package's
validation batch and add nothing else to it.
