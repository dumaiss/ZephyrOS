# Task

M10 stage 3 (architecture 36.24, step 3). Promote the package-35
resident-service IPC substrate from the spike into the nucleus:

- endpoints, `lookup`/`call`/`register`;
- the 32-byte frame;
- buffer descriptors and the copy primitives;
- the nesting and re-entrancy rules;
- the shared service stack;
- IRQ delivery to service handlers.

Prove it with the spike's synthetic services, loaded into bank 6. Then
retire the spike configuration.

## Context

Read:

- `docs/architecture.md` 36.7-36.10 and 36.14;
- `work/M10-REFERENCE.md` (reuse table);
- the package-35 report;
- the spike sources: `tests/target/rsvc/` (`rsvc_core.c`, `rsvcgate.asm`,
  `rsvc_asm.asm` and the synthetic services), `tests/test_rsvc_spike*.py`;
- package 38's layout and gate work.

The spike's 49 checks are the starting conformance suite.

From package 38:
- the fixed upcall shim is `kernel/memory/upcall.asm`;
- placement is enforced through `config/residency.json` and mapcheck;
- the spike kept its own evaluation placement because its loader runs
  while the window shows bank 6.

In this package, test-service loading runs as cold code. It reaches bank 6
only through the shim or the copy primitives, and no loader stays in the
fixed core. The spike's `irq-in-domain` expectations were already updated
to the P-normalizing gates.

## Requirements

1. **Substrate in the nucleus** (`kernel/ipc/` or similar), all in the
   fixed core:
   - the endpoint table (36.7 fields);
   - `register`, `lookup(class, instance)` and `call(handle, op, frame)`;
   - the 32-byte request/reply frame, copied in and back;
   - descriptors captured at entry from the saved latch (36.8) as small
     ids, plus `copy_in` and `copy_out` with bounds checks. Copies use
     the window `LDIR` for offsets `6000h-DFFFh`, the caller window for
     `0000h-1FFFh`, and `zos_bank_copy` otherwise;
   - direct copies down a chain (a descriptor id passed on);
   - nesting limit 4;
   - refusal of re-entrant calls (`ZOS_EBUSY`) unless the endpoint is
     flagged re-entrant;
   - the same-domain fast path;
   - the 512-byte service stack reserved by package 38.

   Promote the spike code; do not redesign it. Where the spike took a
   shortcut that the architecture forbids, fix it and say so.
2. **IRQ ownership by services:**
   - IRQ claim and release for a service handler;
   - delivery as in 36.10: the IRQ entry's own latch slot, the ISR stack,
     the owner's window, a restricted API with no IPC, and an exact
     restore.

   The trampoline latch bug found in package 36 must not reappear.
3. **Syscalls:** `SYS_IPC_LOOKUP` and `SYS_IPC_CALL`.
   - Pin the numbers in a new `abi/zos/ipc.h` and document them in
     `docs/abi.md`.
   - Add SDK client support in `user/sdk` (lookup cache, call, descriptor
     argument conventions).
4. **Bank-6 test loading.** The synthetic services (echo, console-like,
   the vfs→fat→ioc chain, the IRQ-owning service) stay **test fixtures**.
   Load them into bank 6 for an `ipc-selftest` image the way the spike
   did. The real service-image format comes in package 40; do not invent
   it here.
5. **Retire the spike.**
   - Remove `ZOS_RSVC_SPIKE`, `tests/target/rsvc/`'s substrate copies and
     the spike Makefile targets.
   - The conformance checks move to `ipc-selftest` and its test module.
6. **Production does not link the substrate yet.** Bank 7 is full after
   package 38 (cold half: 158 bytes free, arena 0 granules free; fixed core:
   979 bytes free). The substrate is built only into test images (classified
   `fixed-required` in `config/residency.json` for those images). Production
   adopts it in package 41, when the arena drivers leave bank 7. Report the
   substrate's fixed-core cost against package 35's 3,900 code plus 343
   data.

## Constraints

- No real driver, console or VFS migration (packages 41-42).
- The production image is byte-identical (`d017f133…`).
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation

```sh
make clean && make check
make ipc-selftest            # the C1-C8 conformance checks, cycles, stack high-water marks
make m9-selftest
git diff --check
```

Report:

- the null-call, 512-byte chained-read and IRQ-delivery cycles against
  package 35;
- the service-stack and gate-stack high-water marks;
- the five ledgers.

Target: under 20 minutes.

Hardware (owner): run the `ipc-selftest` image and `make smoke-hardware`.
IRQ during a service call is hardware-authoritative.

## Acceptance criteria

- `ipc-selftest` passes the promoted conformance suite on revision 13,
  including descriptor forgery and bounds rejection, nesting refusal,
  re-entrancy refusal, a service IRQ during a call, and the same-domain
  fast path.
- The spike configuration is gone.
- The production image is byte-identical, and the ledgers of the test
  images are reported.
