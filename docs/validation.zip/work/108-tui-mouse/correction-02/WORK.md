# Correction 02

Two SDK defects that package 108b found in placed programs. The 108 and
correction-01 tree is accepted and committed or in the working tree:
build on it and preserve it. Do not touch `UserSoftware/` (the 108b
worker owns it); its two Makefiles carry their own pins until this
correction lands.

1. **Indirect calls reach unmapped code.** `tools/exeplace.py:place()`
   follows direct calls in relocations only. libtui reaches its mouse
   member through `tui_mouse_hook` (a `const struct tui_mouse_hook` of
   function pointers, `user/sdk/tui/src/tui_mouse.c`). When the placer
   puts `tui_mouse.rel`'s code in a far zone, resident `tui_shutdown`
   calls `hook->disable()` at a far address and crashes whenever that
   zone is not mapped. The first `kc` placement showed it.
2. **`PLACE=` quoting.** `mk/kos.mk` passes the pins to the shell
   unquoted, so a library-member pin `libgfx.lib(gfx_text.rel)=home`
   (documented in `docs/sdk.md`) breaks the command on its parentheses.

## Required changes

- **Placer rule:** code whose address appears in a relocation from a
  data or constant area (a function pointer stored in data) is
  resident, with its resident closure, like any other resident root.
  This is general: it covers libtui's hook and any program's
  function-pointer tables. An explicit `PLACE=` pin to a far or home
  zone for such a unit is refused with a message naming the unit and
  the data that points at it.
- **Quoting:** `mk/kos.mk` (and anything else that forwards the pins)
  quotes each pin, so `PLACE=lib.lib(member.rel)=zone` works as the
  docs show, without shell quotes in the caller's Makefile.
- **Docs:**
  - `docs/sdk.md` and architecture 7.2 state the function-pointer rule
    and the library-member pin form;
  - the `kos.mk` header comment matches.

## Validation

Read `work/00-WORKER.md` first (`progress.md` in this directory,
failure classification, no source edits after the frozen-sources
message). SDK and host-tool only: no `make check`. Once, at the end:

```sh
make && make sdk
python3 -m unittest tests.test_exeplace tests.test_tui tests.test_tui_sim \
  tests.test_sdk tests.test_sdk_package tests.test_place tests.test_pack_image
git diff --check
```

If a module in the list does not exist, run the placement tests that
do (`rg -l exeplace tests/`) and record which. Before the batch,
message "main": sources frozen, plus the sha256 of `build/konaos.bin`.
Record: append a "Correction 02" section to
`docs/validation/2026-11-01-tui-mouse.md`.

## Acceptance criteria

- **A unit test in the placer's test module:** a program whose resident
  code calls through a const table into a module that would otherwise
  go far places that module resident.
- **A refusal test:** pinning that module far fails with the message.
- **A build check:** a program built with
  `PLACE=libtui.lib(tui_mouse.rel)=resident`, written unquoted in its
  Makefile, links (the `tui_mprobe` or `tui_mouse` example may be
  placed for the check).
- **No placement regression:** every placed program in the tree links
  as before or with more resident code. Record each one whose
  placement changed.
- Existing tests pass unedited, apart from pins that follow these
  changes (cite this file for each).
