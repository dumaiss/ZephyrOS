# Progress, correction 02

STATUS: in progress

- Read: 00-WORKER.md, WORK.md, exeplace.py, kos.mk, docs sdk.md/architecture 7.2.
- Dirty tree classified: 108/correction-01 SDK work + 108b UserSoftware (not mine). tools/exeplace.py,
  mk/kos.mk, tests/test_exeplace.py, docs/sdk.md, docs/architecture.md are clean in git status (mine to edit).
- Plan: place(): code targeted by edges from data/const units -> resident roots; pin to non-resident of such a
  unit -> PlaceError naming unit and pointing data. kos.mk: single-quote each pin in $(1)_PINS use.
- Note: UserSoftware/KonaEdit and KonaCommander Makefiles carry literal shell quotes in PLACE=; after kos.mk quotes
  the pin they must drop them (108b worker's file; reported, not edited).

STATUS: STEER REQUIRED (no source edited)

Blocker (verified with exeplace.read_archive on build/user/sdk/libtui.lib and an sdcc compile of tui_mouse.c):
- SDK libraries are compiled without --constseg RCONST (user/sdk/exe.mk lines 44, 122, 147, 175, 202, 249, 282 use
  EXE_CFLAGS only; --constseg RCONST is only in mk/kos.mk for program sources). libtui.lib(tui_mouse.rel) therefore
  holds `tui_mouse_ops` in its _CODE area (T 28: `2E 00 6F 02 8F 02`), relocated by area-relative (mode 00, no R_SYM)
  words `R 00 00 00 00 00 04 00 00 00 06 00 00 00 08 00 00`. The relocation record names the area it lies in (_CODE)
  and the target area (_CODE): a function-pointer table and an instruction operand are indistinguishable.
- Exeplace.Module._parse also skips every relocation without R_SYM (`if not mode & R_SYM: continue`), and SDCC emits
  the table words area-relative even for global functions, so the rule would need that parser extension even for
  program sources (verified: with --constseg RCONST the table lands in area 7 _RCONST with the same area-relative
  words).
- Result: the rule "relocation from a data/const area" cannot see libtui's hook as built. Per the worker rules this is
  a stop-and-report condition; options are in the report.

STEER (supervisor, citing my stop report: SDK libraries are compiled without --constseg RCONST, so their tables sit in _CODE):
do option 3 + declared list. Plan: (1) parser records area-relative word relocs from non-code areas to code areas;
data/const -> code edges (symbol or area-relative) make the target code a resident root; pin elsewhere refused.
(2) kos.mk declares per-library resident members (libtui: tui_mouse.rel) and passes them as --declared=MOD to
exeplace only (applied when the program is placed; not a pin, so fitting programs stay unplaced); program pin to
non-resident refused. (3) single-quote pins in kos.mk. UserSoftware KE/KC Makefile quotes + tui_mouse pins: 108b's.
(4) tests in tests/test_exeplace.py; (5) docs sdk.md, architecture 7.2, kos.mk header; record section in
docs/validation/2026-11-01-tui-mouse.md.
STATUS: in progress

- Implemented: exeplace.py (Module.words, pointed_units, --declared, refusal), kos.mk (KOS_POINTER_MEMBERS_tui/kres,
  $(1)_DECLARED, quoted pins), tests (TestFunctionPointers, TestLibraryPointers), Makefile tui_mplaced/tui_mdeclared.
- Found+fixed in scope: a placed program with zero veneers failed the link (veneers.asm always `.globl kos_vcall`,
  libkos vcall only pulled when veneers needed) - exposed by tui_mplaced (everything fits resident). Now .globl only
  when veneers exist.
- Library scan (declared list): grep user/sdk/{src,tui,widgets,gfx,snd,kres} for `(*`, function-pointer typedefs,
  `.dw` tables, stored addresses. Found: libtui tui_mouse_ops (table, stored in tui_mouse_hook); libkres
  kres_io_konaos_read (kres_adapter.c), kres_io_konaos (kres_adapter_mut.c), kres_cache_xmem (kres_cache_xmem.c),
  kres_cache_mem (kres_cache_mem.c: not in libkres.lib, test-only), hooks kres_create_hook/kres_flush_hook set to
  kres_create_container/kres_flush (kres_mut.c); libkos kos_stream_flush (libkos resident); libgfx gfx_text.asm
  gfx_emit_loops .dw (same module, jp (hl) inside gfx_text.rel: pointer never leaves the module); libsnd/widgets:
  none; user callbacks (read_at, event handlers) are program code.

FAILURE (validation run 1): tests.test_sdk TestSdkBoundary.test_every_program_is_declared_once_by_the_generic_rule
- one-line: declared-program list lacks tui_mdeclared and tui_mplaced.
- class: test artifact; source: WORK.md correction-02 "A build check" (a placed program with the unquoted library-member
  pin, in the Makefile) - the two programs are the added check programs. Pin changed: the expected program list in
  tests/test_sdk.py gains tui_mdeclared, tui_mplaced. No other expected output edited.
STATUS: DONE
