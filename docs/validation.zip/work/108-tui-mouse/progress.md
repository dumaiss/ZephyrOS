# 108 progress (worker memory)

Baseline: HEAD b9c616b, tree clean (git status --short empty).

## Status
- Reading contract and named files.
- COORDINATOR: no make clean && make check. Final batch once after last edit: make; make sdk;
  python3 -m unittest tests.test_tui_sim tests.test_tui tests.test_mouse tests.test_sdk
  tests.test_sdk_package tests.test_pack_image; git diff --check. Message "main" with
  sha256 build/konaos.bin before that batch.

## Done (builds clean: make build/user/tui_mprobe.exe build/user/tui_mouse.exe)
- tui.h API (TUI_KEY_MOUSE 0140h, struct tui_mouse, kinds, flags, hook struct + tui_mouse_hook ptr)
- tui_mouse.c member; hook ptr in tui_state.c; pollkey polls via hook; shutdown disables via hook
- runners: widget_menu.c (press on label, wheel), widget_modal.c (press on button)
- tests/tui/tui_mprobe.c probe + Makefile rule; example user/sdk/examples/tui_mouse.c + Makefiles + sdkpack
- tui_dialog map: no mouse member symbols; has _tui_mouse_hook (tui_state) and kos_sdcc_calls (indirect call)
## Next
- tests: test_tui_sim mouse classes (V9958 probe+example, serial probe); test_tui pins (members,
  surface, includes); test_sdk program list; test_sdk_package lists; test_source_layout list
- docs; baseline link-size comparison from git archive HEAD export

## STATUS: STEER REQUIRED (asked main)
- tests.test_tui_sim.TestTuiMouseSerial.test_enable_fails_cleanly: FAIL — enable succeeds on serial.
  Class: unknown/contract premise. Evidence: systems/console-serial.json includes hid + v9958;
  build-console-serial-selftest/modules/drivers.plan.json endpoints (11,0) and (2,0).
  Proposed: tui_mouse_enable -KOS_ENOTSUP unless console INFO flags has KCONSOLE_INFO_RENDER.
- Verified green: TestTuiMouse (both tests) on production replay (pollkey+mouse read ~64.8k T mean).
- Meanwhile: docs, test_tui pins, sdk lists.
- STEER answered "go": enable -KOS_ENOTSUP unless KCONSOLE_INFO_RENDER (tui_state.console_flags from tui_init INFO); implemented.
- tui_wide overflowed resident zone (819Bh) with the first runner code (+612/+320 B); rewrote runners compactly
  (menu: inline label scan, wheel -> LEFT/RIGHT; modal: x/end arrays), dropped hit from hook. tui_wide links.
- Own new serial test used _text (absent on plain base) -> fixed to run["lane"] (implementation of my test).
- FINAL batch green (180 run, 1 skip expected); record docs/validation/2026-11-01-tui-mouse.md. DONE.
