> Worker package. After 107 (accepted). libtui gains opt-in mouse
> events and drives the console pointer; the modal widget runners accept
> clicks. SDK only: no driver, nucleus, ABI or firmware change.
> Baseline: HEAD at the time of dispatch (106/107 committed or the
> accepted tree, as the supervisor states); preserve untracked
> `docs/KonaOS Programmer's Guide.pdf`.

# Task

A libtui program calls one function to get the mouse: the pointer
appears and follows the mouse, and clicks, releases and the wheel come
through the same key loop as keys, in cell coordinates. The modal
runners (menu, message box, confirm) answer to clicks and the wheel.
A program that never enables the mouse behaves and links as before.

## Current state

- Mouse and pointer SDK (106/107): `user/sdk/include/kos/mouse.h`,
  `user/sdk/src/mouse.c`: `mouse_open`, `mouse_init`, `mouse_track`
  (position clamped to an area, `pressed` latch, wheel total),
  `pointer_open`, `pointer_move`, `pointer_hide`, `POINTER_WIDTH` 510,
  `POINTER_HEIGHT` 208. One `mouse_track` ≈ 31,900 T-states with an IOC
  command.
- libtui: `user/sdk/tui/src/` (`tui_key.c` decoder, `tui_lifecycle.c`
  init/shutdown, `tui_internal.h` state); `user/sdk/include/tui.h`,
  `tui_widgets.h`; widgets in `user/sdk/widgets/`. `tui_getkey` calls
  `idle()` (`user/sdk/src/idle.c`: HALT until the next timer tick, 6.4
  ms) between empty polls. The modal runner is a separately linked
  member so render-only programs do not link it (docs/tui.md Widgets).
- Key values: `docs/tui.md` Keys table (`0101h`..`012Ch`).
- Serial console builds publish no `/dev/video` and no mouse.
- Tests: `tests/test_tui_sim.py` (replays examples and probes with
  `IocCommandPeer`, which takes `mouse_reports`).
- Docs: `docs/tui.md`; `docs/konaos-tui-sdk-architecture.md` 3 lists
  mouse as a non-goal.

Read: `work/00-WORKER.md`; `docs/tui.md`; `docs/sdk.md` mouse section;
the files above.

## Requirements

1. **Enable/disable** (Must): `int tui_mouse_enable(uint8_t flags)`
   after `tui_init`: opens the mouse and the pointer, tracks over the
   pointer area, shows the pointer. Returns 0, or a negative error when
   either is missing (serial console, no mouse driver); the program
   stays keyboard-only. `tui_mouse_disable()` hides the pointer and
   releases both handles; `tui_shutdown` calls it. Flag
   `TUI_MOUSE_MOTION`: also report motion without a button held.
2. **Events through the key loop** (Must): `TUI_KEY_MOUSE` (`0140h`)
   from `tui_pollkey`/`tui_getkey` when an event is pending; keys
   already decoded come first. `int tui_mouse_get(struct tui_mouse
   *ev)` returns the event: `col`, `row` (screen cells: pixel x / 6,
   y / 8, clamped to `tui_get_size`), `buttons` held, `pressed`,
   `released`, `wheel` (signed notches), and the kind (press, release,
   wheel, motion; motion also while a button is held, for drags). One
   event per change; no event for a read that changed nothing.
3. **Pacing** (Must): `tui_getkey` reads the mouse once per wake of its
   `idle()` loop; `tui_pollkey` once per call when no key is pending.
   The pointer moves (`pointer_move`) only when the pixel position
   changed.
4. **Hit test** (Must): `int tui_mouse_hit(const struct tui_mouse *ev,
   <the rectangle type tui.h uses>)` with the rectangle in active-window
   coordinates, and the window-relative cell in the event
   (`wcol`, `wrow`, negative outside the window).
5. **Runners** (Must): with the mouse enabled, `tui_menu_run` returns
   the clicked item's ID and the wheel moves the selection;
   `tui_message_box`/`tui_confirm` return the clicked button's ID; a
   click elsewhere does nothing. Without the mouse they behave exactly
   as today.
6. **Link cost** (Must): a program that never calls
   `tui_mouse_enable` links no mouse member: the runners reach mouse
   code through a hook the enable call installs. Prove it with the map
   of an existing example (`tui_dialog`): no mouse symbol.
7. **Example** (Must): `user/sdk/examples/tui_mouse.c`: a menu bar, a
   clickable checkbox and button (via the hit test), a scrolling list
   (wheel), a confirm box, and a status line showing the event. Shipped
   in the store like the other TUI examples.
8. **Docs** (Must): `docs/tui.md` Mouse section (API, event kinds,
   pacing, serial behaviour, link cost); key table gains
   `TUI_KEY_MOUSE`; architecture doc 3 drops the mouse non-goal and
   section 4 places the mouse; `docs/sdk.md` cross-reference.

## Invariants

- Programs without `tui_mouse_enable`: same output and key behaviour;
  `tests/test_tui_sim.py` existing cases pass unedited.
- The pointer is hidden after `tui_shutdown` and after program exit.

## Criteria

- **Must:** a replay with scripted reports shows: events with correct
  cells at both screen edges; press/release/wheel/drag kinds;
  `TUI_KEY_MOUSE` after already-queued keys; menu click returns the
  item; message box click returns the button; enable fails cleanly on
  the serial console build; `tui_dialog` map has no mouse symbol; the
  validation suites green.
- **Informational:** a `tui_getkey` wake with a mouse read, in T-states;
  the example's size.

## Owner checklist

- `tui_mouse` example: the pointer follows; clicks on the menu, the
  checkbox, the button and the confirm box act; the wheel scrolls the
  list; keys still work alongside.

## Validation

SDK-only package: no `make clean && make check`. Once, at the end:

```sh
make && make sdk
python3 -m unittest tests.test_tui_sim tests.test_tui tests.test_mouse \
  tests.test_sdk tests.test_sdk_package tests.test_pack_image
```

Record: `docs/validation/<date>-tui-mouse.md`.
