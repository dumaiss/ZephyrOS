# Correction 01

Two defects in the accepted-pending 108 tree (uncommitted, in the working
tree: build on it, preserve it).

1. **Pacing.** `tui_getkey` reads the mouse on every `idle()` wake
   (6.4 ms timer tick). One read with a pointer move costs about
   64,700 T-states (6.5 ms at 10 MHz), so a mouse-enabled program
   waiting for input keeps the CPU busy almost all the time. The halt
   in `idle()` (`user/sdk/src/idle.c`) exists to keep a polling loop's
   bus activity out of the sound card's audio band, and it barely
   happens.
2. **Lost wheel.** `user/sdk/tui/src/tui_mouse.c:tui_mouse_poll`: a
   read with a press or release and a wheel turn reports the press or
   release, then clears `m->wheel`. The turn is lost.

## Required changes

- **`tui_getkey` reads the mouse on every third wake** (about 52 Hz).
  - The wakes in between poll keys only and halt as before.
  - The first poll of a `tui_getkey` call reads the mouse, so a call
    made right after an event does not wait.
  - `tui_pollkey` called by the program keeps one read per call that
    found no key: its pace belongs to the program's own loop.
  - Implement it in libtui (`tui_key.c` and the hook), with no new
    public function. A named constant holds the 3.
- **`tui_mouse_poll` keeps the wheel** when the event it returns is a
  press or a release. The turn stays in `m->wheel`, so the next poll
  reports a WHEEL event even if that read itself brings no motion: a
  pending turn counts as a change. `ev.wheel` is nonzero only on a
  WHEEL event.
- **`docs/tui.md` Mouse section:** state the pacing (every third wake
  in `tui_getkey`, every call in `tui_pollkey`) and that a press and a
  turn in one read come as two events.

## Validation

Read `work/00-WORKER.md` first (`progress.md` in this directory, failure
classification, no source edits after the frozen-sources message).
SDK-only: no `make check`. Once, at the end:

```sh
make && make sdk
python3 -m unittest tests.test_tui_sim tests.test_tui tests.test_mouse \
  tests.test_sdk tests.test_sdk_package tests.test_pack_image
git diff --check
```

Before that batch, message "main": sources frozen, plus the sha256 of
`build/konaos.bin`. Record: append a "Correction 01" section to
`docs/validation/2026-11-01-tui-mouse.md`.

## Acceptance criteria

- New replay checks (`tests/test_tui_sim.py`):
  - over a `tui_getkey` wait of at least 30 wakes with no input, the
    IOC peer's `mouse_commands` grows by one per three wakes (±1), and
    the CPU halts on the wakes in between;
  - one scripted report with a left press and wheel +2 yields a PRESS
    event, then a WHEEL event with `wheel` 2.
- Every existing test passes unedited except where a pin follows these
  two changes (cite this file for each).
- Informational: the share of a 30-wake wait spent outside HALT, before
  and after.
