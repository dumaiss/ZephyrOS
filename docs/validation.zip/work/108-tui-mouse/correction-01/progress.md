# 108 correction 01 progress
- Done: tui_key.c (getkey reads mouse on 1st poll + every 3rd wake via tui_key_mouse_idle flag, TUI_KEY_MOUSE_WAKES),
  tui_mouse.c (wheel kept on press/release; pending wheel counts as change), tui.h comment, docs/tui.md.
- Tests: mprobe wait phase + _measure_wait in test_tui_sim; pins: press+wheel script wheel 3->2 plus a held report,
  records "mouse 1 .. 0 0" then "mouse 3 .. 1 0 0 2" (contract: press then WHEEL event).
- Baseline (before): 30 reads/30 wakes, 89% outside HALT (no pointer motion). After: 10 reads, 56%.
- Next: message main, final batch, append validation record.
