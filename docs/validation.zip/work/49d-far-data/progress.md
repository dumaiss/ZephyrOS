# 49d far data — working log

Contract: `WORK.md` (this directory).

## Part 1: spike (done, no stop condition hit)

SDCC 4.5.0, sdldz80 V03.00/V05.40.  Both kinds of object can be steered
into their own area and a pair can be based at 8000h.

1. **Flags** (`/tmp/dspike/levels.c`):
   `sdcc -mz80 -c --nostdinc --Werror --constseg DATA1 --dataseg DATA1B
   levels.c` puts `const` objects in `_DATA1` and uninitialized objects
   in `_DATA1B` (`.rel`: `A _CODE`, `A _DATA1B size 10`, `A _DATA1
   size 8`).  Without the flags, BSS goes to the program's own `_DATA`.
2. **Pair layout**: an area that gets `-b _X = 0x8000` is pinned there,
   and an unbased area is concatenated **after the preceding area in the
   area-order list** - not after the last based area.  The order list comes
   from the first input file that defines the areas.
   - `bare` (`-b _DATA1 = 0x8000`, `_DATA1B` unbased, order
     `_CODE,_DATA,_DATA1B,_DATA1` from the .rel) -> `s__DATA1B = 0185h`
     (wrong: it followed `_DATA`).
   - with a tiny order object linked **first**
     (`.area _CODE`, `.area _DATA`, `.area _DATA1`, `.area _DATA1B`):
     `s__DATA = 0181h`, `s__DATA1 = 8000h` (8 bytes), `s__DATA1B = 8008h`
     (exactly after the image) and the primary BSS stays put.
3. **Two pairs plus far code in one link** (`_FAR1` far code, `_DATA1`
   pair, `_DATA2` pair; order object `_CODE,_DATA,_FAR1,_DATA1,_DATA1B,
   _DATA2,_DATA2B`; bases `_FAR1 = _DATA1 = _DATA2 = 8000h`):
   `s__DATA1B = 8008h`, `s__DATA2B = 8004h` (each after its own image),
   `s__FAR1 = s__DATA1 = s__DATA2 = 8000h` and the IHX carries one record
   stream per area (`8000: [25, 1, 9]`) - the 49b method.
4. **Initialized non-`const` object**: `unsigned char init_value = 5;` in
   a `DATAn` source lands in `_INITIALIZED`/`_INITIALIZER` (1 byte each),
   which exepack already refuses; the refusal must name the symbol.
5. `-b` expressions cannot see area lengths: `0x8000 + l__DATA1`,
   `sizeof(_DATA1)`, `_DATA1 + l__DATA1` all evaluate the length as 0.
   Hence the order object, no second link pass.
6. A `DATAn` source with no `const` object leaves `_DATA<n>` empty: the
   row would have image_size 0, which the format forbids; the packer
   refuses it ("payload is empty"), and the rule names the segment.

## Implementation plan taken

- Row `reserved0` (offset 06) becomes `flags` (`EXE_SEG_FLAG_MAPPABLE`).
- Loader: validated in `exe_validate_segment`, placed at slot 4
  (`KOS_AUX_PLACE_FAR`) by `kos_xmem_segment_alloc`, object gets
  `KOS_XMEM_FLAG_MAPPABLE`; `blob`/`farmap` find mappable vs plain DATA
  rows through a new `flags` word in the seginfo record.
- Rules: `DATAn=SRC:SRC`, `BLOBS=a.bin:...`, generated rows
  (FARn, DATAn, BLOBS), generated area-order object linked first.
- SDK: `farmap`/`farunmap`/`blob` (seg.c), `xload` (files + xmem).

### API reading (recorded deviation)

`void *farmap(unsigned int n, unsigned char *prev)` writes the previous
latch into `*prev` on success and the negated error code as a signed byte
on failure (`*(signed char *)prev`), the 8-bit convention the SDK's
runtime codes already use; `farunmap(unsigned char prev)` restores it.
`farmap(n)`/`blob(n)` are 1-based ordinals over the mappable and the plain
DATA rows in container id order, which is what the generated layout makes
`DATAn`/`BLOBS` mean; `DATAn=` options are therefore required to be
contiguous from 1 (like `FARn=`).

## Implementation notes (what the build taught)

Three defects were found by exercising the new paths; each is fixed in
this package:

1. `mk/kos.mk`'s generated files (order object, segment declaration) and
   the `DATAn=` compile flags are written inside a `define`/`$(eval)`
   rule body, so shell variables need **four** dollars and `${n}` braces:
   `$$$${n}B`.  `$$$$nB` made the shell read `$nB` (empty) and
   `$$$$n`-with-suffix lost the number; the generated rows and the
   `--dataseg` flag were both wrong until this was fixed, and the
   `BLOBS=` copies were never prerequisites of the packer target.
2. `tools/exepack.py`'s segment loop reused the name `bss_size` for a
   row's BSS, which (Python scoping) clobbered the primary `bss_size`
   the header is built from: every packed far-data container had
   `bss_size = 0`, so the loader zeroed *nothing* and every static kept
   the previous bank's bytes (`farmap`'s handle cache started at 0xFF).
   The row variable is now `row_bss`; the host test asserts the packed
   header equals the map's `l__DATA`.
3. `kernel/syscall.c` mapped every `EXE_EXEC_ERR_* <= -0x20` to
   `KOS_EINVAL`, including `EXE_EXEC_ERR_NOSPACE`, although
   `abi/kos/syscall.h` has always documented "no free slot or bank ->
   KOS_ENOSPC".  The one resource code is now `KOS_ENOSPC`, which is what
   the bank-exhaustion test asserts.

Fixture details worth keeping: a card file must be an 8.3 name
(`/fs/big.tmp`), and `seg.c`'s `seginfo` record puts the flags word in
bytes 6-7 (the object holds 8 bits, the high byte is 0).
