> **DRAFT. Not dispatched.** Runs after 49c, before 47.

# Task

**Far data from C.** Today a program gets far data only as:
- a `DATA` segment filled from a hand-made binary file, declared in
  hand-written JSON, and reached only by copies (`xread`/`xwrite`);
- runtime objects (`xalloc`) mapped by hand.

After this package a program can do three new things:
1. **Write far data in C:** `DATA1=` … `DATA4=` sources become segments
   linked at `8000h`, holding `const` tables and zeroed variables.
2. **Use them through pointers:** `farmap(n)` opens data segment n in the
   window. While it is open, the program uses the C symbols directly.
3. **Bundle binary assets without JSON:** `BLOBS=a.bin:b.bin` adds plain
   `DATA` segments, reached by copies.

**The rule to document (hardware):** there is one far window
(`8000h-BFFFh`). Far code and mapped far data cannot be visible at the
same time:
- code in the primary image may map data and use pointers;
- a `__banked` function reaches far data only by copy (`xread`), or
  through a pointer the primary image hands it **after** copying.

Read: `work/00-WORKER.md`; the 49b record (it is the model for this
package); `user/sdk/mk/kos.mk`; `tools/exepack.py`;
`formats/include/exe.h`; `kernel/syscall/xmem.c`
(`kos_xmem_segment_alloc`); `kernel/process/process.c`
(`aux_candidates`).

## Part 1: spike (stop gate)

With SDCC 4.5.0, find and record the flags that put a C file's `const`
initialized objects **and** its uninitialized objects into areas the link
can base at `8000h`, image first and then BSS, as one segment. Expect
`--constseg DATA<n>` plus `--dataseg DATA<n>B`, or equivalents; record
what actually works.

**Stop and report** if:
- either kind of object cannot be steered into its own area;
- the linker cannot base two such pairs at `8000h` in one link (the 49b
  method).

## Part 2: implementation

1. **Segment-row flag.** The row's `reserved0` (offset 06) becomes
   `flags`, with `EXE_SEG_FLAG_MAPPABLE` (`0001h`). It is valid on `DATA`
   rows of at most 16 KiB; any other use is refused by `exepack` and by
   the loader (`EXE_EXEC_ERR_SEGMENT`).
2. **Loader:**
   - a mappable `DATA` segment is placed at **slot 4** of an auxiliary
     bank, so its image is at `8000h`, exactly where it was linked;
   - its object gets `KOS_XMEM_FLAG_MAPPABLE`;
   - it occupies an auxiliary bank's window slice, as a far code segment
     does, so far code segments plus mappable data segments are limited
     by the free auxiliary banks;
   - not enough → `-KOS_ENOSPC` from `run`, as for far code;
   - cold half only.
3. **Build rules** (`mk/kos.mk`):
   - `DATAn=SRC:SRC` compiles with the spike's flags into the areas
     `_DATA<n>` (image) and `_DATA<n>B` (BSS), both based at `8000h`;
   - `BLOBS=a.bin:b.bin` names plain payload files (at most 32 KiB each,
     relative to `DIR`);
   - **without `SEGMENTS=`, the rule generates every row:** `FARn` first
     (ids 1..k), then `DATAn` (mappable, ascending n), then `BLOBS`
     (plain, in order);
   - a `DATAn` source with an initialized **non-`const`** object is
     refused by `exepack`, naming the symbol. Far data is either `const`
     or zeroed; initialize writable data at run time;
   - `SEGMENTS=` stays for hand-written layouts.
4. **SDK** (`kos/seg.h`):
   - `void *farmap(unsigned int n, unsigned char *prev)`: opens the n-th
     `DATAn` segment and returns `(void *)0x8000`, or `NULL` with the
     error code in `*prev`. It finds the segment's handle by scanning
     `seginfo` once (cached), then calls `xmap` on that handle and
     `aperture_open`.
   - `void farunmap(unsigned char prev)`.
   - `int blob(unsigned int n)`: the handle of the n-th `BLOBS` file, for
     `xread`.
   - **`int xload(const char *path, unsigned int flags)`:** loads a whole
     file (picked at run time, not bundled) into a new object and returns
     its handle, or -errno.
     - At most 32 KiB, or 16 KiB with `KOS_XMEM_FLAG_MAPPABLE`. A larger
       file → `-KOS_ENOSPC`: such a program streams instead.
     - A mappable object is filled by `read` **straight into the open
       window** (the buffer-identity rule, 36.8): one copy.
     - A plain object is filled through a 512-byte near buffer and
       `xwrite`.
5. **Example** `user/sdk/examples/fardata.c` plus `levels.c` (`DATA1`): a
   `const` table of 4 KiB and a zeroed 2 KiB array.
   - The primary image maps it, reads the table, writes the array, then
     unmaps.
   - A `__banked` function in `FAR1` receives values copied out of the
     table, not pointers into it.
   - It is added to the examples Makefile, so `make sdk` ships it.
6. **Docs:** `docs/sdk.md` gains a "Far data" section:
   - the four kinds (`DATAn`, `BLOBS`, `xalloc`, `xload` for a file read at
     run time), and when to stream instead;
   - the one-window rule;
   - the bank budget (one auxiliary bank per far code or mappable data
     segment);
   - the costs (a banked call is about 31 µs; access through an open
     window costs nothing extra; `xread` costs 21 or 287 T-states per
     byte depending on the slot).

## Working loop and validation (targeted; no `make clean && make check`)

Put the tests in `tests/test_far_data.py` (host: rows, flags, refusals,
the generated layout; replay: the example's checks). Use these commands
while developing, and once at the end:

```sh
make
python3 -m unittest tests.test_far_data tests.test_exe tests.test_bcall
make xmem-selftest      # the allocator and loader paths, once at the end
python3 -m unittest tests.test_console_acceptance   # production still boots
git diff --check
```

## Tests (in `tests/test_far_data.py`)

- **Host:**
  - the flag is accepted only on `DATA` rows of at most 16 KiB;
  - the generated row order (`FARn`, `DATAn`, `BLOBS`);
  - an initialized writable object in a `DATAn` source is refused, naming
    it;
  - `BLOBS` over 32 KiB is refused;
  - the spike's findings, asserted on a compiled sample.
- **Replay** (the example program, or a test program in the xmem image):
  - the table is read through `farmap`, and the array is written and read
    back;
  - the mapping is undone afterwards (the caller's latch is restored);
  - a `BLOBS` file is read with `xread` and compared;
  - `read` from `/fs` and from `/system` **directly into a mapped
    object** returns the right bytes, and the caller's own memory at
    `8000h-BFFFh` is untouched;
  - `xload` of a file, mappable and plain, compared with the file; a file
    over the limit → `-KOS_ENOSPC`, and nothing leaks;
  - too many far and mappable segments for the free banks → `run` returns
    `-KOS_ENOSPC` and nothing leaks.

## Constraints

- Kernel: the loader and the row flag only, in the cold half. Fixed
  core, common and driver ledgers unchanged; report the cold half.
- Record: `docs/validation/<date>-far-data.md`, with the spike findings
  first.
