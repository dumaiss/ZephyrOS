> **Folded into package 56** (`work/56-m13-sdk-buffered-io`); not dispatched on its own.

# Correction 01: a test-harness fix, and the far-data files out of production

Runs after 49d. Targeted validation only.

## 1. A test-harness fix: `test_romfs_sim`'s scratch placement

`make subsystem-selftest` fails in `tests/test_romfs_sim.py`'s `setUp`
with `scratch E000 does not fit the window`. The image is fine: the test
assumes a free 512-byte run just above the cold data, and the subsystem
image's cold data no longer leaves one below `E000h` (most likely 49d's
149 extra cold-code bytes moved it up one step). Do not investigate the
history.

- **Fix the test only.** The scratch is the first `SCRATCH_SIZE` run of
  the window (`6000h-DFFFh`), aligned to 512 bytes, that no linked area
  in the image's map covers.
- If no such run exists, report the room left in each cold area instead.
  Do not shrink an assertion.

## 2. Remove the far-data test files from production

`far_data.exe`, `banks.exe` and `known.bin` were added to
`systems/production.json` only so that 49d's replay could run. Remove
them from the production store; production ships nothing it does not
use.

- Add them to the `fs` test image (`systems/fs.json`), which already has
  `/fs` (IOC-FAT) and `/system`.
- Point `tests/test_far_data.py`'s replay at that image. It runs from
  `make fs-selftest`, and is skipped by `make check` like the other image
  replays.
- `hwtest` is unchanged.

## Validation (targeted)

```sh
make
make subsystem-selftest                               # both of its replay suites pass
make fs-selftest                                      # includes the far-data replay
python3 -m unittest tests.test_far_data
python3 -m unittest tests.test_console_acceptance
git diff --check
```

Record: an addendum to `docs/validation/2026-10-12-far-data.md`. It
contains:
- the new scratch rule and the address it picks;
- the production store size before and after.
