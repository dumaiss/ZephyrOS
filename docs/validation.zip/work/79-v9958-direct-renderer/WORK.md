> Worker package. Runs after package 78 (the bulk-map span). Baseline:
> HEAD after 78. V9958 driver, its asset tool, tests, docs.

# Task

Replace the V9958's HMMM glyph copies with direct VRAM writes from a
1-bit font in the driver's mapped segment, exactly as
`docs/architecture.md` 5.6 ("The V9958 text renderer writes glyphs
directly") states. Fills, scrolling and LMMV/EOR inversion stay on the
command engine.

## Current state

- Glyph drawing: `drivers/v9958/v9958_io.asm:_v9958_out_flush` (pairs
  glyphs into 6x8/12x8 HMMM copies from the pre-coloured atlases in VRAM
  page one, spaces into HMMV). The print run: up to 64 glyphs on one row
  (`V9958_OUT_RUN_SIZE`, `out_run_col`/`out_run_row`).
- Atlases: uploaded at boot (`v9958_boot.c`) and at display reset
  (`v9958.c`: `v9958_upload_font_atlas`, `v9958_upload_atlas_chunk`,
  `v9958_expand_row`, `v9958_font_read`, about 430 bytes of hot code),
  from the bulk font (`v9958_font.asm`, `V9958_FONT_SIZE` 2,048, read
  through `bulk_read`).
- Font asset: `drivers/v9958/assets/font_cp850_6x8.inc` →
  `tools/fontpack.py` (bits 7..2 of a row byte are the six pixels).
- Colours: normal `04h` background / `0Fh` foreground, reverse swapped;
  `_Static_assert`s in `v9958_driver.h` tie the packed fills to them.
- Measured basis: package 77's `textbench` (`tests/bench/textbench*`):
  `txt.run1` 3,357 T/char on the board with per-glyph address arithmetic;
  the V9958 wait is 565-791 T/char. Board `con.mixed` 3,782 (package 76).
- Screen decoding in tests: `tests/test_tui_sim.py:decode_v9958_screen`
  decodes HMMM commands; `tests/test_textbench.py` decodes the peer's VRAM.

Read: `work/00-WORKER.md`; architecture 5.2, 5.6; the 76 and 77 records;
the files above; `tests/z80sim.py:V9958Peer`.

## Requirements

1. **Layout** (Must): `fontpack.py` emits the scanline-major font (eight
   256-byte pages, page `s` = row `s` of every code) for the mapped
   segment. The expansion pages (three per colour pair, page `b` maps a
   font row byte to output byte `b`) for normal and reverse are built at
   init into mapped BSS from the `_Static_assert`ed colours. Pages are
   256-byte aligned (`.bndry` or planner alignment; record which).
2. **Renderer** (Must): `_v9958_out_flush` draws the run inside one span:
   per scanline one address set (R#14 when the page changes, then the
   address pair), then per glyph three expanded bytes; the run's
   attribute selects the expansion set. Spaces are drawn as glyphs unless
   a measured HMMV run is cheaper (record the decision and the figure).
   No VRAM read, no `copy_in` inside the span.
3. **Removal** (Must): the atlases, their upload at boot and at reset, the
   bulk font and every consumer of them are deleted; `v9958.json` declares
   the mapped segment instead of the bulk one. VRAM page one is free
   (`docs/devices.md` VRAM map updated).
4. **Unchanged contracts** (Must): WRITE/PUTC/RENDER/RESET results, the
   cursor sprite, scrolling, INVERT (LMMV/EOR over the drawn pixels), the
   exclusive-hold rules (no VRAM access while held), sprites-off
   bracketing.
5. **Tests follow the subject** (Must): screen checks decode the peer's
   VRAM bitmap. Extend `V9958Peer` to apply what it does not yet apply
   (LMMV/EOR, HMMV if missing), citing the V9958 behaviour mirrored; the
   HMMM-command decoder and atlas tests are deleted, not ported. Every
   existing screen replay (TUI, shell, console, KonaCommander) passes on
   the VRAM decoder.
6. **Docs** (Must): `docs/devices.md` (V9958), `docs/memory.md` (bank 6,
   mapped ledger). Leave the roadmap item "The direct text renderer"
   (architecture section 14) for package 80.

## Invariants

- The visible screen of every replay is unchanged, cell for cell.
- `console-serial` is untouched (module hash).

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free / reserve | after 78 / 1,536 | must not decrease | stop and report |
| driver mapped | 0 of 7,936 | ≤ 3,840 (font 2,048 + pages 1,536 + alignment) | stop and report |
| driver boot/bulk | after 78 | net ≤ +1,792 | stop and report |

## Criteria

- **Must:** requirements 1-6; `make check` green; the board run below
  PENDING or PASS.
- **Should:** board `iobench` `con.mixed` ≤ 2,300 T/char and `con.write`
  ≤ 2,300 (estimate ~2,100; a miss is a finding with the profile).
- **Informational:** simulator `con.mixed`/`con.write`/`con.space` via
  `tests/console_profile.py`; hot, mapped and bulk bytes before/after.

## Simulator

`V9958Peer` models no WAIT and no access slots; its CPU figures are exact,
the board gives the wait. List the peer additions and what they omit.

## Owner checklist

- Boot, shell, `ls`, KonaCommander menus (INVERT), a TUI example,
  `ESC c`, scrolling a long listing, reverse text; then `iobench` and
  photograph the summary.

## Validation

```sh
make && python3 -m unittest tests.test_v9958 tests.test_tui_sim tests.test_shell_sim tests.test_console_acceptance tests.test_textbench tests.test_iocfat tests.test_source_layout
python3 tests/console_profile.py
make console-serial-selftest
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-v9958-direct-renderer.md`.
