# Package 79: V9958 direct renderer - progress (working memory, present tense)

Status: COMPLETE, final gate green (make check: OK).
run done (Should missed, see the record). Record:
`docs/validation/2026-10-22-v9958-direct-renderer.md`.

## Tree at start

Package 78's changes uncommitted in the tree (bulk-map span); preserved.

## Plan

1. Read: v9958_io.asm (`_v9958_out_flush`, wrappers), v9958.c (atlas,
   font, fills, scroll, cursor), v9958_boot.c, v9958_font.asm, v9958.json,
   fontpack.py, V9958Peer, the screen decoders in tests.
2. Peer: apply HMMV/LMMV(EOR) to VRAM if missing; VRAM screen decoder.
3. Font layout + mapped segment; expansion pages built at init.
4. New `_v9958_out_flush`; delete atlases/bulk font.
5. Tests moved to the VRAM decoder; targeted suites; board numbers PENDING.

## Decisions

- Mapped segment = font pages (image, `_MAPPED`, 2,048) + expansion pages
  (BSS, `_MAPPED_BSS`, 1,536), page-aligned through a new manifest
  `"align": 256` on mapped segments (`tools/modpack.py`; host test
  `test_a_mapped_segment_may_ask_for_page_alignment`). Production has one
  mapped user, but correctness must not rest on load order.
- A GRAPHIC 6 cell never crosses a 64-line R#14 page (origin and rows are
  multiples of 8), so R#14 is written once per flush.
- Inner loop: H for the font page in C (per scanline), expansion page high
  byte patched into the loop once per flush (self-modifying, hot tier is
  RAM): about 114 T per glyph scanline.
- Before the first direct write of a flush, wait for CE: an HMMV fill
  (scroll's exposed row, erase) on the same cells must finish first.

## Done

- `tools/fontpack.py paged` -> `$(MODULES)/v9958_font_pages.inc`;
  `drivers/v9958/v9958_font.asm` is the mapped segment (`_MAPPED` font
  pages 2,048 + `_MAPPED_BSS` expansion 1,536); `v9958.json` bulk ->
  mapped with `"align": 256`.
- `_v9958_out_flush` rewritten (direct writes, one span per run, CE wait
  first, R#14 once, patched expansion page); glyph command block,
  template and unused equates removed; hold helpers read
  `_v9958_state+V9958_ST_EXCLUSIVE` directly (74 review finding 1: the
  RENDER entry never set `_v9958_alt_state`).
- v9958.c: atlas upload, font read, expand_row removed;
  `v9958_span_open/close`, `v9958_expand_init` (pair tables -> 6 pages);
  init_display has no upload. v9958_boot.c: no font base. Proto init
  builds the pages. Header: atlas/font constants removed, mapped externs.
- `make` OK. Budgets: hot 31,027 -> 30,471 (-556; free 2,297); boot/bulk
  19,598 -> 21,128 (+1,530 <= 1,792); mapped 3,584 (<= 3,840). V9958 hot
  image 5,987.

- Simulator: `V9958Peer` already applied HMMV and LMMV/EOR to VRAM; it
  now applies HMMM too (`_copy`, DIX/DIY honoured; the driver's row
  copies still use HMMM). `tests/replay.py`: `v9958_cell_table` (font +
  pair tables -> 24-byte cell -> (char, attr), printable first),
  `v9958_cell_bytes`, `v9958_screen(vdp)` (final VRAM + R#23 + 4), and
  `ConsoleReplay.pump` rebuilt on the data-port write stream (cells
  collected from writes, decoded at scanline 7 byte 2; only bursts that
  start at x % 3 == 0 are text).

## Failures

- `test_shell_sim` (2 tests): first run, banner area decoded `"  "`/`"_"`
  lines. Class: implementation of the new pump - the shell logo's own
  data-port writes were read as glyphs. Fixed by the burst rule above
  (the renderer addresses column * 3; the logo starts at byte 4).
- `test_shell_sim` `assert_logo`: `14544 != 3680` logo bytes. Class: test
  artifact - it counted every data-port write in the logo rectangle as
  logo; architecture 5.6 makes text data-port writes too (source: this
  WORK.md requirement 2). Now counts the logo's 46 row addresses per start
  (`LOGO_ROW_ADDRESSES`); the VRAM content check is unchanged.
  `tests.test_shell_sim`: 3 OK.

- `test_v9958`: 8 failures, all test artifacts against the retired
  atlas/bulk font (source: architecture 5.6, WORK.md requirement 3):
  manifest roles (mapped + align), container check now pins the paged
  font (`fontpack.paged`) and the page-aligned base, `bulk_read` pins
  removed, `test_asm_fill_colours_are_the_header_colours` deleted (the
  assembly has no fill bytes), atlas lines and the upload step removed,
  the coalescing pins replaced by the flush's structure (CE wait, span,
  data-port writes, no command port, `v9958_expand_init`). 26 OK.
- Peer: `writes_at` per command, optional `snapshot_codes` (VRAM + R#23
  copied at a command). `test_tui_sim`: `decode_v9958_screen(z)` is the
  VRAM decoder; invertspan checks no data-port write between the first
  and last LMMV; renderbad checks no writes above row 22 after init;
  invertwrap decodes the two LMMV snapshots; the batch test's 12-px
  HMMM-pair count deleted (pairing retired). `test_device_release`
  `first_glyph_after` reads the write stream; `test_textbench` console
  reference decoded from its VRAM snapshot.

- Batch 1 `tests.test_tui_sim.TestTuiV9958Screen`: 24 run, 3 failed
  (styles, widgets form, rendersync: "did not finish" / `('Û',0) !=
  (' ',1)`). Class: implementation of the new decoder - a reverse space
  and a normal full block (DBh) are the same 24 bytes and the table let
  the block win, which also broke word continuity in the text model.
  Fixed: printable codes first in both attributes. The 3 rerun: OK.
- Batch 2 (device_release, textbench, console_acceptance, iocfat,
  source_layout, vblank): 92 run, 4 failed, all `assert_restored` in
  `test_device_release`: it pinned the re-uploaded font atlas in VRAM
  page one and >= 4,096 reset writes. Class: test artifact (source:
  architecture 5.6 "VRAM holds no font", WORK.md requirement 3). Now
  checks the reset rewrote the cursor pattern (1F800h..1F807h);
  `ATLAS_BASE` renamed `PAGE_ONE_BASE` (the takeover still scribbles
  there).
- Docs: devices.md V9958 (terminal, glyph drawing, RENDER TEXT, hardware
  bring-up, font) and the takeover table; konaos-tui-sdk-architecture.md.

- Rerun `test_device_release`: 2 failed `the screen below the text is
  not a cleared field` (2 != 1). Class: test artifact - it sampled VRAM
  line 8 (text row 1) as "below the text", true only while glyph copies
  were not applied to the modelled VRAM; the shell's text is there now.
  Sample moved to line 160 (row 20). The 2 rerun: OK (the other 10 passed
  in the same run).

- `make console-serial-selftest`: 6 OK.
- `tests/console_profile.py` retargeted (bucket "glyph drawing
  (out_flush)" = the whole flush; span-wait loop gone; SAT region ends at
  `v9958_init_g6`). Simulator CPU per char: putchar 2,171, printf 2,453,
  write 1,724, mixed 1,792, space 1,724, held 155; glyph drawing 917-957;
  every row within 1% (worst 0.11%). Before (package 76 record): write
  2,919, mixed 4,780 (simulator), board write 3,083, mixed 3,782.

## Done (final)

- Batch 3: serial TUI + tee + serial console 36 OK; KonaCommander 18 OK
  (its glyph counters read HMMM commands: vacuous, reported).
- Final batch after the decoder-order fix: V9958 TUI, shell, v9958,
  driver images, layout, iocfat: 160 OK.
- Board: write 2,866, mixed 3,226, space 2,885 (Should missed: VRAM
  access-slot bound, record).
