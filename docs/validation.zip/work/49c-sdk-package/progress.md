# 49c-sdk-package — progress

Working state for `work/49c-sdk-package/WORK.md`.  The report is
`docs/validation/<date>-sdk-package.md`; this file is the log.

## Done

1. **`tools/ihx.py`** (new): `LayoutError`, `parse_ihx(text, multi=False)`
   and the map parsing (`parse_map_symbols`) moved out of
   `tools/pack_image.py`.  `pack_image.py`, `tools/exepack.py`,
   `tools/exemanifest.py` and the tests import `ihx` directly; no
   re-exports.  (The two map parsers were compared on all 15 built maps:
   identical output.)
2. **`config/sdk.mk`**: `KOS_SDK_VERSION := 0.1.0`; the ABI number in the
   SDK's `VERSION` is read from `formats/include/exe.h`
   (`tools/sdkpack.py:abi_version`), never copied by hand.
3. **`mk/kos.mk`** (new): the generic `exe_program` rules, with no
   OS-tree variable (`KOS_SDK_ROOT`, `KOS_BUILD`, `KOS_PYTHON`,
   `KOS_TOOLS`, `KOS_INCLUDE`, `EXE_ABI_ROOT`, `KOS_LIB`, `KOS_MODULES`,
   `KOS_RULES` all default and are overridden by each user).
   **`user/sdk/exe.mk`** is now the in-tree wrapper: sets the in-tree
   roots and builds `libkos`/`crt0`/`runtime` from `user/sdk/src`, then
   includes `mk/kos.mk`.  Program options are unchanged
   (`STACK`, `STAGE`, `FAR1..4`, `SEGMENTS`, `INCLUDES`, ...).
   `exe_program` also defines a `NAME` target so an SDK Makefile can list
   its programs in `all`.
4. **`make sdk`** + **`tools/sdkpack.py`**: assemble
   `build/kos-sdk-0.1.0/` and `build/kos-sdk-0.1.0.tar.gz`.  Header
   closure: the SDK headers at `include/kos{,libc}/…`, the public ABI
   headers they include at `include/abi/kos/…` (first include root,
   `-I include/abi -I include`, the in-tree order).  The tool refuses any
   copied file (outside `docs/`) that names `abi/`, `user/sdk` or the
   repository path.
5. **SDK content**: `user/sdk/template/` gained its standalone `Makefile`
   (and its `hello.c` was *broken* - it never compiled, error 196 "pointer
   target lost const qualifier" - fixed); `user/sdk/examples/` holds
   `hello.c`, `fardemo.c` + `fardemo_far.c` (moved from `user/helloworld/`)
   and the new `files.c` (open/read/list), plus their standalone Makefile.
   `user/helloworld/Makefile` declares the examples from their new home.
6. **`tests/test_sdk_package.py`** (8 tests): golden layout (tarball member
   list), header closure, VERSION, stdlib-only tools, no OS-tree names,
   out-of-tree build of template + examples with a path-free environment,
   `X /system/hello.exe` in the simulator printing `Hello, KonaOS!`, and
   the ABI byte changed (offset 05h) refused while the same store's
   unchanged copy runs.
7. Existing tests updated for the split: `test_sdk.py`,
   `test_source_layout.py`, `test_ipc_selftest.py`, `test_ns_selftest.py`.
8. Docs: `docs/sdk.md` (layout, build rule, new section 11 "Using the
   standalone SDK", CODEBASE default corrected to 0x015D),
   `docs/architecture.md`, `README.md`, `user/helloworld/README.md`.

## Decisions / deviations

- The ABI headers are copied under `include/abi/kos/` and reached through
  the first include root, mirroring the tree's `-I abi -I user/sdk/include`
  exactly; the WORK's "copied flat" is read as "with their include paths
  preserved" (`kos/…`, `klibc/…` resolve inside the tree).  `include/abi`
  is the only SDK-internal spelling of the ABI root and contains no
  `abi/` token.
- `lib/` is pinned to `libkos.lib` + `crt0.rel`, and every program links
  the shared runtime object, so the SDK archive carries `runtime.rel` as
  its last member.  It is built as a second artifact
  (`build/user/sdk/libkos-sdk.lib`) so the in-tree link order, archive and
  program bytes stay unchanged.
- SYS_EXEC maps every loader refusal (`EXE_EXEC_ERR_* <= -20h`, the ABI
  check included) to `KOS_EINVAL` (kernel/syscall.c), so the monitor shows
  the existing `ERR: 02`; the test pins that plus "the refused program
  never ran" and the running unchanged copy.
- A few header comments in `abi/kos/*.h` and `user/sdk/include/kos*.h`
  spelled `abi/…`/`user/sdk` and were rephrased ("the ABI's kos/…",
  "the SDK's console clients") so the SDK token check can stay literal.
  Comments only; the production image is byte-identical.

## Evidence so far

- A clean worktree of HEAD (`fa31085`) built the baseline artifacts;
  after the split, this tree rebuilds them **byte-identically**:
  - `build/konaos.bin` `1d5ce5e647ceb45462aca2b89229bc6bb5438b1885d5a406f4b65002ac56ad1b`
  - `build/konaos.ihx` `bd1390df993892331aade000bddbeb18226eb3280a7feffec969a3b3261d7b5e`
  - `build/user/hello.exe` `b7bf0ae7…`, `fardemo.exe` `08e65caa…`,
    `monitor.exe` `4d27328b…` (both trees).
- `python3 -m unittest tests.test_sdk_package` → 8 tests, OK (~15 s warm).
- `tests.test_sdk`, `tests.test_pack_image`, `tests.test_source_layout`,
  `tests.test_ipc_selftest`, `tests.test_ns_selftest` → OK.

## Open / next

- **Pre-existing finding (not from this package):** with
  `build-xmem-selftest/` present (from `make xmem-selftest`),
  `tests.test_xmem_selftest_sim.TestXmemSelftest.
  test_the_token_cache_costs_one_segmap_per_segment` **fails**:
  the image makes `{0:1, 1:5, 2:3, 3:1}` calls, the test expects
  `{0:1, 1:2, 2:2, 3:1}`.  Reproduced at HEAD (`fa31085`) in a clean
  worktree with the same image (image sha256 `3361cb34…` in both trees)
  and in a fresh `make xmem-selftest` there (that target fails).  The
  counter also counts the program's own `segmap`/`farcall` calls, so the
  expectation predates the final `xmem_far.c`; 49b's record claims a pass
  from before the 14:42 test edit and its `make check` (14:57) had the
  image cleaned, so the xmem sim tests skipped.  Not fixed here: it is
  another package's acceptance test and changing its expectation would
  weaken it.  `make clean && make check` skips these replays (no image).
- **Done.** Final validation, once, at the end: `make clean && make check`
  (exit 0, `Ran 670 tests in 151.652s`, `OK (skipped=105)`,
  `check: reproducible rebuild (1d5ce5e6…)`), `make sdk` (exit 0; 37
  files / 290571 bytes, tarball 78368 bytes, sha256 `51d674bc…`),
  `git diff --check` clean.  Record:
  `docs/validation/2026-10-12-sdk-package.md`.  Nothing committed.

## Reproducible package (late addition)

- Repacking the SDK was not reproducible: `sdar` keeps every member's
  date and id (the in-tree `libkos.lib` too), and the Makefile's `tar
  -czf` kept the tree's build times, so two `make sdk` runs gave
  different tarball bytes.  `cmp` on two archives built seconds apart
  showed the first difference inside the ar member header.
- Fixed inside the package: the SDK's release archive is packed with
  `sdar -rcD` (zero dates/ids; the *in-tree* rule is left alone) and the
  tarball is written by `tools/sdkpack.py --tar` (member order, mtimes
  and ownership pinned, gzip header date zero).  Two tests pin both
  (`test_the_shipped_library_carries_no_build_dates`,
  `test_the_tarball_is_reproducible`), and `make -B` on the library plus
  `crt0` between two `make sdk` runs yields the same tarball bytes
  (`51d674bc…`).
