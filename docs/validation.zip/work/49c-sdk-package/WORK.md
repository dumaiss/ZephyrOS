# Task

**A standalone SDK.** `make sdk` produces `build/kos-sdk-<version>/`
(and a `.tar.gz` of it). With it, a developer builds a KonaOS program
with no OS source:

1. unpack the SDK;
2. `make`;
3. copy the `.exe` to the card;
4. run it with `X /fs/app.exe` from the monitor, or `app` from the shell.

Drivers are out of scope. They remain a source/build contract with the
OS tree.

Read:
- `work/00-WORKER.md`;
- `user/sdk/` (`exe.mk`, `include/`, `src/`, `template/`);
- `tools/exepack.py` and `tools/exemanifest.py`;
- `docs/sdk.md`;
- the 49b record.

## Requirements

1. **Layout** (pinned):

   ```text
   kos-sdk-<version>/
     VERSION          "<version> abi <n>", n = EXE_ABI_VERSION
     include/         kos.h, kos/*.h, klibc/*.h, and every abi/kos/ header they include
     lib/             libkos.lib, crt0.rel
     tools/           exepack.py, exemanifest.py (standalone)
     mk/kos.mk        the standalone build rules
     template/        Makefile + hello.c: the smallest program
     examples/        hello, fardemo (__banked), files (open/read/list)
     docs/            sdk.md, exe-format.md
   ```

   - Headers are copied flat under `include/` with their include paths
     preserved: `"kos/…"` and `"klibc/…"`.
   - Nothing in the SDK refers to a path outside it.
2. **Standalone tools.**
   - `exepack.py` imports `pack_image` only for `parse_ihx` and the map
     parsing. Move those two functions into `tools/ihx.py`, which the OS
     tools and the SDK both use, and ship `ihx.py` in `tools/`.
   - Python 3 standard library only.
3. **`mk/kos.mk`.** `exe.mk` is split:
   - the program rules, with no OS-tree variables (`$(BUILD)`, the
     top-level `$(PYTHON)`), go into `mk/kos.mk`;
   - the in-tree `exe.mk` becomes a thin wrapper that sets the in-tree
     paths and includes it.

   In-tree programs build with the same rules, and production boots and
   passes its tests as before. The variables a program sets
   (`STACK`, `STAGE`, `FAR1..4`, `SEGMENTS`, `INCLUDES`) are unchanged.
4. **Version.**
   - `<version>` = `KOS_SDK_VERSION` in a new `config/sdk.mk`, starting at
     `0.1.0`.
   - The ABI number is read from the header, never copied by hand.
   - The loader already refuses an EXE whose `abi_version` differs. Add a
     test that builds a template program with the ABI byte changed and
     sees `run` refuse it with the existing error.
5. **The out-of-tree test**, part of `make check`:
   - unpack the tarball into a temporary directory outside the repo;
   - build `template/` and `examples/` there, with the tree's own
     include and library paths absent from the environment;
   - pack the result into a test store and run `hello` in the simulator,
     expecting its output line;
   - assert that no file in the SDK names `abi/`, `user/sdk` or the
     repository path.
6. **Docs.** `docs/sdk.md` gains a "Using the standalone SDK" section
   (the 4 steps above). It is copied into the SDK. Package 47 rewrites
   it later.

## Tests

- **Host:**
  - the SDK file list matches the pinned layout exactly (a golden list);
  - the header closure is complete: every `#include` inside the SDK
    resolves inside it;
  - `VERSION` matches.
- The out-of-tree build and run (requirement 5).
- The ABI-mismatch refusal (requirement 4).

## Constraints

- No kernel or driver change. Production boots and its tests pass.
- Record: `docs/validation/<date>-sdk-package.md`, with the SDK file list
  and size.

## Working loop (targeted tests only)

`make clean && make check` takes about 25 minutes, so it runs **once, as
the very last step**, after the source is frozen. Do not run it while
developing, and build no image other than the ones listed here.

While developing, use only:

```sh
make sdk                                         # the SDK tree and tarball
python3 -m unittest tests.test_sdk_package       # the new tests (layout, header closure, VERSION, out-of-tree build)
python3 -m unittest tests.test_exe tests.test_sdk   # after touching exepack/ihx or the SDK rules
make build/user/hello.exe                        # one in-tree program, after splitting exe.mk
```

Put the new tests in `tests/test_sdk_package.py`, so that one command
runs them. If a targeted test fails, fix it and rerun **that** test
only.

## Validation (once, at the end)

```sh
make clean && make check     # the last step; includes the out-of-tree SDK test
make sdk
git diff --check
```

No image matrix: this package changes no kernel, driver or image
composition. Production booting is covered inside `make check`.
