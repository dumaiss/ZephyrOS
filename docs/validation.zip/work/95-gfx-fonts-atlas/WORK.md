> Worker package. After 94. Implements the 4×6 font of `docs/gfx-sdk.md`
> §12.2-14 and the glyph atlas of §14.1 (GFX-7). libgfx, its callers,
> gfxtest, the peer model, docs. No OS change.

# Task

Two text features:
- **A second built-in font, 4×6 CP850**, selected per text style: 128
  columns in GRAPHIC 6.
- **Transparent text:** `gfx_text_atlas` hands libgfx an off-screen band, a
  font and a glyph range. Transparent text then draws each glyph as a VDP
  logical copy (LMMM with TIMP) from an atlas of that colour, so colour-0
  pixels leave the screen untouched.

## Current state

- **The 4×6 font:** `/home/kitamura/Documents/Zephyr-80/Code/HOST/CPM2.2/src/assets/font_cp850_4x6.inc`
  (X11 misc-fixed 4x6, public domain):
  - 256 glyphs, 6 bytes each, pixels in bits 7..4, 1,536 bytes, with its
    SHA-256 in the header;
  - the 6×8 asset was imported from the same directory: follow its
    pattern (`drivers/v9958/assets/font_cp850_6x8.inc` header, the
    hash-checked generation package 86 uses for libgfx's table).
- **Opaque text** (package 86): the RAM font, the expansion (G6 tables
  per colour pair; G7 one byte per pixel) and the opaque sink (data-port
  writes, one VRAM address per glyph row). The expansion and the sink are
  separate functions.
- **The batch:** `struct gfx_cmd` (16 bytes) and the asynchronous runner
  (package 94). CPU VRAM accesses wait for CE.
- **LMMM** = 90h | op: SX/SY, DX/DY, NX/NY in dots, ARG (DIX/DIY), CMD
  with the op in the low nibble. TIMP = 8: a source pixel of colour 0
  leaves the destination.
- **Atlas geometry** (§14.1): rows of 8 lines, 85 glyphs per row in G6,
  42 in G7. One atlas per colour, LRU when the band is full.
- **The peer** executes HMMV/HMMM/LMMV-EOR/LMMC/HMMC, plus LINE/PSET from
  package 93 (LINE, PSET, LMMV), but not LMMM.

Read: `work/00-WORKER.md`; `docs/gfx-sdk.md` §12-15; packages 86, 93 and
94's records; libgfx's text sources.

## Requirements

1. **The 4×6 font** (Must):
   - **The asset:** imported byte for byte, with its provenance comment
     and SHA-256 verified at build, next to the 6×8 asset.
   - **The table:** libgfx's const table, in its own archive member,
     with a RAM copy made at first use.
   - **Selection:** `enum gfx_font` and `struct gfx_text_style`'s
     `flags` and `font` fields (§13); a zeroed style is opaque 6×8.
   - **Font-taking calls:** `gfx_text_width(text, font)` and the glyph
     calls (`gfx_font_set_glyph(font, code, rows)`, `reset_glyph`,
     `reset`); update every caller (`gfxtest`, `GfxDemo`). Rows are
     right-aligned in both fonts (§12.3): 6×8 in the low six bits, as
     package 86 implements, and 4×6 in the low four bits.
   - **Expansion** (§14): in G6, 2 bytes per row through a 16-entry
     table of byte pairs per colour pair; in G7, 4 bytes per row.
     - **Pair tables:** package 86's 6×8 cache holds 2 pairs of 771
       bytes. A screen with many fg/bg pairs (a tracker's stripes, beat
       rows and cursor row) would rebuild it constantly. The 4×6 table
       is 32 bytes: cache 8 pairs, or rebuild per call if that measures
       cheaper. Record the choice and the cost. Opaque
     4×6 text in both modes, with x even in G6 (always byte-aligned).
   - **Opaque text: assembly, scanline-major** (Must). Today every glyph
     row costs a C sink call, a C expansion and a VRAM address write, for
     2-3 bytes. A string's rows are contiguous in VRAM: set the address
     once per scanline of the string, then an assembly loop streams every
     glyph's bytes (font byte, pair lookup, OUT). The sink becomes per
     scanline run; clipping and validation stay in C, once per call. The
     same loop serves 6×8 and G7.
   - **Transparent:** one LMMM per glyph through 93's assembly
     pipeline; the SX/SY from the atlas position in assembly too.
2. **API** (Must):
   - `gfx_text_atlas(enum gfx_font font, uint16_t y, uint16_t lines, uint8_t first, uint16_t count)`;
   - `GFX_TEXT_TRANSPARENT` in the style's `flags`.
   - **Refusals:** a band outside y 0-511, too small for one atlas of the
     range, or overlapping lines 0-211 of either page, is `-KOS_EINVAL`.
     Rebuilding the atlas setup discards every atlas.
3. **Atlas build** (Must). On a colour's first transparent use:
   - draw the range's glyphs in that colour on colour 0 into its slot,
     with the existing expansion and opaque sink;
   - the slot's position is recorded;
   - when no slot is free, the least recently used colour's slot is
     rebuilt.

   Record the CPU cost of one build (T-states) in G6 and G7.
4. **Transparent draw** (Must):
   - each glyph is one LMMM | TIMP from its atlas cell to the target,
     batched (new opcode `GFX_OP_GLYPH`, or `GFX_OP_COPY` with a
     logical flag);
   - right-edge clip as for opaque text;
   - a glyph outside the range draws nothing, and the call returns the
     count of such glyphs (0 when all drew);
   - transparent text without an atlas is `-KOS_EINVAL`; YJK
     `-KOS_ENOTSUP`.
5. **Redefinition** (Must). `gfx_font_set_glyph`/`reset_glyph`/`reset`
   mark the glyph stale in every built atlas. A stale glyph is redrawn
   into an atlas at its next transparent use, alone, not as a full
   rebuild.
6. **Peer** (Must). LMMM with IMP and TIMP in G6/G7, DIX/DIY, citing the
   V9958 Technical Data Book. List what isn't modelled.
7. **Docs** (Must). `docs/sdk.md`: both fonts and their selection; the
   atlas and its sizes for printable ASCII (6×8: 16 lines per colour in
   G6, 24 in G7; 4×6: 6 and 12); transparent text; the costs measured.

## Tests

`gfxtest atlas` (new mode) and a replay against the peer's VRAM:

- **4×6 opaque:** a line of 4×6 text in G6 and in G7, in two colour
  pairs. Every glyph decodes against the 4×6 RAM font, at 128 columns in
  G6. A redefined 4×6 glyph and its reset.
- **Asset:** the imported 4×6 asset's hash check fails on a changed byte
  (build-time check).

- **Transparency:** over a background pattern (stripes), transparent text
  in two colours and both fonts. Each glyph's foreground pixels have the colour, and
  every background pixel is the stripe byte, unchanged. Checked against
  the RAM font, in G6 and in G7.
- **LRU:** more colours than slots. The least recently used slot is the
  one rebuilt, and the earlier colours redraw correctly after a rebuild.
- **Stale glyph:** redefine a glyph inside the range, draw it
  transparently, and the new shape appears. Exactly that glyph's cell
  was rewritten in the atlas, not the whole atlas.
- **Refusals:** no atlas; a band overlapping visible lines; YJK.
- **Out of range:** a glyph outside the range draws nothing and is
  counted.
- **Cost:** CPU T-states per transparent glyph (program bank, as the
  package-87c01 timing tests measure). Report it.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | stop and report |
| opaque 4×6 glyph, G6, in a 128-glyph string | - | <= 700 | report with a profile |
| a full 128-glyph 4×6 row, G6, the whole call | - | <= 100,000 (10 ms) | report with a profile |
| opaque 6×8 glyph, G6 | 93's baseline | <= 1,000 | report with a profile |
| opaque 4×6 glyph, G7 | - | <= 1,000 | report |
| transparent glyph, CPU | - | <= 1,000 | report with a profile |
| transparent glyph VDP time; atlas build, G6/G7 | - | report | - |
| code size | - | report only | - |

## Owner checklist

- On the board, `gfxtest atlas`, which shows:
  - 4×6 opaque text at 128 columns;
  - transparent text over stripes in two colours and both fonts;
  - a redefined glyph;
  - a key, then the console back.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-gfx-atlas-text.md`.
