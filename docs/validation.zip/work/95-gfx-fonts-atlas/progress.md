# Package 95 progress (GFX fonts atlas)

- [x] 4x6 asset imported byte-for-byte (drivers/v9958/assets/
      font_cp850_4x6.inc pattern: provenance + SHA-256, build-checked).
- [x] 4x6 const table, own archive member, RAM copy at first use.
- [x] enum gfx_font; style flags/font; font-taking glyph/text calls;
      rows right-aligned low 4 bits.
- [x] Expansion 4x6 (G6 2 bytes/row via 16-entry pair table, G7 4
      bytes/row).
- [x] Opaque text: assembly scanline-major sink (one address per
      scanline run, streaming glyph bytes), C validation unchanged.
- [x] gfx_text_atlas + GFX_TEXT_TRANSPARENT; refusals; LRU atlas build;
      stale-glyph redraw; transparent draw = LMMM|TIMP per glyph.
- [x] Peer: LMMM IMP+TIMP, DIX/DIY.
- [x] docs/sdk.md fonts + atlas.
- [x] gfxtest atlas + replays.

## Notes
- The atlas build double-added the glyph's font offset (emit + row
  loop), so every cell held the wrong glyph; fixed.
- SDCC miscompiled `while (index >= atlas->per_row)` (the offset
  re-derived inside the loop walked the struct); the divisor is
  copied to a local first, the other loops audited clean.
- An atlas built under one mode is refused after a mode switch
  (setup records the mode; the draw compares).
- Budgets (emulated CPU): 128-glyph 4x6 row 27,595 (216/glyph);
  6x8 cached-pair glyph 677; 4x6 G7 glyph 529; transparent glyph
  930 (G6) / 886 (G7); a 95-glyph atlas build 196,600; a stale
  redraw across seven slots 18,017.
