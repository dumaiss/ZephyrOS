> **DRAFT. Not dispatched.** Runs after 53 (timer), with the shell in production,
> so every diagnostic is launched from the shell (`diag …`).

# Task

The diagnostic suite's frame and its first families: `/system/diag.exe`
with the result model, `diag system` and `diag memory`, plus the one
kernel addition, the read-only `SYS_DIAG_ENUM`. The device families are
package 55.

Read: `work/00-WORKER.md`; the architecture's diagnostic-suite section;
`abi/kos/diag.h`; and the M7 diagnostic syscalls.

## Requirements

1. **Program.** Sources in `user/diag/`:
   - `main.c`: the command dispatch and the summary;
   - `result.c`: the result model;
   - one file per family (`system.c`, `memory.c`).

   - The primary image holds main and result. **The families sit in
     far segments** (`FAR1=` … `FAR4=`), called as plain `__banked` C
     functions (package 49b). This makes the suite
     the first production user of far code.
   - The segments are fixed:
     - 1: system and memory;
     - 2: irq and serial;
     - 3: video and hid;
     - 4: ioc, storage, sound and timer.

     Package 54 fills segment 1 only.
   - Add it to the recovery manifest.
2. **Commands:** `diag <family> [options]`, and `diag all`. With no
   argument, print the family list.
   - Families not implemented yet (they come in 55) print `SKIP not
     implemented`.
   - `diag all` runs every family in a fixed order:
     system, memory, timer, irq, serial, video, hid, ioc, storage,
     sound.
3. **Result model.**
   - Each test prints `<family>.<test>: PASS|FAIL|SKIP [detail]`.
   - Each family ends with `<family>: PASS|FAIL|SKIP (<p> pass, <f> fail,
     <s> skip)`.
   - `diag all` ends with `diag: PASS|FAIL (<p>/<f>/<s>)`. It passes when
     no test failed; SKIP is not a failure.
   - Exit status: 0 for PASS or SKIP-only, 1 for FAIL.
   - The final line is always the last line printed, so the smoke test
     reads only that line.
4. **`SYS_DIAG_ENUM` (2Eh)**, recovery-family, cold half:
   - Arguments: `{kind:u8, index:u8, out:u16}`.
   - It copies one fixed 16-byte record to `out` through the checked copy
     gate.
   - Returns: 16; `-KOS_ENOENT` past the last index (the end, not a
     failure); `-KOS_EINVAL` for an unknown kind.
   - Records hold values only: no kernel or driver addresses. Byte 0 is
     the kind, byte 1 is the record version (1).

   | kind | record (after kind and version) |
   |---|---|
   | 1 bank | bank, state (0 free, 1 OS, 2 process, 3 xmem), pid or 0, xmem slot or FFh |
   | 2 irq source | source id, owner (0 none, 1 nucleus, 2 driver), driver index or FFh, enabled:u8 |
   | 3 driver | index, name (8 bytes, NUL-padded), first endpoint, endpoint count, hot KiB, boot KiB |
   | 4 irq totals | unexpected:u16, unclaimed:u16 |

   - It reads only existing state: **no fixed-core change**. There are
     no per-source counters; interrupt delivery is checked through the
     timer driver (package 55).
   - Add the SDK wrapper `diag_enum(kind, index, out)` in `kos/diag.h`.
   - The namespace roots and `/dev` publications come from `list`, not
     from this syscall.
5. **`diag system`:**
   - `getinfo` and `diag_system_info`;
   - the bank map (kind 1);
   - drivers (kind 3);
   - `list` of `//` and `/dev`.

   Tests:
   - the ABI identity is as expected;
   - every bank state is legal;
   - every driver has at least one endpoint;
   - every `/dev` entry binds and returns a type that is not 0;
   - `/fs` is present.
6. **`diag memory`:**
   - `xalloc` a mappable object and a plain object; pattern-write them
     (address-in-address, then inverted) and read them back with
     `xread`/`xwrite`, and through `xmap` plus the aperture;
   - transfers across the 16 KiB slot boundary;
   - allocate until `ENOSPC`, free all, then allocate again (recovery);
   - kind 1 before and after: identical (no leak).

   - **`memory.cost`** (reported, no threshold), in µs:
     - a cached `__banked` call;
     - an `aperture_open`/`aperture_close` pair;
     - one empty syscall (`getinfo`);
     - `xread` of 512 bytes from a 1-slot object (fast slots 3/6) and
       from a 3-slot object (slots 1-3, mostly the slow gate).

   Nothing destructive: only the program's own objects.

## Tests

- **Host:**
  - the record layouts (static asserts in `abi/kos/diag.h`);
  - the result model's aggregation;
  - argument validation of `SYS_DIAG_ENUM` (unknown kind, past the end,
    a bad `out`).
- **Simulator replay** of the production image: at the shell, run
  `diag system`, `diag memory` and `diag all`. Check the final lines and
  the exit status through the shell's `[exit n]`.
- `mapcheck`: `SYS_DIAG_ENUM` is cold code.

## Constraints

- The production hash changes. Record every ledger. Fixed core,
  common and driver ledgers are unchanged. Report the cold half.
- No private kernel symbols in `diag.exe`. The existing
  forbidden-dependency test pattern of `tests/test_monitor.py` applies to
  it.
- Record: `docs/validation/<date>-m12-diag-core.md`.

## Validation (targeted: no `make clean && make check`)

Put the tests in `tests/test_diag.py` (host) and `tests/test_diag_sim.py` (replay). Use these same commands while developing,
and once at the end:

```sh
make                                              # production builds: store fits, mapcheck passes
python3 -m unittest tests.test_diag tests.test_diag_sim
python3 -m unittest tests.test_console_acceptance # production still boots
git diff --check
```
