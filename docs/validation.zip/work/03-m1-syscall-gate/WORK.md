# Task

Implement the M1 native syscall scaffold on top of the accepted memory foundation: install `RST 30h` in native page zero, cross safely from an application-mode caller to the bank-7 kernel through permanent common code, return a deterministic unimplemented error, restore the caller exactly as the ABI requires, and prove the round trip with a target-side smoke test.

## Context

Native entry is `RST 30h`. On entry, `A` is the syscall number and `HL` points to a syscall-specific argument block. Return uses carry clear for success; carry set for error, with `HL` the primary result and `A` the error code. For M1, define `ZOS_ENOSYS` and return it for every number; set `HL=0000h` and carry.

The page-zero vector at `0030h` is exactly `JP zos_syscall_entry`; the dispatcher must not live in page zero. `zos_syscall_entry` lives in common memory. An `RST` has already pushed the return PC on the caller's stack, which may be anywhere in the selected application bank and may disappear above `1FFFh` in mode `11`. Therefore the common gate must save the caller SP without a push, switch to a reserved common gate stack, save required registers/state there, preserve the selected-bank bits while changing only mode `10` to `11`, and only then call the bank-7 dispatcher. Return performs the inverse: restore results/state, restore mode `10`, restore the exact caller SP, and execute `RET` against the caller's original stack.

M1 is single-entry and non-reentrant with interrupts disabled. Do not solve nesting, interrupt entry, scheduling, or process ownership. Until later staging/copy APIs exist, document that native syscall argument blocks must lie in the preserved caller window `0000h-1FFFh`.

## Requirements

- Place `JP zos_syscall_entry` at `0030h` in the native page-zero image and add build assertions for its exact address and three-byte size. Keep reset/copy bytes disjoint from it.
- Define a compiler-independent native ABI document in `docs/abi.md`. In addition to the architecture's `A`, `HL`, and carry contract, specify that `BC`, `DE`, `IX`, and `IY` are preserved, `SP` and selected bank are restored, other flags are unspecified, and alternate registers are not part of the M1 contract. State the `0000h-1FFFh` argument-block restriction.
- Implement the common-memory entry/exit gate entirely in assembly. Preserve the caller's original latch value and SP in the reserved common transition state. Validate that entry mode is application mode and the selected bank is `0-6`; corrupted/unsupported entry state must take a defined fatal path rather than return through an unsafe mapping.
- Switch only the mode bits when entering/leaving the kernel. The application bank bits must remain unchanged while mode `11` is active.
- Call a bank-7 assembly/C dispatch boundary that converts the stable register ABI to internal implementation conventions. The initial dispatcher handles every syscall number identically: `A=ZOS_ENOSYS`, `HL=0000h`, carry set. Do not expose the SDCC calling convention to callers.
- Keep interrupts disabled across the whole crossing. Do not add `EI`, IM2, an interrupt stack, or an interrupt ABI.
- Add a target-side assembly smoke caller in application memory, enabled by a dedicated build option/target. It must set sentinel values in all preserved registers, put its stack above `2000h` to exercise the disappearing-stack case, issue `RST 30h`, and verify the error result, preserved registers, restored SP, restored mode `10`, and unchanged selected bank. A common-memory continuation may re-enter mode `11` after recording the result so the kernel can print `syscall selftest: OK` or a precise failure.
- Add host/static tests that verify the vector bytes/address, common placement of the full gate path, bank-7 placement of the dispatcher, and absence of direct C-symbol addresses in the native ABI surface.
- Keep the ordinary boot banner unchanged when the self-test build option is off.

## Files

Likely files to create or modify:

- `include/zephyros/errno.h`
- `include/zephyros/syscall.h`
- `boot/start.asm` or `platform/zephyr80/page_zero.asm`
- `kernel/syscall.c`
- `platform/zephyr80/syscall_entry.asm`
- `platform/zephyr80/banking.asm`
- `platform/zephyr80/memory.inc`
- `linker/zephyr80.lk`
- `Makefile`
- `tests/`
- `docs/abi.md`
- `docs/architecture.md`

## Constraints

- The only stable interface is the documented register ABI. C names, argument layout, and SDCC conventions remain private.
- The low caller window and selected application bank must survive the crossing. Never use caller memory above `1FFFh` after entering mode `11`.
- Common transition state may be single-depth because interrupts and nesting are explicitly out of scope, but document and assert that limitation.
- Do not implement real syscalls, syscall registration, user processes, CP/M `CALL 0005h`, drivers, or interrupt handling.
- Preserve the M0 early-console and panic behavior.

## Validation

```sh
make clean
make
make test
make check
make syscall-selftest
```

Boot both the normal image and self-test image in MAME. The normal image must retain the exact M0 banner. The self-test image must print `syscall selftest: OK`; test at least application banks 0 and 6 if the smoke harness supports selecting both.

## Acceptance criteria

- `RST 30h` reaches the common gate and returns `ZOS_ENOSYS`, `HL=0`, carry set.
- The gate safely handles a caller stack hidden by mode `11` and restores SP, bank, mode, and all documented preserved registers.
- The dispatcher resides in bank 7; the crossing path resides in common memory; only the jump stub resides in page zero.
- Target and host tests pass, including at least one nonzero application-bank round trip.
- No useful service or later-milestone subsystem is added.
