# Package 42c — prune the abstractions M10 made obsolete

Working log.  Contract: `work/42c-m10-prune-nucleus/WORK.md` (M10 step 8,
architecture 36.24; sections 36.4, 36.11, 36.13, 36.20).
Entry point used: `/home/kitamura/Documents/ZephyrOS/user/sdk/src/zos_internal.h`.

## Status

- [x] Baseline recorded
- [x] Req 1: retired machinery deleted (arena/module loader, zdriver_api,
      device class/capability model, every driver ops table, provider
      interface, M9 mount leftovers)
- [x] Req 2: ZMOD is a plain service image (flat container; docs pending)
- [x] Req 3: version checks host-side only
- [x] Req 3b: flat load plan; loader 1,970 bytes (target <= 2,000) met
- [x] Req 4: two residency tiers (fixed-required, cold)
- [x] Req 4b: arena reservation gone, driver ledger fixed, driver.h/vfs.h
      deleted
- [x] Req 5: main.c boot path pruned
- [ ] Tests reconciled (in progress: driver/format suites green, see below)
- [ ] Docs updated (`docs/module-format.md`, `docs/memory.md`,
      `docs/vfs.md`, `docs/devices.md`, `docs/romfs-format.md` mentions)
- [ ] Final validation run + `docs/validation/<date>-m10-prune-nucleus.md`

## Baseline (HEAD, before 42c)

mapcheck (production):
- fixed core end `42C5h` (7,668 required + 2,859 overflow + 768 stacks,
  5,089 room)
- cold half end `AAEEh`, data 642 at `DC00h`, room 661
- arena `AC00h-DBFFh`, 24 granules, 0 used, 24 free
- common 2,358 of 7,424 (code 1,511, data 847); ceiling 3,072, m10 512,
  limit 2,560
- image sha256 `d5e816f2e47ace191077f916487e61c65df39e61a0709954aff7b32179e8abec`

pack_image manifest (the mis-reported driver ledger 42c fixes):
`service_hot_bytes: 0`, `service_boot_bytes: 0` while the packed service
plan already carried 21,838 hot / 2,170 boot.

Loader object, measured on HEAD with the same accounting used below:
`_WINDOW` 4,952 + `_WINDOW_DATA` 170 = **5,122 bytes** (the 41b review
cites 4,628 with `service_read_layout` 1,899; measured here
`service_read_layout` is 2,069 in a HEAD build).

Driver ledger at HEAD: 21,838 hot / 2,170 boot (services plan).

## What 42b had already removed (verified gone, nothing left in use)

`module_loader`, `module_relocate`, the registry, `ioc_shim`, `fs`,
the M9 mount/provider machinery, and the `m9-*` acceptance targets and
images.  `kernel_boot_module()` in `main.c` had become a two-call boot
path (ROMFS init + `service_load_all`), and the arena carried no module.

## What 42c deleted (with the reason)

| item | action |
|---|---|
| `kernel/module/arena.asm` + the `GEOMETRY_*`/arena derivation | deleted; the cold data base derives from the code end |
| `include/zephyros/module.h` | deleted (flat container in `service.h`) |
| `include/zephyros/device.h`, `driver.h`, `vfs.h`, `block.h`, `hid.h`, `video.h` | deleted (device model, driver ABI, provider interface, classes) |
| `ZDEV_*` uses in sio, hid, v9958, ioc, iocfat | replaced with `-ZOS_E*` |
| `zchar_ops`, `zioc_ops` tables | deleted (drivers call their own functions) |
| `ZVIDEO_*` operations | moved to `abi/zos/protocol.h` (client-visible protocol) |
| `zfs_provider` / `vfs_register_filesystem` / `VFS_PHASE_MODULES` / `kernel_load_vfs_module` | deleted |
| `ZOS_IPC_SERVICE_API_VERSION` and the `ipc_service_api.version` field | deleted (host-side checks only) |
| `tests/modules/` fixtures, `tests/subsys/gen_zmod_fixtures.py`, `tests/test_driver_abi.py` | deleted (their subject) |
| `tools/mountgen.py`, `config/mounts.json` | deleted (M9 mount machinery) |
| empty `zos_boot_test_modules()` hook + module wording | deleted from `main.c` / `target_test.c` |

Grep gate (empty outside `docs/validation/` and `work/`) verified over
`kernel/ drivers/ services/ fs/ include/ abi/ user/ boot/ platform/
modules/` right after the source pass.

## Req 2/3b — the flat service image and the loader

Container (`include/zephyros/service.h`, `tools/zmodpack.py`):
16-byte header (`magic`, four table counts, `init_entry`,
`payload_offset`, `total_size`, `reserved`), then 12-byte segment
records (role, reserved, base, image_size, bss_size, entry,
payload_offset), 8-byte endpoint records, 4-byte dependency records,
20-byte publication records, then the payload.  No module type, no
version, no relocation table, no fini, no resource imports, no granule
geometry.  `parse_container` is the format's only validator.

Loader (`kernel/service/service_loader.c`), rewritten and then shrunk:

| step | bytes |
|---|---|
| HEAD, whole object | 5,122 |
| flat plan, error classes, one read layer | 2,502 |
| record reader on `romfs_read`, 16-bit manifest arithmetic, one manifest bound | 2,434 |
| 16-bit payload wrap bound | 2,351 |
| cached loop counts | 2,331 |
| no magic check (the ROMFS `ZMOD` flag is the type guard), no empty-segment check | 2,281 |
| manifest class folded, `service_open` inlined, header checks trimmed | 2,008 |
| ledgers evidence-only, plan state local, name on the stack | 1,985 |
| no modulo (SDCC would link `__moduchar`), endpoint/publication count checks delegated to the nucleus tables | **1,970** (1,969 `_WINDOW` + 1 `_WINDOW_DATA`) |

Checks the loader keeps (protective bounds only): header present, table
counts within the loader's tables, `total_size == file size`,
`payload_offset <= size`, per-segment role and tier fit (with the 16-bit
wrap guard), boot entry inside the boot tier, hot segment present and
`init_entry` inside the hot image, endpoint number non-zero, dependency
number within the installed range, publication NUL-terminated, plus the
payload wrap guard; `romfs_read` bounds every read, and
`ipc_install_endpoint` / `vfs_ns_install_publication` bound the nucleus
tables.  The evidence lines are unchanged (test builds only):
`driver <name>: hot ...`, `service loader: N images in bank 6`,
`driver hot: N bytes of 32768`, `driver boot/bulk: N bytes of 24576`.

## Req 4/4b — residency, geometry, ledger

- `config/residency.json`: two tiers (`fixed-required`, `cold`), the
  arena entry gone, `bank7_end` added, `vfs_path/vfs_process/
  vfs_workspace` moved from the retired `moves` stage to `cold`.
- `kernel/memory/bank7_end.asm` (+ generated `build/geometry/bank7_end.inc`)
  replaces `arena.asm` as the `__kernel_code_end` carrier.
- `tools/mapcheck.py`: `RESIDENCY_TIERS = (fixed-required, cold)`; cold
  data base = `align_up(window_code_end, 512)`; fixed data base =
  `align_down(service_stack_base - data_size, 512)`; arena/boot-plan
  rules removed.
- `tools/pack_image.py`: `nucleus_ledger(symbols, service_plan)` reads
  `<build>/modules/services.plan.json` (`load_service_plan`), so
  production prints the real `driver hot` / `driver boot/bulk` figures;
  the cold ledger line reports code end and data size/base.
- `platform/zephyr80/memory.{h,inc}`: `ZOS_DRIVER_GRANULE_SIZE` ->
  `ZOS_BANK7_DATA_ALIGN`; the arena narrative is gone.

Ledgers after the source pass (`make`, production):

```
nucleus fixed: required 7667 bytes | overflow 2 bytes | stacks 768 | room 7947 bytes
nucleus cold: code 17776 bytes end A570h | data 1753 bytes at A600h | room 13095 bytes
driver hot: 22013 bytes of 32768
driver boot/bulk: 2170 bytes of 24576
common: used 2358 of 7424 bytes (code 1511, data 847) | ceiling 3072, m10 512, limit 2560
```

Note: driver hot is +175 against the 42b plan (22,013 vs 21,838).  The
cause is the removal of the `ipc_service_api.version` byte: the struct
member offsets shift and SDCC's register allocator picks a spilling
choice in `hid_fetch` (hid +194; ioc -8, iocfat -4, sio_service -3,
v9958_service -2, ioc_service/console_service -1 each).  Behaviour is
identical; the hot tier has 10,755 bytes of room.  Confirmed by
re-inserting a padding byte at HEAD's offset, which reproduces 1,461
bytes for `hid._CODE` exactly.

## Req 5 — main.c

`kernel_boot_module()` -> `kernel_boot_services()` (33 bytes; the whole
`main.rel` is unchanged at 1,667 bytes because 42b had already emptied
the module/arena boot code): `vfs_init()` (panic on a corrupt recovery
image), `service_load_all(ZOS_SERVICE_MANIFEST_NAME)`, then the manifest
failure report.  What remains is the early-console banner, the service
load, the console binding and the boot launcher.  The empty
`zos_boot_test_modules()` hook and its declaration were deleted, and the
module/arena wording in `main.c` and `tests/target/support/target_test.c`
is gone.

## Tests

Updated (green):

- `tests/test_zmod.py` rewritten for the flat container (`.rel` reader,
  round trip, endpoint/publication/dependency records, `parse_container`
  field-by-field rejections, CLI pack/validate/dump).  Deleted with their
  subject: module constants and granule geometry, granule/relocation pack
  round trips, the two-base relocation suite, the arena fixture artifacts
  and the SIO module artifacts (reasons in the module docstring).
- `tests/test_pack_image.py`: the granule-threshold suite replaced by the
  ledger suite (service-plan figures, zero-without-plan, and the built
  image agreeing with the plan); the arena fixture symbols are gone.
- `tests/test_hid.py`, `tests/test_ioc.py`, `tests/test_v9958.py`: the
  `*ClassContract` suites deleted (device model, capability bits, ops
  tables, deleted headers); manifest-shape and container assertions
  updated to the flat format; `ZDEV_*` assertions -> `-ZOS_E*`.
- `tests/test_iocfat.py`: manifest/container shape and Makefile wiring
  updated.
- `tests/test_source_layout.py`: retired owners asserted absent, deleted
  fixture paths removed from the lists, `_tab_recipe_lines` made robust
  to continued rule headers, and the module-facing header boundary
  repurposed to the service ABI surface (`SERVICE_FACING_HEADERS`, a
  service probe translation unit).

Still to reconcile (the failures left by the last full-suite run):
`test_console_acceptance` (boot lanes, `/FS` lane, monitor session —
`driver hot` is pinned there too), `test_ns_selftest`,
`test_ipc_selftest`, `test_service_images` (relocation-record rejection
and round-trip expectations), plus the retired fixture symbols in
`tests/maptools.py`'s synthetic map and `tests/subsys/manifest.json`,
which the next run will confirm.

## Validation plan

`make clean && make check`, the acceptance images
(`fs-selftest`, `ns-selftest`, `ipc-selftest`,
`console-integration-selftest`, `console-fallback-selftests`),
`git diff --check`, and the grep gate.  WORK.md names the retired
`m9-selftest`/`m9-exec-selftest`/`m9-iocfat-selftest` targets: 42b
correction 01 deleted them with the M9 machinery (owner decision), so
the report records `fs-selftest`/`ns-selftest` (+ the console and IPC
images) as the current equivalents.

### 42c session notes (acceptance pass)

- **Loader ledger classification bug (found by the acceptance pass).**
  The rewritten loader counted a `boot` segment into the `driver hot`
  ledger (`role <= ZMOD_SEGMENT_IO` instead of `role == HOT || role ==
  IO`), so `driver boot/bulk` printed 0 whenever a service carried a boot
  segment.  Fixed; the line now matches the packer's plan ledger.
- **`vfs_workspace` residency (real regression, fixed).**  The 42c
  two-tier pass had classified the VFS workspace as `cold`.  A bank-6
  dispatch receives the protocol frame with the path *address* in it, and
  the frame lives in the fixed core, so the workspace is touched while
  the window shows bank 6 and must be `fixed-required` (36.5's fixed
  rule).  With it cold, `iocfat` read 0FFh bytes as the path and refused
  the SDK's `/FS` open with `EINVAL` ("fs-selftest: card not writable");
  `make fs-selftest` re-run after the fix.
- `docs/module-format.md` rewritten for the flat service image (the
  historical name is kept deliberately: the container is still the ZMOD
  container), `docs/devices.md`, `docs/filesystem.md`, `docs/vfs.md`,
  `docs/romfs-format.md`, `docs/architecture.md` and `README.md` purged
  of the retired vocabulary; the grep gate is empty outside
  `docs/validation/` and `work/`.
- `tools/zmodpack.py`: the dead `emit-asm` fixture emitter (its
  `tests/modules` consumers are gone) deleted.

### Final acceptance pass (all on the final source)

- `make clean && make check`: reproducible rebuild
  (`f24d87900142a5e1ff2aebdb86c99ebda59e0e01e6b1ca29fa885f62065aa497`),
  **560 host tests OK** (111 skipped: image-dependent replays).
- `make fs-selftest` OK (3 replay cases; writable card 35/35, absent card
  8/8, handle-release run), `make ns-selftest` 23 tests OK,
  `make console-integration-selftest` 6 tests OK,
  `make console-fallback-selftests` OK (both subsets),
  `make ipc-selftest` OK (53 tests).
- `make subsystem-selftest`: the m4 arena fixtures were dropped from
  `tests/subsys/manifest.json` (their generator and sources are gone) and
  the replay no longer waits for the deleted loader group; re-run clean.
- Loader evidence fix found by the ipc replay: a role placed at `0000h`
  (a boot segment at the bottom of the boot tier) was printed as absent
  because the report used `base != 0` as its presence test; the roles now
  carry an explicit `SERVICE_ROLE_ABSENT` sentinel, so the line matches
  `zmodpack.py services` exactly.  Production bytes are unchanged (the
  report is acceptance-only): the loader stays at 1,986 bytes.
- New file `kernel/memory/bank7_end.asm` (the `__kernel_code_end` ABS
  export the cold geometry needs) staged.
- Report: `docs/validation/2026-10-09-m10-prune-nucleus.md`.

### Subsystem acceptance image (repaired)

- `make subsystem-selftest` was **broken at 42b**: its probe link failed with
  `_module_get`/`_module_count` undefined (the target tests still called the
  deleted loader), and its manifest still named the m4 fixture containers.
  42c dropped the five container entries, dropped the loader group from the
  replay and the module calls from the target tests, so the image builds and
  runs again.
- The replay then failed the process group: `zex-wrong-type.dat` (a DATA
  entry holding a valid ZEX image) was *accepted* by the loader.  The M6
  media gate went missing in 42b when exec moved onto the namespace bind
  (`vfs_ns_file_bind` has no exec intent, so the M9 `VFS_O_EXEC` rule was
  lost).  42c restores it in `process_prepare`: an executable under
  `/SYSTEM` must be a `ROMFS_FLAG_ZEX` entry (`ZEX_EXEC_ERR_TYPE`
  otherwise); a filesystem driver's FILE has no entry kind and is validated
  by its header alone.
- Second latent 42b bug of the same family: `service_cli_write()`
  (`tests/target/support/service_client.c`) wrote through the early
  console but returned 0, while the ROMFS and process groups compare its
  result with their line length - so `_romfs_selftest_result` ended 0x09
  (FAIL_CONSOLE) and `_process_selftest_result` 0x0B even though the
  lines appeared.  It now returns the byte count it wrote.
- `make subsystem-selftest` passes (4 replay tests) on the repaired
  image: syscall/IRQ/ROMFS/process groups, every result word zero, the
  monitor session and its relaunch.

### Final validation (all green)

```text
make clean && make check      CHECK=0  (reproducible b0b8def1f0c83ba2f3707eab8e167c8431eeae1b060e35639787c5f92c034c80,
                                        560 host tests, 111 skipped)
make fs-selftest              OK  (3 replay cases)
make ns-selftest              OK  (23 tests)
make ipc-selftest             OK  (53 tests)
make console-integration-selftest  OK  (6 tests)
make console-fallback-selftests    OK  (3 tests)
make subsystem-selftest       OK  (4 replay tests)
git diff --check              clean
grep gate                     empty outside docs/validation/ and work/
```

Production ledgers on the final source: fixed core `code end 3C9Bh, 8179
required + 2 overflow + 768 stacks, room 7435`; cold half `code 17845
bytes end A5B5h | data 1241 bytes at A600h | room 13607`; common `2358 of
7424 (code 1511, data 847)`; `driver hot 22013/32768`, `driver boot/bulk
2170/24576`.  Loader: 1,986 bytes (1,985 code + 1 data).

Report: `docs/validation/2026-10-09-m10-prune-nucleus.md`.  Temp
artifacts and the HEAD comparison worktree are removed; the new
`kernel/memory/bank7_end.asm` is staged.  Hardware smoke runs remain the
owner's (recorded as pending in the report).
