# Task

M10 step 8 (architecture 36.24): **prune the abstractions M10 made
obsolete** (architecture 36.4 "retired by M10"). This is deletion work. Behaviour is unchanged; production
bytes shrink.

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md`, especially the rejected list;
- architecture 36.4, 36.11, 36.13 and 36.20;
- the package-42b record.

**Before starting:** if 42b left any of the items below in use, stop and
report. Do not keep them alive. 42b already removed the arena,
`module_loader`, `ioc_shim`, `fs`, the M9 mount/provider machinery and
(if it was dead) the registry. Verify those are gone, and remove anything
left over.

Supervisor inventory (production object sizes after package 41):

| item | bytes / files |
|---|---|
| arena module loader `module_loader` | 1,874 |
| `module_relocate` | 2,097 |
| `registry` | 1,624 |
| `ioc_shim` (IOC-FAT's temporary upcall client) | 1,157 |
| `fs` (removed in 42b) | 2,727 |
| `zdriver_api` | `include/zephyros/driver.h`; users in `romfs.c`, `ioc.c`, `iocfat.c`, `v9958_driver.h`, `irq_private.h` |
| device class/capability model | `include/zephyros/device.h` (`ZDEV_*`, caps, handles); users in sio, hid, v9958, the services |
| driver ops tables | `zchar_ops` (v9958), `zioc_ops` (ioc, iocfat). Unused: `zvideo_ops`, `zhid_ops`, `zblock_ops` |
| provider interface | `zfs_ops`, `zfs_provider`, `vfs_register_filesystem`, `VFS_PROVIDER_MAX`, `struct vfs_provider_entry` |
| VFS boot phases | the `VFS_PHASE_MODULES` module-loading phase; `kernel_load_vfs_module`, `kernel_boot_module` in `main.c` |
| M9 mount machinery | the mount table and config (`mount_config.h`, REQUIRED/OPTIONAL, mount runtime state), root-filesystem resolution, M9 descriptor kinds no longer used after 42b |
| runtime version fields | `ZDRIVER_ABI_VERSION`, `ZOS_IPC_SERVICE_API_VERSION` / the table `version` byte, `ZMOD_FORMAT_VERSION` checks at runtime |
| residency tiers | `moves` and `overflow` in `config/residency.json` and mapcheck |

## Requirements

1. **Remove completely:** source, headers, symbols, Makefile objects,
   mapcheck and residency rules, docs, and tests.
   - the arena and arena module loading, `module_loader`,
     `module_relocate` (if 41b left nothing using it), `ioc_shim`;
   - `zdriver_api`;
   - the registry;
   - the device class/capability model;
   - every driver ops table (drivers call their own functions; the
     service wrappers call the driver directly);
   - the provider ops-table interface and provider registration;
      - the module-loading VFS phase and its boot code;
   - the M9 runtime mount machinery and any descriptor kinds left over
     from 42b.
2. **ZMOD becomes a plain service image.** Keep only what 36.11 needs:
   - segments, the endpoint table and namespace entries, and the init and
     boot entries;
   - no imports, resource imports, fini entry, relocation targets or
     module types.

   Update `docs/module-format.md` (or rename it), `tools/zmodpack.py`, and
   the loader.
3. **Version checks** happen on the host only (in the packer). Remove the
   runtime version fields and checks.
3b. **Loader: a flat load plan** (41b review). `service_read_layout`
   (1,899 of the loader's 4,628 bytes) parses and re-validates container
   tables the packer already validated. Make the packer emit a flat plan
   (segment address, length and offset; the endpoint table; the dependency
   table) that the loader iterates with protective bounds only. Target: the
   loader is at most 2,000 bytes. Report the bytes.
4. **Residency** has two tiers, `fixed-required` and `cold`. Place every
   object, and simplify mapcheck to match.
4b. **From the 42b review:**
   - **delete the arena reservation** (24 free granules, 12,288 bytes),
     `kernel/module/arena.asm` and the `GEOMETRY_*`/arena derivation, so
     the cold data base derives straight from the code end;
   - **fix the driver ledger**: production `pack_image` must print the real
     `driver hot`/`driver boot/bulk` figures from the services plan (today
     it prints 0; the plan says 21,838 hot);
   - delete `include/zephyros/{driver,vfs}.h` if they have no users.
5. **`main.c` boot path.** Remove the module/arena boot code. Report what
   remains and its bytes.

## Constraints

- No behaviour change. All outcome tests keep passing.
- **Tests:** delete the tests whose subject is removed, with a reason
  each. Inventory candidates:
  - `target/m9/m9_provider_test.c`, `test_m9_provider_sim.py`,
    `m9_provider_selftest.h` and the `m9-provider-selftest` image
    (provider ABI);
  - `target/loader/loader_test.c`, `loader_selftest.h` (arena loader);
  - `test_block.py` (`ZDEV_BLOCK`);
  - `test_driver_abi.py` (driver ABI);
  - the module-format parts of `test_zmod.py`;
  - registry, arena and granule assertions elsewhere.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-prune-nucleus.md`, with bytes removed per
  item.

## Validation (once, on the final source)

```sh
make clean && make check
make m9-selftest m9-exec-selftest m9-iocfat-selftest
make console-integration-selftest console-fallback-selftests ipc-selftest
git diff --check
```

Grep gate (empty outside `docs/validation/` and `work/`):

```text
zdriver_api ZDEV_ zchar_ops zioc_ops zvideo_ops zhid_ops zblock_ops zfs_ops
zfs_provider vfs_register_filesystem device_register module_relocate
ioc_shim VFS_PHASE_MODULES ZDRIVER_ABI_VERSION
```

Hardware (owner): `make smoke-hardware`, and production with and without
a FAT card.

## Acceptance criteria

- Every listed item is gone, and the grep gate is empty.
- Behaviour is unchanged.
- Bytes removed are reported per item, with the five ledgers before and
  after.
