# 45-m10-acceptance — progress

## State (start)

Baseline `6b313c2` (44b far code), clean tree.  Package 45 proves
architecture 37 on the final tree, closes the ledgers and documents, and
writes the owner hardware checklist.

## Coverage analysis (done before edits)

Read the section-37 rows against the current tests.  Rows and evidence:

- hardware rows: checklist (owner).
- residency: mapcheck/pack_image ledger lines + `ipc-selftest` stack
  high-water replay.
- IPC/typed lifecycle: `ipc-selftest` (client suite + replay); the
  descriptor, nested-call, IRQ and near-direct rows all have in-program
  outcome checks.
- host assembly/drivers: `tests/test_service_images.py`,
  `test_ipc_selftest.py` layout, `test_zmod.py`.
- namespace/devices/files/process: `ns-selftest`, `fs-selftest`,
  console images.
- xmem/far/lifetime: `xmem-selftest` (parent + far program).
- ZEX v2: `test_zex.py` + subsystem process selftest (8a-8e).

Gaps found:

1. **CWD (N7 + the CWD-inheritance half of P4).** No acceptance program
   exercises `chdir`/`getcwd`; and `vfs_ns_dir_check("/")` refuses the
   VFS root with `-ZOS_ENOTDIR`, a regression from M9 (the retired
   `fstest` checked `chdir("/")` and `chdir("..")` back to `/`).
   Fix: accept `/` as traversable in the nucleus; close with outcome
   checks in the ns image.
2. **Ordinary ZEX v2 `P = 0 throughout`.** The subsystem probe already
   proves the bank is not cleared (marker at `D000h`), but nothing reads
   the latch from inside an ordinary program.  Close: read port 00h in
   `zex2probe` and fail unless mode 10 / page 0.
3. **Required-driver init failure.** The console-serial fail image proves
   the explicit stop for a *missing* image; the loader's init-status
   refusal branch has no outcome test.  Close: a test-only service image
   whose init returns 1, in a second failure store of the existing
   `console-serial-selftest` target.

## Work log

- (start) progress file created; coverage analysis done.
- CWD fix (`kernel/vfs/ns.c`: the VFS root is traversable) + ns client and
  child outcomes + replay transcript + host pins.  `make ns-selftest`
  green (93/93 checks).
- `zex2probe` reads the latch (mode 10, P = 0) with a new fail code;
  `make subsystem-selftest` green (`zex2probe` exit status gates it).
- Init-failure service image (`tests/target/console/init_fail.c`,
  `tests/console/manifests/init_fail.json`,
  `tests/console/manifest-init-fail.json`, Makefile selection + rules +
  third image in `console-serial-selftest`); the new replay test passes
  (`service loader: init_fail.zmod: invalid`, `console: service failed`,
  halt).
- Docs: architecture 36.16 per-object limits; 34 M10 close + ledgers;
  sdk.md one `_FAR_CODE` area per link; memory.md + abi.md gate stack 384;
  devices.md 12.6 placement numbers; architecture common-ledger prose
  (released M9 reservation); README M10 entry; report
  `docs/validation/2026-10-11-m10-acceptance.md` complete.
- Formal validation on the frozen tree: `make clean && make check` exit 0
  (100.19 s; reproducible `fd443671…`; 575 tests OK, 104 skipped);
  full image matrix exit 0 (640.60 s; 159 replay tests OK); the fardemo
  image built beside it and replayed by hand (expected transcript);
  `git diff --check` clean.
- First matrix attempt exposed a missing prerequisite in the new
  init-failure pack rule; fixed, definitive batch re-run clean.
- Report sections written: coverage map of all section-37 rows, ledgers,
  matrix hashes, hardware checklist (7.1-7.8), warnings.
- Status: complete.  No commit made (per the task).

