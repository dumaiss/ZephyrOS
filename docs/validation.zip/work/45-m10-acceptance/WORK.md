# Task

**M10 acceptance** (architecture 36.24, step 11; section 37). Prove the
whole of section 37 on the final tree. Close the milestone documents and
 No new features: what fails here
is fixed minimally, or reported.

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md`;
- architecture 34-37;
- every M10 record from package 37 on, in `docs/validation/`.

## Requirements

1. **Coverage map.** Map every architecture 37 row to the test, image or
   hardware step that proves it. List gaps, and close each one with a
   focused outcome test in the image that owns the subject. Add no new
   images unless a row truly needs one.
1b. **From 43:** write the derived **per-object** limits into
   architecture 36.16:
   - one plain xmem object (one far block) is at most 32 KiB (slots 0-3,
     since the aperture slice is reserved);
   - one mappable object is at most 16 KiB.

   State explicitly that these are not application limits. A program has
   its 56 KiB primary bank plus any number of far blocks and far-code
   segments, bounded only by the free slots of banks 0-5.
2. **Final ledgers** against 36.20, with the headroom targets:
   - nucleus fixed (at least 2,048 bytes free);
   - nucleus cold (at least 4,096);
   - driver hot (at least 4,096);
   - driver boot/bulk;
   - common (ceiling 3,072);
   - gate-stack worst case (at most 360);
   - driver-stack high-water mark.

   If a target is missed, report the gap in bytes. Do not raise anything.
3. **The full image matrix,** built once, with `make check`.
4. **Hardware matrix (owner).** Write one checklist covering every
   hardware-authoritative row:
   - bank switching and the aperture;
   - driver IRQs on real sources;
   - both console builds (V9958 + keyboard, serial), ESC `c`;
   - production with and without a FAT card, files under `/FS`, and the
     monitor from `/SYSTEM`;
   - nested exec;
   - xmem, and far code;
   - CP/M still boots.

      Each item gives the image, its hash and the exact steps.

   The owner runs it after this package. Board runs still open from the
   M10 records:
   - `ipc-selftest` (39);
   - `fs-selftest` with a card and with none, plus nested exec (42b);
   - `subsystem-selftest` (44a);
   - `xmem-selftest`, including far code (43, 44b);
   - the `fardemo` image (44b);
   - production `make smoke-hardware`.

   Already passed on the board, so list them as passed: production boot,
   the V9958 console with keyboard input, ESC `c`, and the
   `console-serial` build.
5. **Documents.**
   - `docs/sdk.md`: one `_FAR_CODE` area per link; several far segments
     need differently named areas, each based at `8000h` (44b review).
   - Architecture 34: mark M10 COMPLETE pending the owner's hardware
     sign-off.
   - The as-built docs agree with the tree.
   - Add a short M10 summary of what was built and the final ledgers.

## Constraints

- Fixes are minimal and reported individually. Anything larger is
  reported, not fixed.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-acceptance.md`.

## Validation

```sh
make clean && make check
make <the full image matrix>
git diff --check
```

## Acceptance criteria

- Every architecture 37 row is mapped to passing evidence or to a
  hardware checklist item.
- The ledgers meet 36.20, or the gaps are reported in bytes.
- The documents are closed.
- The owner signs off the hardware checklist.
