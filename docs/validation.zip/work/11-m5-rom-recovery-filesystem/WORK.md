# Task

Implement milestone M5: add a deterministic read-only ROM recovery filesystem, safe runtime ROM-page access, and a ROMFS-backed boot-module source so the production SIO ZMOD is no longer linked into the kernel image as an embedded byte array.

## Context

M4 and the stage-10 ownership cleanup are the baseline. Do not dispatch this package until the pending stage-10 physical M4 smoke matrix in `docs/validation/2026-10-03-stage10-source-cleanup.md` has passed. Preserve the accepted ZMOD v1 bytes, relocation, allocation, rollback, device registration, and console behavior.

The current implementation truth differs from one historical sentence in architecture section 24.2: ROM page 1, not page 7, contains the bank-7 kernel. Preserve pages 0 and 1 and declare ROMFS pages 2 through 7 in platform configuration. The programmed image becomes eight 64-KiB pages (512 KiB). Only `0000h-BFFFh` of each recovery page is a logical ROMFS window, giving six 48-KiB windows and 288 KiB capacity; `C000h-FFFFh` remains `FFh` and inaccessible to ROMFS.

Define ROMFS v1 exactly as little-endian: a 16-byte header (`magic[4]="ZRFS"`, `version:u8=1`, `entry_size:u8=36`, `file_count:u16`, `directory_size:u16`, `reserved:u16=0`, `image_size:u32`) followed by fixed 36-byte entries (`name[24]`, NUL-terminated and zero-padded; `logical_offset:u32`; `size:u32`; `flags:u16`; `reserved:u16=0`) and packed payloads. Flags are one of ZMOD=1, ZEX=2, DATA=3. Names are case-sensitive native names. Payloads begin after the complete table and are packed in manifest order without alignment gaps.

## Requirements

- Add matching ROM/page geometry to `platform/zephyr80/` C/assembly constants and build configuration. Update the image packer to consume `build/recovery.romfs`, preserve boot pages 0/1, place the logical stream across pages 2-7, reject collisions/window overflow, fill every unused byte with `FFh`, and emit per-page hashes and ROMFS placement in the image manifest.
- Implement `tools/romfspack.py` with `pack`, `validate`, and `dump` modes over `recovery/manifest.json`. Reject duplicate/unterminated/overlong names, unsupported flags, missing inputs, reserved fields, table/payload overlap, 32-bit wrap, truncation, capacity excess, and any logical mapping into a page's `C000h-FFFFh`. Output must be reproducible and include a human-readable map listing logical range, physical ROM page/range, type, size, and SHA-256.
- Add `include/zephyros/romfs.h`, `kernel/romfs/romfs.c`, and common-resident `kernel/romfs/rom_access.asm`. Implement allocation-free `romfs_init`, `romfs_lookup`, and bounded `romfs_read`, including reads at EOF and across 48-KiB page boundaries. Fully validate the header/table before publishing the filesystem.
- The ROM access path must validate page/offset/length before changing mappings, lock interrupts, save the exact latch and IFF state, switch to a dedicated common stack, enter shadow mode on SRAM bank 0, copy through a bounded common staging buffer, restore the exact latch/stack/IFF state, and be non-reentrant. No instruction, return address, or active stack may depend on `2000h-DFFFh` while ROM is visible. Extend map/image validators and linked-byte simulation to prove these properties.
- Preserve `module_load()` for existing M4 fixtures and add a generic bounded read-source adapter used by both memory blobs and ROMFS. Share validation/loading logic; do not fork a second ZMOD loader. The source-backed path must validate the entire container structure before allocating the arena, stream payload/relocation bytes safely, and retain M4 transactional rollback. The ZMOD on-disk format and `sio.zmod` bytes must not change.
- Replace the production embedded catalog with `romfs_lookup("sio.zmod")` and source-backed loading. Embedded catalogs remain test-only for M4 acceptance. Add a production mapcheck rejection for embedded boot blob/catalog symbols.
- Add M5 success and corrupt-metadata target images. Success must boot the ROMFS SIO module, bind `sio0.b`, exercise first/last/cross-page reads, and print `m5 romfs selftest: OK` through the normal console. Corruption must fail before module execution and print a precise early-console panic/failure marker.
- Update `docs/boot.md`, `docs/memory.md`, `docs/module-format.md`, architecture implementation notes, and add `docs/romfs-format.md` plus a dated validation record. Keep IOC, SD, FAT, writable filesystems, directories, and user-process work out of scope.

## Files

- `platform/zephyr80/{config.mk,memory.h,memory.inc}`
- `include/zephyros/romfs.h`
- `kernel/romfs/{romfs.c,rom_access.asm}`
- `kernel/module/{loader.c,embedded.c}`
- `recovery/manifest.json`
- `tools/{romfspack.py,pack_image.py,mapcheck.py,serial_smoke.py}`
- `Makefile`, `tests/`, `docs/`

## Constraints

- Preserve unrelated worktree changes and all M0-M4 acceptance behavior.
- No heap, write support, generic VFS API, compression, CP/M naming, MAME dependency, or raw ROM pointer exposed to bank-7 code.
- All offset/range arithmetic must be checked before narrowing. A corrupt image must never drive a latch value or executable address.
- Binary-changing work invalidates earlier whole-ROM hashes. Record the unchanged `sio.zmod` hash separately.

## Validation

```sh
make clean
make check
make zmod-test
make m4-loader-selftest
make m4-selftest
make m4-placement-selftest
make m4-failure-selftest
make romfs-test
make m5-selftest
make m5-corrupt-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean
```

Flash `build-m5-selftest/zephyros-m5-selftest.bin` and run `make smoke-hardware-m5 SERIAL_PORT=...`; then flash the corrupt image and run `make smoke-hardware-m5-corrupt SERIAL_PORT=...`. Record image hashes, 115200 8N1 transcripts, and status under `docs/validation/`. If hardware is unavailable, mark M5 `PENDING` and do not dispatch M6.

## Acceptance criteria

- ROMFS packing, physical placement, lookup, boundary reads, corruption rejection, and exact latch restoration are demonstrated by positive and negative tests.
- Production contains no embedded boot ZMOD and loads the byte-identical SIO module from ROMFS through the shared M4 loader.
- Normal dynamic console operation and every earlier milestone suite remain green.
- Physical success and corrupt-image failure paths are captured before M5 is accepted.
