# 87c01 progress

## Done

- `tui_text.asm` rewritten. The cell walk keeps its state in registers.
  - **Main set:** B the cells left, C the attribute in both nibbles, DE
    the text, HL the character cell, IX the attribute byte.
  - **Alternate set:** B' the dirty bit, HL' a 16-bit pointer to the
    dirty byte (the fix), DE' the invert-map offset, C' "changed".
  - **Parity:** two loop bodies. The even cell tests the whole attribute
    byte first; when it matches, the odd cell checks only its character.
  - **model_only:** a zero mask, so the bitmap updates are no-ops and the
    pending flag stays clear.
  - **Multiply:** a shift-and-add replaces `__mulint`.
- `tui_flush.c`:
  - `tui_next_pending` scans the pending flags with a pointer, and only a
    pending row computes its base index.
  - The pending flags are cleared with `memset`.
  - The 8-cell skip steps the index by 8 instead of multiplying.
- `tui_scroll.asm` audited: its byte-wide state is a parity, a column
  count (128 at most) and an attribute, and its cell offsets are 16-bit.
  Nothing changed.
- **Tests:**
  - `tests/tui/tui_puttext.c` (new, shared): full-width rows at the last
    two rows and the middle row, each with an attribute-only change. It
    is linked into `tui_test` and into the new `tui_putwide` program
    (128-column map; `tui_wide` had no room for it).
  - `test_tui_sim`: the puttext tests compare the captured RENDER
    *streams* byte for byte, read at the program's `console_render`
    entry. Before, they compared lengths only.
  - `test_tui_sim`: `test_timing_mode_meets_the_budgets` replaces
    `test_timing_mode_runs` and asserts all five figures.
- **Proof the new tests catch the bug:** with the 87 `tui_text.asm`, both
  puttext tests fail. The 85-column phases emit different stream counts;
  the wide streams differ in content.

## Figures (program-bank T-states, V9958 lane)

| figure | 87 | budget | 87c01 |
|---|---|---|---|
| put_text 85 equal | 31,086 | 12,000 | 10,436 |
| put_text 85 new | 71,667 | 30,000 | 29,041 |
| flush, nothing pending | 40,522 | 8,000 | 5,872 |
| flush, one dirty row | 57,537 | 60,000 | 24,133 |
| scroll model, 24 rows | 124,482 | 150,000 | 89,823 |

The 87 figures are the record's own; 87c01's are measured with
`_timed_calls`.

## Sizes

| program | headroom before | after |
|---|---|---|
| `tui_test` | 3,351 | 2,601 (the new equivalence rows) |
| `tui_wide` | 239 | 611 |

## Validation

Green: 101 TUI tests, KonaCommander and KonaEdit suites OK, diff check clean; record: Correction 1 in docs/validation/2026-10-23-tui-fast-path.md.
