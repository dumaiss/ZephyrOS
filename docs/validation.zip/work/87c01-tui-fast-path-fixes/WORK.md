> Worker package. Correction to 87 (commit 62ecbcd). libtui and its
> tests only. Runs before 88: 88 draws its status row with
> `tui_put_text`.

# Task

Fix a bitmap-index overflow in `tui_put_text`, bring the three
over-budget figures of 87 in, and wire the timing assertions 87 asked
for.

## Current state

- **The bug:** `user/sdk/tui/src/tui_text.asm` keeps the dirty/invert
  byte index (`tui_text_didx` = cell index >> 3) in one byte. It stores L
  only after the shift, and steps with `inc a`.
  - **85-column build:** row 24 starts at cell 24 x 86 = 2,064, which is
    byte 258 and wraps to byte 2, a row-0 byte.
  - **128-column build:** the wrap starts at row 16.
  - **Effect:** for those rows, characters change in the model but the
    dirty/invert bit lands in another row's bitmap. The right row is
    never drawn, and row 0 gets stray redraws.
  - **Why no test caught it:** `puttext_mode` (`tests/tui/tui_modes.c`)
    writes only rows 0-2.
- **Speed:** the cell loop keeps its state in memory variables
  (`tui_text_parity`, `_mask`, `_didx`, `_nib`, `_chars`, `_text`,
  `_remain`, `_byte`, `_dopend`, `_pdone`). It measures 31k T for 85
  equal cells and 72k for 85 new ones (budgets 12k and 30k).
- **Flush:** `tui_flush_render` with nothing pending measures 40.5k
  (budget 8k): two passes over the rows, with a `TUI_CELL_INDEX` multiply
  per row before the pending test.
- **Timing test:** `test_timing_mode_runs` checks only that the scripted
  sequence finishes.

Read: `work/00-WORKER.md`; `work/87-tui-fast-path/WORK.md`;
`docs/validation/2026-10-23-tui-fast-path.md`; `tui_text.asm`;
`tui_flush.c`; `tests/tui/tui_modes.c`, `tui_test.c`;
`tests/test_tui_sim.py`.

## Requirements

1. **Index** (Must). The dirty/invert position in `tui_put_text` is a
   16-bit pointer, or a 16-bit offset added to `_tui_dirty` /
   `_tui_invert`, valid over the whole map (cell count up to 4,480 for
   128x35). Grep `tui_text.asm` and `tui_scroll.asm` for any other
   8-bit index derived from a cell index, and fix those too.
2. **Coverage** (Must). The equivalence mode also writes the last two
   rows of the reported grid and one middle row, each with a full-width
   `tui_put_text` and with an attribute change. The wide archive runs it
   too, including rows 16, 17 and 34. Render records must be equal byte
   for byte. Before the fix this test must fail; say so in the record.
3. **Cell loop** (Must). Rewrite the loop to keep its state in
   registers:
   - **Main set:** text, chars and attrs pointers, and the dirty pointer
     with its bit mask, in the main set, `IX`/`IY`, or the alternate set
     via `EXX`.
   - **Exception:** only the rare invert path may touch memory
     variables.
   - **Parity:** handle the two nibble parities by unrolling two cells
     per iteration, or by two loop bodies, rather than testing a parity
     variable per cell.
   - **Pending flag:** set it once, after the loop, if any cell was
     dirtied.
   - **Budgets:** 85 equal cells <= 12,000 T; 85 new cells <= 30,000 T.
4. **Flush walk** (Must). The pending test comes before any per-row
   index work, and the row base index is stepped by the stride rather
   than multiplied. With nothing pending: <= 8,000 T.
5. **Assertions** (Must). `test_timing_mode_runs` asserts all five
   figures of 87's budget table, measured as 87 described (program-bank
   T-states, entry to return), on the V9958 lane.

## Budgets

| figure | now | budget | on overrun |
|---|---|---|---|
| `tui_flush`, nothing pending | 40,522 | <= 8,000 T | stop and report |
| `tui_flush`, one dirty row | 57,537 | <= 60,000 T | stop and report |
| `tui_put_text`, 85 equal | 31,086 | <= 12,000 T | stop and report |
| `tui_put_text`, 85 new | 71,667 | <= 30,000 T | stop and report |
| `tui_scroll_rows` model, 24x85 | 124,482 | <= 150,000 T | stop and report |
| `tui_wide.exe` headroom | 239 B | >= 0 (links) | stop and report |

"Stop and report" means: stop, write the profile, and ask. Do not
record an overrun as follow-up and close the package.

## Criteria

- **Must:** requirements 1-5, all budgets, and the TUI suites, KonaEdit
  and KonaCommander green.
- **Informational:** the bytes of `tui_text` code before and after.

## Validation

Develop with single tests by dotted name. Run the block once, at the
end.

```sh
make && make sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_console_tee
make -C UserSoftware/KonaCommander test
make -C UserSoftware/KonaEdit test
git diff --check
```

Record: append a "Correction 1" section to
`docs/validation/2026-10-23-tui-fast-path.md`.
