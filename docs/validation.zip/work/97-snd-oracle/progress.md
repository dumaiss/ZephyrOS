# 97-snd-oracle progress (present tense)

- Read WORK.md, 00-WORKER.md, snd-sdk.md, the two players, z80sim SoundPeer,
  replay helpers, test_sdk_package/test_source_layout, mk/kos.mk, exe.mk.
- Plan: host oracle tools under tests/snd/oracle with include/ stubs; fixtures
  via gen_fixtures.py; golden traces + malformed table in tests/snd/golden/;
  tests/snd_harness.py; sndprobe.c; tests/test_snd_oracle.py.
- Next: write fixtures generator and the two oracle tools.
