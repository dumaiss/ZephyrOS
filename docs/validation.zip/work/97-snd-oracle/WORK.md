> Worker package. First of the libsnd series (97-103, `docs/snd-sdk.md`
> section 10, SND-0). Freeze the behaviour libsnd must reproduce, as
> golden register traces, and build the test harness the series uses. No
> libsnd code, no OS change.

# Task

libsnd extracts two working players: SNTracker's ZTR player
(`UserSoftware/SNTracker`, C) and VGMPlayer's ZVGC decoder
(`UserSoftware/VGMPlayer/vgmplay.c`). Before any code moves, record
exactly what they write to the PSGs, tick by tick, for real songs. Every
later package proves itself against these traces.

## Current state

- **SNTracker** (`UserSoftware/SNTracker`): `ztr.c` (load and validate),
  `player.c` (rows, macros, effects: `player_start`/`player_tick`),
  `psg.c` (the channel-to-register render, a register cache, one
  `sound_write` batch per tick), `sntracker.h` (the channel state and
  event bits). It loads a whole file of at most 20,480 bytes into RAM.
  `tests/test_ztr_host.c` already builds the loader on the host.
- **VGMPlayer** (`UserSoftware/VGMPlayer/vgmplay.c`): ZVGC v1/v2, a
  16-byte header and the opcodes `END`, `WRITE`, `WAIT16`, short waits
  `40h-7Fh` and write runs `80h-8Fh`. A 180 Hz base timer with a phase
  accumulator, and `sound_out` to PSG0 from the handler.
- **Formats:** `ZTR-Format.md` and `CSM-Language.md` are in
  `../Zephyr-80/Code/HOST/SNTracker/docs/`. The songs are in
  `../Zephyr-80/Code/HOST/SNTracker/songs/` (`night-market.ztr` 20,234
  bytes, `RunawayCircuit.ztr` 17,550). The compiler is
  `../Zephyr-80/Code/HOST/VGMPlayer/tools/compile_vgm.py`.
- **Both apps** still build against SDK 0.1.0. Their tests are source
  greps only.
- **The simulator:** `tests/z80sim.py` `SoundPeer` records every card
  write as `(port, value, T-state)`.

Read: `work/00-WORKER.md`; `docs/snd-sdk.md`; `ZTR-Format.md`; the two
apps' sources.

## Requirements

1. **Fixtures** (Must). In `tests/snd/fixtures/`:
   - the two ZTR songs, copied byte for byte;
   - at least two ZVG streams made with `compile_vgm.py`: one with write
     runs and short waits, one with `WAIT16`. Use a small VGM you write
     with a script (the generator is checked in), or a public-domain
     one;
   - malformed fixtures for both formats, one per validation rule in
     `ZTR-Format.md` and each ZVGC header/opcode check. Generate them
     with a script from the good files.

   Record each fixture's provenance in `tests/snd/fixtures/README.md`.
2. **ZTR oracle** (Must). A host build of SNTracker's `ztr.c` and
   `player.c` with `psg.c`'s render, unchanged: link a host
   `sound_write` that records. A tool `tests/snd/ztr_trace` writes, for
   N ticks:
   - per tick: the ordered `(chip, byte)` writes;
   - optionally the 16 channels' state (note, volume, period, macro
     positions) as a second file.

   Golden traces in `tests/snd/golden/` for both songs, at least 3,000
   ticks or to the song's end. Note how the C player's register cache
   suppresses unchanged bytes: libsnd must match it, writes included.
3. **ZVG oracle** (Must). A host build of `vgmplay.c`'s decoder
   (`decoder_tick` and its ring), fed whole files. It writes the
   per-tick byte sequence; golden traces for each ZVG fixture.
4. **Malformed outcomes** (Must). For every malformed fixture, the
   oracle's result (the error and the stage) in a table in the golden
   directory. libsnd may tighten a check (the format document wins);
   the record lists each.
5. **The target harness** (Must). `tests/snd_harness.py`, for the series:
   - **replay:** boot the production image with a card (fixtures on
     it), run a program, then collect the `SoundPeer` writes, split per
     tick by a marker write. Use the DAC, port E4h, value 0xA5, which
     no song uses; document it;
   - **compare:** a tick-by-tick comparison with a golden trace. A
     mismatch names the tick and the first differing byte;
   - **timing:** CPU T-states between marker pairs, excluding interrupt
     service (attribute by PC, as `tests/gfxprof.py` does). A profile
     mode lists functions.

   Test the harness on itself: a small program, `tests/snd/sndprobe.c`,
   writes a known sequence through `sound_out`, and the harness reads
   it back.
6. **Docs** (Must). A short `tests/snd/README.md`: the tools, the
   formats of the trace files, how to regenerate the goldens.

## Tests

- **`tests/test_snd_oracle.py`:**
  - the oracle tools build;
  - they reproduce the checked-in goldens byte for byte;
  - the malformed table matches.
- **The harness self-test:** sndprobe's writes and ticks decode exactly.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | stop and report |
| host oracle run, both songs | - | report | - |

## Owner checklist

None (host and simulator only).

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make
python3 -m unittest tests.test_snd_oracle
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-oracle.md`.
