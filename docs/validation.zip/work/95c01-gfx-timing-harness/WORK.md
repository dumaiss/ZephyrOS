> Worker package. After 95, before 96. A correction: the libgfx timing
> harness measures instructions, not T-states. Fix the clock, re-measure
> every figure, and profile each one. **Measurement only: no libgfx
> optimisation** (the next package works from this record). No OS change.

# Task

The libgfx budgets in packages 93-95 were reported in T-states but
counted in CPU instructions, so every figure is 8-12 times too small. Make
the V9958 peer's clock run on T-states. Re-time the command-duration
model at the board's real clock ratio. Re-measure every libgfx figure,
plus the figures package 96 depends on. Give each one a per-function
profile.

## Current state

- **The peer's clock:**
  - `tests/z80sim.py` sets `vdp_peer.now = self.cycles` in `io_in` and
    `io_out`, and `cycles` is the instruction count (`cycles += 1` in
    `step`);
  - `reg_writes`, `status_reads`, `addr_writes`, `busy_until` and the
    command records all carry that clock;
  - the frame clock (`advance(tstates)`, `frame_period`) already runs on
    T-states, so the retrace window is right.
- **The duration model** (`V9958Peer._command_duration`):
  - it takes openMSX's per-unit VDP ticks, then assumes 3 VDP ticks per
    T-state and "÷10" to reach instructions;
  - the board runs the Z80 at 10 MHz and the V9958 at 21.477 MHz: 2.148
    VDP ticks per T-state (confirm the crystal on the Zephyr-80
    schematic);
  - `command_busy=400` (the default with the model off) is also in
    instructions.
- **The supervisor's re-measurement**, on the current build, T-states
  via `z.tstates` at the same markers:

  | figure | instructions (today's pin unit) | T-states | target |
  |---|---|---|---|
  | one aligned `gfx_fill_rect`, queue + flush | 308 | 3,803 | 1,200 |
  | `gfx_line` | 404 | 4,692 | 1,500 |
  | filled circle r=50 | 123,107 | 1,430,723 | 150,000 |
  | outline circle r=50 | 180,840 | 2,097,885 | 250,000 |
  | 128-glyph 4×6 row, G6 | 27,595 | 232,264 | 100,000 |
  | 6×8 G6, 8-glyph string | 5,417 | 55,458 | 8,000 |
  | 4×6 G7, 6-glyph string | 3,174 | 33,980 | 6,000 |
  | transparent G6, 4 glyphs | 3,722 | 43,048 | 4,000 |
  | transparent G7, 4 glyphs | 3,542 | 40,979 | 4,000 |
  | atlas build, G6 | 196,600 | 2,335,563 | report |
  | stale redraw | 18,017 | 211,503 | report |

- **Profiler pattern:** `work/88-konaedit-view/keprof.py`. It attributes
  exclusive T-states per function, with call counts, from SDCC listings
  and the map.

Read: `work/00-WORKER.md`; packages 93-95's records; `tests/z80sim.py`
`V9958Peer`, plus `io_in`, `io_out`, `step` and `_clock` (both cores,
`tests/simcore/`); `tests/test_gfx.py` `TestGfxTiming`, `TestGfxPages`
and `TestGfxAtlas`; `tests/gfx/gfxtest.c` (the `timing` and `atlas`
marks).

## Requirements

1. **One clock** (Must):
   - the peer's `now` is the CPU's T-state count, in both cores;
   - every timestamp the peer records, `busy_until` included, is in
     T-states;
   - the default `command_busy` is re-expressed in T-states, keeping
     today's behaviour (about 4,000);
   - existing tests that compare peer timestamps (the pages, vblank,
     console and TUI replays) are re-pinned in T-states. Nothing else
     changes meaning.

   If the ripple reaches past the V9958 peer's users, stop and report.
2. **Duration model** (Must). `_command_duration` returns T-states: the
   VDP ticks per unit (openMSX `VDPCmdEngine`, display on, sprites off)
   × 10 / 21.477. Keep the docstring's citation and its error bound
   (access-slot contention omitted, a lower bound). Name the clock
   constants once (`CPU_HZ`, `VDP_HZ`).
3. **Re-measure** (Must). Every figure in the table above, plus these
   new `gfxtest timing` marks (96's workload):
   - a 128-segment polyline across 512×48 (the scope);
   - a 128-glyph 4×6 G6 row with a colour pair not yet cached (a stripe
     change), and the same row cached;
   - a 512×6 stripe fill (`gfx_fill_rect`, COPY, aligned);
   - `gfx_show_page`, excluding its vblank wait;
   - a partial present of a 128×40 G6 band, CPU and VDP time (model).

   Record CPU T-states for all of them. For the VDP-bound ones (the
   copies, transparent glyphs, fills) also record the model's VDP time
   and how much the CPU overlaps it.
4. **Profile** (Must). `tests/gfxprof.py` (a tool, after `keprof.py`):
   - per-function exclusive T-states and call counts between a marker
     pair;
   - libgfx sources' listings, statics included;
   - assembly members named from the map.

   For each figure, record the top functions until 90% of the total,
   tagged C or asm.
5. **Pins** (Must). The timing assertions in `tests/test_gfx.py` use
   T-states:
   - each one is a ceiling at the measured figure + 10%, a regression
     guard;
   - the target goes in the assertion message, for example "target
     1,200".

   The optimisation package lowers them. No other expected output
   changes.
6. **Docs** (Must). `docs/sdk.md`'s measured libgfx costs (package 95's
   paragraph) are replaced by the T-state figures. The tree states
   them as they are now, with no history.

## Tests

- **Units:** a peer unit test. Two register writes a known number of
  T-states apart (a fixed instruction sequence) record exactly that
  difference. A HMMM of N bytes keeps CE busy for the model's T-states.
- **Replays:** `TestGfxTiming`, `TestGfxAtlas` and `TestGfxPages` pass
  with the re-pinned ceilings.
- **Spot check:** the supervisor's figures above reproduce within 1% at
  the same markers.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | stop and report |
| libgfx bytes | unchanged | 0 (gfxtest grows only) | stop and report |

## Owner checklist

None: simulator-only.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_vblank tests.test_sim_core
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-gfx-timing.md`. It holds:
- every figure: CPU T-states, VDP time where it applies, and target;
- the per-figure profiles;
- the clock ratio and its source.
