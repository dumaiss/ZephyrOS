# Package 95c01: gfx timing harness - progress

Status: complete (validation block green).

## Clock and model
- `tests/z80sim.py`: `CPU_HZ = 10000000`, `VDP_HZ = 21477272`; the
  V9958 peer's `now` is `Z80.tstates` at every VDP I/O (both cores
  share `io_in`/`io_out`); `command_busy` default 4000 T-states;
  `_command_duration` returns T-states (openMSX VDPCmdEngine per-unit
  ticks x CPU_HZ / VDP_HZ: HMMV 48/byte, HMMM 88/byte, LMMV 96/dot,
  LMMM 120/dot, LINE 84/dot+24, PSET 112, +40 issue).

## Marks and measurement
- `tests/gfx/gfxtest.c` `gfxtest_timing`: 12 marker pairs - the
  legacy five plus the 128-segment polyline, the uncached/cached
  128-glyph 4x6 row, the stripe, the page switch, the vblank and the
  partial present.
- Measured T-states: fill 3,803 (spot-check exact), line 2,793,
  filled 1,401,366, outline 2,039,101, polyline 725,495, row-new
  286,086, row-cached 234,197, stripe 3,803, page 197,315, vblank
  166,299, present CPU 5,936 with VDP 104,910 (model) and CPU
  overlap 98,974.  Atlas figures: 55,458 / 2,333,664 / 211,503
  reproduce the supervisor's table exactly; the line and circle
  figures shifted with the link layout (bank-crossing thunks) - the
  record documents it.

## Pins and tests
- `TestGfxTiming` rewritten: T-state ceilings at measured + 10%,
  frame clock and duration model on from the 12th marker, the
  partial-present VDP check; `TestGfxAtlas` ceilings in T-states;
  `TestGfxPages` wording; new `VdpClockUnit` (two register writes
  48 T-states apart; an HMMM's CE window is the model's T-states).
- All 25 `tests.test_gfx` tests pass.

## Profiler and docs
- `tests/gfxprof.py`: per-function exclusive T-states + call counts
  per figure, down to 90%, SDCC listings + map (keprof's pattern).
- `docs/sdk.md`: package-95 paragraph now states the T-state
  figures.  `docs/validation/2026-10-25-gfx-timing.md` holds the
  figures, profiles, clock ratio and validation.

## Along the way
- `UserSoftware/GfxDemo/src/gfxdemo.c` updated to the package-95
  font API (`GFX_FONT_6X8` tags) - the demo no longer fails to
  build against the current SDK.
- `pview.exe`/`gfxdemo.exe` rebuilt against the current SDK (their
  unpacked SDK copies and objects were stale from package 94);
  TestPView and TestGfxDemo pass again.
