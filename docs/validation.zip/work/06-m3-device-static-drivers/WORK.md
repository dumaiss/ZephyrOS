# Task

Implement milestone M3 on the accepted M2 kernel: introduce a fixed-size device registry, capability-based lookup, a versioned internal driver API and explicit static-driver table, a statically linked polling SIO0/B driver, and a minimal console service bound to registered devices. Prove that the early console remains an independent fallback.

## Context

`docs/architecture.md` sections 20–21 define driver, device, capability, and service as separate concepts. All M3 driver code/state lives in bank 7. M2 owns IM2, common IRQ crossing, logical source claims, and `RETI`; a driver may register only a bank-7 handler through `irq_claim`.

Use a heap-free registry of 16 entries. Handle `0` is invalid; issued handles are `1..16` and are not a permanent external ABI. Initial classes are `ZDEV_SERIAL`, `ZDEV_VIDEO`, `ZDEV_STORAGE`, `ZDEV_INPUT`, `ZDEV_TRANSPORT`, and `ZDEV_OTHER`. Initial capability bits are `ZCAP_CHAR_IN`, `ZCAP_CHAR_OUT`, `ZCAP_CONSOLE_IN`, and `ZCAP_CONSOLE_OUT`.

SIO0/B uses data/control ports `22h/23h`, 115200 8N1. The M0 early-console path continues to access it directly for boot and panic. The normal M3 driver may poll TX/RX and may explicitly re-establish the documented SIO configuration during initialization.

## Requirements

- Add internal headers for device and driver contracts. Define `zdev_handle_t`, descriptor/ops structures, class IDs, capability bits, errors, and driver ABI version 1. Keep structure layout private to the kernel/driver ABI; it is not a user syscall ABI.
- Implement `device_registry_init`, `device_register`, `device_get`, and `device_find_capability(required, after)` over a fixed 16-entry bank-7 array. Copy descriptor metadata needed for registry integrity, but retain driver-owned ops/state pointers. Reject null/invalid descriptors, duplicate instance names, invalid handle access, capability mismatches, and overflow without overwriting existing entries.
- Add an internal registration checkpoint/rollback operation used around each driver initialization. If init fails after registering entries, remove only entries created by that driver attempt; earlier devices remain intact. This is also the transaction boundary M4 will reuse.
- Define a versioned `zdriver_api` containing only `device_register`, `irq_claim`, and `irq_release` for M3. A `zdriver` descriptor contains name, ABI version, and init entry. Implement an explicit null-terminated `boot_drivers[]` table and `driver_init_static()`; do not use linker discovery.
- Implement the SIO0/B driver under `drivers/sio/`. It registers exactly one instance named `sio0.b`, class `ZDEV_SERIAL`, with character input/output and console input/output capabilities. Provide bounded polling operations for putc, write, poll, and getc. Do not make panic or early boot depend on this driver.
- Add the console service with separate input/output handles. Default binding finds capabilities rather than comparing names. Implement `console_putc`, `console_write`, `console_poll`, and `console_getc`; return explicit errors if unbound or if an operation is unsupported.
- Keep early boot/banner diagnostics on `early_console_*`. After registry initialization, static driver init, and default binding, print a distinct `console: sio0.b OK` line through the normal console service. A build option that disables static driver init or console binding must still print a precise fallback diagnostic through the early console.
- Add a test-only static IRQ probe driver that claims `IRQ_CTC0`, handles it in bank 7 through the M2 executive, and releases/quiesces it after proof. The normal SIO driver may remain polling-only.
- Add host tests for registry initialization, handle iteration, capability matching, duplicates, exhaustion, invalid handles, partial-init rollback, driver ABI rejection, missing capabilities, and unbound console behavior. Extend the target self-test to validate normal console TX/RX and the static IRQ claim on physical hardware.
- Extend map validation to prove registry, console, driver descriptors, ops, handlers, and private state live in bank 7 and that no driver implementation entered common memory.
- Document the device/driver model and add a dated M3 validation record with host results and physical serial/IRQ evidence.

## Files

Likely files to create or modify:

- `include/zephyros/device.h`
- `include/zephyros/driver.h`
- `kernel/device/registry.c`
- `kernel/device/driver.c`
- `kernel/device/console.c`
- `drivers/sio/sio.c`
- `drivers/sio/sio_io.asm`
- `drivers/sio/driver.c`
- `kernel/main.c`
- `Makefile`
- `tools/mapcheck.py`
- `tests/`
- `docs/architecture.md`
- `docs/validation/`

## Constraints

- No heap, dynamic modules, unload, hot-plug, filesystem, process API, or user-visible device syscall.
- The registry owns handles/metadata; drivers own private state. Do not move device-private state into common memory.
- Capability lookup, not driver-name matching, binds services.
- Early console/panic remains direct, common-resident, and usable when registry/driver/service initialization fails.
- Preserve M2 interrupt ownership: drivers do not modify `I`, IM2 vectors, global mode, stacks, or execute `RETI`.

## Validation

```sh
make clean
make
make test
make check
make m3-selftest
make smoke-hardware-m3 SERIAL_PORT=/dev/ttyUSB0
```

## Acceptance criteria

- Every criterion in `docs/architecture.md` section 21 passes.
- `sio0.b` is registered and selected solely by capabilities; normal console I/O works on hardware.
- Registry error/rollback cases are deterministic and covered without heap allocation.
- A static bank-7 driver handler is invoked through the M2 IRQ executive.
- Disabling the registry or binding does not disable early boot/panic diagnostics.
- All M0–M2 validations continue to pass.
