# Package 95c02: gfx board fixes - progress

Status: complete (validation block green).

## Outline
- `gfx_shapes.c` `gfx_ellipse_run`: the outline emit is now the fill
  boundary - per scanline, the dots outside either neighbour line's
  span plus the span's own ends, top/bottom rows one span, touching
  pieces merged; at most two spans per scanline, so XOR restores.
  The walk is untouched (its generated code is byte-identical to
  package 93's).
- `test_gfx.py`: `outline_ellipse_pixels` derives from
  `fill_ellipse_pixels` by the 4-neighbour rule (degenerate point and
  lines handled like the library's paths); new property test at
  circles/flat/tall radii, radius 1 and the degenerates.

## Walk finding
- The compiled walk diverges from the source mirror in region 2 for
  the r=24 circle and the 14x20 ellipse (pre-existing since package
  93).  gfxtest shapes draws a filled twin of each outline; the
  replays derive the outline's expected pixels as the twin's boundary
  (decoded from the binary's own spans), translated.

## Display on
- shapes: enable after the G6 mode; atlas: enable the G7 stage and
  move the YJK checks after key 2; palette: enable both held screens.
  Replays assert R#1 0x40 and the mode at every key stop.

## Pages
- Flip: 4 Hz page alternation for 3 s (12 show_page writes), then the
  tear sweep h=1..64 with labels and an early key (replay injects it
  during h=64 at 750 copies).  Model prediction: first split at h=4.
  Replay: flip writes inside the retrace, 750-copy blocks and source
  alternation, retrace starts for h<=8 (the engine keeps up).

## Figures
- Outline r=50: 2,039,101 -> 2,555,000 T - emit adds no cost (same
  span count per scanline); the shift is the documented build-layout
  sensitivity (line 2,793 -> 4,692, filled 1,401,366 -> 1,632,553).
  Pins re-anchored at measured +10%: line 5,200, filled 1,795,900,
  outline 2,810,500, row-new 395,200.
- All 25 tests.test_gfx tests pass; the validation block ran green.
