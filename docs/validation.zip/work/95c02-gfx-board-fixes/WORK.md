> Worker package. After 95c01, before the libgfx optimisation and 96. A
> correction, found on the board: gapped outline ellipses (the test's
> reference copies the defect), `gfxtest` screens left with the display
> off, and a `pages` mode the owner can't judge by eye. libgfx's
> `gfx_shapes.c`, `gfxtest`, `tests/test_gfx.py`. No OS change.

# Task

Three defects from the owner's board run of `gfxtest shapes`, `atlas`
and `pages`. The simulator reproduces the first two. Fix them, and make
the tests catch them.

## Current state

1. **Outline ellipses have gaps.**
   - `gfx_ellipse_run` (`gfx_shapes.c`) emits, per scanline, only the
     leftmost and rightmost dot (`first[y]`, `last[y]`) as 1-dot
     spans;
   - where the outline runs flatter than 45 degrees (the top and bottom
     of a wide ellipse, the lower arc of the r=24 circle), it skips
     dots, and the outline shows as isolated dots;
   - `tests/test_gfx.py`'s `outline_ellipse_pixels` mirrors the same
     emit ("the C emit"), so the comparison passes;
   - package 93 required "spans covering every outline pixel".
2. **Screens shown black.** `gfx_set_mode` leaves the display off by
   design, and `gfx_display_enable` is the only call that turns it on.
   - **`shapes`:** enables the display once, after the first (G7) mode.
     The G6 screen at key 2 is black on the board.
   - **`atlas`:** enables it after G6 only. It also switches to YJK
     (the refusal checks) before key 2, so the G7 screen is never seen.
   - The replays check VRAM, never R#1, so they pass.
3. **`pages` can't be judged by eye.** Each step is one instantaneous
   state between keys. Nothing alternates, and a tear lasts one frame,
   so the owner can't see a tear point. The package-94 checklist
   expected an alternating flip and a visible tear point.

Read: `work/00-WORKER.md`; packages 93-95's records and 95c01's;
`gfx_shapes.c`; `tests/gfx/gfxtest.c` (`shapes`, `atlas`, `pages`);
`tests/test_gfx.py` (`_SpanSet`, the ellipse references, `TestGfxShapes`,
`TestGfxAtlas`, `TestGfxPages`).

## Requirements

1. **Gapless outline** (Must). The outline's pixel set is the filled
   ellipse's boundary: every pixel of the fill set (the same spans
   `gfx_fill_ellipse` draws) with at least one of its four neighbours
   outside the fill set.
   - **Emit per scanline y:**
     - the left piece runs from `first[y]` to the further of
       `first[y]` and `max(first[y-1], first[y+1]) - 1` (a dot is on the boundary when it lies outside either neighbour line);
     - the right piece mirrors it;
     - the top and bottom scanlines (no line beyond) are one span;
     - pieces that touch or overlap merge into one span.

     At most two spans per scanline, each dot drawn once, so the XOR
     redraw still restores.
   - **The same fill set:** a filled and an outline ellipse with equal
     parameters agree. The outline is a subset of the fill, and the
     fill minus the outline is the fill of the interior.
   - **Cost:** keep the walk; only the emit changes. Record the outline
     r=50 figure (95c01's harness) before and after.
2. **An independent reference** (Must). `outline_ellipse_pixels` derives
   the outline from `fill_ellipse_pixels` by the 4-neighbour rule. It
   never mirrors the C emit. Add a property test, at several radii,
   `rx != ry`, flat and tall, radii 0 and 1:
   - every outline pixel is 8-connected to two others (one ring, no
     gaps), except the degenerate point and line;
   - the outline is a subset of the fill;
   - the XOR pair restores.
3. **The display on at every held screen** (Must):
   - `shapes`: `gfx_display_enable(1)` after the G6 mode;
   - `atlas`: enable after the G7 mode, and move the YJK checks after
     key 2, so key 2 holds the G7 screen;
   - check every other gfxtest mode that holds a screen at a key (the
     same rule);
   - each replay asserts R#1's display bit (0x40) on, and the expected
     mode in R#0/R#1, at every key stop.
4. **A board-visible `pages`** (Must). Keep the replay's held steps
   (async order, page 1 shown, frame count, partial present). Then:
   - **Flip:** alternate pages 0 and 1, with different full-screen
     colours, every 15 frames (4 Hz) for 3 s, paced by
     `gfx_wait_vblank`;
   - **Tear sweep:** for h = 1, 2, 4, 8, 16, 32 and 64 rows, for 2 s
     each:
     - every frame, `gfx_wait_vblank`, then copy an h-row band onto
       the shown page at y = 0, alternating between two source bands
       of different colours on page 1;
     - a 4×6 label shows h. A copy that ends inside the retrace
       flickers whole; a longer one shows a split line across the band;
   - a key ends the sweep early, and the console returns.

   The replay checks the flip count, that every copy starts inside a
   retrace window (the status log), and, with 95c01's duration model,
   at which h a copy outlasts the retrace. Record that h as the model's
   prediction.
5. **Docs** (Must). `docs/sdk.md`: one line, the outline ellipse is the
   fill's boundary.

## Tests

- `TestGfxShapes`: the G7 and G6 outlines equal the new reference; the
  property test; R#1 at both key stops.
- `TestGfxAtlas`: the G7 key stop shows mode G7 with the display on, and
  the YJK refusals still pass after it.
- `TestGfxPages`: as requirement 4.
- Every other gfx replay unchanged.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | stop and report |
| outline circle r=50 (T-states) | 95c01's figure | report; ≤ +10% | report with a profile |

## Owner checklist

- On the board:
  - **`gfxtest shapes`:**
    - G7: the ellipses and the circle are closed, unbroken curves;
    - G6 at key 2: the small shapes are visible.
  - **`gfxtest atlas`:** G6 text at key 1, G7 text at key 2.
  - **`gfxtest pages`:**
    - the flip alternates cleanly;
    - in the tear sweep, note the first h whose band shows a split
      line. That is the board's partial-present limit, to compare with
      the model's prediction.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_sdk_package
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-gfx-board-fixes.md`.
