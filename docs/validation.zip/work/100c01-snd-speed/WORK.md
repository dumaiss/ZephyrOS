> Worker package. After 100c02, before 101. A correction: 98's tick path
> misses its budgets by 6-40x, and 99's file adapters re-seek on every
> call. The targets stand; they are what 102's ZTR engine and the tracker
> are built on. Same API, same traces. No OS change.

# Task

Bring the voice engine and the output flush (`snd_voice.asm`,
`snd_out.asm`, `snd_tick.asm`) to 98's budgets, and make sequential
reads through the handle and stdio adapters cheap. Profile first and
record before and after; never contort a test.

## Current state (98's and 99's records)

| figure | measured | target |
|---|---|---|
| `snd_tick`, 12 voices changing attenuation | ~25,000 steady (engine ~14,600, flush ~9,800) | <= 4,000 |
| one voice, one changed byte | ~2,600 (engine ~1,400, flush ~1,200) | <= 60 per byte + the voice step |
| full refresh, 4 chips | 24,971 | <= 3,500 |
| idle tick | 161 | <= 600 (met) |
| `read_at`, stdio | 156,048 | report |
| `read_at`, handle | 38,942 | report |

- **The flush:** for each queued slot, `_slot_flush` recomputes the
  chip and slot offsets (`chip*6 + slot*2` and so on), moves values
  through memory temporaries (`_snd_tmp*`), and is a call per slot with
  `push`/`pop` around it. About 800 T-states a slot.
- **The engine:** about 1,200 T-states a voice step (slot load, opcode
  dispatch, level table, park).
- **The adapters:** the stdio adapter `fseek`s on every call, which
  discards the stream's 512-byte buffer even when the read is
  sequential. The handle adapter seeks every time too. ZVG and ZTR
  prefetch read sequentially.

Read: `work/00-WORKER.md`; 98's, 99's and 100's records; the three
assembly files; `reader_handle.c`, `reader_stdio.c`; `tests/snd_harness.py`
(timing and profile).

## Requirements

1. **The flush** (Must):
   - **Per-voice binding:** at compile time (in C, when a program
     starts), give each voice precomputed addresses: its desired and
     shadow bytes, its port, and its latch prefixes. The flush then
     touches them with no index arithmetic;
   - **No memory temporaries in the emit loop:** the values stay in
     registers; no call/push/pop per slot (inline the tone and
     attenuation emitters);
   - **The order:** keep the emit order the oracle traces need. If the
     slot queue is only there for the order, a fixed per-chip walk of
     the changed bits may be cheaper; measure both;
   - **The refresh:** the invalidated-shadow rewrite is one straight
     loop over 44 precomputed bytes.
2. **The engine** (Must):
   - the active voice's program pointer and state in registers across
     its opcodes;
   - dispatch through a jump table indexed by the opcode;
   - the level table page-aligned or indexed with an 8-bit add;
   - parking and due-time updates with 8- or 16-bit arithmetic only.
3. **The adapters** (Must):
   - **handle:** keep the position the adapter last left the file at;
     skip `seek` when the offset equals it;
   - **stdio:** skip `fseek` when the offset is the stream's position
     (keep it in the adapter state; `ftell` only if it is cheap). A
     sequential read is then served from the stream's buffer;
   - **record:** the per-call cost for sequential 64-byte reads and for
     random ones, each adapter.
4. **Pins** (Must). 98's timing test and 99's timing report move to
   the new figures (measured +10%), with the targets in the messages.
   Every existing trace test passes unchanged (tones, adsr, noise,
   modes, catch-up, and 100's ZVG goldens).
5. **Docs** (Must): `docs/sdk.md`'s libsnd and reader costs replaced.

## Tests

- All of `tests.test_snd`, `tests.test_reader`, `tests.test_snd_oracle`
  pass unchanged, except the timing pins.
- **A new trace test:** 12 voices with staggered envelopes for 200
  ticks. The per-tick writes equal a Python reference (the same compile
  rules), in DIRECT and BATCH.
- **The reader:** a sequential walk over a card file through stdio
  makes one FS2 read per 512 bytes (the stream's buffer), not one per
  call.

## Budgets (CPU T-states, interrupts out)

| figure | 98/99 | target | on overrun |
|---|---|---|---|
| `snd_tick`, 12 voices changing attenuation | ~25,000 | <= 4,000 | report with a profile |
| one voice step + one changed byte (DIRECT) | ~2,600 | <= 400 | report with a profile |
| full refresh, 4 chips (DIRECT) | 24,971 | <= 3,500 | report with a profile |
| idle tick | 161 | <= 600 | stop and report |
| `read_at` stdio, sequential 64 bytes | (156,048 random) | report; one FS2 read per 512 bytes | report |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board: `sndtest tones`, `adsr` and `noise` sound as before;
  `vgmplay` is clean.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/VGMPlayer test
python3 -m unittest tests.test_snd tests.test_reader tests.test_snd_oracle tests.test_sdk_package
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-speed.md`.
