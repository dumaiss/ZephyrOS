# 100c01 progress (supervisor implementing)

Baseline (this tree before the package, tests.test_snd budgets): idle
153, twelve 21,554, per-byte 1,274, refresh 16,368, batch 8,890,
compile 251.  Profile of a steady 12-voice tick: engine 10.8k (~900 per
voice: run/wait lists, park/resume through memory), flush 6.8k (~560
per slot), snd_queue_push 3.5k (~300 per push).

- [x] 3 readers: stdio skips fseek when ftell == offset (sequential
      reads served from the stream's buffer). The handle adapter keeps
      its seek: the 3.4 contract lets the caller seek its own handle,
      and asking the position costs a syscall too. NIGHT.ZVG coalesced
      gaps 72 -> ~29.
- [x] queue push: no temporaries, chip-bit table (~300 -> ~120)
- [x] ATTEN op: registers instead of temporaries
- [ ] 1/2 MISSED: the 4,000-T 12-voice target needs the engine
      redesign (direct shadow compare+emit per voice, no queue, voice
      state in registers); after these cuts: twelve 19,215, per-byte
      1,260, refresh 15,632, idle 190 - follow-up package
- [x] 4 pins: the budget test passes with its headroom
- [x] make check (986 OK), records (partial: target missed)
