# M8 hardware and reference-source contract

This note fixes the external reference point for work packages 14-20. The
adjacent Zephyr-80 repository was inspected at commit
`2c6b965009256b71ebe3ae18977f80e8c1fcad24`. It is a read-only behavioral and
hardware reference: ZephyrOS must copy/adapt what it needs into this repository
and must never acquire a build-time dependency on `../Zephyr-80`.

## IOC: deployed transport, not a redesign

The authoritative transport description is:

- `../Zephyr-80/Code/MCU/IOController/docs/two-lane-transport.md`
- `../Zephyr-80/Code/MCU/IOController/include/ioc_frame.h`
- `../Zephyr-80/Code/MCU/IOController/include/bulk_channel.h`
- `../Zephyr-80/Code/HOST/CPM2.2/src/layout/{platform,memory}.inc`
- `../Zephyr-80/Code/HOST/CPM2.2/src/core/iocall.asm`
- `../Zephyr-80/Code/HOST/CPM2.2/src/drivers/transport/ioc_command.asm`
- `../Zephyr-80/Code/HOST/CPM2.2/src/drivers/console/hid_input.asm`

The MCU firmware, its headers, build configuration, and generated outputs are
strictly out of scope and must not be modified. The status paragraph at the
top of `two-lane-transport.md` is historical: it names firmware level `17h`
(23) and host transport level `07h`. At the pinned commit, the authoritative
source instead advertises `IOC_FW_LEVEL=74` (`4Ah`) in `ioc_frame.h` and
`ZBIOS_XPORT_LEVEL=08h` in `memory.inc`. Later source and changelog comments
supersede that old status paragraph. The ZephyrOS driver must record the level
returned by PING and adapt to the pinned, currently deployed behavior described
below; it must not request a firmware change to recover the old pairing.

SIO1/B is the command lane at data/control ports `32h/33h`; SIO1/A is the bulk
lane at `30h/31h`. Both use:

```text
A5 5A LEN_LO LEN_HI TYPE SEQ STATUS DATA... CRC_HI CRC_LO
```

`LEN` includes TYPE, SEQ, STATUS, and DATA. Command DATA is at most 26 bytes;
bulk DATA is 1-512 bytes. Command CRC is CRC-16-CCITT (`1021h`, initial zero,
MSB first, no final XOR) over `LEN_LO` through final DATA. Sequence is owned by
the transport. The two lanes share the MCU SPI2 engine and are never active
concurrently.

These details are load-bearing and must be ported, not simplified:

- Persistent External Sync is established once per lane. Channel reset,
  receiver disable, and Enter Hunt destroy alignment. Enter Hunt is used only
  until a verified packet establishes a lane, except during explicit
  `CMD_LINK_SYNC` recovery. Link recovery re-arms both lanes together.
- Auto Enables remain off. Before trusting DCD/CTS, issue WR0 Reset
  External/Status because RR0 modem bits latch on change.
- Command TX preloads `A5` before asserting RTS. RTS is a held
  “unacknowledged request” level, not an edge. Release uses WR5 `00h` (TX
  disabled), because clearing RTS while External-Sync TX remains enabled can
  leave RTS asserted. Send two `FFh` trailer bytes before release.
- Command RX drains only the three-byte FIFO, arms Hunt only when the local
  sync flag is clear, scans a bounded window for the full marker, validates
  length/type/sequence/status/CRC, and leaves RX enabled. Mask interrupts for
  the streaming send/body portions, but not for long MCU/card waits.
- Bulk read drains at most the FIFO depth, asserts RTS, waits for DCD admission,
  scans `A5 5A`, captures the five-byte header at wire speed, then drains DATA
  with the proven INI-shaped loop. The trailing pipeline byte means byte zero
  must never be assumed to be DATA.
- Bulk write preloads disposable `00h` before RTS, waits for CTS admission,
  sends `A5 5A`, header and DATA with the proven OUTI-shaped loop, and must not
  disable TX until the last payload/trailer has left the transmitter.
- The MCU clock does not pause during bulk. Mask interrupts across the bounded
  byte stream and restore the caller's exact IFF on every exit; re-enable them
  before a potentially long commit/DONE wait.
- The deployed firmware has `IOC_BULK_CRC_BYPASS=1`: it sends a zero CRC
  trailer on MCU-to-Z80 bulk and ignores the Z80-to-MCU trailer. The proven Z80
  write path nevertheless uses the SIO TX CRC generator (AAh WR6/WR7 fill,
  generator armed before the lead-in, EOM reset only after the last payload,
  underrun wait, then the measured 128-iteration completion guard). ZephyrOS
  must preserve that wire/timing behavior while bypassing read-side comparison,
  and must still validate marker/header/admission metadata. Do not silently
  enable read verification on one side, and do not modify firmware to change it.
- Normal firmware does not serve the diagnostic-only `CMD_BULK_TEST`,
  `CMD_SD_READ_BULK`, or `CMD_SD_WRITE_BULK` commands. Hardware acceptance must
  use the production `/SHARED` service (`20h`-`28h`) for safe variable-length
  read/write coverage; never make diagnostic firmware or raw-LBA access a
  prerequisite.
- A READY reply binds transfer id, direction, DATA length, response TYPE and
  sequence to the following bulk packet. A write is not successful until a
  matching `CMD_XFER_STATUS` DONE record reports the same id and success.

The IOC class alone may sample DCD/CTS or program SIO1. HID and later storage
drivers consume semantic class operations only.

## HID behavior

The MCU asserts `/CTSB` while translated keyboard bytes are queued. IOC status
maps that level to `ZIOC_STATUS_HID_PENDING`. `CMD_HID_INPUT=0Eh` and
`RSP_HID_INPUT=8Eh`; the one-byte request asks for a maximum count. The reply
DATA begins with `queued` and saturating `dropped`, followed by up to 24 terminal
bytes. Ask only for local free space because returned bytes are dequeued.
Preserve the proven 16-byte local ring and 64-poll stuck-doorbell penalty: an
asserted doorbell followed by an empty/failed fetch must not impose a full IOC
timeout on every console poll.

## V9958 behavior

The authoritative implementation and hardware notes are:

- `../Zephyr-80/Code/HOST/CPM2.2/src/drivers/console/v9958.asm`
- `../Zephyr-80/Code/HOST/CPM2.2/src/core/video_ops.inc`
- `../Zephyr-80/Code/HOST/CPM2.2/docs/archives/lunchcrema-v9958-console-bringup.md`
- `../Zephyr-80/Code/HOST/CPM2.2/src/assets/font_cp850_6x8.inc`

Ports are data `A0h`, command/status `A1h`, palette `A2h`, indirect `A3h`, and
LunchCrema configuration latch `A4h`. The latch captures D0 (interrupt route)
and D1 (`/WS_EN`) together; all writes use a software shadow and preserve D0.
Use the hardware-proven 85x26, 6x8 CP850, GRAPHIC 6 implementation. The raw
font asset is exactly 2048 bytes and has SHA-256
`6db207e0466a05af42894d378261f876da51bb391240e1beda4f1d5f12ec442f`.

Initialization order is non-negotiable: porch off while preserving D0; paced
R#25=`00h`; paced R#8=`08h` for installed 64Kx4 DRAM; stop any prior command;
program the full display/selector state; paced R#25=`04h` (`WTE=1`, `VDS=0`);
porch on; only then program the palette using real WAIT, upload normal/reverse
font atlases, clear G6, initialize the sprite cursor, present, and enable the
display. R#0=`0Ah`, R#2=`1Fh`, R#9=`88h`. Do not rely on warm-reset state or
incidental instruction timing. M8 keeps VDP interrupts disabled.

Port the terminal semantics (print runs, CR/LF/BS/TAB/FF, ANSI/VT100-light
cursor/erase/SGR/save/restore/insert/delete behavior, circular R#23 scrolling,
sprite cursor) without CP/M dispatch tables, BIOS addresses, HID calls, or the
historical VIDEO_SEND 16-byte ceiling. The V9958 module is output-only; HID is
an independent input device.

The exact M7 monitor artifact is the compatibility oracle:
`monitor.zex` is 3533 bytes with SHA-256
`67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed`.
It must not be rebuilt differently for M8 console selection.
