# 56-m13-sdk-buffered-io — progress

## Plan (from WORK.md)

0. Retire the console-integration image (files, Makefile rows, replays,
   serial_smoke mode, the four `KOS_*_SELFTEST` flags only it set).
1. 49d correction 01 exactly as written.
2. `tests/bench/iobench.c` bench rows, run on the current SDK (simulator;
   hardware from the owner).
3. Line-buffered console output in libkos (+ `console_flush`).
4. Buffered file streams in `klibc/stdio.h`; 4b. `kos/stream.h` planning.
5. Docs and comments.
6. Measure again (adds a `file.getc` row).

## State

- [ ] 0. retire console-integration
- [ ] 1. 49d correction 01
- [ ] 2. iobench + before figures
- [ ] 3. console buffering
- [ ] 4. stdio streams (+4b stream.h)
- [ ] 5. docs
- [ ] 6. after figures
- [ ] tests (host unit cases, simulator replays)
- [ ] final validation + report

## Decisions / notes

- The console output buffer lives in `console_proto.c` (the always-linked
  console client), so no archive cycle is introduced and `hello.exe`'s
  linked-module set is unchanged.
- The stream layer registers its exit flush with the console object
  through a pointer, because `exit` must flush open streams while a
  program that never calls `fopen` must link none of the stream code.

## State (updated)

- [x] 0. retire console-integration (13 files deleted, Makefile rows and
      replays updated; driver/layout, SDK and console-acceptance tests OK)
- [x] 1. 49d correction 01 (scratch rule in `tests/test_romfs_sim.py`,
      the three files moved to `systems/fs.json`, store pins updated,
      `tests/test_far_data.py` replays the fs image, addendum written)
- [x] 2. iobench (rows, fs store, Makefile, layout/SDK/store pins)
- [x] 3. console buffering (`console_proto.c`, `console_flush`,
      read/run/exit flushes, `putchar` keeps its byte)
- [x] 4. stdio streams (+4b `kos/stream.h`); host probes in
      `tests/test_stdio.py` all pass
- [x] tests: `tests/io/` programs + `tests/test_io_sim.py` replays pass
- [x] 5. docs (sdk.md 2/5/6.1/6.10/7/8/9, architecture 7.5, the
      `console_proto.c` handle comment, the `kos/stream.h` `costs:` typo,
      `SEEK_*` in `klibc/stdio.h`)
- [x] 6. after figures (both benches run; `file.getc` added; table in the
      record, transcripts beside it)
- [x] tests (host probes, `tests/io/` replays, the bench row replay)
- [x] final validation batch + validation record
      (`docs/validation/2026-10-15-m13-sdk-buffered-io.md`)

## Final validation (on the frozen tree)

- `make`: image 524 288 B sha256 `0a7dde34...`, romfs 132 548 B; mapcheck
  `OK (18 areas, 400 symbols) [production]`.
- `tests.test_sdk tests.test_source_layout tests.test_stdio`: 82 tests OK
  (1 skip); `tests.test_io_sim`: 3 OK.
- `tests.test_console_acceptance tests.test_shell_sim tests.test_hwtest_sim
  tests.test_device_release`: 23 OK (969 s).
- `make fs-selftest`: 3 fs-selftest + 26 `test_events` + 7 `test_far_data`
  + 3 `test_io_sim`, OK.
- `make subsystem-selftest`: blocked before this package's changes (the
  geometry derivation fails at HEAD; `work/53b-m12-device-events/
  correction-01`, reproduced in the pristine `/tmp/zos-head` worktree).
- `git diff --check` clean.  Nothing committed (the owner asked for the
  tree only).

## Findings that changed the code

- The SDK links no multiply helper: SDCC emits `__mulong`/`__mulint`
  calls for variable and 32-bit products, so the stream layer keeps every
  product in a shift-add helper (`stream.c`) and `fread`/`fwrite` walk
  items instead of multiplying `size * nmemb`.
- `fseek` on a read stream pushed the buffered *read* bytes back through
  `write` (the buffer's `count` is not "pending writes" unless the stream
  is dirty).  Fixed in `kos_stream_push`; the host probe case
  `seek-no-write` and the `iostream` replay both cover it.
- The host probe harness must load the linked image into both bank 0 and
  bank 7: mode 11 maps 0x0000-0x1FFF to bank 0 and the rest of the RAM
  window to bank 7, and the SDK's code + data no longer fit below 0x2000.
  `-b _DATA = 0x0400` (test_bcall's shape) overlaps the code for a probe
  this size, so the probes bind `_CODE` only and let `_DATA` follow.
- `console_flush` returns 0 or the flush's error (not the byte count);
  `putchar` returns its byte even when the flush it caused failed.
- The bench's batch size is set by the clock: a batch must span enough
  25.6 us counts to be read, so the console and ipc rows run as one batch
  and the file rows keep eight.
- The buffered console moved `tests/test_events.py`'s reading: its second
  span ran from the handler's last syscall, so `events watch`'s console
  write (one call per byte before, buffered now) left the handler's own
  formatting and copy in the figure (14,068 T per delivery, 7.0%, the 5%
  share assertion failed).  The harness now stamps the handler's entry
  and its return (the address the trampoline pushes, read off the stack)
  and pairs them by nesting depth: the delivery's own cost is 8,407 T
  (4.2%), the mechanism's round trip less the handler - the entry side
  and the argument-block snapshot inside it, as 53b's prose intended but
  its reading did not do.  The bound moved with the definition (9,250
  T); `tests/test_events.py`, the 53b record's addendum,
  `docs/devices.md` and `docs/memory.md` carry the correction.  No kernel
  code changed, and every other assertion in the module reads as before.
- `make fs-selftest`'s `iomix`/`iostream` replays and the shell replays
  are what keep the console's ordering rule honest now that the buffer
  delays the write.
