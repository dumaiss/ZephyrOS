> **DRAFT. Not dispatched.** Runs after 53b, before 54/55 (no `diag` yet).

# Task

Four things, in this order:
0. **Retire the console-integration image** (it no longer fits its cold
   half; other replays cover its devices).
1. **The 49d correction**: apply `work/49d-far-data/correction-01/WORK.md`
   as written (the `test_romfs_sim` scratch fix, and the far-data files out
   of the production store into the `fs` image).
2. **Measure the IPC cost a program feels** with a small bench program,
   on today's SDK.
3. **Buffer the SDK's I/O** so ordinary C code stops paying one IPC call
   per byte, then measure again.

Why: one IPC call costs ~15,500 T (1.55 ms); `putchar` and byte-wise
file loops pay one per byte. Buffering puts ordinary programs on the
batched path. SDK only: no kernel or driver change.

Read: `work/00-WORKER.md`, `docs/sdk.md`, architecture 4.9 and 7.5, the
SDK's `console_proto.c`, `console_io.c`, `klibc/printf.c`.

## Requirements

0. **Retire the console-integration image.** Delete it outright, do not
   make it fit: `systems/console-integration.json`, its Makefile rows and
   target (and its place in `hardware-images`), the in-nucleus
   diagnostics it alone links (`tests/target/console/integration_test.c`,
   `tests/target/ioc/`, `tests/target/hid/`, `tests/target/video/`, their
   `*_selftest.h`, the driver client if nothing else links it,
   `escc.exe` if nothing else uses it), their replays
   (`tests/test_ioc_sim.py`, `test_hid_sim.py`, `test_v9958_sim.py`, the
   integration class of `test_console_acceptance.py`), the
   `serial_smoke.py` mode and every `KOS_*_SELFTEST` flag only it set.
   Keep any host test that checks a driver artifact rather than the image.
   Search for every consumer first. Record the files removed and the
   replay that covers each (production, shell, `hwtest`, device release).
1. **49d correction 01.** Exactly as its WORK.md says, including its
   addendum to `docs/validation/2026-10-12-far-data.md`.
2. **Benchmark rows, before any SDK change.** A test program
   `tests/bench/iobench.c` (`iobench.exe`, in the `fs` image's store, and
   built for a card copy like `devtest`; 54/55 later fold its rows into
   `diag`). One line per row: min/mean/max and per-call figures:
   - `ipc.null`: 100 descriptor-less calls to the console (`console_poll`);
   - `con.putchar`: 2,000 characters through `putchar`;
   - `con.printf`: the same 2,000 characters through `printf`;
   - `con.write`: the same 2,000 characters in 256-byte `console_write`s;
   - `file.byte`: a 32 KiB card file read 1 byte per `read` (SKIP with no
     card; create the file under `/fs/BENCHTMP`, remove it after);
   - `file.block`: the same file in 512-byte `read`s.

   Run them on the current SDK, simulator and (owner) hardware, and keep
   the figures for the record.
3. **Line-buffered console output** in libkos:
   - One output buffer of 128 bytes per program. `putchar`,
     `console_puts` and `printf` append to it (printf drops its own
     32-byte sink). A `console_write` longer than the free space flushes
     the buffer, then writes directly.
   - Flush on: `\n`; buffer full; before every console read
     (`getchar`, `console_read`, `console_poll`, `console_readline`), so a
     prompt shows before input is read; before `run`; at program exit
     (`crt0` exit path and `exit`); and on `console_flush()` (new public
     call, `kos/console.h`).
   - Output order is unchanged against an unbuffered program: a child
     started by `run` never prints ahead of its parent's pending bytes.
   - An error in the flushed write is returned by the call that flushed.
     `putchar` keeps returning the byte. A program that faults loses its
     unflushed bytes; say so in `docs/sdk.md`.
4. **Buffered file streams** (ISO C names keep the ISO signatures):
   `fopen` (`"r"`, `"w"`, `"a"`; a `b` is accepted and ignored), `fclose`,
   `fread`, `fwrite`, `fgetc`/`getc`, `fputc`/`putc`, `fgets`, `fputs`,
   `fflush` (`NULL` flushes every stream and the console), `feof`,
   `ferror`, `fseek` (`SEEK_SET`/`SEEK_CUR`/`SEEK_END`), `ftell`,
   `rewind`, in `klibc/stdio.h`.
   - `fseek` flushes pending writes, discards the read buffer, calls the
     SDK `seek` and clears EOF; `ftell` accounts for buffered bytes not
     yet consumed or written. A looping music player (VGM loop offset)
     is the reference use.
   - 512-byte buffer per stream, from a static pool of 4 streams; a
     program that never calls `fopen` links none of it (one object per
     function group, so the linker leaves them out).
   - Built on `open/read/write/close/sync/seek`; `fclose` and exit flush.
   - Record the SDK library and `hello.exe` sizes before and after; a
     program without streams grows only by the console buffer and flush.
4b. **Stream planning** (`kos/stream.h`; not ISO, short names):
   - `fmeasure(FILE *f, int timer)`: opt-in; the stream then records
     min/mean/max counts per refill (`fstats(f, &st)`). Streams never
     need the timer otherwise.
   - `stream_plan(&need, &plan)`: pure arithmetic. In: consumer rate B
     (bytes/s), tick period T (counts), chunk C (512), mean and worst
     refill time (from `fstats` or a figure the caller passes, e.g. 55's
     SD benchmark), safety factor (default 2). Out: bytes per tick
     b = B·T, refill every n = floor(C / b) ticks, pre-fetch
     P = B·t_max + C (rounded up to C), start-up delay P / R, utilisation
     U = B / R with R = C / t_mean, and `feasible` = U < 50 %.
   - Host tests use these fixtures (R ≈ 27 KiB/s, t_max 150 ms, T 20 ms):
     100 KiB over 180 s → B ≈ 570 B/s, n = 45, P = 1 KiB, U ≈ 2 %;
     100 KiB over 30 s → B ≈ 3.4 KB/s, n = 7, P = 2 KiB, U ≈ 13 %.
   - `docs/sdk.md`: the model, the example, and "refill right after a
     tick" (a refill longer than T makes a tick late, never lost).
5. **Docs and comments.** `docs/sdk.md`: output buffering, `console_flush`,
   the stream calls, and one paragraph "batch your I/O" with the bench
   figures. Architecture 7.5: add the 512-byte read row (≈87,000 T,
   ≈170 T/B) and a line that per-call cost amortises per block. Fix
   `console_proto.c`'s comment: the standard handles are bound fresh for
   each process, not inherited across `SYS_EXEC`.
6. **Measure again**: the requirement-2 rows on the new SDK. Expected:
   `con.putchar` close to `con.printf`; `file.byte` through `getc` close
   to `file.block` (add a `file.getc` row for that).

## Tests

- **Host:** the flush rules as unit cases where the harness allows
  (buffer full, `\n`, read-before-flush ordering); stream mode parsing;
  pool exhaustion (`fopen` returns `NULL` on the 5th stream).
- **Simulator replay:** a small SDK test program (in the `fs` image) that
  interleaves `putchar` without newline, `console_readline`, `run` of a
  child that prints, and exit without newline; the transcript order must
  match an unbuffered run. One stream session: write, append, read back
  with `fgets` and `fread`, byte-compare; `fseek` back to an offset inside
  and outside the current buffer, `ftell` after reads and after writes,
  `rewind`, and a write after a seek lands at the right offset.
- The shell (50-52) and every store program still pass their replays
  unchanged.

## Constraints

- No kernel or driver change. libkos, klibc, crt0, the docs and the
  bench program only.
- Record: `docs/validation/<date>-m13-sdk-buffered-io.md` with the
  before/after bench table (simulator; hardware from the owner).

## Validation (targeted: no `make clean && make check`)

User-land only. Every program relinks, so the replays that read program
output are the check. Once at the end (the same while developing):

```sh
make                       # production and every program build
python3 -m unittest tests.test_sdk tests.test_source_layout tests.<new tests>
python3 -m unittest tests.test_console_acceptance tests.test_shell_sim \
    tests.test_hwtest_sim tests.test_device_release   # output order, relinked store
make fs-selftest           # streams, iobench, the far-data replay (49d)
make subsystem-selftest    # test_romfs_sim's scratch fix (49d)
git diff --check
```
