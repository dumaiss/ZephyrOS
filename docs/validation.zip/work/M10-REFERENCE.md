# M10 shared decisions and reference contract

The architectural target is **`docs/architecture.md` sections 35-37**
(rewritten 2026-10-07, typed namespace model 2026-10-09). It is the only M10 target. Where this note and the
architecture disagree, the architecture wins. A worker that finds a
conflict, or a target that does not fit its ledger, stops and reports it.

`work/00-SUPERVISOR.md` and `work/00-WORKER.md` apply. There is no backward-compatibility obligation until M12
closes. **M9 acceptance machinery is retired** (owner, 2026-10-09); M10
is covered by its own outcome images. The M9 reference is git (`0cfe6d7`).

## Decisions

Project owner:

1. **ZEX v2 replaces ZEX v1** with no compatibility path (architecture
   36.18).
2. **The host computes everything it can.** The packers validate and
   pre-encode; resident loaders only check protective bounds and copy.
3. **Reuse, reuse, reuse.** A new resident mechanism needs an explicit
   justification of why no existing one serves (table below).
4. **The OS uses at most two banks** (bank 7 the nucleus, bank 6 the
   drivers) plus common. A third bank is never the fallback: slim, or move
   code to a lower tier (36.3, 36.20).
5. **16/32 split plus a 16 KiB far aperture, on decoder revision 13**
   (programmed; 36.2, 36.17). The window is `6000h-DFFFh` over a fixed
   core at `2000h-5FFFh`. The aperture is `8000h-BFFFh` when P ≠ 0;
   programs that never map anything keep 56 KiB. Tokens are issued only for
   banks 0-5.
6. **Zero only what the language or ABI requires** (36.19): BSS and the
   startup block. xmem objects start undefined.

Supervisor (phase 0, packages 35-36):

7. **IPC:** 32-byte frame, nesting limit 4, re-entrant calls refused
   (`ZOS_EBUSY`) unless declared, direct descriptor copies (36.7-36.9).
8. **Fixed rule:** code that runs, or data that is touched, while the
   window shows bank 6 is fixed. Cold code reaches drivers through fixed
   upcall shims (36.5).
9. **Drivers are ZMOD images with driver metadata, and permanent:** no
   unload, revocation or restart (36.7, 36.11).

Project owner (2026-10-08/09, typed namespace model; architecture 36.4-36.14):

11. **The VFS is a nucleus root router.** It owns `/` and routes
    (case-insensitively) to exactly three static nucleus namespace
    providers: `/fs` (forwards to the build's filesystem driver, IOC-FAT),
    `/system` (ROMFS, usable before any driver) and `/dev` (a host-built
    publication table). There is no mount table, no provider registration
    and no root merge. A provider owns everything below its root.
12. **Drivers.** A driver is any resident implementation of one or more
    protocol types: hardware, filesystem or composed (for example a
    CONSOLE built from VIDEO + INPUT). Implementations are **selected per
    build**; there is no runtime probing and no fallback. A required driver
    that fails to initialize is a boot failure. (A console driver with its
    own built-in fallback may come later, as an ordinary driver; not in
    M10.) `mkdir`/`rmdir`/`unlink`/`rename` are `fs.h` operations that the
    filesystem driver performs over IPC. `/dev` names describe roles:
    `/dev/console`, `/dev/input/keyboard`, `/dev/video`, `/dev/serial/0`,
    `/dev/ioc`; later `/dev/sound` and `/dev/timer` (the CTC).
13. **Host assembly.** Drivers are linked at their final bank-6 addresses.
    The host resolves endpoint numbers, inter-driver dependencies (as
    typed endpoint/object references) and the `/dev` publication table.
    The loader only copies and installs. Drivers never look each other up
    at run time.
14. **Validation lives in the nucleus only.** Drivers do not re-validate.
15. **Objects.**
    - `bind(path, u16 flags)` returns a handle plus an 8-bit protocol type;
      then `call(handle, op, 32-byte frame, at most 2 descriptors)`; then
      `unbind`.
    - No expected-type argument, no `handle_info`, no lookup, no
      `DIRECTORY` protocol.
    - Namespace enumeration is `ns_enum(path, cookie, out)`, routed to the
      provider. `chdir` is validated by the provider and stores a global
      path.
    - `open`/`close` exist only in the SDK's `fs.h` (bind plus a FILE check,
      and unbind).
    - Protocols are coarse-grained.
    - One global, owner-tagged handle table: the extended M9 descriptor
      pool.
    - Exit unbinds every handle; there is no exit broadcast.
16. **Guiding rule (36.1):** if the host can precompute it, precompute it.
    Build no isolation, discovery or concurrency machinery. Also:
    - driver-to-driver calls are near-direct, with the frame passed by
      reference;
    - `XMEM_MAP` returns the token and the address;
    - one far-code segment per auxiliary bank.

## Rejected options: not guidance

Packages 33-36 evaluated alternatives that are **not** part of the target.
Their reports and work orders are history. Do not take design from them
where they differ from the architecture:

- the 8 KiB slot overlay (transport B) and its decoder;
- the `8000h` window split and the window-only `6000h` decoder (the
  package 34-36 evaluation decoders);
- `SYS_FAR_CALL` with an auxiliary page zero and low window, the far-entry
  table, and ABS16/high-byte segment relocation (package 33);
- the bank-7 driver arena and its 32-granule floor;
- the VFS as a bank-6 service, or a Unix-style universal file/directory
  model (`DIRECTORY` handles, nucleus `open`/`close`);
- runtime mount tables, provider registration and IOC-FAT mounted at `/`
  (it lives behind `/fs`);
- runtime device registration, probing, class lookup and console
  fallback (consoles are selected per build);
- runtime relocation, dependency checking or endpoint registration for
  drivers;
- validation repeated inside drivers;
- the provider ops-table interface, the device class/capability model,
  driver ops tables and runtime ABI/version fields;
- any pre-zeroing beyond BSS and the startup block (zeroed xmem objects,
  whole-bank clears at exec, a zeroing flag);
- a third OS bank.

## Budget

The ledgers and targets are architecture 36.20. Starting projections
(package 36, `docs/validation/2026-10-07-m10-two-bank-feasibility.md`):

```text
nucleus fixed:  about 8.6 KiB measured + upcall shims + M10 fixed rows,
                once process, process_exec and the loader become cold
nucleus cold:   about 3.5 KiB measured + M10 cold rows
driver hot:     13,216 / 32,768 measured after package 41; + IOC-FAT (about
                6.6 KB plus its wrapper) is the remaining planned tenant
driver boot:     2,170 / 24,576 measured after package 41 (font included)
common:         2,488 used at M9 close; ceiling 3,072
```

Every package reports the five ledger lines, the gate-stack worst case
and the service-stack high-water mark. It also reports the bytes it adds,
attributed per object.

## Existing mechanisms M10 must reuse

| need | reuse |
|---|---|
| IPC, descriptors, copy paths | `kernel/ipc/` (packages 39-41) |
| window and transition code | the revision-13 transitions; `kernel/memory/upcall.asm` |
| bank copies outside the window | `zos_bank_copy` (`kernel/memory/user_copy.asm`) |
| service images and loader | the ZMOD format plus service metadata; `kernel/service/` |
| ROMFS | the one reader and the built-in provider |
| process creation, rollback, nested exec | `process_prepare()`/`process_launch()`, the package-28 continuation stack |
| page zero, syscall vector | the existing page-zero construction |
| bank allocation | the process bank map, extended to auxiliary slots |
| IRQ delivery | the IRQ executive and its own saved-latch slot |

Never build a second mechanism beside one of these.

## Process identity versus execution latch

The syscall gate saves the caller's whole latch: bank Q, mode and page P.
Every buffer that a syscall or a service descriptor names is resolved
against that saved latch. An address in `8000h-BFFFh` with P ≠ 0 names the
far bank, not the primary bank (36.8, 36.17).
