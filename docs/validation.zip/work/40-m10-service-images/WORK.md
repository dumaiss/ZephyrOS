# Task

M10 stage 4, part 1 (architecture 36.24, step 4). Add:

- **resident service images**: ZMOD with service metadata (36.11);
- the **service loader** that places them in bank 6's hot and boot/bulk
  tiers (36.6);
- the **boot manifest** read by the bootstrap ROMFS reader (36.12);
- the **service bootstrap interface**.

Bank 6 leaves the application pool. The `ipc-selftest` services become
real service images loaded from a manifest.

## Context

Read:

- `docs/architecture.md` 36.3, 36.6, 36.11 and 36.12;
- `docs/module-format.md`, `tools/zmodpack.py`, `kernel/module/`;
- `kernel/romfs` (the bootstrap reader);
- the process bank allocator;
- package 39's substrate and `ipc-selftest`, plus its record
  (`docs/validation/2026-10-08-m10-ipc-substrate.md`, correction 01
  included).

From package 39:
- the substrate is `kernel/ipc/`;
- the service-facing table is `struct ipc_service_api`
  (`include/zephyros/ipc.h`), which becomes the bootstrap interface below;
- the six synthetic services are containers placed by a test cold loader
  (`tests/target/ipc/ipc_loader.c`). They compile with
  `--dataseg SERVICE_IO`, and the loader refuses `SERVICE_IO` data outside
  bank 6 `8000h-BFFFh` (architecture 36.8, path B).

## Requirements

1. **Format.** Extend ZMOD with a service section. A service image
   declares:
   - its hot segment (relocated into `6000h-DFFFh` of bank 6);
   - its boot segment (relocated into `0000h-5FFFh`);
      - its `SERVICE_IO` data (placed in `8000h-BFFFh`; the copy paths of
     36.8 depend on it);
   - its bulk data (in `0000h-5FFFh`, reached only by nucleus copies);
   - its exported endpoints (class, instance, version, operation-dispatch
     entry, re-entrant flag);
   - the endpoints it depends on.

   `tools/zmodpack.py` validates the image and pre-computes the layout on
   the host. Document the format in `docs/module-format.md`.
2. **Loader.** A cold nucleus loader that:
   - allocates space in both tiers;
   - relocates with the existing ZMOD relocator (no second relocator);
   - runs each boot segment once through the mode-10 gate with Q = 6;
   - registers the endpoints.

   The nucleus keeps an allocation map of both tiers and a `service hot:`
   and `service boot/bulk:` ledger. Code in the boot tier is never
   executed after boot.
3. **Boot manifest.** A ROMFS file listing service images in load order,
   read with flat constant names by the bootstrap reader.
   - Make the reader a fixed-core nucleus primitive, so the ROMFS provider
     can call it later (36.12).
   - Dependency order follows the manifest. A missing dependency is a boot
     error, and is reported on the early console.
4. **Service bootstrap interface.** Formalize package 39's
   `struct ipc_service_api` as a small, versioned set of nucleus entry
   points:
   - register, lookup, call;
   - `copy_in` and `copy_out`;
   - IRQ claim and release;
   - any other primitive a later service provably needs, named
     individually.

   Specify it in a header for service authors. It is not a kernel import
   table: list every entry and justify each one.
5. **Bank 6 leaves the application pool.** The process bank allocator
   hands out banks 0-5 only. Update `docs/memory.md`.
6. **Tests.** Convert the `ipc-selftest` synthetic services into service
   images loaded from a test manifest. The test loader
   (`ipc_loader.c`) is replaced by the real loader. The five-address copy
   matrix and the path-B interrupt test must keep passing. Add an image or test for: a missing
   dependency, an oversized hot segment, and boot-segment execution
   happening once.

## Constraints

- Production is byte-identical: the loader, manifest reader and bootstrap
  interface are built only into test images (bank 7 is full until package
  41). Bank 6 leaving the application pool is the one production change
  allowed; if it changes the bytes, record the new hash.
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation

```sh
make clean && make check
make ipc-selftest            # now manifest-loaded service images
make m9-selftest
git diff --check
```

Report the ledgers and the loader's cold-half cost. Target: under 20
minutes.

## Acceptance criteria

- Service images are packed on the host, loaded from the manifest into
  both bank-6 tiers, boot-initialized once and registered. The
  `ipc-selftest` suite passes on them.
- Bank 6 is no longer allocatable to applications.
- Production is unchanged in behaviour.
