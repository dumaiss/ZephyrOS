# Progress

## Status

DONE — accepted by supervisor on 2026-10-18 after correction 01. Package 68
is active.

## Worker handoff

- Implement only `work/67-tui-screen-engine/WORK.md`.
- Read `work/00-WORKER.md`, `work/TUI-REFERENCE.md`, the whole package, and
  every referenced source before editing.
- Treat the accepted package-66 tree as the baseline. Its modified and new
  files are expected and must be preserved.
- `docs/konaos-tui-sdk-architecture.md` is the user's untracked architecture
  input and must remain unchanged.
- Do not begin package 68.
- On completion, write the required validation record and return a structured
  `TUI_REVIEW_REQUEST` naming package 67, the report, validation status, and
  any pending evidence.

## Done

- Package 66 accepted and independently replayed on both console backends.
- Added the static 85 x 26 cell map, dirty bitmap and run buffer.
- Implemented cursor, text, control bytes, clipping, dirty/run flush and
  formatted text.
- Extended `tui_test.exe` with batch and screen modes.
- Added `tests/test_tui_sim.py`: serial byte comparison and V9958 command
  decoding on both console backends.
- Manual replays pass on both backends; batch write lengths are
  `[91, 7, 17, 15]`.

## In progress

- None.

## Correction 01

- `tui_shutdown()` flushes pending logical cells before the restoration
  sequence, best effort; restoration and uninitialization always happen.
- Added `tui_test.exe shutdown` mode: draws rows 0-2 and shuts down without an
  explicit flush.
- `tests/test_tui_sim.py` checks both backends: 126-byte dirty flush, then the
  15-byte restoration and 20-byte PASS; the serial trace has `dirty`/`two`
  before restoration.
- The SDK fixture now links `tui_flush` through shutdown; screen and
  formatter remain out.

## Validation

- `make build/user/tui_test.exe sdk`: clean.
- `python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_sdk tests.test_sdk_package tests.test_console_serial tests.test_source_layout`:
  120 tests, 119 passed, 1 pre-existing image skip.
- `git diff --check`: clean.
- Report: `docs/validation/2026-10-18-tui-screen-engine.md`.

## Decisions

- Auto-wrap is disabled at init and restored at shutdown, so a full row
  never wraps or scrolls on either console.
- `_xy` text calls keep the application cursor and use a local draw cursor.
- The formatter mirrors the SDK printf conversions and width rules and uses
  `tui_priv_put_byte`, so it needs no output buffer.
- Dirty bits are cleared only after the final `console_flush` succeeds.

## Rejected

- No windows, clear operations, key decoder, save/restore, styles or widgets.
- No per-cell or per-run console sequencing beyond one run write.

## Supervisor review

- The implementation, storage/link maps, formatter separation, batching, and
  both backend screen replays otherwise satisfy the package.
- Independent validation ran 118 tests: 117 passed and the pre-existing
  `build-helloworld` image case skipped.
- Acceptance was initially withheld until correction 01 demonstrated the
  shutdown flush contract.

## Correction 01 acceptance

- Dirty cells are flushed before shutdown restoration on serial and V9958/HID.
- Shutdown remains idempotent and releases library state.
- The worker's 120-test gate passed with one expected skip; the supervisor's
  focused 18-test replay passed.
- Package 67 is accepted and package 68 is dispatched.
