# Correction

Package 67 introduced dirty logical output, but `tui_shutdown()` writes only
the terminal-restoration sequence and then releases the library state. Any
cells changed since the last explicit `tui_flush()` are therefore discarded.
This violates `work/TUI-REFERENCE.md`, which requires shutdown to flush pending
output, and leaves the lifecycle behavior dependent on an undocumented final
flush by the application.

## Required changes

- Make `tui_shutdown()` attempt to flush the logical screen before it emits the
  normal-rendition, auto-wrap, and visible-cursor restoration sequence.
- Preserve shutdown's `void`, idempotent, and best-effort cleanup contract: a
  flush failure must not prevent the restoration attempt or leave the library
  initialized.
- Add a deterministic target mode that changes cells and calls
  `tui_shutdown()` without calling `tui_flush()` first.
- Extend `tests/test_tui_sim.py` to prove on both the serial and V9958/HID
  backends that the changed cells are emitted and visible before shutdown
  completes. The regression must fail against the current package-67 code.
- Update the package-67 validation record, write counts/sizes if they change,
  and `work/67-tui-screen-engine/progress.md`.

Do not begin package 68 and do not add any window, clear, style, keyboard,
region, or widget behavior.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_console_serial \
    tests.test_source_layout
git diff --check
```

## Acceptance criteria

- Dirty cells survive a final `tui_shutdown()` with no preceding explicit
  flush on both console backends.
- Shutdown still restores normal rendition, auto-wrap, and cursor visibility,
  is idempotent, and permits a later `tui_init()`.
- The package-67 screen, formatter, row-batching, and SDK-package tests remain
  green.

