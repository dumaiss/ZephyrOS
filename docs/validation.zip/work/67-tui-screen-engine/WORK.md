# Task

Implement the logical screen engine: one cell map plus dirty bitmap, cursor and
text operations, formatted text, and row-run flushing. This is the only
screen-output path later packages extend.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`;
- `docs/konaos-tui-sdk-architecture.md`, sections 6-9 and 12.1-12.2;
- package 66's accepted validation record and `user/sdk/tui/src/`;
- the V9958 terminal contract in `docs/devices.md`, section 6;
- `drivers/v9958/v9958.c` only for the accepted ANSI/VT100-light sequences;
- `user/sdk/src/klibc/printf.c` and `user/sdk/include/klibc/fmt.h`.

## Requirements

1. Add the private 85 x 26 cell map and dirty bitmap from the reference. There
   is no heap and no second full-screen buffer. Extend lifecycle initialization
   so the model and terminal start as the same blank, normal screen.
2. Implement:

   ```text
   tui_gotoxy tui_wherex tui_wherey
   tui_cursor_show tui_cursor_hide
   tui_putc tui_puts tui_write tui_putc_xy tui_puts_xy
   tui_printf tui_printf_xy
   ```

   Follow the reference's coordinate, clipping, control-byte, result, cursor,
   and initialization rules. This package has only the full-screen window;
   package 68 adds subwindows.
3. Implement dirty/run flush exactly once in the output backend. Coalesce
   horizontal same-attribute runs, emit no redundant cursor or SGR sequence,
   synchronize the final cursor/visibility state, and finish with one
   `console_flush`. Keep dirty state on error.
4. Keep formatting in a separate archive member so a program that never calls
   `tui_printf` pays no formatter cost. Support the same conversions and width
   rules as the SDK's small `printf`; do not add heap allocation, a fixed
   truncation limit, or a second public formatting API.
5. Extend `tests/tui/tui_test.c` with deterministic cursor, text, clipping,
   controls, nested-transaction, unchanged-redraw, and formatting rows.
   `tests/test_tui_sim.py` runs the program on both console backends and checks
   the visible outcome.
6. Count console WRITE dispatches in the simulator without a production hook.
   A form drawn through many cell calls must flush as row runs, not one call per
   cell; a second unchanged flush produces no cell output.
7. Measure and record `libtui.lib` plus the target program's image and BSS. The
   map must show one cell map and one dirty bitmap, not duplicate screens.

## Acceptance

- A whole 85-character dirty row is emitted as one text run, with one cursor
  position and no per-cell calls.
- Mixed normal/reverse cell runs are structurally supported, although package
  70 is the first public producer of reverse cells.
- Text at the right and bottom edges cannot alter another row or escape the
  logical screen.
- The serial byte trace and the V9958 logical result represent the same screen.
- `tui_begin`/`tui_end` nesting and explicit `tui_flush` follow the shared
  contract, including invalid unmatched `tui_end`.

## Constraints

- No windows, clear/line operations, key decoding, box primitives,
  save/restore, or widgets in this package.
- No console, video, HID, IOC, kernel, or ABI change.
- Do not expose the cell map or private state in `tui.h`.
- Record `docs/validation/<date>-tui-screen-engine.md` with write counts and
  size deltas.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_console_serial
git diff --check
```

