> Supervisor-implemented (owner request). Runs after 60. Drivers (IOC,
> IOC-FAT). No firmware change, no nucleus change, no new architecture.

# Task

Close the per-block host gap to CP/M on the same firmware: board 17.1 ms
per 512 B (59/60) against CP/M's 12.8. A T-state profile of cold reads
(simulator, firmware lane timing) attributes ~2.0 ms per command to the
IOC driver's C (`ioc_command_inner` ~0.9 with its reply copy and zero
fill, `ioc_build_request` ~0.3, the IPC side ~0.2, `ioc_bulk_read` and
helpers ~0.3, READY admission ~0.1), ~1.0 ms per read to IOC-FAT's C (the
read loop's 32-bit division and offset arithmetic, the transfer
validation), and ~0.3-0.4 ms to the second driver-to-driver call per
block. CRC already matches CP/M exactly (bulk lane bypassed both ends,
command request computed and reply verified, the same table-less
routine).

Read: `work/00-WORKER.md`; the 59/60 records; `drivers/ioc/*`,
`drivers/iocfat/iocfat.c`, `abi/kos/protocol.h` (KIOC ops).

## Requirements

1. **The command exchange in assembly.** One routine in `ioc_io.asm`
   builds the request packet from the caller's type, status, length and
   data pointer (marker, header, data, CRC), waits for COMMAND_READY,
   sends, receives, validates (LEN bound, CRC, sequence, type binding) and
   delivers the reply's type, status, length and data straight into the
   caller's reply frame. The phase, admission and DONE interlock stay in C
   around it. Same bytes on the wire, same error codes.
2. **No copy layers on the command path.** The IPC side passes the
   frame's payload as the request data and the staged reply frame as the
   reply (one layout), so neither is copied again.
3. **One IOC call per block.** `KIOC_OP_COMMAND_READ`: COMMAND, and when
   it admitted an MCU-to-Z80 bulk phase, the bulk receive straight into
   the caller's hot-tier buffer (the direct form's rule). Returns the bulk
   length, 0 when no bulk was admitted, or a negative error. IOC-FAT's
   READY checks run on the reply after it; a check that fails reports EIO
   as before (the bulk then already ran into its own ring).
4. **IOC-FAT's read path lean.** No 32-bit division or multiplication on
   the per-block path (shifts and 16-bit offsets within the ring), the
   transfer validation without repeated 32-bit reloads.
5. **Measure**: phase image before/after, profile buckets, board SDBENCH.
   Target: 512 B at or under CP/M's 12.8 ms on the board.
6. No behaviour change on the wire for a valid exchange; every replay and
   fault-injection test passes.

## Owner checklist

SDBENCH; `hwtest`; `fs_selftest`; `timer card`; `vgmplay night.zvg`;
keyboard during a long read.

## Validation

```sh
make && make phase-image && make fs-selftest
python3 -m unittest tests.test_ioc tests.test_iocfat tests.test_readpath tests.test_hwtest_sim tests.test_console_acceptance tests.test_shell_sim tests.test_device_release tests.test_hid
make ipc-selftest && make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-m13-transport-asm.md`.
