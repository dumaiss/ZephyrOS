# Progress

## Status

DONE — accepted by supervisor on 2026-10-18. Package 69 correction 01 is
active.

## Worker handoff

- Implement only `work/68-tui-windows-clear/WORK.md`.
- Read `work/00-WORKER.md`, `work/TUI-REFERENCE.md`, the complete package,
  packages 66-67, and their accepted validation records before editing.
- Treat the accepted package-67 tree, including correction 01, as the
  baseline and preserve all unrelated work.
- Do not begin package 69.
- Write `docs/validation/2026-10-18-tui-windows-clear.md` and return a
  structured `TUI_REVIEW_REQUEST` naming package 68, the report, validation
  status, and any pending evidence.

## Accepted baseline

- Package 67's one cell map and dirty bitmap, cursor/text/formatter behavior,
  row batching, and shutdown flush pass on serial and V9958/HID.
- Corrected artifact hashes:
  - `libtui.lib`: `c1d19a1430cb14e8d2049a489bef6f33fcc5b0fce8eb67339f68d3cebf9cda2a`
  - `tui_test.exe`: `684a7358c8e4813e8067a3626a10329a087972b89ca56a84776db5039d9a78bc`

## Scope guard

- Add only windows, clear/line operations, and in-window insert/delete.
- Preserve the common logical-map output path and package-67 outcomes.
- No styles, drawing primitives, keyboard decoder, save/restore, widgets,
  kernel, driver, firmware, protocol, or system-image changes.


## Done

- `user/sdk/tui/src/tui_window.c`: absolute windows, four-deep push/pop,
  `tui_get_window`, `tui_clear`, `tui_clreol`, `tui_clrline`, `tui_insert_line`
  and `tui_delete_line`.
- `user/sdk/tui/src/tui_screen.c` and `tui_internal.h`: one common clipping,
  coordinate-translation and changed-cell layer used by later packages.
- `tests/tui/tui_test.c`: `windows` mode with outside sentinels, edge
  clipping, nested windows, overflow/underflow, invalid windows, insert/delete
  and a separate cleared window.
- `tests/test_tui_sim.py`: identical 21-row model on both consoles.
- Report: `docs/validation/2026-10-18-tui-windows-clear.md`.

## Supervisor acceptance

- Serial and V9958/HID window models, sentinel preservation, clear/shift
  behavior, batching, archive boundaries, SDK packaging, and the wider
  regression suite passed.
- The complete reproduced union ran 169 tests: 167 passed and 2 environmental
  artifact cases skipped.
- `tui_get_window()` is retained as the minimal public read-only query needed
  by widgets to own the active window's top/bottom row. The supervisor added
  it to the architecture and shared reference so the header is no longer an
  undocumented expansion.
- `git diff --check` is clean.
