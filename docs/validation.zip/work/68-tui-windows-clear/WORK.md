# Task

Add window-relative clipping, the bounded window stack, clear operations, and
logical insert/delete line on top of the accepted cell engine.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`;
- `docs/konaos-tui-sdk-architecture.md`, sections 6, 7, 9 and WP-TUI-2;
- packages 66-67 and their accepted validation records;
- current `user/sdk/tui/src/` and `tests/tui/tui_test.c`.

## Requirements

1. Implement:

   ```text
   tui_clear tui_clreol tui_clrline
   tui_insert_line tui_delete_line
   tui_window tui_reset_window tui_push_window tui_pop_window
   ```

2. Window rectangles are absolute screen rectangles; application coordinates
   and drawing rectangles remain relative to the active window. The stack depth
   is four. Install/reset/push/pop homes the cursor as specified in the shared
   reference.
3. Route every package-67 cursor and text operation through one clipping and
   coordinate-translation layer. Do not leave a full-screen fast path with
   different edge behavior.
4. Clear and line operations mutate the logical map, mark only changed cells,
   and preserve all cells outside the active window. Insert/delete shift only
   rows and columns inside that window and blank the exposed row with the
   current attribute. Do not emit CSI IL/DL directly: the map is the source of
   truth.
5. Add target rows for adjacent windows, every boundary, stack overflow and
   underflow, nested push/pop, partial text clipping, and insert/delete in a
   narrow window. The replay asserts sentinel cells surrounding each window
   remain unchanged on both console backends.
6. Add focused host checks that every public operation uses the common clipping
   layer and no application-visible source contains ANSI sequences.

## Acceptance

- A demo divides the screen into independent regions and writes, clears,
  inserts, and deletes lines in each without changing sentinel cells around
  it.
- Invalid windows do not alter state or output.
- Dirty output remains row-batched after coordinate translation.
- The full-screen package-67 outcomes are unchanged.

## Constraints

- No styles beyond normal, box drawing, keyboard, regions, or widgets.
- No kernel, driver, firmware, protocol, or system-image change.
- Record `docs/validation/<date>-tui-windows-clear.md`.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk_package tests.test_console_acceptance tests.test_console_serial
git diff --check
```

