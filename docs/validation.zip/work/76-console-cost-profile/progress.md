# Package 76 — console cost profile — working memory

## Tree state at start

- HEAD `de3bf64` (recorded baseline).
- Dirty files are all package-74 correction-01 work (drivers/v9958/*,
  tests/device/*, tests/test_device_release.py, tests/test_tui_sim.py,
  tests/test_v9958.py, tests/tui/tui_test.c, user/sdk/tui/src/tui_flush.c).
  Preserved. This package adds only tests/ + the record.

## Verified facts

- `make fs-selftest` restores the test image after `make clean` (done;
  test_io_sim 3 OK baseline).
- Driver symbol offsets live in `build/modules/<name>.report.json`
  (`symbols`, `symbol_segments`, segment `base`/`payload_offset`); the
  plan (`build/modules/drivers.plan.json`) has per-driver `hot_base`.
- C-part static function addresses come from `build/modules/<name>.lst`
  (SDCC listing, module-relative) — verified shift rule: report offset
  minus listing offset is constant per source file (v9958.c shift 0,
  v9958_proto.c shift 4433).
- Hand-written v9958_io.asm has no build listing; the profile script
  regenerates one with `sdasz80 -l` (same flags as the Makefile:
  -Iabi -Iplatform/zephyr80/public -Iplatform/zephyr80/private
  -Itests/target/include) and applies shift = report[v9958_io_wait_command]
  - listing[v9958_io_wait_command] (= 3665).
- `_v9958_out_flush` contains an inline CE-poll (`v9958_span_wait`,
  offset 0x01CC) — the CE-wait bucket must include it, so command setup
  = out_flush range minus the span_wait loop.
- `_v9958_io_stream_indirect` is shared by out_flush (command setup) and
  v9958_cursor_write_sat (SAT); the script attributes it by the last
  CALL site (one-entry call tracking).
- Kernel staging: `_api_copy_in` 0x3B5C..0x3B7E and
  `_ipc_nucleus_copy_in` 0x38C0..0x38DA (konaos.map).
- Console module hot = [54954, 55649): console_forward 54954, dispatch
  55303 (hot_base 54876 + report offsets; forward at listing 0x4E).
- v9958 module hot = [35184, 35184+6442).
- Sim: `z.tstates` is the instruction-level T-state counter; `z.step()`
  advances it by the instruction cost (including interrupts, block
  instructions, EI delay).  Profiler charges per-step deltas to the PC
  (and latch) at step start.
- Sim V9958Peer: command_busy = 400 instruction counts (`now`), so
  simulated CE waits are CPU-side only (WORK.md "Simulator" section).
- Benches measured on the sim: row spans detected by
  entry-to-key-symbol after the previous stop and stopped at the next
  CALL instruction to `_timer_now`; the key symbols: putchar `_putchar`,
  printf `_printf`, write/mixed/space `_console_write`, held
  `_console_write` (bind stays outside the batch).  Between stop and the
  true start there is exactly one `_timer_now` CALL (the row's
  batch_begin reading), so "first key entry after the next timer CALL"
  skips the report's printf.
- test_io_sim row regex widened per WORK.md line "Invariants".

## Bench row design

- con.mixed: 2,000 chars of `ls -l`-style lines (snprintf with a
  counter, CR LF, < 80 columns), 8 console_write calls of 256.
- con.space: 2,000 spaces, 8 console_write calls.
- con.held: bind /dev/video exclusive BEFORE the batch; 8 console_writes
  of the con.write text; unbind AFTER the report (release resets the
  display; row output must print unheld).
- vdp.hmmm: bind before batch; select S#2 (R#15=2); per copy: CE wait,
  R#32=17, 15 indirect OUTs (SX=('a'&31)*6, SY=0x100|(('a'>>5)*8),
  DX=DY=0, NX=6 then 12, NY=8, CLR=0, ARG=0, CMD=0xD0); 2,000 6x8 then
  1,000 12x8; unbind after report.  ops=3000, bytes=24000.
- vdp.direct.on / vdp.direct.off: bind before batch; R#14=0; R#8 = 08h
  (sprites on) or 0Ah (sprites off); 2,000 glyph-sized writes of 8
  unrolled blocks (set VRAM address, 3 OUT (A0h), +64 per line) in
  inline asm in tests/bench/iobench.c (no Makefile change — the
  production-unchanged rule); unbind after report.  ops=2000,
  bytes=48000.

## Status

- [x] Read WORK.md, 00-WORKER, iobench.c, test_io_sim.py, vblank.c,
      z80sim (CPU/CTC/V9958Peer), replay.py, v9958 write path
      (console_proto -> v9958_proto -> v9958_io.asm -> v9958.c), maps.
- [ ] Add the six bench rows to tests/bench/iobench.c (header comment
      + rows + helpers + main dispatch).
- [ ] Widen BENCH_ROWS in tests/test_io_sim.py.
- [ ] Build, run tests.test_io_sim, verify row output on the sim.
- [ ] Write tests/console_profile.py (buckets, spans, 1% check).
- [ ] Validate: make && test_io_sim + test_source_layout; profile
      script; make clean && make check once; git diff --check.
- [ ] Record docs/validation/2026-10-21-console-cost-profile.md with
      the bucket table, sim row totals, board rows PENDING (image +
      iobench.exe hashes + owner steps), ceiling estimates.

## Progress notes (continued)

- iobench.c: six rows added after con.write (mixed/space/held/hmmm/
  direct.on/direct.off).  Held and VDP rows bind /dev/video before the
  batch, release after the report; on a console without a video driver
  (the fs image is serial) they print `SKIP no video (-5)` like the
  file rows' `SKIP no card`.
- SDCC trap: a static non-const array initializer creates _GSINIT
  content; sdldz80 appends _GSINIT after _KOS_SDK_DATA (0x15D), which
  collides with the based `_CODE` at 0x15D - the first program ever to
  initialise one.  Fixed with a static const template (_CODE) copied
  once at run time.  Verified with exepack validate.
- The direct row's unrolled asm is inline `__asm__` in iobench.c: no
  Makefile change, the production-unchanged rule stays.
- test_io_sim.py: BENCH_ROWS widened to the six rows; the four video
  rows assert `SKIP no video` on the fs image (the serial console
  image has no /dev/video).  fs image rebuilt, 3 tests OK.
- console_profile.py: spans keyed on the previous row's printed line
  (printf puts characters, so timer-call arming alone mis-fires on the
  reports).  Span = first key entry after the row's first clock
  reading .. the batch-end reading's CALL.  Parsers: SDCC listings use
  `; Function name` prefixed by the source line number; sdasz80 labels
  carry the `_` prefix (stripped).
- Profile target is the production image (the console-v9958-hid path)
  with iobench.exe spliced into the store; the CTC is attached so the
  TIMER clock runs.

## Final status (2026-10-21)

- Six bench rows in iobench.c; held/vdp rows release before the row
  prints (a report while held is dropped - found by the missing held
  line in the glyph trace, fixed).
- test_io_sim: BENCH_ROWS widened to the six names; the four video rows
  assert `SKIP no video (-5)` on the fs image.  fs image rebuilt;
  `python3 -m unittest tests.test_io_sim tests.test_source_layout`:
  55 tests, 0 failures.
- console_profile.py: six spans, all rows inside 1% (worst con.held
  0.06%) after adding the calibration-measured clock reading (11,686)
  back to the bench totals.  Output table recorded in the record.
- Production image byte-identical f3e9e579... (iobench.exe is not in
  the store).  iobench.exe 17,348 bytes sha256 fd57f302...
- Record drafted at docs/validation/2026-10-21-console-cost-profile.md;
  board rows PENDING (owner) with the attribution table and ceiling
  formulas.
- `make clean && make check` running now; after it, re-run
  `make fs-selftest` so the fs image exists again, then finalize the
  record's check line.  No commit.

## Handoff state

- `make clean && make check`: 873 tests, 116 expected skips, 0
  failures; reproducible production image f3e9e579... (unchanged).
- fs image rebuilt after the clean and test_io_sim re-run (3 OK).
- Record finalized at docs/validation/2026-10-21-console-cost-profile.md
  with the simulator bucket table, the check results, the board
  PENDING attribution table and the ceiling formulas.
- Nothing committed (HEAD de3bf64); the correction-01 dirty files are
  preserved untouched by this package.
