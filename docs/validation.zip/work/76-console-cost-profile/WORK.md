> Spike package. Worker. Runs after 74 correction-01 (its hold fix changes
> the `con.held` row); independent of 75. Production code is unchanged:
> only `tests/` and the record. Baseline: HEAD at start (record the commit).

# Task

Find where a console character's cost goes. Board IOBench `con.write`
costs about 3,000 T-states per character at 10 MHz (about 3,300 chars/s).
SymbOS on a 3.58 MHz MSX2 does about 4,500 chars/s (about 800 T per char)
with a font in CPU RAM and unrolled direct VRAM writes. The answer is a
per-layer table, simulator and board, plus the two hardware ceilings that
decide the next design: V9958 command time per glyph, and the CPU's direct
VRAM write rate. No optimisation in this package.

## Current state

- `tests/bench/iobench.c` (rows `ipc.null`, `con.putchar`, `con.printf`,
  `con.write`; file rows). `con.write` sends 2,000 characters `a`..`z`
  repeating, no newline, in 256-byte `console_write` calls: eight calls,
  so per-call overhead is a small share. Auto-wrap scrolls about 23 times.
  Consecutive codes in one atlas row: the run engine's pair merge
  (`v9958_io.asm:_v9958_out_flush`) applies to nearly every pair, the best case.
- Board baseline (owner, HEAD after 74), T-states per character:
  `con.putchar` 3,479, `con.printf` 3,761 (one call), `con.write` 3,071
  (eight calls). Package 74's pair merge, which halved the glyph commands,
  took `con.write` from about 3,800 to 3,071. The record compares against
  these figures and explains why `printf` costs more than `putchar`.
- Timer: TIMER counts of 256 T-states; the bench subtracts its own reading
  cost (`counts_to_tstates`, `clock_read_cost`).
- Write path: SDK `console_write` → syscall → console driver
  (`drivers/console/console_proto.c:console_forward`) → V9958 dispatch
  (`drivers/v9958/v9958_proto.c`, 64-byte `v9958_batch` staging through
  `copy_in`) → `_v9958_char_write` wrapper (private stack, R#8 sprites off
  and on) → `v9958_char_write_worker` → `v9958_term_write` (asm fast path)
  and `v9958_term_feed` (C parser) → `_v9958_out_flush` (HMMM/HMMV command
  per glyph or pair, CE wait) → `v9958_term_sync` (SAT, final wait).
- Holding the VDP: `tests/vblank/vblank.c` acquires it exclusively. While
  held, `v9958_overtaken` drops console bytes before parsing.
- Simulator: `tests/z80sim.py:V9958Peer` holds each command busy a fixed
  400 T-states. Simulated engine waits are not hardware evidence.
- Symbols: `build/konaos.map`, the driver placement plan
  `build/modules/drivers.plan.json` and each driver's link map.
- Ports: `KOS_V9958_DATA_PORT` A0h, `CMD_PORT` A1h, `INDIRECT_PORT` A3h
  (`platform/zephyr80/public/hardware.h`).

Read: `work/00-WORKER.md`; the files above; architecture 5.5;
`docs/validation/2026-10-19-console-render-transactions.md`.

## Requirements

1. **Simulator profile** (Must): `tests/console_profile.py`, a script, not
   a unittest. It runs the production image's iobench replay
   (`tests/test_io_sim.py` setup) and charges every instruction's T-states
   to a bucket by PC and the active bank latch (address and latch both, as
   for simulator hooks). Buckets, from the maps and the plan:
   - SDK and libc in the program; syscall gate and kernel IPC;
   - console driver; V9958 dispatch and staging (`copy_in` and the nucleus
     copy it calls);
   - wrapper (private stack, R#8 writes); parser (`v9958_term_feed`, C);
     fast path (`v9958_term_write`);
   - command setup (`_v9958_out_flush` excluding the CE loop); CE wait loops
     (every loop polling S#2 CE); SAT writes; scroll; other (named).

   Output: T-states per character per bucket, for each console row, and the
   bucket sum checked against the row's total (within 1%).
2. **Bench rows** (Must), added to `iobench.c` after the existing rows,
   each with the existing row format and a line in its header comment:
   - `con.mixed`: 2,000 characters of `ls -l`-style lines (names, spaces,
     digits, CR LF, under 80 columns), the realistic case;
   - `con.space`: 2,000 spaces (HMMV fills only);
   - `con.held`: the `con.write` text while the bench holds the VDP: the
     call chain, staging and drop path with no rendering;
   - `vdp.hmmm`: holding the VDP, 2,000 back-to-back HMMM copies of 6×8
     from the atlas, then 1,000 of 12×8 (the paired width), each waiting
     for CE: hardware engine time per glyph;
   - `vdp.direct`: holding the VDP, 2,000 glyph-sized direct writes: per
     glyph, eight times "set the VRAM address, three `OUT (A0h)`", unrolled
     assembly in `tests/bench/`, display on; once with sprites on and once
     with R#8 sprites off: the CPU write ceiling under the V9958's WAIT.

   The VDP rows release the hold before the next row (the release resets
   the display). Existing rows and their output format are unchanged.
3. **Attribution** (Must): the record's table, per console row: simulator
   buckets; board total; and board minus simulator for the engine-wait
   bucket (real VDP time versus the 400-T model). `con.write` minus
   `con.held` on the board is the rendering share.
4. **Ceiling estimates** (Must), from the board rows and stated as such:
   chars/s if the call chain were the only cost; chars/s with the measured
   HMMM time per glyph; chars/s with `vdp.direct` per glyph plus the
   measured non-rendering cost. Compare each with SymbOS's 4,500 chars/s
   at 3.58 MHz in T-states per character.
5. **Production unchanged** (Must, structural): `git diff --stat` touches
   only `tests/` and the record; the production image boots and its hash is
   recorded.

## Invariants

- `tests/test_io_sim.py` passes; widen its row regex only for the new
  names, and cite this `WORK.md` line in `progress.md`.

## Budgets

None for production. `iobench.exe` must still load; record its size.

## Criteria

- **Must:** requirements 1-5; the validation below green.
- **Informational:** every number in the tables; the simulator profiler's
  own run time.

## Simulator

`V9958Peer` models neither real command durations, VRAM access slots nor
the WAIT line; the profiler's CE and direct-write figures are CPU-side
only. The board rows answer those.

## Owner checklist

- Copy the image and `iobench.exe`, run `iobench` at the shell prompt on the
  V9958/HID console, photograph or paste every row. Run it twice.

## Validation

```sh
make && python3 -m unittest tests.test_io_sim tests.test_source_layout
python3 tests/console_profile.py
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-console-cost-profile.md`: the bucket table,
the board rows (PENDING until the owner runs them, with image and
`iobench.exe` hashes), the ceilings, and what the numbers say about the
call chain, parser, command engine and direct writes. No recommendations
beyond what the numbers show.
