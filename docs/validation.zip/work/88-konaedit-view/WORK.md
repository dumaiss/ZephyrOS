> Worker package. Runs after 87 and 87c01 (`tui_put_text`, the fast
> `tui_scroll_rows`). `UserSoftware/KonaEdit` only: no SDK, libtui,
> driver or ABI change. The document contract of package 82 is unchanged.

# Task

Decouple KonaEdit's display from its document store. A RAM view of the
visible lines drives rendering; the store is touched only for the lines
that change or scroll in, read in page spans instead of byte by byte.
Targets at 10 MHz: a key in <= 0.1 s, a one-line scroll in <= 0.2 s,
anywhere in the file.

## Current state

Simulator profile, 3 KiB file, cursor near line 60, T-states:

- Typing a character costs 2.93M; cursor right 1.79M; a one-line
  scroll 6.67M (the libtui share goes away with 87); Enter 37.3M
  (every row below is redrawn byte by byte); the join 4.4M.
- `render_document_from` (`ke_ui.c`) reads every byte through
  `ke_store_byte` (`locate` + `load_page`: about 3,300 T per byte) and
  draws each cell with a one-cell `tui_fill`.
- `line_number` counts newlines from the viewport top on every key
  (`ke_store_count`, about 190k). `ensure_cursor_visible` walks
  `next_line` one line at a time.
- `render_status` formats Ln/Col with 32-bit divides (about 220k) and
  redraws the status line on every key.
- `ke_store.c` holds `low_edit` and `note_change`, which exist only to
  serve `line_number`.
- Tools: `work/88-konaedit-view/keprof.py` prints a per-function
  T-state profile of one key (header: how to run it).

Read: `work/00-WORKER.md`; `work/82-konaedit-tui-editor/WORK.md`
(product contract); `src/ke_ui.c`, `ke_store.c`, `ke_text.c`;
`docs/tui.md` (`tui_put_text`, `tui_scroll_rows`); `tests/test_ui_sim.py`.

## Requirements

1. **Store spans** (Must). In `ke_store.h`:
   `int ke_store_span(struct ke_store *store, ke_pos_t at, const uint8_t **page, uint16_t *offset, uint16_t *page_length);`
   - For `at < length`, it loads the page holding `at` and returns that
     page's bytes in the cache, at's offset in it, and the page's length.
   - The pointer is valid until the next store call.
   - Rewrite `ke_line_start`, `ke_line_end`, `ke_visual_column`,
     `ke_position_for_column` and `ke_store_count` as loops over spans:
     one `locate` per page, a tight byte loop inside the page.
   - Remove `low_edit` and `note_change`.
2. **View** (Must). A new module, `ke_view.c` and `ke_view.h`; `ke_ui.c`
   keeps the input handling.
   - **State:** `ke_pos_t row_start[KE_VIEW_ROWS + 1]` for the body rows
     (`KE_VIEW_ROWS` = screen rows - 2, at most 32). Entry i is row i's
     line start. A row past the document end holds the document length
     and is drawn blank. Entry `[rows]` is the start of the line after
     the last row.
   - **State, continued:** `uint32_t top_line` (the line number of row
     0), `uint8_t cursor_row`, and the cursor's visual column.
   - **Cursor line:** `top_line + cursor_row`. Nothing counts lines
     except `view_rebuild`.
   - **`view_rebuild(top)`:** snap `top` to its line start, set
     `top_line` with `ke_store_count(0, top, '\n')`, fill `row_start`
     with span-based `ke_line_end`, and draw all rows.
     `render_all` and every action (open, undo, redo, find, go to,
     paste, cut, replace) use it.
   - **Cursor motion:** find `cursor_row` by searching `row_start`.
     One row below the last row: `tui_scroll_rows(1, rows, TUI_SCROLL_UP)`,
     shift `row_start`, draw the new last row. One row above row 0: the
     same with `TUI_SCROLL_DOWN` and row 0. Further away (page keys, jumps
     off screen): rebuild with the cursor's line at the top for a move
     down, or at the bottom for a move up. Page Up/Down keep the exact
     line count in `top_line`, with no recount.
3. **Row drawing** (Must). `view_draw_row(r)`:
   - **Build the row:** fill an `uint8_t cells[128]` with spaces. Walk
     the row's line by spans, expanding TAB to the next multiple of 8 and
     skipping the visual columns left of `left_column`. Stop at the
     newline, the document end, or the right edge.
   - **Write the row:** one `tui_put_text` per attribute run, covering
     the full width. The runs are normal text, plus selected text
     between the selection bounds.
   - **Attributes:** take the attribute values once at start-up, with
     `tui_set_style` + `tui_get_attr` for `TUI_STYLE_NORMAL` and
     `TUI_STYLE_SELECTED`.
   - **Arithmetic:** the 32-bit work is the skip to `left_column`;
     inside the visible part, columns are `uint8_t`.
   - No `tui_fill` and no `ke_store_byte` on this path.
4. **Edits** (Must). After each successful edit:
   - **Within a line** (typed byte, TAB, Delete/Backspace of a
     non-newline): add or subtract 1 from `row_start[r+1 .. rows]`,
     then draw row r.
   - **Newline inserted at row r:** `tui_scroll_rows(r + 2, rows - r - 1, TUI_SCROLL_DOWN)`
     (screen rows; body row r is screen row r + 1), shift `row_start`
     down, set the new row's start, then draw rows r and r + 1. On the
     last row, scroll the view instead.
   - **Lines joined** (Backspace at a line start, Delete at a line
     end): `tui_scroll_rows(r + 2, rows - r - 1, TUI_SCROLL_UP)`, shift
     `row_start` up, compute the new last entry, then draw row r and the
     last row.
   - **Any other edit or result:** use `view_rebuild`.
   - **Fallback:** if `tui_scroll_rows` fails (the serial console),
     draw the affected rows instead.
   - **Selection:** while a mark is active, moving the cursor redraws
     only the rows between the old and the new cursor row.
5. **Status** (Must). Keep the last shown name, modified flag, line,
   column, mode and mark. Rebuild the status text only when one of them
   changed, and write it with one `tui_put_text`. Format numbers without
   division: subtract from a `const uint32_t` powers-of-ten table.
6. **Cursor** (Must). `place_cursor` uses `cursor_row` and the visual
   column. Moving the cursor costs no store access beyond the moved-to
   line.

## Tests

In `tests/test_ui_sim.py`:

- **Measure T-states:** `press_and_measure` also returns
  `z.tstates - start`.
- **Fixture:** a 3 KiB file of about 110 lines, each starting with a TAB
  and about 45 characters long (`keprof.py` builds one). Measure with the
  cursor on line 60, column 8.
- **Correctness:** after each measured key, the screen text equals the
  expected window of the file. Cover:
  - typing, Backspace and Delete within a line;
  - Enter in mid-line, and the join that undoes it;
  - one-line scroll down at the bottom and up at the top;
  - Page Down then Page Up (the same screen, `Ln` correct);
  - a selection over three rows (the attributes of the selected cells);
  - undo after typing;
  - Go To Line 100 (`Ln 100`).
- The existing tests keep passing. Their thresholds may tighten, never
  loosen.

## Budgets

Whole-system T-states (OS and driver included) for one key, simulator:

| figure | now | this package | on overrun |
|---|---|---|---|
| printable key, line 60 | 2.93M | <= 800,000 | report with a `keprof` profile |
| cursor right / down (no scroll) | 1.79M | <= 500,000 | report with a profile |
| one-line scroll down / up | 6.67M | <= 1,200,000 | report with a profile |
| Enter mid-line / join | 37.3M / 4.4M | <= 1,500,000 | report with a profile |
| stack headroom (`test_project`) | 2,760 B | >= 512 B | stop and report |

## Criteria

- **Must:** requirements 1-6; the tests pass; the 512-byte headroom
  test passes.
- **Should:** the budgets above. Every overrun is reported with a
  `keprof` profile that names the top functions.
- **Informational:** before and after figures for each budget row, the
  image size, and the BSS end.

## Owner checklist

The simulator runs HMMM copies instantly, so the board checks these.

- On a 3 KiB source: typing in mid-file, a held arrow key scrolling,
  Enter and Backspace at a line start, a selection, undo.

## Validation

Develop with single tests (`python3 -m unittest test_ui_sim.<Class>.<name>`
from `tests/`); run the suite once, at the end.

```sh
make -C UserSoftware/KonaEdit test
python3 work/88-konaedit-view/keprof.py   # before/after profiles for the record
git diff --check
```

Record: `docs/validation/<date>-konaedit-view.md`.
