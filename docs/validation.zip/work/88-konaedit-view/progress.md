# 88 progress

Done; record: `docs/validation/2026-10-24-konaedit-view.md`.

- **Budgets:** all met (simulator). The join is the closest: 1,494,277
  against 1,500,000.
- **Found:** `tui_scroll_rows` one-row regions ran LDIR/LDDR with BC = 0,
  a 64 KiB copy on the board. Fixed in libtui, with a timing test.
- **Simulator model:** LDIR/LDDR BC = 0 copies nothing in the model.
  Noted for a separate decision.
- **Next:** the board check of scroll, Enter and join speed.
