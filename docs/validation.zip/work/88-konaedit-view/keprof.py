"""Per-function T-state profile of KonaEdit keys in the simulator.

Run from the repository root after `make` and
`make -C UserSoftware/KonaEdit`:

    python3 work/88-konaedit-view/keprof.py

It compiles listings of KonaEdit's sources (static functions included),
loads a 3 KiB fixture, puts the cursor on line 60 and prints, for each
measured key, the total T-states and the top functions by exclusive
T-states with their call counts.  `app:` names are KonaEdit and its
libraries; `osN:` names are approximate (bank N, kernel map).
"""

import bisect
import collections
import glob
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
APP = os.path.join(ROOT, "UserSoftware", "KonaEdit")
sys.path.insert(0, os.path.join(APP, "tests"))
import test_ui_sim as T  # noqa: E402
from z80sim import read_symbols  # noqa: E402

SOURCES = [os.path.splitext(os.path.basename(p))[0]
           for p in glob.glob(os.path.join(APP, "src", "*.c"))]


def listings(out):
    sdk = os.path.join(APP, "build", "kos-sdk-0.2.0", "include")
    for name in SOURCES:
        asm = os.path.join(out, name + ".asm")
        subprocess.check_call(
            ["sdcc", "-mz80", "-S", "--nostdinc", "-I" + sdk + "/abi",
             "-I" + sdk, "--opt-code-size", "--max-allocs-per-node", "50000",
             "-I", os.path.join(APP, "src"),
             os.path.join(APP, "src", name + ".c"), "-o", asm],
            stderr=subprocess.DEVNULL)
        subprocess.check_call(["sdasz80", "-plosgff", name + ".rel",
                               name + ".asm"], cwd=out,
                              stdout=subprocess.DEVNULL)
    return (glob.glob(os.path.join(out, "*.lst")) +
            glob.glob(os.path.join(ROOT, "build/user/sdk/*.lst")) +
            glob.glob(os.path.join(ROOT, "build/user/sdk/tui/*.lst")))


def symbols(mapfile, lsts):
    gl = {}
    for line in open(mapfile):
        m = re.match(r"\s+([0-9A-F]{8})\s+(_\w+)\s", line)
        if m:
            gl[m.group(2)] = int(m.group(1), 16)
    out = dict((a, n) for n, a in gl.items())
    for path in lsts:
        area = None
        labels = []
        for line in open(path):
            ma = re.search(r"\.area\s+(\w+)", line)
            if ma:
                area = ma.group(1)
                continue
            m = re.match(r"\s+([0-9A-F]{8})\s+\d+\s+(_\w+)::?", line)
            if m and area == "_CODE":
                labels.append((int(m.group(1), 16), m.group(2)))
        base = next((gl[n] - off for off, n in labels if n in gl), None)
        if base is not None:
            for off, n in labels:
                out.setdefault(base + off, n)
    items = sorted(out.items())
    return [a for a, _ in items], [n for _, n in items]


def fixture():
    text = "".join("\tPROCEDURE Item%03d(VAR x: INTEGER); (* comment *)\n"
                   % i for i in range(110))
    return text.encode()[:3072]


class Profile(T.KonaEditTuiSmoke):
    def runTest(self):
        pass


def main():
    tmp = tempfile.mkdtemp(prefix="keprof-")
    app_a, app_n = symbols(str(T.PROGRAM_MAP), listings(tmp))
    entries = set(app_a)
    os_syms = sorted((a, n) for n, a in read_symbols(str(T.MAP)).items()
                     if isinstance(a, int))
    os_a = [a for a, _ in os_syms]
    os_n = [n for _, n in os_syms]
    getkey = read_symbols(str(T.PROGRAM_MAP))["_tui_getkey"]

    p = Profile()
    p.setUp()
    replay, z = p.make_replay()
    z.hid.fs2_add("SRC.MOD", fixture())
    shell_bank = z.bank_of(0x0100)
    z.hid.hid_queue.extend(b"/system/konaedit.exe /fs/SRC.MOD\r")
    app = p.wait_for_input_loop(replay, z, shell_bank)

    def name(pc):
        bank = z.bank_of(pc)
        if bank == app:
            i = bisect.bisect_right(app_a, pc) - 1
            return "app:" + (app_n[i] if i >= 0 else "?")
        i = bisect.bisect_right(os_a, pc) - 1
        return "os%d:" % bank + (os_n[i] if i >= 0 else "?")

    def key(seq, label):
        hist = collections.Counter()
        calls = collections.Counter()
        start = z.tstates
        left = False
        z.hid.hid_queue.extend(seq)
        while True:
            pc = z.pc
            n = name(pc)
            if pc in entries and z.bank_of(pc) == app:
                calls[n] += 1
            before = z.tstates
            replay.skip_delay(z)
            replay.feed(z)
            z.step()
            hist[n] += z.tstates - before
            if z.pc != getkey or z.bank_of(z.pc) != app:
                left = True
            elif left:
                break
        total = z.tstates - start
        print("== %s: %d T-states (%.3f s at 10 MHz)" %
              (label, total, total / 1e7))
        for n, t in hist.most_common(30):
            print("  %9d %5.1f%% %6d %s" % (t, 100.0 * t / total, calls[n], n))

    for _ in range(23):
        p.press_and_measure(replay, z, app, b"\x1b[B")
    key(b"\x1b[B", "scroll down")
    for _ in range(36):
        p.press_and_measure(replay, z, app, b"\x1b[B")
    for _ in range(8):
        p.press_and_measure(replay, z, app, b"\x1b[C")
    key(b"X", "type X")
    key(b"\x1b[C", "right")
    key(b"\r", "enter")
    key(b"\x08", "join")
    p.tearDown()


if __name__ == "__main__":
    main()
