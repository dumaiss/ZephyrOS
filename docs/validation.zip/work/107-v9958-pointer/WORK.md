> Worker package. After 106 (accepted). The V9958 driver draws a mouse
> pointer in sprite slot 1 for console programs; the SDK moves it. No
> libgfx/exclusive-holder pointer, no libtui mouse events (later). IOC
> firmware untouched. Baseline: HEAD plus the uncommitted, accepted 106
> tree (mouse driver, SDK, tests, docs; board-passed): build on it,
> preserve it. Preserve untracked `docs/KonaOS Programmer's Guide.pdf`.

# Task

Programs on the text console get a pointer: a sprite the V9958 driver
places at a pixel position, kept visible through console drawing, hidden
on demand and by every display reset. The owner fixed the slot: the
pointer is sprite **#1**; the text cursor stays #0.

## Current state

- G6, sprite mode 2, 8×8 patterns. SAT `F200h` (`V9958_CURSOR_SAT_ADDR`),
  pattern table `F800h` (cursor = pattern 0), colour table `F000h`
  (16 bytes per slot; slot 0 at `F000h`). Constants:
  `drivers/v9958/v9958_driver.h` `V9958_CURSOR_*`.
- `drivers/v9958/v9958.c:v9958_cursor_write_sat` writes 8 SAT bytes:
  slot 0 = cursor (Y = cell top − 1 + `scroll_origin`, X = column × 3,
  sprite X unit = 2 G6 pixels), slot 1 = Y `D8h` (terminator). A hidden
  cursor writes `D8h` into slot 0, which ends evaluation there: any
  later slot is invisible. Cached by `cursor_sat_*`;
  `v9958_cursor_init` uploads pattern and colours at every display
  reset.
- The bracket (`drivers/v9958/v9958_io.asm` `v9958_sprites_off`,
  `v9958_sprites_restore`, `v9958_hold_off/_restore`, call sites near
  lines 615-664): every console WRITE/PUTC/RENDER sets R#8 SPD (sprites
  off) and restores sprites only if `cursor_visible`, read as the bare
  literal `(_v9958_state+11)`; the other offsets are `V9958_ST_*` with
  `_Static_assert`s in `v9958_driver.h:233-247`. While a program holds
  the VDP exclusively, the bracket touches no port.
- Sprites follow R#23: a SAT Y of `D8h` from `y + scroll_origin` is
  possible today for the cursor (latent).
- Every program start runs `KCONSOLE_OP_RESET` → `KVIDEO_OP_RESET`
  (`kernel/main.c` near 300/399, `drivers/console/console_proto.c`), the
  full display re-init.
- Video protocol: `abi/kos/protocol.h` `KVIDEO_OP_*` 0..6.
- Text area: 85 × 26 cells of 6 × 8 = 510 × 208 pixels.
- SDK mouse: `user/sdk/include/kos/mouse.h`, `user/sdk/src/mouse.c`
  (106); `/system/mouse.exe` (`tests/mouse/mouse.c`).
- Peer: `tests/z80sim.py:V9958Peer` records `regs`, `vram`,
  `vram_writes`, `commands`.

Read: `work/00-WORKER.md`; architecture 5.6 (V9958 bullets), 9, 14;
`docs/devices.md` V9958 section; `docs/sdk.md` mouse.

## Requirements

1. **SAT layout** (Must): slot 0 cursor, slot 1 pointer, slot 2 `D8h`
   terminator, always. A hidden cursor or pointer uses a blank pattern
   (all-zero bits, its own pattern number), never `D8h`, so hiding one
   never hides the other and needs no scroll-dependent Y. A visible
   sprite whose Y would be `D8h` is drawn one line higher (`D7h`); same
   rule for the cursor.
2. **Pointer assets** (Must): an 8×8 arrow pattern (hot spot top-left)
   as pattern 1 and slot-1 colours (white, index 15), uploaded by
   `v9958_cursor_init`'s path at every display reset.
3. **`KVIDEO_OP_POINTER (7)`** (Must): no descriptor. `arg0` = x,
   `arg1` = y in G6 pixels (x 0..509, y 0..207; out of range →
   `-KOS_EINVAL`); `arg0 = FFFFh` hides. Converts to sprite space (x/2;
   y + `scroll_origin`, the D8h rule), writes slot 1 only when it
   changed (cache like the cursor's), returns 0. While the VDP is held
   exclusively: `-KOS_EBUSY`, no port touched. Served on any handle.
   Documented in `abi/kos/protocol.h`.
4. **Reset and scroll** (Must): `KVIDEO_OP_RESET` / `KVIDEO_RESET` hide
   the pointer (state cleared). A scroll re-places a visible pointer so
   it stays at the same screen pixel.
5. **Bracket** (Must): sprites are restored when the cursor **or** the
   pointer is visible; while the pointer is visible the bracket does not
   turn sprites off at all, so drawing never blinks it. Replace the
   `+11` literal with a named `V9958_ST_*` offset and a
   `_Static_assert`; new state fields go at the end of the struct.
6. **SDK** (Must): in `kos/mouse.h`/`mouse.c`:
   `int pointer_open(void)` (binds `/dev/video`, type check),
   `int pointer_move(int video, int x, int y)`,
   `int pointer_hide(int video)`. `/system/mouse.exe` bare mode shows
   the pointer following the mouse (`mouse_init` 510 × 208) and prints
   the cell (`x/6`, `y/8`) on each press; `stage` adds the replay checks.
7. **106 leftovers** (Must): `tests/z80sim.py` PING reports level 75
   (`IOC_FW_LEVEL_PINNED`), and `tests/test_shell_sim.py`'s
   "IOC version" pin follows it; the stale comments in `kernel/ipc/ipc.c`
   (driver count) and `tests/test_console_serial.py` (`DRIVER_SET`: one
   class per image; hid serves two) state the current facts.
8. **Docs** (Must): architecture 5.6 (sprite slots, the bracket rule)
   and 14 (remove the pointer item; controllers remain);
   `devices.md` V9958 (SAT layout, `KVIDEO_OP_POINTER`); `sdk.md`.

## Invariants

- The text cursor looks and moves as before: `tests/test_v9958.py`,
  `tests/test_console_acceptance.py` and the console/TUI suites pass
  without expectation edits, except SAT-byte pins that the layout
  change moves (cite requirement 1 for each).
- Exclusive holders (`devtest`, libgfx programs): no port write from
  the pointer path while held; `tests/test_device_release.py` green.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free / reserve | after 106 | the V9958 additions | lower the reserve, not below 768, in all four pins; below that stop and report |
| driver mapped / boot | after 106 | assets | report |
| nucleus ledgers | after 106 | 0 | stop and report any growth |

## Criteria

- **Must:** peer evidence of the SAT (slot 0/1/2, blank-pattern hide,
  D8h never in slots 0-1 while visible, scroll re-placement), sprites
  on through a RENDER while the pointer is visible, reset hides it, held
  VDP → `-KOS_EBUSY` and no write; `make check` green.
- **Informational:** driver hot bytes; one `pointer_move` call in
  T-states; a full-screen RENDER's T-states with the pointer shown and
  hidden (the simulator does not model sprite VRAM contention).

## Simulator

`V9958Peer` already stores VRAM and registers; add nothing unless a
check needs it. Not modelled: sprite rendering, sprite-evaluation VRAM
cost, the 8-per-line limit (owner checklist).

## Owner checklist

- Flash; `/system/mouse.exe` with the dongle: the pointer follows the
  mouse over the whole text area, never blinks while lines print, and
  the text cursor still shows and hides.
- Scroll the console (long output) with the pointer shown: it stays put.
- Run a libgfx program (`pview`) and exit: no stray pointer.

## Validation

```sh
make && python3 -m unittest tests.test_v9958 tests.test_mouse \
  tests.test_console_acceptance tests.test_device_release \
  tests.test_pack_image tests.test_iocfat tests.test_sound \
  tests.test_shell_sim tests.test_console_serial
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-v9958-pointer.md`.
