# 107 progress

## Dirty tree classification (start)
- All modified/untracked files at start = accepted package 106 baseline (HID mouse) + user PDF. Preserve.
- None unclassified.

## Status
- Reading contract and code.

## Baseline (before edits; `make` up to date, then pack_image.py --production rerun)
- image sha256 4bbf0030a087f57a2455e8935210044bce68c96c1d18095b4f541c847733665b (baseline only)
- nucleus fixed: required 9664 | overflow 2 | stacks 768 | room 5950
- nucleus cold: code 25087 end C1FFh | data 1623 at C200h | room 6057
- driver hot 31530/32768 -> free 1238 (reserve 1216 in architecture.md 9, test_pack_image:447, test_sound:153, test_iocfat:178)
- driver boot/bulk 21128/24576; mapped 3584/7936; common 3067 (ceiling 3072)

## Design decisions
- SAT cache: v9958_state.sat[8] (slot0, slot1 entries as written), at struct end; old cursor_sat_* removed. Invalid = Y D8h (never stored).
- Pointer sprite Y = y + origin - 1 (cursor's sprite-line convention: V99x8 draws a sprite one line below its Y). Contract text says "y + scroll_origin": flag as deviation in record.
- term_sync re-commits both slots (scroll re-placement free via cache).

## Driver implemented (build OK)
- v9958_driver.h consts/struct (pointer_* at end, offset 28 asserted; cursor_visible 11 asserted), v9958.c writers, v9958_pointer, cursor_init assets, display_reset hides; proto.c case; protocol.h op 7 + KVIDEO_POINTER_HIDE; asm V9958_ST_CURSOR/POINTER, sprites_off skips when pointer shown, _v9958_sprites_restore exported.
- First build: driver hot 31872 -> free 896 (+342). >= 768, so lower reserve (memory: don't hunt bytes).
- Next: SDK pointer_*, mouse.exe, test_mouse replay, leftovers, docs.

## STATUS: STEER REQUIRED (ABI conflict)
- Verified: `python3 -m unittest tests.test_mouse` -> replay fails: `mouse: pointer range 0 -2 -2`
  (expected -2 -2 -2). Class: unknown -> contract conflict, not implementation.
- Cause: abi/kos/ipc.h struct kos_ipc_frame has `uint8_t arg0` (only arg1 is uint16_t). WORK.md req 3
  says arg0 = x (0..509) and arg0 = FFFFh hides: neither fits a byte (510 truncates to FEh = valid).
  Choosing another layout changes the op's ABI -> worker rules: stop and report.
- Options for the supervisor: (D, recommended) arg1 = x (0..509, FFFFh hides), arg0 = y (0..207);
  (A) arg0 = y with FFh hide, arg1 = x; (C) x/y in the request payload words.
- Second point to confirm: req 3 says sprite Y = y + scroll_origin; the cursor's convention
  (V99x8 draws a sprite one line below its Y) needs y + origin - 1 for the hot spot to land on pixel
  row y. Implemented as y + origin - 1 (pending confirmation).
- Tree state: driver/SDK/mouse.exe/test_mouse replay implemented and building; replay passes up to the
  range line. NOT done: req 7 leftovers, docs (req 8), the four reserve pins (free now 896), test_v9958
  run, final validation, record.

## STEER received (supervisor): option D (arg0 = y, arg1 = x, arg1 FFFFh hides); keep Y = y+origin-1; lower reserve (>=768, <= free).
STATUS: in progress again.
- Option D applied; test_mouse 8/8 OK. Req 7 leftovers done (z80sim level 4Bh, shell pin 75, ipc.c and test_console_serial comments).
- Driver hot after swap 31873 -> free 895; reserve lowered 1216 -> 832 in arch 9, test_pack_image, test_sound, test_iocfat (+ iocfat docstring said 1,536: stale, now 832). memory.md ledger line updated.
- Next: docs (req 8), run focused suites.
- Sources frozen; board image copied.

## Final make check (frozen sources): rc=2, 1024 tests, 1 failure, 119 skipped, 14m03s
- FAIL test_gfx.TestGfxAtlas.test_atlas_mode: "transparent G6, 4 glyphs CPU 10165 (ceiling 9100, target 4,000)".
  Class: pending (investigating whether package code is involved). No edit before classification.
