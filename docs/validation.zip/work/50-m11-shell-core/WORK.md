# Task

The first half of the native shell: `/system/shell.exe`, an ordinary EXE
with no kernel change. This package delivers:
- the read-run loop;
- the parser;
- the path presentation;
- command lookup;
- the built-ins `cd pwd echo path help exit`.

Package 51 adds the file commands, and package 52 puts it in the store and
makes it the boot program. **Here the shell is an ordinary application,
not part of the OS:** it is not in any system's store, the ROM is
unchanged, and it is tested the way any program is: host tests, plus a
run from the (emulated) card. The owner tries it on the machine by
copying `build/user/shell.exe` to the card and typing `X /fs/SHELL.EXE`.

Read: `work/00-WORKER.md`, and the architecture's native shell section
(boot policy excepted).

## Requirements

1. **Program.** Sources live in `user/shell/`, with one file per part:
   - `main.c`: the loop;
   - `parse.c`;
   - `path.c`: presentation and translation;
   - `lookup.c`;
   - `builtin.c`.

   It is built with the SDK `exe_program` rule, with no far code and no
   `STAGE=1`: it goes in no system file. Record the image size.
   **Boundary: the shell is an application.** It uses only the public SDK,
   `kos.h` and `klibc`, exactly like a third-party program: no
   `kos_internal.h`, no raw syscall or gate stubs, no kernel, driver or
   `platform/` header. Everything it needs is already public:
   `console_readline`, `splitargs`, `run`, `chdir`, `getcwd`, `console_*`.
   If something turns out to be missing, stop and report it; do not reach
   around the SDK. The splitter change (requirement 3) is an SDK change
   in `user/sdk/src/args.c`, which the shell then links like any other
   program. Add `user/shell` to the user-boundary checks in
   `tests/test_source_layout.py` (`TestUserSdkBoundary` already walks
   `user/`; also forbid `kos_internal.h` there).
2. **Loop.**
   - Print the prompt `<display cwd>> `, then read a line with
     `console_readline` (128-byte buffer).
   - Parse the line, run it, and store the status.
   - An empty line does nothing.
3. **Parser: one splitter, shared with every program.** Extend the SDK
   `splitargs` (today it handles whitespace and double quotes only). The
   shell parses its line with it, and crt0 parses every program's tail
   with it, so the shell and its children always agree.
   - Spaces and tabs separate words.
   - `'…'`: everything inside is literal.
   - `"…"`: literal, except that `\"` and `\\` are escapes.
   - Outside quotes, `\x` is a literal `x`.
   - Adjacent pieces join into one word. `''` and `""` give an empty word.
     An unterminated quote runs to the end of the line.
   - At most `KOS_ARGV_MAX` (16) words. More words → `shell: too many
     arguments`, status `KOS_EINVAL`.
   - Update the splitter's section in `docs/exe-format.md`, and the splitter's own tests.
4. **Tail serialization (external commands).** Rebuild the tail from
   argv[1..], separated by single spaces.
   - A word that is empty, or contains whitespace, `'`, `"` or `\`, is
     written as `"…"`, escaping `"` and `\`.
   - Over 125 bytes → `shell: argument list too long`, status
     `KOS_EINVAL`, and nothing runs.
   - Round trip: `splitargs(serialize(argv)) == argv`. Test it, including
     empty words and all three quoting forms.
5. **Path presentation** (shell syntax only; the VFS never aliases):
   - Reserved roots: `/fs`, `/system`, `/dev`, matched ASCII
     case-insensitively, as the whole first component.
   - Another absolute path → the same path with `/fs` in front: `/GAMES`
     becomes `/fs/GAMES`, and `/` becomes `/fs`.
   - **`//` names the real VFS root**, and `//x` names `/x`.
   - Relative paths go to the VFS unchanged, which resolves them against
     the real CWD.
   - Displaying a path: `/fs` → `/`, `/fs/X` → `/X`, the VFS root → `//`,
     and everything else as it is.
6. **Startup CWD.** `chdir("/fs")`. If that fails, `chdir("/system")` and
   print `shell: no filesystem, starting in /system`.
7. **Lookup** (shell policy; the kernel has no PATH):
   - A built-in name runs the built-in.
   - A word containing `/` is a path: translate it (requirement 5) and
     `run` it.
   - Otherwise, for each directory in the command path, in order: try
     `<dir>/<name>`, then `<dir>/<name>.exe` (only the first if the name
     already ends in `.exe`).
     - `run` returning `-KOS_ENOENT` (or `-KOS_ENODEV`, a missing card)
       → try the next candidate.
     - Any other result is final.
   - Nothing found → `<name>: command not found`, status `KOS_ENOENT`.
   - The default path is `.`, `/fs/BIN`, `/system`. It holds at most 4
     entries, each at most `KOS_PATH_MAX` bytes and stored translated.
8. **Status and errors.**
   - `run` result < 0: print `<name>: <message>` (the table below). The
     status is the positive code.
   - Child status ≠ 0: print `[exit <n>]`.
   - Built-ins return 0 or a positive `KOS_E*` code and print
     `<builtin>: <path>: <message>`.

   Messages (code → text):
   - 01 not implemented
   - 02 invalid argument
   - 03 no device
   - 04 busy
   - 05 not found
   - 06 no space
   - 07 not supported
   - 08 timed out
   - 09 try again
   - 0A I/O error
   - 0B init refused
   - 0C bad program
   - 10 already exists
   - 11 not a directory
   - 12 is a directory
   - 13 not empty
   - 14 read-only
   - 15 stale
   - 16 cross-device
   - 17 too many open

   Any other code: `error <hex>`.
9. **Built-ins.**
   - `cd [dir]`: no argument → `/`, the display root.
   - `pwd`: prints the displayed path.
   - `echo`: the arguments joined by single spaces.
   - `path`: with no arguments, prints the entries one per line; with
     arguments, replaces them (more than 4 → `EINVAL`).
   - `help`: one line listing the built-ins.
   - `exit [n]`: exit status n (default 0).

   A wrong number of arguments → `usage: <synopsis>`, status `EINVAL`.

## Tests

- **Host:**
  - the splitter and its round trip;
  - path translation and display (all the cases in requirement 5,
    including case-insensitive roots and `//`);
  - the error-message table.
- **Simulator replay** of the unchanged production image, reusing
  `tests/test_hwtest_sim.py`'s `start(card=True, extra_files=...)`: put
  `build/user/shell.exe` on the emulated card as `SHELL.EXE`, run
  `X /fs/SHELL.EXE`, then one scripted session covering:
  - an empty line, quotes and escapes, `echo`;
  - `cd` absolute and relative, `..`, `cd //`, `pwd` display;
  - the `path` edit;
  - a bare name found in `/system` (`hwtest`);
  - an explicit path; a child exiting non-zero; command not found;
  - `exit 3`, with the monitor showing status 3.

  No run without a card (the shell lives on it), and no leak test: exec
  and exit are the OS's, already covered by its own tests. The
  no-filesystem start (requirement 6) is a host-tested branch here; 52
  replays it once the shell is in the store.

## Constraints

- No kernel, driver, system-file or store change. The only change outside
  `user/shell/` and its tests is the SDK splitter (requirement 3).
- The splitter is the one OS-adjacent piece: `crt0` calls it in every
  program, so the store programs relink with it. That is why the
  validation runs `tests.test_sdk` and one production boot. If the
  monitor's pinned size/hash in `tests/test_console_acceptance.py` moves
  only because of the relink, re-pin it and say so in the record.
- Record: `docs/validation/<date>-m11-shell-core.md`, with the shell size.

## Validation (targeted: no `make clean && make check`)

Put the tests in `tests/test_shell.py` (host) and `tests/test_shell_sim.py` (replay). Use these same commands while developing,
and once at the end:

```sh
make                                              # production and build/user/shell.exe build
python3 -m unittest tests.test_shell tests.test_shell_sim tests.test_sdk   # test_sdk: the shared splitter every program links
python3 -m unittest tests.test_console_acceptance # the relinked store still boots
git diff --check
```
