# progress — package 50 (m11 shell core)

State: **done**.  Implementation, host tests, session replay and the
validation batch are green; the record is
`docs/validation/2026-10-12-m11-shell-core.md`.

## Done

- `user/sdk/src/args.c`: the splitter now handles single quotes, double
  quotes with `\"`/`\\` escapes, outside-quote `\x` escapes, adjacent
  pieces, empty words and a trailing backslash; `splitargs` still returns
  the total count and stores at most `max` pointers.  Docs updated in
  `docs/exe-format.md` (section 5), `docs/sdk.md` (section 4 and the tree
  listing), `user/sdk/include/kos/process.h`, `user/sdk/src/crt0.asm`.
- Splitter tests extended in `tests/test_sdk.py`
  (`TestSdkSplitterInSimulator`): tabs, both quote forms, escapes, empty
  words, unterminated quotes; the crt0 argv and capacity tests are
  unchanged and still pass.
- `user/shell/` (main.c, parse.c, path.c, lookup.c, builtin.c, shell.h):
  the read-run loop (128-byte line, `shell: too many arguments` over 16
  words), the tail serializer (`"…"` with `"`/`\` escaped, 125-byte
  limit), presentation/translation (`/fs` ↔ `/`, `//` = the VFS root,
  case-insensitive roots), the command path (`.`, `/fs/BIN`, `/system`,
  stored translated), lookup (`<dir>/<name>` then `.exe`, ENOENT/ENODEV
  continue), the error table and the built-ins `cd pwd echo path help
  exit`.  Declared in the top-level Makefile as `exe_program,shell` with
  `STACK=512`, no far code, no `STAGE=1`, and named on the default target
  (`all:`) so a plain `make` packs `build/user/shell.exe`.
- `tests/test_shell.py` (14 host tests): splitter round trip and quoting
  forms, the 125-byte limit, all translation/display cases, the error
  table, the no-filesystem startup branch (run with stubs staged in the
  program's bank), the artifact (one packed EXE, no segments, not staged,
  no unused SDK member linked).
- `tests/test_shell_sim.py`: production image + card with `SHELL.EXE` and
  `SUB/ORIG.TXT`, monitor `X /fs/SHELL.EXE`, one scripted session
  (empty line, quotes/escapes, cd absolute/relative/`..`/`//`, pwd,
  `path` edit, `hwtest` by bare name, explicit path + `[exit 42]`, command
  not found, too many arguments, `exit 3` → `exec: exit status 0x0003`,
  card unchanged).
- `tests/test_source_layout.py`: `user/shell` files and directory added to
  the owner tables; `TestUserSdkBoundary` now also refuses
  `kos_internal.h` in `user/shell` (the SDK's own sources keep using it).
- `tests/test_sdk.py`: the declared-program list now includes `shell`.
- `tests/test_console_acceptance.py`: `MONITOR_SIZE` 6066 → 6310 and the
  sha256 re-pinned; the monitor relinked because crt0 links the grown
  splitter into every program (the only permitted change outside the
  shell).

## Evidence

- Shell artifact: `build/user/shell.exe` 10602 bytes (image 10566, BSS
  1487, stack 512, 0 segments), sha256
  `4b968470e96f5cd80721d2f6db0dc210a8a2dbf9c505f0d7bc3337b7c32975f8`;
  image sha256 `55951b628932451655cad6a2156c21bb357dd8e5e675bef53f2dcb7cf7f7571c`.
- Production image `build/konaos.bin` sha256
  `3638e156229e79320a5a221a86548c841e578ffb96085223214e71f39b03051d`.
- Final batch: `make` (nothing to be done; `rm build/user/shell.exe && make`
  rebuilt it from the default target during development); `unittest
  tests.test_shell tests.test_shell_sim tests.test_sdk` → 42 tests, OK,
  1 pre-existing skip (helloworld image not built), 53.5 s; `unittest
  tests.test_console_acceptance` → 7 tests, OK, 46.0 s; `git diff --check`
  clean.
- Extra: `unittest tests.test_source_layout` (52, OK); the whole host suite
  (678 tests, 11 min 51 s) fails only the two pre-existing
  `test_system_file_and_boot_order` pins of the old store list (package
  49d added `far_data.exe`, `banks.exe`, `known.bin` to
  `systems/production.json` and left those two tests behind; neither file
  is in this diff — reported, not touched).

## Decisions

- **`path` output is the displayed form** (`/BIN` for the stored
  `/fs/BIN`), like `pwd` and the prompt: the shell speaks its own syntax.
- **`path` over four entries** is a wrong argument count →
  `usage: path [dir ...]` with `EINVAL` (the old path stays).
- **`cd`/`path` errors print the user's own word** (`cd: /nope: not
  found`), never the translated path.
- **`hwtest` under the shell** cannot pass its own xmem/files stages: the
  shell sits one exec level below the eventual boot position, so
  `xmem_selftest`'s far run and `fs_selftest`'s child would be the fifth
  process in the chain and the kernel refuses it.  The replay asserts the
  bare-name lookup and start (`hwtest: begin`), not the verdict; its own
  replay runs the same program one level shallower.  Package 52 (the shell
  as boot program) removes the extra level.
- **The no-filesystem startup branch** (requirement 6) runs in
  `tests/test_shell.py` with `_chdir`/`_getcwd`/console entry points
  replaced by stubs staged in the program's bank: the failed
  `chdir("/fs")`, the `/system` fallback and the exact message are
  asserted.  The replay holds the success path (the first prompt is
  `/> `); package 52 replays the branch itself.
- **`error <hex>`** prints two uppercase hex digits (klibc's `%02x`).
- `lookup.c` holds the error table because requirement 8's first bullet is
  the run-result report; `builtin.c` composes `<builtin>: <path>:
  <message>` out of it.
