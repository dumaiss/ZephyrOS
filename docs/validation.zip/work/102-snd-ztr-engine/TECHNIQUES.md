# 102 — techniques that worked (from 100c04), applied to ZTR

These are optimization defaults for STEER.md's Phase 2: apply them one
at a time, after the literal port matches. The "Measure", "Pitfalls" and
"The write" shadow-initialization notes apply from Phase 1.

## Measure first, with the in-tree tools

- `python3 tests/sndprof.py MODE ARGS` prints per-symbol costs for each
  marker pair (window). `--window N --pc` prints one window's cost per
  instruction, against the listings. Profile before and after every
  change.
- Budgets are counted only while the application mapping is in
  (`app_mapped`, latch mode 10). An interrupt runs OS code at the same
  addresses; leaving it in once produced a false 709 T-state tick.
- The simulator charges every conditional branch its taken cost
  (JR cc 12, CALL cc 17, RET cc 11). Write code for the hardware, not
  for this artefact.
- `z.rd()` reads only through the current mapping. Debug breakpoints
  must sit at application PCs (an entry label); a temporary `::` label
  works.
- The first tick of a phase carries the setup writes. Pin steady-state
  ticks separately from starting ticks.

## Data layout

- **Aligned pages.** Reserve N×256+255 bytes; the page is
  `(area + 255) >> 8` (see `_snd_voice_init`). A 16-byte record per
  channel fills one page, at L = channel << 4 | field.
- **Companion pages.** A ZTR channel needs more than 16 bytes, so use
  several pages with the same L: `inc h` / `dec h` reaches the next
  part of the same channel's record in 4 T-states. Suggested split:
  - one core page (note, instrument, volumes, effect and parameter,
    flags, dirty, arpeggio/pitch values, notation, hairpin);
  - one page per macro slot (5): cursor, timer, delay, and the cached
    loop/release/end;
  - the existing descriptor page, for the shadow and port bytes.
- **Walk with `inc l`.** Order fields in the order the hot code reads
  them. Never re-derive a field with `ld a,l / and F0 / or f` inside a
  loop: keep L at a known field and step with `inc l` / `dec l`.
  Writing `or #field` without `and #0xF0` first was a real 100c04 bug.
- **Table lookups on aligned pages, one load each.**
  - Divisor table: split into a lo page and a hi page, copied at play.
    `ld l,note / ld e,(hl) / inc h / ld d,(hl)`.
  - Loudness: one 256-byte table indexed by `base << 4 | macro`, giving
    `base * macro / 15`. That removes the oracle's multiply and divide.
  - Attenuation `15 - x`: `cpl / and 0Fh`.
- **Zero means nothing to do.** Each channel gets a work-flags byte
  covering an active effect, notation, a hairpin and the active macro
  slots. When it is 0, the walk skips the channel on a single test.
  Maintain it when events are applied, not per tick.

## Control flow

- **One fused walk per channel:** effects, then macros, then render.
  It replaces the oracle's three 16-channel passes. Effects and macros
  write nothing, and the render runs in channel order, so the trace is
  unchanged. Verify against the goldens.
- **Macro step fast path.** No macro → skip. Delay non-zero → `dec`,
  next. Timer non-zero → `dec`, next. Both counters are 8-bit. Only a
  due step reads the item.
  - Keep a cursor pointer to the current item (advance by 3) instead
    of `12 + position * 3`.
  - At bind time, cache the loop, release and end positions as cursor
    values, so bounding is pointer compares with no `ztr_u16` reads.
  - The semantics must match `bound_macro_position` exactly, including
    released versus not released.
- **The dirty bits drive the render, as in the oracle.** Pitch dirty →
  effective note → divisor → `fine_pitch`; volume dirty → loudness.
  Nothing dirty costs one test.
- **`fine_pitch`** needs period × magnitude >> 11, with magnitude
  ≤ 63. Use a 6-step shift-and-add (bounded, about 150 T-states), and
  only when the pitch is dirty and non-zero. That is the only multiply
  allowed.
- **Dispatch.** Order compare chains by frequency, and make the common
  successor a fall-through (as `_op_atten` falls into `_op_wait8`).
  `jp` for far, mostly-taken branches.
- **Bookkeeping once per row or command, not per byte or per tick.**
  The 32-bit counters use `_add32` (`add a,(hl) / ld (hl),a / ret nc`,
  then a carry chain). Every `uint32_t` must be updated in all four
  bytes; ZVG's counters were 16-bit by mistake.
- **No IX/IY, and few push/pop pairs** (21 T-states each). A
  16-bit read-modify-write through memory costs about 40-50 T-states.
  Prefer 8-bit fields wherever the format allows.

## The write (WORK.md requirement 1)

- Take `_snd_fast` (DIRECT and a valid shadow) once per tick. Inline
  compare-and-write: unchanged costs about 70 T-states, changed about
  100.
- Per channel, write the period, then the noise, then the attenuation.
  The noise control is forced on a phase reset (`snd_put_noise` with
  B = 1).
- **The shadow is the library's, in the descriptors** (period shadow
  through +14/15, attenuation at +7), not the oracle's `last_*` fields.
  At play, set the ZTR channels' shadow to what `player_start` assumes:
  the attenuation is 15 after the mute, the period is 0, and the noise
  is "unknown" (write it), so tick 0's writes equal the golden.

## Pitfalls already hit

- A fresh install versus ticks accumulated meanwhile: newly started
  state must see only the current call's ticks.
- A full batch is sent before the append (`SND_BATCH_MAX` 60).
- `snd_tick(n)` runs the ZTR for each of the n ticks (bounded), as the
  ZVG does.
- An L walk ends when `add a,16` wraps to zero. A ring uses `inc l`,
  which wraps inside the page.
