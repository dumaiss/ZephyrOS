# 102 steer: port first, then optimize

**Why:** about 500 minutes went into matching whole-song traces after a
restructured port: a fused walk, cursor pointers, cached macro bounds.
When the trace differs, any of those transforms could be the cause, and
debugging from register writes alone is a search through the whole
song. Today the first divergence is tick 0: `night-market` writes
`c0:93`, the golden `c0:94` (chip 0 voice 0's attenuation, one level
loud).

**The order below is binding.** Stop and report if one divergence takes
more than 60 minutes. Report the (tick, channel, field) that the state
diff names.

## Phase 0: done in 101

101's prepared records equal the oracle's `decode_row` output for every
order of both songs. Pin that as a test first (WORK.md, "101's
remainder"); the engine then starts from records it can trust.

## Phase 1: the literal port

- Port `player.c` and `psg.c` **function by function, in the same
  order**:
  - `player_tick`: `begin_row` (from the record), `advance_effects`
    (all 16), `advance_macros` (all 16 × 5), `psg_render_all` (all 16),
    then the subtick, second and row bookkeeping;
  - the same fields with the same meanings: `macro_position` stays an
    index, `bound_macro_position` reads the macro header each time, and
    the C's `last_period`, `last_attenuation` and `last_noise` stay as
    channel fields;
  - the same clamps, the same signedness, the same order of tests.
- Assembly-owned pages are fine: the field layout is free, the
  semantics are not. Nothing from TECHNIQUES.md's "Control flow" yet.
- The writes go through `snd_put_*` (correct before fast).
- **Debug by state, not by trace.** The oracle already dumps channel
  state per tick (`ztr_trace SONG TICKS STATE`). Export the engine's
  channel state in the same text format:
  - `sndtest ztrdump` writes each tick's state; or the harness reads
    the pages at a breakpoint on the return of `snd_ztr_tick`, in the
    application mapping.
  - A test diffs the two per tick, per channel, per field. The first
    differing field names the function to fix.
  - Do the diff before reading any register trace.
- Gate: both songs, 3,000 ticks, the state equal every tick, and the
  writes equal to the goldens in DIRECT and BATCH. Record the Phase 1
  budget figures (`tests/sndprof.py`).

## Phase 2: optimize under the goldens

- Apply TECHNIQUES.md's transforms **one at a time**: the work-flags
  skip, the macro fast path, the loudness and divisor pages, the inline
  write, then the fused walk last.
- After each transform:
  - run the state diff and the golden tests;
  - profile with `sndprof.py`;
  - keep the transform if both pass and the profile improved, revert it
    otherwise.
- The record lists each transform with its before and after figures.
- A transform that doesn't match within 60 minutes is dropped and
  reported. It is not debugged against the whole song.

## Also

- **Regression:** `tests.test_snd.TestSndZvg.test_malformed_streams_refused_or_stopped`
  (`header-rate-high`: the line is cut after `refused -`; check
  `snd_zvg.c`'s changes and the test's line-end wait). It passes as of
  101's end; keep it passing.
- Keep the rows dump (`ZTR_ROWS_DUMP`, `--rows`) test-only; the
  SNTracker client build must not define it.
