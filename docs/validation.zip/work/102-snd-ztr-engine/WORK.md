> **Read `STEER.md` first: port literally, then optimize; its order is binding.**
> Worker package. After 101. `docs/snd-sdk.md` sections 5.2, 6.3-6.4 and
> 7 (SND-3 and SND-4, the tick side): the ZTR engine in assembly,
> consuming 101's prepared rows, with per-tick register traces identical
> to SNTracker's. SNTracker becomes a libsnd client. No OS change.

# Task

`snd_ztr_engine.asm` is the extracted player. On each tick it:
- at a row's first tick, takes the due record from 101's queue and
  applies its events (the oracle's `begin_row`, ported);
- advances the macros, effects and notation;
- renders the channels into 100c04's descriptors (compare-and-write).

Plus `snd_ztr_play`, `pause`, `resume` and `stop`. The traces must
equal 97's goldens tick by tick, writes included.

## Current state

- **The oracle:** `UserSoftware/SNTracker/player.c` and `psg.c`, the
  semantics to port function by function:
  - `bind_instrument`, `reset_macros`, `release_macros`, `note_on`;
  - `process_modifiers`, `process_effect`, `begin_row` (`decode_row`
    is 101's producer: its records equal the oracle's output);
  - `advance_notation`, `advance_effects`, `bound_macro_position`,
    `advance_macro`, `advance_macros`, `advance_position`;
  - `psg.c`'s `effective_note`, `fine_pitch`, `render_tone`,
    `render_noise`, `render_volume`;
  - `sntracker.h`'s `struct tracker_channel`.
- **The goldens:** 97's per-tick traces and channel-state dumps for both
  songs.
- **Already in place:** the resident tables and the prepared-row queue
  (162-byte records, byte head/tail; `snd_private.h`, 101); 100c04's page-aligned descriptors, level page
  and `snd_put_*` primitives (HL = descriptor); the DIRECT full
  rewrite; the tick dispatch with its catch-up cap (98).

Read: `work/00-WORKER.md`; `docs/snd-sdk.md` 5.2, 6.3, 6.4, 7;
`docs/ZTR-Format.md`; `player.c`, `psg.c`, `sntracker.h`; 98's, 101's and
100c04's records; `snd_voice.asm` (the walk and inline commit) and
`snd_zvg_dec.asm` (the C/assembly split to copy); **`TECHNIQUES.md`
(this directory): the measurement defaults, and the optimizations for
STEER.md's Phase 2.** Profile with `tests/sndprof.py`.

## Requirements

1. **Engine (assembly)** (Must):
   - **Port the oracle's semantics** exactly: note 0-95, instrument,
     volume, OFF, release, legato; the volume, pitch, arpeggio,
     noise/duty and phase-reset macros, with delay, step, loop and
     release index; persistent arpeggio and hairpins; effects 1-6;
     the embedded divisor table; noise rate 3 coupled to tone 2;
   - **Channel state:** in assembly-owned storage, in a layout chosen
     for the code (not necessarily the C struct's). Signed 16-bit where
     the format says so;
   - **Speed:** no 32-bit arithmetic in the tick unless the format needs
     it, no multiply, and table lookups for the divisor and volume
     mappings.
2. **The queue consumer** (Must):
   - at a row's first tick, take the head record if it is the due
     (order, row), apply its slots in channel order, then advance the
     head;
   - if it is not published: underrun (section 6.3). Mute the ZTR's
     voices, enter `UNDERRUN`, count it, and resume at that row once
     `snd_service` publishes it (automatic, documented);
   - the stop-song effect ends in `DONE` deterministically.
   - **Assembly from entry to port.** Everything on the tick path is
     assembly: the queue consumer, the event application, the macros,
     effects and notation, the render, the underrun mute and the stop
     effect. C keeps only setup and rare control (open/prepare, play,
     pause, resume, stop, status), as `snd_zvg.c` / `snd_zvg_dec.asm`
     split it. Any C left on the tick path is stop-and-report.
   - **The render's write** (Must): DIRECT with a valid shadow, compare
     and write inline per register, 100c04's commit shape
     (`ld a,(hl) / inc l / cp (hl) / jr z / ld (hl),a / inc l /
     or (hl) / inc l / ld c,(hl) / out (c),a`). The output-mode and
     shadow-valid test is taken once per tick (`_snd_fast`), not per
     write; BATCH and an invalid shadow use the `snd_put_*` primitives.
     Unchanged registers cost a compare, nothing more.
   - **No IX/IY in the per-channel path**; channel state reached by
     `L` arithmetic on aligned pages, as the descriptors are.
3. **Control (C)** (Must):
   - `snd_ztr_play` needs `READY`, and reserves the mask;
   - `pause` mutes the ZTR's voices and keeps the state; `resume`
     restores them from the engine's shadow;
   - `stop` silences and releases the mask.

   A manual voice inside the mask is refused while the ZTR plays (98's
   ownership).
4. **The tick budget** (Must). With 16 channels active, the worst tick
   of both songs is measured and recorded. Catch-up beyond the cap
   counts as an overrun, as in 98.
5. **SNTracker** (Must). `UserSoftware/SNTracker`:
   - on SDK 0.2.0, `LIBS=snd` and the stdio reader;
   - `snd_tick` from its timer handler and `snd_service` in the
     foreground;
   - its `ztr.c`, `player.c` and `psg.c` removed. Keep the UI and the
     README, updated;
   - the 20,480-byte whole-file limit is gone (the songs stream), in
     the player and in `tools/csmc.py`: `ZEPHYR_PLAYER_LIMIT` and the
     `max_ztr_bytes` default become the format's limit (the option
     stays); `docs/CSM-Language.md`'s example follows.

   A host build keeps the oracle: move the old sources under
   `tests/snd/oracle/` (97's tool already builds them), so the oracle
   survives the client's change.
6. **Docs** (Must). `docs/sdk.md`: ZTR playback, the workflow of
   section 8.1, the costs. `docs/snd-sdk.md`: sections 5-7 confirmed,
   the underrun policy.

## Tests

- **Target:** `sndtest ztr FILE` and SNTracker, replayed with the
  harness (budgets attributed with `app_mapped`, interrupts out):
  - both songs, every tick to 3,000 or the end: the writes equal 97's
    goldens, in DIRECT and BATCH;
  - the channel state at chosen ticks equals the oracle's dump (a
    debug export of the engine state, only in sndtest);
  - from the card (stdio), raw handle, memory and KRES: identical
    traces;
  - a stalled reader: underrun, muted, exact resumption at the row;
  - pause/resume and stop: muted, restored, released;
  - the tick makes no `read_at` call;
  - a manual note outside the mask plays; inside it, it's refused;
  - the stop effect: a short fixture (from 97's generator) ends in
    `DONE`.

## 101's remainder (Must, first)

101's deferred acceptance, before the engine work. `TestSndZtrLoad`:
- the test builds `tests/snd/host/host_ztr.c` and diffs its dump
  against `ztr_trace SONG 0 --rows`, both songs (a manual step today);
- `sndtest ztrload` checksums equal the host's, card and KRES `.KPR`;
- a counting reader: offsets never decrease during open;
- short reads and transient errors: same records or a clean error.

Plus the `snd_ztr_open` and one-`snd_service` budgets.

## Budgets (CPU T-states, interrupts out)

| figure | now | target | on overrun |
|---|---|---|---|
| ZTR tick, worst, 16 channels (both songs) | - | <= 15,000 | report with a profile |
| ZTR tick, typical (median) | - | <= 6,000 | report with a profile |
| row tick (events applied), worst | - | report | - |
| per channel, nothing changed (render + 2 compares) | - | report | - |
| C on the tick path | - | 0 | stop and report |
| stack depth of `snd_tick` | - | report | - |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board, with `sntrack night-market.ztr` and
  `sntrack RunawayCircuit.ztr` from the card:
  - both play as before (A/B against the old binary, if you kept one);
  - Q returns, silently.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/SNTracker test
python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_sdk_package
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-ztr-engine.md`.
