# 102 snd-ztr-engine progress

STATUS: COMPLETE

## Dirty-tree classification

- `tests/snd/ztr_state_diff.py`: package work; Phase 1 state comparator named by `STEER.md`.
- `tests/snd/ztr_validate.py`: package work; combined state/write validation for the Phase 1 gate.
- `user/sdk/snd/src/snd_ztr_dec.asm`: package work; the assembly engine required by `WORK.md`.
- No unrelated or unclassified changes were present at takeover (`git status --short`).

## Verified

- Read `work/00-WORKER.md`, `WORK.md`, `STEER.md`, and `TECHNIQUES.md`.
- The three pre-existing untracked files are preserved as the implementation starting point.

## Current next action

- Inspect every named source, caller, build rule, test, and documentation section, then run the early build and focused ZTR tests to identify the first failure before changing implementation.

## Failures

- The second final validation reaches the clean-tree full suite, where 994 tests pass but two integration defects remain: the SDK boundary inventory does not list the new `ztrkres` program, and `TestSndZtr` runs before `TestSndZtrLoad`, so its oracle helper is absent after `make clean`. Classification: test integration/order dependency, not product behavior. Next: declare `ztrkres` in the expected generic-program list and make the engine test class build its own oracle prerequisite, then rerun the exact final block.
- The first final validation block stops in the new full-song budget assertion: Night Market DIRECT has zero state/write mismatches, but its 3,000-tick median is 17,123 T-states (worst 54,861 at tick 1,668, tick-stack depth 26 bytes), above the 6,000 target. Classification: test expectation; `WORK.md` specifies "on overrun: report with a profile", not semantic-test failure. Next: retain and record the measurements without asserting the target, close the oracle helper's warned file handle, and rerun the final block.
- `TestSndZtrLoad.test_card_and_kres_checksums_equal_the_host` reaches RunawayCircuit order 131 of 136 before the helper's 400,000,000-instruction guard expires; no checksum mismatch is reported. Classification: test timeout artifact for a complete target-side row drain. Next: raise only this helper's bound to 500,000,000, enough for the remaining five orders, and rerun the checksum test.
- The dedicated `ztrloadkres.exe` links and validates at 33,748 bytes, but the shell rejects it with `invalid argument` before `main`. Classification: test executable layout/runtime admission, not reader behavior; no program output is reached. Next: compare its EXE manifest/map and application memory footprint with the working `sndtest` binary, then reduce or correct the dedicated target's link shape.
- Adding `libkres` and the KRES adapter directly to the all-purpose `sndtest` makes its image+BSS collide with the application stack top. Classification: test program composition/link budget; KRES is intentionally optional and the large multi-mode harness should not force it into every sound test. Next: restore `sndtest` to `LIBS=snd` and add a dedicated minimal `ztrloadkres` target linked with `snd:kres`.
- After the forward-pass loader refactor, the 500-tick gate has Night Market at zero markers/state (all ticks missing), while RunawayCircuit remains bit-exact. Classification: product implementation, target-specific open/setup path; the host producer accepts Night Market and its rows match the oracle, so the failure precedes target playback rather than changing semantics. Next: capture sndtest's refusal/prepare line and inspect the target capacity/arithmetic path named by that code.
- The post-refactor oracle command `ztr_trace SONG 0 --rows` is rejected with `ticks out of range`. Classification: test invocation artifact; rows-only mode does not take a zero tick count. Next: invoke the oracle in its declared `SONG --rows` form, then compare only the host producer's `row` lines.
- The new counting-reader host run completes the song but exits with `ztr: reader offsets decreased`. Classification: product implementation in 101's deferred loader acceptance; `snd_ztr_open` must not issue decreasing offsets. Next: log the first reversal, identify the validation phase that rereads an earlier section, and reorder or cache that read without changing decoded records.
- The first permanent stall test expected 16 attenuation writes in one underrun tick, but the DIRECT renderer's valid shadow correctly suppresses writes for the 15 voices that were already silent; the captured pairs contain channel 0's `9f` mute followed by its `9d` restoration. Classification: test expectation, not product behavior. Next: assert the audible voice's mute/restore transition and the exact resumed order/row.
- `python3 tests/sndprof.py ... --files ...` is rejected because the profiler declares singular `--file` and parses options before its positional command arguments. Classification: profiling invocation artifact, not a product failure. Next: use `sndprof.py --file GUEST=HOST MODE ARGS` for the recorded final measurements.
- Rebuilt `sndtest ztrstall` completes its bounded 64-tick run in state `PLAYING` with `underruns 0`, although the fake reader served two zero-length reads. Classification: test harness implementation; the prepared queue contains more than two service intervals, so a two-call stall recovers before it can drain and cannot exercise the required underrun path. Next: keep the fake reader stalled until the target reports `UNDERRUN`, release it there, and run one recovered tick to prove exact due-row resumption.
- `make -C tests/snd sndtest.exe` fails because `tests/snd` has no standalone Makefile target named `sndtest.exe`. Classification: test invocation artifact, not an implementation failure; the target test program is built by the repository's top-level test build. Next: inspect the top-level rule and rebuild through its declared target before exercising the control modes.
- `python3 -m unittest tests.test_snd.TestSndZtrLoad` fails during test discovery because `tests.test_snd` has no class with that name. Classification: test artifact in the package text, not an implementation failure; `WORK.md` names `TestSndZtrLoad`, while the current test module's actual class names must be used. Next: enumerate the module's ZTR test classes and run the matching focused tests.
- `python3 tests/snd/ztr_validate.py night-market 1` raises `IndexError` in `golden_writes`: it iterates the complete golden trace while the engine run intentionally contains the requested one tick. Classification: implementation in the new validation helper; the helper's documented contract is to validate the requested tick count. Next: bound the golden comparison by the engine run/requested ticks, then rerun the same command.
- The first manual `host_ztr` compile fails because the command omitted `-Iabi`, so the host shim cannot find `kos/types.h`; the subsequent diff was invalid because no host binary existed. Classification: test invocation artifact, not product behavior; the project headers place `kos/types.h` under `abi`. Next: rebuild with `-Iabi` and only run row diffs if compilation succeeds.
- After bounding that comparison, `python3 tests/snd/ztr_validate.py night-market 1` runs and reports tick 0 writes empty versus golden `81 1d 94`; it also reports zero state differences, which may mean both state parsers produced no entries. Classification: implementation, because the golden trace is the accepted oracle (`STEER.md` Phase 1 gate). Next: inspect the raw oracle and sndtest output plus marker buckets before changing engine semantics.

## Current renderer diagnosis

- Simulator breakpoint at the application-mapped `_snd_ztr_tick` return verifies channel 0 state equals the oracle but `snd_put_period`/`snd_put_atten` are never entered; core dirty remains `0x0f`.
- At `_zt_render`, the flags read leaves `L=base+ZC_FLAGS`; `_zt_zr_kind` then uses `or #ZC_DIRTY` without first restoring the base, so channel 0 reads `ZC_NOTE` as dirty. The unchanged-cache exits in tone/noise/volume also retain `H=core2`, making the next channel walk the companion page. This is the aligned-page pitfall called out in `TECHNIQUES.md`.
- Next: normalize `L` before the dirty read and restore `H` on every unchanged-cache path, then rerun the exact one-tick validation.

## Verified engine gates

- `python3 tests/snd/ztr_validate.py night-market 1`: PASS after the renderer address restoration; tick 0 has zero write and state mismatches.
- `python3 tests/snd/ztr_validate.py night-market 10`: PASS; zero write and state mismatches.
- `python3 tests/snd/ztr_validate.py night-market 100`: PASS; zero write and state mismatches.
- `python3 tests/snd/ztr_validate.py RunawayCircuit 100`: FAIL with 12 write and 120 state mismatches; first write tick 9 `98` versus `9c`, first state field tick 9 channel 8 macro volume `7` versus oracle `3`. Classification: implementation; the Phase 1 oracle state names the volume-macro path (`advance_macro`/`advance_macros`). Next: compare channel 8's positions/values around ticks 8-10 and inspect its bound macro header before changing the port.
- A 12-tick focused dump shows equality through tick 8; at the tick-9 release the oracle jumps volume-macro position from 9 to 18, while the engine restarts it at 1. `_zt_release_macros` loads the release index into `DE` and then calls `_zt_macro_base`, which clobbers `DE` with the slot index before storing the position. Next: preserve the literal release index across that call and rerun the 12-tick gate.
- After preserving the release index, the 12-tick gate still fails at tick 9 channel 8: macro volume is `0` versus oracle `3` (write `9f` versus `9c`), with six state mismatches. Classification remains implementation in release/macro stepping. Next: inspect the corrected position and the macro item address/value at tick 9; do not alter expected state.
- The focused tick-9 state has engine macro position 22 versus oracle 18. `_zt_release_macros` exchanges the macro pointer into `HL`, advances it two bytes to inspect flags, then exchanges back; this makes `DE=macro+2`, so the subsequent `+8` reads the item count at header offset 10 as if it were the release index. Next: retain the original macro pointer for the offset-8 read, then rerun the focused gate.
- `python3 tests/snd/ztr_validate.py RunawayCircuit 12`: PASS after restoring the original header pointer; zero write and state mismatches.
- Breakpoint-based `ztr_validate.py` replaces target-side state printing: it samples the assembly pages at application-mapped `_snd_ztr_tick` returns and retains marker-framed write comparison. `python3 tests/snd/ztr_validate.py night-market 100 RunawayCircuit 100`: PASS in 23 seconds, zero write/state mismatches.
- `python3 tests/snd/ztr_validate.py night-market 3000 RunawayCircuit 3000`: Phase 1 DIRECT gate PASS; 6,000 marker-framed ticks, zero write mismatches and zero channel-state mismatches.

## Phase 2 measurements

- Literal-port `RunawayCircuit` `ztrpause` profile: row tick 0 = 32,504 T-states; active steady ticks = 17,281-18,871, another row tick = 19,842; paused ticks = 458. This exceeds the 15,000 worst and 6,000 median targets, so the required Phase 2 transforms are necessary. The largest steady costs are unconditional 16-channel effect/notation/render walks and header-bound macro steps.
- Next transform (one at a time per `STEER.md`): use the maintained `ZC_WORK` flags to skip channels/slots with no effect, notation, macro, or dirty render work; clear dirty-work after the render. Then rerun the 3,000-tick state/write gate before profiling.
- Work-flags transform: 500 ticks of both songs PASS with zero state/write mismatches. Profile improves row tick 0 from 32,504 to 20,859; steady ticks from 17,281-18,871 to 8,316-9,114; later row tick from 19,842 to 13,845. Keep the transform.
- Next transform: cache each bound macro's loop/release/count in the unused half of its slot record so the due-step path preserves index semantics but stops rereading three header words twice per step.
- Cached macro bounds: 500 ticks of both songs PASS. Steady ticks improve by 262 T-states (8,054-8,852); later row tick improves from 13,845 to 12,791. Start/bind tick grows from 20,859 to 22,378 due to the one-time cache fill. Keep it because the steady path improves and the fused walk can address the remaining row cost.
- Next transform: take DIRECT/valid once into `_snd_fast`; inline period/noise/attenuation compare-and-write in the ZTR renderer, retaining `snd_put_*` only for BATCH or invalid-shadow paths as required by `WORK.md`.
- Inline write transform: DIRECT and BATCH each pass 500 ticks of both songs with zero state/write mismatches. Profile is essentially neutral on mostly unchanged steady ticks (about +60 T-states from the required once-per-tick `_snd_fast` setup); changed writes avoid the primitive's repeated mode/valid checks. Keep it because it is a structural Must.
- Next and final control-flow transform: fuse effect/notation, active macros, and render into one channel-order walk. Each channel is independent, and tone 2 precedes its coupled noise voice, so the oracle's write order remains channel order; validate the full state/write gate immediately.
- First fused-walk build fails at assembly line 1718 with `Branching Range Exceeded`. Classification: implementation in the new transform; a forward `jr z,_zt_fw_render` spans the unrolled five-slot block. Next: change only far fused-walk branches to `jp`, rebuild, then run the gate.
- Fused walk: 500 ticks of both songs PASS. Steady ticks improve from 8,116-8,858 to 6,640-7,382; later row tick 12,169; start tick 20,061. Keep it. Next: complete the work-flag fast path with a single zero-work channel skip and skip `begin_row` retirement for channels without an effect; validate and profile before considering cursor changes.
- Complete zero-work skip: 500 ticks of both songs PASS. Typical active ticks are 4,963-5,705 (target met), later row tick 8,256; start tick is still 17,740. Inspection against the literal oracle finds extra bind work: C `bind_instrument` only changes macro pointers, while assembly also resets position/timer/delay (which belongs to `note_on`) and zeroes them when unbinding. Next: restore literal bind semantics; this also removes duplicated row-tick setup.
- Literal bind semantics: 500 ticks of both songs PASS; start tick falls to 16,310 while typical remains 4,963-5,705. Next: an absent binding only needs its two-byte null pointer (cached bounds are ignored), and a present bind can reuse the slot page already found instead of calling `_zt_macro_base` twice.
- Lean bind: 500 ticks of both songs PASS; start tick is 15,685, typical unchanged. Next: remove the redundant first `bound_macro_position` call because every stored position is already bounded, while fixing `reset_macros` to reset absent slots too (the C oracle does so). Validate semantics before accepting the timing result.
- Removing the redundant bound call and resetting absent slots correctly passes 500 ticks; typical improves to 4,498-5,240. Start is 16,468 because the literal all-slot reset exposed expensive repeated header/page lookup. Next: cache each macro's initial delay in spare slot byte 12 at bind and make reset a single slot-page visit with no header dereference.
- Cached initial delay passes 500 ticks; start tick is 15,666 and typical remains 4,498-5,240. The worst sampled start is 666 T-states above target; the required overrun action is a profile, recorded above. Do not trade away literal absent-slot reset semantics.

## Producer and client

- Host producer built with `-DHOST_ZTR`; both songs' complete decoded event dumps compare byte-for-byte with `ztr_trace --rows`.
- Preserved `ztr.c`, `player.c`, `psg.c` and `sntracker.h` under `tests/snd/oracle`; oracle build paths and README follow them.
- SNTracker is an SDK 0.2.0 `LIBS=snd` client using a stdio reader, `snd_tick(count)` in the timer handler and `snd_service()` in foreground; its private player sources and whole-file loader test are removed.
- `make sdk && make -C UserSoftware/SNTracker test`: PASS, 4 client tests; packed `sntrack.exe` is 32,110 bytes, SHA-256 `4c7390eb4d6d3727b2adb2ab6a13ee6fb9b060c4c493d923b483adc184d3fa2c`.
- Next: grow the literal-port gate in small tick ranges and classify the first semantic divergence before further changes.
- The deferred 101 acceptance is now permanent: both host row dumps equal the oracle; normal and 3-byte short reads are identical; a transient error returns `-KOS_EIO`; every malformed ZTR is refused; open offsets are monotonic; raw-card and KRES per-order checksums equal the host for all 30/136 orders.
- The documented forward open pass now populates resident orders, instruments, the one-based macro section, pattern directory and divisors on first encounter. Bounded 256-byte section reads avoid raw-handle request limits. A 100-tick DIRECT and BATCH gate for both songs passes after the refactor.
- Producer profiles (Night Market, application mapping only): complete `snd_ztr_open` 25,801,339 T-states; one `snd_service` after freeing a queue slot 60,072 T-states.

## Final control and sampled budgets

- `sndtest ztrpause` resumes in `PLAYING` at order 0, row 3, tick 2; both paused marker pairs are empty. `ztrnotes` returns `-KOS_EBUSY` inside the reserved mask and succeeds outside it.
- The repaired bounded `ztrstall` drains the queue, records one underrun, emits the audible voice's mute, restores it, and executes the due row: `PLAYING`, order 0, row 3, with six stalled reader calls.
- `sndprof.py` sampled start/row/steady windows for both fixtures. Night Market: start 15,757, later row ticks 6,719/8,486, active steady 3,426-6,016. RunawayCircuit: start 15,670, later row ticks 7,791/7,799, active steady 4,498-5,240. The worst sampled starts exceed 15,000 by 757 and 670 T-states respectively; their symbol profiles are recorded in the command output, led by row application, macro reset/bind and the fused walk.

## Final validation

- The exact required block passes: build, SDK package, four SNTracker client tests, 53 targeted sound/oracle/package tests, clean reproducible rebuild, all 996 repository tests (119 expected skips), and `git diff --check`.
- Full 3,000-tick DIRECT profiles: Night Market median 17,123, worst 54,861 at tick 1,668; RunawayCircuit median 10,433, worst 100,522 at tick 2,628; maximum `snd_tick` stack depth is 26 bytes for both. These exceed the package targets and are reported with the recorded profiles as required.
- `sntrack.exe`: 31,946 bytes, SHA-256 `1a70d91682f7b789d8749cf1e1ab4cac948a5e0728b7e92090f26896f9877a03`.
- Production image SHA-256: `48275a3aa624f6e633c002dc177c828bfed3b518d8e431b05d4f87617644e828`.
- Board playback remains the owner checklist; no automated hardware claim is made.
