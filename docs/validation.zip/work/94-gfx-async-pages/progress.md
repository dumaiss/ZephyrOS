# Package 94 progress (GFX async pages)

- [x] Async: CE wait before each command in v9958_run_batch; no wait
      after last; CPU VRAM paths (upload, text sink, palette, mode set,
      close, page switch) wait for CE first.
- [x] gfx_wait() in kos/gfx.h + io asm (was in gfx_batch.c; kept).
- [x] gfx_show_page(page), gfx_wait_vblank(): refusals, flush pending.
- [x] v9958_io.asm: wait_vblank poll (VR low then high).
- [x] R#2 write with page bit (bit 5, A16): page shown tracked, get_info
      reports, set_mode shows page 0.
- [x] Peer: S#2 VR follows frame clock retrace window (262 lines, 212
      visible, 60 Hz); R#2 write records displayed page; replay reads it.
- [x] Peer duration model: per command from openMSX VDPCmdEngine deltas
      (HMMV 48 ticks/byte, HMMM 88, LMMV 96/dot, LINE 84/dot + 24, PSET
      112; 3 ticks per T-state, /10 to instructions at the poll rate),
      omitted display-slot contention stated (~20%).
- [x] docs/sdk.md async + page flipping.
- [x] gfxtest pages + replays (async order, 32-fill batch, page 1
      shown, frame pacing, partial present, refusals, restore).

## Budgets
- one command queue + flush: 308 (93's figure, unchanged)
- 32-fill batch CPU to return, VDP busy: 14,367 instructions
- HMMM 512x64 G6: 480,637 T at 3.58 MHz = 134 ms (42 retraces; one
  512-dot row = 7,549 T = 2.1 ms fits the 3.18 ms blank)
