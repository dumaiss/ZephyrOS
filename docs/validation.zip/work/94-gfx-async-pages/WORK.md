> Worker package. After 93. Implements the asynchronous execution of
> `docs/gfx-sdk.md` §9.2 and the page flipping of §15.1 (GFX-6). libgfx,
> gfxtest, the peer model, docs. No OS change, no line interrupt.

# Task

Two timing features:
- **Asynchronous batches:** wait for the command engine before starting a
  command, not after it, so the CPU runs while the VDP draws; `gfx_wait`
  waits for completion.
- **Page flipping:** `gfx_show_page` switches the displayed page at
  vertical blank, and `gfx_wait_vblank` lets a program time a partial
  present (a band copied from the hidden page onto the shown one).

## Current state

- **Pages:** both drawing modes have two 256-line pages (y 0-255, 256-511),
  212 lines visible each. libgfx already draws anywhere in 0-511.
  `gfx_set_mode` sets R#2 for page 0 (`GFX_V9958_R2_PAGE_ZERO`, in the
  common register table, `v9958_gfx.c`).
- **The page bit:** in GRAPHIC 6 and 7, the displayed page is R#2 bit 5
  (A16 of the pattern name table base). The other bits keep the value
  `gfx_set_mode` writes. Confirm against the V9958 Technical Data Book and
  cite it.
- **Status:** status register 2 is selected (R#15 = 2) for the CE polls.
  Bit 6 VR is high during vertical retrace. IE0 is off while libgfx holds
  the display, so nothing else reads the status registers.
- **The batch runner:** `v9958_run_batch` (`v9958_gfx.c`) starts each
  command and waits for it, before returning.
- **CPU VRAM paths:** `gfx_upload_*`, the opaque text sink (package 86),
  `gfx_set_palette`, `gfx_set_mode` and `gfx_close` write ports directly.
- **The peer** (`tests/z80sim.py:V9958Peer`): `frame_period` and the frame
  clock exist (`advance`). Check what status register 2's bit 6 models
  today, and extend it to the retrace window, citing the real timing
  (262 lines at 60 Hz, 212 visible: the retrace is the remaining lines).

Read: `work/00-WORKER.md`; `docs/gfx-sdk.md` §9.2, §15, §15.1;
package 93's record; `v9958_gfx.c`, `v9958_io.asm`; the `V9958Peer` frame clock and
status reads.

## Requirements

1. **Asynchronous** (Must):
   - `v9958_run_batch` waits for CE before each command and returns
     without waiting after the last;
   - every CPU VRAM access waits for CE first: the upload, the text sink,
     the palette, the mode set, `gfx_close`, and the page switch;
   - `gfx_wait()` in `kos/gfx.h` waits for CE.

   The existing tests pass unchanged.
2. **API** (Must). `gfx_show_page(uint8_t page)` and `gfx_wait_vblank()`
   in `kos/gfx.h`.
   - **Refusals:** page other than 0 or 1 is `-KOS_EINVAL`; without a
     mode set, `-KOS_EINVAL`.
   - **Pending batch:** both flush it first.
3. **Vertical blank** (Must). `gfx_wait_vblank` waits for the *start* of
   the next retrace: VR low, then high. If called inside a retrace, it
   waits for the next one, so a frame loop runs once per frame. Polling
   is assembly, in `v9958_io.asm`.
4. **Show** (Must). `gfx_show_page`: wait for CE, `gfx_wait_vblank`, then
   write R#2 with the page bit. `gfx_get_info` reports the shown page.
   `gfx_set_mode` shows page 0.
5. **Peer** (Must):
   - status register 2's VR follows the frame clock's retrace window;
   - an R#2 write records the displayed page;
   - the replay can read which page is shown.

   List what isn't modelled (the display's scan position within a line).
   - **Command duration** (Should): CE stays busy for each command's
     execution time, computed per dot or byte from the Technical Data
     Book's timing tables (display on, sprites off). This lets the
     replay measure the CPU/VDP overlap, and lets package 96 measure
     VDP-bound figures. Cite the tables, and state the model's error
     bound.
6. **Docs** (Must): `docs/sdk.md` (asynchronous execution and `gfx_wait`,
   page flipping, partial present with an example sequence).

## Tests

`gfxtest pages` (new mode) and a replay, with the peer's frame clock on:

- **Asynchronous order:** a fill then an upload over the same rectangle.
  The upload's bytes win, because it waited for the fill. A batch returns
  while CE is still set: the replay sees the program reach the next call
  before CE clears.

- **Page 1 shown:** draw page 1, `gfx_show_page(1)`. The R#2 write lands
  inside a retrace window (the replay checks the frame clock at the
  write), and the shown page reads 1.
- **Frame pacing:** three `gfx_wait_vblank` calls in a row return in three
  different frames, one per frame.
- **Partial present:** a band (a third of the screen) drawn on page 1,
  then `gfx_wait_vblank` + `gfx_copy_rect` onto page 0. Page 0's band
  equals page 1's, and the rest of page 0 is untouched.
- **Refusals:** page 2 `-KOS_EINVAL`.
- **Restore:** after `gfx_close` the console shows its own page; this is
  the existing restore check.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | stop and report |
| one command, queue + flush (CPU, CE wait excluded) | 93's figure | no increase | report with a profile |
| a 32-command batch: CPU time to return, VDP still busy | - | report (needs the duration model) | - |
| HMMM band copy, 512×64 G6, VDP time (duration model) | - | report against the 3.2 ms retrace | - |

## Owner checklist

- On the board, `gfxtest pages`, which:
  - alternates two different full pages several times a second, with no
    tearing;
  - then updates a third of the screen by partial present;
  - then waits for a key, and gives the console back.
- Note whether the band copy tears. That measures the VDP copy speed
  against the vertical blank.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-gfx-pages.md`.
