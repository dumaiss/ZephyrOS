> Worker package. After 108 correction 02. The nucleus allows 32
> extended-memory objects system-wide instead of 16. OS change: full
> validation. Baseline: HEAD plus the uncommitted SDK and `UserSoftware/`
> work in the tree (preserve it, do not edit `UserSoftware/`).

# Task

`XMEM_MAX_OBJECTS` is 16 system-wide, and it binds before memory does:
banks 0-5 hold 42 slots, most objects take one slot, and the objects'
consumers keep growing:
- every far segment of a placed program, up to four per EXE (`kc` and
  `kedit` are placed);
- mappable data segments;
- one libkres catalog cache per open container;
- a parent's objects while a child runs.

KonaEdit, now placed, holds 8 objects per document and needs 16 while it
replaces a document, plus its far segment: 17, so File > Open fails.
Raise the limit to 32.

## Current state

- `kernel/syscall/xmem.c`:
  - `XMEM_MAX_OBJECTS 16u`; `struct xmem_object` is 12 bytes
    (`_Static_assert`).
  - A handle is `(index << 4) | generation` (generation 1..15, the file's
    header comment). `xmem_lookup` refuses `handle > 0xFFu`, so 16 is a
    limit of the encoding, not only of the table.
  - Handles are made at `xmem.c` near lines 218, 297-298 and 507.
- Handles are 16-bit in the syscall ABI and opaque (architecture 4.8,
  "At most 16 objects exist system-wide").
- Users of the limit:
  - `docs/architecture.md` 4.8, `docs/memory.md` ledgers,
    `docs/snd-sdk.md`, `tests/test_ipc_selftest_sim.py` (mentions);
  - the xmem selftest (`make xmem-selftest`, `tests/xmem/`,
    `tests/test_xmem_selftest_sim.py`).
- Nucleus ledgers (`build/konaos.manifest.json`): fixed room 5,950 (rule
  ≥ 2,048), cold room 6,057 (rule ≥ 4,096).

Read: `work/00-WORKER.md`; architecture 4.2, 4.8, 9; `kernel/syscall/xmem.c`
whole; `tests/xmem/`.

## Requirements

1. **The limit** (Must): `XMEM_MAX_OBJECTS 32u`. A handle stays
   `(index << 4) | generation`, now up to 9 bits (index 0..31); the
   `handle > 0xFFu` bound becomes the 9-bit one. Every producer and
   consumer of an xmem handle (kernel, loader segment handles, SDK
   `xmem.c`, `xload.c`, libkres, the tests) keeps it in 16 bits:
   - `rg` every place that stores one;
   - none may narrow it to a byte;
   - list the places you checked in the record.
2. **Exhaustion** (Must): the 33rd allocation fails with the same error
   the 17th did; the selftest proves 32 succeed and the 33rd fails, and
   a freed slot is reused with a new generation.
3. **Docs** (Must):
   - architecture 4.8 says 32;
   - architecture 9 and `docs/memory.md` record the ledger change;
   - `docs/snd-sdk.md` and any other mention follow;
   - the `xmem.c` header comment states the 9-bit handle.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| nucleus (the tier holding `xmem_table`) | ledger | +192 data | any ledger rule broken: stop and report |
| other ledgers | ledger | 0 | report any growth |

## Criteria

- **Must:**
  - the selftest's exhaustion at 32;
  - no handle narrowed to a byte anywhere;
  - `make check` green;
  - `make xmem-selftest` replays.
- **Informational:** the nucleus ledger before and after.

## Owner checklist

- Flash; `/system/hwtest.exe`; run `kedit.exe`, open a file, then File >
  Open another: it replaces the document.

## Validation

```sh
make && python3 -m unittest tests.test_xmem_selftest_sim \
  tests.test_ipc_selftest_sim tests.test_exe tests.test_far_data
make xmem-selftest
make clean && make check   # once, at the end
```

Before `make check`, message "main": sources frozen, plus the sha256 of
`build/konaos.bin`. Record: `docs/validation/<date>-xmem-objects.md`.
