# 110 xmem-objects progress

## Dirty tree classification (at start)
- All modified files listed by `git status --short` at start are pre-existing: package 108 + corrections 01/02 (SDK, docs, tests, tools, mk) and package 108b (UserSoftware/). Classified "unrelated, preserve" per supervisor brief. docs/architecture.md is pre-modified: edit only xmem lines, keep the rest.

## Status
- Reading contract and xmem code.

## Baseline (verified: `make` = nothing to do; manifest)
- build/konaos.bin sha256 05ab6ed3...dafb (pre-change, not a result)
- nucleus fixed room 5950; cold code 25087 end C1FFh, data 1623 at C200h, room 6057.

## Contract mismatches (non-blocking, recorded)
- docs/snd-sdk.md and tests/test_ipc_selftest_sim.py contain no mention of the 16-object limit (rg for xmem/object/16/sixteen). Nothing to follow there.
- architecture 9 holds rules only (values are in docs/memory.md); no figure to change there.

## Handle audit (rg xalloc|xmap|seginfo|.handle|kos_xmem_segment_alloc)
- BYTE STORE FOUND: user/sdk/src/seg.c:64 `static unsigned char farmap_handles[4]` (farmap cache) -> fix to unsigned int.
- 16-bit OK: kernel xmem.c (args u16, lookup u16, success u16, seg_info record[4..5]); exec.c:721 uint16_t handle; abi structs u16; sdk xmem.c unsigned int; xload.c int object; kres_cache_xmem.c:26 int handle; tests xmem_*.c unsigned int/int; far_data.c int; exe2seg/exe2big info.handle u16; hwtest.c held[] unsigned int.
- xmem_far.c:231 masks (handle+1)&0xFF: compares a far return value packed with latch byte; not a store.
- UserSoftware (read only): KonaEdit uint16_t handles; DonkeyKong int cart_handle. OK.

## Plan
- kernel: XMEM_MAX_OBJECTS 32, XMEM_HANDLE_MAX 0x1FF bound, drop redundant index check, comments.
- selftest: held[32]; boot-only rows objects-* (table exhaustion 32, 33rd ENOSPC with mappable room free, reuse same index new gen, 9-bit alias refused). Stage count 61 unchanged (rows boot-only: in stage memory binds first).
- replay OUTCOMES add rows; docs arch 4.8, memory.md ledgers.
- edits done: xmem.c, seg.c, xmem_selftest.c, test_xmem_selftest_sim.py; next: make + xmem-selftest
- FAIL (run 1, make xmem-selftest): test_the_token_cache_costs_one_segmap_per_segment: caller attributed `_bcall_token` instead of `___sdcc_bcall_ehl`. Class: pending investigation (hypothesis: map symbol layout shift from seg.c farmap_handles widening; attribution is nearest-symbol).
  - Classified: test artifact. Source: user/sdk/src/bcall.asm as committed in 5b8cea5 (2026-10-30, automatic placement) moved the cache lookup into the global subroutine `_bcall_token::` (bcall.asm:97), which makes the `call _segmap`; the replay's expectation (`___sdcc_bcall_ehl`) dates from e6cf239 and the last xmem-selftest record is 2026-10-12-banked-calls.md, before 5b8cea5. Unrelated to this package (bcall.asm untouched); blocks the Must "make xmem-selftest replays" -> fix the pin to `_bcall_token`, same counts {1:1, 2:1}. Found-outside-scope item for the report.
- SOURCES FROZEN after plain make; next: message main, then validation block
- block: 85 tests OK skipped=19 (missing ipc/subsys/fs images); make xmem-selftest 9 OK, image cfdf5ad9...; next make clean && make check (background, log scratchpad/check.log)
- make clean && make check: 1037 OK, 120 skipped (acceptance images removed by clean + 2 abstract harness), 13m08s. build/konaos.bin 477c10be... unchanged.
- Record written: docs/validation/2026-11-01-xmem-objects.md. docs/alteration-guide-outline.md appeared untracked (not ours).
STATUS: DONE, handed off.
