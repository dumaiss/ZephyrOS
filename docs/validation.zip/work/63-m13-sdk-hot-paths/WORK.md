> Supervisor-implemented (owner request). Runs after 62. The SDK only
> (user/sdk): every program linked to it gains, SDBENCH and SC2KOS among
> them. No ABI change, no kernel change.

# Task

Make the SDK's per-call and per-byte paths cheap. A T-state profile of an
SDK program's read loop (simulator) shows the SDK's C costs: the compiler
division helpers `__divuint`/`__moduint` ~3,400 T per call and the 32-bit
ones far more (every `/` and `%`, and printf's digits: `utoa`/`ultoa` run
two helper calls per digit), `call()` ~0.19 ms of marshalling per call,
`timer_now()` ~0.42 ms assembling its 32-bit result with shifts, and
`memcpy`, `memset`, `strlen` and the other klibc string routines as C
byte loops.

Read: `work/00-WORKER.md`; `docs/sdk.md`; `user/sdk/src/` (`klibc/`,
`ipc.c`, `timer.c`, `stdio.c`, `console_io.c`); the 59-62 records.

## Requirements

1. **Arithmetic helpers in assembly**: `__divuint`/`__moduint` (and the
   signed pair through them) as a shift-subtract routine under the
   compiler's calling convention; the 32-bit pair at least no slower.
   Same results for every input class (a host test drives the routines
   in the simulator against Python's arithmetic, including 0 divisors,
   which return 0 as now).
2. **Digits without generic division**: `utoa`/`ultoa`/`itoa`/`ltoa`
   (and printf through them) use one divide-by-base step that yields
   quotient and remainder together (16/8 per byte for 32-bit values).
3. **klibc memory and string routines in assembly**: `memcpy` (unrolled
   `LDI`), `memmove`, `memset`, `memcmp`, `strlen`, `strcmp`, `strncmp`,
   `strchr`; same results and return values.
4. **The call path**: `call()` and its helpers with no avoidable copies;
   `timer_now()` stores its result as bytes.
5. **Measure**: the user-mode profile before and after; board SDBENCH; a
   printf-heavy row (iobench console) before and after.
6. No behaviour change: `tests.test_sdk*`, the SDK program replays and
   every image using the SDK pass.

## Validation

```sh
make && python3 -m unittest tests.test_sdk tests.test_sdk_package tests.test_io_sim tests.test_shell_sim tests.test_hwtest_sim tests.test_readpath
make clean && make check   # once, at the end, with 62
```

Record: `docs/validation/<date>-m13-sdk-hot-paths.md`.
