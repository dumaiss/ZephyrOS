# Public IOC Client Contract

## Task

Correct the remaining compile-time dependency from the HID driver into the IOC
driver's private implementation directory. Preserve the accepted M8 runtime
behavior, module ABI, wire protocol, ZMOD format, module load order, and all
hardware-visible behavior.

This is a post-M8 boundary correction, not a reopening of package 17 or any
other M1-M8 milestone. The accepted M8 implementation is the behavioral
baseline.

## Problem and required boundary

`drivers/hid/hid.c` includes `drivers/ioc/ioc_proto.h` through the global
`-I drivers/ioc` module include path. That header labels itself private, but it
also contains the HID request/reply identifiers and payload offsets that a
legitimate IOC client must know. Runtime coupling is already correct: HID
discovers `ZDEV_IOC` by class/capability and invokes `struct zioc_ops`; it does
not import IOC symbols or touch SIO1. The correction is therefore limited to
the source/interface boundary.

Create `include/zephyros/ioc_protocol.h` as the client-visible contract for
deployed MCU command vocabulary and payload layouts that must be shared across
drivers or target diagnostics. Move, do not duplicate, the HID request/reply
constants and their client-visible payload offsets/limits into that header.
Move any other constants only when they have an actual non-IOC client. Keep
wire framing, CRC/sequence handling, lane setup, READY/DONE admission state,
bulk recovery, pinned-driver implementation details, and private helper
declarations under `drivers/ioc/`. `include/zephyros/ioc.h` remains the IOC
class ABI; the new header describes service vocabulary, not another device
interface.

Update HID, IOC, and target diagnostic includes and tests to use the correct
owner. Remove `-I drivers/ioc` from the global module compile flags. IOC source
may include its local private headers from its own directory; an explicitly
test-only IOC diagnostic rule may use a private include path only if it tests
private transport behavior. No production driver may include or depend on a
sibling driver's private path.

Add a filesystem/build dependency regression check that rejects production
cross-driver private includes and sibling-driver include paths. Prefer checking
declared include paths and dependency edges over attempting to parse arbitrary
C syntax. Update `docs/devices.md` and the relevant IOC/HID comments so they no
longer describe a private header as a client contract.

## Constraints

- Do not change numeric command/reply values, payload interpretation, queue
  sizes, retry policy, IOC timing, or firmware assumptions.
- Do not add a generic bus or protocol framework.
- Do not modify the adjacent Zephyr-80 repository or deployed IOC firmware.
- Do not alter `struct zioc_ops`, `struct zioc_frame`, `struct zdriver_api`, or
  any ABI version.
- Keep the patch focused on ownership of shared constants and mechanical
  enforcement. Package 22 owns broader header visibility.
- Production IOC and HID ZMOD bytes are expected to remain byte-identical. If
  they do not, stop and explain the semantic or toolchain reason before using
  prior physical evidence.

## Validation

Run at least:

```sh
make clean
make check
python3 -m unittest tests.test_ioc tests.test_ioc_sim tests.test_hid tests.test_hid_sim -v
python3 tools/zmodpack.py validate build/modules/ioc.zmod
python3 tools/zmodpack.py validate build/modules/hid.zmod
git diff --check
```

Compare the corrected production IOC and HID ZMOD SHA-256 values with the
accepted baseline:

```text
ioc.zmod  808b6d5e986b7abbc06b943264a8ef277b60b9f288d5ebb66b5e186a27d77ca3
hid.zmod  bd7e3933f669f544e6d5b9fb3f1ff6670d773545041545a8fa7619915193ef11
```

## Acceptance criteria

- HID reaches IOC only through the public class API at runtime and public
  client-visible protocol declarations at compile time.
- No production build rule gives every module access to `drivers/ioc/`.
- IOC transport-private declarations remain private and are not copied into a
  second header.
- A regression test fails on a future sibling-driver private-header edge.
- All stated tests pass and both production ZMOD hashes are unchanged.

## Expected files

- `include/zephyros/ioc_protocol.h`
- `drivers/{ioc,hid}/`
- `tests/`, `Makefile`
- `docs/devices.md`

