> Worker package. After 103. SN-Track's static view: `docs/sntrack-ui.md`
> drawn from a ZTR file, no playback. A user application on the SDK
> tarball; no OS, libgfx or libsnd change, except fixing a defect the view
> finds (record it). Baseline: HEAD; the dirty song/HID/test files are
> not in scope.

# Task

`sntview FILE.ZTR [ORDER]` in `UserSoftware/SNTracker/`: GRAPHIC 6, the
whole SN-Track screen for one order and one 25-row page, from the song's
own data. Space steps to the next page (next order after the last page)
with a page flip, as playback will. Q/Esc exits.

`sntrack` (the console player) stays as it is: `tests/test_snd.py`
plays both songs through it. The next package wires libsnd into the view,
makes it `sntrack`, and deletes `sntview` and the console player
together.

## Current state

- **libgfx** (`kos/gfx.h`, `docs/gfx-sdk.md` 6-8.1, 11-13, 15.1):
  `GFX_FONT_4X6` opaque text, `gfx_fill_rect` with `GFX_OP_XOR`,
  `gfx_line`, `gfx_show_page`. Text x must be even in GRAPHIC 6
  (`gfx_text.asm`); fills and lines take any x.
- **The reader:** `kos/reader.h`, `kos_reader_from_stdio`; `read_at` is
  absolute. `sntracker.c` shows the open/size path.
- **The songs:** `UserSoftware/SNTracker/songs/`. Both have 32 rows per
  pattern (two pages: 25 + 7), all noise events carry a note and an
  instrument, no arpeggio macros, one-value duty macros. RunawayCircuit
  runs at 62 Hz (TEMPO 310), 136 orders, 11 instruments.
- **The noise rule's source:** `tests/snd/oracle/psg.c`
  `render_noise`, `effective_note`.
- **Simulator harness:** `tests/test_snd.py` `run_sntrack` (an exe from
  `/fs` on the production image); `tests/test_gfx.py` `g6_text_row4`
  (4×6 glyph rows as G6 bytes); `UserSoftware/KonaEdit/tests/test_ui_sim.py`.

Read: `work/00-WORKER.md`; `docs/sntrack-ui.md` (all of it: the target;
`mockup.png` here shows the look, with sample data that does not follow
the spec: the spec wins on every value and format);
`docs/ZTR-Format.md`; `UserSoftware/PView/` (a gfx app's Makefile and
exit path).

## Requirements

1. **`ztrdoc` (C)** (Must), `ztrdoc.c`/`ztrdoc.h`, section 11:
   - `ztrdoc_open(reader)`: header, strings, orders (up to 136 × 16),
     instrument directory; bounds and counts checked as
     `docs/ZTR-Format.md` states; a bad file is a negative `KOS_E*`;
   - instrument types (`T`/`N`/`M`) from one pass over every stream;
     a tone-and-noise instrument is `-KOS_EINVAL`;
   - `ztrdoc_load_order(order, buf, size)`: the order's 16 streams into
     a caller buffer of 1,024 bytes (`-KOS_ENOSPC` if larger), with a
     start/end per channel, none for `FFh`;
   - an event decoder keeping every field: note, instrument, volume,
     effect + parameter, OFF, release, legato, the modifier flags and
     values;
   - each instrument's arpeggio and noise/duty macro: value 0, its
     fixed flag, the delay.
2. **View (C)** (Must), `view.c`/`view.h`: sections 1-10, exactly:
   - palette (section 2, `level * 255 / 7`);
   - every coordinate from section 8.1's table; every text x even; a
     `_Static_assert` or table check on the column x values;
   - cells formatted from decoded events only: section 8.3, 8.4;
     absent fields blank; `N` blank unless section 8.4's conditions hold;
   - one row is drawn by `view_draw_row(page, row, events)`; the
     viewport is 25 calls, so the next package can spread it over steps.
3. **Static state** (Must): `STOP`, `00:00`, `POS` = ORDER/count,
   `ROW 00/rows-1`, `HILITE 04/10`, `OCT 4`, `STEP 1`, `INS 00`,
   `FOCUS CHIP A`. XOR highlights on the cursor row, the current order and
   instrument 00, tracked per page; never two over the same pixels.
4. **Paging** (Must). Space: the next page is drawn on the hidden page
   (static regions included, or copied with `gfx_copy_rect`), then
   `gfx_show_page`. After the last page: the next order, page 0, the
   order window scrolled when the order leaves it (section 5), the cursor
   on row 0. Wraps after the last order.
5. **Program** (Must): `sntview` in the Makefile beside `sntrack`,
   `LIBS=gfx`, the same SDK archive. A load error prints a message on the
   console before `gfx_open`; every exit path closes gfx and the file.
   `README.md` gains a `sntview` section: what it shows, the keys.
6. **Spec gaps** (Must): if `docs/sntrack-ui.md` cannot be followed
   on the hardware, stop and report it; do not work around it.

## Tests

`tests/test_sntrack_view.py`, run by `make check`: `sntview.exe` on
the production image, VRAM decoded with 4×6 glyph rows.
- **Reference:** a Python model in the test reads the ZTR and formats
  every expected string (titles, orders, instrument lines, cells).
- **Both songs, order 0 page 0:** the title bar, the three panels and
  every pattern cell equal the reference at section 8.1's x; the palette
  registers equal section 2.
- **A synthetic ZTR** written by the test, covering: OFF, release,
  legato, every effect ID, modifiers (not shown), absent fields, `FF`
  orders, an unused instrument (`M`, colour 7), `N` blank and shown, a
  pattern of 40 rows (a third page with blank rows).
- **Highlights:** the cursor row's pixels are the base row's XOR 8; no
  other row holds a colour above 7 outside the order and instrument
  highlights.
- **Space:** R#2 switches; page 2's rows 19h-1Fh equal the reference and
  rows 20h-31h are blank; after the last page the next order shows page
  0, and order 4 scrolls the order window.
- **Refusals:** a tone-and-noise instrument, a truncated file and an
  order over 1,024 stream bytes print their message and exit with gfx
  never opened.
- **Exit:** Q restores the console.

## Budgets (CPU T-states)

| figure | now | target | on overrun |
|---|---|---|---|
| `ztrdoc_open`, RunawayCircuit | - | report | - |
| one order's load and decode | - | report | - |
| one pattern row drawn (16 cells) | - | report | - |
| full viewport (25 rows) | - | <= 6,000,000 (600 ms: 25 rows at speed 3 last 1.2 s) | report with a profile |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board, `sntview /fs/night-market.ztr` and
  `sntview /fs/RunawayCircuit.ztr 4`: the screen matches the mockup's
  layout; on Space the next page appears all at once (no rows
  painting in, no flicker); Q returns to the shell.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/SNTracker test
python3 -m unittest tests.test_sntrack_view tests.test_snd
git diff --check
```

Record: `docs/validation/<date>-sntrack-view.md`.
