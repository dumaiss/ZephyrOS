# Progress

- STATUS: done; host and simulator validation recorded, board PENDING.
  Record `docs/validation/2026-10-28-sntrack-view.md`.
- Owner changes folded into `docs/sntrack-ui.md` mid-package: `FFh` orders
  blank; unused channels marked `M` (colour 7) in the header's last slot;
  empty slots show CP850 `FAh` (middle dot) in colour 2.
- Fixed after the worker stopped:
  - the smoke test's "displayed" condition fired before drawing (the console
    already had the display on); the test now waits for off, then on;
  - `sntview` called `gfx_show_page(0)` with the display off; the peer has no
    retrace then and it hung. `gfx_set_mode` already shows page 0: removed;
  - the test enables the peer's frame clock (`frame_period`) for flips;
  - `ztrdoc_open` 231 M T-states: per-byte stream reads and a linear
    directory scan per order cell. Now one in-memory decoder, a 1 KB read
    window, the directory sorted once with a per-channel index: 84 M, of
    which 66 M is the simulated reader;
  - the order heading drew 54 characters of a 51-character string;
  - status `ROW` showed `00` on every page; row fills now span 512 px.
- Tests: `tests/test_sntrack_view.py`, a reference renderer of the spec
  compared pixel for pixel: Night Market (two pages and the next order,
  palette, exit), RunawayCircuit order 4, a synthetic song (every field,
  three pages, order-window scroll), three refusals. 4 tests, ~40 s.
- Do not run the simulator tests in parallel: four at once ran the host out
  of memory.
