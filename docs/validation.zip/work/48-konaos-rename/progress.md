# Package 48 (KonaOS rename) - working log

Contract: `work/48-konaos-rename/WORK.md`. Baseline: the accepted 46 tree
(HEAD `676924c`, production image
`c4b407ee6a2cc0f1a885686c0547a911a2718d75b03df83e44ee0a7dd7570a08`).
Runs after 46 and before 47 (47 is still a draft). No commit.

## 1. Baseline snapshot (before any edit)

- `build/` copied whole to `/tmp/k48/baseline-build/` (production image,
  page bins, manifest, `modules/`, `recovery.romfs`) so the end check can
  compare regions after the tree is rebuilt.
- Baseline figures: production sha `c4b407ee...`; store
  `2d2f8f3c...`, 88389 bytes; fixed core end 3D2Ch (8335 + 2 + 768, room
  7279); cold half end BB33h, data 1527 at BC00h, room 7689; driver hot
  21910/32768; driver boot/bulk 2170/24576; common 2358/7424 (code 1511,
  data 847, ceiling 3072); gate stack 384.

## 2. Renames applied (git mv, 22 moves)

Directories: `abi/zos/`->`abi/kos/`, `user/sdk/include/zos/`->`kos/`,
`user/sdk/include/zlibc/`->`klibc/`, `user/sdk/src/zlibc/`->`klibc/`.
Files: `formats/include/{zex,zmod}.h`->`{exe,mod}.h`,
`tools/{zexpack,zexmanifest,zmodpack}.py`->
`{exepack,exemanifest,modpack}.py`, `user/sdk/{zex.mk->exe.mk}`,
`user/sdk/include/{zos.h->kos.h}`, `user/sdk/src/{zos_internal.h->
kos_internal.h}`, `docs/{zex-format.md->exe-format.md}`,
`tests/{test_zex.py->test_exe.py}`, `tests/{test_zmod.py->test_mod.py}`,
`tests/subsys/gen_{zex_fixtures,zex2_segments}.py`->
`gen_{exe_fixtures,exe2_segments}.py`,
`tests/target/process/{zex2big,zex2probe,zex2seg,zextest}.c` and
`zextest_sp.asm` -> `{exe2big,exe2probe,exe2seg,exetest}.c` /
`exetest_sp.asm`.

## 3. Content pass

308 tracked files rewritten by the mechanical rules R1-R5 (case-sensitive
substring replacement, `work/` and `docs/validation/` excluded). The
complete line-level report is `/tmp/k48/changes.txt`.

Magic fix-ups after the mechanical pass (the stored header bytes are
`KEX2`/`KMOD`, not the mechanical `EXE2`/`MOD`):

| file | change |
| --- | --- |
| `formats/include/exe.h` | magic comment `KEX2`; `EXE_MAGIC_0 'K'` (`4B`) |
| `formats/include/mod.h` | `MOD_MAGIC_0 0x4Bu` (`'K'`) |
| `tools/exepack.py` | docstring + `MAGIC = b"KEX2"` |
| `tools/modpack.py` | docstring + `MAGIC = b"KMOD"` |
| `docs/exe-format.md` | magic row `KEX2` (`4B 45 58 32`), boundary row |
| `docs/module-format.md`, `docs/architecture.md` | magic `KMOD` |
| `tests/test_exe.py` | magic chars `enumerate("KEX2")` |
| `tests/test_ns_selftest.py` | packed-container magic `b"KMOD"` |

Fixtures keep building their containers through `exepack.MAGIC` /
`modpack.MAGIC`, so they follow the new magic automatically.

Negative tests added (one per format, old magic written as hex bytes so
the final grep stays empty):

- `tests/test_exe.py::test_old_magic_is_rejected` (with
  `gen_exe_fixtures.old_magic_container()`, bytes `5A 45 58 32`; the
  ordinary `EXE_EXEC_ERR_MAGIC` boundary);
- `tests/test_mod.py::TestContainerValidation::test_old_magic_is_rejected`
  (bytes `5A 4D 4F 44`; the ordinary "bad magic" check).

## 4. Unmapped (left unchanged, not covered by R1-R5)

- private prefixes: `zt_`, `ZT_`, `zrt_`, `ZRT_`, `zn_`, `zs_`, `zout`,
  `zxmem_`, `ZDRIVER_` (WORK.md names them);
- the hardware: `Zephyr-80`, `zephyr80`, `ZEPHYR80`,
  `platform/zephyr80/`, and the Z80 tool/CPU names (`z80`, `sdldz80`,
  `sdasz80`, `z80sim.py`);
- the ROMFS container magic `ZRFS` (no rule covers it; the ROMFS format
  is unchanged);
- the repository directory, the git remote and `work/`,
  `docs/validation/` (contract).

## 5. Findings the build forced

- **SDCC 4.5.0 cannot take the boot path through `-D`.** The driver
  asserts the preprocessor command line free of ".exe"
  (`SDCCutil.c` `setPrefixSuffix`), and every `KOS_BOOT_PROGRAM` ends in
  `.exe`, so the setting now travels as the generated header
  `$(BUILD)/boot_program.h` that `kernel/main.c` includes.  The compiled
  string is unchanged; `tools/bootprogram.py` still validates the setting
  before the header is written.
- **Program relayout from the renamed SDK symbols.** `sdld` pulls
  library members in symbol-hash-table order; renaming `_zos_*` to
  `_kos_*` changes that order, so the linked user programs
  (`fs_child.exe`, `hwtest.exe`, the xmem programs) differ in layout
  even where no string changed.  Controlled experiment: the same objects
  link `fs` before `args` with the old `libzos.lib` and `args` before
  `fs` with the new `libkos.lib`; the archives differ only in the
  renamed symbols.  This is reported in the record (the store's program
  payloads are not byte-identical to package 46's).
- **Monitor re-pin**: `MONITOR_SIZE` 6068 -> 6066, `MONITOR_SHA256` ->
  `4d27328b...` (banner two bytes shorter plus the layout shift).
  `PINNED_FONT_SHA256` is unchanged (the font asset edit is a comment).
- **Sorted-name assertion** in `test_sdk.py`: the renamed `exe2*`/
  `exetest` names sort before `fardemo` now; the expected list was
  re-ordered (same set, no weakening).
- **Documentation-dependent tests dropped (owner decision, 2026-10-12).**
  Two live docs cite the historical record
  `docs/validation/2026-10-03-m6-zex.md`, whose name is frozen (the
  rules are not applied in `docs/validation/`), so
  `tests/test_docs_evidence.py` failed on the renamed citations.  Per the
  owner: no test depends on documentation.  The module
  `tests/test_docs_evidence.py` is deleted, and `test_iocfat.py`'s
  doc-reading assertions are dropped (the residency assertion stays,
  test renamed).  The citations themselves stay renamed, so the final
  grep is empty.

## 6. Done

- Formal validation on the frozen source (2026-10-12):
  `make KOS_JOBS=16 clean && make KOS_JOBS=16 check` -> exit 0, 3m50s,
  reproducible rebuild `8a4f4067...`, 607 tests OK / 104 skipped;
  the full image matrix -> exit 0, 10m31s, 163 tests, no failure, no
  skip (re-run once with `-Otarget` to attribute the counts: 6m09s);
  `git diff --check` empty; the final grep empty.
- End check against the package 46 baseline: fixed core/ledgers/common
  and gate stack identical apart from relocated operands into the
  two-byte-shorter cold half; cold half differs only by the renamed
  strings (boot-path extension bytes and the banner); drivers differ by
  the magic byte only; the store by names, extensions, magic and the
  program relayout reported above.
- Record written: `docs/validation/2026-10-12-konaos-rename.md`.
- No commit (owner instruction).  Handoff: package 47 (documentation
  pass) follows.
