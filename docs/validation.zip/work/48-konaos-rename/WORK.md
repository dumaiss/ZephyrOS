# Task

**A rename only** (owner decision, 2026-10-12): the OS becomes
**KonaOS**. Its code prefix, executable format and module format follow.
Every rename is fixed in the tables below. You make **no design
decisions**, and there is no behaviour change other than the stored
header bytes named in R3 and R4.

Runs **after 46 and before 47**, so the documentation pass sees the final
names. Baseline: the accepted 46 tree (production `c4b407ee…`). Read
`work/00-WORKER.md`, the 46 record and `work/46-m10-surfaces/TABLES.md`
(its collision rule applies here).

## Steps

Apply the rules in order, R1 to R5. **Build nothing between steps.** The
production image is built and checked once, at the end, as part of the
validation below. Do not commit.

**End check, against the baseline** (`c4b407ee…`):
- driver hot and boot, common and the gate stack are identical;
- fixed core and cold half change only by the length difference of the
  renamed strings ("ZephyrOS" is 8 bytes, "KonaOS" is 6);
- the store changes only through the new names, extensions and header
  bytes.

Any other change: report it with its cause.

## Tables

Each rule is a case-sensitive substring replacement, applied everywhere:
- identifiers, file and directory names, strings, ROMFS names, Makefile
  variables and rules, tool names and options, comments;
- `docs/` (except `docs/validation/`), `README.md`.

It is not applied in `work/` or `docs/validation/`. There are no
exceptions beyond the ones listed. A collision check over the whole tree
found none (2026-10-12).

**R1, product:**
- `ZephyrOS` → `KonaOS`;
- `zephyros` → `konaos`;
- `ZEPHYROS` → `KONAOS`.

The hardware keeps its name: `Zephyr-80`, `zephyr80`, `ZEPHYR80` and
`platform/zephyr80/` are unchanged.

**R2, prefix:**
- `zos` → `kos`, `ZOS` → `KOS`, `Zos` → `Kos`.

This covers `abi/zos/` → `abi/kos/`, `zos.h` → `kos.h`, `libzos` →
`libkos`, `user/sdk/include/zos/` → `kos/`, the `-DZOS_*` flags,
`_ZOS_SDK_DATA` and `zos-sdk`.

**R3, executable format:**
- `zex` → `exe`, `ZEX` → `EXE`, `Zex` → `Exe`.

This covers:
- the `.zex` extension → `.exe` (stored names, `/system/*.exe`, the boot
  program setting, manifests);
- `formats/include/zex.h` → `exe.h`, `tools/zexpack.py` → `exepack.py`,
  `zexmanifest.py` → `exemanifest.py`, `user/sdk/zex.mk` → `exe.mk`;
- `zex_program` → `exe_program`, `ROMFS_FLAG_ZEX` → `ROMFS_FLAG_EXE`,
  `zextest` → `exetest`, `docs/zex-format.md` → `docs/exe-format.md`.

**Header magic `ZEX2` → `KEX2`** (`'K','E','X','2'`). The header version
stays 2.

**R4, module format:**
- `zmod` → `mod`, `ZMOD` → `MOD`, `Zmod` → `Mod`.

This covers the `.zmod` extension → `.mod` (`sio.mod`, …),
`formats/include/zmod.h` → `mod.h`, `tools/zmodpack.py` → `modpack.py`,
`ZmodError` → `ModError` and `DRV_SET_ZMODS` → `DRV_SET_MODS`.

**Header magic `ZMOD` → `KMOD`** (`'K','M','O','D'`).

**R5, public `Z` families → `K`** (ABI, protocol, SDK and test mirrors of
them):

| from | to |
|---|---|
| `ZFS_`, `zfs_` | `KFS_`, `kfs_` |
| `ZFILE_` | `KFILE_` |
| `ZCONSOLE_` | `KCONSOLE_` |
| `ZVIDEO_` | `KVIDEO_` |
| `ZHID_`, `zhid_` | `KHID_`, `khid_` |
| `ZSIO_` | `KSIO_` |
| `ZIOC_`, `zioc_` | `KIOC_`, `kioc_` |
| `ZCAP_` | `KCAP_` |
| `ZREL_` | `KREL_` |
| `zlibc`, `ZLIBC_` | `klibc`, `KLIBC_` (the directories included) |

Private prefixes stay as they are: `zt_`, `ZT_`, `zrt_`, `ZRT_`, `zn_`,
`zs_`, `zout`, `zxmem_`, `ZDRIVER_`. List them under "Unmapped".

## Rules (no judgement calls)

1. **Unmapped.** Anything not covered by a rule stays unchanged and is
   listed in `progress.md` and in the record.
2. **Renames of files and directories are `git mv`.**
3. **Tests change only by the same rules.**
   - Pinned artefact hashes and sizes (for example `MONITOR_SHA256`) are
     re-pinned, and the record lists each one.
   - No assertion is deleted, skipped or weakened.
   - Test fixtures that build ZEX or ZMOD bytes switch to the new magic.
   - Add one negative test per format: the old magic is rejected with the
     existing bad-magic error. Write the old magic as hex bytes
     (`5A 45 58 32`, `5A 4D 4F 44`) so the final grep stays empty.
4. **Stop and report**, rather than working around, if:
   - the end check fails;
   - a rule produces a name that already exists;
   - the rules conflict.
5. **Docs are rewritten by package 47.** Here they change only by these
   rules, so mechanical artefacts are expected. List the obvious ones for
   47.

## Out of scope

- Renaming the repository directory, the git remote or the Zephyr-80
  hardware names.
- Any other rename or fix: list it instead.

## Validation (once, at the end)

```sh
make clean && make check
make <the full image matrix>
git diff --check
grep -rIl -e zos -e ZOS -e zex -e ZEX -e zmod -e ZMOD -e ZephyrOS \
  --exclude-dir=.git --exclude-dir=work --exclude-dir=validation \
  --exclude-dir='build*' .        # must print nothing
```

## Record

Write `docs/validation/<date>-konaos-rename.md`. It contains:
- the production hash and the ledgers, before and after;
- the re-pinned artefacts;
- the "Unmapped" list;
- the empty grep;
- the store before and after.
