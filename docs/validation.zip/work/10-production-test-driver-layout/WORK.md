# Task

Finish the M4-era source-tree cleanup by separating production drivers, module packaging/runtime support, and milestone acceptance code. Remove the obsolete M3 static-driver boot mechanism. Preserve the current device registry, console service, dynamic ZMOD loader, SIO behavior, IRQ behavior, and failure rollback while making every remaining production file's name and owner describe its current purpose.

## Context

The platform ownership cleanup is complete, but the current tree still reflects bring-up history:

- `drivers/sio/driver.c` is actually the SIO ZMOD entry and also contains IRQ/failure test variants; the generic name is inconsistent with `drivers/ctc/ctc.c`.
- `drivers/sio/module*.json` are packer manifests, not driver implementation. Only `module.json` is production metadata; the IRQ and failure manifests are test fixtures.
- `drivers/sio/sdcc_glue.asm` is not SIO logic. It supplies module-local SDCC indirect-call trampolines because ZMODs cannot import the kernel copy. The same implementation is duplicated as `tests/modules/m4_sdcc_glue.asm`.
- Target tests remain in `kernel/irq/`, `kernel/device/`, `kernel/module/`, `drivers/test/`, and `include/zephyros/`. `kernel/syscall.c` also contains conditional self-test implementation. `kernel/irq/selftest.c` is an unreferenced older test implementation.
- `kernel/device/driver.c`, `boot_drivers[]`, `struct zdriver`, `driver_init_static()`, static-driver counters, M3 fallback flags, and their map/tests are linked legacy from M3. Production M4 boots only embedded ZMOD drivers, so this static path is no longer required.

Use this canonical ownership:

```text
drivers/sio/                 sio.c, sio.h, sio_io.asm, sio_module.c
drivers/ctc/                 ctc.c
modules/manifests/           production ZMOD manifests (sio.json)
modules/runtime/             shared module-local runtime sources
tests/modules/               synthetic/test ZMOD sources and manifests
tests/target/m1..m4/         target-side milestone acceptance code
tests/target/include/        target-test-only headers/constants
tests/target/support/        shared target-test runner/hooks/helpers
```

## Requirements

- Rename `drivers/sio/driver.c` to `drivers/sio/sio_module.c`. Make it production-only: device descriptor plus `sio_module_init`; remove `ZOS_SIO_MODULE_IRQ_SELFTEST`, `ZOS_SIO_MODULE_INIT_FAIL`, counters, handlers, deliberate failure, and all other acceptance logic.
- Keep `drivers/sio/sio.c` as the SIO implementation and update its stale “M3 static driver” comments. `drivers/ctc/ctc.c` remains the CTC implementation. Family implementation files are therefore consistently named `sio.c` and `ctc.c`; module entry is explicitly `sio_module.c`.
- Move the production packer manifest to `modules/manifests/sio.json`. Move the IRQ and failure SIO module variants and manifests under `tests/modules/`; each test variant must provide its own clearly named module entry rather than compiling test branches into production `sio_module.c`.
- Replace both `drivers/sio/sdcc_glue.asm` and `tests/modules/m4_sdcc_glue.asm` with one source, `modules/runtime/sdcc_indirect_calls.asm`. Compile that source separately into every ZMOD that needs it so each module remains self-contained. Document why it cannot use `kernel/runtime/sdcc_helpers.asm`.
- Remove the M3 static-driver mechanism: delete `kernel/device/driver.c`; remove `struct zdriver`, `boot_drivers[]`, `driver_init_static`, `driver_static_*`, and static-only state/tests/map requirements. Keep `struct zdriver_api`, ABI version/result constants, and the registry checkpoint/owner/rollback mechanisms used by dynamic module initialization.
- Simplify `kernel_main()` to initialize the registry and loader, load the boot catalog, then bind the console. Remove `ZOS_M3_NO_STATIC_DRIVERS`, `ZOS_M3_NO_CONSOLE_BIND`, `driver_init_static()`, and `m3-fallback`; M4's failing/empty dynamic-catalog tests are the fallback evidence.
- Move all target acceptance implementations and headers out of production directories. This includes the syscall self-test block in `kernel/syscall.c`, `kernel/irq/irq_selftest.c`, `kernel/device/m3_selftest.c`, `kernel/module/m4_selftest.c`, `drivers/test/`, and `include/zephyros/{selftest,irq_selftest,m3_selftest,m4_selftest}.h`. Delete the unused `kernel/irq/selftest.c` after confirming no build reference.
- Organize moved code by milestone under `tests/target/m1` through `tests/target/m4`. Retain meaningful M3 registry/console/IRQ regression coverage, but remove tests that exist only to exercise the retired static table/descriptor. Direct test setup or dynamic test modules must replace static test drivers.
- Remove fixture-catalog conditionals from `kernel/module/embedded.c` and fixture declarations from the production module header. Test catalog definitions belong under `tests/target/m4/` and are linked only into acceptance images.
- Consolidate milestone calls in production code behind one clearly marked `ZOS_TARGET_TEST_BUILD` integration seam. The runner and milestone selection live under `tests/target/support/`; production files must not contain individual `ZOS_M1/M2/M3/M4_*SELFTEST` implementations. If multiple boot-phase hooks are required for the CTC timing test, keep them minimal and label them `TEST-ONLY HOOK` with the exact test-owned implementation path.
- Update `Makefile`, manifests, host tests, map/image checks, `README.md`, `docs/architecture.md`, `docs/devices.md`, and `docs/module-format.md`. Keep M3's static design as historical milestone documentation, but explicitly state it is retired and must not describe the current production tree.
- Extend `tests/test_source_layout.py` to reject production self-test files/headers, `drivers/test/`, the retired static-driver symbols, test-only SIO macros in production sources, JSON manifests under `drivers/`, and driver-private SDCC glue. Assert the canonical paths above.

## Constraints

- Do not redesign the device registry, console API, IRQ executive, ZMOD format, loader allocation/relocation, or module driver API.
- Production SIO and all synthetic modules must remain independently relocatable and must not import private kernel symbols.
- Preserve object order within each ZMOD unless a test-specific entry replaces the old conditional entry. Keep production `sio.zmod` byte-identical if possible; explain any unavoidable difference.
- Test artifacts must be unmistakable by directory and filename. Any unavoidable production hook must use the single test-build guard and an explicit removable marker.
- No MAME dependency. Preserve unrelated worktree changes and historical validation transcripts.

## Validation

```sh
make clean
make check
make syscall-selftest
make irq-selftest
make m3-selftest
make zmod-test
make m4-loader-selftest
make m4-selftest
make m4-placement-selftest
make m4-failure-selftest
python3 -m unittest discover -s tests -v
git diff --check
```

Also prove with source/map checks that normal production images contain no `_driver_init_static`, `_boot_drivers`, `_driver_static_*`, `_m3_*`, self-test runner, fixture catalog, test SIO handler/counter, or deliberately failing module symbols. Record new hashes and rerun physical Zephyr-80 smoke validation for the normal image, dynamic-SIO M4 image, shifted-placement image, and failure-rollback image because removing linked static scaffolding changes kernel layout.

## Acceptance criteria

- Driver directories contain device implementation only; names communicate family implementation versus module entry.
- Production module metadata and reusable module runtime support have explicit non-driver-code owners.
- All milestone/acceptance implementation is under `tests/`, except minimal clearly marked test hooks.
- No static-driver boot path or static-driver test fixture remains in the production kernel.
- Normal M4 boot, dynamic SIO console, relocation, IRQ delivery, and rollback still pass host simulation and physical hardware validation.
- Layout tests prevent the retired structure from returning.
