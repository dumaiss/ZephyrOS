# Task

Implement ZephyrOS milestone M0 from the current empty source skeleton: a reproducible SDCC/sdasz80 build must produce a bootable Zephyr-80 ROM image that copies itself into SRAM, enters the kernel in a deterministic mapping, initializes the polled early serial console, calls C, prints the M0 banner, and remains in a controlled halt loop.

## Context

`docs/architecture.md` is the contract. The target uses a banking latch at I/O port `00h`: mode `10` is value `10h` and mode `11` is `18h`. SIO0/B is the early console at data port `22h` and control port `23h`, using 115200 8N1 from the board's fixed clock.

Use a 128 KiB boot image for M0/M1. ROM page 0 is copied to SRAM bank 0; ROM page 1 is copied to SRAM bank 7. The stackless reset copier selects page 1 and destination bank 7 with latch value `27h`, then selects application mode/bank 0 (`10h`). This page assignment matches the current MAME driver's 128 KiB ROM load and is independent of the runtime SRAM mapping.

Establish this initial linked layout:

- `0000h-00FFh`: page-zero/reset reservation in page 0; reset/stackless copier must remain below `0030h` so M1 can install `RST 30h` there.
- `2000h-DFFFh`: kernel body in SRAM bank 7, visible in mode `11`.
- `E000h-FEFFh`: permanent common code/data in physical SRAM bank 0.
- `FF00h-FFFFh`: 256-byte common boot/runtime stack, with initial `SP=0000h` (top-exclusive `10000h`).

The page-1 image must contain a byte-identical copy of the active reset copier at the same addresses because instruction fetch continues while the ROM-page latch changes. After both copies, execution continues from bank 0 and reaches a common-memory entry. That entry establishes the common stack, writes `18h` to enter OS mode over caller bank 0, and calls `kernel_main()` in bank 7.

## Requirements

- Create the small source tree described for M0 in `docs/architecture.md`: public fixed-width types/platform declarations, boot assembly, kernel main/panic/early console, Zephyr-80 hardware and memory constants, linker control, and host image tooling.
- Provide a GNU Make build using SDCC, sdasz80, and sdldz80 (or SDCC as the final linker driver). Build only freestanding objects; do not link the hosted CRT or standard library. Generate `.ihx` or equivalent link output, a symbol/map artifact, per-page binaries, and final ROM images under `build/`.
- Make `build/zephyros.bin` exactly 131072 bytes: page 0 followed by page 1, unused bytes filled with `FFh`. Also produce `build/zephyr80.bin` as an identical convenience artifact for MAME.
- Implement reset/startup in assembly. Begin with `DI`; make no assumptions about firmware register or stack state; perform the two full 64 KiB ROM-to-SRAM copies without any stack read while mode `00` is active; then establish the common stack and mode `11` before calling C. Do not execute `EI`.
- Initialize the SDCC C runtime state actually used by this kernel. Either copy initializer data and clear BSS from linker-provided area symbols, or make the build fail if unsupported initialized/BSS areas become non-empty. Document which contract is implemented.
- Implement `early_console_init`, `early_console_putc`, and `early_console_puts` without `printf`. Use the proven SIO sequence: channel reset (`WR0=18h`), x16/one-stop/no-parity (`WR4=44h`), 8-bit RX with Auto Enables (`WR3=E1h`), 8-bit TX enabled/DTR asserted with RTS released (`WR5=E8h`), and interrupts disabled (`WR1=00h`). Poll RR0 TX-empty (`04h`) and CTS (`20h`) with a finite timeout before writing port `22h`; a missing terminal must not hang the kernel forever.
- Have `kernel_main()` print exactly these CRLF-terminated lines, then enter a `DI`/`HALT` loop:

  ```text
  ZephyrOS 0.0
  platform: Zephyr-80
  kernel entry: OK
  serial: OK
  HALT
  ```

- If `kernel_main()` returns, enter `panic("kernel_main returned")`. `panic()` prints a clear `PANIC: ...` diagnostic when possible and ends in the same controlled halt loop.
- Add host-side tests for the ROM packer/image layout, including exact size, fill bytes, copier mirroring, and rejection of out-of-region content.
- Write `docs/boot.md` with the reset/copy/mapping sequence, image format, external MAME invocation, and a physical-ROM test checklist. Update `README.md` with build prerequisites and basic commands.

## Files

Likely files to create or modify:

- `Makefile`
- `README.md`
- `docs/boot.md`
- `include/zephyros/types.h`
- `include/zephyros/platform.h`
- `boot/start.asm`
- `kernel/main.c`
- `kernel/panic.c`
- `kernel/early_console.c`
- `platform/zephyr80/hardware.h`
- `platform/zephyr80/hardware.inc`
- `platform/zephyr80/memory.inc`
- `platform/zephyr80/reset.asm`
- `platform/zephyr80/serial.asm`
- `linker/zephyr80.lk`
- `tools/pack_image.py`
- `tests/`

## Constraints

- Preserve the mode `10`/`11` architecture and keep all raw port constants under `platform/zephyr80/`.
- The early console remains a direct, polling diagnostic path. Do not add drivers, interrupts, allocators, processes, filesystems, CP/M conventions, or a generic runtime.
- C/assembly calls are internal implementation details, not a stable ZephyrOS ABI.
- Do not modify the adjacent Zephyr-80 CP/M or MAME repositories.
- Keep generated files under `build/` and ensure they are ignored by Git.

## Validation

```sh
make clean
make
make test
sha256sum build/zephyros.bin build/zephyr80.bin
cmp build/zephyros.bin build/zephyr80.bin
```

Run the debug MAME build from the adjacent Zephyr-80 tree with `build/zephyr80.bin` supplied as `roms/zephyr80/zephyr80.bin`, expose `sio0b_rs232` as a PTY, and verify the exact banner. A checksum warning is expected and non-fatal. Perform the physical test when hardware/programmer access is available and record whether it was executed.

## Acceptance criteria

- A clean checkout builds reproducibly with no hosted runtime dependency.
- The final ROM is exactly 128 KiB and all host tests pass.
- Reset copying is stackless, mode `11` is active before C kernel code executes, the stack remains in common memory, and interrupts remain disabled.
- MAME emits the exact banner and reaches the halt loop.
- The physical hardware procedure is documented; M0 is fully accepted only after the same banner is observed on hardware.
- No M1-or-later subsystem is introduced.
