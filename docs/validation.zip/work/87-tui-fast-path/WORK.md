> Worker package. Runs after 82 is committed (its `tui_scroll_rows`,
> `user/sdk/tui/src/tui_scroll.asm`, is the baseline). libtui and its tests
> only: no nucleus, driver, console ABI or KonaEdit change.

# Task

Make libtui's per-cell work cheap enough that an editor can answer a key in
under 0.1 s and scroll a line in under 0.2 s at 10 MHz. Three changes: a
row primitive in assembly, an assembly cell-map shift for
`tui_scroll_rows`, and per-row pending flags so a flush skips clean rows.

## Current state

Measured in the simulator (T-states, KonaEdit, 3 KiB file):

- `tui_scroll_rows` shifts the model through `tui_delete_line` /
  `tui_insert_line` (`tui_window.c`), which call `tui_priv_set_cell` per
  cell: 2,295 `set_cell` + 4,206 `tui_priv_attr` calls, about 2.7M
  T-states per one-line scroll.
- `tui_flush_render` (`tui_flush.c`) walks every row's dirty and invert
  bitmap bytes, twice: about 360k T-states even when one row is dirty.
- `tui_priv_set_cell` (`tui_screen.c`) is the only writer of dirty and
  invert bits (`TUI_DIRTY_SET`, `TUI_INVERT_SET`); `tui_clear_dirty`,
  `tui_dirty_all` (`tui_flush.c`) and `tui_init` (`tui_lifecycle.c`)
  reset the maps.
- Cell map (`tui_internal.h`): `tui_chars[TUI_CELL_COUNT]`, one byte per
  cell; `tui_attrs`, 4 bits per cell, even cell in the low nibble; stride
  `TUI_MAX_COLS` (85, or 128 for `libtui_128x35.lib`), so with 85 a row
  starts on a half byte every other row.
- `tui_scroll_rows` flushes before it submits the SCROLL record, so the
  dirty and invert maps are all zero when the model shifts.

Read: `work/00-WORKER.md`; `docs/tui.md`; `user/sdk/tui/src/*`;
`user/sdk/exe.mk` (libtui members); `tests/tui/tui_test.c`;
`tests/test_tui_sim.py`; `docs/validation/2026-10-22-tui-storage.md`.

## Requirements

1. **Row primitive** (Must). Public, in `tui.h`:
   `int tui_put_text(uint8_t x, uint8_t y, const char *text, uint8_t length, uint8_t attr);`
   x and y are window-relative. Each byte is stored as a literal glyph:
   no control-byte meaning, the cursor does not move. The effect is
   exactly that of calling `tui_priv_set_cell(x + i, y, text[i], attr)`
   for i = 0 .. length-1, clipped to the window: the same chars, attrs,
   dirty and invert bits, `model_only` honoured. It returns
   `-KOS_EINVAL` when not initialised or `text` is null; 0 otherwise,
   also when clipped to nothing.
   - Assembly, in its own archive member `tui_text.asm`, so programs
     that do not call it do not link it.
   - Compute the cell index and the attribute nibble position once, then
     step through the row: no multiply or call per cell.
   - `attr` is the cell value `tui_get_attr` returns.
2. **Model shift** (Must). `tui_scroll_rows` keeps its record and its
   return values, but its model step no longer calls
   `tui_delete_line`/`tui_insert_line`. An assembly routine moves the
   region's rows by one:
   - chars as one block (`LDIR`, or `LDDR` for down) of
     (height-1) x `TUI_MAX_COLS` bytes;
   - attribute nibbles with a nibble-aware copy, valid for odd and even
     strides (`RLD`/`RRD` or a two-nibble loop).
   The exposed row then holds what the current model-only path leaves
   there (`tui_blank_row`): spaces in `tui_state.attr` across the
   screen width. Dirty and invert stay zero.
3. **Pending rows** (Must). `uint8_t tui_row_pending[TUI_MAX_ROWS]`
   (`tui_state.c`, declared in `tui_internal.h`):
   - `tui_priv_set_cell` sets the row's flag whenever it sets a dirty or
     invert bit, and so does `tui_put_text`;
   - `tui_clear_dirty` and `tui_init` clear all flags; `tui_dirty_all`
     sets all;
   - both passes of `tui_flush_render` skip a row whose flag is zero;
     the ANSI path (`tui_flush_ansi`) may use the flags too.
   A set flag with no bits is harmless; a clear flag with bits set is
   a bug.
4. **set_cell in assembly** (Should). `tui_priv_set_cell`,
   `tui_priv_attr` and `tui_priv_store` in assembly, same semantics, so
   `tui_fill`, `tui_puts_xy` and the widgets speed up too. Skip it if the
   Musts already meet the budgets and it would cost more than 150 bytes.
5. **Docs** (Must): `docs/tui.md` (`tui_put_text`; `tui_scroll_rows`
   cost), `docs/sdk.md` member list.

## Tests

In `tests/tui/tui_test.c` (new modes) and `tests/test_tui_sim.py`, on
both lanes where the existing TUI tests run:

- **Equivalence:** a mode that writes the same rows with `tui_put_text`
  and with `tui_puts_xy` (same attribute), on a screen with mixed
  attributes, some cells already equal, and a row clipped by a window.
  Each path flushes; the render records of the two paths are equal
  byte for byte.
- **Shift:** fill the screen with a distinct char and attribute per cell
  (both nibble parities), then `tui_scroll_rows` up and down over
  several regions (top 1, height 24; top 3, height 5; height 1). After
  each, `tui_save` of the full screen equals the expected shifted grid.
  This runs on the 85-column and 128-column archives.
- **Pending:** after a flush with no change, the next flush emits no
  span. After one `tui_putc_xy` on row 20, only row 20's spans go out.
- **Timing:** measure T-states with `z.tstates` from a function's entry
  PC to its return. At entry, read the return address from the stack;
  stop when PC equals it and SP is above the entry SP. Assert the
  budgets below. Measure `tui_scroll_rows` only while PC is in the
  program's bank, so the console IPC and driver time are excluded.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| `tui_flush`, nothing pending | ~360k | <= 8,000 T | stop and report |
| `tui_flush`, one 85-cell row dirty | ~370k | <= 60,000 T (program bank) | report |
| `tui_put_text`, 85 cells, all equal | (n/a) | <= 12,000 T | stop and report |
| `tui_put_text`, 85 cells, all new | (n/a) | <= 30,000 T | stop and report |
| `tui_scroll_rows` model work, 24 rows x 85 | ~2.7M | <= 150,000 T (program bank) | stop and report |
| KonaCommander headroom | 868 B | >= 512 B | report |
| `tui_test.exe` | builds | links | stop and report |

Record the before and after figures, measured the same way.

## Criteria

- **Must:** requirements 1-3 and 5; the tests above pass; all TUI suites
  pass (`tests.test_tui`, `tests.test_tui_sim`, `tests.test_console_tee`,
  KonaCommander's and KonaEdit's suites); the Must budgets met.
- **Should:** requirement 4.
- **Informational:** sizes of `tui_text.rel`, `tui_scroll.rel`,
  `tui_flush.rel` and `tui_screen.rel`, before and after.

## Simulator

The V9958 peer runs the SCROLL record's HMMM copies instantly. The board
pays for the copy, so the owner checks scrolling speed on the board.

## Owner checklist

- KonaCommander: cursor moves and panel redraws look the same as before.
- KonaEdit (after 88): one-line scroll and typing speed on the board.

## Validation

Develop with single tests
(`python3 -m unittest tests.test_tui_sim.TestTuiV9958Screen.<name>`, about
1 min each). Run the block below once, at the end: `test_tui_sim` whole
takes about 35 min.

```sh
make && make sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_console_tee tests.test_sdk tests.test_sdk_package tests.test_source_layout
make -C UserSoftware/KonaCommander test
make -C UserSoftware/KonaEdit test
git diff --check
```

Record: `docs/validation/<date>-tui-fast-path.md`.
