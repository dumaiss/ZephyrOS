# 87 tui-fast-path progress

In-progress. Present-tense notes; not a report.

## Context (verified)

- libtui members built by `user/sdk/exe.mk` (`KOS_TUI_ASM_SRC`); two grids
  (85x26 default, 128x35 wide) share the same .asm sources, so asm needs the
  capacity stride at runtime. Plan: `uint8_t stride` appended to
  `struct tui_state` after `model_only`, set in `tui_reset_model`
  (offset 38; existing scroll offsets 0..37 unchanged).
- sdcccall(1): first two byte args in A, L; the rest on the stack
  (verified by compiling `f5`/`g4`/`s3` with sdcc 4.5 and reading the asm).
  Callee pops stack args (`pop hl; inc sp; jp (hl)` for N stacked bytes).
- `tui_scroll_rows` currently shifts the model via `tui_delete_line`/
  `tui_insert_line` under `model_only` (`tui_scroll.asm`); WORK.md wants a
  direct block move instead. The SCROLL record and return values stay.
- Dirty/invert maps are linear over cells (index>>3 byte, 1<<(index&7) bit).
- Attrs: 4 bits/cell, even cell in low nibble; stride 85 (odd) means rows
  alternate nibble parity; 128 is byte-aligned.
- `tui_priv_set_cell` is the only dirty/invert writer;
  `tui_clear_dirty`/`tui_dirty_all` in `tui_flush.c`; `tui_init` in
  `tui_lifecycle.c`.
- Tests to extend: `tests/tui/tui_test.c` modes, `tests/test_tui_sim.py`
  (TuiModeChecks runs modes on V9958 + serial lanes), `tests/test_tui.py`
  (TUI_MEMBERS set, TUI_FUNCTIONS set must gain `tui_put_text`).
- Budget table from WORK.md; on-overrun rules: stop and report.

## Plan (per WORK.md)

1. `tui_row_pending[TUI_MAX_ROWS]` in `tui_state.c`, declared in
   `tui_internal.h`; set by `tui_priv_set_cell` on every non-model_only
   store, by `tui_put_text` likewise; cleared by `tui_clear_dirty`,
   `tui_init` (reset_model); all set by `tui_dirty_all`; both flush
   passes skip a zero-flag row; after a successful render flush clear the
   walked rows' flags (rows < screen.rows).
2. `tui_text.asm` (new member): `tui_put_text`, cell-index/nibble computed
   once, per-cell loop mirrors C `tui_priv_set_cell` semantics incl. x+i
   uint8 wrap.
3. `tui_scroll.asm`: replace the delete/insert model step with
   LDIR/LDDR chars (capacity stride) + nibble-aware attr move (byte path
   for even stride, two parity cases for odd) + blank exposed row
   (spaces, `tui_state.attr`, screen width; no dirty/invert/pending).
4. Docs: `docs/tui.md`, `docs/sdk.md` member list.
5. Tests: new tui_test modes (puttext equivalence, shift grid, pending
   rows, timing), `tests/test_tui_sim.py` tests on both lanes, wide
   archive shift test; `tests/test_tui.py` member/function pins.
6. Requirement 4 (set_cell in asm, Should): decide after Must budgets are
   measured; skip if Musts pass and growth > 150 bytes.

## Done so far

- Read all referenced sources and the test infra.
- `tui_row_pending[TUI_MAX_ROWS]` (`tui_state.c` + `tui_internal.h`);
  set by `tui_priv_set_cell` on every non-model_only store and by
  `tui_put_text`; cleared by `tui_clear_dirty`, `tui_dirty_all`,
  `tui_reset_model`; both flush passes (`tui_flush_render`,
  `tui_flush_ansi`) skip zero-flag rows; walked rows cleared after a
  successful render flush.
- `tui_text.asm` (new archive member, ~540 bytes): `tui_put_text` with
  one loop mirroring `tui_priv_set_cell`; cell index/nibble parity/bit
  mask computed once, one `__mulint` per call, no IX/IY/exx. Sim
  debugging found and fixed: mask computed `(1|(idx&7))<<(idx&7)`
  instead of `1<<(idx&7)`; missing `pdone` reset at entry (must sit
  before `ld l,a` so the pending-pointer row survives); missing
  `window_x` in the base cell index; `y == h` boundary now returns.
- `tui_scroll.asm`: model step replaced with LDIR/LDDR chars move
  (capacity stride) + nibble-aware attribute move (byte path for even
  stride; both parities, partial tails, 16-bit counters and a height-1
  guard for odd); SCROLL record, flush and return values unchanged.
  Debugging found both odd-stride main loops placed the source nibbles
  in the wrong half-byte (src high must land in dst low); the partial
  tails and the first-byte specials were already correct.
- `tui_flush.c`: trailing STATE record stays unconditional. An attempt
  to omit it when cursor/attr/visible were unchanged was reverted: the
  V9958 driver advances its text cursor through TEXT spans, so the
  trailing STATE re-anchors the console cursor and six
  position-sensitive tests failed without it.
- Wide build (`TUI_GRID=128x35`) stays inside the exe budget: the
  `% 94` patterns in the shift test were rewritten as remainder loops;
  image+BSS ends at 0xDEF2, 270 bytes under the 0xE000 stack top.
- Docs: `tui.h` and `docs/tui.md` document `tui_put_text`.
- Tests: new modes in `tui_modes.c`/`tui_modes_stub.c` (puttext, shift,
  pending, timing) wired into `tui_test.c` and the Makefile;
  `tests/test_tui.py` pins `tui_put_text` and `tui_text.rel`;
  `tests/test_tui_sim.py` gains the four mode tests on both lanes
  (pending expects `[17]` on V9958: one span plus the trailing STATE).

## Current status

- Static suite (`tests/test_tui.py`): 29/29 pass (map-size pins moved to
  the 86-column stride).
- Targeted sim tests pass on V9958: shift, puttext, pending, timing,
  batch, windows, grid, gridsize (wide archive), invertspan,
  renderboundary, renderrows, invert, flush_counts (V9958 and SERIAL),
  screen, shutdown, widgets.
- The odd-stride attribute move was removed, not fixed: the layout now
  uses an even stride.  `TUI_STRIDE = (TUI_MAX_COLS + 1) & ~1` (86 for
  the 85-column build, 128 for the wide one) in `tui_internal.h`, used
  by `TUI_CELL_INDEX`/`TUI_CELL_COUNT` and `tui_state.stride`; the
  scroll's attribute move is one LDIR/LDDR of (height-1)*stride/2
  bytes, and `tui_put_text`'s nibble parity is the absolute column
  parity.  BSS grows by 45 bytes per 85-column program (chars +26,
  attrs +13, dirty/invert +3 each); wide programs are unchanged.
- SERIAL flush_counts test made robust: strips trailing shutdown/pass
  writes (15/20/21) instead of one fixed pop.

## Next

- Commit the package; record is in
  `docs/validation/2026-10-23-tui-fast-path.md`.  Reported overruns
  (flush-nothing 40.5k vs 8k, put_text equal 31.1k vs 12k, put_text
  new 71.7k vs 30k) are follow-up work; the budget assertions are not
  wired into the timing test.
