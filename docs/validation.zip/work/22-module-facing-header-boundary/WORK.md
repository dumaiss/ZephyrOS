# Module-Facing Header Boundary

## Task

Make the compile-time surface offered to ZMOD drivers match the driver ABI v2
architecture. Modules must see the types and callbacks they can use, but not
kernel registry transactions, IRQ-executive lifecycle controls, or raw memory
mode primitives. Preserve all accepted M8 behavior and binary interfaces.

This is a boundary-only post-M8 correction. It does not redesign the driver
model or reopen milestone acceptance.

## Problem and required design

`include/zephyros/driver.h` is the declared complete module service surface,
yet it includes `device.h` and `irq.h`, which also publish kernel-only registry
initialization, checkpoint/rollback and owner controls, IRQ registry lifecycle,
platform quiesce/test hooks, and `irq_arch_lock()`. `platform.h` likewise mixes
board constants with raw memory-latch/bank primitives, and module sources
include it even when they need no platform item. ZMOD unresolved-import checks
prevent most current misuse at pack time, and no current module imports these
kernel functions, but the headers do not let a worker reason locally about the
allowed API.

Keep public ABI types, device descriptors, class/capability values, class
interfaces, `irq_source_t`, and `irq_handler_t` in module-consumable headers.
Move kernel-only device registry lifecycle/storage declarations to a private
header owned by `kernel/device/`. Move IRQ registry lifecycle, checkpoint,
owner, dispatch diagnostics, platform quiesce, and interrupt-state locking to
one or more private headers owned by `kernel/irq/` (or the owning driver where
appropriate). Move raw memory-control function declarations out of the general
platform constant header into a kernel-private header owned by
`kernel/memory/`.

Update kernel includes explicitly. Remove unused `platform.h` includes from
module entry and device sources. Hardware-owning driver implementations may
include the narrow Zephyr-80 hardware constant header they require; this does
not authorize direct hardware access by non-owning drivers. Do not move
declarative board constants out of `platform/zephyr80/`.

Add a regression check that preprocesses or compiles a representative module
against only module-facing headers and proves that kernel registry
checkpoint/owner symbols, IRQ locks/platform hooks, and memory-control
functions are not declared. Retain the ZMOD unresolved-import whitelist as a
second line of enforcement.

## Constraints

- Do not change the layout or callback order of `zdriver_api`, device
  descriptors, class interfaces, frames, or IRQ handler signatures.
- Do not change exported ZMOD imports, module contents, register programming,
  or boot policy.
- Avoid cosmetic renaming and avoid a generic portability framework.
- `platform/zephyr80/` remains declarative; private kernel headers must not
  become a new implementation location.
- Production ZMODs and the production ROM are expected to remain
  byte-identical. If include-only changes alter bytes, stop and account for the
  difference before relying on existing hardware evidence.

## Validation

Run a clean `make check`, all focused source-layout/module tests, and every
module pack/validation target used by production. Run `git diff --check` and
compare the production image plus all four production ZMOD SHA-256 values with
the pre-change baseline recorded by the current validation report. Inspect the
packed modules to confirm no new unresolved kernel import was introduced.

## Acceptance criteria

- A module author can read `driver.h` and its class headers without seeing
  kernel-only mutation, owner, locking, quiesce, or banking declarations.
- Kernel subsystems include their private interfaces from explicit owning
  paths.
- Only hardware-owning driver sources include relevant board hardware
  constants; empty convenience includes are removed.
- ABI/layout assertions and module hashes are unchanged.
- Mechanical tests fail if the kernel-only declarations leak back into the
  module-facing include closure.

## Expected files

- `include/zephyros/{driver,device,irq,platform}.h`
- `kernel/{device,irq,memory}/`
- `drivers/`, `tests/`, `Makefile`
- focused interface documentation under `docs/`

