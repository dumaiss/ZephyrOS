> Worker package. After 102c01. `docs/snd-sdk.md` section 4.4 (SND-5): the
> tiny phrase notation, parsed and compiled in C into voice programs that
> 98's assembly engine plays. Plus the SDK examples, the link-size matrix,
> the timing benchmark and the closing docs. No OS change.

# Task

- **The phrase calls:** `snd_phrase_parse` (text to events, once) and
  `snd_phrase_compile`/`snd_phrase_start` (events and an instrument into
  a voice program, in a caller-owned buffer). `snd_phrase_stop` ends it.
- **Examples:** `snd-notes`, `snd-ztr-file`, `snd-ztr-kres` and
  `snd-zvg`, in the SDK.
- **Close out libsnd:** the link-size matrix, the timing benchmark and
  the acceptance matrix of section 10.1.

## Current state

- **98:** the voice-program format and engine, `snd_note_for`'s compiler.
- **100:** ZVG playback. **102:** ZTR playback.
- **The clients:** SNTracker and VGMPlayer are libsnd clients.
- **Example layout:** `user/sdk/examples/` holds hello, fardemo, fardata,
  files (each a directory with a Makefile, shipped in the SDK tarball by
  `tools/sdkpack.py`).

- **The authoring tools:** `UserSoftware/SNTracker/tools/` holds
  `csmc.py` (+ `csm_language.py`) and `fur2ztr.py` with their tests;
  their tests read `UserSoftware/SNTracker/songs/` (both songs' CSM,
  Furnace text and ZTR) and pass (27), but `make check` doesn't run
  them. `tests/test_snd_oracle.py` still reads the Zephyr-80 copies.

Read: `work/00-WORKER.md`; `docs/snd-sdk.md` 4.3-4.4, 8, 9, 10.1;
`docs/CSM-Language.md` (Source notation: the phrase subset follows it);
98's, 100's and 102's records; `user/sdk/examples/`.

## Requirements

1. **Parse (C)** (Must). `snd_phrase_parse(text, default_ticks, dst,
   capacity, &written)`:
   - **accepted:** space-separated `pitch`, `pitch@ticks`, `~` and
     `~@ticks`, with an optional `|` separator (no meaning);
   - **pitches:** lowercase `c d e f g a b`, an optional `#` or `b`, and
     an octave 0-7, so `c4` is note 48;
   - **refused, strictly** (`-KOS_EINVAL`, with the token's offset
     reported): unknown tokens, CSM syntax (`^ < > =`, braces,
     declarations), durations overflowing 16 bits, pitches out of range,
     and a full `dst`.
2. **Compile and play (C, then the engine)** (Must):
   - `snd_phrase_compile(voice, instrument, events, count, buf, size,
     &used)` writes the voice program, with each note's envelope as 98
     compiles a single note and rests as waits. `buf = NULL` reports the
     size needed;
   - `snd_phrase_start(voice, buf, used)` hands the program to the
     engine; `snd_phrase_stop(voice)` releases it;
   - the voice's ownership rules apply (98).

   The parser and the compiler are separate members: `snd_note_for`
   programs link neither.
3. **Split `sndtest` first** (Must). It is 13 bytes under its limit
   (image + BSS 56,947 of 56,960). Move the ZTR modes (`ztr`, `ztrstall`,
   `ztrpause`, `ztrload`, `ztrdump`, `ztrnotes`) to a new `ztrtest`
   program, with its own map and `SNTEST`-style test constant; `sndtest`
   keeps the manual and ZVG modes and gets `phrase`; `stress` goes in
   `ztrtest`. All existing tests pass unchanged in meaning. Report both
   programs' sizes.
4. **Examples** (Must). In `user/sdk/examples/`:
   - `snd-notes`: a chord, then a phrase, from the timer;
   - `snd-ztr-file`: a ZTR from `/fs` through stdio;
   - `snd-ztr-kres`: the same from a `.KPR` resource;
   - `snd-zvg`: a ZVG on a chosen chip.

   Each has a README and builds in the SDK tarball (`make sdk`, then
   each example from the unpacked tree, as `test_sdk_package` does for
   the others).
5. **Matrix and benchmark** (Must). In the record and in `docs/sdk.md`:
   - **link sizes:** code and data for manual-only, phrase,
     ZVG, ZTR from memory, and ZTR from KRES;
   - **timing:** `snd_tick` at 50 and 60 Hz, DIRECT and BATCH, for ZTR,
     ZVG and 12 manual voices; plus a ZTR playing while 95c03's
     128-glyph text rows draw in the foreground (the graphics and sound
     together, no underrun).
6. **Authoring tools in the SDK** (Must), section 9:
   - `test_snd_oracle` reads `UserSoftware/SNTracker/songs/` (no
     Zephyr-80 path left);
   - `make check` runs the tools' own tests (`test_csmc`,
     `test_fur2ztr`), all passing;
   - `tools/sdkpack.py` ships the three tools in `tools/snd/` and
     `CSM-Language.md`, `ZTR-Format.md` in `docs/`;
   - from the unpacked tarball, `csmc.py` compiles
     `RunawayCircuit.csm` and `fur2ztr.py` converts `night-market.txt`;
     both ZTRs pass libsnd's validator and play (`sndtest ztr`).
7. **Docs** (Must):
   - `docs/snd-sdk.md`: the status line reads implemented; section 4.4's
     notation and the compile; section 10.1 checked off, each item
     pointing at its test;
   - `docs/sdk.md`: the libsnd section complete.

## Tests

- **Host:** the parser on every legal form (sharps, flats, rests,
  durations, separators) and every refusal, with its offset; the
  compiled program for a known phrase.
- **Target:** `sndtest phrase`: a phrase's per-tick trace equals a
  Python reference built from the same events and envelope rules; two
  phrases on two voices at once; stop mid-phrase silences.
- **Link:** `snd-notes`'s map has no parser member when it only calls
  `snd_note_for`. (Add a variant build for the check if the example uses
  phrases.)
- **SDK package:** the four examples build from the tarball; the
  tarball's tools build both songs, which validate and play.
- **Together:** `ztrtest stress` plays a ZTR from the timer while drawing
  libgfx text rows in the foreground; no underrun or overrun across 600
  ticks.

## Budgets (CPU T-states, interrupts out)

| figure | now | target | on overrun |
|---|---|---|---|
| `snd_phrase_parse`, per token | - | report | - |
| a phrase tick (2 voices) | - | <= 1,500 | report with a profile |
| the stress run: underruns and overruns | - | 0 | report with a profile |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board: `snd-notes` plays its chord and phrase; `snd-ztr-file`
  and `snd-ztr-kres` play a song; `snd-zvg` plays on chip 2;
  `ztrtest stress` plays cleanly while text scrolls.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_snd tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-phrases.md`.
