# M0-M9 Work Pipeline

Role instructions:

- [`00-SUPERVISOR.md`](00-SUPERVISOR.md) — how to analyze requests, design
  work packages, delegate implementation, review results, and enforce gates.
- [`00-WORKER.md`](00-WORKER.md) — general implementation, validation,
  scope, shared-tree, hardware-evidence, and handoff rules for every worker.

Execute these worker contracts in order. A stage starts only after the previous
stage's diff and validation results have been reviewed and accepted. Each stage
must preserve all earlier acceptance criteria.

Dispatch exactly one `WORK.md` at a time and tell the worker its path. Do not
combine contracts into one pass: later contracts assume that the prior diff,
tests, and target behavior have already been reviewed.

1. [`01-m0-bringup/WORK.md`](01-m0-bringup/WORK.md) — create the build, boot
   image, startup path, early serial console, C kernel entry, panic path, and M0
   documentation.
2. [`02-m1-memory-banking/WORK.md`](02-m1-memory-banking/WORK.md) — make the
   mode `10`/`11` memory layout, common stack, section ownership, and banking
   primitives explicit and enforceable.
3. [`03-m1-syscall-gate/WORK.md`](03-m1-syscall-gate/WORK.md) — install the
   native `RST 30h` vector and implement a safe common-memory crossing into the
   bank-7 dispatcher.
4. [`04-m1-validation-acceptance/WORK.md`](04-m1-validation-acceptance/WORK.md)
   — harden map/image checks, add negative tests and physical serial-output
   validation, complete the documentation, and record physical-hardware
   acceptance evidence.
5. [`05-m2-interrupt-executive/WORK.md`](05-m2-interrupt-executive/WORK.md)
   — establish kernel-owned IM2, safe cross-mode IRQ entry, source ownership,
   IRQ stacks, and physical CTC0 validation.
6. [`06-m3-device-static-drivers/WORK.md`](06-m3-device-static-drivers/WORK.md)
   — add the fixed device registry, capability model, static SIO0/B driver,
   and normal console service.
7. [`07-m4-module-loader/WORK.md`](07-m4-module-loader/WORK.md)
   — reserve the driver arena and implement ZMOD tooling, relocation, loading,
   ownership, and failed-load rollback.
8. [`08-m4-dynamic-driver-acceptance/WORK.md`](08-m4-dynamic-driver-acceptance/WORK.md)
   — migrate SIO0/B to an embedded relocatable module and complete M4 target
   integration and acceptance.
9. [`09-source-tree-architecture-alignment/WORK.md`](09-source-tree-architecture-alignment/WORK.md)
   — move executable implementation out of the platform-description tree,
   align source ownership with architecture section 3, and prove all accepted
   ROM/module artifacts remain byte-identical.
10. [`10-production-test-driver-layout/WORK.md`](10-production-test-driver-layout/WORK.md)
    — separate production drivers from ZMOD packaging/runtime and milestone
    tests, retire the M3 static-driver boot path, and enforce the M4-era tree.
11. [`11-m5-rom-recovery-filesystem/WORK.md`](11-m5-rom-recovery-filesystem/WORK.md)
    — add safe runtime ROM access and ROMFS, expand the physical image, and
    source the production boot ZMOD from recovery storage.
12. [`12-m6-native-process-zex/WORK.md`](12-m6-native-process-zex/WORK.md)
    — define ZEX v1, single-tasking native process lifecycle, application-bank
    loading, useful console/exit syscalls, and parent restoration.
13. [`13-m7-native-monitor/WORK.md`](13-m7-native-monitor/WORK.md)
    — port the monitor as a native ZEX, add validated diagnostic syscalls, and
    establish the interactive recovery environment.
14. [`14-m8-driver-abi-arena/WORK.md`](14-m8-driver-abi-arena/WORK.md)
    — introduce driver ABI v2, class-aware discovery and console preference,
    and derive the production module arena from linked kernel size.
15. [`15-m8-ioc-command/WORK.md`](15-m8-ioc-command/WORK.md)
    — implement and physically accept the immutable-firmware IOC command/status
    lane as the first `ZDEV_IOC` surface.
16. [`16-m8-ioc-bulk/WORK.md`](16-m8-ioc-bulk/WORK.md)
    — add the timing-critical bulk read/write lane and strict READY/DONE state.
17. [`17-m8-hid/WORK.md`](17-m8-hid/WORK.md)
    — add IOC-discovered HID keyboard/text input and its bounded local queue.
18. [`18-m8-v9958-video/WORK.md`](18-m8-v9958-video/WORK.md)
    — add the direct V9958 VIDEO class, hardware-safe initialization and
    ROMFS-backed font atlas.
19. [`19-m8-v9958-console/WORK.md`](19-m8-v9958-console/WORK.md)
    — add V9958 terminal/character output and prove the unchanged monitor over
    split HID/V9958 console binding.
20. [`20-m8-integration-acceptance/WORK.md`](20-m8-integration-acceptance/WORK.md)
    — complete boot/fallback integration, full regression and physical M8
    acceptance.
21. [`21-public-ioc-client-contract/WORK.md`](21-public-ioc-client-contract/WORK.md)
    — replace HID's dependency on the IOC driver's private protocol header
    with an explicit client-visible IOC service contract.
22. [`22-module-facing-header-boundary/WORK.md`](22-module-facing-header-boundary/WORK.md)
    — separate the ZMOD-facing ABI surface from kernel registry, IRQ, and
    memory-control internals.
23. [`23-production-test-boundary/WORK.md`](23-production-test-boundary/WORK.md)
    — remove acceptance-only CTC control code and obsolete IRQ mapping code
    from the production kernel and enforce the separation.
24. [`24-current-docs-evidence-alignment/WORK.md`](24-current-docs-evidence-alignment/WORK.md)
    — reconcile authoritative M8 documentation and make referenced validation
    evidence durable in the repository.
25. [`25-m9-vfs-bootstrap-romfs/WORK.md`](25-m9-vfs-bootstrap-romfs/WORK.md)
    — kernel VFS core, generated/validated mount table, ROMFS as the static
    system provider at `/SYSTEM`, and VFS-path boot module/monitor loading.
    Correction: [`25-m9-vfs-bootstrap-romfs/correction-01/WORK.md`](25-m9-vfs-bootstrap-romfs/correction-01/WORK.md)
    — keep VFS/ROMFS-provider objects out of `ZOS_ROMFS_BOOT=0` images.
    Correction: [`25-m9-vfs-bootstrap-romfs/correction-02/WORK.md`](25-m9-vfs-bootstrap-romfs/correction-02/WORK.md)
    — path-based provider ABI rework, flat mount selection, single ROMFS
    lookup (architecture trim of 2026-10-04).
25a. [`25a-retire-pre-m8-acceptance/WORK.md`](25a-retire-pre-m8-acceptance/WORK.md)
    — apply the Mn-1 retention rule: retire M1-M7 images, flags, hooks,
    smoke modes and legacy geometry; move mechanism coverage onto the
    current boot path by subsystem.
25b. [`25b-m9-bank7-budget/WORK.md`](25b-m9-bank7-budget/WORK.md)
    — size-optimized kernel/module compile, derived bank-7 data base, and
    the `bank7:` budget ledger.
    Correction: [`25b-m9-bank7-budget/correction-01/WORK.md`](25b-m9-bank7-budget/correction-01/WORK.md)
    — trim V9958 font staging to reach 9 granules; make missing derived
    geometry keys fail loudly.
26. [`26-m9-provider-abi-cache/WORK.md`](26-m9-provider-abi-cache/WORK.md)
    — driver ABI v3 provider registration, normal mount phase, kernel
    file/dir mutation API, root merge, test ramfs (no VFS cache).
27. [`27-m9-fs-syscalls/WORK.md`](27-m9-fs-syscalls/WORK.md)
    — global descriptor pool, CWD pool, pinned `FS_*` syscalls, staging
    buffer, runtime wrappers and the first `fstest.zex`.
    Correction: [`27-m9-fs-syscalls/correction-01/WORK.md`](27-m9-fs-syscalls/correction-01/WORK.md)
    — one 512-byte VFS workspace replaces six path buffers + staging;
    fix the package-27 ledger record.
28. [`28-m9-nested-exec/WORK.md`](28-m9-nested-exec/WORK.md)
    — `SYS_EXEC` as a thin composition of the existing process machinery:
    prepare-then-launch, shallow suspension point, continuation stack for the
    shared gate stack, depth 4, budgeted at about 1 KB code.
    Also: banner-only production smoke contract, `zex-test` prerequisite,
    parallel builds by default.
    Correction: [`28-m9-nested-exec/correction-01/WORK.md`](28-m9-nested-exec/correction-01/WORK.md)
    — move the exec path buffer out of common memory; correct the
    "unreachable" claim; add common-memory usage to the ledger.
28b. [`28b-m9-shell-readiness/WORK.md`](28b-m9-shell-readiness/WORK.md)
    — `SYS_EXEC` argument passing (startup block at 0080h), the
    `ZOS_BOOT_PROGRAM` setting, and the M10/M12 scope decisions, so the
    shell needs no kernel work.
28c. [`28c-m9-user-sdk/WORK.md`](28c-m9-user-sdk/WORK.md)
    — public native ABI headers (`abi/zos/`, one source of truth), the user
    SDK (`libzos`, crt0, `zlibc`, generic `zex_program` rule), all ZEX ported
    onto it, and the `user/helloworld/` demo project with `hello.zex`.
    `user/ZShell/` (M10) builds only from this SDK.
29. [`29-m9-block-class-sd/WORK.md`](29-m9-block-class-sd/WORK.md)
    — rename to `ZDEV_BLOCK` and publish the block class contract only (no
    driver until a consumer exists).
30. [`30-m9-iocfat-provider/WORK.md`](30-m9-iocfat-provider/WORK.md)
    — `iocfat.zmod` path-based FS2 provider with its own write-through
    file-data cache, mounted as optional writable `/`.
    Correction: [`30-m9-iocfat-provider/correction-01/WORK.md`](30-m9-iocfat-provider/correction-01/WORK.md)
    — trim IOC-FAT from 15 to at most 13 granules (keep the one-slot cache),
    slack target lowered to 1 KiB, then complete the withheld integration.
30b. [`30b-m9-reclaim-audit/WORK.md`](30b-m9-reclaim-audit/WORK.md)
    — measurement-only bank-7/common reclaim audit: permanent granule-
    threshold ledger, ranked A/B/C findings with granule effects, `iocfat`
    12/11-granule analysis, common-ceiling proposal, M10 residency estimate.
30c. [`30c-m9-reclaim/WORK.md`](30c-m9-reclaim/WORK.md)
    — implement the owner-selected 30b findings and pin the common ceiling.
    The supervisor fills in its selection after reviewing 30b.
31. [`31-m9-integration-acceptance/WORK.md`](31-m9-integration-acceptance/WORK.md)
    — full section 33 matrix, physical acceptance, documentation and
    durable validation record.

Packages 14-20 use [`M8-REFERENCE.md`](M8-REFERENCE.md), which pins the
read-only Zephyr-80 implementation references and the deployed IOC/V9958
hardware contracts. The IOC firmware is never a work target.

Packages 21-24 are post-M8 architecture-conformance corrections. M1-M8 remain
closed and accepted; these packages preserve the accepted runtime behavior and
are dispatched in order, one at a time, with the validation required by each
contract.

Packages 25-31 implement M9 and use [`M9-REFERENCE.md`](M9-REFERENCE.md),
which pins the shared ABI values (errors, syscall numbers, structures, driver
ABI v3), cache/budget/gate-stack rules and the deployed FS2/volume-unit
firmware facts. Do not dispatch package 25 until packages 21-24 are reviewed,
accepted and committed. Each M9 package that changes production bytes carries
its own hardware gate; do not begin the next package until that gate is
recorded as passed or the supervisor explicitly accepts it as `PENDING`
with the dependency risk stated. After package 26, stop at the bank-7 budget
checkpoint in `M9-REFERENCE.md`; package 27 needs an explicit continuation
decision based on the measured ledger.
The post-26 checkpoint passed on 2026-10-05 (continue, with budget measures).
The post-28 checkpoint passed on 2026-10-05: IOC-FAT cache fixed at 1 slot, and
package 30 must measure the gate-stack depth through IOC-FAT first.

Stages 11-20 are strict milestone gates. Do not dispatch stage 11 until the
pending stage-10 physical smoke matrix is complete; do not dispatch stage 12
or 13 until the preceding milestone has been reviewed and physically accepted.
For M8, dispatch exactly one package at a time and do not begin 15-20 until the
preceding package's diff, full stated validation, and required physical gate
have been reviewed and accepted. Writing the complete pipeline in advance does
not waive any stage gate.

The boot-ROM layout for M0/M1 is deliberately simple: a 128 KiB image containing
ROM page 0 (copied to SRAM bank 0) and ROM page 1 (copied to SRAM bank 7). ROM
page numbering is independent of SRAM bank identity. This compact format does
not change the architectural requirement that mode `11` maps SRAM bank 7 at
`2000h-DFFFh`. Stage 11 preserves those two boot pages and expands the programmed
image to eight pages, with ROMFS assigned to pages 2-7.

The adjacent Zephyr-80 sources are read-only references, not dependencies of
this repository. In particular, consult:

- `/home/kitamura/Documents/Zephyr-80/Memory Management.md`
- `/home/kitamura/Documents/Zephyr-80/Code/HOST/CPM2.2/src/layout/platform.inc`
- `/home/kitamura/Documents/Zephyr-80/Code/HOST/CPM2.2/src/common/rom_copy.asm`
- `/home/kitamura/Documents/Zephyr-80/Code/HOST/CPM2.2/src/common/sio.asm`

Do not copy CP/M policy or interfaces into ZephyrOS. Those files are useful only
for verified board constants, reset mechanics, and SIO programming sequences.

## M10 — Resident-service nucleus, extended memory, far code/data, ZEX v2

**Target:** `docs/architecture.md` sections 35-37, the only M10 target
(rewritten 2026-10-07 from the package 33-36 evaluations). Shared
decisions, the list of rejected options, budget and reuse rules:
[`M10-REFERENCE.md`](M10-REFERENCE.md). Implementation follows the stage
order of architecture 36.24.

**Evaluation packages (closed; history, not guidance).** Packages 32-36
measured options. Where their work orders or reports differ from
architecture 35-37 (the slot overlay, the `8000h` split, `SYS_FAR_CALL`
with a low window, the bank-7 arena), the architecture wins.

32. [`32-m10-retire-m8-acceptance/WORK.md`](32-m10-retire-m8-acceptance/WORK.md)
    — Mn-1 retention at the start of M10 (M8 images and tests retired).
33. [`33-m10-design-spike/WORK.md`](33-m10-design-spike/WORK.md)
    — design spike: M10 did not fit the end-of-M9 bank-7 residency.
34. [`34-m10-rev13-window-evaluation/WORK.md`](34-m10-rev13-window-evaluation/WORK.md)
    — decoder revision 13 (the mode-11 window) and the window measurements.
35. [`35-m10-resident-service-spike/WORK.md`](35-m10-resident-service-spike/WORK.md)
    — the resident-service IPC substrate; claims C1-C9 confirmed on the
    window.
36. [`36-m10-two-bank-feasibility/WORK.md`](36-m10-two-bank-feasibility/WORK.md)
    (+ [`correction-01`](36-m10-two-bank-feasibility/correction-01/WORK.md))
    — the two-bank fit at the `6000h` split.

**Implementation packages:**

37. [`37-m10-rev13-baseline-cleanup/WORK.md`](37-m10-rev13-baseline-cleanup/WORK.md)
    — stage 1: decoder revision 13 (the `6000h` window plus the mode-10
    aperture, programmed on the board) becomes the single decoder design
    and the simulator default, and the machinery of every rejected option
    is removed (transport B, the evaluation decoders and the package-34
    evaluation, the package-33 `ZOS_M10_SPIKE`). The production image is
    byte-identical. **Accepted 2026-10-07.**
38. [`38-m10-nucleus-layout/WORK.md`](38-m10-nucleus-layout/WORK.md)
    — stage 2: the nucleus links as a fixed core (`2000h-5FFFh`) plus a cold
    half (`6000h-DFFFh`), with the residency classification enforced by
    mapcheck. The syscall and IRQ gates normalize P and restore the latch
    exactly. Adds the upcall shim and the five M10 ledgers, which replace
    the M9 bank-7 budget. No behaviour change. **Accepted 2026-10-08.**
39. [`39-m10-ipc-substrate/WORK.md`](39-m10-ipc-substrate/WORK.md)
    — stage 3: the IPC substrate is promoted from the spike into the
    nucleus, test images only (production adopts it in 41), with
    `SYS_IPC_LOOKUP`/`CALL` and service-owned IRQs. The spike is retired.
    [`correction-01`](39-m10-ipc-substrate/correction-01/WORK.md): copy
    paths for every caller-buffer location (caller window, aperture copy
    with service buffers in bank 6 `8000h-BFFFh`, gate/bounce fallback).
    **Accepted 2026-10-08.**
40. [`40-m10-service-images/WORK.md`](40-m10-service-images/WORK.md)
    — stage 4a: the service-image format (ZMOD + service metadata,
    `SERVICE_IO`), the loader into bank 6's two tiers, the boot manifest,
    and the bootstrap interface. Test images only; bank 6 leaves the
    application pool.
    **Accepted 2026-10-08.**
41. [`41-m10-driver-services/WORK.md`](41-m10-driver-services/WORK.md)
    — stage 4b: SIO, HID, IOC, V9958 and the console become bank-6
    services. Production switches to the substrate and the loader (the
    loader is slimmed first), the console syscalls are retired, and the
    early console and panic path stay in the nucleus.
    [`correction-01`](41-m10-driver-services/correction-01/WORK.md): close
    the package: `make check` green (retired tests deleted), the SDK
    low-window rule, `ipc-selftest` placement, the IOC/HID images finished,
    fresh stack figures and the validation record.
    **Accepted 2026-10-08** (hardware pending, owner).
41b. [`41b-m10-service-slimming/WORK.md`](41b-m10-service-slimming/WORK.md)
    — step 5, host assembly: drivers host-linked at their final addresses
    (the loader becomes a copier), endpoints and inter-driver dependencies
    host-resolved, validation in the nucleus only, near-direct
    driver-to-driver calls, ledgers renamed to `driver`. **Accepted
    2026-10-09** (hardware pending, owner).

**Remaining M10 packages (run in order 42a, 42b, 42c, 42e, 42d, 43, 44a, 44b, 45; each checks its predecessor's record before starting and stops on a contradiction):**

42a. [`42a-m10-namespace-handles`](42a-m10-namespace-handles/WORK.md) — the VFS root router; the DEVICE (`/dev`, host publication table) and ROMFS (`/SYSTEM`) providers; bind/call/unbind with 8-bit types; one handle table; `ns_enum`; standard console handles; lookup removed. [`correction-01`](42a-m10-namespace-handles/correction-01/WORK.md): test image only, production unchanged; switch-over in 42b. **Accepted 2026-10-09.**
42b. [`42b-m10-files-on-handles`](42b-m10-files-on-handles/WORK.md) — the FS provider routes `/FS` to IOC-FAT as a bank-6 driver; `fs.h` over bind/call/unbind; the filesystem-namespace protocol; provider-validated `chdir`; exec binds FILE; `FS_*` retired; paths move to `/FS`; **production switch-over**, deleting the arena, `fs`, the M9 VFS machinery and the registry. [`correction-01`](42b-m10-files-on-handles/correction-01/WORK.md) (after 42b): retire all M9 acceptance machinery and add one new `fs-selftest` outcome image. **Both accepted 2026-10-09** (hardware pending, owner).
42c. [`42c-m10-prune-nucleus`](42c-m10-prune-nucleus/WORK.md) — pure deletion: `zdriver_api`, the device model, ops tables, runtime versions, transitional tiers, a ZMOD reduced to plain driver images, the loader's flat load plan, verification of 42b's deletions. **Accepted 2026-10-10** (hardware pending, owner).
42e. [`42e-m10-console-builds`](42e-m10-console-builds/WORK.md) — consoles selected per build (`console-v9958-hid`, `console-serial`), runtime fallback removed, an ESC `c` test program for the board. Runs after 42c, before 42d. **Accepted 2026-10-10** (hardware pending, owner).
42d. [`42d-m10-scaffolding`](42d-m10-scaffolding/WORK.md) — one replay helper, a table-driven image matrix, tools without retired rules, as-built docs; production byte-identical. **Accepted 2026-10-10.**
43. [`43-m10-xmem-aperture`](43-m10-xmem-aperture/WORK.md) — bank map, xmem objects, map tokens with addresses, the aperture, buffer identity. **Accepted 2026-10-11** (hardware pending, owner).
44a. [`44a-m10-zex-v2`](44a-m10-zex-v2/WORK.md) — v2 replaces v1, data segments, BSS-only zeroing, programs converted. **Accepted 2026-10-11** (hardware pending, owner).
44b. [`44b-m10-far-code`](44b-m10-far-code/WORK.md) — far-code segments through the aperture, SDK/linker support, demo. **Accepted 2026-10-11** (hardware pending, owner).
45. [`45-m10-acceptance`](45-m10-acceptance/WORK.md) — section 37 coverage map, final ledgers, hardware checklist, documents, Mn-1 list. **Accepted 2026-10-11. M10 COMPLETE; hardware sign-off done 2026-10-12.**

45b. [`45b-m10-hardware-acceptance/WORK.md`](45b-m10-hardware-acceptance/WORK.md) — **ready:** a feature exerciser in the **production** image: `/SYSTEM/hwtest.zex` runs xmem with far code, files (writes confined to `/FS/HWTEST`), namespace and handles against the real devices, and nested exec; started from the monitor's new `X <path>` command. ipc and subsystem stay separate. [`correction-01`](45b-m10-hardware-acceptance/correction-01/WORK.md) (after 45b): **run programs from `/FS`**, an M10 regression where exec stages its path in the cold half (architecture 36.5 buffer rule); audit and guard the same class of bug. **45b and correction 01 accepted 2026-10-12; hwtest passes on hardware, with and without a card.**
46. [`46-m10-surfaces/WORK.md`](46-m10-surfaces/WORK.md) — a refactoring only, in six steps with every move and rename pinned in [`TABLES.md`](46-m10-surfaces/TABLES.md): tree moves, driver vocabulary, headers by audience, the VFS split, lowercase roots, short SDK names. **Accepted 2026-10-12** (production `c4b407ee…`, ledgers unchanged, `putchar` +15 bytes owner-approved).
47. [`47-m10-docs-first-version/WORK.md`](47-m10-docs-first-version/WORK.md) — **done (2026-10-12, supervisor), awaiting owner review; record [`2026-10-12-m10-docs-first-version.md`](../docs/validation/2026-10-12-m10-docs-first-version.md); found two 49d breaks (store list vs test_hid/test_v9958; ROMFS replay no longer fits the subsystem image):** all documentation rewritten as the first version of KonaOS (by subsystem, glossary, roadmap, one entry point per audience), plus no build history anywhere in the tree (package and milestone numbers out of code, tests, tools and JSON); inputs in [`inputs.md`](47-m10-docs-first-version/inputs.md).
48. [`48-konaos-rename/WORK.md`](48-konaos-rename/WORK.md) — the KonaOS rename: product name, `zos`→`kos`, ZEX→EXE (`KEX2`), ZMOD→MOD (`KMOD`), `K` protocol families. **Accepted 2026-10-12** (production `8a4f4067…`; SDCC rejects `.exe` in any argument, so the boot path goes through a generated header).
49a. [`49a-systemgen`](49a-systemgen/WORK.md) — one `systems/<image>.json` per image plus `tools/systemgen.py` (`system.mk`, the store manifest, `drivers.man`, resolved driver-manifest copies for `modpack`); symbolic `depends`; canonical store order; ROMFS magic `KRFS`. **Accepted 2026-10-12** (final decisions in its record, section 1).
49b. [`49b-banked-calls`](49b-banked-calls/WORK.md) — `__banked` far calls as plain C through the SDK `___sdcc_bcall_ehl` trampoline (68 bytes, 310 T-states cached; linked only when used); `FAR1=`…`FAR4=`; several far areas at `8000h`; `farcall` stays. **Accepted 2026-10-12.** [`correction-01`](49b-banked-calls/correction-01/WORK.md) (after 49c): the token-cache test failed (stale pass in 49b; segment 1 maps once more than explained); the extra call was `xmem_child`'s probe (an image-wide counter); the trampoline is clean (2 fills for 22 entries); the test now attributes all 10 calls by caller. **Accepted 2026-10-12.**
49c. [`49c-sdk-package`](49c-sdk-package/WORK.md) — `make sdk` → `kos-sdk-0.1.0/` (37 files, reproducible tarball), `mk/kos.mk` shared with the tree, `tools/ihx.py`, examples `hello`/`fardemo`/`files`; the out-of-tree build-and-run and the ABI refusal are tested in `make check`. **Accepted 2026-10-12.**
49d. [`49d-far-data`](49d-far-data/WORK.md) — far data from C: `DATA1=`…`DATA4=` (const + zeroed at `8000h`, mappable rows at slot 4), `BLOBS=`, generated rows, `farmap`/`farunmap`/`blob`/`xload`, `ENOSPC` for bank exhaustion. **Accepted 2026-10-12.** [`correction-01`](49d-far-data/correction-01/WORK.md): fix `test_romfs_sim`'s scratch placement (a test assumption; the image is fine), and remove the far-data test files from production (they move to the `fs` test image).

**M11: native shell, then M12: diagnostics** (owner decision 2026-10-12:
the shell comes first, so the diagnostics run from it). Before them: 48 (KonaOS), 49a-d (systemgen,
`__banked`, the SDK, far data), then 47 (docs).

50. [`50-m11-shell-core`](50-m11-shell-core/WORK.md) — **done (2026-10-13), accepted; record [`2026-10-12-m11-shell-core.md`](../docs/validation/2026-10-12-m11-shell-core.md).**
    `shell.exe` as an ordinary application (in no store, ROM unchanged,
    replayed from the emulated card): the loop, one shared splitter (single and double
    quotes, backslash; crt0 uses it too), tail serialization with a round
    trip, `/fs` shown as `/` and `//` for the VFS root, the command path,
    `cd pwd echo path help exit`.
51. [`51-m11-shell-commands`](51-m11-shell-commands/WORK.md) — **done (2026-10-13), accepted; record [`2026-10-12-m11-shell-commands.md`](../docs/validation/2026-10-12-m11-shell-commands.md).**
    `ls cat stat cp mv rm mkdir rmdir`, with one 512-byte buffer; far code
    only if the shell exceeds 24 KiB. Still card-only, no OS change.
51b. [`51b-m11-device-release-reboot`](51b-m11-device-release-reboot/WORK.md) — **done (2026-10-13), accepted; record [`2026-10-13-m11-device-release-reboot.md`](../docs/validation/2026-10-13-m11-device-release-reboot.md); hardware checklist passed (owner, 2026-10-13);** release notification to drivers (`KOS_OP_RELEASE`, endpoint flag), exclusive device binds (`KOS_BIND_EXCLUSIVE`, `KOS_OP_ACQUIRE`), V9958 restore on release, `KVIDEO_OP_RESET`/`KCONSOLE_OP_RESET` (the launcher resets the console before every start), warm reboot (`SYS_REBOOT` 0Ch: latch 00h, `JP 0`; boot inits audited for "any state"; shell `reboot`, monitor `B`; Ctrl-Alt-Esc is the controller's hard reset).
52. [`52-m11-shell-boot`](52-m11-shell-boot/WORK.md) — **done (2026-10-13), accepted; record [`2026-10-13-m11-shell-boot.md`](../docs/validation/2026-10-13-m11-shell-boot.md); hardware checklist passed on both console builds (owner, 2026-10-13); the console-integration image no longer fits its cold half: retired in 56, not fixed;**
    the shell enters the store and production boots it; launcher policy with `KOS_BOOT_AFTER_EXIT`
    (test images end at the monitor, not in a loop); monitor fallback;
    hardware checklist. Ends M11.
53. [`53-m12-timer`](53-m12-timer/WORK.md) — **done (2026-10-14), accepted with corrections 01-03:** syscall bodies run with the caller's interrupt state (01); CTC2 timer-mode control word, model honours D6, bounded waits, `hwtest` rate probe (02); CTC ports by physical channel (CS0/CS1 swapped on the board), IRQ counters in monitor `R` (03). Record [`2026-10-13-m12-timer.md`](../docs/validation/2026-10-13-m12-timer.md); board: `hwtest` 4/4 PASS, `irq: unexpected 0`, card copy and 60 s run match a stopwatch.
53b. [`53b-m12-device-events`](53b-m12-device-events/WORK.md) — **done (2026-10-15, finished by the supervisor), accepted:** device events (`NOTIFY`, signal-style delivery while the subscriber runs); the event timer redesigned on the clock (channel 3 loads only the final stretch); `EVENT_RETURN` masked; every IFF2 read repeated (the board's Z84C0020 shows the `LD A,I` behaviour); `beat` with `run`/`ls`/`reboot`. Record [`2026-10-14-m12-device-events.md`](../docs/validation/2026-10-14-m12-device-events.md); board: `beat`, `beat ls`, `beat reboot` ×5, `hwtest` 4/4. [`correction-01`](53b-m12-device-events/correction-01/WORK.md) open: split the subsystem image (no longer links).
54. [`54-m12-diag-core`](54-m12-diag-core/WORK.md) — **draft:**
    `/system/diag.exe` in 4 far segments, PASS/FAIL/SKIP, `diag system`
    and `diag memory`, and `SYS_DIAG_ENUM` (2Eh, values only, cold half,
    no fixed-core change).
55. [`55-m12-diag-devices`](55-m12-diag-devices/WORK.md) — **draft (when dispatched: fold 56's `iobench` rows into `diag`):**
    timer, irq (delivery via the timer), serial, video, hid, ioc, storage,
    sound; **benchmarks:** SD write and read, bulk lane (same sector) and
    command lane (PING round trip); `diag all` is never destructive. Ends
    native completion.
56. [`56-m13-sdk-buffered-io`](56-m13-sdk-buffered-io/WORK.md) — **done (2026-10-15), accepted; record [`2026-10-15-m13-sdk-buffered-io.md`](../docs/validation/2026-10-15-m13-sdk-buffered-io.md); board `iobench`: file rows match the simulator, console draws ~1,800 chars/s:**
    retire the console-integration image (its in-nucleus device
    diagnostics; `diag` covers the devices), the 49d correction 01 (ROMFS-replay scratch; far-data files out of
    production into the `fs` image), `diag bench` rows measuring the IPC
    cost a program feels, then line-buffered console output
    (`console_flush`) and ISO buffered file streams in the SDK; measured
    before and after.
57. [`57-m13-read-path`](57-m13-read-path/WORK.md) — **done (2026-10-16), accepted as a simulator measurement:** the board phase image broke bulk transfers (stamp overrun) and was abandoned; the simulator (instruction costs fixed in this package) attributes ~31.6 of 47.4 ms per 512-byte read to the IOC-FAT staging copy (a C byte loop, ~290 T/byte). Record [`2026-10-16-m13-read-path-measure.md`](../docs/validation/2026-10-16-m13-read-path-measure.md).
58. [`58-m13-read-path-fix`](58-m13-read-path-fix/WORK.md) — **done (2026-10-16, supervisor), awaiting owner acceptance; record [`2026-10-16-m13-read-path-fix.md`](../docs/validation/2026-10-16-m13-read-path-fix.md):** direct bulk form (no staging copy) and an `LDIR` block copy for every driver copy loop; 512-byte miss 50.8 → 20.3 ms (simulator), board SDBENCH 21.7 KiB/s at 512 B (was ~10), 23.2 at 4 KiB; hwtest, fs_selftest, timer card, vgmplay pass. The remaining gap to CP/M (~39 KiB/s) is the per-block command exchange (three IPC calls) and the caller copy.
59. [`59-m13-read-path-host`](59-m13-read-path-host/WORK.md) — **done (2026-10-16, supervisor), make check green, final image passes on the board; record [`2026-10-16-m13-read-path-host.md`](../docs/validation/2026-10-16-m13-read-path-host.md):** assembly command CRC, reads copied straight from the cache, every driver's `DRIVER_IO` in an io segment (8000h-BFFFh, now enforced by the packer), nucleus path A over the whole hot tier (fixes a card-exec corruption), one-stream bulk receive, simulator lane on the firmware's schedule; board SDBENCH 512 B 29.2 KiB/s (was 21.7).
60. [`60-m13-read-ahead-cache`](60-m13-read-ahead-cache/WORK.md) — **done (2026-10-16, supervisor), make check green, board pending; record [`2026-10-16-m13-read-ahead-cache.md`](../docs/validation/2026-10-16-m13-read-ahead-cache.md):** unrolled-`LDI` copy primitives, `bulk_write`, a 16 KiB block cache in bank 6's bulk tier with a 4-block read-ahead ring and one copy per run; the pipelined fill is not achievable without a firmware change (the reply is unsolicited into a 3-byte FIFO) and is recorded as such.
61. [`61-m13-transport-asm`](61-m13-transport-asm/WORK.md) — **done (2026-10-16, supervisor), make check green, board passes; record [`2026-10-16-m13-transport-asm.md`](../docs/validation/2026-10-16-m13-transport-asm.md):** the command exchange in assembly, no copy layers on the command path, one IOC call per block (`KIOC_OP_COMMAND_READ`), a 16-bit read loop; board SDBENCH 512 B 31.2 KiB/s (15.95 ms), 4 KiB 35.6 KiB/s.
62. [`62-m13-nucleus-call-path`](62-m13-nucleus-call-path/WORK.md) — **closed early (2026-10-16, supervisor; owner's decision), validated with 63; record [`2026-10-16-m13-nucleus-call-path.md`](../docs/validation/2026-10-16-m13-nucleus-call-path.md):** endpoint slot map, per-number handle memo, event-exit pending hint, copy paths classified per descriptor, syscall frames in place; board 512 B 15.82 ms (was 15.95), target 13.5 not reached.
63. [`63-m13-sdk-hot-paths`](63-m13-sdk-hot-paths/WORK.md) — **done (2026-10-16, supervisor); record [`2026-10-16-m13-sdk-hot-paths.md`](../docs/validation/2026-10-16-m13-sdk-hot-paths.md):** 16-bit division, `__mulint`, digit conversion and the klibc string/memory routines in assembly, `timer_now` by bytes; user-mode profile 385 → 294 ms, `__moduint` ~3,400 → ~51 T; board read path unchanged (as expected), hwtest and fs_selftest pass.
64. [`64-m13-read-run`](64-m13-read-run/WORK.md) — **done (2026-10-17, supervisor; KonaOS and IOC firmware), board passes, SDBENCH 512 B 50.8 KiB/s and 4 KiB 61.9 KiB/s (were 31.6 and 35.4); record [`2026-10-17-m13-read-run.md`](../docs/validation/2026-10-17-m13-read-run.md):** file runs of 4 blocks per IOC command (`FS2_READ_RUN`, the added firmware command in [`FIRMWARE.md`](64-m13-read-run/FIRMWARE.md)), block-by-block on firmware without it; the file records and the packet loop in assembly for room; a copy no longer re-reads the ring after every write.
65. [`65-m13-sound-driver`](65-m13-sound-driver/WORK.md) — **done (2026-10-18, worker), accepted; record [`2026-10-18-m13-sound-driver.md`](../docs/validation/2026-10-18-m13-sound-driver.md):** `/dev/sound` for the Afternoon Blend card (442-byte hot segment, 67 io): one reset routine, `KSOUND_OP_INFO`, batched `KSOUND_OP_WRITE` validated before any `OUT`, exclusive direct I/O; `beat.exe` moved off diagnostic I/O; the driver tier's reserve is 3,584 bytes (3,588 free). VGMPlayer and SNTracker use the driver and play correctly on the board.

## TUI SDK — staged user-space implementation

**Target:** [`docs/konaos-tui-sdk-architecture.md`](../docs/konaos-tui-sdk-architecture.md).
Shared implementation decisions, exact key vocabulary, return conventions,
library layout, clipping, styles, widgets, and evidence rules are pinned in
[`TUI-REFERENCE.md`](TUI-REFERENCE.md).

Dispatch exactly one package at a time, in order. Review and accept its diff
and validation record before starting the next package. Packages 66-70 are the
first useful core milestone; 71 adds overlay storage, 72 adds the optional
widget library, and 73 is the clean integration and physical acceptance gate.

66. [`66-tui-sdk-foundation`](66-tui-sdk-foundation/WORK.md) — **done
    (2026-10-18), accepted; record
    [`2026-10-18-tui-sdk-foundation.md`](../docs/validation/2026-10-18-tui-sdk-foundation.md):**
    public `tui.h`, separate deterministic `libtui`, generic `LIBS=` program
    linkage, standalone-package integration, lifecycle, and the fixed queried
    geometry; independently replayed on V9958/HID and serial consoles.
67. [`67-tui-screen-engine`](67-tui-screen-engine/WORK.md) — **done
    (2026-10-18), accepted after
    [`correction-01`](67-tui-screen-engine/correction-01/WORK.md); record
    [`2026-10-18-tui-screen-engine.md`](../docs/validation/2026-10-18-tui-screen-engine.md):**
    one logical cell map plus dirty bitmap, cursor/text/formatting,
    transactions, horizontal-run output batching, and shutdown-flushed dirty
    output validated on serial and V9958/HID.
68. [`68-tui-windows-clear`](68-tui-windows-clear/WORK.md) — **done
    (2026-10-18), accepted; record
    [`2026-10-18-tui-windows-clear.md`](../docs/validation/2026-10-18-tui-windows-clear.md):**
    absolute window regions, relative clipping, bounded nesting, clear, and
    in-window insert/delete line.
69. [`69-tui-key-decoder`](69-tui-key-decoder/WORK.md) — **done
    (2026-10-18), accepted after
    [`correction-01`](69-tui-key-decoder/correction-01/WORK.md); physical
    hardware pending for package 73:** the IOC's complete VT100 vocabulary,
    standalone ESC, nonblocking/blocking reads, malformed-input replay, and
    lifecycle-clean parser state, validated on both simulator routes.
70. [`70-tui-styles-primitives`](70-tui-styles-primitives/WORK.md) — **done
    (2026-10-18), accepted after
    [`correction-01`](70-tui-styles-primitives/correction-01/WORK.md):**
    semantic normal/reverse styles and clipped CP850 fill/line/frame/title
    primitives, with terminal and glyph knowledge confined to `libtui` and
    zero-area titled frames preserved as no-ops.
71. [`71-tui-save-restore`](71-tui-save-restore/WORK.md) — **implemented,
    accepted (2026-10-18):**
    caller-buffered clipped cell regions and exact dirty restore for overlays.
72. [`72-tui-widgets`](72-tui-widgets/WORK.md) — **implemented and accepted
    (2026-10-18):** separate
    `libtui_widgets`, procedural controls, keyboard interaction, menus and
    modal dialogs built only on the public core API.
73. [`73-tui-examples-acceptance`](73-tui-examples-acceptance/WORK.md) —
    **correction 02 active (2026-10-19); correction 01 accepted:** public
    guide, three standalone examples, SDK 0.2.0, scoped user-SDK/TUI forced
    rebuild and out-of-tree/simulator regression, size/write-count evidence,
    and tracked reproducible packaging. A physical run found that
    `tui_dialog` rejects valid menu ID 11 because it embeds the simulator's
    ID-10 oracle; fix only the example/tests/guidance under
    [`correction-02`](73-tui-examples-acceptance/correction-02/WORK.md).
74. [`74-console-render-transactions`](74-console-render-transactions/WORK.md)
    — one descriptor as the V9958 rendering transaction boundary, plus
    LMMV/EOR attribute-only menu selection changes without glyph redraw.
    Review: correction required — exclusive-hold VDP access, unexplained
    T-state cost, behavioural coverage, run-time ANSI fallback; see
    [`correction-01`](74-console-render-transactions/correction-01/WORK.md).
75. [`75-console-serial-tee`](75-console-serial-tee/WORK.md)
    — the ZSDOS serial rescue on the production console: ESC ESC ESC from the
    serial terminal arms an output tee and toggles input ownership (polled
    detection); RENDER falls back to ANSI while teed. **Ready (worker).**
76. [`76-console-cost-profile`](76-console-cost-profile/WORK.md)
    — spike: where a console character's 3,000 T-states go (simulator
    per-layer profile, board rows for HMMM time and the direct-write
    ceiling). Runs after 74 correction-01. **Ready (worker).**
77. [`77-direct-text-spike`](77-direct-text-spike/WORK.md)
    — spike: a user-mode bench renders the `con.mixed` text through the
    console and through direct-write renderers (1-bit and pre-coloured
    font, per glyph and per run); same pixels, CPU/wait split, sizes.
    **Ready (worker).**
78. [`78-bulk-map-span`](78-bulk-map-span/WORK.md)
    — the bulk-map span and mapped segments (architecture 5.2, 5.4):
    `bulk_map`/`bulk_unmap`, refusals, leak closure, planner role, ledger.
    **Ready (worker).**
79. [`79-v9958-direct-renderer`](79-v9958-direct-renderer/WORK.md)
    — direct VRAM glyph writes from a 1-bit, scanline-major font in the
    V9958's mapped segment; atlases removed. After 78. **Ready (worker).**
80. [`80-console-geometry`](80-console-geometry/WORK.md)
    — `KCONSOLE_OP_INFO`/`KVIDEO_OP_INFO`: the grid is reported, libtui
    reads it. After 79. **Ready (worker).**
81. [`81-tui-storage`](81-tui-storage/WORK.md)
    — libtui's 4-bit attribute store, a smaller `console_info`, clamping a
    larger grid, and the per-program `TUI_GRID` capacity option. After 80.
82. [`82-konaedit-tui-editor`](82-konaedit-tui-editor/WORK.md)
    — one complete CP850, XMEM-backed text editor and TUI stress consumer:
    64-KiB documents, long lines, literal tabs, three-level undo, keyboard
    menus, paged Open/Save As dialogs, safe saves and render-traffic evidence.

**Architecture edits pending** (package 47 writes these straight into its new roadmap; see its Inputs):
- swap the milestones: M11 is the shell, M12 the diagnostics; "launch
  diag" moves to the diagnostics acceptance;
- the shell: `//` names the VFS root; the shared splitter's quoting
  rules; the launcher policy table and `KOS_BOOT_AFTER_EXIT`;
- diagnostics:
  - M12 adds the TIMER driver (CTC channel 2, `/dev/timer`): the first
    production interrupt source; the diagnostics time and benchmark with
    it;
  - the `SYS_DIAG_ENUM` kinds are bank, irq source, driver and irq
    totals; the namespace comes from `list`;
  - drop "before M12 supplies the shell, launch diag directly".

**After M10 (before M11).**

*1. Architecture/code audit.* A full pass that matches the code to the
architecture: boundaries and vocabulary.
- "service" names left in code (`services/`, `kernel/service/`,
  `service.h`, `SERVICE_IO`, `ipc_service_api`, `*_service.c`), where the
  architecture says **driver**; the console driver lives outside
  `drivers/`.
- The SDK files bind/call/unbind under `zos_ipc_*` / `zos/ipc.h`; they
  belong to the nucleus object API (`abi/zos/object.h`).
- Owner decision: does the terminal (escape-sequence parser, scrolling,
  cursor) stay in the V9958 VIDEO driver or move to the console driver?
- Recovery monitor: `DB`/`MB` reaching banks 0-6 is intended. Optionally
  extend them to bank 7, and label banks 6 and 7 as drivers and nucleus.
  Never restrict access.
- **Portability classification:** mark every ABI element as family-wide
  or Zephyr-80-port. Cheap steps: a CPU field in ZEX, sizes as an SDK
  platform type (not `uint16_t`), limits discoverable through `INFO`
  calls instead of fixed in the ABI.

*2. One build description per image* (`config/system.json` and one per
test image). It lists:
- the drivers, the `/dev` name each publishes, and symbolic dependency
  wiring (protocol names, not class numbers);
- the boot program and any extra store files.

The packer generates `services.man`, the publication table and the ROM
store from it. Driver manifests keep only what is intrinsic to the
driver. This removes the drift between `ZOS_SERVICES` and the store
manifests.

*3. Far calls as plain C (`__banked`).*
- Spike: SDCC 4.5's `b_` symbols and the `___sdcc_bcall_ehl` contract
  under `sdcccall(1)`.
- An SDK trampoline (cached `SYS_SEG_MAP` token, save the latch, `OUT`,
  `CALL`, restore) and `FARn=` build rules.
- Port `fardemo`/`xmem_far`; `zos_far_call` stays as the primitive.
- First users: the M11 diagnostics and the M12 shell.

*4. Name (decided 2026-10-12, package 48):* KonaOS for the OS family (KonaOS/80
on the Zephyr-80, …). Probable. Settle it before package 47 (see its
TODO): 47 writes the docs with the product name, and a separate rename
package moves the code prefix `zos`/`ZOS` → `kos`/`KOS` (headers, `abi/zos/`,
constants, types, SDK package name, banners; stored format names such as
ZEX/ZMOD to be decided).

*6. From the external architecture/DX review* (post-M10, before the M12
ABI freeze):
- Split headers by audience: nucleus-private (`kernel/include`), driver
  kit, SDK, on-media formats, platform public/private. Use per-audience
  include allow-lists; drop `-I .` for drivers and add a negative test.
- Drivers as self-describing directories (`drivers/<kind>/<id>/
  driver.json`) plus one `systems/*.json` per image and a `systemgen`
  that emits the build plan, `services.man`, the ROM store and the
  tables. This merges item 2.
- SDK naming: short concept names (`open/read/write/close`,
  `bind/call/unbind`, `run`, `exit`, `x*`, `seg*`, `farcall`), one
  spelling, typed handles, diagnostics in a recovery-only header, typed
  clients (`zos/video.h` and others). **Owner decision:** bare POSIX-like
  names versus a libc-compatibility layer later.
- A short current-architecture document plus a historical archive,
  instead of the 6.7k-line chronological file as the entry point.

*7. Standalone SDK package* (after 46's renames, before 47's
documentation pass):
- `make sdk` produces `zos-sdk-<version>/`: `include/` (`zos.h`,
  `zos/*.h` and the ABI headers they need, copied in), `lib/` (`libzos`,
  `crt0`), `tools/` (`zexpack`/`zexmanifest`, with no OS-tree imports),
  `mk/zos.mk` (standalone build rules), `template/`, `examples/`, `docs/`
  and `VERSION` (the ABI version).
- Today `zex.mk` depends on the top-level Makefile (`$(BUILD)`,
  `$(PYTHON)`), the packers live in `tools/` (`zexpack` imports
  `pack_image`), and the ABI headers are in `abi/`.
- `make check` gains an out-of-tree test: unpack the SDK into a temporary
  directory, build the template and run it in the simulator.
- The OS refuses a ZEX built for an incompatible ABI version.
- The developer workflow: SDK → `make` → copy the `.zex` to the card →
  `X /fs/app.zex`, with no OS source.
- Drivers are out of scope: they remain a source/build contract with the
  OS tree.

*5. Smaller items.*
- Dead Makefile items from 49a: `TEST_FIXED_OBJS` (referenced, never
  defined) and the `KOS_VFS_WS_GUARD` variable.
- Watch the global handle table (12 entries) when the M12 shell nests
  programs.
- Clearer `zexpack` diagnostics for initialized writable data and for
  `&global[runtime index]` refusals.
- Optionally merge `nucleus-selftest` into the subsystem image, now that
  the common limit is 3,072.
- Test images whose boot program is the test (`ipc-selftest`, the other
  self-tests) loop on hardware, because the launcher relaunches the boot
  program after it exits. Make each test end by running the monitor (as
  `hwtest` does), or report once and halt.
- The `console-integration` acceptance image has 49 bytes of cold room
  (it links the merged IOC/HID/V9958/console diagnostics). Split or slim
  it before anything is added to it.
83. [`83-gfx-foundation`](83-gfx-foundation/WORK.md)
    — GFX-1: `KVIDEO_OP_DIRECT_INFO`, `libgfx` lifecycle and modes, `gfx_clear`.
84. [`84-gfx-images`](84-gfx-images/WORK.md)
    — GFX-2: streaming upload, palette, KIMG v1, `tools/kimg.py`, `pview`.
85. [`85-gfx-primitives`](85-gfx-primitives/WORK.md)
    — GFX-3: the batch, `fill_rect`, overlap-safe `copy_rect`.
86. [`86-gfx-text`](86-gfx-text/WORK.md)
    — GFX-4: RAM font, mutable glyphs, expansion + opaque sink, `gfxdemo`.
104. [`104-sntrack-view`](104-sntrack-view/WORK.md)
    — SN-Track static view (`docs/sntrack-ui.md`): `sntview`, ZTR document
    layer, G6 screen for one order/page, page flip on Space; no playback.
106. [`106-hid-mouse`](106-hid-mouse/WORK.md)
    — `/dev/input/mouse` (type MOUSE) in the HID driver over IOC
    `CMD_HID_MOUSE`; SDK `kos/mouse.h`; `/system/mouse.exe`.
107. [`107-v9958-pointer`](107-v9958-pointer/WORK.md)
    — mouse pointer in sprite slot 1 (`KVIDEO_OP_POINTER`), kept through
    console drawing; SDK `pointer_*`; cursor hide without `D8h`.
108. [`108-tui-mouse`](108-tui-mouse/WORK.md)
    — libtui opt-in mouse: `TUI_KEY_MOUSE` events in cells, pointer
    driving, hit test, clickable modal runners; `tui_mouse` example.
108b. [`108b-apps-mouse`](108b-apps-mouse/WORK.md)
    — KonaCommander and KonaEdit use the mouse; shipped as `kc.exe` and
    `kedit.exe`.
109. [`109-gfx-pointer`](109-gfx-pointer/WORK.md)
    — libgfx 16×16 sprite pointer in G6/G7 (tables in page-1 lines
    496-511), sprites on only while shown; `gfx_mouse` example.
110. [`110-xmem-objects`](110-xmem-objects/WORK.md)
    — 32 extended-memory objects system-wide (9-bit handles); KonaEdit's
    document replace fits beside its far segment.
111. [`111-joy-driver`](111-joy-driver/WORK.md)
    — `joy` driver: `/dev/input/joy/0` and `/1` (type JOY), the controller
    latches through `IN FCh`/`FFh`, ColecoVision bytes as is; SDK
    `kos/joy.h` with a direct-read fast path; `/system/joy.exe`.
