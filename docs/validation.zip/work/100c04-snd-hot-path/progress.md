# 100c04 progress (supervisor implementing)

Baseline (100c03 record): put_atten 298, 12 voices 27,245, one voice
6,090, refresh 23,096, ZVG/byte 224, ZVG wait tick 416, idle 546.

- [ ] read current engine/out/zvg
- [ ] 1 layout (page-aligned descriptors, shadows inside, level page)
- [ ] 2 atten/period write shapes
- [ ] 3 voice step
- [ ] 4 ZVG run loop
- [ ] 5 primitives convention
- [ ] 6 pins, docs; make check; record

Design in progress (supervisor):
- descriptors page-aligned (runtime, 512-byte area, _snd_desc_page),
  base = page:(v<<4); fields: 0 flags, 1-2 wait, 3-4 cursor, 5 touched,
  6 atten desired, 7 atten shadow, 8 atten latch, 9 port, 10 reg latch,
  11 chip, 12-13 desired reg ptr, 14-15 shadow reg ptr
- puts take HL = descriptor base; snd_all_valid global fast check
- attenuation arrays move into descriptors; period/noise arrays stay

## 2026-10-25 (cont.)
- Fixed: commit's DESIRED_REG sites now mask L (and #0xF0). Down to 3 failures:
  adsr tick-by-tick ((224,159) vs (224,154)), budgets 12 voices 54,506, ZVG wait tick 518.
- Fixed: fresh programs (stored wait 0) take _snd_now (this call's ticks), not pending+n. All functional tests pass; ZVG wait tick 502 > 300 remains.
- Profile (window 9, 12 voices): engine 15,124 = ~1,260/voice spread evenly over instructions; put_atten 166/write. Next: ZVG wait tick, ZVG run loop (Must), then engine tightening.
- tests/test_snd.py: app_mapped(z) gate — interrupt (OS mapping) time no longer attributed. zvg wait 209, per-byte 99; snd idle 207, twelve 22,993, per-byte 3,172, refresh 20,035. All test_snd pass. Next: ZVG run loop, engine tightening.
- ZVG decoder rewritten (port once per command tick, ld/inc l/out/djnz run loop, account once per command, 32-bit counters fixed). per-byte 27, wait 231. Orig in scratchpad/snd_zvg_dec.asm.orig. Next: engine tightening.
- Engine rewrite v2 in progress (v1 saved scratchpad/snd_voice.asm.v1): flags==0 skip, VF_FORCE in flags, VD_LEVEL +5 in desc (C reads via snd_desc_page), level table copy on page+1, global _snd_touched for period/noise only, inline atten commit (_snd_fast).
- Engine v2 passes all test_snd. Steady: twelve 10,371 (first tick 18,611 incl 12 periods), one voice 1,804 over idle 207, refresh 18,560 (flush_all), batch 7,110. Sim charges jr cc=12 always (table cost). Next: flush_all.
- flush_all DIRECT path (ldir shadow copy + port in C): refresh 18,560 -> 12,363.
- put_period DIRECT holds the port; countdown inlined; commit entry fixed L. Final sim figures: idle 207; twelve steady 9,987 / first tick 18,594; one voice +1,772; refresh pair 12,351 (flush_output 4,547); batch 7,117; ZVG wait 231, per-byte 27, command loop 920.
- Engine stops here (~830 T per steady ATTEN+WAIT voice, flat profile). Next: pins (+10%), docs, record, make check.
- Pins/docs done (sdk.md costs, snd-sdk 4.3/4.5/7.1; SND_BATCH_MAX header 60). Running validation.
- DONE 2026-10-26: make check OK (989, skip 119), OS hash unchanged; record docs/validation/2026-10-26-snd-hot-path.md. Pending: owner board checklist; follow-up decision on the engine wait model.
- ACCEPTED by owner 2026-10-26 as is (engine figures over target, headroom judged sufficient). 102 amended: tick path all assembly, inline compare-and-write.
