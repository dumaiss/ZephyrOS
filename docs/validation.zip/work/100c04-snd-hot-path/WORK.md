> Worker package. After 100c03, before 101. A correction: 100c03's
> structure is right, but its hot paths are slow (12 voices 27,245 against
> 4,000; `snd_put_atten` 298 against 80; ZVG 224 per byte against 50).
> Rewrite the inner code to the shapes below. Same behaviour, same
> traces, same API. No OS change.

# Task

Make the three hot paths cheap. They are the write-through primitives,
the active-voice step and the ZVG run loop. The patterns below are
binding unless a measured profile shows a better one.

## Current state (100c03's record)

- **IY everywhere:** the descriptors are reached through IY. Each
  `(iy+d)` access costs 19 T-states, and most fields are touched
  several times per step.
- **Two indirections per write:** each write loads a pointer to the
  desired byte and one to the shadow byte from the descriptor, then
  dereferences both, then checks a chip-valid flag, then emits.
- **The ZVG run loop** calls `_zvg_write` per byte, which re-tests the
  output mode and re-reads the port from a table every time, with
  push/pop around each call.
- **The harness now attributes by symbol** (the fixed-window figures
  before were low). The new figures are the real ones.

Read: `work/00-WORKER.md`; 100c03's record; `snd_voice.asm`,
`snd_out.asm`, `snd_zvg_dec.asm`, `snd_private.h`.

## Requirements

1. **The data layout** (Must):
   - **The descriptor table** is page-aligned: 16 descriptors of 16
     bytes is exactly one 256-byte page (runtime-aligned in a 512-byte
     area, as the ZVG ring is). A descriptor's fields are reached with
     `L` arithmetic only;
   - **the shadow bytes live inside the descriptor**, next to their
     latch prefix and the port. Order the fields so the write path walks
     them with `inc l`:
     `atten_shadow, atten_latch, port, period_lo_shadow,
     period_hi_shadow, tone_latch, ...`. The 44-byte rewrite walks the
     descriptors in card order;
   - **the level table** (linear 0-255 to attenuation) is page-aligned,
     so a lookup is `ld e,level / ld d,page / ld a,(de)`;
   - **no IX or IY in the per-voice or per-byte paths.** HL is the
     descriptor cursor, DE the program cursor.
2. **The attenuation write** (Must). The DIRECT shape, with HL pointing
   at `atten_shadow` and A holding the new attenuation (0-15):

   ```
   cp   (hl)        ; equal: nothing to do
   jr   z,1$
   ld   (hl),a      ; shadow
   inc  l
   or   (hl)        ; | atten_latch (90h | sub<<5)
   inc  l
   ld   c,(hl)      ; port
   out  (c),a
   1$:
   ```

   That is about 55 T-states when changed and 20 when equal. The period
   write follows the same shape over its two shadow bytes and latch.
   BATCH swaps the `out` for an append; take the mode branch once per
   tick, not per write (two copies of the voice loop, or a patched call).
   The full-rewrite path (an invalid shadow) is checked once per tick,
   not per write.
3. **The voice step** (Must):
   - the walk keeps 100c03's unrolled countdown for waiting voices;
   - **an active voice:** HL = its descriptor, DE = its cursor, the
     opcode jump-table dispatch; ATTEN is `ld a,(de) / inc de` → the
     level table → requirement 2's shape → the next opcode;
   - **at a WAIT:** store the cursor and the counter back once;
   - target about 200 T-states for an ATTEN+WAIT voice step, all in.
4. **The ZVG run loop** (Must). Per tick, load the chip's port into C
   (DIRECT) once, then:

   ```
   ld   a,(hl)
   inc  l
   out  (c),a
   djnz loop
   ```

   No call per byte. BATCH appends in a second loop, bounded by the
   batch's free room, sending when full. `writes`, `consumed` and
   `head` are updated once per command, not per byte.
5. **The internal primitives for 102** (Must). `snd_put_period`,
   `snd_put_atten` and `snd_put_noise` keep their meaning, with the new
   register convention: HL = the descriptor's field, A or DE = the value.
   Document it in `snd_private.h`.
6. **Pins and docs** (Must). The timing test's ceilings move to the new
   figures (+10%), with the targets in the messages. `docs/sdk.md` gets
   the costs.

## Tests

- **Unchanged and passing:** all of `tests.test_snd`, `tests.test_snd_oracle`
  and `tests.test_reader` (the voice-order references, staggered
  voices, catch-up, the primitives, the ZVG goldens, the timed
  `NIGHT.ZVG` replays).
- **The profile:** the record lists each hot routine's T-states (the
  harness's symbol attribution), before and after.

## Budgets (CPU T-states, interrupts out)

| figure | 100c03 | target | on overrun |
|---|---|---|---|
| `snd_put_atten`, changed / equal (DIRECT) | 298 / - | <= 80 / <= 30 | report with a profile |
| one ATTEN+WAIT voice step, all in | - | <= 250 | report with a profile |
| 12 voices changing attenuation | 27,245 | <= 4,000 | report with a profile |
| one voice step + one changed byte (DIRECT) | 6,090 | <= 400 | report with a profile |
| full rewrite, 4 chips (DIRECT) | 23,096 | <= 3,500 | report with a profile |
| ZVG, per written byte in a run (DIRECT) | 224 | <= 50 | report with a profile |
| ZVG, wait-only tick | 416 | <= 300 | report with a profile |
| idle tick (12 waiting) | 546 | <= 600 | stop and report |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board: `sndtest tones`, `adsr`, `noise`; `sndtest zvg
  /fs/night.zvg 2` and `vgmplay /fs/night.zvg` play as before.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/VGMPlayer test
python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_reader tests.test_sdk_package
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-hot-path.md`.
