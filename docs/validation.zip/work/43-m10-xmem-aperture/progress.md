# 43-m10-xmem-aperture progress

## Baseline (2026-10-10)

- Tree at `a7bfb43` (42d), clean; `make clean && make` green (36 s wall,
  `-j20` default).
- Production hash `6e437af5…` reproduced; ledgers: fixed 8183+2 required
  (7431 room), cold end A5BAh (13607 room), hot 21846/32768, boot/bulk
  2170/24576, common 2358/7424 (ceiling 3072, m10 512, limit 2560).
- Supervisor steer: validation = `make clean && make check`;
  `make xmem-selftest fs-selftest subsystem-selftest`; `git diff --check`.
  No `m9-*` images exist. One new image only (44b will extend it).
- 42d record reviewed: does not contradict the 43 contract (it records the
  2560 limit and expects 43 to lift it to 3072).

## Decisions taken

- Bank map lives in `kernel/process/process.c` (extend the existing
  allocator): slot ownership `uint8_t owner[6][7]`, three bank states
  derived (FREE / PRIMARY via the process table / AUXILIARY via any live
  slot). Aux: highest bank first, packing banks with live slots first;
  primary allocator skips aux-live banks (ENOSPC).
- Slot policy (36.16): mappable objects only in slots 4-5 (1 slot: 4 then
  5; 2 slots: 4-5); non-mappable prefer window-speed slots then 0-2:
  1: 3,6,0,1,2; 2: 2-3,0-1,1-2; 3: 1-3,0-2; 4: 0-3. Largest object
  32 KiB; MAPPABLE at most 16 KiB.
- Object table + handles in `kernel/syscall/xmem.c` (cold): 16 entries,
  handle = (index << 4) | generation (1..15), owner-tagged by pid.
- Copies (36.16): slot 3-6 chunks through the mode-11 window (new
  common-resident `zos_window_copy` in kernel/memory/user_copy.asm,
  P = 7 - bank); slots 0-2 through the existing mode-10 `zos_bank_copy`
  gate. Caller side through `zos_syscall_bank_*`.
- Buffer identity (36.8/36.17): new `zos_syscall_buffer_bank()` resolves
  8000h-BFFFh under a saved nonzero page to bank 7 - P; used by every
  syscall caller-buffer copy (object/ns/exec/xmem). `zos_syscall_buffer_ok`
  rejects a buffer crossing the aperture boundary. Descriptor capture was
  already done by ipc.c `desc_bank()`.
- MAP returns HL = token (mode 10 | P = 7 - bank | caller bank) and writes
  the aperture address into the block; tokens exist only for the caller's
  own objects in banks 0-5.
- Exit: `zos_xmem_release_process(pid)` runs in `process_exit()` after
  `vfs_process_exit()` (handles first, then objects).
- 5b: common limit becomes the 3072 ceiling, the 512-byte reservation
  field disappears from platform files, tools, ledger line and docs.

## Implementation log

- Bank map, slot map, xmem family, window copy, buffer identity, exit
  release, SDK wrappers and aperture helpers: done as decided above.
- `docs/abi.md` section 14 pins the family (numbers, blocks, token rule,
  buffer identity, lifetime); `abi/zos/xmem.h` and
  `user/sdk/include/zos/xmem.h` are the code-side pins.

## Debugging record (kept: it changed a shared tool)

- The first full replay of `xmem-selftest` ran away into the syscall gate:
  the program's `big[i] = handle` store landed on `E0E4h` (common code).
- Cause: `tests/z80sim.py` decoded the DD/FD-prefixed `add ix/iy,rr`
  group with the unprefixed register table, so `add iy,iy` (`FD 29h`,
  SDCC's index doubling) added **HL** instead of IY.  Fixed in
  `tests/z80sim.py` (the prefixed forms answer the index register where
  the unprefixed encoding names HL; `add iy,iy` is `FD 29h`).
- Two test-side bugs surfaced after the simulator fix (both in
  `tests/xmem/xmem_selftest.c`):
  * the exhaustion checks asserted `-ZOS_ENOSPC` *after*
    `count_until_full` had already freed the objects, so the refusal
    could not be observed; now the objects stay held for the refusal and
    a `*-refill` check follows the release;
  * the identity checks wrote at offset `2000h` of an 8 KiB anchor
    (out of range, correctly `-ZOS_EINVAL`); rewritten to be in-range and
    to prove the far bank on both sides (a far-bank destination read back
    through the aperture and by handle).
- The child printed `%02X`, which the SDK printf does not implement (it
  emitted a literal `X`); now `%02x`.
- The launcher's report is `active 0 free-banks 6`: the boot program is a
  kernel-launched process, so after its exit nothing is active and all
  six application banks are free again - that is the exit-release proof
  (bank 5 held the two anchor objects).

## Final validation (2026-10-10, run once, serially)

- `make clean && make check`: reproducible rebuild
  `8886f15494383474c4214d0fb45e0668b115f088f1a2d730f83ad4c750e3a57f`,
  545 tests OK, `mapcheck: OK (18 areas, 340 symbols) [production]`.
- Production ledgers: fixed 8335+2+768 (room 7279) | cold 20346 `AF7Ah`,
  data 1443 `B000h` (room 10845) | hot 21846/32768 | boot/bulk
  2170/24576 | common 2358/3072.  No ledger raised; common use is
  unchanged from the M9 baseline (the window copy links into the fixed
  core, and the reservation was released rather than spent).
- `make xmem-selftest fs-selftest subsystem-selftest`: all three green
  (5 + 3 + 4/26 replay tests OK); xmem image `61 checks, 0 failures` and
  `PASS`, exit report `active 0 free-banks 6`.
- `git diff --check`: clean (no whitespace findings).
- Report: `docs/validation/2026-10-10-m10-xmem-aperture.md`.

## Status

- [x] Baseline build/ledgers recorded.
- [x] Implementation, image, replay and docs.
- [x] Final validation and the report.
- [x] Committed.
