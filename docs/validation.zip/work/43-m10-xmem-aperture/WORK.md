# Task

M10 step 9 (architecture 36.24). Add the **application bank map** with
auxiliary slots (36.15), **extended-memory objects** (36.16), **map
tokens** and the **mode-10 far aperture** (36.17), and **buffer
identity** for aperture addresses (36.8).

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md` (decisions 5, 6 and 16);
- architecture 36.8 and 36.15-36.17;
- the process bank allocator (banks 0-5);
- `kernel/ipc/ipc.c` (`desc_bank()` already carries the aperture hook);
- the package-42d record.

The package-33 xmem and bank map were removed in package 37. Consult git
(`69cddf8`) for ideas only.

**Before starting:** if 42d's record contradicts this contract, stop and
report.

## Requirements

1. **Bank map.**
   - Each bank is FREE, PRIMARY(process) or AUXILIARY.
   - An auxiliary bank has seven 8 KiB slots (`0000h-DFFFh`) with the slot
     classes of 36.16.
   - Primary banks are allocated lowest-first. Auxiliary slots are
     allocated highest-bank-first, packing existing banks first.
   - A bank with a live slot cannot become primary (`ZOS_ENOSPC`).
2. **xmem syscalls:** `ALLOC(size, flags)`, `FREE`, `READ`, `WRITE`,
   `INFO`, `MAP`.
   - The `MAPPABLE` flag means at most 16 KiB, placed in slots 4-5.
   - Contents are **undefined**; nothing is pre-zeroed (36.19).
   - Ranges are checked before any copy.
   - Copies use the window for slots 3 and 6 and the gate for slots 0-2.
   - **`MAP` returns the token and the object's aperture address** (an
     object in slot 5 is at `A000h`).
   - Pin the numbers in `abi/zos/xmem.h` and document them in
     `docs/abi.md`.
3. **Map tokens.**
   - Tokens are only for the caller's own objects, and only for banks
     0-5.
   - The SDK opens the aperture with `OUT` and closes it by restoring the
     previous token. Provide the SDK helpers.
4. **Buffer identity.** An address in `8000h-BFFFh` with the saved latch
   in mode 10 and P ≠ 0 resolves to bank 7 − P. This applies in the
   syscall copies and in descriptor capture (path C, 36.8).
5. **Lifetime.**
   - Exit frees every object after closing the process's handles (36.13).
   - A suspended parent keeps its objects, and a child inherits none.
   - Exec starts the child with P = 0 and restores the parent's latch
     exactly.
5b. **Common limit.** `tools/mapcheck.py` still enforces the old 2,560-byte
   common limit (2,358 used). Lift it to the 3,072 ceiling, as 36.20 allows
   M10 (the 512-byte reservation is released). Remove the `m10`
   reservation field from the ledger line.
6. **Tests.** One `xmem-selftest` image covering the architecture 37 xmem
   rows and the far-data rows that do not need ZEX v2. Assert outcomes
   only.

## Constraints

- No ZEX v2 or far-code segments (packages 44a and 44b).
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-xmem-aperture.md`.
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation

```sh
make clean && make check
make xmem-selftest fs-selftest subsystem-selftest
git diff --check
```

Hardware (owner): run `xmem-selftest`. The aperture is
hardware-authoritative.

## Acceptance criteria

- The xmem and non-ZEX far-data rows of architecture 37 pass in the
  simulator and on hardware.
- Buffer identity holds.
- The ledgers are within 36.20.
