# Task

M10 step 10, part 2 (architecture 36.24). **Far code through the mode-10
aperture** (36.17, 36.18):

- `FAR_CODE` segments linked at `8000h`, at most 16 KiB, executed in
  place;
- `SYS_SEG_MAP`;
- SDK and linker support with near-code checks;
- a far-call helper and a demo.

## Context

Read:
- `work/00-WORKER.md`;
- architecture 36.16-36.18;
- the package-43 and 44a records;
- `user/sdk` (`zex.mk`, the template, `docs/sdk.md`).

**Before starting:** if 44a's record contradicts this contract, stop and
report.

## Requirements

1. **Packer and loader.**
   - `FAR_CODE` segments are linked at `8000h`, at most 16 KiB, with no
     relocation.
   - The loader places **one far-code segment per auxiliary bank** in the
     aperture slice (36.16). The free aperture slot may hold mappable
     data.
2. **`SYS_SEG_MAP(segment)`** returns a token, for the caller's own
   `FAR_CODE` segments only. The segment is always at `8000h`.
3. **SDK and toolchain.**
   - Build a program with far-code segments: SDCC areas linked at `8000h`.
   - Check at build time that code, stack and data used while the
     aperture is open lie outside `8000h-BFFFh` of the primary image.
   - Provide a far-call helper (map, then a plain `CALL`, then restore)
     and a demo program.
   - If SDCC/sdld cannot express something, **stop and report** with a
     minimal reproduction. Do not hand-patch binaries.
4. **Tests.** Extend `xmem-selftest` (package 43) with a far-code
   program; do not add a new image. It covers the architecture 37
   far-code rows:
   - map, call far and return;
   - far code calling primary code;
   - syscalls from far code, including a buffer inside the aperture;
   - exec and exit from far context;
   - token refusal for other processes and for banks 6/7.

## Constraints

- No other mechanism changes.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-far-code.md`.
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation

```sh
make clean && make check
make xmem-selftest fs-selftest subsystem-selftest
git diff --check
```

Hardware (owner): run `xmem-selftest` and the far-code demo, plus
`make smoke-hardware`.

## Acceptance criteria

- Far code runs through the aperture, and the architecture 37 far-code
  rows pass in the simulator and on hardware.
- The ledgers are within 36.20.
