# 44b — M10 far code through the mode-10 aperture: working state

Contract: `work/44b-m10-far-code/WORK.md`.  Baseline: package 44a at
`9b8e88d` (clean tree).

## Decisions taken (design)

- **SDK builds one `_FAR_CODE` area per program** (one `sdldz80` link:
  `-b _FAR_CODE = 0x8000`); the primary and far code cross-reference by
  linker symbols, and the far entry is a normal linked symbol the primary
  passes to the far-call helper.  Several areas cannot share `8000h` in
  one link, and a second link would break the linker-resolved entry rule,
  so the *container* supports several far segments (one payload per id)
  while the SDK rule links one area.  A container may declare the same
  area more than once: the loader places one payload per auxiliary bank.
- **Payload extraction is host-side in `zexpack.py`**: a FAR_CODE segment
  declares `{"id", "kind": "FAR_CODE", "area": "_FAR_CODE", "bss_size"}`
  and the packer resolves `s__<area>` (must be `8000h`) and `l__<area>`
  (1..`4000h`) from the program's own map and takes those IHX bytes
  (holes zero-filled).
- **Build-time aperture rule** (36.17 linker rule) in the packer: a
  container with any FAR_CODE segment must keep the primary image, its
  BSS and the whole stack outside `8000h-BFFFh` (image+BSS end at most
  `8000h`, stack base at least `C000h`).  It is a host/linker rule (the
  kernel does not repeat it; the kernel's own bound is that a far segment
  is at most 16 KiB so it fits the aperture slice).
- **`SYS_SEG_MAP` (27h)**: `{segment:u8, reserved:u8}` -> token.  Only the
  caller's own FAR_CODE segments; the token is the aperture latch value
  (P = 7 - bank, banks 0-5 only); the address is always `8000h`, so the
  ABI returns a token only (architecture 36.17).
- **Loader placement**: FAR_CODE takes slot 4 (1-2 slots, `8000h` in the
  bank), so one far segment per auxiliary bank is structural; slot 5 of
  that bank stays free for a mappable object (exercised by the far
  program: a mappable object lands in the same bank, same token, address
  `A000h`).
- **Tests**: the xmem-selftest image gains a third program
  `/SYSTEM/xmem_far.zex` (the far-code program) that `xmem_selftest.zex`
  execs; it declares two far segments, maps/calls both, has its far code
  call primary code, run syscalls with an aperture buffer, exec
  `xmem_child` from far context and leave its aperture open at exit.  The
  parent's package-43 checks are untouched (61) plus two far-program
  status/release checks (63 total); `xmem_child` gains the foreign
  far-segment refusals (tail carries the far program's ids).
- **Demo**: `user/helloworld/fardemo` (SDK demo set), bootable as
  `/SYSTEM/fardemo.zex`.

## Status

- [x] kernel/ABI
- [x] packer
- [x] SDK rule + wrappers
- [x] xmem far program + tests
- [x] demo
- [x] fixtures/host tests
- [x] docs
- [x] validation + record (`docs/validation/2026-10-11-m10-far-code.md`)

## Log

- (start) read contract, 44a and 43 records, architecture 36.15-36.20,
  36.8, 36.17/36.18, docs/sdk.md, zex.mk, zexpack/zexmanifest, exec.c,
  xmem.c, process.c, xmem selftest + replay, test_sdk/test_zex.
- Toolchain probes (in /tmp): SDCC `--codeseg FAR_CODE` + sdld `-b
  _FAR_CODE = 0x8000` links the far area at `8000h` next to the primary
  image; the map carries `s__FAR_CODE`/`l__FAR_CODE`; string literals and
  `const` arrays of a far module land in `_FAR_CODE`; two areas at the
  same base in one link emit overlapping IHX records (unusable) - hence
  the single-area decision above.
- Implemented: `abi/zos/seg.h` 27h + `struct zos_seg_map_args`,
  `ZEX_SEG_MAX_FAR_SIZE`; `kernel/syscall/xmem.c` (placements,
  `zos_seg_map`, `SYS_SEG_INFO` handle 0 for far), `kernel/syscall.c`
  (20h-27h), `kernel/process/process.{c,h}` (`ZOS_AUX_PLACE_*`,
  `process_aux_alloc(place)`), `kernel/process/exec.c` (accept FAR_CODE,
  16-KiB limit); `tools/zexpack.py` (area extraction, aperture rule,
  per-kind limits, overlap), `user/sdk/zex.mk` (`FAR=`,
  `-b _FAR_CODE = 0x8000`, auto `NAME.far.json`, ASM does not need the
  option), `user/sdk/{include/zos/seg.h,src/seg.c,src/zos_internal.h}`
  (`zos_seg_map`, `zos_far_call`), `user/sdk/src/sdcc_calls.asm`
  (`___sdcc_call_iy`/`_hl`/`___sdcc_enter_ix`).
- Programs/tests: `tests/xmem/xmem_far.c`, `xmem_far_code.c`,
  `xmem_far.segments.json`, `tests/xmem/xmem_selftest.c` (far section),
  `xmem_child.c` (foreign far refusals), both manifests, the Makefile
  (program, ROMFS deps), `tests/test_xmem_selftest_sim.py` (far
  outcomes), `tests/test_zex.py` (+10), `tests/test_sdk.py` (program
  list, FAR boundary), `tests/subsys/gen_zex_fixtures.py` +
  `manifest.json` (`zex-seg-kind` = 3, `zex-far-oversize`).
- Demo: `user/helloworld/fardemo.c` + `fardemo_far.c`, its Makefile line
  and store entry.
- Bugs found and fixed while bringing the far program up: (1) the
  selftest compared a 16-bit token with a signed shift
  (`(result >> 8) == (int)t2` failed for tokens >= `80h`) - now
  `((unsigned int)result >> 8)`; (2) the far and primary halves' literal
  strings have to match exactly (a stray `\r\n` made the far console line
  differ); (3) `___sdcc_call_iy` was undefined for the indirect far call,
  hence `sdcc_calls.asm`.
- Validated on the frozen tree: `make clean && make check` (reproducible
  `02100c28…`, 573 host tests OK, 102 skipped), `make xmem-selftest
  fs-selftest subsystem-selftest` (all green: far program 19 checks, the
  parent 63 checks, `free-banks 6`), `make helloworld-image` (green,
  `test_sdk` 28) and the far-demo boot image (transcript captured for the
  record); `git diff --check` clean.
- Record written: `docs/validation/2026-10-11-m10-far-code.md`.  Tree
  left with the implementation uncommitted (the task forbids committing).
- Baseline comparison for the ledger: a detached worktree of `9b8e88d`
  in `/tmp/44a-base` rebuilt the 44a production image
  (`d1ed3ecf…`, the hash 44a's record pins) and gave the per-object code
  sizes (`xmem.rel` +323, `process.rel` +54, `process_exec.rel` +41 =
  the 418-byte cold-code growth).

