> Worker package. After 83. Implements `docs/gfx-sdk.md` sections 10, 11,
> 16 and 17 (GFX-2).

# Task

Streaming pixel upload, the palette, the KIMG v1 format, its host
converter and the card picture viewer `pview`.

## Current state

- libgfx from package 83 (`user/sdk/gfx/src/`, `kos/gfx.h`).
- The SDK ships host tools in `tools/` (`tools/sdkpack.py` `TOOL_FILES`).
- User applications live in `UserSoftware/<App>/` and build with the
  standalone SDK (`UserSoftware/KonaCommander/Makefile` is the pattern:
  unpack `build/kos-sdk-*.tar.gz`, include `mk/kos.mk`).
- Pillow is available on the development host; the build must not need it.

Read: `work/00-WORKER.md`; `docs/gfx-sdk.md`; package 83's record.

## Requirements

1. **Upload** (Must): `gfx_upload_begin/write/end` as direct data-port
   writes; the position is kept across calls; one VRAM address per row, or
   one for the whole transfer when the rectangle is full-width; any chunk
   length; the exact byte count is enforced (`end` with bytes missing, or
   a write past the end, is `-KOS_EINVAL` and leaves no half state); not
   nestable; pending batch flushed first (a no-op until package 85);
   y 0-511 (the off-screen page included); G6 x/width even.
2. **Palette** (Must): `gfx_set_palette` (RGB 0-255 to the V9958's 3-bit
   values, written under WAIT); `-KOS_ENOTSUP` in the 256-colour and YJK
   modes.
3. **KIMG v1** (Must): the header of `docs/gfx-sdk.md` 16 in a shipped
   header (`kos/kimg.h`, layout and constants only).
4. **Converter** (Must): `tools/kimg.py` (Pillow): scale/crop to the mode,
   G6 palette generation (16 colours) and packing, G7 RGB332, YJK
   encoding; shipped in the SDK `tools/`. Its test skips without Pillow.
5. **Fixtures** (Must): small pre-converted `.kimg` files committed (G6,
   G7, YJK; full screen or a rectangle), produced by the converter.
6. **pview** (Must): `UserSoftware/PView/` (Makefile like KonaCommander's,
   `LIBS=gfx`): `pview file.kimg` per `docs/gfx-sdk.md` 17, reading the
   file in 4 KiB blocks; a bad header prints an error and exits without
   touching the display.
7. **Docs** (Must): `docs/sdk.md` (upload, palette, KIMG, the converter).

## Tests

- Upload in chunks of 1, 7, 256 and 4,096 bytes: VRAM equals the payload;
  a short and an overlong stream refused; off-screen target.
- Palette in G6: the peer's palette entries; refused in G7.
- KIMG round trip (converter -> file -> header parser) when Pillow is
  present.
- `pview` replay on the production image with a fixture on the card: VRAM
  and registers after the upload, the console restored after the key.

## Owner checklist

- Convert a real photograph to YJK and to G7 with `tools/kimg.py`, copy
  them and `PVIEW.EXE` to the card, view both, return to the shell.

## Validation

```sh
make && make sdk && make -C UserSoftware/PView test
python3 -m unittest tests.test_gfx tests.test_kimg tests.test_sdk_package tests.test_source_layout
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-gfx-images.md`.
