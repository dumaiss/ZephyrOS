# progress.md — 84-gfx-images

Present-tense working notes. Baseline: HEAD (e5e16ca, package 83
committed). Implements docs/gfx-sdk.md 10, 11, 16, 17 (GFX-2).

## Plan

- libgfx: gfx_upload_begin/write/end (data-port streaming, position kept
  across calls, exact byte count, not nestable), gfx_set_palette (G6
  3-bit RGB, -KOS_ENOTSUP in G7/YJK).
- kos/kimg.h (KIMG v1 header, layout + constants only), shipped.
- tools/kimg.py (Pillow): scale/crop, G6 palette + packing, G7 RGB332,
  YJK encoding; SDK TOOL_FILES; test skips without Pillow.
- Fixtures: small committed .kimg (G6, G7, YJK), converter-produced.
- UserSoftware/PView/: Makefile (KonaCommander pattern, LIBS=gfx),
  pview.c reading in 4 KiB blocks; bad header errors without touching
  the display.
- Docs: docs/sdk.md (upload, palette, KIMG, converter).
- Tests: test_gfx.py additions (upload chunks 1/7/256/4096, short and
  overlong refused, off-screen target; palette G6 + refused G7);
  tests/test_kimg.py (round trip, skip without Pillow); pview replay on
  production image with a card fixture; update test_sdk_package
  (tools/kimg.py in the tree, kos/kimg.h shipped) and
  test_source_layout.

## Open design points (resolve as I go)

- Upload VRAM addressing: R#14 for A16 (page 0/1), then two command-port
  address bytes per row; one address for a full-width rectangle.
- G6 upload byte packing: streamed bytes are packed G6 bytes (two
  4-bit pixels per byte) - upload geometry counts pixels, bytes = x even.
- KIMG v1 layout: read section 16 exactly.
- pview: exit codes, console lines like other card programs.

## Status

- [ ] read gfx-sdk.md 16/17, KonaCommander Makefile, sdkpack TOOL_FILES
- [ ] libgfx upload + palette
- [ ] kos/kimg.h
- [ ] tools/kimg.py + fixtures
- [ ] UserSoftware/PView
- [ ] tests + docs
- [ ] validation batch + record

## Implementation notes (post-debugging)

- v9958_io.asm bugs found and fixed during the replay work:
  - stream_vram's remainder path: `ld a,l` leaves the flags from the
    earlier `or a`, so `ret z` returned for any length <= 255, writing
    nothing.  Fixed with `or a` before the `ret z`.
  - set_vram's ABI: sdcccall(0) passes (u8, u16) in A, DE, but the asm
    read the offset from HL (stale caller registers).  Rewritten to use
    DE directly, r14 held across the wait on the stack.
- Card filesystem is 8.3: on-card KIMG files use the .img extension
  (e.g. TEST7.IMG); the host fixtures keep .kimg.
- A solid-colour G6 source quantizes to a 1-entry palette; KIMG's
  palette_count field carries the count (<= 16 for G6), so that is
  valid output - the replay's palette expectations use the fixture's 16.
- pview_keyed must wait for the run's own display cycle (R#1 00h then
  40h), because the console leaves R#1 at 40h when gfx_open lands.
- Upload rect base addresses: y=300 -> 0x12C00 (300*256), not 0x10B00.

## Status

- [x] read gfx-sdk.md 16/17, KonaCommander Makefile, sdkpack TOOL_FILES
- [x] libgfx upload + palette
- [x] kos/kimg.h
- [x] tools/kimg.py + fixtures
- [x] UserSoftware/PView
- [x] tests + docs
- [x] validation batch + record
