# M9 shared decisions and reference contract

This note fixes the decisions shared by the M9 packages (25 and its
corrections, 25b, 26-31). `docs/architecture.md` sections 32-33 are the
architectural contract, including the 2026-10-04 trim: path-based providers,
provider-owned caching, a global descriptor pool, the trimmed syscall set, a
deferred block driver, and the bank-7 residency budget in section 32.39.
`docs/filesystem.md` is the historical proposal and adds nothing normative.
Where this note pins a value the architecture leaves open, the value here is
the decision. A worker that finds a conflict stops and reports it.

The adjacent Zephyr-80 repository remains a read-only reference pinned at
commit `2c6b965009256b71ebe3ae18977f80e8c1fcad24`. The MCU firmware is never a
work target. `work/M8-REFERENCE.md` still governs all IOC transport behavior.

## No backward compatibility

ZephyrOS is still being built. No interface, ABI version, binary format, image
layout, transcript or artifact hash carries a backward-compatibility
obligation. Completed milestones prove that mechanisms work; they do not freeze
them. Consequences for every M9 package:

- Replace mechanisms in place. Never keep an old path, alias, wrapper or
  "legacy" mode beside the new one.
- ABI and struct changes are made directly. There are no version-negotiation
  or append-only rules. Bump a version number only where a validator uses it
  to reject stale build artifacts.
- Earlier acceptance transcripts, image hashes and `monitor.zex` bytes are not
  oracles. The behavior they proved must still work; prove it with current
  tests on the current boot path.
- Hardware evidence applies to the bytes it was recorded on. Changed
  hardware-facing bytes need a fresh smoke run.
- Retention window (`00-SUPERVISOR.md`): only M8 (Mn-1) and M9 acceptance
  machinery exists after package 25a. Every package's validation implicitly
  includes the subsystem targets 25a creates (`tests/target/<subsystem>/`),
  in addition to the commands it lists. Do not reintroduce M1-M7
  configurations.

## Pinned native ABI values

Errors, in `include/zephyros/errno.h` (syscall-visible):

```text
ZOS_EEXIST    0x10    ZOS_EROFS   0x14
ZOS_ENOTDIR   0x11    ZOS_ESTALE  0x15
ZOS_EISDIR    0x12    ZOS_EXDEV   0x16
ZOS_ENOTEMPTY 0x13    ZOS_EMFILE  0x17
```

`ZOS_EMFILE` reports descriptor-pool or provider open-handle exhaustion
(architecture 32.30). A path or component over the limit is `ZOS_EINVAL`. An
operation that needs the `/` filesystem while none is mounted is
`ZOS_ENODEV`. Removing or renaming a mountpoint is `ZOS_EBUSY`; `mkdir` of a
mountpoint is `ZOS_EEXIST`.

Syscall numbers (same `RST 30h` gate and conventions as M6/M7):

```text
05h SYS_EXEC        (package 28; argument block + startup block at 0080h: 28b)
10h FS_OPEN     11h FS_CLOSE    12h FS_READ     13h FS_WRITE
14h FS_SEEK     15h FS_STAT     16h FS_OPENDIR  17h FS_READDIR
18h FS_CLOSEDIR 19h FS_MKDIR    1Ah FS_RMDIR    1Bh FS_UNLINK
1Ch FS_RENAME   1Dh FS_CHDIR    1Eh FS_GETCWD   1Fh FS_SYNC
```

There is no `FS_STATFS` and no `FS_TRUNCATE` in M9 (architecture 32.26).
Truncation to zero is `FS_OPEN` with `ZFS_O_TRUNC`.

Limits and metadata are in `include/zephyros/fs.h`: `ZOS_PATH_MAX 128` and
`ZFS_NAME_MAX 64`. Both count the terminating NUL, so the longest path is 127
bytes and the longest component is 63. `zfs_stat` and `zfs_dirent` use the
exact section 32.25 layout. `zfs_dirent.name` is NUL-terminated. There is no
`zfs_statfs` in M9. Flags:

```c
#define ZFS_O_READ   0x01u  #define ZFS_O_WRITE 0x02u  #define ZFS_O_CREATE 0x04u
#define ZFS_O_EXCL   0x08u  #define ZFS_O_TRUNC 0x10u
#define ZFS_SEEK_SET 0u     #define ZFS_SEEK_CUR 1u    #define ZFS_SEEK_END 2u
```

Pin every structure with `_Static_assert` and host tests in the same way as
`zioc_frame`.

## Pinned kernel decisions

- Headers:
  - `include/zephyros/fs.h` is the native application ABI.
  - `include/zephyros/vfs.h` is the provider ABI: `struct zfs_provider
    {name, ops, provider_state}` and the path-based `struct zfs_ops` exactly
    as in architecture 32.12. It is module-facing and must pass the package
    22 module-header boundary checks.
  - Kernel-only VFS APIs (init, phases, kernel file API, descriptor pool,
    process hooks) belong in `kernel/vfs/vfs.h`.
- **Provider paths** are provider-relative, absolute (`/`-rooted), already
  normalized, NUL-terminated and at most 127 bytes. Providers implement ASCII
  case-insensitive matching themselves. VFS compares only the first
  component against root-level mountpoints. There is no node object, lookup,
  release or per-component traversal in VFS.
- **Mount selection is flat.** If the first component matches a `MOUNTED`
  root-level mountpoint, that mount owns the path; otherwise `/` owns it.
  The provider path is the remainder, or `/`.
- **VFS has no cache**, no generation tracking and no object identity.
  Caching is provider policy; IOC-FAT's cache is specified in package 30 and
  architecture 32.19.
- **Descriptor pool.** One global `_DATA` pool of 8 entries, owner-tagged:
  - Each entry holds the owner pid, `FREE`/`FILE`/`DIRECTORY`, mount index,
    provider handle, uint32 offset and access flags.
  - The fd a process sees is the pool index, and every operation verifies
    the owner.
  - Exhaustion returns `ZOS_EMFILE`.
  - Process exit closes every entry owned by that pid.
- **CWD storage.** One canonical CWD (at most 128 bytes) per *active process
  chain level*, in a static pool of `ZOS_EXEC_MAX_DEPTH` (4) entries
  allocated at process start and released at exit. The kernel launcher's
  CWD is the constant `/`.
- **No dynamic allocation in VFS.** One shared static 128-byte pathname
  scratch buffer, plus a second one only where an operation needs two paths
  (`rename`).
- **Gate-stack discipline.** Syscalls run on the 256-byte common gate stack.
  VFS, providers and loaders keep paths, dirents and transfer data in static
  bank-7 workspace. An automatic object larger than 32 bytes is a review
  defect.
- **Staging.** The single 512-byte transfer staging buffer lives in bank-7
  runtime data, never in common memory.
- **Driver ABI v3** (package 26) adds `int (*fs_register)(const struct
  zfs_provider *)` to `zdriver_api`. The loader accepts only ABI 3, and every
  module is rebuilt. The module resource imports (`resource_size/read`) are
  served through the single ROMFS lookup (correction-02); keep their current
  DATA-only rule unless the package says otherwise.
- A successful VFS bootstrap prints nothing. The production
  `config/mounts.json` contains only `/SYSTEM` until package 30 adds `/`.

## Bank-7 budget (architecture 32.39)

Decision (project owner, 2026-10-04): M9 stays within bank 7. There is no
second kernel bank, overlay or far-call mechanism. The architecture trim plus
size discipline is the strategy. Targets for the end of M9, within
`2000h-DEFFh`:

```text
production arena floor  >= 32 granules, holding the production boot set
runtime data      derived; reviewed like code
slack             >= 1 KiB  (lowered from 2 KiB on 2026-10-05, see below)
```

- Package 25b introduces size-optimized kernel and module compiles, the
  derived data base (`arena_end = data_base = align_down(DF00h - data_size,
  512)`) and the `bank7:` ledger line.
- Every package reports the ledger before and after, and the bytes its own
  code and data add.
- Gates: the production arena keeps at least 32 granules and holds that
  package's production boot set. Exceeding a gate or a target is
  stop-and-report. Never raise a ceiling or lower the floor.
- Size discipline:
  - no 32-bit arithmetic where 16 bits suffice;
  - no duplicated helpers;
  - shared argument validation;
  - mutation pointers left null in read-only providers;
  - no feature without a consumer;
  - no hand-written assembly for size unless the supervisor asks for it.
- Kernel, module and data bytes are interchangeable within the window, so
  the only targets are the arena floor and total slack (architecture 32.39,
  revised at the post-26 checkpoint). There are no separate kernel or module
  limits.
- **Checkpoint after package 26: passed 2026-10-05.**
  - Measured: `bank7: code 23526 bytes end 7BE6h | arena 46 granules (20
    boot, 26 free) | data 1501 bytes at D800h | isr 256 | slack 291 bytes`;
    package 26 density about 6-7 bytes per line.
  - Projected end-of-M9 slack: 1.4-3.2 KiB.
  - Project-owner decision: continue, with two measures. Package 28 sizes its
    exec frame saves from the measured worst-case gate-stack depth, and the
    IOC-FAT cache defaults to 1 slot.
- **Checkpoint after package 28: passed 2026-10-05.**
  - Measured: `bank7: code 28159 bytes end 8DFFh | arena 36 granules (20
    boot, 16 free) | data 2113 bytes at D600h | isr 256 | slack 191 bytes`.
    Common memory: 1410 code + 822 data of 7424 bytes.
  - Package 28 cost 400 bytes of bank-7 code against a 1 KB target.
  - The kernel ends one byte below a granule boundary, so any kernel code in
    29/30 costs one granule.
  - Worst-case gate-stack depth is 207 of 256 bytes.
  - Projection for package 30, with IOC-FAT at about 4.5-5.5 KB (9-11
    granules) and the kernel crossing one boundary: arena 35 granules, boot
    set 29-31, end-of-M9 slack about 2.2-3.2 KiB with **one** cache slot.
    A second slot costs one more granule and puts the low end under the 2 KiB
    target.
  - Decision: `IOCFAT_CACHE_SLOTS = 1`. Package 30 may raise it to 2 only if
    its measured final ledger still shows at least 2.5 KiB of slack with 2
    slots. Before package 30 builds IOC-FAT, the gate-stack depth through
    IOC-FAT must be measured (see package 30).
- **After 28b/28c (2026-10-05):** `bank7: code 28431 bytes end 8F0Fh |
  arena 35 granules (20 boot, 15 free) | data 2241 bytes at D600h | slack 63
  bytes`; common 2104 of 7424 bytes. 28b cost +272 bytes of code (the
  predicted granule). 28c changed no kernel or module byte. The worst-case
  gate-stack depth is 213 of 256 bytes.
- **Package 30 budget stop (2026-10-05).** The complete IOC-FAT provider
  measured 7441 bytes (15 granules) and exactly filled the arena (0 free,
  63 bytes of slack). Project-owner decision: trim IOC-FAT to at most 13
  granules, **keep the one-slot cache**, and **lower the end-of-M9 slack
  target to at least 1 KiB** (package 30 correction-01).

## Static mount table: from JSON to VFS

Mount policy exists in exactly one place: the selected JSON manifest. VFS
source contains no paths, provider names or sources.

Architecture section 32.33 is the normative description of this flow. This
section adds only the implementation names and values the architecture leaves
open: file paths, Makefile variables, capacity 4 and flag values.

**Inputs.** The manifest file is selected per image by the Makefile variable
`ZOS_MOUNTS`. It defaults to `config/mounts.json`; acceptance builds point it
at `tests/m9/mounts-*.json`. The list of providers linked into the kernel is
set by `ZOS_VFS_BUILTIN := romfs`.

**Generator.** `tools/mountgen.py <manifest> --builtin <names> --out
build/generated/vfs_mounts.c --report build/generated/vfs_mounts.json`

- The generator never rewrites the policy. It either emits it verbatim or
  rejects it.
- It applies every section 32.5.1 rule. It also rejects:
  - more than `VFS_MAX_MOUNTS` (4) entries;
  - a mount path that is not upper-case ASCII or that has a trailing `/`
    (only `/` itself may end in a slash);
  - a `system` entry whose `filesystem` is not in `--builtin`;
  - `required` present on the system entry.
- Its output is deterministic: no timestamps, no hashes of absolute paths,
  and byte-identical across rebuilds, so `make check` reproducibility holds.
- The output is generated under `build/` only and never committed.
- The rule depends on the manifest, `tools/mountgen.py` and the Makefile
  variables, so changing any of them rebuilds the kernel.

**Generated C** (the only content of `vfs_mounts.c`):

```c
#include "kernel/vfs/mount_config.h"

const struct vfs_mount_config vfs_mount_table[] = {
    { "/SYSTEM", 7u, "romfs",  "recovery", VFS_MOUNT_SYSTEM   },
    { "/",       1u, "iocfat", "ioc.0",    VFS_MOUNT_OPTIONAL },
};
const uint8_t vfs_mount_count = 2u;
```

- Entries are emitted in manifest order.
- Flags: `VFS_MOUNT_SYSTEM 0x01`, `VFS_MOUNT_REQUIRED 0x02`,
  `VFS_MOUNT_OPTIONAL 0x00` (that is, `required: false` or absent).
- The table is `const`, so it links into the ROM-loaded bank-7 kernel image.

**Config record.** `struct vfs_mount_config { const char *path; uint8_t
path_len; const char *filesystem; const char *source; uint8_t flags; }` is
declared in the kernel-private `kernel/vfs/mount_config.h`. It is neither a
native ABI nor a module ABI.

**Runtime state.** VFS keeps a separate `_DATA` array `vfs_mount_state[4]`
indexed in parallel with the config table. Each entry holds the state
(`UNMOUNTED`, `MOUNTED` or `FAILED`), the provider pointer, the `fs_state`
and the last error code. VFS never writes the config table.

**Boot use.**

1. Bootstrap: `vfs_init()` registers the built-in providers. It then finds the
   single entry flagged `VFS_MOUNT_SYSTEM`, and panics if there is not exactly
   one. This is a defensive recheck of a rule the generator already enforces.
   It looks the provider up by name (case-insensitive) in the provider
   registry and calls `ops->mount(provider_state, source, &fs_state)`. The
   `source` string is passed through as an opaque, NUL-terminated pointer
   into the table.
2. Mount phase: VFS walks the remaining entries in table order, applying the
   same lookup and mount call plus the required/optional failure rules.

**Path resolution.** Resolution uses only `MOUNTED` entries and is flat (see
"Mount selection is flat" above). The provider-relative remainder always
starts with `/`.

**Root merge.** The root directory merge lists the `MOUNTED` entries whose
path has exactly one component.

**Tests.**
- Host tests run the generator on the production manifest and on every
  `tests/m9` manifest, and compare the report JSON.
- A negative test covers each rejection rule.
- A test checks that `ZOS_VFS_BUILTIN` names exactly the providers the
  kernel's built-in registration table registers.

## IOC FS2 service (IOC-FAT backend)

Authoritative sources: `Code/MCU/IOController/include/ioc_frame.h` (FS2 block,
`IOC_STATUS_FS2_*`), `src/fs2.c`, `tools/test_fs2_contract.py`. The CP/M client
reference is `Code/HOST/CPM2.2/src/drivers/storage/native_vfs.inc` and `fat.asm`.

- Commands `30h-44h` and responses `B0h-C4h`: CAPS, GENERATION, RESET, ROOT,
  PUSH, OPEN_RO, READ, CLOSE, OPENDIR, READDIR, CLOSEDIR, STAT, SPACE,
  OPEN_RW, WRITE, SYNC, TRUNCATE, UNLINK, RENAME, MKDIR, RMDIR.
- CAPS v1 reports flags, a uint32 media generation, chunk max 512, 2 file
  slots, 1 directory slot, a 16-component resolver, and 2-byte tokens.
  `IOC_FS2_CAP_READ_ONLY` is set when the firmware is built read-only, so the
  provider must honor it.
- Names are packed 11-byte, space-padded FCB 8.3 forms. The resolver is
  stateful: ROOT resets it to `/`, and PUSH descends into one existing
  directory component. Name operations resolve against the current resolver
  path. RENAME is same-directory only.
- Tokens encode a slot plus a cookie. A closed or reused slot yields STALE.
  Media failures advance the generation and drop every MCU context.
- READ and WRITE carry an explicit uint32 offset and a uint16 length of at
  most 512. Success is an M8 READY reply followed by the bulk phase. A write
  is committed only on a matching DONE. `RSP_FS2_READ`/`RSP_FS2_WRITE` and the
  volume classes below are already in the IOC driver's frozen bulk-arming
  gate, so M9 does not change `drivers/ioc/`.
- Status mapping (provider-owned, never VFS):

```text
NOT_FOUND 40h ENOENT   EXISTS 42h EEXIST    BAD_NAME 43h EINVAL
READ_ONLY 44h EROFS    NO_SPACE 45h ENOSPC  NOT_DIR 46h ENOTDIR
IS_DIR 47h EISDIR      STALE 49h ESTALE     RANGE 4Ah EINVAL
NO_MEDIA 4Bh ENODEV    TRANSPORT 4Ch EIO    UNKNOWN_WRITE 4Dh EIO
IO 4Eh EIO             NO_HANDLE 48h  EMFILE on open/opendir, else ESTALE
END 41h -> readdir end of directory (success, no entry)
```

- FatFs reports a non-empty `rmdir` as FR_DENIED, which FS2 maps to READ_ONLY.
  The provider therefore checks emptiness with OPENDIR/READDIR before RMDIR
  and returns `ZOS_ENOTEMPTY` itself.

## IOC volume units (future ZDEV_BLOCK backend; not built in M9)

Recorded for the first native-filesystem milestone that needs `sd-ioc.zmod`.
M9 defines only the `ZDEV_BLOCK` class and `block.h` (package 29).

Normal firmware does not serve raw-card bulk (`05h`/`07h` are diagnostic-only).
The production raw-block service is volume-relative. It has two units (0 and
1), which are auto-mounted CP/M images `/CPM/CPM_1.DRV` and `/CPM/CPM_2.DRV`
(or raw mode):

- `CMD_VOL_INFO 11h` returns mode, extents, base LBA, a 128-byte record count,
  the name and guard state.
- `CMD_SD_READ_BLOCK 0Fh` takes a uint32 512-byte block number plus an
  optional unit byte at DATA offset 4. It replies with READY plus an LBA echo
  that must be checked, then 512 bulk bytes.
- `CMD_SD_WRITE_REC 09h` takes a uint32 128-byte record plus the unit. It
  replies with READY, then a 128-byte bulk write, then the DONE query.
- `CMD_SD_FLUSH 0Ah` flushes the MCU record cache.

These volumes hold the user's CP/M data. Any future hardware write test must be
opt-in and must save and restore the block it touches.
