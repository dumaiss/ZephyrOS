# Task

M10 step 8 (architecture 36.24): **consolidate the test, tool and build
scaffolding.** The production image is byte-identical. Outcome coverage
stays; duplication and retired-model machinery go.

Baseline (supervisor inventory after package 41):

| item | size |
|---|---|
| Python tests | 18,700 lines in 39 files, 14 replay harnesses, 9 with their own boot/replay code |
| target test programs | 11,300 lines |
| tools | 8,200 lines (`zmodpack` 2.3k, `mapcheck` 1.9k, `pack_image` 1.1k) |
| simulator | 2,600 lines |
| Makefile | 2,210 lines, 17 self-test images, 30 conditionals |

## Context

Read:
- `work/00-WORKER.md` (Tests section);
- the package-42e record (42d runs after 42e).

**Before starting:** confirm `make check` is green on the 42e tree.

## Requirements

1. **One replay helper module.** Put boot, run-until, the guarded
   serial-delay skip, transcript capture and stack/ledger readers in one
   module (in or beside `tests/z80sim.py`). Every replay harness uses it,
   and the per-file copies are deleted.
2. **The image matrix.** List every self-test image with what it uniquely
   covers.
   - Merge or delete images whose coverage another image already
     provides.
   - Target about 8 images or fewer: production, console-serial,
     IPC, `fs-selftest`, `ns-selftest`, plus whatever the
     coverage table proves necessary.
      - Report build and replay time before and after.
   - **Known problems from 42e:**
     - `romfs-corrupt-selftest` does not build (its boot set `sio
       console-serial` and its store, the production manifest, disagree);
       repair it or fold its coverage elsewhere;
     - `tests/test_romfs_sim.py` still reads the deleted `arena.plan.json`;
          - on hardware, the console-integration self-check prints `FAIL read`
       because it expects input to be ready immediately (the keyboard
       works). Make the read check wait for a key, or drive it from the
       serial host sync. Bring `tools/serial_smoke.py`'s expected strings
       in line with the current transcripts in every mode (no M8
       `class`/device-count/`PING` tokens);
     - `ipc-selftest`'s replay takes **about 17 minutes**. Cut it to a few
       minutes by replaying once and asserting outcomes, not trace
       censuses; drop checks that duplicate other images.
3. **Makefile.** *(Table-driven generation DROPPED by supervisor steer, 2026-10-10: deletions only.)*
   - Define the images as one table (name, sources, manifest, flags) that
     generates the targets.
   - Delete dead variables, conditionals and targets.
   - Report the line count before and after.
4. **Tools.** Remove the rules for retired models from `mapcheck`,
   `pack_image` and `zmodpack`:
   - the M9 `bank7:` budget;
   - arena and granule rules;
   - two-bank evaluation paths;
   - module-format branches gone after 42c.
5. **As-built docs.** Bring `docs/memory.md`, `docs/devices.md`,
   `docs/abi.md`, `docs/module-format.md`, `docs/vfs.md` and
   `docs/filesystem.md` into line with the tree. Remove pre-M10 text that
   no longer describes anything.

## Constraints

- The production hash is unchanged.
- Every behaviour covered before is still covered by an outcome test.
  Give a short coverage map (old test → where its outcome is now checked)
  for anything merged.
- Aim for 20-30% fewer test and tool lines, and a shorter
  `make check` + image batch. Report the actual figures.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-scaffolding.md`.

## Validation (once, on the final source)

```sh
make clean && make check
make <every image in the new matrix>
git diff --check
```

## Acceptance criteria

- One replay helper, a table-driven image matrix, and no retired-model
  rules in the tools.
- The production image is byte-identical, and coverage is preserved.
- The measured reductions are reported.
