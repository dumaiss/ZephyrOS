# Package 42d progress (M10 scaffolding consolidation)

Working state for `work/42d-m10-scaffolding/WORK.md`. Report:
`docs/validation/2026-10-10-m10-scaffolding.md`.

## Baseline (42e tree, 2026-10-10)

- `make clean && make check` exit 0, 60 s wall; reproducible rebuild
  `6e437af55c436c3d4a95275c098beea6da79cc5783c5879f374d4f7ccc5b9c20`;
  host suite **562 tests, 0 failures, 112 skipped** (22 s).
- Line counts before: Makefile 1901; python tests 17,581
  (tests/*.py + tests/subsys/*.py, z80sim.py 2643); tools 7,156;
  target C test programs 4,324; 15 image targets (13 acceptance + the
  production and helloworld builds).
- Known problems from 42e to fix: broken `romfs-corrupt-selftest`
  (boot set vs production store), `test_romfs_sim._derive_scratch` reads
  deleted `arena.plan.json`, console-integration read check fails on
  hardware, `serial_smoke.py` M8-era strings, `ipc-selftest` replay 1021 s.

## Log

- 2026-10-10: package started; baselines recorded; inventory under way.

## Plan (decided after inventory)

Target matrix (self-test images, 8):

| image | unique coverage | change |
| --- | --- | --- |
| production | byte-identical reference; store + monitor | none |
| subsystem-selftest | syscall gate, IRQ, ROMFS reader, process/ZEX, + nucleus gates/upcall | absorbs nucleus image + replay |
| console-integration-selftest | full production stack: integration + ioc + hid + video diagnostics, ESC c, monitor session | absorbs console-selftest + the three device images |
| console-serial-selftest | serial console lane | keep |
| console-serial-fail-selftest | required-driver halt | keep |
| fs-selftest | FS2 outcomes / handles / nested exec | keep |
| ns-selftest | namespace + typed handles | keep |
| ipc-selftest | IPC substrate conformance | keep, replay cut to outcomes |
| (folded) romfs-corrupt | corrupt-store rejection | folded into the subsystem replay as an in-ROM patch (same bytes corrupt_romfs.py writes) |
| (kept) helloworld-image | SDK demo boot | unchanged (demo image, not in the self-test matrix) |

Test files: helper `tests/replay.py`; `test_nucleus_sim.py` and
`test_console_sim.py` merge away; ioc/hid/video replays point at the
integration image; retired-machinery sections of `test_romfs_sim.py`
deleted.  Tools: mapcheck/pack_image/zmodpack rules for the retired
models removed.  Makefile: keep the plain per-image blocks; delete the
dead conditionals, variables and targets for the merged images.

## Decision (supervisor, 2026-10-10)

The `$(eval)`/`$(call)` image table was reverted: the Makefile keeps its
plain per-image `ifeq` blocks and only loses the retired images with
their dead variables, conditionals and targets.  Everything else in the
package stands.

## Progress

- **Replay helper**: `tests/replay.py` carries boot, the guarded
  serial-delay skip, run-until with marker settle, the transcript and
  stack/ledger readers, `ConsoleReplay` (glyph model) and
  `IntegrationInputs`; every image replay uses it, and the per-file
  copies are gone (`test_subsys_sim.py`, `test_romfs_sim.py`,
  `test_nucleus_sim.py`, `test_ioc_sim.py`, `test_hid_sim.py`,
  `test_v9958_sim.py`, `test_console_acceptance.py`,
  `test_console_serial.py`, `test_fs_selftest_sim.py`,
  `test_ns_selftest_sim.py`, `test_sdk.py`).
- **Images merged**: console-integration absorbs the console binding
  image and the IOC/HID/V9958 device images (one image, four replays);
  the subsystem image absorbs the ROMFS replay; the corrupt-store image
  is folded into `test_romfs_sim.py` as an in-ROM header patch; the
  nucleus image stays its own row (its group does not fit the subsystem
  ledger).  Targets now: subsystem, nucleus, console-integration,
  console-serial (+ fail store), fs, ns, ipc, helloworld.
- **Known fixes**: corrupt-store coverage in `test_romfs_sim.py`; the
  stale `arena.plan.json` reader replaced by a geometry-derived scratch;
  the integration diagnostic waits for its key
  (`INTEGRATION_POLL_BUDGET`, `uint32_t` poll counter) instead of
  printing `FAIL read` on hardware, and the smoke tool tells the
  operator to type `K41`; `tools/serial_smoke.py` reduced to the five
  current modes with current transcripts; `test_ipc_selftest_sim.py`
  reduced from a per-instruction tracer to one outcome boot
  (1021 s -> 330 s, 1846 -> 529 lines).
- **Tools**: mapcheck's dead `_module_loader_load` cold-symbol rule and
  zmodpack's dead `required_granules` field are gone (the arena/granule,
  two-bank and M9 `bank7:` rules had already been removed by 42b/42c;
  the Makefile's dead `ZOS_*_SELFTEST` selects are gone too).
- **Docs**: README's build/smoke lists, `docs/boot.md` (corrupt store,
  smoke modes, coverage sentence), `docs/devices.md` (the four device
  sections, the console-driver section, the acceptance list),
  `docs/architecture.md` (section 31 coverage sentence),
  `docs/abi.md` (syscall/IRQ/M6/M7 validation targets, the IPC replay
  description), `docs/memory.md` (the IPC replay and subsystem rows,
  the self-test common block) and `docs/vfs.md` (the `--mode normal`
  note) are back in line with the tree.

## Validation (final source, 2026-10-10)

- `make clean && make check`: exit 0, 93 s (two cold builds 36 s each +
  the host suite 21 s); `check: reproducible rebuild
  (6e437af55c436c3d4a95275c098beea6da79cc5783c5879f374d4f7ccc5b9c20)` -
  the 42e hash, unchanged.
- Full matrix from clean (573 s, exit 0): `all`, `subsystem-selftest`,
  `nucleus-selftest`, `console-integration-selftest`,
  `console-serial-selftest`, `fs-selftest`, `ns-selftest`,
  `ipc-selftest`, `helloworld-image`; every image's replay suites green.
- Host suite with the matrix built: 547 tests, 0 failures, 4 skipped,
  511 s (the ipc replay is 338 s of it).
- `git diff --check`: clean.
- Reductions: Makefile 1900 -> 1702 lines; python tests 17,581 -> 15,843
  (36 -> 35 files); tools 7,156 -> 6,698; target test programs 6,354 ->
  6,232 (50 -> 48 files); image builds 14 -> 8 (15 -> 9 images);
  ipc replay 1021 s -> 338 s; `serial_smoke.py` 1070 -> 614 lines.
- Report: `docs/validation/2026-10-10-m10-scaffolding.md`.
