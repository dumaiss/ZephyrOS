# Task

Implement the bank-7 and common-memory reclaim findings that the project owner
selected from the package-30b audit, pin the common-memory ceiling, and leave
M9 at its optimized ledger before acceptance.

## Context

The selection below was made by the project owner on 2026-10-05 from the
30b report (`docs/validation/2026-10-05-m9-reclaim-audit.md`). The
supervisor confirmed that F7's five functions have no callers (only their
definitions, declarations and comments reference them).

Dispatch only after package 30b is accepted and the selection is recorded
here. Read `work/00-WORKER.md`, the 30b report
(`docs/validation/<date>-m9-reclaim-audit.md`), architecture 32.39,
`docs/memory.md`, and `work/M9-REFERENCE.md`. There is no
backward-compatibility requirement.

## Selected findings

1. **F7 (B), dead kernel code, expected +1 granule.** Delete
   `zmod_validate_container` (`kernel/module/relocate.c`, 237 bytes),
   `module_load` (`kernel/module/loader.c`, 63), `vfs_path_normalize`
   (`kernel/vfs/path.c`, 28; callers use `vfs_path_normalize_at`),
   `vfs_provider_owner` (`kernel/vfs/mount.c`, 5) and `device_registry_owner`
   (`kernel/device/registry.c`, 5): 338 bytes. Remove their declarations
   (`include/zephyros/module.h`, `kernel/vfs/vfs.h`,
   `kernel/device/registry.h`), their `tools/mapcheck.py` bank-7 symbol
   entries, the `tests/maptools.py` fixture references and any stale comments
   (for example `loader.c` line ~26 on the "historical `module_load()`").
   Target: kernel code end at or below `8E00h` (30b: about `8DEAh`), arena
   36 granules.
2. **F3 (A), one kernel ASCII case-insensitive compare.** Replace
   `vfs_name_equal` (85), `romfs_name_match` (120) and `device_name_equal`
   (17) with a single kernel-private helper (for example `zos_ascii_equal_ci`
   in a small `kernel/lib/` or beside an existing kernel-private header). It
   is not module-facing; modules keep their own copies by isolation. Keep
   each caller's exact semantics (length or NUL termination, and ROMFS's
   bounded name field), with host and simulator tests covering mixed case,
   prefix-only matches and the length edges. Expected 60-120 bytes of extra
   code margin, 0 granules.
3. **F8 (B), dead V9958 function.** Delete the unused `static
   v9958_write_ctrl_byte` (36 bytes). `v9958.zmod` stays 9 granules. This is
   the only module change.

**Not selected:** F4 (the `SYS_EXEC` path buffer stays as package 28
designed it), F5, F1, F2, F6, F9 and F10. `iocfat` stays at 13 granules, with
its cache.

**Common-memory ceiling (owner-approved, from 30b section 5):** ceiling
**3072 bytes** of packed `_COMMON` + `_COMMON_DATA`, with a **512-byte M10
far-call reservation**, so M9 enforces **used ≤ 2560** (current 2104).

**Expected end-of-M9 ledger:** arena 36 granules (33 boot, 3 free), data
2241 bytes at `D600h` with 63 bytes of slack, so 1599 bytes of total slack;
common 2104 of the 2560 enforced limit.

## Standing requirements

- Implement **only** the selected findings. Report each with its measured
  before/after bytes and its actual granule effect.
- **Behavior is unchanged.** Every saving keeps the VFS/provider/driver
  layering and every acceptance behavior.
- **Pin the common-memory ceiling** (3072 bytes, with a 512-byte M10
  reservation) in the platform memory description
  (`platform/zephyr80/memory.{inc,h}`). Enforce it in mapcheck (fail the build when
  common use exceeds the ceiling minus the M10 reservation), and print it on
  the `common:` ledger line.
- Report the final `bank7:` and `common:` ledgers and the 30b granule-
  threshold table after the changes.

## Validation

At the `00-WORKER.md` efficiency defaults, run one formal batch in the
background:

```sh
make clean && make check
make subsystem-selftest m9-vfs-selftest m9-provider-selftest m9-fs-selftest m8-v9958-selftest
python3 -m unittest tests.test_subsys_sim tests.test_m9_vfs tests.test_m9_vfs_sim tests.test_m9_provider_sim tests.test_m9_fs tests.test_syscall_sim tests.test_v9958 tests.test_v9958_sim tests.test_pack_image tests.test_m8 -v
git diff --check
```

Suite choice: F7 and F3 touch the loader, VFS, ROMFS and registry
(subsystem, VFS, provider and FS images). F8 changes M8-owned V9958 code, so
`m8-v9958-selftest` is the one Mn-1 image this package builds (see the
`00-WORKER.md` Mn-1 rule). IOC-FAT is not touched.

Hardware: production boot with a FAT card: `make smoke-hardware` plus the
operator's V9958 check, which also covers the F8 V9958 rebuild (normal and
reverse text render, and the monitor answers a key).

## Acceptance criteria

- Every selected finding is implemented with measured savings, and nothing
  else changed.
- The common-memory ceiling is pinned, enforced and printed.
- All listed suites pass, and the final ledger is recorded for package 31.
