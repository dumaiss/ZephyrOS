# Task

M10 stage 1 (architecture 36.24, step 1). Make decoder **revision 13**,
the `6000h` window plus the mode-10 aperture (architecture 36.2), the
baseline. Remove from the tree every piece of machinery that implements an
option the architecture rejected, so that the code, the tools and the
documents describe only the M10 target of `docs/architecture.md` sections
35-37.

This package adds no M10 feature. The production image is byte-identical.

## Context

Read:

- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md`, especially "Rejected options: not guidance";
- `docs/architecture.md` sections 35-37, especially 36.2 and 36.24.

**Hardware is done.** The owner programmed the design that the tree
currently holds as `platform/zephyr80/hdl/MEM_DECODER_rev13d.pld`
(2026-10-07), and CP/M and the production ZephyrOS ROM both boot on it. From now on that design is
simply **revision 13**. Earlier evaluation decoders are not referred to by
revision name anywhere outside `docs/validation/` and `work/`.

The history of everything removed here is in git: commit `69cddf8` for the
package-33 spike, plus the package 34-36 trees. Later stages consult it
there; nothing is kept "for reference".

## Requirements

### A. Revision 13 is the baseline

1. **One decoder design.** Rename `MEM_DECODER_rev13d.pld`/`.si` to
   `MEM_DECODER_rev13.pld`/`.si`, replacing the `8000h` design that holds
   that name today, and set the `Revision` field to 13. Then:
   - `tools/rev13_vectors.py` generates only this design's vectors and the
     revision-12 cross-check file;
   - `tools/pld_terms.py` keeps only the variants needed to check this
     design's fit and minimum form;
   - `make rev13-pld` is the one PLD target: vectors, minimum form, WinCUPL
     compile and simulate when available, and the revision-12 cross-check.
     `rev13d-pld` disappears.
   - The PLD's header comment describes the design as revision 13. It does
     not mention letters or rejected variants.
2. **Simulator.** `tests/z80sim.py`'s memory decoder models revision 13,
   and revision 13 becomes the **default** for every build and test.
   - Revision 12 stays only as the reference that the P = 0 equivalence is
     proven against.
   - The window base is no longer a parameter.
   - A test replays every revision-13 vector through the simulator model.
   - A test proves that revision 13 equals revision 12 whenever P = 0, in
     every mode.
3. **Images are unaffected.** No existing image sets P outside ROM mode
   (mode 00 is unchanged), so every image behaves identically under the new
   default. Show this with the validation batch below. Do not change image
   code to make it so.
4. **Documents.** `docs/memory.md` (the as-built memory document) records:
   - the latch field D5-D7 (P);
   - the revision-13 mappings per mode;
   - the P = 0 rule;
   - that revision 13 is programmed.

   It points to architecture 36.2 for the target use. Remove the overlay
   and window-evaluation text it carries today.

### B. Remove the rejected options

Remove each item completely: sources, Makefile variables and targets, build
directories in `make clean`, tests, tools, fixtures and document sections.
`tests/test_source_layout.py` and similar inventories follow.

1. **Transport B (slot overlay):**
   - `MEM_DECODER_rev13b.pld` and `.si`;
   - the overlay model and variant in `tests/z80sim.py`;
   - the overlay paths in `tools/rev13_vectors.py`, `tools/pld_terms.py`
     and `tools/wincupl_build.sh`;
   - the overlay tests;
   - the transport-B spike image (`build-rsvc-spike-b`) and every B code
     path in the resident-service spike.
2. **The evaluation decoders and the package-34 evaluation:**
   - the `8000h` window design (today's `MEM_DECODER_rev13.pld`, replaced
     per A.1);
   - `MEM_DECODER_rev13c.pld` and `.si`, and `make rev13c-pld`;
   - the evaluation configuration `ZOS_REV13_EVAL`: `tests/target/rev13/`,
     `tests/test_rev13_eval_sim.py`, `tests/m10/manifest-rev13.json`,
     `rev13-classification.json`, `rev13-segments.json`,
     `make rev13-eval-selftest`;
   - the `8000h` paths in `tools/rev13_layout.py`.
3. **The package-33 M10 spike (`ZOS_M10_SPIKE`):**
   - `SYS_FAR_CALL` (`kernel/syscall/far.c`, `kernel/process/far.asm`),
     the auxiliary page zero and low window, and the far-entry table;
   - the spike's xmem, bank map and ZEX v2 loader
     (`kernel/syscall/xmem.*`, `kernel/process/bankmap.*`,
     `kernel/process/zex2prog.h`, and the v2 paths in `exec.c`,
     `process.c` and `syscall.c`);
   - `abi/zos/xmem.h` and the SDK xmem and far stubs;
   - `tests/target/m10/`, the `--zex-v2` path in `tools/zexpack.py` and its
     tests, `docs/zex-format.md` section 8, and `make m10-spike-selftest`.

   These encode the rejected layout: a low window, slots at
   `2000h-DFFFh`, zeroed objects and relocated segments. Stage 6
   re-implements xmem and ZEX v2 against architecture 36.15-36.18.
4. **The resident-service spike** (`ZOS_RSVC_SPIKE`) **stays**. Stage 3
   promotes its IPC substrate into the kernel. Reduce it to the single
   configuration the target uses:
   - transport A on revision 13 (the `6000h` split);
   - drop the `ZOS_RSVC_SPLIT` knob, so `make rsvc-spike-selftest` builds
     that one image;
   - keep `tests/m10/two-bank-classification.json` and
     `tools/rev13_layout.py --two-bank`; stage 2 uses them.
5. **Grep gate.** After removal, the tree outside `docs/validation/`,
   `work/` and git history contains none of these:

   ```text
   rev13b  rev13c  rev13d  "Revision 13b/13c/13d"  overlay (decoder sense)
   ZOS_REV13_EVAL  ZOS_M10_SPIKE  ZOS_RSVC_SPLIT  window_base
   SYS_FAR_CALL  zos_far  far_entry  build-rsvc-spike-b
   ```

   Show the command and its empty output in the report.

## Constraints

- **Production is byte-identical**: hash
  `f4da0496f2130fe718308b63a1ddf62160a9e584975a42d5400d54370693bcf7`.
  Production code changes only where it removes `#if ZOS_M10_SPIKE`
  blocks.
- Removal and renaming only. Fix nothing else you notice, including the
  production exec's whole-bank clear (architecture 36.19 is stage 6's).
  List such findings in the report instead.
- Do not edit `docs/architecture.md`, `work/M10-REFERENCE.md` or other
  packages. Report any conflict.

## Validation

```sh
make clean && make check                 # production hash unchanged; host suite
make m9-selftest                         # one integration image under the new default
make rsvc-spike-selftest                 # the remaining spike image
make rev13-pld                           # vectors, minimum form, WinCUPL if present, rev12 cross-check
python3 -m unittest tests.test_decoder_rev13 tests.test_rsvc_spike tests.test_rsvc_spike_sim -v
git diff --check
```

Add the grep gate (B.5). Build no other images and do not run
`unittest discover` after building images. Report the wall-clock time; the
target is under 20 minutes.

Write `docs/validation/<date>-m10-rev13-baseline-cleanup.md` with:

- what was removed, listed by item B.1-B.4;
- the line count removed;
- the batch results and the grep gate;
- the production hash;
- any findings left alone.

## Hardware

Done (owner, 2026-10-07): revision 13 is programmed, and CP/M and the
production ZephyrOS ROM both boot on it. Production stays byte-identical in
this package, so no further hardware run is needed.

## Acceptance criteria

- One decoder design, named revision 13. The simulator defaults to it. The
  P = 0 equivalence with revision 12 and the vector replay pass.
- Every item in B.1-B.4 is removed or reduced as specified, and the grep
  gate is empty.
- The production image is byte-identical. `m9-selftest` and the
  resident-service spike pass under the new default.
