> Worker package (strong model). Independent of 87/88. Test
> infrastructure only (`tests/`, the Makefile's test targets): no
> nucleus, driver, SDK or program change, and no test's assertions
> changed. Baseline: a tree where `make check` is green.

# Task

Port the simulator's Z80 core to C with identical semantics. A switch
selects the core; the whole suite must pass with either. The Python
peers (V9958, IOC/HID, sound, SIO) stay in Python. The goal is speed:
the Python core runs about 210k instructions/s, a boot is 13 s, and
`test_tui_sim` takes 35 min.

## Current state (`tests/z80sim.py`)

- **`Z80`:** registers as attributes; memory in `bank0`, `bank7`,
  `banks[1..6]` (64 KiB bytearrays) and `rom[n]`; `rd`, `wr`, `rd16`,
  `wr16`, `push16`, `pop16`; `bank_of`; `step`; `accept_interrupt`,
  `assert_int`; `io_in`/`io_out` (port 00h is the latch; SIO 22h/23h;
  IOC 32h/33h; V9958 A0h-A4h with `vdp_peer.now = cycles`; sound
  E0h-E4h).
- **`MemoryDecoder`:** revisions 12 and 13 (`test_decoder_rev13`).
- **Semantics the tests depend on:**
  - A block instruction is one `step()`, costed
    `opcode_cost` = 21 x count - 5 up front.
  - `cycles` counts instructions; T-states come from the
    `ONE_BYTE_T`/`ED_T`/`DD_T` tables (fallback 4).
  - `_clock(t)` runs before execution and advances `tstates`,
    `ctc.advance(t)` and `vdp_peer.advance(t, cpu)`.
  - HALT clocks 4 T per step; IM2 only; `ei_delay`.
- **Per-instruction Python:** `_clock` calls `Ctc.advance` (channel
  loop, interrupt offer) and `V9958Peer.advance` (frame flag, IE0
  interrupt) on every instruction. These must move into C, or the C core
  gains nothing.
- **Test loops:** about 45 call `z.step()` once per instruction. Each
  step also calls `replay.skip_delay(z)` (a PC + latch check, then pop)
  and `replay.feed(z)` (`input_driver`; only
  `test_ipc_selftest_sim` sets one). Every 0x1FFF steps they call
  `replay.pump(z)`. The hot ones:
  - `replay.py`: `crt0`, `run_to`, `run_until`, `run_until_count`;
  - `tests/test_tui_sim.py`: `_run`, `_render_interval`, `_boot`;
  - the `tests/test_ui_sim.py` of KonaEdit and KonaCommander.

Read: `work/00-WORKER.md`; `tests/z80sim.py`; `tests/replay.py`;
`tests/test_tui_sim.py`; the Makefile's `check` and `test` targets.

## Requirements

1. **C core** (Must).
   - **Location:** `tests/simcore/z80core.c` + `.h`, built by
     `make sim-core` into `build/sim/libz80core.so` (`cc -O2 -shared
     -fPIC`, no other dependency), loaded with `ctypes`. `make check`
     builds it first.
   - **Scope:** all of `Z80.step` (every opcode and prefix the Python
     core implements, with the same flag results, including whatever it
     does with undocumented bits), `opcode_cost`, interrupts (IM2,
     HALT, `ei_delay`), `MemoryDecoder` revisions 12 and 13, the latch
     port, and `_clock` with the `Ctc` and the `V9958Peer` frame clock.
2. **Shared state** (Must).
   - **Memory:** the C core works on the existing bytearrays through
     their buffers, with no copy, so tests that read or poke `z.bank0`,
     `z.banks[n]` or `z.rom[n]` see the same bytes. Bytearrays are never
     resized.
   - **Registers and fields:** registers and every `Z80` field tests
     touch (`pc`, `sp`, `hl`/`de`/`bc`, flags, `iff1`, `im`, `latch`,
     `cycles`, `tstates`, `halted`, `int_pending`, ...) are properties
     over a C struct.
   - **Timer state:** CTC channel state and counters (`expiries`,
     `delivered`) and the VDP frame fields (`frame_clock`,
     `frame_period`, `frame_flag`, `frames`, `frame_irqs`, R#1 IE0) live
     in C. The Python objects read and write them through properties, so
     their existing tests keep working. Find every reader with grep.
3. **I/O** (Must). An IN or OUT on any port other than 00h calls back
   into Python `io_in`/`io_out` unchanged. A peer that raises an
   interrupt (`assert_int`) sets the C fields.
4. **Run loop** (Must). Add `z.run(limit, stops=frozenset(),
   delay=(addr, latch))`.
   - **What it does:** it steps until one of these, and returns which:
     - `limit` instructions have run;
     - PC is in `stops` (checked before each instruction);
     - the CPU is halted with no possible wake-up.
   - **Delay skip:** at `delay` it does what `skip_serial_connect_delay`
     does, inline.
   - **Move the hot loops** to `run(0x1FFF, ...)` chunks with `pump`
     between them. The order of events seen by peers and tests must not
     change.
   - **Watch-address checks:** checks such as a console dispatch PC
     become `stops`, and the Python check runs only on a hit.
   - `step()` stays for every other caller.
   - **Python core:** implements `run` too, as a plain loop, so both
     cores share one test code path.
5. **Switch** (Must). `KOS_SIM_CORE=python|c`. The `Z80(...)`
   constructor returns the selected core with the same signature, and
   the default stays `python` in this package.
   - `make check SIM_CORE=c` runs the whole suite with the C core.
   - A missing library is a clear error naming `make sim-core`, never a
     silent fallback.
6. **Lockstep** (Must). `tests/test_sim_core.py`:
   - **Opcode fuzz:** 200k random instructions, all opcode pages
     (plain, CB, ED, DD, FD, DDCB, FDCB), from random register and
     memory states. After each, compare all registers, flags, `cycles`,
     `tstates` and the written bytes.
   - **Boot lockstep:** both cores side by side through the production
     boot to the shell, and through `tui_test foundation` on both lanes.
     Compare the full state at every instruction and the I/O call
     sequence. The first divergence is reported with its PC and
     instruction.
   - It is skipped, with the reason, when the library is not built.

## Budgets

| figure | now (Python) | C core | on overrun |
|---|---|---|---|
| boot to shell | 13 s | <= 0.5 s | report with a profile |
| `test_tui_sim` | ~35 min | <= 5 min | report with a profile |
| `make check` (sim share) | ~40 min | report | informational |
| test count, assertions | - | identical on both cores | stop and report |

## Criteria

- **Must:** requirements 1-6. `make check` is green with
  `SIM_CORE=python` and with `SIM_CORE=c`, with the same test count.
  The lockstep tests pass.
- **Should:** the budgets.
- **Informational:** wall time per simulator module on each core. Record
  any Python-core behaviour that looks like a model bug: report it and
  copy it faithfully, never fix it here.

## Rules

- **Semantics:** do not change them, even where they differ from real
  silicon. Correcting the model is a separate decision.
- **No contorting:** never change a test to make the C core pass. A
  divergence is a core bug until the lockstep shows otherwise.
- **Develop with targeted tests:** `test_sim_core` and single tests by
  dotted name. Run `make check` with each core once, at the end.

## Validation

```sh
make sim-core
python3 -m unittest tests.test_sim_core
KOS_SIM_CORE=c python3 -m unittest tests.test_tui_sim   # once
make clean && make check                     # once, Python core
make clean && make check SIM_CORE=c          # once, C core
git diff --check
```

Record: `docs/validation/<date>-c-cpu-core.md`.
