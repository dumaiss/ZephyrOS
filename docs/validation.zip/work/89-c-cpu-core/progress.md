# 89 progress

## Done

- **`tests/simcore/z80core.c` + `.h`:** a transliteration of `Z80.step`,
  `step_ed`, `step_cb`, `step_prefix`, `alu`, `_logic` and the rest, in
  the same branch order.
  - **Covered:** `opcode_cost`, IM2, HALT and the EI delay, decoder
    revisions 12 and 13, the CTC's `advance`.
  - **Python callbacks:** other ports call `io_in`/`io_out`. The V9958
    frame clock calls back while `frame_period` is set (only
    `test_vblank`).
  - **Errors:** stop the step where they happen, as the Python raise
    does.
  - **`core_run`:** PC stops (before an iteration), the serial-connect
    skip, and stops after a step that wrote a given port or left the CPU
    halted.
- **`tests/simcore/core.py`:** a `CZ80` subclass of the Python `Z80`.
  - **State:** registers and counters are properties over the ctypes
    struct. Memory is the same bytearrays, through their buffers.
  - **Callbacks:** they go through the instance's `io_in`/`io_out`
    attributes, so the CTC's and tests' wrappers work. Exceptions are
    stored and re-raised by `step()`/`run()`.
  - **The CTC:** an attached CTC is rebound to C state, with channel and
    counter views.
- **`tests/z80sim.py`:**
  - `PythonZ80` is the reference.
  - `KOS_SIM_CORE=python|c` selects `Z80`. A missing library raises,
    naming `make sim-core`.
  - New: `Z80.run` (the reference loop) and `StopSet`.
- **`tests/replay.py`:** `drive()` is the replay loop by chunks, with
  watched-PC hooks and the periodic tick at the same states as the
  per-step loop.
  - Moved to it: `run_to`, `run_until_count`, `run_to_pattern`, `crt0`,
    and `call` without `on_step`.
  - `run_until` without `on_step` stops on SIO-data writes, keeping its
    quiet count and returns exact.
- **Moved to `drive()` in the tests:** `test_tui_sim` `_run` and the
  serial `_boot`; KonaEdit and KonaCommander `wait_for_input_loop` and
  `press_and_measure` (the return-to-getkey condition is computed
  exactly from the stop count).
- **Makefile:** `sim-core`; `test`/`check-fast` build it;
  `SIM_CORE ?= $(or $(KOS_SIM_CORE),python)` is exported as
  `KOS_SIM_CORE`.
- **`tests/test_sim_core.py`:**
  - an opcode fuzz: 200k random instructions, every page, random latch
    modes; state, port calls and memory compared;
  - replay lockstep: boot plus `tui_test foundation` on both lanes,
    compared at every instruction.
  - Both pass. Two planted bugs (an inc flag, a DD T-state cost) are
    caught by the fuzz.

## Figures

- `test_tui_sim` foundation, both lanes: 53.6 s (Python core) -> 0.6 s
  (C core).

## Validation

- Done: see docs/validation/2026-10-24-c-cpu-core.md (both cores green, C core the default).
