# 100c03 progress

STATUS: COMPLETE

- Verified the tree is clean with `git status --short` before edits.
- Read `work/00-WORKER.md`, this package's complete `WORK.md`, the 98,
  100c01 and 100c02 validation records, and the named sound sources/tests.
- Current implementation matches the package's stated baseline: an 8-byte
  run-list slot plus due/wait lists in `snd_voice.asm`, per-chip changed-slot
  queues in `snd_out.asm`, and one deferred flush from `snd_tick.asm`.
- Implementation direction: fixed 16-byte assembly-owned descriptors walked
  linearly in voice order; cursor/wait/active plus precomputed port, latch and
  desired/shadow pointers; write-through `snd_put_*` primitives; output flush
  reduced to invalid-shadow rewrite and BATCH send.
- Next action: replace the dead queue/list machinery, update initialization and
  private declarations, then build before changing acceptance tests or docs.

- First incremental `make -j2` failed in `snd_voice.asm:203`: sdasz80 cannot
  encode `_snd_noise_force - _snd_desired_noise` because the symbols are owned
  by another module. Classification: implementation. The descriptor already
  carries the chip in its flag byte; next action is to address
  `snd_noise_force[chip]` directly from that precomputed chip field.
- Second incremental build reached `snd_out.asm` and failed on two `jr` branches
  to the distant batch-send tail (lines 268 and 279). Classification:
  implementation. Next action: use absolute `jp` for those non-local branches.
- Focused replay (`TestSndTones`, `TestSndAdsr`, `TestSndNoise`) built but three
  modes hung/crashed before PASS (one host-only compiler test passed).
  Classification: implementation. Evidence: the new C-callable assembly entry
  points and `snd_engine` clobber IY, which SDCC uses as a preserved frame
  register. Next action: preserve IY at every C boundary, including the engine
  reached through `snd_tick`, then rerun the same focused block.
- The rerun progressed into sound output but tones/ADSR faulted and noise did
  not finish. Classification: implementation. Inspection found the full rewrite
  loop letting `_rewrite_emit` clobber BC: the attenuation loop loses its loop
  count and the tone path loses its period bytes between the pair's two emits.
  Next action: preserve BC across those emitter calls and rerun the same block.
- The next focused run completes but tick 0 contains immediate voice writes
  followed by the 44-byte invalid-shadow rewrite. Classification:
  implementation. The accepted trace requires the first voice results to be
  folded into that one rewrite. Next action: when a descriptor's chip shadow is
  invalid, each `snd_put_*` updates desired state and returns without emitting;
  the tick-end straight rewrite then publishes the final desired state once.
- Focused rerun: tones and noise pass; ADSR tick 0 advanced to attenuation 9
  instead of 12. Classification: implementation. The WAIT handler checked the
  restored program cursor for zero instead of the remaining tick count, so it
  crossed every WAIT during a one-tick call. Next action: test remaining before
  restoring the cursor, then rerun ADSR and the broader core modes.
- Broader core run: tones, ADSR, noise, modes and catch-up pass; close emits a
  44-byte rewrite instead of only the three changed mute bytes.
  Classification: implementation. Next action: have close run the descriptor
  engine with zero elapsed to commit pending silences through the normal
  compare-and-write path, then flush BATCH, without invalidating a known shadow.
- New primitive test passes. The stagger DIRECT run passes, but `stagger batch`
  is rejected by the generic one-argument mode guard before dispatch.
  Classification: implementation (test command exercises the specified BATCH
  mode). Next action: dispatch stagger with its optional validated `batch`
  argument before the generic guard, then rerun both new tests.
- The rerun reaches BATCH tick 1 but all twelve entries target chip 0.
  Classification: implementation. `_descriptor_emit` still rotates four places
  from an earlier high-nibble chip encoding, while the final descriptor stores
  chip in flag bits 2-3. Next action: rotate two places and rerun.
- Replaced stale hard-coded profiler windows with map-symbol ranges. The real
  idle figure is 7,056 T-states, above the Must <=600 limit, because even a
  completely inactive engine walks all 16 descriptors. Classification:
  implementation. Next action: publish a one-byte any-work gate from install,
  clear and noise setup; recompute it from post-step descriptor state during a
  real walk; return before loading IY when it is clear.
- Final focused sound run: 23 tests pass after adding the direct countdown fast
  path and map-symbol profiling. Measured: 12 waiting voices 546 (Must <=600,
  met); 12 changing 27,245; one changed byte 6,090; rewrite 23,096; BATCH
  11,488. The latter misses are report-with-profile findings under WORK.md.
- Package-specific tests pass: 200 staggered ticks in DIRECT/BATCH, coalesced
  final state, and direct primitive equal/forced behavior.
- Next action: run the prescribed final validation block once, record exact
  results, then write the validation record and diff checks.
- Final prescribed build/test block passed: 54 focused tests and four
  VGMPlayer API tests. The clean repository gate passed 989 tests with 119
  expected skips in 395.255 seconds; `make check: OK` and both production
  image names have SHA-256
  `0c940491f7383cf9ef993bbb3703144c2c9d1594d33c4d7e003a57485ce9bb11`.
- The validation record documents the active/rewrite timing misses, the
  symbol-corrected ZVG profile, warnings/skips, pins and pending hardware
  checklist. `git diff --check` passes.
