> Worker package. After 100c02, before 101. The libsnd voice engine and
> output rework 100c01 deferred: write-through per voice, no queue, no
> flush pass. The program format and the public API stay the same. No OS
> change.

# Task

Rewrite the tick path of manual voices (`snd_voice.asm`, the shadow
part of `snd_out.asm`) so that each voice compares and writes its
registers directly from a precomputed descriptor. This reaches 98's
budgets and gives 102's ZTR engine a cheap compare-and-write primitive.

## Current state (100c01's record)

- **Cost per voice that sets its volume then waits one tick, about
  1,600 T-states:**
  - **engine** (~900): finds the 8-byte state by index arithmetic,
    copies the cursor and wait to globals, dispatches through a compare
    chain, and parks or resumes through linked run/wait lists with a
    `min_due` update;
  - **queue push** (~120): records the changed slot per chip;
  - **flush** (~560 per slot): walks each chip's queue, recomputes
    `chip*6 + slot*2` style addresses, compares with the shadow, and
    calls a generic `_emit` that reloads the mode and port.
- **Figures:** 12 voices changing 19,215 (target 4,000); one voice and
  one byte 1,260 (400); refresh 15,632 (3,500); idle 190 (600).
- **Unchanged parts:** the ZVG decoder writes its chip directly
  (100/100c02) and keeps doing so. The voice program format
  (`snd_private.h`) and its C compiler (`snd_manual.c`) don't change.

Read: `work/00-WORKER.md`; 98's, 100c01's and 100c02's records;
`snd_voice.asm`, `snd_out.asm`, `snd_tick.asm`, `snd_private.h`,
`snd_manual.c`; `tests/test_snd.py`.

## Requirements

1. **The voice descriptor** (Must). One per voice, in assembly-owned
   storage, filled in C when a program starts (`snd_voice_install` or a
   new C helper):
   - the program cursor, a 16-bit wait counter and an active flag;
   - the chip's port, and the latch prefixes: the tone latch
     `80h | sub<<5`, the volume `90h | sub<<5` (for a noise voice, the
     noise control `E0h` and volume `F0h`);
   - pointers to the voice's shadow bytes (the attenuation, the period
     pair, the noise byte), so the tick does no index arithmetic.

   Document the layout in `snd_private.h`. About 16 bytes a voice;
   record the RAM.
2. **The engine** (Must):
   - **The walk:** a linear walk over the active voices (a compact list
     of descriptor pointers, or a next pointer in each), with no
     run/wait lists and no `min_due`;
   - **A waiting voice:** decrements its counter and moves on (target
     about 40 T-states);
   - **An active voice:** its ops run with the cursor and descriptor in
     registers (IX or HL/DE as fits), dispatched through a jump table on
     the opcode;
   - **The waits keep 98's semantics:** a WAIT always ends the voice's
     tick, at most one envelope step per tick, and the catch-up cap. Under
     catch-up (`elapsed` > 1), a voice consumes its waits from `elapsed`
     exactly as 98 specified.
3. **Write-through output** (Must):
   - **PERIOD, ATTEN and NOISE:** compare with the descriptor's shadow
     byte or bytes. If it differs (or the noise force applies), update
     the shadow and output now: DIRECT `OUT (C),A` with the
     descriptor's port, BATCH appended to the batch (bounded, sending
     when full as 100c02 does);
   - **No changed-slot queue and no per-tick flush walk.** The tick's
     end only sends the BATCH batch;
   - **The full rewrite** (after open, a failed batch, a ZVG stop): one
     straight loop over the 44 registers in card order, from the desired
     state;
   - the ZVG chip's handling stays as it is (100c02).
4. **The write order** (Must). Within a tick, bytes now go out in voice
   order, as each voice's ops run. Update the Python references in
   `tests/test_snd.py` that assumed per-chip grouping, and state the
   order in `docs/snd-sdk.md` 7.3. Each voice's own sequence (the period
   before its attenuation, as `psg.c`) is unchanged.
5. **The primitive for 102** (Must). Expose the compare-and-write as
   internal entry points documented in `snd_private.h`:
   - `snd_put_period` (descriptor or chip/voice, period);
   - `snd_put_atten`;
   - `snd_put_noise` (with the force flag).

   102's ZTR engine renders through them.
6. **Docs** (Must): `docs/sdk.md` libsnd costs; `docs/snd-sdk.md`
   sections 4.3 (the engine, the waits) and 7 (write-through, the order).

## Tests

- **Unchanged and passing:** all of `tests.test_snd` (tones, adsr,
  noise, modes, catch-up, close, zvg, zvgnotes and the timed songs),
  `tests.test_snd_oracle` and `tests.test_reader`, with only the order
  updates of requirement 4.
- **New, staggered voices:** 12 voices with staggered envelopes and
  waits for 200 ticks. The per-tick writes equal a Python reference
  built from the same programs (in voice order), in DIRECT and BATCH.
- **New, catch-up:** `snd_tick(5)` over staggered waits gives the same
  final shadow as five `snd_tick(1)`s, and the writes only of each
  voice's last state per register.
- **New, the primitive:** a sndtest mode drives `snd_put_*` directly:
  equal values write nothing; a forced noise writes.

## Budgets (CPU T-states, interrupts out)

| figure | now | target | on overrun |
|---|---|---|---|
| idle tick (12 waiting voices) | 190 | <= 600 | stop and report |
| one voice waiting (per voice) | - | <= 50 | report with a profile |
| 12 voices each changing attenuation | 19,215 | <= 4,000 | report with a profile |
| one voice step + one changed byte (DIRECT) | 1,260 | <= 400 | report with a profile |
| full rewrite, 4 chips (DIRECT) | 15,632 | <= 3,500 | report with a profile |
| `snd_put_atten`, changed (DIRECT) | - | <= 80 | report with a profile |
| BATCH tick (12 voices) | 8,135 | report | - |
| descriptor RAM | - | report | - |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board: `sndtest tones`, `adsr` and `noise` sound as before;
  `sndtest zvg /fs/night.zvg 2` and `vgmplay /fs/night.zvg` play
  cleanly.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/VGMPlayer test
python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_reader tests.test_sdk_package
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-voice-engine.md`.
