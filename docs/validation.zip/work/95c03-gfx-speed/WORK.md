> Worker package. After 95c02, before 96. libgfx speed, from 95c01's
> profiles (`docs/validation/2026-10-25-gfx-timing.md`). Every drawing
> routine in assembly. Same API, same pixels. No OS change.

# Task

Bring libgfx to the package-96 budgets. Measure each change before and
after with `tests/gfxprof.py`; a miss is re-profiled and reported, never
a contorted test.

## Current state (95c01, CPU T-states)

- **Per command:** fill 3,803 (`gfx_fill_rect` 1,707, `gfx_batch_submit`
  1,260, `gfx_rect_ready` 378); line 2,793; a polyline segment 5,668
  (submit, `gfx_line`, `run_line` 767, `start_command` 520, dispatch).
- **Ellipse r=50:** filled 1.40M, outline 2.04M. `__mulint` (380 calls,
  263k), `gfx_mul32`, a 3 KB span-set `memset` (65k), span visit/run,
  submit per span; every span an LMMV (96 VDP ticks per dot).
- **Text:** a cached 128-glyph 4×6 G6 row 234k, fresh pair 286k
  (`memcpy` 34k); `text_row` 267 per glyph-scanline; a 6×8 fresh pair
  366k (C `gfx_text_build_pages`).
- **Transparent and atlas:** about 10,000 per glyph (not profiled); atlas
  build 2.33M; stale redraw 212k.
- **The first five timing pairs** run with the duration model off: their
  engine waits are `command_busy`, not the chip.

Read: `work/00-WORKER.md`; 95c01's and 95c02's records; libgfx `src/`
(`gfx_batch.c`, `gfx_draw.c`, `gfx_shapes.c`, `gfx_text.c`, `gfx_font*.c`,
`gfx_atlas.c`, `backends/v9958/*`); `tests/gfxprof.py`; `tests/test_gfx.py`
`TestGfxTiming` and `TestGfxAtlas`.

## Requirements

0. **The rule** (Must). Every drawing routine is assembly, from the
   public entry point to the port:
   - **in scope:** every call that draws or moves pixels: the shapes and
     ellipses, `gfx_fill_rect`, `gfx_clear`, `gfx_copy_rect`, the upload
     stream, text (opaque and transparent), the atlas build and
     redraw, the batch (`gfx_begin`/`gfx_end`/`gfx_flush`) and the
     builders;
   - **stays in C:** setup and rare calls: `gfx_open`/`gfx_close`,
     `gfx_set_mode`, `gfx_display_enable`, the palette, `gfx_get_info`,
     `gfx_text_atlas` setup, and the font set/reset (they only write
     the tables). No C wrapper: the header's prototype is the assembly
     entry;
   - **refusals and results unchanged.**
1. **The model on everywhere** (Must). Every timing pair runs with the
   frame clock and the duration model on. Each figure is reported
   three ways:
   - CPU T-states excluding engine waits and interrupt service;
   - the engine wait, and the interrupt time inside the window;
   - the total.

   95c02 saw the figures swing by up to 70% with link layout (bank
   thunks, kernel IRQs inside windows). Mark each call that crosses a
   bank thunk; the pins use the ISR-free CPU figure.

   Profile the missing figures first: transparent G6/G7, 6×8 G6, 4×6
   G7, the atlas build and the stale redraw.
2. **The command path** (Must):
   - **Direct issue:** outside `gfx_begin`/`gfx_end`, a call validates,
     builds the register block and issues it, with no queue record and
     no batch dispatch. Inside a batch, the record is built in place in
     the queue slot (`gfx_batch_slot()`), with no 16-byte copy.
   - **Builders:** compute the block from the arguments in registers or
     IX, with no intermediate struct where avoidable; issue with OUTI,
     the CE wait before it.
3. **Ellipses** (Must):
   - **The walk:** incremental midpoint, with no multiplies in the loop
     (a handful of products for the constants), 24-bit or 32-bit adds.
     It must stay exact for the 512×512 space.
   - **The span set:** clear only the bounding box's lines.
   - **Spans:** COPY uses HMMV for the byte-aligned part, with LMMV
     only for an odd G6 end dot. This halves the VDP time in G7 and
     quarters it in G6. XOR stays LMMV.
   - **Emit as the walk goes,** when the scanline is final.
   - **95c02's gapless outline rule is kept.**
   - **Exact:** 95c02 found the compiled walk lagging the Python
     midpoint in region 2 (r=24, 14×20). The assembly walk equals
     `fill_ellipse_pixels` for every shape; the "filled twin"
     grounding goes.
4. **Text** (Must):
   - **Row-major font tables:** for each glyph row, a 256-byte page
     indexed by the character code (4×6: 6 pages; 6×8: 8 pages; the RAM
     fonts in that layout). The row loop is then `ld l,(char) ;
     ld a,(hl)`, with H the row page.
   - **Page-aligned pair tables** (4×6 G6 16×2 bytes, 6×8 G6 64×3, G7
     per-pixel), built in assembly; the fresh pair's `memcpy` goes.
   - **The inner loop** (per glyph-scanline): the character, the font
     byte, the pair lookup, 2-3 OUTs. Aim for about 80 T-states per
     glyph-scanline in G6 4×6.
   - **VRAM rate:** an OUT every ~35 T (3.5 µs); if the board drops
     bytes, report it (the WAIT bridge handshakes, not a delay loop).
   - **`gfx_font_set_glyph` and the resets** keep their API: they
     write the row-major layout.
5. **Transparent and atlas** (Must):
   - **Transparent:** one LMMM per glyph through the direct or batch
     path of item 2; SX/SY from a per-atlas cell table, or shift/add in
     assembly.
   - **The atlas build:** draw the atlas's glyph rows as strings
     through item 4's row loop (one VRAM address per scanline of the
     atlas row), not one cell at a time.
   - **The stale redraw:** stays one cell per atlas.
6. **SDK refresh** (Must). Every `UserSoftware/*/Makefile` re-unpacks
   the SDK when its archive's hash changes (PView's `.kos-sdk-sha256`
   rule; GfxDemo built against a stale unpack).
7. **Docs** (Must). `docs/sdk.md`: libgfx's measured costs replaced by
   this package's figures, and the direct-issue rule (a call outside a
   batch issues at once).

## Tests

- Every existing gfx replay passes unchanged (VRAM against the
  references, refusals, XOR restoration, atlas decodes).
- **Direct versus batched:** the same shapes drawn directly and inside
  a batch give identical VRAM and identical command blocks.
- **Ellipse spans:** the HMMV/LMMV split is pinned by command codes (an
  odd-centred G6 ellipse; no LMMV for G7 COPY); pixels equal the
  reference.
- **Font layout:** a redefined glyph and its reset in both fonts; the
  row-major RAM tables decode to the const fonts.
- **Timing:** each pin is lowered to the achieved CPU figure + 10%, with
  the target in the message.

## Budgets (CPU T-states excluding engine waits, model on)

| figure | 95c01 | target | on overrun |
|---|---|---|---|
| one aligned `gfx_fill_rect` | 3,803 | <= 1,200 | report with a profile |
| `gfx_line` | 2,793 | <= 1,500 | report with a profile |
| 128-segment polyline | 725,495 | <= 200,000 | report with a profile |
| filled circle r=50 | 1,401,366 | <= 150,000 | report with a profile |
| outline circle r=50 | 2,039,101 | <= 250,000 | report with a profile |
| 128-glyph 4×6 G6 row, cached | 234,197 | <= 90,000 | report with a profile |
| the same row, fresh pair | 286,086 | <= 100,000 | report with a profile |
| 6×8 G6, 8 glyphs | 55,458 | <= 8,000 | report with a profile |
| 4×6 G7, 8 glyphs | 33,360 | <= 8,000 | report with a profile |
| transparent glyph, CPU | ~10,000 | <= 1,000 | report with a profile |
| atlas build, 95 glyphs, G6 | 2,333,664 | <= 150,000 | report with a profile |
| 6×8 fresh pair | 365,755 | <= 30,000 (Should) | report |
| filled circle r=50, total | - | <= VDP time + 10% (CPU hidden) | report |
| OS bytes | unchanged | 0 | stop and report |
| libgfx code size | - | report only | - |
| drawing code left in C | - | none (list any) | stop and report |

## Owner checklist

- On the board: `gfxtest atlas` text appears at once; `gfxtest shapes`
  as 95c02; `gfxdemo` and `pview` unchanged.

## Validation

Develop with single tests by dotted name, and `tests/gfxprof.py` per
item. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/GfxDemo test && make -C UserSoftware/PView test
python3 -m unittest tests.test_gfx tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-gfx-speed.md`: every figure before and
after, and the profile of anything over its target.
