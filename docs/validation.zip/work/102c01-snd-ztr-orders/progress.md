# 102c01-snd-ztr-orders — progress

Starting tree: clean, HEAD 95a58ee ("package 102"). Prior 101/102 work is
committed; WORK.md's deadlock fix is in the committed tree.

## In progress

### Reading the contract and references
- Read WORK.md, work/00-WORKER.md, docs/snd-sdk.md 6 (streaming model).
- Reading: snd_ztr.c (producer to replace), snd_ztr_dec.asm (row intake
  to replace), snd_private.h, snd_zvg.c/snd_zvg_dec.asm (refill/decode
  split), Zephyr-80 player.asm (decode model), TECHNIQUES.md, sndtest.c
  modes, oracle player.c decode_row, tests/test_snd.py, SNTracker client.
- Verify: _snd_ztr_tick runs only while PLAYING (deadlock fix present).

## Plan

1. Replace the C row producer with order double buffers (refill from
   setup_order's directory scan; two 1,024-byte buffers; handshake
   published/consumed order bytes).
2. Fast open: validate whole windows in a loop, no C call per byte
   (reuse one order buffer as the window scratch).
3. Engine: replace _zt_take_row with per-channel cursors decoding raw
   pattern bytes at the row's first tick (player.asm model); order
   change swaps to the published buffer or underruns.
4. sndtest `ztr FILE timed [batch]`; sntrack in simulator both songs,
   0 underruns, tempo within 2%, first 3,000 ticks equal goldens;
   stalling-reader recovery.
5. Cost report: median/worst ZTR tick vs 60 Hz frame; snd_ztr_open per
   song; profiles via tests/sndprof.py. Optimizing is not in scope.
6. Docs: docs/sdk.md ZTR paragraph; validation record.

## Verified

- sndtest.exe packs: image 36,139 + BSS 20,360 = 56,499 (limit 56,704
  with the 384-byte stack); ztrkres.exe packs too.
- Host build of host_ztr.c compiles -Wall -Wextra -Werror.
- The exe limit is exepack's: image+BSS <= 0xDE80 (STACK_TOP - stack),
  tighter than exemanifest's 0xDF00 check.

## Current state

- snd_private.h: SND_ZTR_ORDER_BYTES 1024 / ORDER_TABLE 64 /
  ORDER_STREAM 960; handshake published/consumed; order_base[2];
  capacities tightened (orders 136, macro 6640).
- snd_ztr.c: order double buffers + refill_order + windowed fast
  validation (256-byte windows, one fill per event, no C call per
  byte); pattern directory resident compacted 8->6 bytes (count is
  validation-only); largest-order ENOSPC; header/instrument/note-table
  reads through the order scratch.
- snd_ztr_dec.asm: _zt_take_row decodes from the front buffer's
  per-channel cursors into the event vars, applies via
  _zt_apply_event; _zt_advance_position takes the published buffer at
  an order change or underruns; tick never runs outside PLAYING.
- sndtest: ztrbegin shared preamble, ztrload checksums per-order
  buffered streams, ztr FILE timed mode, ztrbudget marker windows.
- ztrloadkres: same per-order drain through the KRES reader.

## Next

- Smoke: host_ztr both songs (buffers vs file, checksums).
- tests/test_snd.py: rewrite TestSndZtrLoad host test (no row lines
  anymore: buffer comparison lives in host_ztr), stall pins, new timed
  + sntrack tests.
- State gate: ztr_validate both songs 3000 ticks; TestSndZtr suite.
- Budgets/cost report; docs; validation record.

## Notes

- Reconstructed snd_ztr.c once from the session transcript after a
  stray `git checkout --` reverted it (edits are all recorded here);
  host compile + full rebuild re-verified.

## Final state (2026-10-27)

- Host producer: both songs' order buffers byte-equal the file's
  selected streams (30 + 136 per-order checksums); short mode reads
  forward-only (3-byte reads); error mode refuses at call 2 (-10);
  43/43 malformed refused.
- Card: ztrload checksums equal the host, card and KRES (TestSndZtrLoad).
- Engine gate: 3000-tick state + write gate passes, DIRECT and BATCH,
  both songs (ztr_validate + TestSndZtr).
- Real playback: `sndtest ztr FILE timed` night-market = DONE, 11,518
  timer events for 11,518 ticks; sntrack both songs 0 underruns, 0
  overruns, 0 missed, timer events within 2% of the tick counts, the
  first 3,000 ticks' writes equal the goldens (TestSndZtrClient).
- Stall mode: one underrun at the order change, exact recovery.

Bugs found and fixed on the way:

- `_zt_take_row`'s event-defaults loop clobbered HL (the stream
  cursor): the cursor is now saved in DE across the defaults.
- The shared stream walk's fill discarded in-flight event bytes at a
  window boundary (and re-read 8-12 bytes backward in the
  fill-at-cursor variant): zs_fill now compacts the <=12-byte tail to
  the window front and reads the continuation from the window end,
  keeping every reader request strictly forward.
- The directory pass's counts scratch advanced past its base before
  `pattern_streams_ok` read it (host and card both refused).
- A full 256-byte window truncated ws_have (8-bit): windows are
  capped at 255 bytes.

Open cost is above the 5 M target (13.9 M / 36.7 M T-states; the
largest-order scan dominates RunawayCircuit).  Optimization deferred
by owner decision; the profiles are in the validation record.

sndtest.exe: image 36,331 + BSS 20,360 (+256 load) = 56,947 <= 56,960.
Record: docs/validation/2026-10-27-snd-ztr-orders.md.
