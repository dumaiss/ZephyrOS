> Worker package. After 102. A correction: ZTR streams by **order**,
> the ZVG model (the foreground copies raw bytes, the tick decodes),
> replacing 101's C row decoder and its 3-row record queue.
> `docs/snd-sdk.md` section 6 is the target. ZTR v1 is unchanged. No OS
> change.

# Task

`sntrack` fails on the board:
- Night Market stops after its first note;
- RunawayCircuit stops after about 5 s;
- both are slow to start.

Two causes, both found by running `sntrack.exe` in the simulator:

1. **A deadlock (fixed in the tree, uncommitted).** The tick ran while in
   `UNDERRUN` and consumed the next record out of turn. The apply loop
   then aborted, the head advanced, and the position never did. Now the
   tick runs only while `PLAYING` (`snd_ztr_dec.asm`, `_snd_ztr_tick`).
   Keep this fix.
2. **The producer can't keep up.** The C decoder costs about 60,000
   T-states per row and fills 162-byte records, so the queue holds 2
   rows (~170 ms).
   - With the 3-row queue Night Market plays at half speed with 1,644
     underruns; a 16-row experiment still gave 413 underruns and half
     speed.
   - The fix is the design, not the depth.

Replace the row input; keep everything else.

## Current state

- **Keep:**
  - `validate()` and its `zs_*` windows, `load_resident()`,
    `setup_order()`'s directory scan, and the controls and status;
  - the whole engine (`snd_ztr_dec.asm`): effects, macros, notation,
    render, writes. It passes the 3,000-tick state and write gate in
    DIRECT and BATCH.
- **Replace:**
  - `snd_ztr.c`'s `produce_row_record`, `ztr_produce_rows`,
    `ztr_window_complete`, the producer's use of `decode_event`, and the
    queue;
  - `snd_private.h`'s queue and record constants (both copies:
    `snd_ztr_dec.asm` mirrors them);
  - `_zt_take_row` and the slot-apply loop in the engine.
- **The decode model:** the Zephyr-80 assembly tracker,
  `../Zephyr-80/Code/HOST/SNTracker/src/player.asm`:
  - `player_begin_row` and `player_decode_channel_row`, with the event
    handlers after it;
  - sdasz80 syntax; it decodes each row from raw pattern bytes through
    per-channel cursors, in the tick.
  - The C oracle (`tests/snd/oracle/player.c` `decode_row`) remains the
    semantic and trace reference.
- **Tests that missed this:**
  - every ZTR test drives `sndtest`, where the tick and `snd_service`
    strictly alternate in one context;
  - SNTracker's tests only grep its source;
  - `sndtest ztr` is unpaced, so tempo follows `snd_service`'s cost.

Read: `work/00-WORKER.md`; `docs/snd-sdk.md` 4.2, 6; 101's and 102's
records; `player.asm` (above); `snd_zvg.c`/`snd_zvg_dec.asm` (the
refill/decode split to copy); `work/102-snd-ztr-engine/TECHNIQUES.md`
("Measure" and "Pitfalls").

## Requirements

1. **The order buffers (C)** (Must):
   - two buffers of `SND_ZTR_ORDER_BYTES` (1,024: night-market's
     largest order is 871);
   - `snd_ztr_open` records the largest order's total stream bytes in
     its forward pass, and a larger one is `-KOS_ENOSPC`;
   - each buffer carries a 16-entry table, a start and an end per
     channel (none for `FFh`);
   - `refill(order, buffer)`: `setup_order`'s scan, then one `read_at`
     per stream;
   - the handshake is two bytes (published order, consumed order), each
     written after the data it covers;
   - `snd_service` does one refill per call when the back buffer is
     free, otherwise returns at once; `snd_ztr_prepare` loads order 0;
   - a reader error is the last error, and playback stays in `UNDERRUN`.
2. **Decode in the tick (assembly)** (Must):
   - at a row's first tick, each channel decodes its next event from
     its cursor if the event's row is due, as `player.asm` and
     `decode_row` do, and applies it through the existing event code;
   - at the order change (`advance_position`), switch to the published
     buffer and set the 16 cursors from its table; if it is not
     published, underrun (mute, count, hold);
   - `snd_service` resumes at that order's first row, and the tick
     never runs outside `PLAYING`;
   - the stop-song effect still ends in `DONE`.
3. **Fast open** (Must). `snd_ztr_open` validates whole windows in a
   loop, with no C call per byte. Target: ≤ 5,000,000 T-states
   (0.5 s) per song; today Night Market costs 25.8 M.
4. **Real playback tests** (Must):
   - **`sndtest ztr FILE timed [batch]`:** paced by the timer from
     `snd_timer_period`, as `zvg_play_timed` is. It ticks from the
     event handler, services in the foreground, and prints the ticks,
     timer events and underruns at the end;
   - **`sntrack.exe` in the simulator:** both songs from the card play
     to the end:
     - 0 underruns, 0 overruns;
     - the timer-event count within 2% of the song's tick count (the
       tempo);
     - the writes equal the goldens for the first 3,000 ticks;
   - **the same with a stalling reader:** an underrun at an order
     change, then exact recovery.
5. **Report the cost as a share of a 60 Hz frame** (Must). Give the
   median and worst ZTR tick in T-states and as a percentage of
   166,667, for both songs. Optimizing is not part of this package;
   report a worst tick above 25% of the frame with its profile
   (`tests/sndprof.py`). Pin the figures +10%.
6. **Docs** (Must):
   - `docs/sdk.md`'s ZTR paragraph: order buffers, sizes, the frame
     shares;
   - the record lists what was removed.

## Tests

- **Unchanged and passing:**
  - the 3,000-tick state and write gate, DIRECT and BATCH;
  - pause, resume, stop and ownership;
  - the stop effect;
  - the malformed table;
  - 101's forward-pass, short-read and error tests.
- **Changed:** the host producer test compares each order's buffered
  streams with the bytes `setup_order` selects, every order, both songs.
  `sndtest ztrload` checksums the buffers per order, card and KRES.
- **New:** requirement 4.
- `sndtest.exe` must still fit: removing the queue and the C decoder
  should free more than the buffers take. Report the image and BSS
  sizes.

## Budgets

| figure | now | target | on overrun |
|---|---|---|---|
| `sntrack` underruns, both songs | 1,644 (Night Market) | 0 | stop and report |
| tempo: timer events vs song ticks | ~2x | within 2% | stop and report |
| `snd_ztr_open` per song | 25.8 M | <= 5 M | report with a profile |
| one order refill | - | report | - |
| ZTR tick, worst, % of 60 Hz frame | 60% (RunawayCircuit) | report | report above 25% |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board:
  - `sntrack night-market.ztr` and `sntrack RunawayCircuit.ztr` play
    to the end at the right tempo, with no stalls, and Q returns
    silently;
  - `sndtest ztr /fs/night-market.ztr timed` keeps a steady rhythm.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/SNTracker test
python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_sdk_package
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-ztr-orders.md`.
