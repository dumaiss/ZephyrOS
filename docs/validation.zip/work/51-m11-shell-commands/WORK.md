> **DRAFT. Not dispatched.** Runs after 50.

# Task

The file built-ins of the shell: `ls cat stat cp mv rm mkdir rmdir`.
They are written in `user/shell/fscmd.c`, with one function per command,
on the SDK only (`open/read/write/close/sync`, `stat/mkdir/rmdir/unlink/
rename`, `list`).

Paths are translated as in package 50 before use, and shown in display
form in every message.

As in 50, the shell is an ordinary application: it is in no store, the
ROM is unchanged, and it runs from the emulated card in the replay.

Read: the package-50 record, and the architecture's native shell section
(file policy and recovery without storage).

## Requirements

1. **One shared buffer**, `static uint8_t io_buf[512]`, used by `cat`
   and `cp`. No other buffer is larger than `KOS_PATH_MAX`.
2. **`ls [path…]`** (default `.`):
   - **Directory or root:** `list` it until the end and print one entry
     per line. A container gets a trailing `/`. A file gets two spaces and
     its decimal size from `stat`; skip the size if `stat` fails.
   - **File:** print the same single line for it.
   - **Several arguments:** print `<display path>:` before each one's
     listing.
   - It works on `//`, `/` (that is, `/fs`), `/system`, `/dev` and
     `/dev/input`. A `/dev` entry shows no size.
3. **`cat file…`:** copy each file to the console with `console_write`, in
   chunks of up to 512 bytes. The bytes are raw, with no translation.
4. **`stat path…`:** print `<display path>:`, then one line per field of
   `struct kfs_stat`:

   ```text
   type: <file|dir|n>
   attributes: <hex>
   size: <decimal>
   mtime: <hex>
   ```

5. **`cp src dst`:**
   - If `dst` is a directory, the target is `dst/<last component of src>`.
   - Open `src` for reading. Open the target with `WRITE|CREATE|TRUNC`.
   - Copy through `io_buf`, then `sync`, then close both.
   - A directory `src` → `EISDIR`.
   - On a write error: close both, `unlink` the partial target, and report
     the write error.
6. **`mv src dst`:** the same target rule as `cp`.
   - Try `rename` first.
   - It returns `EXDEV`, or `src` and `dst` sit under different reserved
     roots → copy as in `cp`, then `unlink src`.
   - If that `unlink` fails (for example `EROFS` on `/system`), report it,
     keep the copy, and set the status to that error.
7. **`rm file…`, `mkdir dir…`, `rmdir dir…`:**
   - one call per argument;
   - on an error, report it and continue with the next argument;
   - the status is the last error, or 0.
   - There is no `-r` and no `-f`.
8. **Errors:** the package-50 format (`<cmd>: <display path>: <message>`)
   and status rule. A write to `/system` reports `read-only`.
9. **Size.** Record the shell size.
   - If the primary image exceeds 24 KiB, move `fscmd.c` into far
     segment 1 (`FAR1=`, plain `__banked` calls, package 49b), and record both sizes.
   - Otherwise, no far code.

## Tests

**Simulator replay**, with a card. Every write stays in `/fs/SHTEST`,
which the session creates and then removes. Cover:
- `ls` of `//`, `/`, `/system`, `/dev`, a file, and two arguments;
- `mkdir`; `cp` into a directory and to a name;
- `cat` of the copy, compared byte for byte with the source;
- `stat` of a file and of a directory;
- `mv` within `/fs` (`rename`);
- `mv` from `/system` to `/fs` (a copy, and then the unlink fails with
  `read-only`);
- `rm` of several files, one of them missing; `rmdir` of a non-empty and
  of an empty directory;
- `cp` onto `/system` (`read-only`).

The no-card cases (`ls /system` and `cat /system/drivers.man` work;
`ls /` and `mkdir /X` report `no device`) need the shell in the store, so
52 replays them; here the host tests cover the `no device` message path.

**Host:** the target-name rule for `cp`/`mv` (a directory versus a name,
and a trailing `/`).

## Constraints

No kernel, driver, SDK, system-file or store change. Only `user/shell/`
and its tests change.

Record: `docs/validation/<date>-m11-shell-commands.md`.

## Validation (user-land only: no `make clean && make check`)

Put the tests in `tests/test_shell.py` and `tests/test_shell_sim.py` (extend 50's). Use these same commands while developing,
and once at the end:

```sh
make                                              # build/user/shell.exe builds
python3 -m unittest tests.test_shell tests.test_shell_sim
git diff --check
```

Run the full check only if this package had to touch the SDK, the
kernel or a driver; if so, report why.
