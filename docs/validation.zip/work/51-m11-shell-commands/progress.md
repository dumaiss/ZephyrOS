# progress — package 51 (m11 shell commands)

State: **done**.  Implementation, host tests, session replay and the
validation batch are green; the record is
`docs/validation/2026-10-12-m11-shell-commands.md`.

## Done

- `user/shell/fscmd.c`: the file built-ins `ls cat stat cp mv rm mkdir
  rmdir`, one function per command, on the SDK only (`open/close/read/
  write/sync`, `stat/mkdir/rmdir/unlink/rename`, `list`, `getcwd`).
  One `static uint8_t io_buf[512]` shared by `cat` and `cp`; every other
  buffer is `KOS_PATH_MAX` and static (the shell is single-tasked and the
  stack stays for the call chain).
  - `ls` (default `.`): `stat` first, so a file gets its single
    name-and-size line; anything else is `list`ed to the end.  A
    container gets a trailing `/`, a file gets two spaces and its decimal
    size from `stat` — skipped when `stat` does not answer, which is
    every `/dev` entry.  Several arguments print `<display path>:` before
    each listing.  A failed `stat` is not an `ls` error until the listing
    fails too (`/` and `/dev` are the namespace's own containers).
  - `cat`: raw chunks of up to 512 bytes straight to `console_write`.
  - `stat`: `<display path>:` then `type:` (`file`, `dir`, or the number),
    `attributes: %02x`, `size: %lu`, `mtime: %08lx`.
  - `cp`: a directory `src` is `EISDIR`; the target follows the shared
    rule; `WRITE|CREATE|TRUNC`, `io_buf`, `sync`, `close`.  A short write
    continues at its own position; a failed read/write/flush closes both
    handles, `unlink`s the partial target and reports that error.
  - `mv`: the same target rule; `rename` first when both paths sit under
    one reserved root, `EXDEV` still falling through to the copy; else
    copy and `unlink src`, and a failed unlink (a `/system` source) keeps
    the copy and is the status.
  - `rm`/`mkdir`/`rmdir`: one call per argument, each error reported
    before the next, the status is the last error or 0.
  - Errors: `<command>: <display path>: <message>` with the package-50
    `shell_strerror` table, the status positive.
- `user/shell/shell.h`: `shell_file_command`, `shell_fscmd_target` (the
  target rule, non-static for the host tests) and `shell_path_root`.
- `user/shell/path.c`: `shell_path_root` (fs/system/dev or NULL), the one
  definition of the reserved set (`path_reserved_root` now defers to it).
- `user/shell/builtin.c`: `help` lists the file built-ins too, and
  `shell_builtin` falls through to `shell_file_command`.
- `Makefile`: `fscmd.c` added to the shell's `exe_program` source list.
- `tests/test_shell.py` (18 host tests):
  - `TestShellFileTargets`: the target rule — a directory (`stat` answer)
    versus a name, a trailing `/` with no `stat` answer, a relative
    destination, the longest target that fits (63 + 63) and a refused one
    over the limit;
  - `TestShellFileErrors`: `ls /` and `mkdir /X` with no card, the linked
    `_stat`/`_list`/`_mkdir` replaced by `-KOS_ENODEV` stubs and
    `_console_write` by a capture stub — the two messages are read back
    through the memory map (printf formats on the stack, which is in the
    common bank);
  - staging constants moved above the grown image (0x6000-0x7000) and
    `TestShellArtifact.test_it_leaves_the_host_tests_their_staging_area`
    added, so a future image that grows into them fails loudly instead of
    looking like a test bug;
  - `SHELL_MODULES` gained `fscmd` and `fs` (the SDK's FILE wrapper),
    `UNUSED_MODULES` lost `fs`.
- `tests/test_shell_sim.py`: `test_file_commands`, a second session on a
  card (`SHELL.EXE`, `SUB/ORIG.TXT` = `card`), with the `help` row of the
  first session updated.  Rows: `ls //`, `ls /`, `ls /system` (the
  packed store's names and sizes, read from `build/recovery.romfs`),
  `ls /dev`, `ls /dev/input`, `ls` of a file, `ls` of two arguments,
  the `cp`/`cat` usage lines, `mkdir /SHTEST`, `cp` into it and to a name,
  `cat`, `stat` of a file
  and of a directory, `mv` inside `/fs`, `mv` from `/system`, `rm` of two
  files and one that is missing, `rmdir` non-empty and empty, `cp` onto
  `/system`, `exit 0`.  The test snapshots the card after every row, so
  the copy `cat` read back, the copy `cp` made and the copy `mv` could
  not unlink are asserted byte for byte where they happen, and the end
  proves the card unchanged.
- `tests/test_source_layout.py`: `user/shell/fscmd.c` added to
  `OWNER_FILES`.

## Evidence

- Shell artifact: `build/user/shell.exe` **16272** bytes (image 16236,
  BSS 3023, stack 512, 0 segments — no far code needed), sha256
  `f589167e5ed988e9abd97123d2a1ad67229a95cf8528f1d85b2b7785670a7ebe`;
  image sha256 `7489c8e7c5e60372c3c67ab3033f245334b58bce1c8985956a0136c3f257a78`.
  Package 50's shell was 10602 bytes / image 10566 / BSS 1487.
- The production image did **not** change: `build/konaos.bin` sha256
  `3638e156229e79320a5a221a86548c841e578ffb96085223214e71f39b03051d`
  and `build/modules/monitor.exe` 6310 bytes /
  `8a25071a468ff7aca212d929d03f2088c0eef5d8412be17b9eddc7b651acde7f`
  are the package-50 values, so the pinned acceptance identity needed no
  re-pin.
- Final batch: `make` (builds `build/user/shell.exe`, then "Nothing to be
  done for 'all'"); `python3 -m unittest tests.test_shell
  tests.test_shell_sim` → **20 tests, OK, 89.9 s**; `git diff --check`
  clean.
- Extra: `python3 -m unittest tests.test_sdk
  tests.test_console_acceptance` → 34 tests, OK, 1 pre-existing skip
  (helloworld image not built), 48.4 s (the acceptance replay is the
  strongest statement that the production image still boots; it needed no
  re-pin); `python3 -m unittest tests.test_source_layout` → 52 tests, OK.

## Decisions

- **Far code was not needed**: the primary image is 16236 bytes, under
  the 24 KiB line (`work/51-m11-shell-commands/WORK.md` requirement 9),
  so `fscmd.c` stays in the primary image and no `FAR1=` was added.
- **`ls` is `stat` first, `list` second**: only the namespace can answer
  for `/` and `/dev`, and only `stat` can answer "file" — so a failed
  `stat` is not an error until the listing fails too.
- **Directory sizes and times**: the card and the store both report
  `attributes` 0 and `KFS_TIME_UNKNOWN`, and `struct kfs_stat` says 0 for
  a directory, so `stat /SHTEST` prints `size: 0` and `mtime: 00000000`.
  The replay pins those exact lines.
- **`mv` decides by reserved root, not by the error alone**: the router
  answers `EROFS` for a `/system` *source* before it ever sees the
  destination, so `mv /system/x /fs/y` must not ask `rename` first.  A
  relative path takes the CWD's root; one that climbs above the CWD is
  left to the namespace (its `rename` answer stands).
- **The unlink's error is the `mv` status** and the copy stays
  (`mv: /system/known.bin: read-only`), which is the "recovery without
  storage" policy of the architecture's native shell section.
- **`cat`'s output is the only place a file's bytes reach the console**;
  the byte-for-byte claims are made against the card snapshots, not
  against console text.
- **No documentation change was needed**: `docs/architecture.md`
  section 14 already names the file built-ins and `mv`'s copy-and-unlink
  policy, and the shell is still a card program (package 52 puts it in
  the store and documents its place there).
- **The no-card rows are host-tested, not replayed** (the shell lives on
  the card), exactly as the package's WORK.md asks; package 52 replays
  `ls /system`, `cat /system/drivers.man` and the two `no device` rows
  once the shell is in the store.
