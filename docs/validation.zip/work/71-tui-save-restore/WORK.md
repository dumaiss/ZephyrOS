# Task

Implement caller-buffered save and restore of clipped cell regions so dialogs
and overlays can restore exact logical contents without heap allocation.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`, especially "Save and restore";
- `docs/konaos-tui-sdk-architecture.md`, sections 8.1, 9 and WP-TUI-6;
- packages 66-70 and their accepted validation records;
- the current cell-map, clipping, and dirty-run implementation.

## Requirements

1. Implement `tui_saved_size`, `tui_save`, and `tui_restore` in a separately
   pullable archive member.
2. Rectangles are relative to the active window and clipped exactly once by
   the common clipping layer. Size is the clipped row-major cell count times
   `sizeof(struct tui_cell)`. There is no allocator and no hidden region pool.
3. Save copies character and resolved attribute. Restore copies both and marks
   only changed cells dirty; it does not move the logical cursor, change the
   current style/window, or flush.
4. Validate initialization, pointers, multiplication, and caller buffer size
   before copying. A failure changes neither model nor buffer. Empty clipped
   rectangles have size zero; save/restore of them succeeds without access.
5. Extend the target program with overlays that cover mixed text/styles,
   clipped edges, nested windows, exact and short buffers, zero-area clips,
   and restore-without-change. Sentinel cells outside the clipped area remain
   byte-identical.
6. Assert a popup can be drawn and removed with the exact prior V9958 result
   and serial output. Restoring identical cells emits no cell run on flush.
7. Prove programs that do not call the region API do not link its archive
   member. Record its code and BSS contribution.

## Acceptance

- An arbitrary in-window popup restores character and style exactly.
- Caller storage is the only per-overlay storage.
- Short/null buffers and arithmetic/rectangle errors cannot partially copy.
- Restore participates in the existing dirty batching and preserves cursor,
  style, transaction, and window state.

## Constraints

- No widget implementation in this package.
- No heap, far-data segment, xmem object, kernel, driver, firmware, protocol,
  or system-image change.
- Record `docs/validation/<date>-tui-save-restore.md`.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_sdk_package
git diff --check
```

