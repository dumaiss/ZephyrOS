# Progress

## Status

DONE — accepted by supervisor on 2026-10-18. No commit was made.

## Done

- `user/sdk/tui/src/tui_region.c`: clipped size, save and restore in a
  separately pullable member; caller buffer only; restore dirties changed
  cells only and never moves cursor/style/window/transaction or flushes.
- `tests/tui/tui_test.c`: `region` mode covering mixed content, popup
  restore, identical restore, short/null buffers, zero-area clips, a null
  size pointer and nested-window relative save.
- `tests/tui/tui_core_probe.c`: map proof that the region member stays out.
- Report: `docs/validation/2026-10-18-tui-save-restore.md`.

## Supervisor acceptance

- Reviewed clipping, exact-size validation, row-major save/restore, dirty-cell
  behavior, and the separately pullable archive boundary.
- Accepted the worker's combined 173-test gate (171 passed and 2 environmental
  skips) and independently observed the static/link-map checks and both region
  simulator routes pass before stopping duplicate validation at the owner's
  request.
- Corrected the public-header and architecture comments to describe the actual
  clipped-area size contract; implementation bytes were unchanged.
