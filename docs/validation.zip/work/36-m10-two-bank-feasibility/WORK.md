# Task

Answer one question with measurements: **can ZephyrOS stay within two banks**
(bank 7 the nucleus, bank 6 the resident services, plus the existing common
region) under the resident-service architecture? The candidate layout is the
revision-13 window at a **`6000h` split**:
- a 16 KiB always-visible nucleus fixed core (`2000h-5FFFh`);
- a 32 KiB window (`6000h-DFFFh`), which shows bank 7's cold nucleus half
  when P = 0 and the service bank when P = 1.

Bank 6's out-of-window offsets (`0000h-5FFFh` and `E000h-FFFFh`, 32 KiB
at `6000h`; 40 KiB at `8000h`) are never visible through the window. They are evaluated as
space for boot-time service code and bulk service data. The package
measures, against the 24/24 `8000h` baseline:
- the fixed core;
- the hot service set;
- the out-of-window service tier;
- the GAL fit.

It also boots the resident-service spike at the new split.

Two banks is an owner constraint (`work/M10-REFERENCE.md`, decision 5),
not one option among several. A third OS bank is not an acceptable
fallback: it wastes too much memory. The package measures how the OS fits
in two banks and, if it does not yet, what closes the gap.

This is a spike. Success means **"does it boot, and what are the numbers"**
(`work/00-SUPERVISOR.md`, "Spike and evaluation packages"). Production stays
unchanged.

## Context

Dispatch after package 35 is accepted. Read:
- `work/00-WORKER.md`;
- `docs/architecture-proposal.md` (Parts II-III);
- the package-33, -34 and -35 reports;
- `tests/m10/rev13-classification.json`;
- `tools/rev13_layout.py`, `tools/pld_terms.py`;
- the package-35 spike sources (`tests/target/rsvc/`, the `rsvc-spike`
  Makefile targets).

Measured inputs (verify against the tree):

| item | value | source |
|---|---|---|
| fixed set today (package 34) | 12,979 code + 881 data | 34 §4 |
| IPC substrate | 3,900 code + 343 data | 35 §7 |
| VFS/provider objects | 17,115 B (`romfs` 2,879, `fs` 2,727, `vfs_*` ~9.5 KB, `romfs_provider` 1,513, …) | 35 §8, 30b |
| resident drivers | `sio` 328, `hid` 979, `ioc` 3,711, `v9958` 4,462, `iocfat` 6,643 = 16,123 B | M9 ledger |
| M10 mechanisms | 1,530-3,110 code + 136-272 data + 128-256 common (package 33, corrected) | 33 note |
| window `RAM_A16` terms (`8000h`) | 8 of 10; 7 with the mode-10 aperture | 35 §9 |

## Requirements

1. **Reclassify the nucleus under the service model.** Write
   `tests/m10/two-bank-classification.json`, assigning every kernel object
   and the package-35 substrate to exactly one tier, with a reason:

   | tier | rule |
   |---|---|
   | `fixed` | must be visible while the window shows bank 6: gates, IPC dispatch, the copy primitive, service-callable nucleus primitives, the IRQ executive, **any nucleus code that calls a service** (for example the loader's executable-stream upcall and the process-exit notification), and the data those touch |
   | `cold` | nucleus code and data used only with P = 0 (syscall-side bookkeeping, xmem allocation, boot-only setup, panic formatting) |
   | `service` | moves to the service bank: VFS core, ROMFS provider, drivers, the console composition |
   | `retired` | replaced in the service model (the `fs` syscall front end by IPC dispatch; the device registry by the endpoint table, if so) |

   Place the ISR stack and the 512-byte service stack in `fixed` (not
   common). Add the package-33 M10 mechanisms as tagged estimates split
   between `fixed` and `cold` according to who calls them.
2. **Measure the fixed core at both splits.** Extend `tools/rev13_layout.py`
   to take this classification and report, for `6000h` and `8000h`:
   - fixed code + data + stacks against the fixed region (16 KiB / 24 KiB);
   - cold nucleus against bank 7's window half (32 KiB / 24 KiB);
   - the remaining room.

   Measured objects use real sizes; the M10 rows are labeled estimates.
   **If the fixed core exceeds 16 KiB at `6000h`, list the smallest set of
   changes that would bring it under, with bytes**: for example which
   objects could become cold by moving a service call out of them.
3. **Project the service bank.** For the `6000h` window (32 KiB hot) and the
   out-of-window tier (`0000h-5FFFh` + `E000h-FFFFh`, 32 KiB; 40 KiB at
   `8000h`; reached only through the gate
   or nucleus copies):
   - **Drivers:** split each resident module into hot code (runtime
     operations) and boot-only code (init, probing, the V9958 font and
     atlas upload, IOC-FAT CAPS/mount, registration), from symbol sizes. Report
     hot and boot bytes per module.
   - **VFS service, structural slimming only,** measured: today's objects
     minus `fs` (retired), minus the ROMFS reader if the provider calls a
     nucleus bootstrap-reader primitive instead (state the primitive's
     size, which stays in the nucleus). Do not count speculative
     SDCC-idiom savings in the main figure; report them separately as a
     range, labeled estimate.
   - **The service-bank ledger:** window hot code + data + service stacks
     against 32 KiB (and against 24 KiB for comparison); out-of-window boot
     code and bulk data against 32 KiB (40 KiB at `8000h`). Add a `service bank:` ledger line to
     the layout tool's output.
4. **GAL fit.** Run `tools/pld_terms.py` for a `6000h-DFFFh` window, alone
   and with the mode-10 far aperture (region `8000h-BFFFh`, or the
   stack-safe alternative the minimizer prefers). Report terms per
   `RAM_A16/A17/A18` against 10/12/14. Add the `6000h` variant to the
   simulator decoder model (a window-base parameter) and to
   `platform/zephyr80/hdl/` as a variant PLD with vectors, for the owner to
   program if adopted.
5. **Does it boot.** Build the package-35 resident-service spike, transport
   A, at the `6000h` split, with the fixed/cold placement from requirement 1
   as far as the existing code allows. Boot it under the `6000h` decoder
   variant and record:
   - `rsvc: PASS`;
   - the null-call and 512-byte chained-read cycles against package 35;
   - the gate/service/ISR stack high-water marks;
   - the actual linked fixed-core end.

   If some object cannot be placed as classified without code changes,
   leave it where it links. Report the gap between the classified and the
   linked fixed core.
6. **Report.** Write `docs/validation/<date>-m10-two-bank-feasibility.md`
   with:
   - the classification summary;
   - the fixed-core, cold and service-bank ledgers at both splits;
   - the GAL terms;
   - the boot result and cycles at `6000h`;
   - a **verdict:**
     - (a) two banks fit at `6000h` with stated headroom;
     - (b) two banks fit only with named changes (listed with bytes);
     - (c) two banks do not fit yet. Give the gap in bytes and a ranked
       list of measures that close it **within two banks**, each with
       bytes and a measured/estimate tag. Candidates:
       - moving more boot-only or rarely used code to the out-of-window
         tier;
       - turning fixed code into cold code;
       - deeper VFS or driver slimming;
       - retiring more objects;
       - loading boot-only service code transiently and reusing its space
         after boot.

       A third OS bank is not a valid recommendation.

## Constraints

- Production unchanged: the image hash is identical to package 35's, and the
  simulator default stays revision 12.
- Measurement and placement only. No real driver or VFS migration, no new
  mechanisms, and no rewrites for size (idiom savings are estimates in the
  report, not code).
- Reuse the package-34/35 tooling and spike. Don't build parallel layout
  tools.

## Validation (spike rule)

```sh
make clean && make check                 # production hash unchanged
make rsvc-spike-selftest ZOS_RSVC_SPLIT=6000   # or the target name you add; boots at 6000h
python3 -m unittest tests.test_decoder_rev13 tests.test_rsvc_spike tests.test_rsvc_spike_sim -v
git diff --check
```

Build no other images and run no `unittest discover` after building images.
Report the wall-clock time; the target is under 15 minutes.

Hardware: optional. If the owner programs the `6000h` variant, the spike
image can be run on the board; otherwise record `PENDING (spike)`.

## Acceptance criteria

The deciding question is "does it boot, and what are the numbers".

- The spike boots at the `6000h` split, and the report gives the measured
  fixed core, cold half, service-bank hot and out-of-window tiers, and GAL
  terms at both splits.
- The verdict (a)/(b)/(c) is stated with bytes.
- The production image is unchanged.
