# Correction

**Scope narrowed (project owner, 2026-10-07).** Package 36 evaluates **only
transport A (the revision-13 window) at the 16/32 split (`6000h`)**.

Drop the following:

- **Transport B (the 8 KiB slot overlay).** Do not evaluate it, compare it,
  count its product terms or build anything for it. Package 35 settled
  that question. Ignore the transport-B material in
  `docs/architecture-proposal.md` and the package-35 report except as
  background.
- **New measurements at the `8000h` (24/24) split.** Do not run the layout,
  GAL or spike measurements at `8000h`. Where the report needs a baseline,
  quote package 35's measured `8000h` numbers (with the section reference),
  and add no new runs.

Requirements 2-6 change as follows:

| req | was | now |
|---|---|---|
| 2 | fixed core and cold half at `6000h` and `8000h` | `6000h` only: fixed core against 16 KiB, cold half against 32 KiB |
| 3 | service-bank ledger against 32 KiB and against 24 KiB | against the 32 KiB window and the 32 KiB out-of-window tier only |
| 4 | `6000h` window terms | unchanged: `6000h`, with and without the mode-10 aperture; no other variants |
| 5 | spike at `6000h` | unchanged; compare cycles with package 35's published figures |
| 6 | ledgers at both splits | ledgers at `6000h`; one baseline line quoting package 35 |

Requirement 1 (the classification) is unchanged. If you have already done
work on B or the `8000h` split, stop there. Don't extend it or polish it,
and leave it out of the report.

The validation batch and the acceptance criteria are otherwise unchanged.
In the acceptance criteria, "at both splits" now means "at `6000h`".
