# Task

Let loadable modules register path-based filesystem providers through driver
ABI v3, and mount them in the normal mount phase. Complete the kernel
file/directory API with the M9 mutation set and the root-directory merge, and
prove it with a test-only writable RAM provider module. VFS gets no cache; the
directory name is historical.

## Context

Dispatch only after packages 25 (with corrections 01 and 02), 25a and 25b are
accepted. Entry check: the 25a retention test passes, so no M1-M7 target,
flag, hook, smoke mode or `tests/target/m1..m7` directory exists, and the
production build has a single VFS/ROMFS boot path and a single derived arena
geometry. If any pre-M8 machinery is still present, stop and report; do not
work around it. Read `work/00-WORKER.md`, architecture sections 32.6-32.12, 32.22,
32.27-32.33 and 32.39, and `work/M9-REFERENCE.md`. There is no
backward-compatibility requirement.

Current state:
- `zdriver_api` is the 14-byte ABI-v2 block, pinned by `_Static_assert`s in
  `include/zephyros/driver.h`. `tools/zmodpack.py` and the loader enforce
  `DRIVER_ABI_VERSION`.
- A failed module init is rolled back transactionally through the
  device-registry and IRQ checkpoints. Provider registration must join that
  transaction.
- After correction-02, providers are path-based (`include/zephyros/vfs.h`,
  14 operations) and VFS mount selection is flat.

## Requirements

- **Driver ABI v3.**
  - Add `fs_register` to `zdriver_api` and set `ZDRIVER_ABI_VERSION` and
    zmodpack to 3.
  - Rebuild and repack every production and test module. The loader rejects
    any other ABI.
  - Update the static asserts, `docs/module-format.md` and the host tests.
  - `fs_register` succeeds only during the module phase. It rejects null or
    malformed providers, duplicate names (case-insensitive) and a full
    registry (capacity 4) with negative `ZOS_E*`.
  - Registrations made by a module whose init then fails are removed exactly
    by the loader's rollback, together with its devices and IRQs.
- **Normal mount phase.**
  - After the module phase, instantiate every non-system entry in table
    order. A missing provider or a failed `mount()` is a mount failure.
  - A required mount failure panics with `vfs: required mount <path> failed
    0xNN`. An optional mount failure prints `vfs: <path> unavailable 0xNN`
    and the rest of the namespace stays usable.
- **Kernel file/dir API** (`kernel/vfs/`, kernel-only), operating on
  caller-provided state (package 27 adds the descriptor pool):
  - open with `ZFS_O_READ/WRITE/CREATE/EXCL/TRUNC`, read, write, seek
    (32-bit, SET/CUR/END, negative result rejected), stat, sync, close;
  - opendir, readdir, closedir;
  - mkdir, rmdir, unlink, rename.

  Semantics:
  - A write advances the offset only after the provider reports success.
    EOF is a successful zero-byte read, and short reads are valid.
  - Opening a directory returns `ZOS_EISDIR`; opendir on a file returns
    `ZOS_ENOTDIR`. Unknown flag bits, or `WRITE`/`TRUNC`/`CREATE` without
    the needed access, return `ZOS_EINVAL`.
  - A rename whose two paths select different mounts returns `ZOS_EXDEV`.
  - rmdir, unlink or rename of a mountpoint returns `ZOS_EBUSY`; mkdir of a
    mountpoint returns `ZOS_EEXIST`.
  - An operation needing `/` while it is unmounted returns `ZOS_ENODEV`,
    while `stat("/")` and root readdir still work.
  - A null mutation pointer returns `ZOS_EROFS`.
  - `close` calls `sync` and then the provider's `close`.
- **Root merge.** `readdir("/")` first yields each mounted root-level
  mountpoint as a DIR entry. It then yields the `/` provider's entries,
  skipping any whose name equals a mountpoint (case-insensitive), so the
  mountpoint shadows it. The merge state is a small VFS-owned field of the
  directory handle; no extra table.
- **Test-only RAM provider** (`tests/modules/ramfs.c` + `ramfs.json` →
  `ramfs.zmod`, ABI v3), registering provider `ramfs`:
  - path-based and hierarchical, honoring ASCII case-insensitivity;
  - bounded: 16 nodes, 4 KiB of data per instance, two instances;
  - test controls selected by documented reserved names: fail the next write
    with `ZOS_EIO` without committing; make open handles report
    `ZOS_ESTALE`; refuse mount;
  - per-operation call counters and an open-handle count for acceptance.

  It never enters production manifests or the production ROMFS.
- **Configurations and tests.** Add `tests/m9/` mount configurations: `/` =
  ramfs (required), `/R2` = ramfs (optional), and failure variants. The M9
  target and simulator suites must cover:
  - ABI v3 registration, duplicate rejection and rollback;
  - required and optional mount failure;
  - every mutation semantic and error above;
  - root merge and shadowing;
  - the section 33 sizes (1, 127, 128, 129, 511, 512, 513, >64 KiB via
    seek/read windows);
  - stale handles and failed confirmed writes (offset unchanged);
  - `EXDEV`.
- **Ledger.** Report the `bank7:` ledger before and after. Record the bytes
  per line of the new kernel C code, because the supervisor checkpoint uses
  it.

## Files

- `include/zephyros/{driver,vfs}.h`, `kernel/module/loader.c`, `kernel/vfs/`
- `tools/{zmodpack,mapcheck,mountgen}.py`, `modules/manifests/*.json`, `tests/modules/`
- `Makefile`, `tests/m9/`, `tests/target/m9/`, `tests/test_m9_*.py`, `tests/test_zmod.py`
- `docs/{module-format,vfs,memory}.md`

## Constraints

- No cache of any kind in VFS. No syscalls, descriptor pool, CWD, exec, block
  class or IOC-FAT.
- No dynamic allocation. Use the shared pathname scratch buffer, plus a second
  one for `rename` only.
- The production `config/mounts.json` stays `/SYSTEM` only. ramfs and its
  hooks stay under `tests/`.
- All module bytes change, so hardware must be rerun.

## Validation

```sh
make clean && make check
make zmod-test romfs-test ioc-test hid-test v9958-test monitor-test \
     m8-selftest m8-fallback-selftests \
     m9-vfs-selftest m9-provider-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod
make clean && git status --short
```

Flash production and run `make smoke-hardware-m8 SERIAL_PORT=...`; the boot
must reach the monitor with HID and V9958 bound. Record `PENDING` if hardware
is unavailable.

## Acceptance criteria

- ABI v3 modules register providers transactionally, and mount failures
  behave as specified.
- All mutation, merge and error semantics are demonstrated against ramfs.
- The ledger and code density are reported, and the production boot works on
  hardware or is recorded `PENDING`.
- The supervisor budget checkpoint follows this package.
