# Task

Recover bank-7 space before M9 continues, without changing the memory model's
mode semantics. Compile kernel and modules for size, and derive the code/data
boundary from the linked runtime-data size instead of the fixed `C000h`. Add a single bank-7
budget ledger that every later package reports against.

## Context

Dispatch only after package 25, its corrections 01 and 02, and package 25a are accepted. ROMFS deduplication moved to correction-02. Use the post-correction-02 numbers as the "before" ledger. Read
`work/00-WORKER.md`, architecture sections 7, 22.2, 30.2 and 32.19-32.29,
`docs/memory.md`, and the budget section of `work/M9-REFERENCE.md`.

Measured state after package 25:
- Kernel `_CODE` is 24,291 bytes and ends at 7EE6h.
- The production arena is `8000h-BFFFh`, exactly the 32-granule floor, with
  about 150 bytes of headroom.
- `_DATA` is 1,210 bytes at fixed `C000h`, inside a `C000h-DEFFh` region of
  7,936 bytes, so about 6.7 KB is reserved but unused.
- The kernel and modules compile with no SDCC optimization options. A trial
  build with `--opt-code-size --max-allocs-per-node 50000` on kernel C only
  measured 1,849 bytes smaller.

The project owner chose to stay within bank 7 and trimmed the M9 architecture
(section 32.39). There is no backward-compatibility requirement (see
M9-REFERENCE). A supervisor checkpoint after package
26 decides with measured numbers whether M9 can continue within bank 7. This
package must not introduce a second kernel bank, overlays or far calls.

## Requirements

- **Size-optimized compile.**
  - Add `ZOS_SDCC_OPT := --opt-code-size --max-allocs-per-node 50000` to
    `platform/zephyr80/config.mk`.
  - Apply it to kernel `CFLAGS` and module `MOD_CFLAGS`.
  - Leave `user/` and ZEX builds on their current flags (their size is not
    bank-7 resident). Keep the flag sets separate.
  - Audit every C-coded bounded poll or delay loop in kernel and drivers
    (IOC, HID, V9958, SIO, the connect delay) for cycle-count assumptions.
    Timing-critical loops already live in assembly; any C loop whose bound
    is derived from instruction timing must be recalibrated or moved to
    assembly, with the reasoning written down.
  - Report kernel bytes and per-module granules before and after.
- **Derived bank-7 data base.** Replace the fixed `-b _DATA = 0xC000` with a
  value derived by the existing two-pass geometry build:

  ```text
  data_size  = l__DATA + l__INITIALIZED          (from pass 1)
  data_base  = align_down(DF00h - data_size, 512)
  arena_end  = data_base
  arena      = [align_up(__kernel_code_end, 512), arena_end)
  ```

  - The generated geometry include carries `data_base`, and the linker
    command and `arena.asm` consume it.
  - `__driver_arena_end` follows `arena_end`, and the loader already uses
    linker-exported bounds.
  - mapcheck enforces the derived `_DATA` range, no overlap with the arena
    or the ISR stack, and the unchanged 32-granule production floor.
  - Every check, document or constant that assumes `C000h` is the data start
    or the arena end must use the derived value. `ZOS_BANK7_LOAD_END` becomes
    the maximum load end, not a fixed boundary. Verify that runtime-data
    zeroing at startup uses the linked bounds, not `C000h`.
  - Builds stay reproducible: two clean builds must produce identical bytes.
- **Single geometry, honest naming.** Package 25a removed every fixed-arena
  image. What remains of the "fixed" geometry is only the placeholder the
  first (probe) link uses: the `A000h`/16-granule constants and
  `ZOS_DRIVER_ARENA_DERIVED` in `platform/zephyr80/memory.inc`, the
  `.org ZOS_DRIVER_ARENA_BASE` branch in `kernel/module/arena.asm`, the
  zmodpack fixed-plan path, and the `derived=False` geometry output asserted
  as "legacy" in `tests/test_m8.py`. Rework the two-pass derivation so the
  probe link places no arena that could constrain kernel growth (the
  `A000h` placeholder would fail once the kernel passes it). Rename every
  remaining "legacy"/"fixed" reference to "probe", or delete it. Fix the stale
  `memory.inc` comment that says the constants are kept "for reproducible
  pre-M8 images". Remove mapcheck's guards and comments for deleted symbols
  (`_module_catalog_load_all`, `kernel/module/embedded.c`); the retention
  test already prevents their return.
- **V9958 font staging.** The font already lives in ROMFS and is streamed to
  VRAM. What remains resident is 352 bytes of init/reset-only staging BSS
  (`v9958_font_group[256]`, `v9958_atlas_row[96]`). Before this package,
  `v9958.zmod` was 4,008 + 724 = 4,732 bytes, 10 granules, which is 124 bytes
  over the 9-granule line. After the size-optimized compile, if it still
  needs 10 granules:
  - shrink the font read chunk from 32 glyphs (256 bytes) to 8 glyphs (64
    bytes);
  - write each atlas scanline in matching 24-byte segments;
  - keep the ROMFS DATA-only rule, the font validation, the exact
    VRAM/atlas result and the `ZVIDEO_RESET` reload.

  The target is 9 granules. Prove the VRAM contents are identical in the
  V9958 simulator tests and confirm visually on hardware.
- **Budget ledger.** `pack_image.py` and the `arena.plan.json` report print one
  line, and emit matching JSON:

  ```text
  bank7: code <bytes> end <addr> | arena <n> granules (<used> boot, <free> free) | data <bytes> at <addr> | isr 256 | slack <bytes>
  ```

  Add a host test that checks the line against the map. Add the ledger to
  `docs/memory.md` and record the package-25b numbers there.
- **Documentation.** Update architecture sections 7.2 and 30.2 and
  `docs/memory.md` to describe the derived boundary: the bank-7 layout is
  kernel code, then the derived arena, then the derived runtime data, then
  the ISR stack. Mode 10/11 semantics are unchanged.

## Files

- `platform/zephyr80/{config.mk,memory.inc,memory.h}`, `linker/zephyr80.lk`, `Makefile`
- `kernel/module/arena.asm`
- `tools/{mapcheck,pack_image}.py`, `tests/test_m8.py`, `tests/test_m4.py`, `tests/test_source_layout.py`
- `docs/{memory,architecture}.md`

## Constraints

- No new features and no M9 package-26 work. Mode 10/11 mapping, the ISR
  stack, common memory and the IM2 page are unchanged. No kernel code moves
  to common memory.
- Do not lower the 32-granule floor or any validator.
- ZMOD formats and ABI are unchanged by this package; module bytes change
  because of the optimizer.

## Validation

```sh
make clean && make check
make zmod-test romfs-test zex-test monitor-test ioc-test hid-test v9958-test \
     m8-selftest m8-fallback-selftests \
     m9-vfs-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod build/modules/monitor.zex
make clean && git status --short
```

Report the before/after ledger and the savings from each measure separately.

Hardware is required, because every kernel and module byte changes and IOC
code is recompiled. Flash production and run `make smoke-hardware-m8`, then a
manual HID-typing and V9958-console check. Also run
`make smoke-hardware-m8-ioc` with the M8 IOC image, because the IOC
command/bulk lanes are the most timing-sensitive C path. Record `PENDING` for
anything not run.

## Acceptance criteria

- The production ledger shows the size-optimized kernel and modules,
  and the arena extended to the derived data base, with the 32-granule floor
  still enforced.
- Every acceptance image passes, the monitor works, and the
  builds are reproducible.
- The production boot and the IOC smoke pass on hardware, or are recorded
  `PENDING`.
