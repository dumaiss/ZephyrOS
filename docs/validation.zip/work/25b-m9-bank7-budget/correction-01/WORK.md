# Correction

Two small budget items from the 25b review. Neither is a 25b defect. The
V9958 item was added to the 25b contract after the worker had already started,
and the fallback item is a robustness gap in the new geometry tooling.

1. **V9958 font staging.** `v9958.zmod` is 4,008 image + 724 BSS = 4,732
   bytes, which is 10 granules and 124 bytes over the 9-granule line. 352 of
   those BSS bytes are staging used only at init and `ZVIDEO_RESET`:
   `v9958_font_group[256]` (one 32-glyph group) and `v9958_atlas_row[96]`.
   The font itself already lives in ROMFS and is streamed to VRAM.
2. **Silent `C000h` fallback.** `tools/mapcheck.py` and `tools/pack_image.py`
   read `ZOS_DRIVER_ARENA_END` (and related derived values) with
   `values.get(..., DEFAULT_ARENA_END)` where `DEFAULT_ARENA_END = 0xC000`.
   If the generated geometry ever lacks a key, the tools silently validate
   against the retired `C000h` boundary instead of failing.

Read `work/00-WORKER.md`, `drivers/v9958/`, `tests/test_v9958*.py`, the
geometry code in `tools/{mapcheck,pack_image,zmodpack}.py`, and
`work/M9-REFERENCE.md`. There is no backward-compatibility requirement.

## Required changes

- **V9958:**
  - Reduce the font read chunk from 32 glyphs (256 bytes) to 8 glyphs (64
    bytes) and write each atlas scanline in matching 24-byte segments
    (8 glyphs x 6 px / 2 per byte). This shrinks `v9958_atlas_row` to 24
    bytes.
  - Keep the ROMFS DATA-only resource rule, the 2048-byte size validation
    before any port I/O, the normal and reverse atlases, and the
    `ZVIDEO_RESET` reload.
  - The resulting VRAM contents must be byte-identical to today's. Target:
    `v9958.zmod` at 9 granules or fewer. If the change does not reach 9, stop
    and report the measured size instead of trimming anything else.
- **Tools:** every geometry value the derived build is supposed to produce
  (arena start/end, data base, granules, kernel end) is required. A missing
  key raises a clear error naming the key and the include it was expected
  in. Delete the `DEFAULT_ARENA_*`/`DATA_BASE` fallback constants that only
  existed for that path. Add a negative test with a geometry include that
  lacks `ZOS_DRIVER_ARENA_END`.

## Validation

Following `00-SUPERVISOR.md` "Validation depth", the worker runs and records:

```sh
make clean && make check
make v9958-test m8-v9958-selftest m8-v9958-fontfail-selftest m8-console-selftest m8-selftest
python3 -m unittest tests.test_v9958 tests.test_v9958_sim tests.test_v9958_console tests.test_m8_acceptance tests.test_m8 tests.test_pack_image -v
git diff --check
```

The V9958 simulator suite must assert identical VRAM contents for both atlases
before and after: capture the expected bytes from the current implementation
first. Record the `bank7:` ledger and the `v9958.zmod` image, BSS and granule
counts before and after. Explain every skipped test in the listed suites.

Hardware: flash production and confirm the V9958 console renders normal and
reverse text correctly (a visual check), and that an `ESC c` full reset
redraws correctly. Record `PENDING` if hardware is unavailable.

## Acceptance criteria

- `v9958.zmod` needs at most 9 granules, VRAM atlas contents are identical,
  and the font-failure path still rolls back cleanly.
- Missing derived-geometry keys fail loudly, proven by a negative test.
- The listed suites pass with skips explained, and the console renders
  correctly on hardware or is recorded `PENDING`.
