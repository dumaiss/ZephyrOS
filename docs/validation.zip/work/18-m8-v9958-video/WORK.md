# Task

Implement the direct-hardware V9958 core as `v9958.zmod`: hardware-safe
initialization, the native VIDEO class operation surface, ROMFS-backed 6x8 font
atlas setup, and low-level graphics/command primitives. This stage registers a
VIDEO device but deliberately does not yet advertise character/console output.

## Context

Start only after package 17 is accepted. Read `work/00-WORKER.md`, architecture
sections 30.2 and 30.4, and the V9958 material in `work/M8-REFERENCE.md`.
Directly inspect the pinned Zephyr-80 `v9958.asm` and hardware bring-up record.
They are read-only. The established target is 85x26, 6x8 CP850, GRAPHIC 6 with
128 KiB VRAM. Physical WAIT/timing evidence is mandatory.

## Requirements

- Add paired declarative platform constants for V9958 ports `A0h-A4h`, latch
  bits, required register values and bounded bootstrap delay. All instruction
  sequences, loops and behavior live in `drivers/v9958/`.
- Add `include/zephyros/video.h` with `zvideo_ops.send` and exact native values:
  CTRL_WRITE=1, DATA_WRITE=2, DATA_BLOCK=3, PALETTE_WRITE=4,
  INDIRECT_WRITE=5, PRESENT=6, RESET=7. Define the seven matching VIDEO
  capability bits allocated by package 14. These are native operations, not a
  compatibility packet ABI.
- Validate every operation before I/O. PRESENT/RESET require zero length;
  write operations require non-null payload and nonzero length. Unsupported
  operations return `ZDEV_ENOTSUP`. Stream the full 16-bit length for direct
  writes—there is no historical 16-byte limit. Capabilities are authoritative.
- Import the exact 2048-byte CP850 6x8 font from the pinned reference into a
  reviewable ZephyrOS source asset and deterministically produce
  `v9958-6x8.font` as ROMFS DATA. Test SHA-256
  `6db207e0466a05af42894d378261f876da51bb391240e1beda4f1d5f12ec442f`.
  Load it during module init through the ABI-v2 resource imports in bounded
  chunks; do not embed it in resident ZMOD image/BSS and do not depend on the
  adjacent repository.
- Port the exact initialization discipline: software latch shadow preserving
  D0; porch off; paced R#25 WTE/VDS off; R#8=`08h`; stop command; program all
  G6 and selector/scroll registers including R#0=`0Ah`, R#2=`1Fh`, R#9=`88h`;
  enable WTE then porch; program the palette under hardware WAIT; upload
  normal/reverse font atlases; clear screen; initialize sprite cursor; present;
  finally enable display. Re-establish all owned state on RESET.
- Port the VDP wait, register, palette, indirect, VRAM-addressing and command
  helpers needed by the reference renderer. Status register 2 remains selected
  while owned; command engine operations wait for CE completion. Keep `/INT`
  disabled and do not claim `IRQ_VDP_FF` in M8.
- Register `v9958.0`, class `ZDEV_VIDEO`, with `class_ops` and the supported
  VIDEO bits only. `char_ops` is null and CONSOLE_OUT absent until package 19.
  Module init/resource/VDP failure rolls back without affecting IOC/HID/SIO.
- Extend simulator port modeling to record and validate latch preservation,
  paced bootstrap order, WAIT-enabled palette phase, register values, font
  reads/atlas bytes, command completion waits, 128-KiB R#14 addressing, reset,
  long DATA_BLOCK, and malformed/no-I/O cases. Add map/source tests excluding
  CP/M tables, fixed BIOS addresses, Virtual Drip framing and IOC/HID imports.
- Add a target image that uses native VIDEO operations to reset, write a
  deterministic visible color/pattern and exercise a payload above 16 bytes;
  report pass/fail independently over early SIO. Preserve a visual validation
  checklist and image/module/font hashes.

## Files

- `include/zephyros/video.h`, `platform/zephyr80/hardware.{h,inc}`
- `drivers/v9958/`, `drivers/v9958/assets/`, `modules/manifests/v9958.json`
- `recovery/manifest.json`, M8 manifests, `Makefile`
- `tests/test_v9958*.py`, `tests/target/m8/`, `tests/z80sim.py`
- `tools/{fontpack,mapcheck,serial_smoke}.py` as needed
- `docs/{devices,architecture}.md`, `docs/validation/`

## Constraints

- No IOC firmware, Virtual Drip transport, CP/M ABI, video syscall, HID input,
  VDP interrupt, or terminal parser in this package.
- Never guess a shorter initialization/timing sequence. Preserve the proven
  ordering and explicit software pacing before native WAIT is enabled.

## Validation

```sh
make clean
make check
make zmod-test
make v9958-test
make m8-v9958-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean
```

Flash the named V9958 image, run `make smoke-hardware-m8-v9958
SERIAL_PORT=...`, and visually confirm the documented pattern, correct palette,
stable 128-KiB addressing and reset/repaint. Simulator success is not timing
acceptance.

## Acceptance criteria

- The VIDEO class performs all seven validated native operations, including a
  block above 16 bytes, and malformed requests cause no port writes.
- The font is ROMFS DATA rather than resident module storage; all M8 modules
  still fit the reported arena.
- Hardware confirms the non-negotiable WAIT/porch/DRAM sequence and visual
  output, with VDP interrupts disabled and no firmware changes.
