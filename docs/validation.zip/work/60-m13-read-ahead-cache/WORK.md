> **DRAFT.** Runs after 59. Drivers (IOC, IOC-FAT), the nucleus (the
> bulk-tier write mirror, the copy primitives), the simulator's
> controller model. **No IOC firmware change; no bank outside bank 6; no
> change to the memory model or the copy-path architecture.**

# Task

Use the RAM for a file cache and overlap the host's per-block work with
the controller's. After 59 the board reads 512 B in 17.05 ms (29.2 KiB/s),
4 KiB requests at 15.3 ms per block; CP/M takes 12.8 ms on the same
firmware. Each block today: FS2 READ, idle polling while the controller
reads the card, READY, bulk, copy out. The idle wait is the window.

Firmware facts this design rests on (`Zephyr-80/Code/MCU/IOController`,
read-only): the reply to a command is clocked out as soon as dispatch (the
card read) ends, without waiting for the host, into a three-byte FIFO; the
bulk phase waits up to 500 ms for the host's RTS. The SIO1 interrupt is on
the IM2 chain (lowest priority).

Read: `work/00-WORKER.md`; the 58/59 records; `drivers/ioc/*`,
`drivers/iocfat/iocfat.c`; `kernel/ipc/ipc.c` (copy paths A/B/C, the bank
copy gate); architecture 4.9, 5.x; `docs/memory.md`.

## Requirements

1. **Cache in bank 6's boot/bulk tier.** That tier (0000h-5FFFh) holds
   only boot stubs and the V9958 font; ~21.7 KiB is free. IOC-FAT declares
   a BSS-only bulk segment of 16 KiB (32 slots of 512 bytes); the packer
   places it and the loader registers the extent, as for any bulk data.
   The nucleus adds `bulk_write`, the mirror of `bulk_read` (same owner
   binding and bounds, one `LDIR` in mode 10 over bank 6). A fill moves a
   received block from the ring into its slot; a hit `bulk_read`s the
   slot into the ring and copies out from there. No other bank is used.
2. **IOC-FAT block cache.** Blocks keyed by (file identity, block number),
   LRU, write-through: a write updates or invalidates its blocks; rename,
   delete, truncate, unmount and a stale generation invalidate. Reads that
   hit never touch the IOC link. The one-slot cache goes.
3. **Read-ahead with a pipelined fill.** A sequential miss fills several
   blocks ahead (a policy constant, measured) through a small ring
   (2-4 blocks) in IOC-FAT's io segment (8000h-BFFFh, the bulk receive's
   direct target and the one-`LDIR` copy-out source). Per
   block: send FS2 READ for k+1, then do block k's work (store to the
   cache, copy to the caller) while the controller reads the card, catch
   k+1's reply, run its bulk. One IOC operation per block (command + READY
   + bulk), replacing the two calls.
4. **Catching the reply.** The reply must be taken within about three
   command-lane byte times. Measure the worst stretch the "block k" work
   holds interrupts masked; then either enable the SIO1 receive interrupt
   only inside the fill (handler in the IOC driver) or split block k's
   work into pieces short enough to poll between. Record the choice and
   its margin. The link stays polled everywhere else.
5. **Link ownership.** A fill holds the IOC link (the existing busy
   guard); keyboard polling waits at most one block. A read-ahead in
   flight when the caller seeks, closes or switches file is completed
   and kept (or drained), never abandoned mid-protocol.
6. **Fewer, cheaper copies.** One `copy_out` per contiguous run, not per
   512-byte block: the ring keeps consecutive blocks contiguous, and a
   multi-block read or hit copies each run at once (today each call costs
   ~0.6 ms beyond its `LDIR`). The copy primitives - the nucleus's path A
   and B copies, path C's two passes, `bulk_read`/`bulk_write` and the
   drivers' `kos_block_copy` - move bytes with an unrolled `LDI` run
   (16 per iteration, ~16.6 T/byte against `LDIR`'s 21), remainder
   included, same results and the same interruptibility.
7. **The simulator's controller** models a card-read latency per FS2 READ
   (board-derived; a cache-hit figure for repeated blocks) so the overlap
   is measurable, and the reply is pushed unsolicited as on the board.
8. **Measure** before and after: board SDBENCH (cold), a re-read of the
   same file, `vgmplay night.zvg`, the phase table, and crossings per
   read. Targets: cold 512 B at or under CP/M's 12.8 ms; a cache hit under
   2 ms per 512 B.
9. No behaviour change beyond speed: same bytes, errors and FS2 traffic
   order per block; every replay passes.

## Owner checklist (production image)

1. SDBENCH twice in a row (cold, then cached); checksum PASS both.
2. `hwtest` 4/4, `fs_selftest` 37/37, `timer card`, `vgmplay night.zvg`
   (0 underruns), keyboard responsive during a long read.

## Validation

```sh
make && make phase-image && make fs-selftest && make ipc-selftest
python3 -m unittest tests.test_ioc tests.test_iocfat tests.test_readpath tests.test_hwtest_sim tests.test_console_acceptance tests.test_shell_sim tests.test_device_release tests.test_ipc
git diff --check
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-m13-read-ahead-cache.md`.
