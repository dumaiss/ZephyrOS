# Task

Apply the Mn-1 retention rule at the start of M10. M9 becomes the reference
milestone (Mn-1), and M8's acceptance machinery is retired. Before deleting
anything, move the coverage of every M8 mechanism that is still in the system
(the IOC transport, HID, V9958 and the console binding and fallback) onto
subsystem-owned tests that run on the current boot path.

## Context

Dispatch only after M9 is closed (package 31 accepted and committed). Read
`work/00-SUPERVISOR.md` ("Milestone retention and compatibility"),
`work/00-WORKER.md`, `work/M10-REFERENCE.md`, the package-25a contract (the
precedent), the Makefile, `tools/serial_smoke.py`, and `tests/`. There is no
backward-compatibility requirement.

M8 machinery today (verify; the tree is authoritative):

```text
make targets  m8-ioc-selftest m8-hid-selftest m8-hid-noioc-selftest
              m8-hid-badioc-selftest m8-v9958-selftest m8-v9958-fontfail-selftest
              m8-console-selftest m8-selftest m8-fallback-selftests
smoke modes   smoke-hardware-m8{,-ioc,-hid,-v9958,-console,-fb-nohid,
              -fb-nohid-nov9958,-fb-badioc,-fb-arena}
tests         tests/target/m8/*, tests/m8/*, tests/test_m8*.py, and the
              m8-image parts of test_{ioc,hid,v9958}*_sim.py
```

## Requirements

- **Migrate coverage first**, by subsystem (`tests/target/<subsystem>/`,
  `tests/test_<subsystem>*.py`, smoke modes named by subsystem), on the
  current production boot path. Fold cases into as few images as practical.

  | mechanism | was | must be covered by |
  |---|---|---|
  | IOC command lane: PING, level, link sync, sequence/CRC faults, recovery | `m8-ioc-selftest` | `tests/target/ioc/` image plus the `IocCommandPeer` sim suite; hardware smoke mode `ioc` |
  | IOC bulk lane: READY/DONE, read/write 1/128/512, unknown-write | `m8-ioc-selftest` | same `ioc` image (the `/SHARED` service or FS2, whichever the current peer serves) |
  | HID text input, ring, stuck-doorbell penalty, missing/bad IOC dependency rollback | `m8-hid*-selftest` | `tests/target/hid/` (including fake-IOC fixtures); hardware smoke mode `hid` |
  | V9958 init, font/atlas, renderer, font-failure rollback | `m8-v9958*-selftest` | `tests/target/video/`; hardware smoke mode `video` |
  | console binding preference and fallbacks (no HID, no HID or V9958, bad IOC, arena exhaustion) | `m8-console-selftest`, `m8-fallback-selftests`, `m8-selftest` | `tests/target/console/` fallback set |

  For every row, record the exact test and image names that now cover it. A
  mechanism with no current coverage is a stop-and-report finding.
- **Delete** the M8 make targets, build directories, smoke modes, manifests,
  fixtures and `tests/target/m8/`, plus any production conditional or flag
  that exists only for them. The M9 acceptance images stay; M9 is now Mn-1.
- **Retention guard.** Move `ALLOWED_MILESTONES` in
  `tests/test_source_layout.py` from `(8, 9)` to `(9, 10)`.
- **Docs.** Update `README.md`, `docs/devices.md` and `docs/boot.md` (the
  hardware smoke table) and the architecture's M8 implementation notes,
  naming the subsystem tests that replace each retired image.

## Constraints

- No production kernel, driver or module byte change: prove the production
  image hash is identical to the M9-close image.
- No new features. Do not weaken any assertion during the migration; a
  moved check must stay at least as strict.

## Validation

At the efficiency defaults, run one formal batch:

```sh
make clean && make check
make <every new subsystem image target>
python3 -m unittest <the new subsystem suites> tests.test_source_layout -v
git diff --check
```

Report:
- the coverage table with test names;
- the targets, files and lines removed;
- the full-suite runtime before and after;
- the production hash (identical to M9 close).

Hardware: run each new subsystem smoke mode once (`ioc`, `hid`, `video`,
and one console-fallback row), because the images are new even though
production bytes are not. Record `PENDING` for any row not run.

## Acceptance criteria

- No M8 target, image, smoke mode, manifest or test directory remains, and
  the retention guard is `(9, 10)`.
- Every M8 mechanism is covered by a named subsystem test on the current
  boot path.
- Production bytes are unchanged.
