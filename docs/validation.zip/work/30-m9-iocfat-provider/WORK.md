# Task

Implement `iocfat.zmod`, the resident path-based filesystem provider that
exposes the deployed MCU FatFs service (FS2) to VFS, including its own
write-through 512-byte file-data cache. Mount it as the optional writable root
`/` in production, so `/SYSTEM` stays available when the SD card is absent or
broken.

## Context

Dispatch only after package 29 is accepted and the post-28 budget checkpoint (M9-REFERENCE) has fixed the cache slot count. Before work starts the ledger is: `bank7: code 28431 bytes end 8F0Fh | arena 35 granules (20 boot, 15 free) | data 2241 bytes at D600h | isr 256 | slack 63 bytes`; `common: used 2104 of 7424 bytes`. Read `work/00-WORKER.md`,
architecture sections 32.3-32.8, 32.12, 32.16-32.19, 32.28, 32.32.4-32.32.6
and 32.39, and the "IOC FS2 service" section and status mapping of
`work/M9-REFERENCE.md`. Also read `fs2.c` and `test_fs2_contract.py` in the
pinned firmware tree, and use the CP/M `native_vfs.inc` client as the
sequencing reference. Copy or adapt; never add a build dependency on
`../Zephyr-80`. There is no backward-compatibility requirement.

The provider ABI (v3 `fs_register`, 14 path-based operations), the descriptor
pool, the syscalls, nested exec and `fstest.zex` already exist and were proven
against ramfs. VFS, the syscalls and the IOC driver do not change, except for
defects found and reported.

## Requirements

- **Placement.** Put the provider in `fs/iocfat/` with manifest
  `modules/manifests/iocfat.json` (ABI v3, resident). All FS2 command,
  response, payload-offset and status constants are private to
  `fs/iocfat/`.
- **Init.**
  1. Find the first IOC with command + bulk read + bulk write, using only
     `device_find` and `device_interface`.
  2. Issue `FS2_CAPS` and require version 1, 2-byte tokens and chunk max of
     at least 512.
  3. Record the generation and flags.
  4. Register provider `iocfat`.

  Missing IOC, a CAPS failure or `UNKNOWN_CMD` fails init, with transactional
  rollback and the message `iocfat: unavailable 0xNN`.
- **`mount(source)`.** Accept only `ioc.0`; anything else returns
  `ZOS_EINVAL`. Re-query the generation and probe the root. `NO_MEDIA` and
  the not-mounted statuses map to `ZOS_ENODEV`. If CAPS reports `READ_ONLY`,
  every mutation returns `ZOS_EROFS`.
- **Path translation.**
  - Split the provider path into components and pack each one into 11-byte
    upper-case 8.3 FCB form.
  - Reject a component that cannot be represented with `ZOS_EINVAL`, before
    any IOC traffic: empty base, base longer than 8 or extension longer than
    3, more than one dot, a leading dot, space, or any of
    `*?/\:<>|"+,;=[]`.
  - Resolve the parent with `ROOT` plus one `PUSH` per directory component
    (at most 16; deeper returns `ZOS_EINVAL`), then issue the leaf command.
  - Never assume the resolver state persists between provider calls.
  - Case-insensitivity comes from FAT and upper-case packing (architecture
    32.8).
- **Handles.** Static pools sized to the CAPS slot counts (2 files,
  1 directory). Exhaustion returns `ZOS_EMFILE`. An open file holds its FS2
  token and the generation at open time. Tokens are never exposed. `stat`
  and `open` of `/` treat the root as a synthesized directory.
- **Open mapping.**

  | Flags | FS2 action |
  |---|---|
  | read only | `OPEN_RO` |
  | write, no create | `OPEN_RW UPDATE` |
  | `CREATE|EXCL` | `CREATE_NEW` |
  | `CREATE|TRUNC` | `CREATE_ALWAYS` |
  | `CREATE` alone | `UPDATE`, falling back to `CREATE_NEW` on `NOT_FOUND` |
  | `TRUNC` without `CREATE` | `UPDATE`, then `FS2_TRUNCATE` to 0 |

  `open` reports the size. Opening a directory returns `ZOS_EISDIR`.
- **Data path.**
  - `read` issues `FS2_READ` (explicit offset, at most 512 bytes), validates
    READY including the echoed offset, then calls `bulk_read`. The firmware's
    end-of-file reply is a successful short or zero read.
  - `write` issues `FS2_WRITE`, then READY, `bulk_write` and a matching
    DONE; only then does it report the count. `UNKNOWN_WRITE` and any DONE
    failure return `ZOS_EIO` and are never counted.
  - `sync` maps to `FS2_SYNC`, and `close` to `FS2_SYNC` then `FS2_CLOSE`.
  - Directories use `OPENDIR`, `READDIR` (where `END` means end) and
    `CLOSEDIR`. Unpack 8.3 names to `NAME.EXT` (no trailing dot).
    Attributes are 0 and times are `ZFS_TIME_UNKNOWN`.
- **Provider-local file-data cache** (architecture 32.19). Use
  `IOCFAT_CACHE_SLOTS` (a module build setting, default **1** as fixed at the
  post-28 checkpoint; raise it to 2 only if the final ledger with 2 slots
  still shows at least 2.5 KiB of slack, and report both ledgers) slots in
  module
  BSS. Each slot holds the owning open file, the FS2 generation at fill
  time, the aligned 512-byte offset, the valid count and `data[512]`.
  - A read hit is served locally. A miss reads the aligned block and fills a
    slot. Reads crossing a block boundary are split.
  - Write-through: only after a confirmed DONE, update or invalidate
    overlapping slots of the writing file.
  - Invalidate every slot of the *other* open file on a confirmed write, a
    truncating open, `unlink` or `rename` (FS2 serves at most two open files,
    so this is the whole coherence rule).
  - A generation change or `STALE` invalidates every slot.
  - LRU replacement.
  - Expose hit, miss, fill and invalidate counters through a `TEST-ONLY HOOK`
    for acceptance only; mapcheck keeps them out of production.
- **Staleness.** A `STALE` status, a generation mismatch on a handle, or a
  generation change on any reply returns `ZOS_ESTALE`; nothing is retried
  silently. A transport error returns `ZOS_EIO` and leaves the provider
  consistent. The IOC driver's existing link recovery handles the next
  operation.
- **Namespace operations.** `mkdir`, `rmdir` and `unlink` resolve the parent
  and send the leaf. `rmdir` checks emptiness first with
  OPENDIR/READDIR/CLOSEDIR and returns `ZOS_ENOTEMPTY` itself. `rename`
  with different parent directories returns `ZOS_EXDEV`. Document this FS2
  limitation; userland `mv` copies, as it does across mounts. A same-parent
  rename uses `FS2_RENAME`.
- **Gate-stack depth (decisive, measure early).** Every `FS_*` call into
  IOC-FAT runs on the 256-byte common gate stack: syscall entry, VFS, the
  provider, then the IOC driver's command/bulk path. The post-28 worst case
  is already 213 bytes (the `SYS_EXEC` path, measured after 28c). Build the IOC-FAT read/write
  path first and measure its worst-case depth in the simulator (the
  correction-01 canary, or the existing measurement) before writing the rest
  of the provider. The final design must keep the worst case at or below
  224 bytes (32 bytes of margin) and have a simulator test that asserts it.
  If it cannot, stop and report the measured chain per function, because
  the shared-kernel-syscall-stack decision goes back to the project owner. Do
  not work around it with a private provider stack the way V9958 did.
- **Kernel bytes.** After 28c the kernel ends at `8F0Fh`, which leaves 241
  bytes before the next granule boundary (`9000h`). Keep kernel-side changes
  to the boot list and mount configuration, within that headroom, and report
  them.
- **Programs are SDK programs.** `fstest` and any new IOC-FAT test program
  are built with `zex_program` from `user/sdk/` (`docs/sdk.md`). Test
  programs include only `zos.h`/`abi/zos` headers.
- **One documentation fix.** Architecture 32.12 still says `statfs` is
  "deferred to M10 with `df`". Make it match 32.26/32.34: deferred until a
  consumer requires it.
- **Production integration.**
  - Add `iocfat.zmod` to `recovery/manifest.json` and load it last, with
    optional semantics.
  - Add `{"path": "/", "filesystem": "iocfat", "source": "ioc.0",
    "required": false}` to `config/mounts.json`.
  - A healthy SD card prints nothing new. No card or no FAT prints exactly
    `vfs: / unavailable 0xNN`, and the console and monitor are unaffected.
- **Tests.**
  - A fake-IOC FS2 server test module or host fixture covering:
    - 8.3 packing and unpacking with the full rejection table;
    - resolver sequencing for depth 0-16;
    - every open mode;
    - READY/offset echo and EOF;
    - DONE-confirmed writes and the failure/unknown-write paths;
    - STALE/generation;
    - slot exhaustion returning `ZOS_EMFILE`;
    - `ENOTEMPTY` and cross-directory `EXDEV`;
    - `READ_ONLY` CAPS;
    - every cache rule, proven by FS2 command counts and the cache
      counters.
  - Static checks: no SIO ports, raw I/O or `drivers/ioc` include in
    `fs/iocfat/`.
  - `fstest.zex` gains an IOC-FAT section selected by mount configuration,
    so the same binary runs it against a real `/` on hardware.

## Files

- `fs/iocfat/`, `modules/manifests/iocfat.json`
- `config/mounts.json`, `recovery/manifest.json`, `kernel/main.c` (boot list)
- `tests/modules/`, `tests/m9/`, `tests/target/m9/`, `tests/test_iocfat*.py`, `tests/test_source_layout.py`
- `Makefile`, `tools/{serial_smoke,mapcheck}.py`, `docs/{vfs,devices,architecture}.md`

## Constraints

- Never modify firmware, the IOC transport or `/SHARED` (`20h-28h`). No FAT
  parsing on the Z80. No `statfs` or arbitrary truncate.
- VFS keeps no FS2 or cache knowledge.
- The `/SYSTEM` recovery path must work with the card removed. Hardware tests
  write only under a dedicated `/ZOSTEST` directory that the test creates and
  removes.
- Budget: report the `bank7:` ledger. The resident boot set (now including
  `iocfat.zmod` and its cache BSS) must meet the section 32.39 targets, or
  stop and report.

## Validation

```sh
make clean && make check
make m9-fs-selftest m9-iocfat-selftest
python3 -m unittest tests.test_iocfat tests.test_iocfat_sim tests.test_m9_fs tests.test_syscall_sim -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod
make clean && git status --short
```

IOC-FAT only consumes the IOC driver through its class interface and
does not change it, so no M8 image is built. Build `m8-ioc-selftest` only if
an IOC-FAT test fails in a way that could be a transport regression (see
`00-WORKER.md`, Mn-1 isolation).

Hardware, all with transcripts:

1. Production boot with a FAT card: flash production `build/zephyros.bin` and run `make smoke-hardware` (early serial banner), plus an operator check that the V9958 display shows the monitor prompt and HID input works (the serial `normal` mode cannot see a V9958-bound console).
2. Production boot with the card removed: `/ unavailable` is printed, and the
   monitor and console work.
3. `make smoke-hardware-m9-iocfat SERIAL_PORT=...` with a card, where
   `fstest` passes its IOC-FAT section, including the cache cases.

Record `PENDING` for anything not run.

## Acceptance criteria

- `/` is served by IOC-FAT through the path-based ABI with the full section 33
  IOC-FAT list, confirmed writes, generation-aware staleness and a coherent
  write-through cache, all inside the provider.
- Absent or failed SD leaves `/SYSTEM` and the recovery console fully usable.
- The simulator suites pass, physical evidence is recorded or `PENDING`, and
  the ledger meets the budget.
