# Correction

Package 30 stopped correctly at the bank-7 budget gate. The complete provider
(`fs/iocfat/iocfat.c`, 1601 lines) measures 6800 image + 641 BSS = 7441 bytes,
which is **15 granules**. That exactly fills the production arena (35 granules,
35 boot, 0 free, 63 bytes of data slack) against the 2 KiB slack target. The
supervisor's 9-11 granule projection was low: the code density is good (about
4.2 bytes per line), but the FS2 protocol surface is larger than estimated.

**Project-owner decision (2026-10-05):** trim IOC-FAT, **keep the one-slot
cache**, and **lower the end-of-M9 slack target to at least 1 KiB**. This
correction trims the provider to fit, then completes the production
integration and acceptance work that package 30 withheld.

Measured per-function `_CODE` (production build) guiding the trim:

```text
data path    write 522, read 498, exchange 110, ready 102, cache_fill 298, cache_hit 88
open         open 408, open_send 298
directories  readdir 359, opendir 327, closedir 126, dir_is_empty 84, dir_find 84
8.3 names    pack 292, unpack 224, parse 118, legal 83, pack_nth 57, text_equal 69
namespace    rename 241, same_parent 119, leaf_op 91, rmdir 87, unlink 73, mkdir 69
init/mount   init 323, mount 96, query_generation 60, reset/reset_files/reset_dirs 174
```

Read `work/00-WORKER.md` (including "Working efficiently"), the package-30
contract, `work/M9-REFERENCE.md` (the updated budget), architecture 32.17,
32.19 and 32.39, and `docs/sdk.md`. The package-30 contract still applies,
except as amended here. There is no backward-compatibility requirement.

## Required changes

1. **Fit: `iocfat.zmod` at most 6656 bytes (image + BSS), 13 granules.**
   Keep every behavior in the package-30 contract, including the one-slot
   write-through cache. Expected measures (use your judgment on the exact
   factoring and report per-function before/after):
   - **one FS2 bulk-transfer helper** shared by read, write and cache fill:
     request, READY validation (length, direction, echoed offset), bulk
     phase, and DONE confirmation for writes. Read and write keep only their
     offset/length/cache logic. Expected saving 250-400 bytes.
   - **table-driven open**: fold `open_send` into `open` and drive the
     open-mode mapping from a small constant table instead of branches.
     Expected 150-250 bytes.
   - **one 8.3 codec**: merge `parse`/`legal`/`pack`/`pack_nth` into a
     single component walker and simplify `unpack`; drop `text_equal` if the
     codec makes it redundant. Expected 150-250 bytes.
   - **shared directory plumbing**: one resolve-and-open path for
     `opendir`/`dir_is_empty`/`dir_find`, and one handle lookup. Expected
     100-150 bytes.
   - the size discipline in M9-REFERENCE (16-bit arithmetic where possible,
     no duplicated validation, constants in tables).

   If 13 granules cannot be reached without dropping a contract behavior,
   stop and report the per-function sizes. Do not drop the cache, and do not
   remove error handling or validation.
2. **Gate-stack depth (unchanged rule, do it early).** Measure the worst-case
   gate-stack depth through IOC-FAT read/write/readdir in the simulator. It
   must be at most 224 bytes (the current worst case is 213, the `SYS_EXEC`
   path). If it exceeds that, stop and report the chain per function.
3. **Complete the withheld integration**, now within budget:
   - production wiring: `config/mounts.json` `/` (optional), the
     `recovery/manifest.json` entry, `kernel/main.c` boot load (last,
     optional), `BOOT_ZMODS`;
   - the `m9-iocfat-selftest` image and the FS2 host peer;
   - `tests/test_iocfat*.py` with the package-30 coverage list;
   - the pinned-expectation updates for the new boot order, ROMFS and
     mount manifest;
   - documentation, including the architecture 32.12 `statfs` wording fix.
4. **Cache evidence (accepted deviation).** The module-side counter
   `TEST-ONLY HOOK` stays removed. Prove every cache rule with FS2 command
   counts observed by the host peer: a repeated read sends no `FS2_READ`; a
   cross-block read fetches exactly the expected blocks; after a confirmed
   write (own file or the other open file) or a generation change, the next
   read fetches again. Record this in the validation record.
5. **Budget documentation.** Update architecture 32.39 and the package-30
   record: the end-of-M9 slack target is **at least 1 KiB** (owner decision,
   2026-10-05, with the reason: IOC-FAT measured 15 granules; trimmed to 13
   and the cache kept). Report the final ledger.

## Validation

At the `00-WORKER.md` efficiency defaults, run one formal batch in the
background:

```sh
make clean && make check
make m9-fs-selftest m9-iocfat-selftest
python3 -m unittest tests.test_iocfat tests.test_iocfat_sim tests.test_m9_fs tests.test_syscall_sim -v
git diff --check
```

Report:
- the `iocfat.zmod` image/BSS/granules and the per-function sizes before
  and after;
- the final `bank7:` and `common:` lines (production must show at least 2
  free granules plus data slack, totalling at least 1024 bytes);
- the measured gate-stack depth through IOC-FAT;
- the formal run's wall-clock time;
- every skip in the listed suites, with its reason.

Hardware rows (from package 30):
1. production with a FAT card: `make smoke-hardware` plus the operator's
   V9958 check;
2. production with the card removed: `vfs: / unavailable 0xNN`, and the
   monitor and console still work;
3. `make smoke-hardware-m9-iocfat` with a card: `fstest` passes its IOC-FAT
   section, including the cache cases.

Record `PENDING` for any row not run.

## Acceptance criteria

- `iocfat.zmod` is at most 13 granules with every package-30 behavior,
  including the one-slot write-through cache.
- The production arena ends with at least 2 free granules and at least
  1 KiB of total slack, the gate-stack depth through IOC-FAT is at most 224
  bytes, and the 32-granule floor holds.
- `/` is served by IOC-FAT in production. An absent SD card leaves
  `/SYSTEM` and the console fully usable.
- Cache behavior is proven by FS2 command counts, and the budget change is
  recorded in the architecture.
