# Task

Introduce the kernel VFS core and make it part of the boot foundation. Add a
generated, host-validated mount table and turn ROMFS into a statically linked
filesystem provider mounted at `/SYSTEM` before any module loads. Boot ZMODs
and the monitor ZEX then load through VFS paths instead of ROMFS names. Runtime
behavior and every accepted transcript stay unchanged.

## Context

Dispatch only after packages 21-24 are accepted and committed. Read
`work/00-WORKER.md`, architecture sections 32.1-32.14, 32.32-32.33 and 32.36,
and all of `work/M9-REFERENCE.md`.

Current state: `kernel/main.c` `kernel_boot_module()` calls `romfs_init()`
followed by `romfs_load_zmod()` for sio, ioc, hid and v9958.
`process_exec(romfs_name)` in `kernel/process/exec.c` reads through
`romfs_lookup/romfs_read`. The loader already accepts a bounded
`struct zmod_source` (`module_load_source()`). ROMFS v1 is flat, and its names
are currently case-sensitive. Pre-M5 acceptance images
(`ZOS_ROMFS_BOOT=0`) boot from the embedded catalog and have no ROMFS.

## Requirements

- Add `include/zephyros/fs.h` with the limits, type/attribute/time constants,
  and the `zfs_stat`, `zfs_dirent` and `zfs_statfs` layouts. Use the values
  pinned in M9-REFERENCE. Syscall argument blocks are added later, in
  package 27.
- Add `include/zephyros/vfs.h` with `struct zfs_provider`, `struct zfs_ops`
  (the section 32.12 set; `mkdir/rmdir/unlink/rename` take
  `(fs_state, parent_node, name)` / `(fs_state, from_parent, from_name,
  to_parent, to_name)`), and `struct zfs_open_info {object_id, size, type}`.
  The `open` operation fills `zfs_open_info`. Lookup uses a NUL-terminated
  component. Node handles are opaque. VFS releases looked-up nodes through a
  `release` operation (providers with static nodes may implement it as a
  no-op).
- Add `kernel/vfs/` with these parts:
  - path normalization (absolute/relative, `.`, `..`, repeated `/`,
    traversal above `/` clamped to `/`, ASCII-only case-insensitive compare,
    the length limits);
  - runtime mount state (parallel to the generated `const` config table, which VFS never writes) and longest-match mount resolution that produces the
    FS-relative path;
  - the built-in provider registry (capacity 4);
  - the lifecycle (`BOOTSTRAP`, `MODULES`, `MOUNT`, `READY`);
  - a kernel file API (open/read/stat/close on caller-provided
    `struct vfs_file` storage, read-only in this package);
  - a `zmod_source` adapter over a `vfs_file`.

  Kernel-only declarations go in `kernel/vfs/vfs.h`. VFS contains no ROMFS
  layout knowledge and no Zephyr-80 mount policy.
- Add `fs/romfs/` with a ROMFS provider built on the unchanged
  `kernel/romfs/` reader. Requirements:
  - names match case-insensitively;
  - the provider tree is a single root directory;
  - `object_id` is entry index + 1;
  - attributes are `READONLY`;
  - timestamps are `ZFS_TIME_UNKNOWN`;
  - `statfs` reports the image size and 0 free with `ZFS_STATFS_READONLY`;
  - a lookup below a file returns `ZOS_ENOTDIR`;
  - every mutation returns `ZOS_EROFS`;
  - the `source` must be `recovery`, otherwise mount returns `ZOS_EINVAL`.

  The provider is linked into the kernel image. It is not a ZMOD.
- `tools/romfspack.py` must reject names that collide case-insensitively and
  names containing `/`. Add negative tests for both.
- Add `config/mounts.json` (production: only `/SYSTEM`, romfs, `recovery`,
  `system: true`), `tools/mountgen.py`, `kernel/vfs/mount_config.h`, the
  `ZOS_MOUNTS`/`ZOS_VFS_BUILTIN` Makefile variables, and the generated
  `build/generated/vfs_mounts.c` exactly as specified in "Static mount table:
  from JSON to VFS" in M9-REFERENCE. That section covers the generator
  command line, the extra rejection rules, deterministic output, the
  generated C shape, the config/runtime split, and the boot consumption order.
  Add a negative test for every rejection rule. Acceptance images select
  `tests/m9/mounts-*.json` through `ZOS_MOUNTS`.
- Boot integration (`ZOS_ROMFS_BOOT=1` images):
  1. Run `vfs_init()`, register built-in providers, and mount the unique
     system entry.
  2. Load sio, ioc, hid and v9958 in the unchanged order and with the
     unchanged failure semantics from `/SYSTEM/<name>.zmod`, through
     `module_load_source()` and the VFS adapter.
  3. Run the normal mount pass (a no-op for production).
  4. Enter READY.

  If the system mount fails, print exactly the existing `romfs_diagnose()`
  lines and the `romfs: corrupt recovery image` panic. Remove
  `romfs_load_zmod()`; do not leave it as a parallel loader. Keep the
  embedded-catalog path for `ZOS_ROMFS_BOOT=0` untouched and VFS-free.
- Change `process_exec()` to take a VFS path and read through the kernel file
  API. ZEX validation and bank semantics stay unchanged. The launcher execs
  `/SYSTEM/monitor.zex`. Update every acceptance caller (`tests/target/m6`,
  `m7`, and others).
- Optional mounts and required non-system mounts must already work (attempt,
  tolerate or panic, with the section 32.32.4 rules). Prove this with
  `tests/m9` configurations whose optional mount names an unregistered
  provider. That failure prints `vfs: <path> unavailable 0xNN`.
- Add target and simulator acceptance (`m9-vfs-selftest`, `tests/target/m9/`,
  `tests/test_m9_vfs*.py`) covering:
  - normalization and case-insensitive resolution;
  - `/SYSTEM` lookup, stat and read of every ROMFS entry, byte-compared with
    the packed files;
  - root enumeration with `/` unmounted (only `SYSTEM`);
  - `stat("/")` and `stat("/SYSTEM")`;
  - ENOENT, ENOTDIR and EROFS;
  - ZMOD/ZEX loading through VFS;
  - optional-mount failure.

## Files

- `include/zephyros/{fs,vfs}.h`, `kernel/vfs/`, `fs/romfs/`
- `kernel/main.c`, `kernel/process/exec.c`, `include/zephyros/{process,romfs}.h`
- `config/mounts.json`, `tools/{mountgen,romfspack,mapcheck}.py`, `Makefile`
- `tests/m9/`, `tests/target/m9/`, `tests/test_m9_vfs*.py`, `tests/test_source_layout.py`
- `docs/{boot,romfs-format,memory}.md`, a new `docs/vfs.md`, `docs/architecture.md` implementation notes

## Constraints

- No syscalls, descriptors, file-data cache, writable provider, ABI v3, block
  devices or IOC-FAT. Those belong to later packages.
- VFS is kernel mechanism: no executable code under `platform/` or `config/`.
  `fs/romfs` must not include driver headers.
- Preserve every M1-M8 acceptance transcript, the boot order, and the monitor
  hash. Production ROM bytes change, so hardware evidence must be rerun.

## Validation

```sh
make clean && make check
make romfs-test zex-test monitor-test m5-selftest m5-corrupt-selftest \
     m6-selftest m7-selftest m8-selftest m8-fallback-selftests m9-vfs-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod build/modules/monitor.zex
make clean && git status --short
```

Report the budget numbers required by M9-REFERENCE. Flash the production image
and run `make smoke-hardware-m8 SERIAL_PORT=...`. The transcript must match the
accepted M8 boot. Record `PENDING` with image and hash if hardware is
unavailable.

## Acceptance criteria

- `/SYSTEM` is mounted by VFS before any module loads, and every boot ZMOD and
  the monitor load by VFS path. `romfs_load_zmod()` no longer exists.
- Mount-config validation rejects every section 32.5.1 case.
- M5-M8 acceptance output is unchanged, and the M9 VFS suite passes in the
  simulator.
- The production hardware boot matches M8, or is recorded `PENDING`.
