# Correction

Package 25 links the VFS core (`kernel/vfs/*`), the generated mount table and
the ROMFS provider (`fs/romfs/`) into every image, including the
`ZOS_ROMFS_BOOT=0` embedded-catalog images (M1-M4 acceptance). In those images
the code can never run. The contract said: "Keep the embedded-catalog path for
`ZOS_ROMFS_BOOT=0` untouched and VFS-free."

Impact: about 7.8 KB of dead code in the historical images. It pushes
`m4-selftest` to `_CODE` end 921Bh and `m4-placement-selftest` to 9099h,
against their fixed arenas at A000h and 9E00h. The worker reported this as
legacy fixed-arena pressure. It also means those images no longer match their
accepted pre-M9 bytes for no reason.

## Required changes

- Link `vfs_*`, `vfs_mounts`, `romfs_provider` and any other M9-only objects
  only when `ZOS_ROMFS_BOOT=1`. Use the existing Makefile conditional; do not
  add new guards to C source where an object-list change suffices.
- Any kernel source shared by both paths must not reference VFS symbols when
  `ZOS_ROMFS_BOOT=0`. `process_exec()` keeps its package-25 path signature, but
  in embedded images it must not pull in VFS. Use the narrowest change and
  explain it, for example compiling the VFS-backed exec body only under the
  existing ROMFS-boot conditional, as `kernel_boot_module()` already does.
- Mechanical enforcement: mapcheck (or the image check) must reject any
  `_vfs_`, `_romfs_op_` or `_vfs_mount_table` symbol in an image built with
  `ZOS_ROMFS_BOOT=0`. Add a negative fixture proving the check fires.

## Validation

- Build the committed baseline `3dedd09` and the corrected tree. Compare
  SHA-256 for: `syscall-selftest`, `irq-selftest`, `m3-selftest`,
  `m4-loader-selftest`, `m4-selftest`, `m4-placement-selftest`,
  `m4-failure-selftest`. Byte identity is expected. List and justify any
  difference by symbol and section.
- Report `_CODE` end for each of those images.
- `make clean && make check`, the M5-M8 and M9 VFS suites from the package-25
  validation list, `python3 -m unittest discover -s tests -v`,
  `git diff --check`, then `make clean && git status --short`.

## Acceptance criteria

- No VFS or ROMFS-provider symbol appears in any `ZOS_ROMFS_BOOT=0` image, and
  a regression check enforces it.
- The M1-M4 images match the pre-package-25 baseline bytes, or every
  difference is explained.
- The production and M5-M9 results are unchanged from package 25.
