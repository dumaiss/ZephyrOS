# Correction

Package 25 implemented the original node-based provider design: a 20-operation
`zfs_ops` with lookup/release, `zfs_open_info.object_id`, per-component VFS
traversal, longest-match mount resolution, and `statfs`/`truncate`/
`syncfs`/`unmount`. It also kept the M5 ROMFS name lookup beside a second,
case-folded provider lookup.

The architecture was trimmed on 2026-10-04 (sections 32.8, 32.12, 32.13,
32.33.5, 32.39). Measured cost of the superseded machinery in the production
map:

- `vfs_lookup_rel` 544 bytes;
- `vfs_release_node` 512 bytes;
- `vfs_resolve_node` 115 bytes;
- `vfs_statfs` 284 bytes;
- the duplicate ROMFS lookups `romfs_lookup` 312 and `romfs_lookup_ci` 395
  bytes;

plus provider glue. The production kernel ends at 7EE6h, with about 150 bytes
of headroom against the 32-granule arena floor.

Dispatch only after correction-01 is accepted (it changes the same Makefile
object lists). Read `work/00-WORKER.md`, architecture sections 32.6-32.13,
32.33 and 32.39, and `work/M9-REFERENCE.md` (in particular "No backward
compatibility" and "Pinned kernel decisions"). There is no compatibility
requirement: replace the package-25 interfaces in place.

## Required changes

- **Provider ABI.** Replace `include/zephyros/vfs.h` `struct zfs_ops` with the
  14 path-based operations of architecture 32.12, in that order. `open`
  reports size through `uint32_t *size`. Delete `zfs_open_info`,
  `object_id`, and the lookup, release, unmount, syncfs, truncate and statfs
  operations. Remove `zfs_statfs` and `ZFS_STATFS_READONLY` from
  `include/zephyros/fs.h`. Update the static asserts and host tests.
- **VFS core (`kernel/vfs/`):**
  - Keep path normalization against a base (`/` until package 27 adds CWD).
  - Replace longest-match resolution with flat selection: compare the first
    component with the `MOUNTED` root-level mountpoints, case-insensitively;
    otherwise use `/`. Produce the provider path (the remainder, or `/`).
  - Delete node objects, `vfs_lookup_rel`, `vfs_release_node`,
    `vfs_resolve_node`, `vfs_statfs`, the mount-path component helpers, and
    any per-component walk.
  - The kernel file API (open/read/stat/close, opendir/readdir/closedir, the
    `zmod_source` adapter) calls providers with the provider path.
  - `stat("/")` and `stat` of a mounted mountpoint are answered by VFS as
    directories.
  - Root enumeration with `/` unmounted lists the mounted root-level
    mountpoints.
  - Use one static 128-byte pathname scratch buffer. No dynamic allocation.
- **ROMFS:** exactly one lookup, ASCII case-folded, over the validated
  directory.
  - `kernel/romfs/` keeps the ROM-access primitive, whole-image validation,
    indexed entry access, bounded reads, and the module resource imports, now
    routed through the single lookup with the DATA-only rule unchanged.
  - Delete the case-sensitive `romfs_lookup` and any read/lookup helper the
    provider duplicates. Keep `romfs_diagnose()` and the corrupt-image panic
    behavior.
  - `fs/romfs/` is path-based: `/` is the only directory; `/<name>` is a
    file; a deeper path returns `ZOS_ENOTDIR` when the first component names
    a file, otherwise `ZOS_ENOENT`.
  - Leave the mutation pointers null; VFS turns a null mutation operation
    into `ZOS_EROFS`.
- **Tests** (`tests/test_m9_vfs*.py`, `tests/target/m9/`): rework them for
  the path-based contract and keep every behavioral case from package 25.
  Add these cases:
  - case-insensitive ROMFS hits;
  - `ENOTDIR` below a file;
  - `EROFS` from null mutation operations;
  - flat mount selection, including a name such as `/SYSTEMX` that must not
    match `/SYSTEM`;
  - a static check that `vfs.h` declares exactly the 14 operations.
- **Docs.** Update `docs/vfs.md`. Replace the architecture 32.38.1 stage-25
  note with an accurate description of the reworked implementation, and
  remove the superseded-notice paragraph the supervisor added there.

## Validation

```sh
make clean && make check
make romfs-test zex-test monitor-test m5-selftest m5-corrupt-selftest \
     m6-selftest m7-selftest m8-selftest m8-fallback-selftests m9-vfs-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean && git status --short
```

Report the `_CODE` end, the arena granules, and the per-object `_CODE` sizes
for `vfs_*`, `romfs*` and `romfs_provider` before and after. The expected
saving is in the 2-3 KB range. If the saving is under 1.5 KB, explain where
the bytes went.

Hardware: production bytes change. Flash production and run
`make smoke-hardware-m8 SERIAL_PORT=...`; the monitor must launch from
`/SYSTEM/monitor.zex` with console input/output working. Record `PENDING` if
hardware is unavailable.

## Acceptance criteria

- The provider ABI is the 14-operation path-based interface. No node, lookup,
  release, statfs, truncate, syncfs or unmount code or declaration remains.
- There is one ROMFS lookup, case-insensitive, serving the provider and the
  resource imports.
- Every package-25 behavior is still demonstrated, plus the new cases.
- The measured kernel reduction is reported, and the production boot works
  on hardware or is recorded `PENDING`.
