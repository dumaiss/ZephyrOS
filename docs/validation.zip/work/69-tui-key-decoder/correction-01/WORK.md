# Correction

The key decoder passes its preloaded transcript but does not implement the
standalone-ESC contract. When ESC is the only pending byte, the immediate read
returns zero and the parser remains in ESC state forever. In addition, parser
state is held in file-static storage that is not reset by `tui_init()`, so a
partial sequence can leak across a shutdown/reinitialization boundary.

## Required changes

- After reading ESC, perform the specified immediate pending check. If no
  continuation byte is pending, deliver `TUI_KEY_ESC` immediately and return
  to NORMAL. Use the existing console polling/read surface; do not add a timer,
  sleep, configurable timeout, or OS/driver change.
- Reset all parser, ready-key, sequence, and replay state for every successful
  TUI initialization. Preserve archive pullability: a screen-only program must
  still contain no `tui_key` member or decoder symbols.
- Define and test the nonblocking pre-initialization behavior consistently with
  the shared public-result rules (`tui_key_pending` reports `-KOS_EINVAL` and
  `tui_pollkey` produces `TUI_KEY_NONE`). Do not make `tui_getkey` busy-spin
  before initialization.
- Add a target/simulator case that injects exactly one ESC byte and no following
  byte, on both serial and V9958/HID. The previous implementation must hang or
  fail this regression.
- Add a phased replay that leaves an incomplete sequence, shuts down,
  reinitializes, and proves the next ordinary/known key is decoded from a clean
  NORMAL state.
- Preserve the complete existing vocabulary, malformed-tail replay, split-read
  behavior, NUL handling, and screen-only link-map result.
- Update package 69's validation record, size evidence, and progress file.

Do not begin or modify package 70-73 behavior as part of this correction.

## Validation

```sh
make build/user/tui_test.exe build/user/tui_core_probe.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_console_serial
git diff --check
```

## Acceptance criteria

- A lone ESC returns `TUI_KEY_ESC` without waiting for another byte on both
  console backends.
- No partial key/parser state survives a completed shutdown/reinitialization.
- Polling remains nonblocking, blocking reads still call `idle()` only while
  genuinely empty, and malformed input loses no tail bytes.
- The decoder stays absent from a screen-only link map.
- The physical keyboard/serial gate remains explicitly `PENDING` unless the
  owner supplies actual hardware evidence.

