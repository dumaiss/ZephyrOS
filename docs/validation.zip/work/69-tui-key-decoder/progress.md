# Progress

## Status

DONE — accepted by supervisor on 2026-10-18 after correction 01. The focused
correction gate passed on both simulator backends; physical keyboard and
serial-terminal evidence remains pending for package 73.

## Done

- `user/sdk/tui/src/tui_key.c`: one parser shared by `tui_key_pending`,
  `tui_pollkey` and `tui_getkey`; NORMAL/ESC/CSI/SS3 states; eight-byte
  sequence and replay buffers; one-byte ESC look-ahead; NUL ignore; exact
  controller vocabulary; malformed/overlong replay.
- `tests/tui/tui_test.c`: `keys` mode with 47 symbolic results over the
  serial and V9958/HID routes.
- `tests/test_tui_sim.py`: identical ordered transcript on both lanes.
- `tests/tui/tui_core_probe.c`: screen-only map with no decoder member or
  symbols.
- Report: `docs/validation/2026-10-18-tui-key-decoder.md`.

## Correction 01

- Lone ESC now uses an immediate non-blocking look-ahead and returns
  `TUI_KEY_ESC` without entering a waiting ESC state.
- `tui_init()` advances a shared key generation; the decoder resets all
  private parser/ready/sequence/replay state on the next call without pulling
  the decoder into screen-only programs.
- Pre-init/after-shutdown behavior: `tui_key_pending()` is `-KOS_EINVAL`,
  `tui_pollkey()` is `TUI_KEY_NONE`, `tui_getkey()` returns `TUI_KEY_NONE`
  immediately.
- Added `loneesc` and phased `keyreset` replay modes on both console routes.
- `tui_key.rel` is 11,163 bytes; `tui_core_probe.exe` remains free of the
  decoder member and symbols.
- Report updated: `docs/validation/2026-10-18-tui-key-decoder.md`.

## Pending evidence

- Physical V9958/HID keyboard and serial-terminal key report: PENDING.

## Supervisor review

- The existing 47-key transcript passes on both simulator backends, but its
  final ESC is immediately followed by another byte. It does not exercise the
  required lone-ESC policy.
- With ESC as the only pending byte, `tui_key_decode()` reads it, receives zero
  on immediate look-ahead, leaves the parser in ESC state, and never delivers
  `TUI_KEY_ESC`.
- Parser storage is also outside lifecycle reset, so an incomplete sequence can
  survive shutdown/reinitialization.
- See [`correction-01/WORK.md`](correction-01/WORK.md).

## Final supervisor acceptance

- Built `tui_test.exe`, the screen-only `tui_core_probe.exe`, and the SDK.
- Replayed lone ESC and shutdown/reinitialization parser reset on both serial
  and V9958/HID simulator routes.
- Rechecked the link-map/member isolation and TUI archive invariants.
- Focused result: 14 tests passed; `git diff --check` clean.
- Physical V9958/HID keyboard and serial-terminal replay remains `PENDING` and
  is carried into package 73's acceptance gate.
