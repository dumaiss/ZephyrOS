# Task

Implement the one VT100-to-`tui_key_t` decoder shared by every TUI
application, with blocking, nonblocking, and pending APIs over the existing
console byte stream.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`, especially "Key decoder";
- `docs/konaos-tui-sdk-architecture.md`, sections 5, 9, 12.3, 13 and
  WP-TUI-3;
- `drivers/hid/hid.c` and `docs/devices.md`, section 5, for byte preservation;
- `user/sdk/src/console_proto.c`, `console_io.c`, and `idle.c`;
- packages 66-68 and their accepted validation records.

## Requirements

1. Implement `tui_key_pending`, `tui_pollkey`, and `tui_getkey` in their own
   archive member group. Use only `console_read`, `console_poll`, and `idle`.
   Do not bind the timer or another object.
2. Implement the exact sequence table, standalone-ESC policy, NUL handling,
   bounded state/replay buffers, malformed-sequence recovery, and result rules
   in `work/TUI-REFERENCE.md`. CSI and SS3 are distinct states.
3. All three public functions drive the same parser and byte queue. No path may
   decode a sequence differently, block inside `tui_pollkey`, or consume an
   incomplete/unknown sequence without replaying its tail.
4. Extend the target program with a key-report mode. The simulator injects:
   - every ordinary/control byte class;
   - standalone ESC;
   - arrows, HOME/END, INSERT/DELETE, PGUP/PGDN, and F1-F12;
   - sequences split across console reads;
   - unknown CSI/SS3, truncated, and overlong input followed by a known key.
5. Run the identical byte vectors through the V9958/HID input route and the
   serial route. Assert symbolic results, ordering, no lost replay bytes, and
   recovery to a following ordinary/known key.
6. Prove a screen-only program does not pull the decoder member into its link
   map. Record the decoder's image/BSS contribution.

## Acceptance

- Every current IOC key sequence maps to the exact public constant.
- A lone ESC returns ESC and never waits indefinitely.
- `tui_pollkey` is nonblocking and returns NONE on empty input.
- `tui_getkey` idles between empty polls instead of busy-spinning.
- Malformed input cannot poison the next key or overflow private state.
- The same target binary produces the same decoded stream on both consoles.

## Hardware gate

On the V9958/HID console, run the key-report mode and press every listed key,
including F1-F12 and standalone ESC. On the serial console, send the equivalent
sequences. Record the transcript and any terminal settings. If the owner is not
available, record `PENDING`; do not claim physical acceptance.

## Constraints

- No IOC firmware, HID, console, timer, kernel, or ABI change.
- No modifier-key extension, UTF-8 decoder, terminal capability table, or
  configurable timeout.
- Record `docs/validation/<date>-tui-key-decoder.md`.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk tests.test_sdk_package tests.test_console_serial
git diff --check
```

