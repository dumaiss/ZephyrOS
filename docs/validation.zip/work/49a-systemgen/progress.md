# 49a — systemgen: working state

## Contract notes (supervisor decisions, 2026-10-12)

- The byte-identical requirement is **dropped**.  Acceptance is: `make clean
  && make check` green, the image matrix tests green, production boots to the
  monitor in the simulator replay.
- **Canonical store order**: the driver images in load order, then
  `drivers.man`, then the system file's `store` files.
- **KRFS** (the ROMFS magic `ZRFS` → `KRFS`) lands in the same pass; no
  separate step and no per-image byte comparison.
- `systemgen` does **not** take over packing.  It writes into `$(BUILD)`:
  `system.mk` (`KOS_DRIVERS`, `KOS_BOOT_PROGRAM`, `KOS_SYSTEM_CFLAGS`,
  `KOS_DRIVER_OBJECTS`, `KOS_STORE_FILES`), the ROMFS store manifest
  (`store.json`), the boot manifest (`modules/drivers.man`) and one
  **resolved copy** of each selected driver manifest
  (`drivers/<id>.json`, `depends` turned back into `{class, instance}` rows).
  `modpack.py` keeps the endpoint numbers, the tier plan, the in-container
  publication table and the plan report; its `drivers` command becomes
  `plan`, which no longer writes the boot manifest.
- Driver ids: a bare id resolves under `drivers/` (`drivers/<id>/<id>.json`
  or the single `drivers/*/<id>.json`); a test-only driver is named by its
  repo-relative path without `.json`; the id is the basename; ids are unique
  per system; a manifest's `name` must equal its id.
- Symbolic `depends`: `"INPUT"`, `"VIDEO:1"`, `"#16"` (raw class, decimal),
  trailing `?` for optional.  Resolution is by endpoint class against the
  selected set; none or more than one match is an error naming the system,
  the driver and the entry.
- The IPC acceptance drivers are boot drivers (in `drivers`), their images
  are `<id>.mod` in the image's own module directory (the `ipc-` prefix and
  the `ipc-modules/` subdirectory go), and their objects carry an `ipc_`
  prefix so they cannot collide with a production driver's objects.
- `tests/ns/manifests/{sio,console-serial}.json` are deleted (copies of the
  `drivers/` ones).
- The system file's flag field is `cflags` (raw flags, e.g.
  `-Itests/target/include`); a `.exe` path in it is refused.
- The FS publication type name is spelled `FS` again.
- The one setting that does not fit a system file: the required-console
  failure store omits one selected driver's image.  It stays in the image
  target as `SYSTEM_OMIT.console-serial-missing := --omit-image
  console-serial` and is listed under "Unmapped" in the record.

## Baseline (before any edit)

- `make clean && make check` green (wall clock 41.9 s for the first build; the
  full check and the image matrix are captured in
  `files/baseline.log` in the session workspace, hashes included).
- Matrix, in order: subsystem, console-integration, console-serial, fs, ipc,
  xmem, ns, nucleus, helloworld — all green.

## Decisions taken while implementing

- `systemgen` resolves `depends` by **endpoint class** (the protocol type
  numbers of `abi/kos/protocol.h`, shared with `modpack.TYPES`), which is
  what `"#16"` implies for the acceptance drivers whose classes carry no
  protocol name.  A `?`-marked dependency that no selected endpoint provides
  keeps its row with `optional: 1`, so the driver's dependency array keeps
  its positions and the packer resolves the number to 0.
- The resolved copies are written **before** anything is packed, and
  `--objdir $(MODULES)` resolves their `objects` names unchanged: every
  driver image of an image builds into that one directory.
- `KOS_DRIVER_OBJECTS` comes from the system file, so an image builds only
  the objects its selected drivers need (the ipc image therefore never
  builds the production `ioc.rel`).
- The image-name suffix, the acceptance test objects and the mapcheck cold
  override stay build-side wiring in the Makefile, keyed on the system name
  (`SYSTEM_*` tables, no per-image `ifeq`).
- `KOS_SMOKE_HOST_SYNC=1` moved from the image targets into the four
  diagnostic system files' `cflags` (it is a `-D` the kernel compiles in).
- The subsystem/nucleus store's cross-page asset is now built as
  `$(MODULES)/crosspage.bin`, so every store entry's name equals its file
  name (the generator knows one name per store file).
- `tests/ns/manifests/sio.json` and `console-serial.json`'s `depends` was
  equal to `drivers/sio/sio.json` (modulo key order), so deleting them keeps
  the packed containers identical, apart from the new schema field.

## Applied (final state)

- new: `tools/systemgen.py`, `systems/*.json` (12), `tests/test_systemgen.py`;
- patched: the Makefile (system selection, the wiring table, the per-driver
  pack rules, the store rule, the image targets), the driver manifests
  (`schema` + symbolic `depends`, the IPC object names, the `FS`
  publication type), `tools/modpack.py` (`plan`), `tools/romfspack.py` and
  `formats/include/romfs.h` and `kernel/main.c` (KRFS), the docs and the
  affected tests;
- deleted: `config/system.mk`, `tools/bootprogram.py`, the eleven
  hand-written store manifests, `tests/ns/manifests/{sio,console-serial}.json`;
- verified: the whole suite passes in a copied tree before the repo was
  touched, and the final acceptance run on the repo is green -
  `make clean && make check` exit 0 (649 tests, 104 skips, reproducible
  rebuild compared) and the full image matrix exit 0 (subsystem,
  console-integration, console-serial, fs, ipc, xmem, ns, nucleus,
  helloworld); `git diff --check` clean; the record is
  `docs/validation/2026-10-12-systemgen.md`.
- two Makefile wiring bugs were found by the matrix (not by the unit
  tests) and fixed: `PK_SUFFIX` and `SYSTEM_GEN_FLAGS` are immediate
  assignments and must follow the `SYSTEM_*` table rows they read.  The
  first is now named by a layout test; the second was the reason the
  fail image packed the same store as the serial image.
- no commit was made (the package's instruction).

## Known follow-ups

- `TEST_FIXED_OBJS` (referenced, never defined) and the namespace image's
  `KOS_VFS_WS_GUARD` Make variable (set, never read) are pre-existing dead
  Make variables; both are preserved as they were and reported.
