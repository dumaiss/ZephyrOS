# Correction

Package 28 is accepted. Three small issues remain, all about how its memory
is placed and accounted for.

1. **Path buffer in common memory.** `_zos_process_path_scratch` (128 bytes,
   `kernel/process/launch.asm`) holds the `SYS_EXEC` path across
   `process_prepare()`. The reason it is separate from the VFS workspace is
   sound: the workspace is in use while loading. But architecture section 7
   reserves `E000h-FFFFh` for code and state that must stay reachable across
   mode changes, and this buffer is only used in mode 11. The continuation
   records, gate-state shadows and frame-save areas *do* belong in common
   (the resume gate restores them while changing mode), so they stay.
2. **False claim.** The validation record, `docs/abi.md` (line ~440) and
   `docs/memory.md` (line ~344) say common-memory state is placed "where a
   mode-10 child cannot reach" it. Common memory is mapped in mode 10;
   every application can read and write it. That is how Zephyr-80 works
   (there is no protection), and it is not a reason to place anything there.
3. **Common memory is off the ledger.** Package 28 moved +688 bytes into
   common memory (`_COMMON` 1041 -> 1410, `_COMMON_DATA` 503 -> 822) while
   the `bank7:` line reported "+0 data". Common memory is the scarcest
   region, and growth there must be as visible as bank-7 growth.

Read `work/00-WORKER.md` (including "Working efficiently"), architecture
sections 7 and 32.39, `kernel/process/launch.asm`, `kernel/syscall.c`,
`tools/{pack_image,zmodpack,mapcheck}.py`. There is no backward-compatibility
requirement.

## Required changes

- Move the `SYS_EXEC` path buffer to bank-7 runtime data (`_DATA`), owned by
  `kernel/process/`, keeping its lifetime rule (stable across
  `process_prepare()`). Measured bank-7 data slack is 191 bytes, so 128 bytes
  must not cost a granule; confirm with the ledger. If the copy-in path from
  the caller bank currently relies on the buffer being in common, route it
  through the existing checked bank-copy gate instead. Keep exec behavior
  unchanged.
- Correct the three "cannot reach" statements. State the real reason each
  remaining common item lives there (it is restored by the resume gate across
  the mode change).
- Extend the ledger. Add `common <used> of <capacity> bytes (code <n>, data
  <n>)` to the `bank7:` line (or a second `common:` line printed beside it),
  in `arena.plan.json` and in `docs/memory.md`. Capacity is
  `ZOS_COMMON_CODE_END - ZOS_COMMON_BASE`. Add a host test that checks the
  line against the map.
- Gate-stack canary (cheap insurance before IOC-FAT deepens the syscall
  path). In acceptance and simulator builds only, fill the gate stack with a
  pattern at boot and let the existing simulator gate-depth measurement
  assert against it. Production stays unchanged. Skip this if the existing
  measurement already observes the true high-water mark; say which.

## Validation

At the `00-SUPERVISOR.md` "Validation depth" and `00-WORKER.md` efficiency
defaults, the worker runs one batch:

```sh
make clean && make check
make m9-exec-selftest
python3 -m unittest tests.test_m9_exec tests.test_m9_exec_sim tests.test_pack_image -v
git diff --check
```

Report the before/after `bank7:` and new `common` figures, and confirm
`_zos_process_path_scratch` (or its renamed successor) is in `_DATA`.

Hardware: production only (`make smoke-hardware` with the banner-only
contract, plus the operator's V9958 check), because common-memory placement
changes.

## Acceptance criteria

- The exec path buffer lives in bank-7 data without costing an arena
  granule. Only transition-critical state remains in common memory.
- No document claims common memory is unreachable from mode 10.
- Common-memory usage is printed and test-checked alongside the `bank7:`
  ledger.
- Exec acceptance and the production boot are unchanged.
