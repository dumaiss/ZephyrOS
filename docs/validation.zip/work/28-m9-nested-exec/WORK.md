# Task

Make the existing process subsystem able to say: "this ordinary process has a
suspended ordinary parent; when it exits, clean it up normally and resume that
parent." Add `SYS_EXEC` as a thin composition of the machinery that already
exists (process slots, banks, the single ZEX loader, page zero, VFS process
hooks, exit cleanup), plus the one genuinely new piece: a continuation stack
for the shared gate stack. This is not a second process manager. It provides
the parent/child semantics section 33 requires and the process model the M10
shell needs.

## Context

Dispatch only after package 27 and its correction-01 are accepted. Read
`work/00-WORKER.md`, architecture sections 26.1-26.9, 32.21-32.22 and 32.39,
`docs/zex-format.md`, `docs/abi.md`, `kernel/process/{launch.asm,process.c,exec.c}`,
`kernel/syscall/entry.asm`, and `work/M9-REFERENCE.md`. There is no
backward-compatibility requirement.

What already exists:
- `struct process` (`include/zephyros/process.h`) has `state`
  (`FREE`/`RUNNING`/`SUSPENDED`), `pid`, `bank`, `parent` (a pid or
  `PROCESS_KERNEL_PARENT`), `flags` and `exit_status`.
- `process_exec(path, &status)` performs slot allocation, CWD start, bank
  allocation, the VFS-backed ZEX load and validation, page zero, rollback,
  and `process_launch_child()`, all in one call.
- `zos_process_launch`/`zos_process_resume` save exactly one launcher context
  (`zos_proc_saved_sp/latch/iff`) and are "deliberately single-depth".
- The kernel launcher runs on the common boot stack. Every syscall, including
  a parent's in-flight `SYS_EXEC`, runs on the single 256-byte common gate
  stack that the child's own syscalls reuse. That shared gate stack is the
  only parent state the process table cannot already preserve.

## Budget (decisive)

Measure from the accepted post-27-correction ledger. The production arena
must stay at or above 32 granules after this package, counting both new code
(arena start moves up) and new data (data base moves down). With the
package-27 figures before its correction (35 granules, 279 bytes of data
slack, kernel end 12 bytes below a granule boundary), package 28 could spend
at most three granules. Rules of thumb:

- data growth within the current data slack: about 1.5 KB of code available;
- data growth that crosses one granule: about 1 KB of code available.

**Target: package 28 adds at most about 1 KB of kernel code and at most the
existing data slack.** If the implementation needs more, stop and report
where the bytes went, attributed per function. Do not lower the nesting
limit, trim other features, or touch the floor to make it fit.

Expected resident additions, and essentially nothing else:

```text
SYS_EXEC glue and validation (reusing the package-27 path copy-in)
parent linkage and SUSPENDED/RUNNING transitions on existing struct process
depth check
continuation array: saved SP, latch, IFF per depth
3 x ZOS_EXEC_FRAME_SAVE gate-frame save areas
assembly save/resume primitive (generalized launch/resume)
exit path: "resume parent" instead of "return to kernel launcher"
```

## Design decisions (do not redesign)

- **One process mechanism.** `SYS_EXEC` uses the existing process slot, bank,
  loader, page-zero, VFS-hook and exit machinery all the way through.
  - Do not add structures such as `exec_children[]`, an exec bank map, exec
    file tables, or `exec_*` copies of allocation, loading, page-zero or
    cleanup code.
  - The only process-table information used for nesting is the existing
    `parent` field. Add a field only if a value genuinely cannot be derived,
    and justify it.
  - There are no copies of parent bank, CWD, descriptors, page zero or
    memory: they stay where they already are. The parent's pool entries stay
    owner-tagged to the parent; `vfs_process_exit(child)` closes only the
    child's.
- **Exact `SYS_EXEC` order.** This order resolves "frame too large fails
  before anything is allocated" together with "launch cannot fail":

  ```text
  SYS_EXEC
     +-- validate and copy the path
     +-- check nesting depth                  (no allocation yet)
     +-- preflight continuation size          (no allocation yet)
     |      len = zos_process_continuation_size();
     |      if (len > ZOS_EXEC_FRAME_SAVE) return ZOS_EBUSY;
     +-- process_prepare()                    (allocates; own rollback)
     |      slot, bank, CWD, ZEX load/validate, page zero, close executable
     +-- process_launch()                     (infallible from here on)
  ```

  `zos_process_continuation_size()` is a tiny common helper returning
  `zos_gate_stack_top - SP` as seen by its caller. It is called from the
  **same final `SYS_EXEC` frame** both for the preflight and immediately
  before launch, so the stack has the same shape at both points.
  `process_prepare()` must return completely, leaving that frame exactly as
  it was. In debug and simulator builds, assert that the length measured at
  launch equals the preflight value, and add a test that fails if they ever
  differ. `process_launch()` performs no check that can fail: nothing it
  does may return an error.
- **Prepare, then launch.** Split today's `process_exec()` into:
  - `process_prepare(path, parent_pid, &child)`: every allocating and
    fallible step (path resolution, slot, bank, `vfs_process_start`
    inheriting the parent's CWD, the VFS-backed ZEX load and validation, page
    zero), using the existing rollback, with the executable source **closed
    before returning**;
  - `process_launch(child)`: the continuation transition only. It is
    infallible because depth and frame size were preflighted and
    `process_prepare()` succeeded.

  The kernel launcher (monitor) and `SYS_EXEC` both call these two functions.
  There is one loader path and one rollback path, never
  `process_exec_kernel`/`process_exec_user` variants.
- **All failures happen before suspension.** `ENOENT`, `EISDIR`, `EINVAL`,
  `ENOSPC`, provider errors, the depth limit and the frame-size check all
  return from `SYS_EXEC` while the parent is still a normal running process;
  the depth and frame-size checks run before `process_prepare()` allocates
  anything.
  Past the suspension point nothing can fail. No transactional rollback of
  suspended processes is needed or allowed.
- **Shallow suspension point.** `process_prepare()` fully returns (its
  loader, VFS and provider frames unwind) before `process_launch()` runs. The
  saved gate frame is therefore only the syscall entry, the `SYS_EXEC`
  handler and the launch call, never `sys_exec -> process_exec -> zex_load ->
  vfs_open -> provider`.
- **Nothing borrowed survives the child.** At the suspension point the parent
  holds no pointer into the shared VFS workspace (27 correction-01), no loader
  state, no open executable source, no provider handle and no other temporary
  kernel buffer; the child may reuse all of them. Restoring the parent's
  stack bytes restores only the parent's own continuation. Assert this in a
  code comment at the launch site, and in the simulator by poisoning the
  workspace while the child runs.
- **Continuation stack.** Generalize `zos_process_launch`/`zos_process_resume`
  from one saved launcher context to a small array indexed by nesting depth
  (`saved_sp`, `saved_latch`, `saved_iff`), plus one `ZOS_EXEC_FRAME_SAVE`
  area per suspended *user* parent.
  - Depth 0, the kernel launcher on the boot stack, needs no frame copy.
  - Launch copies `[saved_sp, zos_gate_stack_top)` into that depth's area.
  - Resume order. Once `LDIR` begins, the child's gate-stack frame is being
    overwritten, so everything needed to finish the return must already be
    in common continuation state or in registers, never on that stack:
    saved SP, saved latch, saved IFF, frame source and length, **and the
    child's exit status** that becomes the parent's `SYS_EXEC` result.

    ```text
    DI
    load SP/latch/IFF/frame src+len/exit status from common state
    LDIR saved frame -> gate stack      no CALL, no PUSH, no POP, no IRQ
    restore latch
    restore SP
    place exit status as the SYS_EXEC result (carry clear, HL = status)
    if saved IFF was set: EI         (EI delay: RET runs before any IRQ)
    RET
    ```

    Add a comment proving that no stack access happens from the start of
    the copy until SP is restored. A simulator test checks that the parent
    receives the child's exact status (including `ZOS_EFAULT`) at every
    depth.
  - It is the same launch/return mechanism for every caller. `process_launch`
    does not care whether it is waiting for the kernel, a shell or a
    compiler.
- **Frame-save sizing from measurement.** Measure, in the simulator, the
  worst-case gate-stack depth at the shallow suspension point. Set
  `ZOS_EXEC_FRAME_SAVE` to that plus a 25% margin, rounded up to 16 bytes,
  with the measurement recorded beside the constant. Measure at the same
  frame the preflight and the launch use. Reference points: 80
  bytes keeps three saves (240 bytes) inside the current data slack; 96 bytes
  probably costs a granule. Do not contort the code to hit a number; measure
  honestly and report it. The oversize check is the allocation-free
  preflight above, never a check inside `process_launch()`.
- **Depth.** `ZOS_EXEC_MAX_DEPTH = 4` user processes in one chain. Pin this
  exact example in a comment beside the constant, because "depth 4" is easy
  to read off by one:

  ```text
  kernel launcher (boot stack)
    +- shell       depth 1: kernel continuation, no saved gate frame
       +- IDE      depth 2: frame save #0 holds the shell's SYS_EXEC frame
          +- compiler  depth 3: frame save #1 holds the IDE's
             +- linker  depth 4: frame save #2 holds the compiler's
                linker calls SYS_EXEC -> ZOS_EBUSY (before any allocation)
  ```

  So there are exactly three frame-save areas (`ZOS_EXEC_MAX_DEPTH - 1`),
  because the outermost process is launched by the kernel from the boot
  stack. The nesting limit is not a budget lever.

## Requirements

- `SYS_EXEC 05h {path:u16, length:u16}`: path rules identical to `FS_*`,
  resolved against the caller's CWD, through the existing package-27 copy-in.
  - Success: carry clear, HL = the child's u16 exit status (including a
    synthesized `ZOS_EFAULT` from a raw-return child).
  - Failure: carry set and a `ZOS_E*` code in A, with nothing allocated.

  Error mapping (pin it in `docs/abi.md`):

  | Condition | Error |
  |---|---|
  | missing file | `ENOENT` |
  | directory | `EISDIR` |
  | malformed or oversize ZEX | `EINVAL` |
  | no free slot or bank | `ENOSPC` |
  | depth limit or frame too large | `EBUSY` |
  | provider read error | passed through unchanged |
- Exit path: existing cleanup (`vfs_process_exit`, bank and slot release),
  then, if `parent == PROCESS_KERNEL_PARENT`, the existing return to the
  launcher; otherwise mark the parent `RUNNING` and resume it with the status
  as the `SYS_EXEC` result. `PROCESS_FLAG_KERNEL_PARENT` and `SYS_GETINFO`
  report the true parent.
- Add `zos_exec()` to `user/runtime/`. The monitor and the kernel launcher
  keep working at depth 1 through the same prepare/launch path.
- Tests (test-only code, not resident in production): extend `fstest.zex` and
  add children under `tests/target/m9/` (for example `fschild.zex`,
  `fsdeep.zex`), packed into the M9 acceptance `/SYSTEM` only. Cover:
  - inherited CWD (from `/SYSTEM` and from a ramfs subdirectory), and a
    child's `chdir` that does not affect the parent;
  - a child exiting with descriptors open, whose entries are freed (ramfs
    open-handle counter, and the parent can reopen); the parent's own open
    file keeps its offset and data;
  - the exit-status round trip, including raw-return `ZOS_EFAULT`;
  - the depth probe stopping at exactly 4 with `ZOS_EBUSY`;
  - every exec failure mode returning while the parent is unaffected;
  - 32 exec/exit cycles returning the process table, bank map, pool
    occupancy and ramfs handle count to baseline.

  Simulator checks:
  - gate-stack bytes identical before `SYS_EXEC` and after resume at every
    depth;
  - IFF and latch restored;
  - the workspace-poisoning check above;
  - the measured frame depth, against `ZOS_EXEC_FRAME_SAVE`.
- Production-map check (mapcheck or a host test): none of the test
  instrumentation symbols (probes, counters, poison helpers, test children)
  appear in the production image.

## Tooling (also in this package)

Three small tooling fixes ride along. None of them touches kernel or module
bytes.

- **Production smoke contract** (`tools/serial_smoke.py --mode normal`,
  `tests/test_monitor.py::TestProductionSmokeMode`). On real hardware the
  production console binds to the V9958, so the serial port only ever
  carries the 65-byte early banner. The current mode demands console and
  monitor lines on serial and can never pass. Change the serial contract to
  what serial can observe:
  - **PASS** when the four banner lines arrive in order and then, within a
    quiet window (default 5 s after the banner), no `PANIC`, no `console:
    unbound`, no `console: dynamic driver failed` and no `<module>:
    unavailable` line appears.
  - **SIO-fallback bench:** if the console and monitor lines do appear on
    serial, validate them as today (the stronger check).
  - On a banner-only PASS, print an explicit operator step: "confirm on the
    V9958: monitor banner, status line and `Z80>` prompt; type a key".
  - Update `test_banner_alone_is_not_enough` and the related expectations to
    the new contract, and add negative tests (`PANIC` after the banner, a
    module `unavailable` line, a missing banner line).

  This replaces the photo-only convention that packages 26-27 used to work
  around the old mode.
- **`zex-test` prerequisite.** `$(MODULES)/zex-fixtures.stamp` runs
  `tests/subsys/gen_zmod_fixtures.py`, which needs the loader fixtures
  (`m4_probe`, `m4_fail`, `m4_filler` `.zmod`), but the rule does not declare
  them. Declare the real prerequisites so `make clean && make zex-test` works
  on its own.
- **Parallel builds by default.** A clean production build takes 92 s serial
  and 22-27 s with `-j` on the 20-core build host, with identical bytes.
  Make parallel the default (`ZOS_JOBS ?= $(shell nproc)` and `MAKEFLAGS +=
  -j$(ZOS_JOBS)`, overridable with `ZOS_JOBS=1`), making sure recursive
  image targets inherit it. Prove it is race-free: production and every
  image this package builds must hash identically under `ZOS_JOBS=1` and the
  default, and `make check` reproducibility must still pass. Fix any race by
  declaring the missing dependency, never by serializing a target with
  `.NOTPARALLEL`, unless you report why.

## Working efficiently (build time is not idle time)

Builds and suites are slow (about 22 s per image with `-j`, 48 s for the
host suite), so organize the work so you are not waiting on them:

- **Iterate incrementally.** During implementation use plain `make`
  (incremental, parallel) and the one or two test modules for what you just
  changed (for example `python3 -m unittest tests.test_m9_exec_sim`). Never
  `make clean` while iterating. Rebuild an acceptance image only when the
  change affects it.
- **Run long commands in the background** and keep working: write the next
  test, the docs or the validation record while a build or suite runs. Do
  not poll in short sleep loops. Check once when you expect it to finish.
- **Run the formal validation exactly once, at the end**, from a clean tree,
  in one background batch:
  `make clean && make check && make m9-fs-selftest m9-exec-selftest subsystem-selftest && python3 -m unittest <listed modules>`.
  Draft the validation record while it runs, then fill in counts and hashes.
- **Do not rebuild for documentation-only edits** made after the formal
  run. Rerun only a test that reads the edited file (for example
  `tests.test_docs_evidence`).
- **Hardware images:** build only production and `m9-exec-selftest`, and
  only after the formal run (reuse those artifacts; never `make
  hardware-images`).
- Report wall-clock time for the formal validation run in the record. The
  target is under 10 minutes.

## Files

- `kernel/process/{launch.asm,process.c,exec.c}`, `include/zephyros/process.h`
- `kernel/syscall.c`, `kernel/syscall/fs.c` (path copy-in reuse), `include/zephyros/syscall.h`
- `user/runtime/`, `tests/target/m9/`, `tests/test_m9_exec*.py`, `tools/mapcheck.py`, `Makefile`
- `tools/serial_smoke.py`, `tests/test_monitor.py`, `tests/subsys/gen_zmod_fixtures.py` (tooling)
- `docs/{abi,zex-format,memory}.md`, architecture M6/M9 implementation notes

## Constraints

Explicitly excluded:
- asynchronous spawn/wait, schedulers, background children, signals,
  process groups, jobs;
- descriptor inheritance or redirection, environment, PATH lookup,
  executable search rules;
- argument passing (it arrives later as a startup block in the child's
  bank, not as resident exec state);
- dynamic nesting limits;
- a new ZEX format or a second loader;
- an exec-specific descriptor table or file handle;
- full 256-byte gate-stack copies "just to be safe".

All transition code stays common-resident, and mapcheck proves its placement.

## Validation

At the `00-SUPERVISOR.md` "Validation depth" defaults, the worker runs and
records:

```sh
make clean && make check
make m9-fs-selftest m9-exec-selftest subsystem-selftest
python3 -m unittest tests.test_m9_exec tests.test_m9_exec_sim tests.test_syscall_sim tests.test_subsys_sim tests.test_monitor -v
make clean && make zex-test          # prerequisite fix, on a clean tree
git diff --check
```

Report:
- the `bank7:` ledger before and after;
- the resident bytes added, attributed to the expected-additions list above;
- the measured frame depth and `ZOS_EXEC_FRAME_SAVE`;
- every skip in the listed suites, with its reason;
- the serial-vs-parallel hash comparison;
- wall-clock time of the formal validation run.

Hardware: flash production `build/zephyros.bin` and run `make smoke-hardware`.
With the tooling fix it must report PASS on the banner-only contract; the
operator then confirms the prompt and a keypress on the V9958. Then flash the M9
exec image and run `make smoke-hardware-m9-exec SERIAL_PORT=...`; this is the
authoritative check of the stackless resume under real interrupts. Record
`PENDING` if hardware is unavailable.

## Acceptance criteria

- `SYS_EXEC` is a thin composition of the existing process machinery: one
  loader path, one rollback path, no parallel exec structures. Every failure
  occurs before suspension.
- Nesting works to depth 4 and is refused at depth 5. Every parent resumes
  with exact gate-stack bytes, IFF, latch, CWD and descriptors, and nothing
  borrowed survives the child.
- The section 33 process-lifecycle cases pass in the simulator, and on
  hardware or are recorded `PENDING`.
- The production arena stays at or above 32 granules with the bytes
  attributed. A larger cost is a stop-and-report finding, not a reason to cut
  semantics.
- Depth and frame-size refusals allocate nothing, `process_launch()` cannot
  fail, and a test proves the preflight and launch continuation lengths are
  identical.
