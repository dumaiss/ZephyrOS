# 101-snd-ztr-load progress

## Status
- Implementing 101 first (user-approved), then 102 on top.
- Tree was clean at start except untracked `tests/sndprof.py` (pre-existing, preserve).
- Baseline: HEAD 166e827 (added missing songs to SNTracker).

## Plan
1. Read snd-sdk.md 4.2/5/6/7.2, ZTR-Format.md, ztr.c fully.
2. Extend 97's oracle (tests/snd/oracle/ztr_trace.c) with a decode_row dump.
3. Implement snd_ztr.c (open/validate/resident/prepare/service/status/close) in
   user/sdk/snd/src/, with SND_ZTR_* in snd_private.h and API in kos/snd.h.
4. Add sndtest ztrload and tests; record RAM sizes; docs snd-sdk.md 6.2.
5. Validate, record docs/validation/<date>-snd-ztr-load.md, then start 102.

## Notes
- 102's TECHNIQUES.md "For 101": prepared row records fixed-size, decoded,
  per-channel event mask byte 0 = no event; consumer skips idle channels on
  one test and never parses.
- Budgets: report snd_ztr_open T-states, snd_service one call, RAM; OS bytes 0.
