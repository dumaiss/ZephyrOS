> Worker package. After 100c04. `docs/snd-sdk.md` sections 4.2, 5, 6 (SND-3
> and SND-4, the C side): ZTR open and strict validation, the resident
> tables, and the foreground producer of the prepared-event queue that
> 102's assembly engine consumes. No engine yet, no OS change.
> **Done** (record `docs/validation/2026-10-26-snd-ztr-load.md`); the
> deferred tests moved to 102.

# Task

`snd_ztr_open`, `snd_ztr_prepare`, `snd_ztr_close`, `snd_ztr_get_status`
and the ZTR part of `snd_service`:

- **Open:** validate the whole song through the reader, before any
  hardware change.
- **Keep resident** what the tick needs: the header, the divisor table,
  the order list, the instruments and their macro data.
- **Decode patterns** in the foreground into a bounded queue of
  fixed-size row events, published atomically, ahead of playback.

## Requirements (summary)

1. Validate (C): every check of section 5.3 and `docs/ZTR-Format.md`,
   32-bit offset+length arithmetic, pattern streams read in bounded
   windows; a failure changes no state; outcomes match 97's table.
2. Resident data with compile-time capacities (`SND_ZTR_*`),
   `-KOS_ENOSPC` beyond them; the reserved channel mask.
3. The prepared-event queue: fixed-size row records, the producer in
   `snd_service` (`decode_row`'s semantics), byte tail/head
   publication, `snd_ztr_prepare`'s start window.
4. Status and close (close forgets the source, closes nothing).
5. Docs: `docs/snd-sdk.md` 6.2.
