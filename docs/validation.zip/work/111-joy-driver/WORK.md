> Worker package. After 109. A new resident `joy` driver publishes
> `/dev/input/joy/0` and `/1`, reading the board's controller latches
> through the Z80 I/O ports. Not the HID driver, no IOC command, no
> firmware change. OS change: full validation. Baseline: HEAD plus the
> accepted 109 work (committed or in the tree: preserve it; do not edit
> `UserSoftware/`).

# Task

The IO controller decodes each USB pad (Logitech F310, DirectInput mode)
into a ColecoVision controller byte. It drives two cascaded 74AHC595
latches with those bytes, and the Z80 reads them with `IN` in the
`E0h-FFh` block (writes there go to the sound card). KonaOS gets a
driver and an SDK client that deliver those bytes **exactly as the
controller sets them**: the ColecoVision values, active low.

## Current state

- Latch byte (Zephyr-80 `Code/MCU/IOController`:
  `src/controller_latch.c`, `include/controller_latch.h`, `README.md`
  "Controller Latch Bring-Up"):
  - active low: D0 up, D1 right, D2 down, D3 left, D6 fire (A or B);
    D7 low;
  - idle `7Fh`; an unplugged pad also reads `7Fh` (no presence bit);
  - X/Y/Back/Start put keypad codes `0Dh`/`07h`/`09h`/`06h` in D3:D0,
    replacing the directions while held; a USB keyboard's digits drive
    pad 0's keypad nibble.
- Ports: ColecoVision decode, `FCh` controller 1 and `FFh` controller 2
  (A1 selects; ColecoGo leaves cartridges' `IN A,(n)` in `E0h-FFh`
  unchanged and the cartridge BIOS reads them; MAME does not model the
  latches). Treat this as the board fact. The owner
  checklist confirms which pad is which.
- Sound owns `E0h-E4h` **writes** (`drivers/sound/`); reads in the block
  are the latches.
- Pattern for a small resident driver with ports and an INFO:
  `drivers/sound/` (manifest, `KSOUND_OP_INFO`, direct I/O for programs)
  and `drivers/timer/`.
- Types and classes:
  - `abi/kos/object.h` `KOS_TYPE_*` (MOUSE 11 last);
  - `abi/kos/protocol.h` `KOS_CLASS_*`;
  - `tools/modpack.py` `TYPES`;
  - `kernel/vfs/dev.c` type range check.
- A driver dispatch receives the frame only; the publication's object
  reaches it only in `KOS_OP_RELEASE`.
- Capacities:
  - publications: 10 of 16 (`kernel/vfs/vfs.h`);
  - endpoints: 10 of 12 (`kernel/ipc/ipc.c`).
- Driver hot tier: reserve 832 in architecture 9, `test_pack_image`,
  `test_sound`, `test_iocfat`.
- Simulator: `tests/z80sim.py` (`SoundPeer` takes the `E0h-E4h` writes;
  reads there have no model).
- Patterns:
  - `tests/mouse/mouse.c` and `tests/test_mouse.py` (outcome program
    `/system/mouse.exe`, `STAGE=1`);
  - `user/sdk/src/mouse.c`.

Read: `work/00-WORKER.md`; architecture 4.10, 5.3-5.6, 6.3, 9, 14;
`docs/devices.md` (sound and HID); `docs/sdk.md` (mouse and sound).

## Requirements

1. **ABI** (Must):
   - `KOS_TYPE_JOY 12u`, `KOS_CLASS_JOY 12u`;
   - `modpack.TYPES["JOY"] = 12`; `dev.c` accepts up to `KOS_TYPE_JOY`;
   - `abi/kos/protocol.h` documents the protocol:
     - `KJOY_OP_READ (0)`: `arg0` = pad (0 or 1, else `-KOS_EINVAL`);
       returns 0, with the raw latch byte in payload 0;
     - `KJOY_OP_INFO (1)`: the pad count and each pad's port (listed one
       by one, as the sound INFO lists PSG ports).
2. **Driver** (Must): `drivers/joy/`, the whole driver hot:
   - one endpoint (class 12, instance 0); publications `/dev/input/joy/0`
     (object 0) and `/dev/input/joy/1` (object 1), type `JOY`, both on
     that endpoint;
   - READ is one `IN` from the pad's port;
   - it owns those two read ports and nothing else, and does no decoding;
   - in every system file that has the sound driver or the production
     console.
3. **SDK** (Must): `user/sdk/include/kos/joy.h`, `user/sdk/src/joy.c`
   (libkos and the standalone SDK):
   - `int joy_open(uint8_t pad)` binds `/dev/input/joy/<pad>`, checks the
     type, and asks INFO once for the port;
   - `uint8_t joy_read(int joy)` is a direct `IN` from that port, in
     assembly, with no call per read (speed first: a game reads every
     frame);
   - `int joy_read_call(int joy, uint8_t *raw)` goes through
     `KJOY_OP_READ`;
   - `joy_close`;
   - the header defines the ColecoVision masks (`JOY_UP` `01h`,
     `JOY_RIGHT` `02h`, `JOY_DOWN` `04h`, `JOY_LEFT` `08h`, `JOY_FIRE`
     `40h`, all active low; `JOY_IDLE` `7Fh`) and the keypad codes the
     controller uses (`0Dh`, `07h`, `09h`, `06h`, and the USB keyboard's
     0-9 table from `README.md` "USB keyboard keypad");
   - it states that a keypad code replaces the directions while held, and
     that an idle pad and an absent pad both read `7Fh`;
   - **two readings of the same byte**, because the board ignores the
     ColecoVision mode select (`OUT 80h` keypad, `OUT C0h` joystick) and
     the controller merges both into D3:D0. The program chooses, as a
     ColecoVision game does:
     - `uint8_t joy_dirs(uint8_t raw)` (joystick reading: active-high
       `JOY_UP/RIGHT/DOWN/LEFT/FIRE`);
     - `int joy_key(uint8_t raw)` (keypad reading: `'0'-'9'`, `'*'`,
       `'#'` from the controller's table, or -1 for `Fh` or an unused
       code);
     - `JOY_KEY_FIRE` (D6, the keypad-mode second fire);
   - The header documents the table, and which digits share a nibble
     with a direction (1, 2, 3, 5, 6, 9, `*`, `#`; 0, 4, 7 and 8 are
     impossible direction combinations).
   - Both decoders are pure, with no state, and get a host unit test over
     all 16 nibbles against the controller's table (source:
     `src/ioc_hid.c` `coleco_keypad_nibble`,
     `src/controller_latch.c`).
4. **Outcome program** (Must): `tests/joy/joy.c` as `/system/joy.exe`
   (`STAGE=1`). Bare: the owner check prints each pad's raw byte and its
   set bits when it changes, until a key. `stage`: the replay checks.
5. **Simulator** (Must): `tests/z80sim.py` models the latch reads: an
   `IN` in `E0h-FFh` returns `latch[A1]` (default `7Fh`). The docstring
   cites `controller_latch.c` and states what it does not model (USB, the
   decode, mode select).
6. **hwtest** (Must): the namespace stage binds both names with type
   JOY.
7. **Docs** (Must):
   - architecture 4.10 (names), 5.6 (driver table, port ownership next
     to sound), 9 (reserve), 14 (remove the controllers item);
   - `devices.md` (a joy section);
   - `sdk.md` (joy);
   - `docs/memory.md`.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free / reserve | after 109 | the joy driver | lower the reserve, not below 512, in all four pins; below that stop and report |
| publications | 10 / 16 | +3 rows | over 16: stop |
| endpoints | 10 / 12 | +1 | over 12: stop |
| nucleus | ledger | only the type bound | any growth over 16 bytes: stop and report |

## Criteria

- **Must:**
  - a replay sets both latches and shows raw bytes through `joy_read`
    and `joy_read_call` (including a keypad code and idle `7Fh`);
  - pad 2 → `-KOS_EINVAL`; bind types;
  - INFO lists ports `FCh`/`FFh`;
  - `make check` green; `make ns-selftest` replays.
- **Informational:** `joy_read` and `joy_read_call` T-states; driver hot
  bytes.

## Owner checklist

- Flash; `/system/hwtest.exe`.
- `/system/joy.exe` with one F310 (D mode), then two: each pad's d-pad and
  A/B change its own line; X, Y, Back, Start show their keypad codes;
  confirm pad 0 is the first-mounted F310 (if swapped, report it).

## Validation

```sh
make && python3 -m unittest tests.test_joy tests.test_ns_selftest \
  tests.test_pack_image tests.test_iocfat tests.test_sound \
  tests.test_hwtest_sim tests.test_sdk tests.test_sdk_package
make ns-selftest
make clean && make check   # once, at the end
```

Before `make check`, message "main": sources frozen, plus the sha256 of
`build/konaos.bin`. Record: `docs/validation/<date>-joy-driver.md`.
