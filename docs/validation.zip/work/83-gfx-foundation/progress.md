# progress.md — 83-gfx-foundation

Present-tense working notes. Baseline: HEAD (clean tree).

## Plan

Implements docs/gfx-sdk.md 3-7 + the GFX-1 lifecycle part of 18:
KVIDEO_OP_DIRECT_INFO, abi/kos/kvideo.h, the V9958 driver answer, libgfx
(gfx_open/close/get_info/set_mode/display_enable/clear), the gfxtest
program, docs and tests.

## Design decisions (to state in the record)

- `gfx_clear` = one HMMV, DX=0, DY=0, NX = width (512 G6 / 256 G7),
  NY = 212 + 256 = 468: one rectangle covering the visible 212 lines of
  both VRAM pages ("both pages' visible area"), waited for.
- Mode register set follows the driver's proven G6 baseline
  (drivers/v9958/v9958.c v9958_init_g6 order: R#46 stop, R#8, R#0..R#11,
  selectors), all through native-WAIT register writes (the release
  guarantees WAIT on; no porch/paced work in the SDK).
  G6: R#0=0Ah. G7/YJK: R#0=0Eh. All modes: R#1=00h (display off, IE0
  off), R#2=1Fh, R#8=0Ah (VR|SPD), R#9=80h, R#15=2, R#23=0, R#25=04h
  (YJK: 14h), R#26/R#27=0.
- libgfx archive split: gfx.c (open/close/get_info + state),
  gfx_mode.c (set_mode/display_enable), gfx_draw.c (clear),
  backends/v9958/v9958_gfx.c (register programming), v9958_io.asm
  (port I/O). Private header gfx_internal.h.
- gfxtest modes: `info` (DIRECT_INFO refusal/fields), `mode6`, `mode7`,
  `yjk`; optional second arg `leak` skips gfx_close (the
  exits-without-close test).
- "No VIDEO dispatch between open and close" is observed by watching
  v9958_driver_dispatch (report.json) and reading frame->op at z.hl:
  expected sequence for a mode run is WRITE(1), ACQUIRE(0xFE),
  DIRECT_INFO(6), RELEASE(0xFF), WRITE(1).

## Budget

- Driver hot at HEAD: image 6,389 bytes (build/modules/v9958.report.json).
  After this package: 6,473 bytes hot image => +84 bytes consumed
  (share was <= 64; rule = report). Driver-hot ledger: 31,000 / 32,768
  used => 1,768 free, above the 1,536 reserve.
- Report before/after in the record.

## Pre-existing tree changes (preserved, not mine)

- `UserSoftware/KonaEdit/README.md` modified before this package started.
- Mid-session, `UserSoftware/KonaEdit/src/ke_ui.c`,
  `UserSoftware/KonaEdit/src/ke_widgets.c`,
  `UserSoftware/KonaEdit/tests/test_ui_sim.py` appeared modified (parallel
  KonaEdit work in the shared tree).  Not touched here; preserved and
  reported in the record.

## Status

- [x] ABI: protocol.h op 6, abi/kos/kvideo.h
- [x] Driver: v9958_proto.c DIRECT_INFO (held only) - builds, pinned
- [x] SDK: kos/gfx.h, libgfx (gfx.c, gfx_mode.c, gfx_draw.c, backend,
      v9958_io.asm), exe.mk libgfx rules, Makefile gfxtest + sdkpack
- [x] Tests: tests/test_gfx.py (9 tests) + updated test_v9958,
      test_sdk, test_sdk_package, test_source_layout
- [x] Docs: docs/sdk.md, docs/devices.md, docs/abi.md
- [x] Validation: named batch 141 tests OK (2 skips, both baseline);
      make clean && make check: reproducible rebuild + 900 tests OK
      (119 baseline skips), 0 FAIL/ERROR; git diff --check clean.
- [x] docs/validation/2026-10-24-gfx-foundation.md written.
- Hardware owner checklist: PENDING (no board in session), recorded.

## Budgets final

- v9958 hot image: 6,389 -> 6,468 (+79 bytes; share was 64; reported).
- driver-hot ledger: 30,916 -> 30,995 / 32,768; reserve 1,536 held
  (1,773 free).

## Key fixes during the run (each verified by a rerun)

- kvideo.h comment dropped "abi/" tokens (sdkpack forbids them).
- gfxtest argv: argv[0] is the first tail word (no program name).
- DIRECT_INFO record: high bytes of flags/vram_kib written zero
  explicitly (the request payload is not zeroed).
- test_gfx: pump the glyph model inside run_recording; expected VRAM
  counts = 468 rows; leak prints nothing after the key; settle on
  R#8 = 08h before the restore check (the prompt is visible mid-render,
  before the renderer's sprites restore).
- test_v9958 pin slices the helper function, and compares the exclusive
  check with the first payload write.
