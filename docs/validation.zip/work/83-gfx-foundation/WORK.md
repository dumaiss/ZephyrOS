> Worker package. Independent of 82 (KonaEdit). Baseline: HEAD. Implements `docs/gfx-sdk.md` sections 3,
> 4, 5, 6, 7 and the lifecycle part of 18 (GFX-1). One resident addition;
> everything else is SDK.

# Task

The graphics foundation: `KVIDEO_OP_DIRECT_INFO`, `libgfx` with its
lifecycle and mode setup, and `gfx_clear` as the one drawing call this
package needs to prove a mode.

## Current state

- Exclusive hold: `bind("/dev/video", KOS_BIND_EXCLUSIVE, &type)`
  (`tests/vblank/vblank.c`); the V9958 release re-runs the bring-up
  (`drivers/v9958/v9958_proto.c`, `KOS_OP_RELEASE`); process exit releases
  handles. `v9958_state.exclusive` marks the hold.
- The info-record pattern: `abi/kos/ksound.h` + `drivers/sound/` +
  `user/sdk/src/sound.c` (`sound_info`).
- V9958 ports and register constants: `platform/zephyr80/public/hardware.h`
  (`KOS_V9958_*`); the proven bring-up order: `drivers/v9958/v9958.c`
  (`v9958_init_g6`, `v9958_enable_hardware_wait`).
- SDK libraries: `user/sdk/exe.mk` (libtui pattern), `tools/sdkpack.py`,
  `mk/kos.mk` `LIBS=`, `tests/test_sdk_package.py`.
- Programs cannot hold an initialised non-const static array (it does not
  link): tables are `const` or built at run time.

Read: `work/00-WORKER.md`; `docs/gfx-sdk.md`; the files above;
`docs/devices.md` 6 and 14.

## Requirements

1. **ABI** (Must): `KVIDEO_OP_DIRECT_INFO` (6) in `protocol.h`;
   `abi/kos/kvideo.h` (shipped by the SDK) with `struct kvideo_direct_info`
   as in the doc (version 1, backend `KVIDEO_BACKEND_V9958`, flags
   `KVIDEO_DIRECT_IO | KVIDEO_HW_WAIT | KVIDEO_PALETTE | KVIDEO_YJK`,
   `vram_kib` 128, the five ports listed one by one, `config_initial`),
   `_Static_assert`ed size.
2. **Driver** (Must): the V9958 answers it in the reply payload only while
   held (`-KOS_EBUSY` otherwise). Budget below.
3. **libgfx** (Must): `kos/gfx.h` and `libgfx.lib` (own archive, shipped,
   `LIBS=gfx`): `gfx_open` (exclusive bind, type check, DIRECT_INFO,
   backend selection; any failure after the bind unbinds first),
   `gfx_close` (idempotent), `gfx_get_info` (mode, width, height, bpp),
   `gfx_set_mode` (G6, G7, G7+YJK: complete register state from any VDP
   state, WAIT on (R#25 WTE, plus YJK for the YJK mode), R#9 = 80h
   non-interlaced, sprites off (R#8 SPD), R#15 = 2, IE0 off, display off
   until `gfx_display_enable`), `gfx_display_enable`, `gfx_clear` (one
   HMMV over both pages' visible area, waited for). No VIDEO IPC after
   `gfx_open`. The backend lives in `user/sdk/gfx/src/` with a private
   header; port I/O is assembly.
4. **Program** (Must): `gfxtest` (in-tree, `tests/gfx/`): modes `mode6`,
   `mode7`, `yjk`: open, set mode, clear to a colour, display on, wait for
   a key, close.
5. **Docs** (Must): `docs/sdk.md` (libgfx, `LIBS=gfx`), `docs/devices.md`
   (the op), `docs/abi.md`; `docs/gfx-sdk.md` stays the design.

## Tests

- DIRECT_INFO refused without the hold, answered with it (fields).
- Each mode: the peer's registers after `gfx_set_mode` (R#0/R#1/R#8/R#9/
  R#25), the clear in VRAM, no VIDEO dispatch between open and close.
- After the key: the console is fully restored (`test_device_release`'s
  restore checks: registers, palette, cursor pattern, a prompt drawn).
- A program that exits without `gfx_close` leaves the console restored.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free / reserve | after HEAD / 1,536 | <= 64 bytes | report |

## Owner checklist

- `gfxtest mode6`, `mode7`, `yjk` on the board: a solid colour, a key,
  the console back.

## Validation

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_device_release tests.test_sdk tests.test_sdk_package tests.test_v9958 tests.test_source_layout
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-gfx-foundation.md`.
