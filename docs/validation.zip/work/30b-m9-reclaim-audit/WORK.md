# Task

Measure, before M9 closes, where every resident bank-7 and common-memory byte
goes, and produce a ranked list of reclaim opportunities. Distinguish
**architectural, maintainable savings** from one-off code golf, and express
every saving in the unit that matters: **arena granules**. Also estimate the
residency M10 will need, so the project owner can decide on the residency
architecture before M10 starts.

This is a measurement-and-report package. The only code it adds is
measurement tooling. It changes no kernel, driver, provider or user-program
bytes.

## Context

Dispatch only after package 30 (with its correction) is accepted. Read
`work/00-WORKER.md`, `work/00-SUPERVISOR.md` (the boundary-review guidance),
architecture 32.39, `docs/memory.md`, `docs/m10-m12-target-architecture.md`
(in particular 1, 2.3, 2.7-2.18 and 4.5), and `work/M9-REFERENCE.md`.

Expected starting point (verify; the tree is authoritative): production arena
35 granules with 33 in the boot set (`sio` 1, `ioc` 8, `hid` 2, `v9958` 9,
`iocfat` ≤13), about 1 KiB plus data slack of headroom, kernel `_CODE` about
28.5 KB ending near `8F3Ch`, common memory about 2.1 of 7.4 KB.

The target architecture states that M10 must not weaken the arena floor or
the common-memory ceiling, and that a larger kernel-residency design, if
needed, is decided separately **before** M10.

## Requirements

- **Granule-threshold tooling.** Extend the ledger tooling (`zmodpack plan` /
  `pack_image.py`) to report, for each resident module and for the kernel:
  - the exact image + BSS, the granules, the bytes **above the next lower
    granule threshold** (the saving needed to free one granule) and the
    bytes left before the next higher one;
  - for the kernel, the bytes to the next granule boundary in each
    direction, both for the arena start (code end) and for the data base
    (data size).

  Emit it to `arena.plan.json` and as a readable table. Add a host test
  that checks the arithmetic against the map. This persists as a permanent
  tool; it is not throwaway.
- **Inventory**, measured from the production map and `.rel`/`.sym` files,
  reported separately for: kernel `_CODE`, kernel `_DATA`, common
  `_COMMON`/`_COMMON_DATA`, each resident ZMOD image, each resident ZMOD
  BSS, and granule-rounding waste per module.
- **Findings, ranked in this order** (investigate each category; report "none
  found" when that is the result):
  1. code or data duplicated across the kernel and ZMODs, or across ZMODs
     (for example string, compare, CRC, formatting, copy helpers);
  2. SDCC runtime helpers pulled in accidentally (`__mulint`, `__divuint`,
     `__rlslong`, `___sdcc_enter_ix` frames, 32-bit helpers) and the call
     sites that pull them;
  3. oversized static buffers or scratch areas; anything that duplicates
     the VFS workspace pattern;
  4. per-module 512-byte rounding waste, with the threshold distances above;
  5. resident functions that could move to user space (an SDK program or
     the monitor) without losing a system responsibility;
  6. generic helpers duplicated inside `iocfat` that the kernel or SDK
     already provides;
  7. code paths with no current consumer;
  8. tables or constants represented inefficiently (branches where a table
     would do, or 32-bit where 16-bit suffices);
  9. stored state that could be cheaply recomputed;
  10. opportunities to consolidate common filesystem/provider logic without
      violating the VFS/provider layering (architecture 32.10-32.12).

  For each finding report: location (file/function/symbol), the measured
  bytes, which region it affects, the **granule effect** (savings that do not
  cross a threshold save zero granules; say so), a risk/effort note, and a
  classification:
  - **A (architectural/maintainable):** a reusable structural improvement
    that keeps layering and makes later work easier;
  - **B (local cleanup):** worthwhile, contained, low risk;
  - **C (code golf):** saves bytes at a cost to clarity; listed but not
    recommended unless it frees a granule cheaply.
- **`iocfat` special attention.** Report its exact image + BSS and the bytes
  separating it from 12 and from 11 granules, then say whether each
  threshold is realistically reachable with A/B findings alone.
- **Common-memory ceiling proposal.** The target architecture refers to a
  common-memory ceiling that is not yet pinned. List every common item with
  its owner and why it must be common. Propose a ceiling and an M10
  reservation (the far-call frame/gate and any per-process far state from
  target 2.13-2.15), with its derivation.
- **M10 residency estimate.** Using measured M9 code density, estimate the
  resident kernel code, kernel data and common bytes for each M10 mechanism
  in the target architecture: the `SYS_XMEM_*` family and allocator; unified
  bank ownership; the ZEX v2 loader with auxiliary segments and relocation;
  the far-entry table; `SYS_FAR_CALL` and the auxiliary low window; and
  `SYS_ZEX_SEGMENT_INFO`. Note what can replace existing code (ZEX v1
  removal) and what is net new. Give a low/high range, and compare it with
  the post-30 headroom and with the best-case post-reclaim headroom.
- **Report.** Write `docs/validation/<date>-m9-reclaim-audit.md` with:
  - the inventory tables and the granule-threshold table;
  - the ranked findings, each with class A/B/C, bytes and granule effect;
  - the `iocfat` threshold analysis;
  - the common-ceiling proposal;
  - the M10 residency estimate;
  - a closing recommendation: which findings to implement in package 30c,
    the expected end-of-M9 ledger, and whether the M10 estimate fits.

## Constraints

- No changes to kernel, driver, provider, SDK or program code, and no
  changes to production or acceptance image bytes. Only measurement tooling,
  its tests, and the report.
- Do not implement any finding; package 30c does that after the project
  owner selects.

## Validation

```sh
make clean && make check
python3 -m unittest tests.test_pack_image tests.test_m8 -v
git diff --check
```

Production image and module hashes must be identical to package 30's
accepted build; report them. No hardware run.

## Acceptance criteria

- The ledger reports per-module and kernel granule thresholds permanently,
  with a test.
- The report covers every category, with bytes, region, granule effect and
  A/B/C class, and gives the `iocfat` 12/11-granule analysis, a common-ceiling
  proposal and an M10 residency estimate.
- No product bytes change.
