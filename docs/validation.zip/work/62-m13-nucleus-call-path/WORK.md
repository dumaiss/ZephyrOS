> **DRAFT.** Runs after 61. The nucleus call and copy paths. No ABI
> change, no architecture change (the layers stay; each gets cheaper), no
> firmware change.

# Task

Cut the per-call cost of the layered path. After 61 a 4 KiB read is
within ~9% of CP/M on the board (13.9 ms per block), but a 512-byte read
takes 15.95 ms against CP/M's 12.8: the remaining ~3 ms is paid per call,
not per byte. The simulator puts a cached 128-byte read at ~5 ms door to
door, of which the provider is ~1.7 ms; the rest is the call path.

The 61 profile (cold reads, 54 calls; per-function kernel attribution is
approximate - the scratch profiler anchors statics by area and mislabels
some) shows, per call, roughly: `ipc_syscall_call_object` ~0.2 ms (two
32-byte frame copies, descriptor capture and release), endpoint lookup and
invoke/domain switching ~0.3 ms, `vfs_handle_find` ~0.07 ms per scan
(83 scans for 54 calls), object/VFS routing (`object_call`,
`vfs_ns_fs_call`, `vfs_ns_resolve`) ~0.15 ms, syscall entry and dispatch
~0.15 ms, event pick at every syscall and interrupt exit ~0.05 ms. Each
`copy_out` costs ~0.4-0.5 ms around its bytes (`api_copy`, descriptor
lookup, path choice, the gate).

Read: `work/00-WORKER.md`; the 59-61 records; `kernel/ipc/ipc.c`,
`ipc_asm.asm`, `ipc_common.asm`; `kernel/syscall*`; `kernel/vfs/*`;
`kernel/event/*`; architecture 4.x; `docs/memory.md` (the ledgers).

## Requirements

1. **Measure first, exactly.** Attribute nucleus time per function from
   the map's per-module area bases (no mislabelled statics), for one
   syscall read (hit and miss) and one `copy_out`. Record the table; it
   chooses what follows.
2. **The syscall-to-provider path.** From that table, the top items of
   syscall entry, `ipc_syscall_call_object`, VFS handle lookup and
   routing, endpoint resolve/invoke and the domain switches: no repeated
   scans in one call (a handle found once is passed down), frame copies
   with the unrolled copy and only the bytes the operation uses, hot
   checks in assembly where C pays IX frames. Stop when no item exceeds
   0.05 ms per call.
3. **The copy API.** `copy_out`/`copy_in` decide the path once per
   descriptor (at capture) and run it with the least work around the
   bytes; target under 0.15 ms per call beyond the bytes.
4. **Exits.** The event pick at syscall and interrupt exit returns
   immediately when nothing is armed.
5. **Budgets.** Common memory has ~20 bytes of room (3,051 of 3,072):
   nothing moves into it without an equal saving; the cold half's and
   fixed core's room are reported before and after.
6. **Measure**: the phase table (hit and miss), the profile buckets, board
   SDBENCH. Target: a 512-byte read at or under 13.5 ms on the board and
   a cached 128-byte read under 3 ms in the simulator.
7. No behaviour change: every replay, the IPC acceptance image and the
   event tests pass unchanged.

## Owner checklist

SDBENCH; a small file read twice; `hwtest`; `fs_selftest`; `timer card`;
`vgmplay night.zvg` (0 underruns; it exercises the event exits).

## Validation

```sh
make && make ipc-selftest && make phase-image && make fs-selftest
python3 -m unittest tests.test_ipc tests.test_events tests.test_readpath tests.test_hwtest_sim tests.test_shell_sim tests.test_console_acceptance
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-m13-nucleus-call-path.md`.
