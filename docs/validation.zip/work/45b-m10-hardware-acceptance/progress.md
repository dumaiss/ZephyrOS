# 45b progress — M10 hardware acceptance exerciser

Baseline: package-45 tree, production `fd4436710e3fae940cee619bbf87831a0aa939bdf9e39328c74f928845f6e91d`.

## Contract reading (WORK.md)

- Production image gains `/SYSTEM/hwtest.zex` (runner) plus the outcome
  programs it runs, and one monitor command `X <path> [tail]`.
- Nucleus and drivers unchanged; production changes only in the monitor
  and the store; new hash recorded.
- `tools/serial_smoke.py --mode hwtest` and a production simulator replay
  (with and without a card) both drive `X /SYSTEM/hwtest.zex`.

## Supervisor decision (2026-10-11), recorded from the ask

Requirement 5 wants the smoke tool to *send* the command over SIO0/B at
the monitor prompt, but the production console input is HID
(`console-v9958-hid`): lane bytes reach the SIO service and nothing reads
them as input.  The supervisor selected, over the alternatives (targeting
the console-serial variant image, or a capture-only mode):

> Give the production monitor a polled serial command-input path (bind
> /dev/serial/0 when present, merged with console input) so the smoke
> drives the real production image with no special flash.

## Design decisions

1. **Monitor input.** `user/monitor/` binds the namespace name
   `/dev/serial/0` when a SERIAL object is published there and polls it
   as a second command source beside the console.  No port I/O, no driver
   symbol, no protocol knowledge beyond the SERIAL ops the console-serial
   build already uses: bind returns the type and the monitor checks it.
   - Console is polled first, so the console-serial build keeps its single
     stream (a byte is consumed by the console path, exactly as today).
   - The monitor echoes each byte to the *source it came from*: a lane byte
     echoes on the lane, a console byte on the console.  The serial-console
     build therefore sees each byte once, and in production the tool driving
     the lane sees its command echoed back (the send handshake), while the
     owner sees keyboard input on the V9958 as before.
   - The monitor's reader applies the SDK line-editor rules (`zos_read_line`
     semantics: BS/DEL with erase echo, CRLF suppression, bell instead of
     overflow, control bytes ignored, 80-column cap) because the two
     sources must be serviced by one loop.
   - Nothing is written to the lane at startup, so the production boot
     transcript (four early-console lines) is unchanged.
2. **`X <path> [tail]`.** `user/monitor/monitor_exec.c`: the ordinary
   `SYS_EXEC` path through `zos_exec()`, which already runs the child
   synchronously and returns its u16 status.  Argument problems report
   `ERR: ARG`; a service failure reports `ERR: <code>`; a normal exit
   prints `exec: exit status 0x<4 hex>`.  Help gains one line.
3. **Runner.** `tests/hwtest/hwtest.c` (STAGE=1, `tests/hwtest/`), the
   production store's `/SYSTEM/hwtest.zex`:
   - stage 1 xmem+far: `/SYSTEM/xmem_selftest.zex` unchanged (it execs
     `xmem_child` and `xmem_far` itself);
   - stage 2 files: `/SYSTEM/fs_selftest.zex` with a new tail option
     `scratch=<dir>` (`/FS/HWTEST`), which confines every write, removes
     the scratch tree at the end even after a failure, and returns instead
     of handing the console to the monitor; `fs_child` gains a path tail
     for the same reason (it wrote `/FS/CHILD.TMP`);
   - stage 3 namespace/handles: the `tests/ns/ns.c` checks that apply to
     the real production publications, plus CWD, bad path/handle and
     handle-table exhaustion/recovery;
   - one line per stage, a final `hwtest: <n>/<m> PASS|FAIL`, and
     `card absent` in the summary when there is no card;
   - every line goes to the console and, when the lane is published, to
     the lane, so the owner's terminal and the smoke tool see the same
     transcript;
   - handles are released before each `run`.
4. **Store.** `recovery/manifest.json` gains the runner and the reused
   programs; the Makefile's production branch depends on them.  Size
   before/after against capacity is reported in the record.
5. **Smoke + replay.** `--mode hwtest` waits for the boot banner, then
   echoes a command handshake over the lane (send `X`, wait for its echo,
   send the rest at typed speed) and checks the stage lines and summary,
   with and without a card.  `tests/test_hwtest_sim.py` replays the
   production image with a card (command injected on the lane) and without
   a card (command typed through HID), checks the summary and that
   `/FS/HWTEST` is gone.

## Constraints kept

- no sub-agents; no commit (owner instruction);
- the fs image transcript (tests/test_fs_selftest_sim.py, 35/8 checks) is
  unchanged: the new options only add lines in stage mode;
- `ipc-selftest` and `subsystem-selftest` stay separate (they need
  test-only nucleus code) — stated in the record.

## Implementation log (final state)

1. **Monitor** — `user/monitor/monitor.c` polls the console first
   (`zex_read`, non-blocking) then the lane (`/dev/serial/0`,
   `ZSIO_OP_POLL`/`GETC`), echoing each byte to the source it came from;
   `user/monitor/monitor_exec.c` adds `X <path> [tail]` through
   `zos_exec`, printing `exec: exit status 0xssss` (uppercase hex) or
   `ERR: ARG` / `ERR: <code>`; help gains the row.  Monitor 6053 bytes,
   `5f6a0d35…`; `MONITOR_SIZE`/`MONITOR_SHA256` re-pinned in
   `tests/test_console_acceptance.py`; the help-row marker in
   `tests/test_monitor.py` follows the wording.
2. **The one option the reused programs gained is `stage`**
   (the earlier `scratch=<dir>` idea was dropped: the runner owns the
   directory and the far run).  `fs_selftest.c` selects `/FS/HWTEST`
   paths and stops handing the console to the monitor; `fs_child.c`
   accepts `stage` (card file `/FS/HWTEST/CHILD.TMP`); `xmem_selftest.c`
   measures the banks it can open, states its pool rows against that
   number, and leaves the far run to the runner.  The fs image's boot
   transcript is byte-identical (its replay is unchanged).
3. **Runner** `tests/hwtest/hwtest.c` → `/SYSTEM/hwtest.zex`: three
   stages, one line each (`hwtest: <stage> PASS|FAIL|card absent`), a
   verdict `hwtest: <n>/3 PASS|FAIL` with the card note, every line to
   the console and the lane, handles released around each `run`, whole
   bank counts bracketing each stage program.
4. **Store** 27 326 → 87 840 of 294 912 bytes (the six programs 59 222
   payload + 216 directory, the monitor +1076).
5. **Smoke** `tools/serial_smoke.py --mode hwtest` (per-byte echo
   handshake, card-state inference, `HW_TIMEOUT` 120 s) and
   `make smoke-hardware-hwtest`.
6. **Tests** `tests/test_hwtest_sim.py` (production replay with a card on
   the lane, without a card over HID, `X /SYSTEM/fs_child.zex tail-42`
   for the exit-status row), `tests/test_hwtest.py` (15 static pins),
   plus the updated production-store pins.

## Findings (also in the record, section 5)

- Exec chain depth 4 → the runner runs `xmem_far` directly; the two far
  rows of `xmem_selftest` move to the runner (61 checks in the stage, 63
  in the acceptance image).
- A bank held by a live process is closed to auxiliary placement: the
  exerciser measures 3 open banks where the acceptance image has 5.
- The descriptor pool is global (12): the monitor's 3 handles leave the
  runner 7; the stage pins the behaviour, not a count.
- **`X /FS/<name>.zex` failed with `ERR: 02`** (no FS2 traffic at all;
  fixed by correction 01 below):
  `zos_process_path_scratch` is bank-7 `_DATA` at 0xC0DD, inside the
  `6000h-DFFFh` window a bank-6 provider replaces, so the `/FS` provider
  never sees the path.  `/SYSTEM` works (in-process ROMFS reader); M9 had
  card executables because its provider was in-process.  Fix is one
  kernel change; the package freezes the nucleus, so the supervisor
  confirmed shipping without it (2026-10-11) and the gap is on the
  post-M10 list.  `user/monitor/` and `docs/monitor.md` state the
  verified behaviour.
- Three defects found and fixed by the new replay: `fs_child`'s
  startup-tail length, `xmem_selftest`'s hard-coded `big[4]`, and
  `xmem_selftest`'s initialized `static` (ZEX v2 has no initialized
  writable data).

## Correction 01 (2026-10-11): run programs from `/FS`

Contract: `work/45b-m10-hardware-acceptance/correction-01/WORK.md`.
Record: `docs/validation/2026-10-11-m10-hardware-acceptance-correction-01.md`.

1. **The fix.** `syscall_exec` copies the caller's path into `VFS_WS_IN_A`
   inside `vfs_ws_enter(VFS_WS_VIEW_PATH)`/`vfs_ws_leave()` and calls
   `process_prepare` there; `process_prepare` holds the path view around
   its one `vfs_ns_bind` (the loader that follows reads the bound FILE
   through descriptors and the common staging, and the tail copy happens
   after the view is left).  `zos_process_path_scratch` is retired from
   `kernel/process/process.c`, `include/zephyros/process.h` and the
   `launch.asm` comment - the cold-half `_DATA` block is gone, which is
   where the 128 bytes the ledger shows as "cold data −128" went.
2. **The guard.** `tools/mapcheck.py`: the obsolete M9 window requirement
   for that buffer is deleted (it failed the build) and `_vfs_workspace`
   joins `REV13_FIXED_SYMBOLS`, so a link into `6000h-DFFFh` fails the
   build.  `config/residency.json` already had `vfs_workspace`
   `fixed-required` for the same reason, so nothing changed there.
3. **The audit (requirement 2).** bind = `VFS_WS_IN_A`; FS namespace ops
   (`stat`/`mkdir`/`rmdir`/`unlink`/`rename`) and `chdir`/`ns_enum` put
   the path in the *call frame's payload* on the nucleus stack
   (`5D00h-5F00h`, fixed core) and route enumeration output through the
   call descriptor; the loader's FILE reads and the service loader use
   `_zos_user_copy_staging` in common memory (always mapped); the
   monitor's `X` has no buffer of its own; the `/SYSTEM` ROMFS reader is
   in-process.  The retired scratch was the only violation.
4. **Card-absent consistency (requirement 5).** One documented error,
   `ZOS_ENODEV` (`03h`), for every operation below `/FS` with no media
   (`fs/iocfat/iocfat.c`, `docs/devices.md`).  The driver's probe
   (`iocfat_media_readable`) opens the root *and* reads one entry, and
   the root `ZFS_OP_STAT` proves the media the same way before answering
   "directory": the deployed firmware answers `OPENDIR` for the root from
   a cached mount context after the card is gone, which is how the bench
   reached `chdir("/FS") == 0` while `mkdir` below `/FS` failed.  The
   simulator's FS2 model now answers exactly like the firmware
   (`CAPS`/`GENERATION`/`ROOT`/`OPENDIR` OK, `READDIR` and the rest
   `NO_MEDIA`), so the replay proves the probe.  `hwtest`'s rows report
   the code they saw (`got 02 want 03`, `type 02 want 04`, `not listed`)
   through `hw_check_status`/`hw_check_accepted`/`hw_check_enum`.
5. **Console `=` (requirement 6).** Not a glitch: it is the
   `console-write` row's own byte - `zos_console_write("=", 1u)` writes
   one `=` and then the row prints.  Commented, nothing changed.
6. **Coverage.** `fs_selftest` copies the child onto the card and execs
   it (`exec-card-copy`, `exec-card-status`; 35 → 37 checks with a card,
   absent branch stays 8); the exerciser's file stage does the same under
   `/FS/HWTEST` and removes `HW_PROGRAM` in `hw_scratch_remove`; the
   production replay runs `X /FS/FS_CHILD.ZEX tail-42` through the
   monitor and asserts the transcript *and* the FS2 request log
   (`OPEN_RO`/`READ`/`CLOSE`), which is the row that failed before.
7. **Numbers.** Production image
   `5a731321687636e8a7c26a1ccbadb545209621429e3577bbbafd13a647c395d2`;
   store 88 687 of 294 912; `iocfat.zmod` 7812 → 7847 (`b6c1a7a4…`);
   `hwtest.zex` 12175 → 12461 (`8f45ab3b…`); `monitor.zex` unchanged
   (6053, `5f6a0d35…`); nucleus fixed/cold/common ledgers unchanged
   except the cold half's `-128` data.
8. **Validation.** `make clean && make check` green, 606 tests
   (104 skipped), 136.1 s, rebuild byte-identical; the four acceptance
   targets green in 6m36.7s; `git diff --check` clean.  No commit.

## Validation

- `make clean && make check`: green (606 tests, 104 skipped; rebuild
  reproducible, `5a731321…`).
- `make xmem-selftest fs-selftest ns-selftest console-integration-selftest`:
  green, 6m36.7s (re-run with correction 01; 6m26s at 45b).
- `git diff --check`: clean.  No commit (owner instruction).
