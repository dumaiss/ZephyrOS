# Task

Ship a **feature exerciser in the production image**, so that the owner
can check most of the M10 hardware checklist on the real production
system, with no special flash:
- `/SYSTEM/hwtest.zex`, a runner, plus the outcome programs it runs, in
  the **production store**;
- a monitor command to run it: `X /SYSTEM/hwtest.zex`.

Production still boots straight to the monitor. The exerciser runs only
when asked.

## Context

Read:
- `work/00-WORKER.md`;
- the package-45 record (`docs/validation/2026-10-11-m10-acceptance.md`,
  sections 4 and 7);
- `user/monitor/`;
- `recovery/manifest.json`;
- the `xmem_selftest` and `fs_selftest` program families and their
  manifests;
- `tests/ns/ns.c`, for its namespace checks.

Baseline: the package-45 tree (production `fd443671…`).

## Requirements

1. **Monitor: `X <path> [tail]`.**
   - Runs a program (synchronous `run`) and prints its exit status, then
     returns to the prompt.
   - Add it to the help.
   - It works for any ZEX on `/SYSTEM` or `/FS`, so it is also a
     recovery tool.
2. **The runner, `/SYSTEM/hwtest.zex`.** It runs, in order, and prints
   one line per stage, then a final `hwtest: <n>/<m> PASS` (or `FAIL`):
   - **xmem and far code:** the existing `xmem_selftest` family,
     unchanged, including its far program;
   - **files:** the `fs_selftest` family, with every write confined to a
     scratch directory (`/FS/HWTEST`) that is removed at the end, even
     after a failure. Never touch other files on the card. With no card
     present, the absent-card branch is the expected result, and the
     summary says `card absent`;
   - **namespace and handles, against the real production
     publications:**
     - `bind` `/dev/console`, `/dev/video`, `/dev/input/keyboard`,
       `/dev/serial/0` and `/dev/ioc`, checking the returned types;
     - `ns_enum` on `/`, `/dev`, `/SYSTEM` and (with a card) `/FS`;
     - `chdir`/`getcwd`, including `/`;
     - a bad path and a bad handle;
     - handle-table exhaustion and recovery.

     Reuse the checks from `tests/ns/ns.c` where they apply; the
     synthetic `nsdev` checks do not apply.
   - **Nested exec:** covered by the stages above (a tail, exit status,
     handles released).

   The runner releases its handles before each `run`, and prints on the
   console (the V9958 in production) and on the serial lane.
3. **Programs.** Reuse the outcome programs as they are. Where one
   assumes it is the boot program, or writes outside the scratch
   directory, give it an option through its tail rather than forking a
   copy. Do not weaken any check.
4. **Store budget.** Report the ROM store's size before and after against
   its capacity. If the programs do not fit, stop and report.
5. **Smoke mode.** `tools/serial_smoke.py --mode hwtest` sends `X
   /SYSTEM/hwtest.zex` at the monitor prompt and checks the stage lines
   and the summary, with and without a card.
6. **Simulator replay.** The production image, with a card and without:
   `X /SYSTEM/hwtest.zex` reaches `PASS`, and `/FS/HWTEST` is gone
   afterwards. Outcomes only.

## Not covered (stays separate, by design)

`ipc-selftest` (real CTC interrupts into drivers) and
`subsystem-selftest` (syscall, IRQ, ROMFS and process probes): both need
test-only nucleus code, which production does not contain. Say so in the
record.

## Constraints

- The production nucleus and drivers do not change. The production image
  changes only in the monitor and the store; record the new hash.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-hardware-acceptance.md`, and it includes the
  **owner checklist:** flash production, run `X /SYSTEM/hwtest.zex` with a
  card, then without, and the expected lines.

## Validation

```sh
make clean && make check
make xmem-selftest fs-selftest ns-selftest console-integration-selftest
git diff --check
```

The replay runs as part of `make check` (production).
