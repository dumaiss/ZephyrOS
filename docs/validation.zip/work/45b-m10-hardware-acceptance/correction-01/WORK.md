# Correction 01: run programs from `/FS`

Runs after 45b completes, as its follow-up.

**The defect (an M10 regression, found during 45b).** Executing a program
from `/FS` fails: `X /FS/<name>.zex` prints `ERR: 02` (`EINVAL`), and
IOC-FAT issues no FS2 command at all. The same name resolves through a
program's own `bind`.
- `SYS_EXEC` stages the caller's path in `zos_process_path_scratch`,
  which is cold-half `_DATA` (`C0DDh`), inside the `6000h-DFFFh` region
  that the bank-6 window replaces.
- A bank-6 provider therefore reads bank-6 bytes, not the path. That
  breaks the buffer rule of architecture 36.5: memory a driver reaches
  must never be in the cold half.
- `/SYSTEM` works because the ROMFS provider runs in-process. M9 ran
  card executables because its provider was in-process too.

## Requirements

1. **Exec stages its path the way `SYS_BIND` does**, through the VFS
   workspace in the fixed core. Do not add a new buffer. Retire
   `zos_process_path_scratch` for this use, and delete it if nothing else
   uses it.
2. **Audit the same class of bug.** Check every nucleus path that hands a
   buffer or a path to a provider or driver: `stat`, `ns_enum`, `chdir`,
   the loader's FILE reads during exec, the monitor's `X`, and any other.
   Fix every instance the same way, and list what you checked.
3. **A guard.**
   - Mark each such buffer `fixed-required` in `config/residency.json`,
     with the reason.
   - If it is cheap, make `mapcheck` reject a provider-facing buffer
     symbol placed in the cold half.
4. **Regression coverage.**
   - The `fs_selftest` family execs a child **from `/FS`**, with a tail
     and an exit status.
   - The `hwtest` file stage does the same.
   - The monitor's `X /FS/<name>.zex` works, which the simulator replay
     must show, FS2 traffic included.
5. **Card-absent consistency (hardware, 2026-10-11).**
   - With no card, `hwtest` failed `chdir-card-enodev` on the board but
     passed in the simulator.
   - Define one documented error for "`/FS` has no media", and make
     `bind`, `stat`, `ns_enum` and `chdir` below `/FS` all return it,
     whatever the real IOC answers (the simulator's IOC model must give
     the same no-media answer as the hardware).
   - Make `hwtest` print the actual code on any mismatch.
6. **Console glitch:** on the board, a stray `=` was printed before
   `fs-selftest: console-write OK` on the V9958. Find the cause if it is
   cheap (a byte from the program, the console driver or the terminal
   parser); otherwise report it.
7. **Record:** a production fix with the new hash, the ledgers, and the
   audit list.

Also update the 45b owner checklist with a card step:
`X /FS/HWTEST/<child>.zex`, or a program copied to the card.

## Validation

```sh
make clean && make check
make fs-selftest xmem-selftest ns-selftest console-integration-selftest
git diff --check
```
