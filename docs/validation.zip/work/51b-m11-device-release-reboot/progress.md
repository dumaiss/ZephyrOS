# progress — package 51b (m11 device release and reboot)

State: **done**.  Implementation, host tests, simulator replays and the
validation batch are green; the record is
`docs/validation/2026-10-13-m11-device-release-reboot.md`.

## Done

1. **Release notification.**
   - `formats/include/mod.h`: `MOD_EP_RELEASE` (bit 1).
   - `tools/modpack.py`: the endpoint manifest key `"release"` (a
     boolean) is validated and ORed into the packed endpoint flags; the
     container checks accept both declared bits.
   - `kernel/ipc/ipc.c`/`ipc.h`: `ipc_endpoint_flags()` exposes what an
     endpoint was installed with.
   - `kernel/vfs/dev.c`: `vfs_device_notify_release()` (the common
     `KOS_OP_RELEASE` call, result ignored) and the DEVICE bind path that
     stores the exclusive mark; `kernel/vfs/handles.c`:
     `vfs_ns_release_entry` notifies an endpoint that declared the flag,
     on explicit unbind and on process exit; `kernel/vfs/vfs.h`:
     `VFS_HANDLE_EXCLUSIVE`.
2. **Exclusive binds.**
   - `abi/kos/object.h`: `KOS_BIND_EXCLUSIVE` (`8000h`) as the one
     DEVICE flag.
   - `kernel/vfs/dev.c`: a flagged endpoint is asked with
     `KOS_OP_ACQUIRE` before the handle is built, its 0 or `-KOS_EBUSY`
     becomes the bind result, and an unflagged endpoint with the flag is
     `-KOS_ENOTSUP` without a call.
   - `docs/devices.md` section 12 states the contract: a program writes a
     device's ports only while it holds that device's exclusive handle.
3. **VIDEO.**
   - `drivers/v9958/v9958.json`: `"release": true`.
   - `drivers/v9958/v9958_proto.c`: `KOS_OP_ACQUIRE` (claim or EBUSY),
     `KOS_OP_RELEASE` (`arg1` = 1 ends the takeover and re-runs the
     display init) and `KVIDEO_OP_RESET` (3).
   - `drivers/v9958/v9958.c`: while a takeover is held the PUTC and WRITE
     paths drop the bytes and count them (saturating 16-bit counter, the
     caller keeps its length); `v9958_display_reset()` is the shared
     re-init: terminal defaults, mode registers, wait, palette, both font
     atlases, clear, cursor home, present, display on.
4. **Console reset.** `KCONSOLE_OP_RESET` (5) in
   `drivers/console/console_proto.c`: the V9958 build drains the input
   queue through `KHID_OP_GETC` (bounded, first empty answer ends it) and
   forwards `KVIDEO_OP_RESET`; the serial build answers 0.
5. **Launcher.** `kernel/main.c`: `kernel_console_reset()` runs before
   every `process_exec` of the boot program (start, restart after an
   exit, and the start that follows a warm reboot), through the ordinary
   console path.
6. **Warm reboot.** `abi/kos/syscall.h`: `KOS_SYSCALL_REBOOT` (`0Ch`);
   `kernel/syscall.c`: `syscall_reboot()` masks interrupts, runs the
   existing CTC quiesce and enters `_platform_reboot_now`
   (`kernel/memory/banking.asm`, common-resident: `di`, latch `00h`,
   `jp 0`); `user/sdk/src/gate.asm` and `kos/process.h`: `reboot(void)`.
   Callers: the monitor's `B` and the shell's `reboot` built-in (also in
   its `help` line). No peripheral receives a hardware reset: every boot
   init was audited (below) and IOC-FAT gained the one fix it needed.
7. **Docs.** `docs/architecture.md` (reset/reboot, launcher, exit
   release, handles, the syscall table), `docs/abi.md` (the syscall, the
   bind flag, the release on unbind, the console reset, the reboot
   section), `docs/devices.md` (the new takeover section, the V9958 and
   console operations), `docs/vfs.md`, `docs/monitor.md`, `docs/sdk.md`,
   `docs/boot.md`, `docs/filesystem.md`, `docs/module-format.md`.
8. **Tests.** `tests/test_device_release.py` (host and replay) with
   `tests/device/devtest.c`, the outcome program the replays place on the
   card; `tests/test_sdk.py` and `tests/test_source_layout.py` pin the
   new program; `tests/test_shell_sim.py` gained `reboot` in the `help`
   row; `tests/z80sim.py`'s MCU peer answers the FS2 `RESET` command the
   way the deployed firmware does.

## Boot-init audit (no peripheral gets a hardware reset)

| init | state it could have inherited | outcome |
|---|---|---|
| SIO (driver and early console) | programmed channel, FIFO bytes, hunt mode | full WR programming plus channel reset first: any-state safe |
| CTC | channel mode, time constant, a pending count | nothing has programmed it before the quiesce (`platform_irq_quiesce` only stops it) |
| V9958 | the whole register file, both VRAM pages, palette | every owned register, selector, palette entry and VRAM asset is rewritten; a program's leftovers are replaced |
| IOC | command and bulk lanes, sequencing, a stale reply | boot resets both lanes and re-runs the link-sync handshake |
| HID | its own rings only (the MCU owns the queue) | RAM-only state; the console reset drains the ring before the next program |
| IOC-FAT | **MCU-held file and directory slots a dead Z80 side never closed** | **fix:** the driver now sends FS2 `RESET` (32h) before `CAPS`, closing every controller context and advancing the generation |
| Console | terminal attributes, the escape parser, cursor, queued input | the launcher's `KCONSOLE_OP_RESET` before every start |

## Notes

- The keyboard reset requirement was dropped by the owner: the IOC
  already resets the machine on its own key combination (the combination
  is the MCU's, and the console never sees it), so the console driver
  does not turn a key combination into `REBOOT`.  `reboot` is reachable
  from the monitor's `B`, the shell's built-in and any program's
  `reboot()`.
- `tests/test_device_release.py` runs in about five minutes: twenty
  boots for the reboot loop, the rest single-boot replays.

## Validation

- `tests.test_device_release`: 12 tests, OK (4m54s).
- `make clean && make check`: reproducible rebuild, 695 tests, the two
  accepted failures only (`tests.test_hid`, `tests.test_v9958`
  `test_system_file_and_boot_order`), 10m35s.
- `make console-serial-selftest`: 6 tests, OK.
- `git diff --check`: clean.  The handoff grep prints only the three
  shell-location comments the shell packages' contract states.
