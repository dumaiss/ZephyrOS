> **DRAFT. Not dispatched.** Runs after 51, before 52 (52's launcher
> uses the console reset).

# Task

**Restoring hardware state after a program.** The Z80 cannot stop a
program from writing to ports, so this is a contract plus recovery, in
three layers:
1. drivers hear about release;
2. a program that takes over a device holds an exclusive handle, and the
   driver restores the device when that handle goes;
3. a console reset and a warm reboot catch everything else.

**The gap today:** architecture 36.13 says exit releases device
instances, but `vfs_ns_release_entry` (`kernel/vfs/handles.c`) only
closes `/fs` files. A device driver never learns that a handle went
away.

Read:
- `work/00-WORKER.md`;
- the architecture's object/handle and resident-driver sections;
- `kernel/vfs/handles.c`, `kernel/vfs/dev.c`, `drivers/v9958/`,
  `drivers/console/`, `boot/`, `kernel/irq/ctc.c`;
- the Zephyr-80 `Memory Management.md`, "Reset and ROM-to-RAM copy".

## Requirements

1. **Release notification.**
   - New endpoint flag `MOD_EP_RELEASE` (bit 1, `formats/include/mod.h`),
     declared in the manifest as `"release": true`.
   - When a handle on a DEVICE publication whose endpoint has the flag is
     unbound (explicitly or by exit), the nucleus calls the endpoint with
     the common operation `KOS_OP_RELEASE` (`FFh`, `abi/kos/protocol.h`):
     `arg0` = the object, `arg1` = 1 if the handle was exclusive.
   - The result is ignored. Endpoints without the flag cost nothing.
   - Cold half only. Report the bytes.
2. **Exclusive binds.**
   - Bind flag `KOS_BIND_EXCLUSIVE` (`8000h`), for DEVICE binds.
   - For a flagged endpoint, the nucleus first calls the common operation
     `KOS_OP_ACQUIRE` (`FEh`, `arg0` = the object). The driver returns 0,
     or `-KOS_EBUSY` if another handle holds it exclusively; on an error,
     the bind fails with that error.
   - A non-flagged endpoint with `KOS_BIND_EXCLUSIVE` → `-KOS_ENOTSUP`.
   - **The contract** (written in `docs/devices.md`): a program writes a
     device's ports, or reprograms it beyond its protocol, only while it
     holds that device's exclusive handle.
3. **VIDEO (V9958).**
   - Set the release flag.
   - While an exclusive handle is held, the console does not draw. Console
     output is dropped and counted.
   - On an exclusive release, the driver re-runs its full init: mode
     registers, palette, font upload, clear, cursor home. The next console
     output starts on a clean screen.
   - New operation `KVIDEO_OP_RESET` (3): the same re-init, callable at
     any time.
   - Its init must not assume power-on register values (see requirement
     6).
4. **Console reset.** New operation `KCONSOLE_OP_RESET` (5): reset the
   terminal state (attributes, the escape parser, the cursor), call
   `KVIDEO_OP_RESET` on its VIDEO dependency when there is one, and empty
   the input queue. The serial console resets only its own parser.
5. **The launcher calls `KCONSOLE_OP_RESET`** before every start or
   restart of the boot program and before the monitor fallback. The
   ordinary console path is used; there is no new mechanism.
6. **Warm reboot.**
   - `KOS_SYSCALL_REBOOT` (`0Ch`); SDK `reboot(void)`, which does not
     return.
   - Sequence: mask interrupts, the existing CTC quiesce, write latch
     `00h`, `JP 0000h`. The ROM reset vector then re-copies the OS
     exactly as at power-on. Nothing in RAM is trusted.
   - **No peripheral gets a hardware reset**, so audit every boot init:
     SIO, CTC, V9958, IOC, HID, IOC-FAT and the console. Each must
     program its device fully from any state.
     - The IOC uses its existing `RESET` command and the link-sync
       handshake.
     - The audit list goes in the record, with a fix for each init that
       assumed a power-on state.
   - Users:
     - the monitor's `B` (reboot) command;
     - the shell's `reboot` built-in (in `user/shell/builtin.c`, added to
       `help`);
     - **Ctrl-Alt-Esc is not KonaOS's:** the I/O controller intercepts
       it and pulls the Z80 reset line (a hard reset, as the reset
       button). It is the way out of any hung program, including one not
       reading the keyboard, so KonaOS adds no key combination of its own.
       Document it (architecture boot section, `docs/boot.md`,
       `docs/monitor.md`). The controller itself is not reset, so the IOC
       driver's link bring-up must recover from any controller state:
       that is part of the requirement-6 init audit.

## Tests

- **Host:** the manifest flag; the acquire and release rules (busy, not
  supported); the reset operations' numbers.
- **Simulator replay:**
  - a test program binds `/dev/video` exclusively, sets a graphics mode
    through `diag_io_out`, and exits: the shell prompt comes back in text
    mode on a clean screen (check the VDP registers and VRAM);
  - a second exclusive bind is refused with `EBUSY`; release then
    acquire works;
  - a program that pokes the VDP without the handle and exits: the
    launcher's console reset restores text mode;
  - `reboot` from the shell, 20 times in a row, each reaching the prompt;
  - one reboot during a file transfer and one after a graphics-mode exit
    both reach the prompt, and the card still reads.

## Owner checklist (hardware)

1. Run the graphics test program, then exit: you get a clean text
   prompt.
2. `reboot` 10 times; monitor `B` once; Ctrl-Alt-Esc once at the shell
   prompt. Each reaches
   the prompt, and `ls /` reads the card afterwards.
3. Ctrl-Alt-Esc while `cp` is copying a large file: the system boots and
   the card still mounts.

## Constraints

- Fixed core unchanged. Report the cold-half, driver hot and common
  ledgers.
- Record: `docs/validation/<date>-m11-device-release-reboot.md`, with
  the init audit.

## Working loop (targeted only)

Put this package's tests in `tests/test_device_release.py` (host and replay)`. While developing, run only:

```sh
python3 -m unittest tests.test_device_release
make
```

## Validation (once, the last step; `make check` takes about 25 minutes)

```sh
make clean && make check     # the last step
make console-serial-selftest # the serial console's reset path, once
git diff --check
```

No image matrix.

**Known failures (accept these two, nothing else):**
`tests.test_hid` and `tests.test_v9958` `test_system_file_and_boot_order`
fail on the production store list (49d's far-data files). Package 56
fixes them; do not touch them here.
