> **DRAFT. Not dispatched.** Runs after 54. Ends M12 (diagnostics) and
> native completion.

# Task

`diag.exe`'s device families (`timer irq serial video hid ioc storage
sound`, far segments 2-4), with **benchmarks of the SD card, the IOC bulk
lane and the command lane**. User-land only: typed protocols, `list`, the
diagnostic calls, `SYS_DIAG_ENUM` and `kos/timer.h`.

Read: the 53 and 54 records; the architecture's diagnostic-suite section;
`abi/kos/protocol.h`; and the `fs_selftest` family (the storage tests
reuse its checks).

## Rules for every family

- **Non-destructive by default.**
  - Only `diag storage --destructive` may write outside its scratch
    directory, and only `diag all` never passes it. In this package even
    that option only enables the raw-media write test, which is SKIP
    until a BLOCK driver exists.
- **SKIP cases:**
  - a device that is absent (bind returns `ENOENT`/`ENODEV`);
  - a test that needs an operator, when it runs under `diag all`.
- **Interactive tests** run only when the family is named directly. They
  ask the operator with `y/n` lines read by `getchar`.
- **Bounded:** every wait has a time limit, measured with `timer_now`.
  If `/dev/timer` is absent, timed tests are SKIP.
- **Benchmarks** pass when the data is correct. Their figures go in the
  detail field, for example `storage.read: PASS 65536 B 14.2 KiB/s`.
  There is no speed threshold. Rates are bytes × 1,000,000 /
  `timer_us(elapsed)`, printed with one decimal.

## Families

0. **timer:**
   - The INFO values are 390,625 and 250.
   - `now` is monotonic over 1,000 reads.
   - `timer_wait_us(1000000)` elapses between 1.000 and 1.010 s on the
     timer itself.
   - Run directly: count 10 s on screen for a stopwatch.
1. **irq:**
   - List the kind-2 sources: every source with an owner is enabled, and
     every enabled source has an owner. `IRQ_CTC2` is owned by the timer
     driver.
   - **Delivery:** over 1 s, the timer advances by 156 ± 2 ticks
     (`now / 250`).
   - Kind 4 read before and after: unexpected and unclaimed do not grow
     (FAIL if they do).
2. **serial:**
   - Bind `/dev/serial/0` (absent → SKIP).
   - `WRITE` the line `diag serial: test line` and check the count.
   - `POLL` returns within its bound.
   - `READ` with nothing pending returns 0 or `EAGAIN`.
   - When the console is the serial driver, the line appears in the
     transcript; the smoke test checks for it.
3. **video:**
   - Bind `/dev/video` **exclusively** (absent → SKIP). The driver restores
     the text screen on release (51b).
   - Using `WRITE`/`PUTC`: write all 256 font cells in rows of 32, then
     a test grid: a frame of `+-|` around 80×24 positions.
   - Under `diag all` it passes on protocol success alone.
   - Run directly, it also asks `pattern correct? (y/n)`.
4. **hid:**
   - Bind `/dev/input/keyboard` (absent → SKIP).
   - `READY` succeeds.
   - Run directly: `press keys, ESC to end`. It echoes each event's code
     and character until ESC, or 30 seconds, then asks `keys correct?
     (y/n)`.
   - Under `diag all`: SKIP (operator).
5. **ioc** (model: the Zephyr-80 `BULK.COM` and `SDBENCH.COM`,
   `../Zephyr-80/Code/HOST/Utilities/src/ioc_bulk.asm`, `ioc_sdbench.asm`,
   `sdbench_file.inc`). Read their header comments first; they explain
   the method.
   - Bind `/dev/ioc` (absent → SKIP). `STATUS` and `READY` succeed.
   - **Command lane:** one `PING` (`IOC_CMD_PING`) checks the echo bytes,
     the reply class and the length. Benchmark: 100 `PING` round trips.
   - **Bulk lane, isolated from the card:** `CMD_BULK_TEST` (04h; add it
     and its reply `84h` to `drivers/include/ioc_protocol.h` from
     `ioc_bulk.asm`).
     - The controller generates a `00 01 … FF` ramp, received with
       `KIOC_OP_BULK_READ`.
     - Every byte is verified (a shifted or dropped byte FAILs).
     - Run 64 transfers each of 128, 256 and 512 bytes.
   - Protocol calls only; never touch the driver's transport state.
6. **storage**, under `/fs/DIAG` (no card → SKIP):
   - the `fs_selftest` checks for create, write, seek, read back, stat,
     rename and unlink;
   - a cache check: write, `sync`, close, reopen, compare;
   - **write:** a 256 KiB file in 512-byte calls, then `sync`, timed
     including the sync;
   - **sequential read** of that file at 128, 256 and 512 bytes per call,
     with the bytes compared. The controller's cache is 8 × 512 bytes
     (4 KiB) and the file is far larger, so this measures the card plus
     the lane;
   - **cache-hit read:** re-read one 2 KiB window of the file for 128
     passes (SDBENCH `/C`). After the first pass it is served from the
     controller cache, so this measures the controller and the lane
     without the card;
   - **raw card read** (non-destructive): 128 single-sector reads with
     `CMD_SD_READ_BULK` (05h) through `/dev/ioc`, with no filesystem;
   - **raw card write** only with `diag storage --destructive`, never under
     `diag all`:
     - it asks first with `this overwrites LBA 00100000h on the card -
       test cards only (y/n)`;
     - then 128 writes with `CMD_SD_WRITE_BULK` (07h) at SDBENCH's LBA,
       followed by one read-back verify;
   - `/fs/DIAG` is removed at the end, even after a FAIL.
   - Copy each command constant and frame layout from SDBENCH.
6b. **Timing report** for every benchmark row, not only the mean
   (SDBENCH: "a streamer cares what the worst one costs"):
   - count, bytes, total, rate in KiB/s;
   - per-call min, mean and max in µs;
   - an 8-bucket latency histogram (bucket edges 0.25, 0.5, 1, 2, 4, 8 and
     16 ms, then the rest), printed as counts.

   Each call is timed with `timer_now` (25.6 µs resolution).
7. **sound:**
   - The SN76489 chips are write-only, so presence cannot be detected.
   - Run directly: play a 440 Hz tone for 1 s on each of the four chips
     in turn, through `diag_io_out` on the card's ports, then silence all
     four (timed with the timer). Ask `four tones heard? (y/n)`.
   - Under `diag all`: SKIP (operator).
   - Take the port addresses from the hardware project's working code
     (`../Zephyr-80/Code`). Name the file in the record, and add them to
     `platform/zephyr80/public/hardware.h`.
   - Always silence the chips on exit, including after a FAIL.

## Tests

- **Simulator replay** of production, at the shell:
  - `diag all` with a card and without one: final line `PASS`, with the
    SKIP counts as expected;
  - `diag storage`, `irq` and `timer`; well-formed benchmark lines;
    `/fs/DIAG` absent afterwards.
- `tools/serial_smoke.py --mode diag`: sends `diag all` at the shell
  prompt and checks the final line.
- **Host:** that `diag all` never passes `--destructive`; the
  family-to-segment table.

## Owner checklist (hardware; put it in the record)

Run it for each of: V9958+HID production, serial production.
1. `diag all` with a card, then without one → `diag: PASS`.
2. `diag video` (pattern), `diag hid` (keys), `diag sound` (four tones):
   answer each question.
3. `diag storage` and `diag ioc` → PASS. Record every benchmark row
   (rate, min/mean/max, histogram), and compare with SDBENCH/BULK under
   CP/M on the same card. Then run `diag storage --destructive` on a test
   card only.
4. `diag timer`: compare the 10-second count with a stopwatch.
5. `monitor`, then `Q`; then `diag all` again (no leak, same result).

## Constraints

- No kernel or driver change. Only the store and `hardware.h` constants
  change.
- Record: `docs/validation/<date>-m12-diag-devices.md`, with the owner
  checklist and the final ledgers. This record closes native completion.

## Validation (user-land only: no `make clean && make check`)

Put the tests in `tests/test_diag.py` and `tests/test_diag_sim.py` (extend 54's). Use these same commands while developing,
and once at the end:

```sh
make                                              # production builds: store fits, mapcheck passes
python3 -m unittest tests.test_diag tests.test_diag_sim
python3 -m unittest tests.test_console_acceptance # production still boots
git diff --check
```

Run the full check only if this package had to touch the SDK, the
kernel or a driver; if so, report why.
