# Task

Apply the Mn-1 retention rule (`work/00-SUPERVISOR.md`, "Milestone retention
and compatibility") at the start of M9. Retire every M1-M7 acceptance image,
build configuration, smoke mode and production hook. Move the coverage of
mechanisms that are still part of the system onto the current boot path,
organized by subsystem. Only M8 (Mn-1) and M9 acceptance machinery remain.

## Context

Dispatch after package 25 corrections 01 and 02 are accepted, and before 25b.
Read `work/00-WORKER.md`, `work/00-SUPERVISOR.md` (retention section),
`work/M9-REFERENCE.md` ("No backward compatibility"), the Makefile, `kernel/main.c`,
`kernel/module/embedded.c`, `tools/{mapcheck,serial_smoke,pack_image}.py`, and
`tests/`.

Inventory of the retired configurations (verify it; the tree is authoritative):

```text
make targets  syscall-selftest irq-selftest m3-selftest m4-loader-selftest
              m4-selftest m4-placement-selftest m4-failure-selftest
              m5-selftest m5-corrupt-selftest m6-selftest m6-failure-selftest
              m7-selftest   (+ smoke-hardware-{selftest,irq,m3,m4,m4-failure,
              m5,m5-corrupt,m6,m6-failure,m7} and their serial_smoke modes)
flags/hooks   ZOS_ROMFS_BOOT=0 embedded-catalog boot (embedded.c,
              module_catalog_load_all, fixture catalogs), ZOS_MONITOR_BOOT=0,
              ZOS_M4_SIO_IRQ + zos_target_test_irq_hold_*, ZOS_M4_ARENA_*,
              the legacy fixed-arena geometry (ZOS_DRIVER_ARENA_DERIVED=0
              constants, variant memory include, mapcheck "legacy" mode)
tests         tests/target/m1..m7, tests/test_m1.py, test_m3*.py, test_m4*.py,
              test_m6_sim.py, test_m7_sim.py, milestone-specific fixtures in
              tests/modules (m4_*, sio-fail, sio-irq) and tests/m5..m7 manifests
```

Kept, because it is subsystem-owned rather than milestone-owned:
- host tests `test_zmod`, `test_zex`, `test_romfs`, `test_pack_image`,
  `test_monitor`, `test_source_layout`, `test_ioc*`, `test_hid*`,
  `test_v9958*`, `test_docs_evidence`;
- all M8 and M9 acceptance images and smoke modes;
- `ZOS_TARGET_TEST_BUILD` (the single test seam);
- `ZOS_SMOKE_HOST_SYNC` (a bench tool, not milestone history).

## Requirements

- **Migrate mechanism coverage first.** Keep it subsystem-owned under
  `tests/target/<subsystem>/` and `tests/test_<subsystem>*.py`, running on the
  current production boot path (ROMFS/VFS boot, derived arena). Prefer folding
  each case into one or two current acceptance images over one image per
  mechanism.

  | Mechanism | Was proven by | Must be covered by |
  |---|---|---|
  | `RST 30h` gate round trip, argument windows, page zero | M1, M6 | syscall/process tests on a ZEX (extend `zextest`) |
  | IRQ delivery in modes 10 and 11, unclaimed source, claim/release, a module claiming a source across load | M2, M4 IRQ | `tests/target/irq/` using the test-owned CTC0 helper |
  | Loader validation, relocation, failed-init rollback (devices, IRQs) | M4, M4 failure | ZMOD fixtures loaded from `/SYSTEM` in a current acceptance image, plus host relocation at two bases in `test_zmod` |
  | Arena exhaustion | M4 placement, M8 fb-arena | keep `m8-fb-arena` |
  | ROMFS corrupt-image detection and panic | M5 corrupt | `tests/target/romfs/` corrupt-store image on the current boot path |
  | ZEX validation failures, raw-return `EFAULT`, rollback | M6 failure | `tests/target/process/` |
  | Monitor launch and session | M7 | the M8 monitor session tests (already current) |
  | Device registry and console binding | M3 | M8 tests (already current); add host cases if any branch is uncovered |

  For every row, record in the handoff the exact test name that now covers
  it. A mechanism with no current coverage is a stop-and-report finding.
- **Delete the retired machinery completely:** the make targets and their
  build directories, smoke-hardware targets and `serial_smoke` modes,
  milestone flags, the embedded-catalog boot path and fixture catalogs, the
  `ZOS_MONITOR_BOOT=0` and `ZOS_M4_SIO_IRQ` paths in `kernel/main.c`, the
  hold hooks, the legacy fixed-arena geometry, mapcheck's legacy mode and
  the variant memory include, plus milestone-only fixtures, manifests,
  helpers and tests. Production keeps exactly one boot path: VFS/ROMFS boot
  with the derived arena.
- **Drop transcript baggage.** Remove the retained M0 `HALT` banner line and
  any banner text kept only to match old transcripts. Update the M8 and M9
  expected transcripts accordingly.
- **Correction-01 overlap.** Its "no VFS in `ZOS_ROMFS_BOOT=0` images" check
  becomes moot once those images are gone. Delete the check together with
  the configuration; do not leave a check for a configuration that cannot be
  built.
- **Make the rule mechanical.** Extend `tests/test_source_layout.py` to fail
  if:
  - `tests/target/m<k>/` exists for any `k` other than 8 or 9;
  - a Makefile target `m<k>-*` exists for those `k`;
  - a `ZOS_ROMFS_BOOT`, `ZOS_MONITOR_BOOT` or `ZOS_M4_*` symbol reappears.

  Put the allowed milestone list in one constant, with a comment that it
  moves forward at the start of each milestone.
- **Documentation.** Update `README.md`, `docs/boot.md`, `docs/memory.md`,
  `docs/module-format.md` and `docs/devices.md` so they describe the single
  current boot path and geometry. Historical milestone sections of
  `docs/architecture.md` stay as history, but add one sentence where they
  name retired images, saying the images were retired under the Mn-1 rule
  and naming the current coverage.

## Files

- `Makefile`, `kernel/main.c`, `kernel/module/{embedded.c,loader.c}`, `include/zephyros/module.h`
- `platform/zephyr80/{memory.inc,memory.h}`, `tools/{mapcheck,serial_smoke,pack_image}.py`
- `tests/target/`, `tests/modules/`, `tests/m5..m7`, `tests/test_*.py`
- `README.md`, `docs/{boot,memory,module-format,devices,architecture}.md`

## Constraints

- Delete; do not hide. No `if False`, skip decorators, unused flags or
  commented-out targets.
- Do not change M8 or M9 runtime behavior except for removing the transcript
  baggage above. The production image changes (removed hooks and banner
  line), so hardware must be rerun.
- No new features and no M9 package-26 work.

## Validation

```sh
make clean && make check
make zmod-test romfs-test zex-test monitor-test ioc-test hid-test v9958-test \
     m8-ioc-selftest m8-hid-selftest m8-v9958-selftest m8-console-selftest \
     m8-selftest m8-fallback-selftests m9-vfs-selftest m9-required-mount-selftest \
     <every new subsystem target>
python3 -m unittest discover -s tests -v
git diff --check
make clean && git status --short
```

Report:
- the mechanism-coverage table with the test names;
- the number of make targets, test files and source lines removed;
- the full-suite runtime and test count before and after;
- the `bank7:` numbers before and after.

Hardware: flash production and run `make smoke-hardware-m8 SERIAL_PORT=...`,
plus any migrated IRQ or corrupt-store image that touches hardware-facing
paths. Record `PENDING` if hardware is unavailable.

## Acceptance criteria

- Only M8 and M9 acceptance machinery remains, and a source-layout test
  enforces the window.
- Every mechanism in the coverage table is exercised by a named current test
  on the current boot path.
- Production has a single boot path and a single arena geometry.
- The full suite passes, and the production boot works on hardware or is
  recorded `PENDING`.
