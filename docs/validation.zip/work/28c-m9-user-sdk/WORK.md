# Task

Give user programs a real, self-contained development kit, so a native program
never depends on kernel code or kernel headers. This package delivers three
things:

1. one public native-ABI header set, shared by the kernel and user space,
   which removes today's hand-mirrored copies;
2. a user SDK (`libzos`, a startup object, a minimal C subset, and a generic
   "build a ZEX" rule) that replaces the ad-hoc `user/runtime/`;
3. a `helloworld` sub-project for demo and example programs, starting with
   `hello.zex`.

Every existing ZEX (the monitor and the test programs) moves onto the SDK.
The M10 shell (`user/ZShell/`) will be built only from this SDK, as the
reference for how user programs are made. It is not part of this package.

## Context

Dispatch only after package 28b is accepted. 28b defines the startup block at
`0080h` and `zos_exec(path, args)`, which this SDK consumes. Read
`work/00-WORKER.md` (including "Working efficiently"), architecture sections
3.1, 26.3-26.6, 32.25-32.26 and 32.39, `docs/{abi,zex-format}.md`,
`user/runtime/`, `user/monitor/`, `tools/zexpack.py`, the ZEX rules in the
`Makefile`, and `tests/target/{process,m9}/`. There is no
backward-compatibility requirement.

Current state:
- **The ABI is defined twice.** The kernel uses
  `include/zephyros/{syscall,errno,fs}.h`. `user/runtime/zex_runtime.h` and
  `zex_fs_runtime.h` hand-mirror the syscall numbers, error codes and path
  limits ("pinned by tests").
- **The boundary is porous.** `user/runtime/zos_fs.c` includes
  `zephyros/fs.h` and `zephyros/syscall.h` from `include/zephyros/`, the same
  directory as `driver.h`, `device.h` and `vfs.h` (module and kernel
  interfaces).
- **No scaffolding.** Every ZEX has hand-written Makefile rules
  (`MONITOR_USER_CFLAGS`, `ZEX_TEST_BUILD`, and so on), a manifest JSON with
  hand-entered `image_size`/`bss_size`, and its own entry `.asm`.
  Monitor-only helpers (`hexfmt`, `hexdump`, `status`) sit in the shared
  runtime.
- `sdar` (the SDCC archiver) is available, and there is no C library
  (`--nostdinc`).

## Layout (pinned)

```text
abi/zos/              public native ABI: the ONLY headers shared by kernel and user space
    syscall.h         syscall numbers, argument blocks (incl. SYS_EXEC args), windows
    errno.h           syscall-visible ZOS_E* codes
    fs.h              limits, ZFS_O_*/SEEK_*, zfs_stat, zfs_dirent
    process.h         startup block v1 (0080h), getinfo record, exit/exec constants
    diag.h            recovery/diagnostic syscall blocks (documented as recovery-only)
user/sdk/
    include/          zos.h (umbrella), zos/console.h, zos/fs.h, zos/process.h,
                      zos/diag.h, zlibc/string.h, zlibc/fmt.h
    src/              gate stubs, C wrappers, crt0, zlibc
    zex.mk            the generic ZEX build rule
    template/         a copyable minimal program (hello-sized)
user/helloworld/      demo/example programs; first: hello.c -> hello.zex
user/monitor/         ported onto the SDK
user/ZShell/          reserved for M10 (not created here)
docs/sdk.md           how user programs are made
```

## Requirements

- **Public ABI (`abi/zos/`), one source of truth.**
  - Move the syscall-visible ABI out of `include/zephyros/{syscall,errno,fs}.h`
    and the 28b startup-block definitions into `abi/zos/`.
  - The kernel and modules include them as `"zos/…"`, using `-I abi` in
    kernel and module flags.
  - Errors that are never syscall-visible (for example the IOC transport
    codes `EPROTO`/`ECRC`/`EBADSEQ`, and any other internal-only code;
    verify against `docs/abi.md`) stay in a kernel/module header under
    `include/zephyros/`.
  - Delete every mirror in user code. Keep the `_Static_assert` layout pins
    in the ABI headers.
  - Kernel bytes must not change: prove the production image hash is
    identical to 28b's accepted image. This is a header move, so byte
    identity is the validation technique here.
- **Mechanical boundary.** User builds get exactly `-I abi -I user/sdk/include`
  plus the program's own directory, never `-I include` or `-I platform`. A
  source-layout test fails if anything under `user/` (or a ZEX test program)
  includes a `zephyros/…` header, a `kernel/…` path, or a platform header, or
  if a user build rule names `include/` or `platform/`.
- **`libzos` (`user/sdk/src`).**
  - Consolidate the existing stubs and wrappers into one library: exit,
    console write/read/poll, getinfo, all `FS_*`, `zos_exec(path, args)`,
    and the diagnostic calls.
  - Keep the return convention (a value or the negated error) and the
    low-window argument-block rule (`0100h-1FFFh`).
  - Build it as an `sdar` archive (`libzos.lib`), one object per independent
    function group, so a program links only what it uses. `hello.zex` must
    not contain FS or diagnostic code; show this with its size.
  - SDCC calling conventions stay private; the documented ABI is the
    `RST 30h` register contract plus these C prototypes.
- **`crt0`.**
  - Entry at the ZEX entry point.
  - Takes HL = startup block (from 28b) and runs the 28b whitespace and
    double-quote splitter into a bounded `argv` (at most 16 entries, stored
    in program BSS).
  - Calls `int main(int argc, char **argv)`; on return, calls `SYS_EXIT`
    with the low 16 bits of the result.
  - Places the shared low-window scratch so it always sits inside
    `0100h-1FFFh` (crt0 and libzos are linked first).
  - Programs never write entry assembly.
- **`zlibc`, minimal and on demand.**
  - `string.h`: `strlen`, `strcmp`, `strncmp`, `strchr`, `strrchr`,
    `memcpy`, `memmove`, `memset`, `memcmp`, plus bounded copy and
    concatenation helpers.
  - `fmt.h`: unsigned and signed 16/32-bit decimal and hex formatting into a
    buffer, plus a small `zos_printf`/`zos_snprintf` supporting `%s %c %d %u
    %x %ld %lu %lx %%` and width/zero-pad.
  - Each in its own archive member. No `malloc`, no stdio streams, no float.
- **Generic build rule (`user/sdk/zex.mk`).** One line per program, for
  example `$(eval $(call zex_program,hello,user/helloworld,hello.c,STACK=256))`.
  - It compiles the sources with the user flags and links crt0, the program
    objects and `libzos.lib`.
  - It **generates the ZEX manifest**: `image_size` and `bss_size` come from
    the link map, and the stack size and scratch symbol come from rule
    options or SDK defaults. There is no hand-written manifest JSON and no
    hand-entered sizes.
  - It runs `zexpack` validation and puts the output in
    `build/user/<name>.zex`.
  - It works with parallel make (no shared intermediate filenames between
    programs).
  - Retire every per-program ZEX rule and hand-written manifest it replaces.
- **Port every ZEX onto the SDK:**
  - `user/monitor/` (its private helpers `hexfmt`/`hexdump`/`status` move into
    the monitor, or into `zlibc/fmt` where they are generic; delete
    `user/runtime/`);
  - `zextest`, `fstest`, `fstest_l` and the exec children (`fschild`,
    `fsdeep`, `fsraw`, plus 28b's argument test program).

  Behavior must be unchanged: every simulator suite that runs these programs
  passes, and the monitor still answers `r` and `h`. The monitor's bytes may
  change.
- **`user/helloworld/`.**
  - Its own `Makefile` fragment, one `zex_program` line per demo, and a
    `README.md` saying it holds demos and examples.
  - First program: `hello.c` prints `Hello, ZephyrOS!`, then one line per
    `argv` entry, then exits 0.
  - Not in the production `/SYSTEM` (architecture 32.14 keeps that minimal).
    Add `make helloworld-image`: a separate build directory using 28b's
    setting `ZOS_BOOT_PROGRAM=/SYSTEM/hello.zex`, with `hello.zex` added to
    that image's recovery manifest. This doubles as the end-to-end proof that
    a user program needs no kernel change to boot.
  - A simulator test boots that image and checks the transcript.
- **`user/sdk/template/`:** a minimal copyable program (source plus its one
  build line), so a new program means "copy the template, add one line".
- **`docs/sdk.md`, the canonical "how user programs are made":**
  - layout and include rules;
  - the `libzos` API reference;
  - crt0, `argv` and exit semantics;
  - `zlibc` contents;
  - `zex_program` options;
  - memory layout (0100h image, BSS, stack, low-window scratch);
  - the boundary test;
  - which library member pulls in what.

  State that `user/ZShell/` (M10) must be built only from the SDK and serves
  as its reference implementation. Update `docs/{abi,zex-format}.md`
  references and architecture 3.1 (directory ownership: `abi/`, `user/sdk/`,
  `user/helloworld/`, `user/ZShell/`).

## Constraints

- No kernel behavior change and no new syscall. The production kernel and
  module bytes are identical to 28b's.
- No shell, no `malloc`, no stdio, no floating point, no POSIX emulation.
- Do not keep `user/runtime/` or any mirrored ABI header beside the new
  layout.

## Validation

At the `00-WORKER.md` efficiency defaults, run one formal batch in the
background:

```sh
make clean && make check
make monitor-test zex-test m9-fs-selftest m9-exec-selftest helloworld-image
python3 -m unittest tests.test_monitor tests.test_zex tests.test_m9_fs tests.test_m9_exec tests.test_m9_exec_sim tests.test_syscall_sim tests.test_source_layout tests.test_sdk -v
git diff --check
```

`tests/test_sdk.py` is new. It checks the library members, the
`hello.zex` contents (no FS or diagnostic symbols), manifest generation from
the map, crt0 `argv` and exit behavior in the simulator, and the boundary
rules.

Report:
- the production hash compared with 28b's (must be identical);
- the `bank7:`/`common:` lines (unchanged);
- `hello.zex` and `monitor.zex` sizes before and after;
- the formal run's wall-clock time;
- every skip in the listed suites, with its reason.

Hardware: flash the helloworld image and capture its serial transcript. Then
flash production, run `make smoke-hardware`, and have the operator check that
the ported monitor answers `r` and `h` on the V9958. Record `PENDING` if
hardware is unavailable.

## Acceptance criteria

- `abi/zos/` is the single source of the native ABI for the kernel and user
  space, with no mirrors left. Production kernel and module bytes are
  unchanged.
- No user-side source or build rule can reach `include/zephyros/`, `kernel/`
  or `platform/`, and a test enforces it.
- Every ZEX is built with one `zex_program` line from the SDK, with
  generated manifests, and `user/runtime/` is gone.
- `hello.zex` boots on its own image through `ZOS_BOOT_PROGRAM` and prints
  its greeting and arguments, in the simulator and on hardware or recorded
  `PENDING`.
- `docs/sdk.md` lets someone write a new program by copying the template and
  adding one line.
