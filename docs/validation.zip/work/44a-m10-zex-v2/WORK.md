# Task

M10 step 10, part 1 (architecture 36.24). **ZEX v2 replaces ZEX v1**
(36.18):

- the v2 packer and the v2 loader;
- data segments as process-owned xmem objects;
- `SYS_SEG_INFO`;
- a loader that zeroes only BSS and the startup block (36.19);
- every first-party program converted, and v1 deleted.

Far-code segments are package 44b. Here every program is a v2 image with
no far code.

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md` (decisions 1, 2 and 6);
- architecture 36.18 and 36.19;
- `docs/zex-format.md`, `tools/zexpack.py`, `tools/zexmanifest.py`;
- `kernel/process/exec.c`;
- the SDK build (`user/sdk/zex.mk`);
- the package-43 record.

**Before starting:** if 43's record contradicts this contract, stop and
report.

## Requirements

1. **Format and packer.** `tools/zexpack.py` produces v2 only:
   - a header with every count and size needed for one up-front
     feasibility check;
   - the primary image at `0100h`;
   - a segment table (id, kind, image size, BSS size, payload offset);
   - 32-bit geometry.

   The packer validates everything it can. Document the format in
   `docs/zex-format.md`, replacing v1.
2. **Loader.** v2 only, in the cold nucleus.
   - One feasibility check from the header.
   - It allocates the primary bank, and the `DATA` segments as xmem
     objects.
   - It copies payloads, zeroes BSS, and builds the startup block and page
     zero.
   - It rolls back completely on failure.
   - **It removes the whole-bank clear at exec** (36.19).
3. **`SYS_SEG_INFO(segment)`** returns the size, kind and load state.
   Document it in `docs/abi.md`.
4. **Conversion and deletion.**
   - Convert every first-party program, tool and test image to v2,
     including the monitor, the SDK demos and the programs in every
     current image (subsystem `zextest` fixtures, fs, ns, ipc, console
     integration, helloworld).
   - Delete the v1 parser, the packer path and the documentation.
   - Add a grep gate showing that no v1 code remains.

## Constraints

- No far-code support (44b).
- **Tests:** delete the v1-format tests. Add packer tests and loader
  outcome tests: malformed header, a container larger than 64 KiB,
  rollback, BSS zeroed, the bank not cleared.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-zex-v2.md`.

## Validation

```sh
make clean && make check
make subsystem-selftest fs-selftest ns-selftest ipc-selftest \
     console-integration-selftest xmem-selftest helloworld-image
git diff --check
```

Hardware (owner): `make smoke-hardware`, and nested exec from the
monitor.

## Acceptance criteria

- v2 is the only executable format, and every first-party program runs as
  v2.
- The loader zeroes only BSS and the startup block.
- The ledgers are within 36.20.
