# 44a-m10-zex-v2 progress

## Baseline (2026-10-11)

- Tree at `43f8ffa`, clean `git status`.
- `make clean && make` green, 37 s wall, reproducible hash
  `8886f15494383474c4214d0fb45e0668b115f088f1a2d730f83ad4c750e3a57f`.
- Ledgers: fixed 8335+2+768 (room 7279) | cold 20346 `AF7Ah`, data 1443
  `B000h` | hot 21846/32768 | boot/bulk 2170/24576 | common 2358/3072.
- 43's record does not contradict the 44a contract (it expects 44b to
  extend `xmem-selftest`; 44a adds its loader outcomes to the subsystem
  acceptance image, whose store and process selftest already exist).

## Design decisions (contract-driven, architecture 36.18/36.19)

- **Container.** Fixed 36-byte header ("ZEX2", format 2, abi 1, flags 0,
  reserved0/1 zero, header_size 36, segment_count, reserved, primary
  image/bss/entry/stack, `segment_table_offset` u32, `file_size` u32,
  `primary_payload_offset` u32, `total_segment_slots` u16, reserved2).
  Then primary payload at 0100h, the segment table
  (count * 16-byte rows: id, kind, image_size, bss_size, reserved, u32
  payload_offset, u32 reserved), then payloads. All offsets 32-bit, so a
  container may exceed 64 KiB.
- **Kinds:** `FAR_CODE` = 1 (44b), `DATA` = 2. 44a refuses FAR_CODE in
  both packer and loader with `ZEX_EXEC_ERR_SEG_KIND`; no far code exists
  in this package.
- **Feasibility.** One up-front header check: geometry (image/BSS/stack
  inside 0100h-E000h), `segment_count <= 8`,
  `total_segment_slots <= 20` (five non-primary banks x four
  non-aperture data slots), table and primary payload inside
  `file_size`, `file_size` equal to the FILE metadata size. Segment rows
  are then validated (protective bounds) before any allocation.
- **DATA segments are xmem objects** of type `ZOS_XMEM_TYPE_SEGMENT`
  owned by the child: the loader allocates them with the package-43 bank
  map before it touches the bank, registers them in the xmem table with
  their container id, copies payloads through the same gates the xmem
  copies use (window for slots 3-6, mode-10 gate for slots 0-2; BSS
  zeroed through a zeroed staging write on the window path because the
  window gate has no ZERO op), zeroes their BSS, and rolls back through
  `process_slot_release()` (which already releases pid-owned objects).
- **`SYS_SEG_INFO(0x26)`** returns an 8-byte record
  {size = image+bss, kind, state = LOADED, handle = xmem handle for
  DATA / 0 otherwise, reserved}; the caller then reads/writes the
  segment through `SYS_XMEM_READ/WRITE`. `SYS_XMEM_FREE` refuses a
  loader segment (released only at exit); `SYS_XMEM_INFO` reports the
  SEGMENT type. `SYS_SEG_MAP` is 44b.
- **36.19:** the whole-bank clear is gone. The loader writes only the
  page-zero vector at 0030h, the image, BSS (primary + segments) and the
  startup block. Bank contents outside those are undefined.
- **Packer manifest (v2):** `"format": "zex-v2"`, primary fields as v1,
  optional `"segments": [{"id", "kind": "DATA", "input": <raw payload
  file>, "bss_size"}]`; the packer derives image_size from the payload
  file, lays out the container, validates everything and writes the same
  deterministic report. `zexmanifest.py` stays primary-only in 44a
  (44b adds the far-code/area tooling); the packer's segment path is
  driven by the subsystem test manifests.
- **Programs.** Every program and test image converts by construction
  (the one `zex_program` rule calls the v2 manifest/packer); v1 parser,
  packer path, docs and tests are deleted, and a grep gate in
  `tests/test_source_layout.py` pins that `ZEX1` / `zex-v1` cannot come
  back.
- **Loader outcomes (target, subsystem image):** the malformed fixture
  set regenerates for v2 with the new boundaries; new SDK programs
  `zex2probe.zex` (BSS zeroed + bank-not-cleared marker written by the
  kernel test through `zos_bank_copy`) and `zex2seg.zex` (one DATA
  segment: contents, handle, BSS zero, FREE refusal) plus `zex2big.zex`
  (two 32 KiB segments, container > 64 KiB); the rollback case execs
  `zex2seg.zex` with banks 1-5 reserved so its segment allocation fails
  and the table/banks must be clean.

## Implementation log

- **Format + tools.** `include/zephyros/zex.h` is v2 only (36-byte header,
  16-byte segment rows, kinds, limits, four new result codes);
  `tools/zexpack.py` rewritten (v2 packer/validator/dumper, 32-bit
  geometry, segment layout, report with the table); `tools/zexmanifest.py`
  emits `zex-v2` and merges `--segments FILE`; `user/sdk/zex.mk` gains the
  `SEGMENTS=` option (prerequisite + `--segments`).
- **Loader.** `kernel/process/exec.c`: one up-front header feasibility
  check, table read/validation, child-bank construction with the
  page-zero vector + image + BSS only (whole-bank clear removed), DATA
  segments allocated as xmem objects before the bank is touched, payload
  copy and BSS zero through the window/gate split, full rollback through
  `process_slot_release()`.
- **Segments.** `kernel/syscall/xmem.c`: `ZOS_XMEM_TYPE_SEGMENT`
  objects, `zos_xmem_segment_alloc()`, `SYS_SEG_INFO` (26h), FREE
  refusal; `abi/zos/seg.h` + `SYS_SEG_INFO` pinned in `docs/abi.md`
  section 15; SDK `zos_seg_info` (`user/sdk/src/seg.c`, `seg.h`,
  scratch-union member, `zos.h`).
- **Programs/tests.** Every program converts by construction (one rule);
  `tests/subsys/gen_zex_fixtures.py` regenerates the malformed set for
  the v2 boundaries (24 fixtures) and the subsystem manifest carries
  them plus the new outcome programs; `tests/subsys/gen_zex2_segments.py`
  writes the DATA payloads; `zex2probe`/`zex2seg`/`zex2big` (SDK
  programs) + `process_test.c` step 8 cover BSS-zeroed, bank-not-cleared,
  segment wiring, >64-KiB container and segment-allocation rollback;
  `tests/test_zex.py` rewritten for v2 (44 tests) and
  `tests/test_source_layout.py` gained the no-v1-code grep gate.
- **Docs.** `docs/zex-format.md` rewritten for v2; `docs/abi.md` sections
  11/14/15 updated; `docs/sdk.md` (SEGMENTS, member table, seg wrapper);
  README M6/M9 notes; monitor/launch/asm/comment v1 references updated.
- The simulator replay of the subsystem image shows all new markers
  (`zex2probe: OK`, `zex2seg: OK` twice, `zex2big: OK`, `zex2 BSS/bank
  OK`, `zex2 segment OK`, `zex2 big container OK`, `zex2 rollback OK`)
  and `process selftest: OK`.

## Final validation (2026-10-11, run once, on the frozen tree)

- `make clean && make check`: reproducible rebuild
  `d1ed3ecfd641529991941d27753d0bd7774918117239b953bc400a2f243ff949`;
  559 host tests OK (99 skipped = image-dependent tests, run below);
  `mapcheck: OK (18 areas, 343 symbols)`.  One pinned artifact had to
  move with the format: `tests/test_console_acceptance.py`'s
  `MONITOR_SIZE`/`MONITOR_SHA256` (4961 -> 4977 bytes, v2 header growth).
- `make subsystem-selftest`: the image plus `test_subsys_sim.py` and
  `test_romfs_sim.py` green; the replay's process-selftest group shows
  `zex2probe: OK`, `zex2seg: OK`, `zex2big: OK`, the four
  `process selftest: zex2 ... OK` lines and `process selftest: OK`.
- `make fs-selftest ns-selftest ipc-selftest
  console-integration-selftest xmem-selftest helloworld-image`: all
  green (the console-integration replay ran 40 tests).
- `git diff --check`: clean.
- Ledgers: fixed 8335+2+768 (room 7279) | cold code 22943 `B99Fh`, data
  1655 `BA00h` (room 8073) | hot 21846/32768 | boot/bulk 2170/24576 |
  common 2358/3072.  Bytes added: `process_exec.rel` +1865 code / +212
  data, `xmem.rel` +732 code.
- Report: `docs/validation/2026-10-11-m10-zex-v2.md`.
- Hardware: PENDING (owner): `make smoke-hardware-subsystem`, image
  `eac8e3f2…`, plus a nested exec from the monitor.

## Status

- [x] Baseline recorded; 43 record reviewed.
- [x] Implementation (format, tools, loader, segments, syscall, conversion, tests, docs, grep gate).
- [x] Validation and report.
- Not committed: owner instruction (leave the tree uncommitted).
