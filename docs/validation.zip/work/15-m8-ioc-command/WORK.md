# Task

Implement the resident `ioc.zmod` command/status transport over SIO1/B, using
the deployed MCU's exact packet, synchronization, handshake, timing, and
recovery behavior. Register a partial but honest `ZDEV_IOC` interface providing
command and semantic status capabilities; bulk is added by the next package.

## Context

Start only after package 14 is reviewed and accepted. Read
`work/00-WORKER.md`, architecture sections 30.3, 30.6-30.8, and all IOC material
in `work/M8-REFERENCE.md`. Inspect the referenced Zephyr-80 sources directly
before writing the driver. They are read-only reference code at the pinned
commit, never a dependency. IOC firmware modification is forbidden.

Define `struct zioc_frame` as native TYPE, STATUS, DATA-length, and 26 DATA
bytes; sequence and wire CRC remain driver-private. `struct zioc_ops` has the
architecture's `command`, `bulk_read`, `bulk_write`, and `status` order; the two
bulk pointers are null and their capability bits absent in this stage.

## Requirements

- Add declarative SIO1 ports and all verified command-lane register/status,
  packet, timeout, marker-scan, FIFO-depth, link-level, and HID-doorbell
  constants to paired platform headers. Do not place sequences or routines in
  `platform/`.
- Add `include/zephyros/ioc.h` with the class API, 26-byte maximum, semantic
  status (`ZIOC_STATUS_HID_PENDING`), transport errors, and stable packed/layout
  assertions. Keep MCU command numbers needed by consumers in a private driver
  protocol header, not in the general device API.
- Build `drivers/ioc/` as a relocatable ABI-v2 ZMOD. Keep port I/O and the
  timing-critical streaming loops in module-owned assembly; C may own framing,
  CRC, validation, state and the entry descriptor. Add its manifest, packer
  report, ROMFS entry and deterministic boot load after SIO.
- Initialize SIO1/B once: reset, WR1 interrupts/WAIT off, External Sync x1,
  `FFh` fill, RX initially disabled, TX enabled/RTS inactive. Never channel
  reset during an ordinary transaction. On init, perform bounded
  `CMD_LINK_SYNC` retry, re-arming local Hunt each attempt; register `ioc.0`
  only after a CRC-verified matching reply.
- For each command: reject null/malformed/native length above 26 without I/O;
  wait for COMMAND_READY on DCD after Reset External/Status; stamp rolling
  sequence; construct the exact common packet and CRC; preload `A5`, reset EOM,
  assert RTS, stream while interrupts are masked, add two `FFh` trailers,
  release RTS by disabling TX, then arm RX before restoring interrupts.
- RX must clear error status without resetting the channel, drain at most the
  FIFO depth, use Enter Hunt only until first verified sync, scan a bounded
  window for `A5 5A`, capture/validate the complete header/body/CRC and expected
  sequence, clear unused reply DATA, and leave the receiver enabled. Every wait
  is bounded; every error releases RTS and restores exact entry IFF/state.
- Serialize all IOC operations with a module-private foreground busy/state
  guard. Recursive/overlapping use fails with `ZDEV_EBUSY`; do not hold the M2
  registry lock over transport I/O. `status()` samples `/CTSB` via RR0 only in
  this module, resetting the external/status latch first, and maps it to the
  semantic HID_PENDING bit. It returns no raw SIO bits.
- Extend the Z80 simulator with an IOC command-lane peer capable of arbitrary
  leading bytes, delayed readiness/reply, CRC/length/type/sequence faults,
  stalled clocks, and a held HID doorbell. Test exact output packets, one-time
  Hunt, bounded drains, retry/recovery, no reinit between commands, RTS release,
  exact IFF restoration, and rollback when module init/link bring-up fails.
- Add an M8 IOC-command target image that reports through direct early SIO and
  performs repeated PING/echo plus HID semantic-status sampling. It must print
  and validate the returned controller level (`74`/`4Ah` for the pinned
  deployment) and identify the implemented host contract as transport level
  `08h`; do not copy the stale `23`/`07h` status banner from the transport doc.
  Preserve the transcript and hashes in a dated stage validation record;
  physical hardware is the gate for accepting this timing-sensitive package.

## Files

- `include/zephyros/ioc.h`, `platform/zephyr80/hardware.{h,inc}`
- `drivers/ioc/`, `modules/manifests/ioc.json`
- `kernel/main.c`, `recovery/manifest.json`, `Makefile`
- `tests/test_ioc*.py`, `tests/target/m8/`, `tests/z80sim.py`
- `tools/{mapcheck,serial_smoke}.py`, `docs/{devices,architecture}.md`

## Constraints

- Do not edit anything under `/home/kitamura/Documents/Zephyr-80`, especially
  `Code/MCU/IOController/`.
- No SIO1 access outside the IOC module; no interrupts or WAIT/DMA on this lane.
- Do not implement bulk, HID policy, storage, filesystem, or V9958 code here.

## Validation

```sh
make clean
make check
make zmod-test
make ioc-command-test
make m8-ioc-command-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean
```

Flash the named command selftest image and run
`make smoke-hardware-m8-ioc-command SERIAL_PORT=...` at 115200 8N1, starting
capture before reset. If hardware is unavailable, record `PENDING` and stop at
this gate; do not infer transport timing from simulation.

## Acceptance criteria

- `ioc.zmod` registers command/status only after link synchronization, handles
  repeated PINGs without resetting persistent sync, and exposes only semantic
  status to clients.
- Fault injection proves bounded failure, exact cleanup/IFF restoration, and
  SIO fallback after module rollback.
- Host and physical command-lane validation pass with no IOC firmware changes.
