# KonaOS TUI SDK implementation reference

This is the shared implementation contract for work packages 66-73. Read it
with `docs/konaos-tui-sdk-architecture.md` and the assigned `WORK.md`.
The architecture defines the product; this file resolves details that the
worker must not redesign independently.

## Boundary

`libtui` and `libtui_widgets` are user-space SDK libraries. They use only the
published SDK surface and `/dev/console` through the process's standard
handles. They add no syscall, protocol operation, driver endpoint, IOC
command, or V9958 mode. Kernel, driver, firmware, and platform sources are out
of scope.

The ownership rule is:

```text
IOC          keyboard event -> VT100 bytes
console      byte transport and terminal rendering
libtui       VT100 key decoding and logical text-screen state
application  UI policy
```

The libraries do not include kernel or driver-private headers. They include
only public SDK headers. They use no heap and keep no OS-visible global state.

## Source, archives, and program rules

The source owners are pinned:

```text
user/sdk/include/tui.h
user/sdk/include/tui_widgets.h
user/sdk/tui/src/
user/sdk/widgets/src/
```

Private headers stay beside their library sources. `libtui.lib` and
`libtui_widgets.lib` are separate archives. An archive keeps one coherent
function group per object so an application does not link the key decoder,
formatter, region support, or widgets it never calls.

`exe_program` gains one generic option:

```text
LIBS=tui
LIBS=tui_widgets:tui
```

The colon-separated order is link order. Every named library resolves as
`lib/lib<name>.lib` in the standalone SDK and as the corresponding archive in
the in-tree SDK build. Program objects precede these archives; `libkos` follows
them. Existing programs with no `LIBS=` option link exactly as before.

The standalone package ships the public headers and archives. Its golden file
list, header-closure checks, deterministic-archive checks, out-of-tree build,
and forbidden-path checks cover them. TUI changes do not change the EXE ABI.
The SDK version becomes `0.2.0` only in package 73, when the whole v1 surface,
documentation, and examples ship together.

## Public results and errors

The declarations and numeric key/style/frame values are those in architecture
sections 9 and 10. Package 66 installs the complete core header; package 72
installs the widget header when that library exists.

- Lifecycle, cursor, window, style, drawing, clear, save, and restore calls
  return `0` on success and a negated `KOS_E*` value on failure.
- `tui_putc` returns `1`; `tui_write`, `tui_puts`, and their `_xy` forms return
  the number of input bytes consumed, even where clipping prevents a cell
  change. The formatting calls return their formatted byte count.
- A null required pointer, an invalid enum, an invalid rectangle, an operation
  before initialization, window-stack overflow/underflow, or unmatched
  `tui_end` returns `-KOS_EINVAL`.
- `tui_key_pending` returns `1`, `0`, or a negative console error.
  `tui_pollkey` returns `TUI_KEY_NONE` when no complete key is available.
  Because `tui_key_t` has no error range, a console error also produces
  `TUI_KEY_NONE`; it does not create a synthetic key.
- `tui_shutdown` is idempotent. It restores normal rendition and a visible
  cursor, flushes pending console output, and releases only library state.

`tui_init` is also safe after `tui_shutdown`. A second call while initialized
returns `-KOS_EINVAL`; it does not discard the current screen.

## Geometry, storage, and transactions

TUI v1 has one logical geometry: 85 columns by 26 rows. There is no console
size query or capability protocol in the current OS, and terminal discovery is
a v1 non-goal. `tui_get_size` returns this logical geometry; applications query
it instead of embedding the numbers. The serial terminal used for acceptance
must be configured to display that logical surface.

The core owns a static 85 x 26 `struct tui_cell` map and a dirty bitmap. This
cost appears only in a program that links the screen engine. There is no second
full-screen map. Private state also holds the current window, logical cursor,
rendition, window stack, transaction depth, and key parser.

Initialization makes terminal and model agree: normal rendition, visible
cursor, clear display, home, full-screen window, blank/normal cells, and no
dirty cells. Drawing changes the model and dirty bits; it does not write a
cell immediately.

`tui_begin` increments a bounded nesting count. `tui_end` decrements it and
flushes only when it closes the outermost transaction. `tui_flush` always
flushes explicitly, even inside a transaction. A flush:

1. scans dirty cells in row-major order;
2. coalesces adjacent dirty cells of one attribute into a horizontal run;
3. emits one 1-based `CSI row;column H` for the run;
4. emits SGR only when the physical attribute changes;
5. writes the run as one buffer, then synchronizes physical cursor and
   visibility and calls `console_flush` once.

Unchanged cells are not sent. A failed flush leaves the affected dirty state
set so a later flush redraws to a known result. Redrawing an already-sent run
is acceptable; losing a dirty cell is not. No path emits one console call per
cell.

The backend sequences are 7-bit ANSI/VT100 sequences already accepted by both
console implementations. Application code and widget code contain none of
them; only the `libtui` output backend does.

## Coordinates, text, and windows

Application coordinates are 0-based. Drawing and cursor coordinates are
relative to the active window. Window rectangles themselves are absolute
screen rectangles. A zero-sized or out-of-screen window is invalid; windows
must fit completely within the logical screen.

`tui_window` replaces the current window and homes its logical cursor.
`tui_push_window` saves the current rectangle, installs the supplied absolute
rectangle, and homes. `tui_pop_window` restores the saved rectangle and homes.
The stack depth is four. `tui_reset_window` selects the full screen and homes.
`tui_get_window` copies the current absolute rectangle to caller storage. It is
the public read-only query used by widget code that owns the active window's
top or bottom row; a null pointer or call before initialization is invalid.

Drawing rectangles are relative to the active window and are clipped to it.
Text never wraps or scrolls implicitly: printable bytes at or past the right
edge are consumed but do not alter another row. `CR` moves to column zero;
`LF` moves down one row and clamps at the bottom; `BS` moves left when
possible; `TAB` advances to the next eight-column stop and clamps; other C0
controls are ignored. Bytes `20h-FFh` are cells.

`tui_clear` fills the active window with spaces in the current attribute and
homes. `tui_clreol` fills cursor through the window's last column.
`tui_clrline` fills the current window row. Insert/delete line shift only the
active window and blank the exposed row with the current attribute.

## Styles and glyphs

A cell's `attr` is `0` for normal and `1` for reverse video. Low-level
`tui_set_attr` accepts only those values. Semantic v1 mapping is:

```text
normal:   NORMAL DISABLED ERROR INPUT ACCENT
reverse:  TITLE SELECTED STATUS
```

The mapping is deliberately small; applications use semantic names so a later
backend can improve it without changing application code. The backend emits
SGR 0/27 for normal and SGR 7 for reverse.

Box glyph bytes are private to the drawing implementation:

```text
single: h C4  v B3  tl DA  tr BF  bl C0  br D9
double: h CD  v BA  tl C9  tr BB  bl C8  br BC
```

They are the existing CP850 font's bytes. `TUI_FRAME_NONE` draws no border.
ASCII fallback and richer colors are later backend work, not a v1 branch or
runtime probe.

## Key decoder

The parser recognizes exactly the controller's existing vocabulary:

```text
Up/Down/Right/Left  ESC [ A/B/C/D
Home/End            ESC [ H/F
Insert/Delete       ESC [ 2~/3~
Page Up/Page Down   ESC [ 5~/6~
F1-F4               ESC O P/Q/R/S
F5-F8               ESC [ 15~/17~/18~/19~
F9-F12              ESC [ 20~/21~/23~/24~
```

Ordinary nonzero bytes, including CR, TAB, BS, and DEL, retain their byte
value. NUL is ignored because `TUI_KEY_NONE` is zero. No modifier vocabulary is
invented.

The private parser has NORMAL, ESC, CSI, and SS3 states and an eight-byte
bounded replay buffer. After ESC it drains bytes already pending from the
console. If no continuation byte is pending after that immediate look-ahead,
it returns `TUI_KEY_ESC`; it has no timer-driver dependency and does not make
the nonblocking API sleep. The console IPC round trip provides the intended
brief look-ahead, and the IOC enqueues each generated sequence together.

For an unknown, malformed, or overlong sequence, return `TUI_KEY_ESC` first
and replay every consumed tail byte as ordinary input in order. Thus input is
never silently lost and the parser returns to NORMAL. `tui_getkey` uses the
same parser as `tui_pollkey`, calling `idle()` between empty polls.

## Save and restore

Save/restore rectangles are relative to the active window and clipped to it.
`tui_saved_size` returns the clipped area times `sizeof(struct tui_cell)`, or
zero when uninitialized, null, or empty after clipping. Save and restore reject
a buffer smaller than that exact size. They copy row-major cells; restore
marks only cells whose value changes dirty. They never allocate or flush.

## Widgets

Widgets are procedural functions over `libtui`; no object model, callbacks,
heap, hidden event loop, terminal sequences, or OS calls are introduced.
Render-only calls leave input policy to the application. The `_run` calls and
modal dialogs use `tui_getkey` and redraw only the affected controls.

All widget coordinates are relative to the active window. A status bar owns
its bottom row; a menu bar owns its top row. `tui_menubar` treats `selected`
as an in/out item ID (not an array index), highlights that ID when present,
and writes the chosen ID. A null `selected` is invalid. `tui_menu_run` starts
on the first item and returns its ID, or `TUI_ID_NONE` on ESC.

`buttons` is a mask with bit `TUI_ID_*` selecting OK, CANCEL, YES, or NO; the
header supplies `TUI_BUTTON(id)`. Buttons are ordered OK, YES, NO, CANCEL.
Left/right or TAB moves focus, ENTER chooses the focused ID, and ESC chooses
CANCEL when present or `TUI_ID_NONE` otherwise. Menu navigation uses
left/right, ENTER, the declared shortcut, and ESC. List navigation uses arrows,
HOME/END, PGUP/PGDN. Input editing accepts printable bytes, left/right,
HOME/END, BS/DELETE; ENTER commits and ESC cancels. `tui_input_run` returns
`1` for commit, `0` for cancel, or a negative error.

Message and confirmation boxes center within the active window, wrap at word
boundaries, and are capped at 60 columns by 16 rows. The separately pullable
modal archive member owns one static 60 x 16 cell save buffer; nested modal
calls are invalid. This is the only hidden widget backing store. It is absent
from programs that use render-only controls and avoids placing kilobytes on a
normal application stack. `tui_confirm` is a YES/NO message box with YES
initially focused.

All controls clip to their supplied rectangle/window. Empty lists, long labels,
and small rectangles are valid and clipped; null required storage is invalid.

## Common evidence

The staged target program is `tests/tui/tui_test.c`, built as
`build/user/tui_test.exe` with `LIBS=tui` or
`LIBS=tui_widgets:tui`. It is not added to a production or recovery store.
Simulator tests inject it through the emulated card and run the same bytes on:

- the production V9958/HID console; and
- `systems/console-serial.json`.

Static/host tests live in `tests/test_tui.py`; replay tests live in
`tests/test_tui_sim.py`. The simulator may count entries to the console
driver's WRITE dispatch to prove batching; no production test hook is added.
Package 73 adds public examples, performs a forced rebuild and full validation
of the scoped user-SDK/TUI artifacts, and owns the physical-console checklist.
It reuses the accepted OS/backend images as immutable simulator fixtures; it
does not run the repository-wide clean/check gate for user-mode-only changes.

