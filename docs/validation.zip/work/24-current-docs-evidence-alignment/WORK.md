# Current Documentation and Evidence Alignment

## Task

Make the authoritative documentation and repository evidence describe the
accepted current M8 implementation. This is a documentation/reproducibility
correction; it does not reopen milestone decisions or change target behavior.

## Required corrections

`docs/module-format.md` calls itself authoritative but retains pre-M8 values:
the header table limits `required_granules` to `1..16`, the loader lifecycle
labels the callback block “driver API v1,” and surrounding status/fixed-arena
wording mixes historical M4/M5 behavior with the current derived M8 arena. The
implementation correctly uses ABI v2 and validates against the architectural
maximum of 80 granules, further bounded by the linked arena's live granule
count. Reconcile every normative statement with
`include/zephyros/{driver,module}.h`, the packer, loader, and current M8
architecture. Keep fixed `A000h-BFFFh` descriptions only when clearly labeled
as historical acceptance geometry.

`docs/boot.md` is titled and narrated as M0 while also describing the current
512-KiB image. Its kernel-entry section says the kernel prints the banner and
halts and that interrupts are never enabled; the current M8 boot continues
through IRQ initialization, the ordered SIO/IOC/HID/V9958 module set, one
console bind, and monitor launch. Update it to distinguish the historical M0
acceptance transcript from current boot semantics. The literal `HALT` line in
the current transcript is a retained historical marker, not the terminal M8
state; document that fact rather than changing the accepted output. Correct
stale milestone labels in live build comments where they claim to describe the
current tree.

The architecture and README cite dated M3-M8 validation records under
`docs/validation/`, but `.gitignore` blankets that directory and only M1/M2
records are currently tracked. Remove the blanket ignore for authoritative
records and commit all architecture-referenced summaries and intended
transcripts. If any raw capture is intentionally excluded, document the
durable summary policy and do not leave tracked documentation pointing only to
an ignored file. Add a repository test that extracts `docs/validation/...`
references from tracked live documentation and fails when a referenced path is
missing or untracked.

Preserve completed work-package text as historical evidence. Do not “correct”
old contracts to current limits. Do not alter target sources or regenerate
hardware claims. The user's M1-M8 closure and physical-boot acceptance are
inputs to this correction, not results to be re-proved.

## Validation

Run the documentation/reference test, `make check`, and `git diff --check`.
Use `git ls-files docs/validation` to prove every live referenced record is
tracked. Search the live normative docs for obsolete claims including driver
API v1, a current 16-granule maximum, current terminal halt after the M0
banner, and dangling validation links. Historical work contracts and clearly
labeled historical sections are exempt.

No target binary should change. Compare the production ROM and all production
ZMOD hashes with the current baseline; any difference is out of scope and must
be investigated before acceptance.

## Acceptance criteria

- Normative ZMOD documentation states ABI v2, the 80-granule format maximum,
  and the linked arena's tighter live bound.
- Boot documentation accurately separates M0 history from current M8 boot and
  monitor behavior.
- Every validation file cited by tracked current documentation exists in a
  clean clone and is tracked.
- The reference-integrity test prevents a future dangling evidence citation.
- Production artifacts remain byte-identical and all host checks pass.

## Expected files

- `docs/{module-format,boot,architecture}.md`, `README.md`
- `docs/validation/`, `.gitignore`
- `tests/`, `Makefile`

