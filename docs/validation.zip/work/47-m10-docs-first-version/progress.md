# Package 47 progress

Implementer: supervisor session (owner: "47 is for you"), 2026-10-12.
Baseline: `81f80cd` (49d committed), clean tree.

## Plan

1. Read docs/architecture.md fully; build the old→new section map.
2. Write the new docs/architecture.md (by subsystem, glossary, roadmap,
   toolchain appendix).
3. Rewrite the other docs (abi, boot, devices, exe-format, filesystem,
   memory, module-format, monitor, romfs-format, sdk, vfs, README);
   delete m10-m12-target-architecture.md.
4. Remove build history from code, tests, tools, JSON (requirement 6).
5. Greps, targeted tests, then make clean && make check once.

## Status

- [x] 1 section map
- [x] 2 architecture
- [x] 3 other docs (all rewritten; m10-m12-target-architecture.md removed; docs grep clean; links resolve)
- [x] 4 code/test history (grep clean bar the listed exceptions; history-only guards removed from tests)
- [x] 5 validation (see the record)

## Old -> new architecture section map

| old | new |
|---|---|
| 1 purpose, milestone list | 1.1 (milestones dropped) |
| 2 principles | 1.2 |
| 3, 3.1 source tree, ownership | 1.3 (current tree, include roots) |
| 4 toolchain | 1.4 |
| 5.1-5.6 M0 objective, latch, boot, entry, early console, panic | 2.1, 2.2, 2.5, 3.1, 3.4 |
| 6, 7 memory model (modes 10/11, regions, common) | 2.2-2.4 |
| 8 page zero | 4.3 |
| 9, 10 syscall ABI, common entry | 4.3, 4.4 |
| 11 stacks | 4.2, 4.3, 2.4 |
| 12 map validation | 8.2 |
| 13 asm/C boundary | 1.2 (principle 7) |
| 14, 15 interrupt/driver state at M1 | dropped (history) |
| 16 CP/M relationship | 12 |
| 16.1 emulator validation | 8.2 (hardware authoritative) |
| 17, 17.1 M0/M1 acceptance, hardware reference | 2.1, 2.5 (acceptance dropped) |
| 18 IRQ executive | 4.5 |
| 19 M2 acceptance | dropped |
| 20-23 registry, static drivers, M4 arena/relocation | dropped (deleted mechanisms) |
| 24 ROMFS, ROM access | 4.6 |
| 26 process, page zero, EXE v1 | 4.7, 6.7, 6.8 (v1 dropped) |
| 28 monitor | 7.4 |
| 30 M8 device stack | 5.6 (IOC transport, console per build) |
| 32.1-32.9 namespace, paths, limits | 4.10 |
| 32.10-32.20 providers, block, IOC, IOC-FAT, caching | 4.10, 5.6 (registry, mounts, block class dropped) |
| 32.21-32.31 process FS state, handles, metadata, errors, close/sync, EXDEV | 4.10, 6.5, 6.6 |
| 32.32-32.33 boot lifecycle, mount table | 3.2 (mount table dropped) |
| 32.35 personality boundary | 12 |
| 32.39 bank-7 budget | 9 (two-bank ledgers) |
| 32.40 exec | 4.7, 6.8 |
| 33, 34 acceptance, milestone summary | dropped |
| 35 completion sequence | 14 |
| 36.1 central rules | 1.2 |
| 36.2 rev 13 | 2.2 |
| 36.3 two-bank residency | 2.3, 1.2 |
| 36.4 nucleus vs drivers | 4.1, 5.1 |
| 36.5 fixed core, cold half, upcalls, buffer rule | 4.2 |
| 36.6 driver bank | 5.2 |
| 36.7 endpoints, handles, IPC | 4.9, 4.10 |
| 36.8 descriptors, copy paths | 4.9 (corrected: one descriptor) |
| 36.9 nesting, stacks | 4.9, 4.2, 4.3 |
| 36.10 driver IRQs | 4.5 |
| 36.11 driver images, host assembly | 5.3-5.5 |
| 36.12 boot | 3.2 |
| 36.13 VFS, providers, handles, exec, exit | 4.10, 4.7 |
| 36.14 syscall ABI | 6.1, 6.2, 6.4 |
| 36.15 banks | 4.8 |
| 36.16 xmem | 4.8 |
| 36.17 aperture, far code | 4.8, 7.2, 4.7 |
| 36.18 EXE v2 | 6.7, 4.11 |
| 36.19 memory init | 4.8 |
| 36.20 ledgers | 9 |
| 36.21 portability | 11 |
| 36.22 protection | 10 |
| 36.23 non-goals | 12 |
| 36.24 implementation order, 37 acceptance | dropped (records) |
| 38-41 diagnostics, shell | 14 (shell first; pending decisions) |
| 42 completion boundary | 14 |
| (new) far data, build, SDK | 7.3, 8.1, 8.3 |
| (new) toolchain appendix | Appendix A |

Corrections made against the code: one descriptor per call (old text said
two); `call(handle, ...)` for applications (old 36.7/36.14 said
`dependency_ref`, a mechanical-rename artefact); standard handles bound
fresh per process (old: "inherited"); consoles selected per build with no
fallback (old 30.9 said fallback); extended-memory objects: 16
system-wide.

## Step 4 notes

- Exceptions to the requirement-6 grep: `.gitignore` (`work/`,
  `docs/validation/` must stay ignored), the V9958 `M5+M3` register bits
  (hardware names in `hardware.h` and `v9958.c`).
- History-only test guards removed: removed-path tombstones, retired
  targets/boot modes/smoke modes, the Mn-1 window, the EXE v1 and old
  ROMFS/EXE/MOD magic checks, the legacy name comparisons, the static
  driver symbols, the system-composition tombstone tokens.
- Stale comments corrected: `kernel/lib/name.{c,h}` callers, IPC header
  "two IPC numbers", `docs/abi.md` section numbers in abi/kos headers,
  remap ranges (`4.2-4.5`, `4.10-6.2`).
- Open (not 47): `tests.test_hid`/`tests.test_v9958`
  `test_system_file_and_boot_order` fail on the 49d store list
  (far_data.exe, banks.exe, known.bin): the deferred 49d correction.
