> **READY** (2026-10-12). Baseline: the tree after 49d (49d's correction
> 01 is deferred by the owner). Run on the stronger model (owner
> decision). The old-to-new section map below is the guard against
> losing a current rule. Build it first, and check it before deleting
> anything.

# Task

**One pass over all documentation, so it reads as the first version of
KonaOS** (owner decision, 2026-10-11). A contributor sees the system as
it is, not how it got here.
- No milestone history, retired mechanisms, "superseded" notes or
  package numbers in the developer documentation.
- Git history keeps all of it. `docs/validation/` and `work/` stay as
  the records and are not developer documentation.

## Requirements

1. **Architecture document.** Rewrite `docs/architecture.md` as a
   current-state document, organized by subsystem, not by milestone:
   - purpose and principles (the guiding rule: host-precomputed, trusted,
     single-tasking; the two-bank OS);
   - hardware and memory model (revision 13 decoder, banks, window,
     aperture, common);
   - the nucleus (fixed core and cold half, gates, IRQs, processes,
     memory, IPC and descriptors, the namespace and handles, the loaders);
   - resident drivers (the image contract, the bootstrap API, lifecycle,
     build-time composition);
   - the native ABI (syscalls, objects and protocols, the two result
     channels, EXE, process startup);
   - programs and far memory (far code with `__banked`, far data with
     `DATAn`/`BLOBS`/`xalloc`/`xload`, the one-window rule, the costs);
   - the build (one system file per image, `systemgen`, driver
     manifests with symbolic dependencies, the standalone SDK);
   - budgets and ledgers;
   - portability (family-wide versus Zephyr-80 extensions, such as the
     aperture and far memory);
   - **a glossary**, normative.

   Planned work (the shell, then the diagnostics; owner order 2026-10-12;
   no milestone numbers) goes in a short, separate
   roadmap section or file, written as the future.
2. **Contract text matches the code:**
   - one descriptor per call;
   - the loader is one pass in manifest order;
   - standard handles are bound fresh for every process, with the CWD
     copied;
   - the endpoint key is not the protocol type;
   - far memory is a Zephyr-80 extension;
   - one explanation of the two result channels.

   Driver images are a source/build contract, not a binary module ABI.
3. **Every other document** (`docs/*.md`, `README.md`, the SDK guide,
   driver and format documents) is rewritten in the same voice, with
   the final names (packages 46 and 48).
   - Remove history; merge or delete documents that only described
     retired machinery (the mount table, provider ABI, registry, arena,
     `FS_*`, M8/M9 transcripts).
   - `docs/m10-m12-target-architecture.md` goes.
4. **One entry point.** `README.md` points each audience to its guide:
   application developer, driver developer, OS developer.
5. **Checks** (validation commands run for this package and recorded;
   **not tests in the suite**: the owner rule is that nothing in the test
   suite tests documentation):
   - a grep over the developer documents shows no milestone numbers
     (`M0`-`M12`), no package numbers, no "retired" or "superseded",
     and no old names (`FS_*`, `SYS_IPC_LOOKUP`, registry, arena, mount
     table, ZephyrOS, `zos`, ZEX, ZMOD);
   - links resolve;
   - add no test that reads documentation, and remove any that is left.

6. **No build history anywhere in the tree.** Package numbers ("work
   package NN", "42c", "correction 01", `WORK.md`, `work/…` paths), dated
   validation records (`docs/validation/2026-…`) and milestone numbers
   (`M0`-`M12`) are the build history. They stay in `docs/validation/`,
   `work/` and git, and nowhere else.
   - **Scope:** every tracked file outside `docs/validation/` and
     `work/`. That means source and headers, tests (comments, docstrings,
     assertion messages), tools, the Makefile and `*.mk`, the linker
     script, JSON (for example the `reason` fields in
     `config/residency.json`, system and driver manifests), and docs.
     Today there are about 600 such lines; about 700 more lines mention
     milestones or retired mechanisms ("legacy", "retired", "formerly",
     "the old …").
   - Rewrite each one in the present tense. **Keep the reason, drop the
     history:** "package 42c placed every object, so X" becomes "X,
     because Y". Delete the reference when it carries no current reason.
   - Rename identifiers, test names and files that encode a package or a
     milestone after their subject (for example `ALLOWED_MILESTONES` in
     `tests/test_source_layout.py`). This includes production
     identifiers, if any are left.
   - A rule that depends on milestones (the Mn-1 retention list in the
     tests) is restated without numbers, or removed if it only guards
     history.
   - **Check** (a validation command, not a test): a grep over the scope
     for `[Pp]ackage [0-9]`, `[0-9]{2}[a-e]\b` in package context,
     `WORK\.md`, `work/`, `docs/validation/`, `\bM[0-9]{1,2}\b`,
     "retired", "superseded" and "formerly" prints nothing. List every
     exception and the reason for it.

## The OS name: ZephyrOS became KonaOS in package 48

Until package 48 (accepted 2026-10-12) the OS was called **ZephyrOS**. 48
renamed it **KonaOS** in the code, the build and the docs, mechanically:

| before 48 | after 48 |
|---|---|
| ZephyrOS, `zephyros` | KonaOS, `konaos` |
| `zos_`, `ZOS_`, `abi/zos/`, `zos.h`, `libzos` | `kos_`, `KOS_`, `abi/kos/`, `kos.h`, `libkos` |
| ZEX, `.zex`, magic `ZEX2` | EXE, `.exe`, magic `KEX2` |
| ZMOD, `.zmod`, magic `ZMOD` | MOD, `.mod`, magic `KMOD` |
| `ZFS_`, `ZIOC_`, `ZCONSOLE_`, … | `KFS_`, `KIOC_`, `KCONSOLE_`, … |
| ROMFS magic `ZRFS` | `KRFS` (49a) |

What this means for this package:
- **The names are final.** Write every document with the KonaOS names.
  The hardware keeps its name: Zephyr-80, `platform/zephyr80/`.
- **Do not mention the rename.** The developer documents read as a first
  version, so "formerly ZephyrOS" does not appear in them.
- **The old names are history.** They survive only where history is kept:
  `docs/validation/` (records dated before 48), `work/`, git, and the
  repository directory name `ZephyrOS/`. None of these is developer
  documentation. Do not edit them.
- **48's substitution was mechanical, so expect artefacts:** grammar such
  as "a EXE", and stale names that were renamed rather than removed (see
  Inputs).

## Inputs

`inputs.md` (in this directory) lists what the earlier packages and the
owner hand to this one: the leftovers to remove, the roadmap decisions,
the device-state contract and the toolchain appendix. Every item in it is
a requirement.

## Constraints

- No behaviour change. Production source changes only in comments and in
  identifiers that encode history (requirement 6); no logic, string or
  constant changes.
  Production boots, and every test passes with the same outcomes.
- Keep what is true and useful. Rewriting is for voice and structure,
  not for dropping current contracts: every current rule in today's
  architecture 36 must survive into the new document. Report a short map
  from old section to new section.
- Report: `docs/validation/<date>-m10-docs-first-version.md`.

## Working loop (targeted only)

`make clean && make check` runs once, as the very last step. While
editing, use only:
- the requirement-5 and requirement-6 greps;
- `python3 -m unittest tests.<module>` for each test file you touch;
- an incremental `make` after editing comments in C or assembly files.

## Validation (once, at the end)

```sh
make clean && make check      # production boots; every host test passes
git diff --check
```

There is no full image matrix. For each acceptance image whose replay
test file you edited, run that image's target once, after your last
edit: `make clean` removes the images, so `make check` skips their
replays.
