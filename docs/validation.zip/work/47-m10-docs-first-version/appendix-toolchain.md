# Appendix: far calls with another toolchain

Written for package 47 to place as an appendix of the new architecture
document. It describes the state after package 49b.

## What is toolchain-independent

Far code is an OS and executable-format contract. It does not depend on
any compiler:
- an EXE file carries up to four `FAR_CODE` segments (ids 1-4), each
  linked at `8000h` and at most 16 KiB;
- `SYS_SEG_MAP` returns a segment's aperture token;
- the program opens the aperture with that token and restores the
  previous token afterwards (`aperture_open`/`aperture_close`);
- `farcall(segment, fn, a, b)` is an ordinary C function built on these
  calls. Any C compiler that can call a C function can use it.

The kernel, the loader and the EXE format know nothing about SDCC.
Existing binaries keep working whatever toolchain builds new ones.

## What is SDCC-specific

The plain-C call syntax and its glue:

1. **Source syntax.** `__banked` and `#pragma bank <n>` are SDCC
   extensions. Another compiler either has its own syntax (z88dk, IAR) or
   none.
2. **The call convention.** For a call to a banked function, SDCC loads
   the segment id (the `b_<fn>` symbol) into `E` and the address into
   `HL`, then calls `___sdcc_bcall_ehl`. The SDK implements that symbol
   (`user/sdk/src/bcall.asm`):
   - it caches each segment's token;
   - it opens the aperture;
   - it calls `HL`;
   - it restores the previous token, preserving the argument and result
     registers of SDCC's `sdcccall(1)`.
3. **Packer input.** `exepack` reads the linker's Intel HEX image (a
   common format) and SDCC's map file (specific to SDCC) for symbol
   addresses and area sizes.

## Porting to another toolchain

Expect three pieces of work. The OS itself does not change.

- **An entry adapter.** Implement the new toolchain's banked-call entry
  (its name and registers) as a small assembly routine with the same four
  steps as `bcall.asm`: token lookup, open, call, restore. It is about
  30-60 bytes.
  - For a toolchain with no banked-call support, call far functions
    through `farcall` explicitly.
- **Source portability.** Code meant to build with several compilers
  should not spell `__banked` directly. Wrap it in a project macro that
  expands to the compiler's keyword, or to nothing plus explicit
  `farcall` use.
- **A map reader.** Give `exepack` a reader for the new linker's symbol
  and area output that returns the same information: symbol addresses,
  the primary image range, and each far segment's range and size. The
  rest of the packer is unchanged.

**Requirements on any toolchain:**
- it can link a code section at a fixed address (`8000h`), separately
  per segment;
- it can produce Intel HEX or a raw image with known bases;
- it reports symbol addresses.
