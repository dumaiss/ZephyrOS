# Package 47 inputs

Read with `WORK.md`; each item is a requirement of the package.


1. **Leftovers listed in 46's "Unmapped" section**
   (`docs/validation/2026-10-12-m10-surfaces.md` §5):
   - the stale `kos_opendir/readdir/closedir`, `kos_ipc_lookup` and
     `KOS_IPC_CACHE_ENTRIES` (`docs/abi.md`, `docs/sdk.md`): mechanisms
     that no longer exist, renamed by 48 rather than removed;
   - `vfs_fd_check` (`docs/vfs.md`);
   - the mechanical "driver drivers" and "Driver, device, capability, and
     driver" artefacts.

   Add them to the grep gate. From 48's record: the broken citation of
   `docs/validation/2026-10-03-m6-exe.md` (the file is named `…-zex.md`;
   drop the history citation), and grammar such as "a EXE".
2. **Roadmap decisions** (owner, 2026-10-12): see the "Architecture edits
   pending" list in `work/README.md`. They are written straight into the
   new roadmap, not edited into the old document first:
   - M11 is the shell, then M12 the diagnostics;
   - the shell decisions (`//`, the shared splitter,
     `KOS_BOOT_AFTER_EXIT`);
   - the TIMER driver on CTC channel 2;
   - the `SYS_DIAG_ENUM` kinds;
   - the device-state contract (51b): release notification, exclusive
     binds (a program reprograms a device only while it holds its
     exclusive handle), the console reset before every boot-program
     start, and warm reboot (latch 00h, `JP 0`; every driver init works
     from any state).
3. **Appendix** (owner, 2026-10-12): place
   `work/47-m10-docs-first-version/appendix-toolchain.md` as an appendix
   of the new architecture document, adjusted to the code as 49b built
   it: far calls with another toolchain.


4. **What 49a-d added** (document the current state; their records are
   the source):
   - **build:** `systems/<image>.json`, `tools/systemgen.py`, the
     canonical store order, symbolic driver `depends`, and test-only
     drivers named by path;
   - **SDK:** `make sdk` → `kos-sdk-<version>/`, `mk/kos.mk`, the
     template and examples, `docs/sdk.md` section 11;
   - **far code:** `__banked` and `FAR1=`…`FAR4=`; `farcall` stays the
     primitive; the 310 T-state banked call;
   - **far data:** `DATA1=`…`DATA4=`, `BLOBS=`, `farmap`/`farunmap`/
     `blob`/`xload`, the mappable segment-row flag, the one-window rule,
     the bank budget, the copy costs (21 or 287 T-states per byte by
     slot). `docs/sdk.md` section 12 is the starting point;
   - **files on the card are 8.3 names.** IOC-FAT refuses a longer base
     name; say so in the filesystem document.
5. **Do not document the three far-data test files** that 49d placed in
   the production store (`far_data.exe`, `banks.exe`, `known.bin`). Its
   deferred correction removes them.
