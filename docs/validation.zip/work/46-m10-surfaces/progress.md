# 46 progress — M10 surfaces (nucleus / drivers / applications)

Contract: `work/46-m10-surfaces/WORK.md` + `TABLES.md`. Refactoring only,
six fixed steps, no design decisions. Do not commit.

## Baseline (45b tree, before step 1)

Production image `build/zephyros.bin`
sha256 `5a731321687636e8a7c26a1ccbadb545209621429e3577bbbafd13a647c395d2`
(matches the 45b baseline recorded in
`docs/validation/2026-10-11-m10-hardware-acceptance.md`).

Ledgers (build/zephyros.manifest.json + mapcheck output):

| ledger | value |
|---|---|
| nucleus fixed | required 8335, overflow 2, stacks 768, room 7279 (free 7279) |
| nucleus cold | code 23352 end BB38h, data 1527 at BC00h, room 7689 (free 7689) |
| driver hot | 21910 / 32768 |
| driver boot/bulk | 2170 / 24576 |
| common | used 2358 of 7424 (code 1511, data 847), ceiling 3072 |
| gate stack | 384 bytes reserved (platform constant); M10 acceptance worst case 275 (tests/test_ipc_selftest_sim.py), unchanged by this package |

Pre-existing worktree change (preserved, not mine): `docs/architecture.md`
modified (116/116 lines) — a partial rename attempt with `DEVice`-style
strings and lowercased `/fs`, `/system`. Kept as found; only the
path/identifier renames from the tables are applied on top.

## Step log

### Step 1 — tree moves (T1) — DONE

`git mv`: services/console→drivers/console; the five manifests→their
driver dirs (+ the two console manifests→drivers/console/); fs/iocfat→
drivers/iocfat; modules/runtime→drivers/runtime; drivers/ctc/ctc.c→
kernel/irq/ctc.c.  Empty services/, fs/, modules/, drivers/ctc/,
kernel/core/ removed.  Makefile: per-driver manifest resolution
(`SVC_MANIFEST` + `zmod_pack_rule` eval; the NS override moved into
`SVC_MANIFEST_DIR`), source paths, comments.  Tests/docs updated
(test_source_layout.py pins, test_ioc/hid/v9958/iocfat/console_acceptance/
sdk, README, docs/devices|vfs|memory|architecture).

Build: `make` (forced rebuild of every moved source and manifest via
`touch`) — **production sha256
`5a731321687636e8a7c26a1ccbadb545209621429e3577bbbafd13a647c395d2`,
identical to baseline**.  Ledgers identical to baseline: fixed required
8335/overflow 2/stacks 768/room 7279; cold code 23352 end BB38h/data 1527
at BC00h/room 7689; driver hot 21910/32768; driver boot/bulk 2170/24576;
common 2358 of 7424 (code 1511, data 847) ceiling 3072.  Gate stack
untouched (384 reserved; 275 worst case).

### Step 2 — driver vocabulary (T2) — DONE

`git mv`: kernel/service→kernel/driver (service_loader.c→driver_loader.c,
service_boot.asm→driver_boot.asm); drivers/{ioc,sio,v9958}/X_service.c→
X_proto.c; drivers/console/console_service.c→console_proto.c;
user/sdk/src/console_service.c→console_proto.c; include/zephyros/
service.h→driver.h; tests/target/*/service_client.{c,h}→driver_client.*;
tests/test_service_images.py→test_driver_images.py.  Content: the
mechanical rule `service|Service|SERVICE`→`driver|Driver|DRIVER` after the
T2 specific renames (`ipc_service_*`→`driver_*`, Makefile `SVC_`→`DRV_`
and `svc`→`drv`), repo-wide except `docs/validation/` and `work/`
(LICENSE reverted: its "service marks" is Apache text, not an identifier
— recorded under Unmapped).  ROMFS `services.man`→`drivers.man`; tool
command `zmodpack.py services`→`drivers`; plan/report key
`services`→`drivers`; printed labels (`service loader:`→`driver loader:`,
`services: unavailable`→`drivers: unavailable`, `console: service
OK/failed`→`console: driver OK/failed`, monitor and integration labels).

Deviations (owner-approved, see record): the `ipc_service_boot()`
accessor keeps `driver_boot()` (specific rule) and the file-static boot
bundle is `driver_boot_bundle` (the general rule would have produced a
C name collision: SDCC error 91).  `call` member's `handle` parameter
renamed `dependency_ref` in `driver_api`, its `api_call` implementation
and the docs that name it.  `X_service.rel` objects follow the general
rule → `X_driver.rel` (packed from `X_proto.c`).

Build: `make -k` then `make` — **production sha256
`717abc1b04be5d352c9cad11b332ac7fd13655048b9e16f341717ef4896241a2`**
(changed, as step 2 requires).  Ledgers: fixed required 8335 / overflow 2
/ stacks 768 / room **7279 (identical)**; cold code 23347 end BB33h
(was 23352/BB38h, −5 bytes: the renamed boot strings — `drivers:
unavailable 0x`, `console: driver OK/failed` ×3 −1 each, `driver
loader: ` −1, `drivers.man` −1), data 1527 at BC00h, room **7689
(identical)**; driver hot **21910/32768 (identical)**; driver boot/bulk
**2170/24576 (identical)**; common **2358 of 7424 (identical)**; gate
stack untouched (384; worst case 275).

### Step 3 — headers by audience (T3) — DONE

`git mv`: ipc.h→drivers/include/driver.h; ioc.h, ioc_protocol.h→
drivers/include/; kernel.h→kernel/include/; process.h, platform.h→
kernel/include/; irq.h→kernel/include/irq_types.h; romfs.h, zex.h→
formats/include/; driver.h→formats/include/zmod.h; hardware.{h,inc}→
platform/zephyr80/public/; memory.{h,inc} and irq.{h,inc}→
platform/zephyr80/private/.  `include/` deleted; its private errno.h's
three IOC transport codes (ZOS_EPROTO/ECRC/EBADSEQ) moved into
drivers/include/ioc.h; every includer switched to `"zos/errno.h"`.
Include spellings now bare (`"kernel.h"`, `"driver.h"`, `"zex.h"`,
`"hardware.inc"`, …); `"zos/…"` and `"kernel/<part>/…"` unchanged.

Include roots (Makefile/config.mk): nucleus CFLAGS = `. $(ZOS_PLATFORM_CFLAGS)`
= `. abi kernel/include drivers/include formats/include
platform/zephyr80/public platform/zephyr80/private $(BUILD)`; DRV_CFLAGS =
`abi drivers/include platform/zephyr80/public $(BUILD)`; MOD_CFLAGS = the
same + the driver's own directory (`drivers/sio`), no `.`; ASFLAGS =
`-Iabi -Iplatform/zephyr80/public -Iplatform/zephyr80/private`
(+`-Itests/target/include`); SDK unchanged (`-I abi -I $(ZOS_SDK_INCLUDE)`).
Tools/tests that read the headers follow the new paths (maptools, romfs,
hwtest, ioc, hid, zex, sdk, ns, ipc, v9958, serial_smoke, romfspack).

Additions (WORK "Additions" 2 and 3) in `tests/test_source_layout.py`:
- `test_driver_roots_cannot_reach_kernel_h`: compiles a one-line source
  including `"kernel.h"` with the driver roots; passes when the compile
  fails.
- `TestIncludeRootAllowLists`: the exact `-I` set of each T3 build class
  (nucleus, DRV_CFLAGS, MOD_CFLAGS, ZEX_CFLAGS).

Build: `make` — **production sha256
`717abc1b04be5d352c9cad11b332ac7fd13655048b9e16f341717ef4896241a2`,
identical to step 2**.  Ledgers identical to step 2 (fixed 8335/2/768/7279;
cold 23347 BB33h/1527/7689; driver hot 21910; driver boot 2170; common
2358/7424) — the file moves change no compiled byte.

### Step 4 — VFS split (T4) — DONE

`git mv` `kernel/vfs/ns.c`→`router.c`, `ns_file.c`→`system.c`,
`process.c`→`handles.c`; `git rm` `kernel/vfs/ns.h`.  The one VFS becomes
eight parts, each rebuilt from the HEAD text (the step-2/step-3 rules
replayed first, so no earlier rename is lost):

| file | content |
|---|---|
| `router.c` | bind/unbind/resolve, `vfs_emit`/`vfs_room`, `ns_enum_root`→`vfs_enum_root`, `vfs_ns_enum`, `vfs_fs_namespace_op`, `vfs_ns_file_call`, `vfs_ns_dir_check`, `vfs_init`/`vfs_phase`/`vfs_ns_reset`/`vfs_ns_init` |
| `dev.c` | the publication table (`vfs_ns_pub_count`, `vfs_pub_find`), `vfs_ns_publication_endpoint`, `vfs_ns_install_publication`, `vfs_device_bind`, `vfs_enum_device` |
| `fs.c` | every `ns_fs_*` (`vfs_fs_put_path`/`rel`/`alloc`/`close`/`bind_file`/`read_path`/`root_path`), `vfs_ns_fs_call`, `vfs_ns_fs_release`, `vfs_enum_fs`, `vfs_ns_fs_endpoint` |
| `system.c` | all of `ns_file.c` + `vfs_enum_romfs` |
| `handles.c` | all of `process.c` + `vfs_ns_release_entry`, `vfs_ns_standard_handles` |
| `path.c` | all of `path.c` + `vfs_fold`, `vfs_component_eq`, `vfs_component_length`, `vfs_path_under` |
| `workspace.c` | unchanged |
| `vfs.h` | today's `vfs.h` + `ns.h` + the cross-file declarations (staged at the end) |

Names: cross-file statics became extern with `ns_`→`vfs_`
(`ns_fold`→`vfs_fold`, `ns_pub_find`→`vfs_pub_find`, `ns_emit`→`vfs_emit`,
`ns_room`→`vfs_room`, `ns_enum_romfs`→`vfs_enum_romfs`,
`ns_enum_device`→`vfs_enum_device`, `ns_enum_fs`→`vfs_enum_fs`,
`ns_device_bind`→`vfs_device_bind`, `ns_fs_*`→`vfs_fs_*`); the T4
type/locals rename (`struct vfs_descriptor`→`struct vfs_handle_entry`,
`vfs_descriptors`→`vfs_handles`, `VFS_FD_MAX`→`VFS_HANDLE_MAX`,
`vfs_fd_active_count`→`vfs_handle_active_count`,
`vfs_ns_release_desc`→`vfs_ns_release_entry`, `desc` locals→`entry`)
applied in `kernel/vfs/*` and `kernel/process/exec.c`.  The file-local
`ns_file_*` helpers and `ns_pub_child`/`ns_pub_add`/`ns_fs_close`/
`ns_fs_root_path` keep their names (no cross-file user).  Each new `.c`
opens with its one-line part comment (WORK "Additions" 1).

Wiring: Makefile (`VFS_OBJS`, `OBJS` — `vfs_router`, `vfs_dev`, `vfs_fs`,
`vfs_system`, `vfs_workspace`; explicit rules for each part; the NS
selftest `COLD_EXTRA`/`--cold-extra` list `vfs_router,vfs_system,object,
vfs_file`), `config/residency.json` (the five VFS parts; `vfs_workspace`
stays `fixed-required`), `linker/zephyr80.lk` (vfs_path, vfs_handles,
vfs_workspace, vfs_router, vfs_dev, vfs_fs, vfs_system, object), tests
(test_ns_selftest object/tier/linker picks, test_ipc_selftest linker pick,
test_fs_selftest_sim `_vfs_handles`/`VFS_HANDLE_MAX`/handle-table wording,
tests/ns + tests/hwtest comments, test_source_layout `OWNER_FILES`,
`TestKernelNameComparison` caller → `kernel/vfs/dev.c`, retired
`kernel/vfs/ns.c|ns.h|ns_file.c|process.c` pins) and the docs that name
VFS paths (`docs/vfs.md`, `docs/memory.md`, `docs/romfs-format.md`,
`docs/architecture.md`, comments in `kernel/ipc/ipc.h`,
`kernel/syscall/object.c`, `abi/zos/protocol.h`).

Two comment blocks the first split pass dropped (above `ns_pub_child` and
`ns_pub_add` in `dev.c`) are restored; the hash is unchanged.

Build: `make` — **production sha256
`cbfc212578074d83248dff710d18f8252bc37f630bdaef1a1b4ab2f361facad0`**
(changed, as step 4 requires: the cold half holds the same code in the new
part order).  Ledgers **identical to step 3**: fixed required 8335 /
overflow 2 / stacks 768 / room 7279; cold code 23347 end BB33h, data 1527
at BC00h, room 7689; driver hot 21910/32768; driver boot/bulk 2170/24576;
common 2358 of 7424 (code 1511, data 847) ceiling 3072.  `mapcheck:
OK (18 areas, 362 symbols)`.  Statics turned extern changed no byte: the
split is code-identical, only the link order of the cold objects differs.

Test-unit repairs for steps 1-3 that running `tests/test_source_layout.py`
surfaced (all "change tests by the same renames and path updates"):

- `_platform_files()` yielded the `public`/`private` directories as files
  (T3 nested them) — it now yields files only.
- `test_no_production_block_module_manifest` read the deleted
  `drivers/manifests/` — it now walks each driver's own manifest (T1).
- `test_production_headers_declare_no_test_runners` read
  `include/zephyros/` — now the seven T3 header paths.
- the `drivers/ioc` listing pin was not in `sorted()` order after the T2
  `ioc_proto.c` rename.
- `test_no_driver_private_sdcc_glue` now exempts the shared source itself
  (T1 moved it to `drivers/runtime/`).
- `tests/test_ns_selftest.py` still asked for `SVC_MANIFEST_DIR` (T2).
- the driver-image probe compiled `zmod.h`/`irq_types.h` (kernel-only
  since T3) — its includes are the driver audience's (`driver.h`, `ioc.h`,
  `ioc_protocol.h`, `hardware.h`) and the negative half includes
  `driver.h`.
- 21 stale `include/zephyros`/`zephyros/` references in README/docs/
  tests/tools/platform stayed from T3 (the audience trees are now
  `kernel/include`, `drivers/include`, `formats/include`,
  `platform/zephyr80/{public,private}`).

`python3 -m unittest tests.test_source_layout` → **61 tests, OK**.
`tests/test_ns_selftest.py` / `tests/test_ipc_selftest.py` still fail on
the two container-manifest assertions only: their `build-*-selftest/`
recovery stores are pre-step-2 artifacts (`services.man`); the production
`build/recovery.romfs` already carries `drivers.man`, so `make clean &&
make check` (final validation) rebuilds them.

### Step 5 — lowercase roots (T5) — DONE

Deterministic sweep of the two root literals and their path spellings
(`"FS"`/`"SYSTEM"`, `/FS`/`/SYSTEM`) over **62 files, 476 replacements**,
left-guarded with `(?<![A-Za-z0-9_])` so identifiers stay put (`FS_SIZE`,
`VFS_*`, `ZOS_SYSTEM_*`).  Values changed, lengths did not:
`tools/zmodpack.py` `FS_ROOT`, `tools/bootprogram.py` `SYSTEM_PREFIX`,
the stored boot path, `Makefile` `ZOS_BOOT_PROGRAM`, `config/system.mk`,
the `kernel/vfs/` comparisons and the enum-of-`/` names,
`VFS_NS_FS_ROOT`, the provider check, monitor/programs/tests/smoke strings
and the docs that quote them.  Path normalization is untouched.

Build: `make` — **production sha256
`d1663b2a6e831698f7cfcbdab0bfa367a6dc63751b393b8d602dc978262f09de`**.
Ledgers identical to step 4 (equal-length strings only): fixed required
8335 / overflow 2 / stacks 768 / room 7279; cold code 23347 end BB33h,
data 1527 at BC00h, room 7689; driver hot 21910/32768; driver boot/bulk
2170/24576; common 2358 of 7424 (code 1511, data 847); `mapcheck:
OK (18 areas, 362 symbols)`.

Test repairs the sweep surfaced (renames and path updates only):

- `SVC_MANIFEST`→`DRV_MANIFEST` pins still in the tests (step 2 rename).
- `tests/test_source_layout.py`'s include probe expected the deleted
  `include/zephyros/errno.h` spelling `INTERNAL_ERRNO_H`; T3 put those
  three codes in `drivers/include/ioc.h` → the probe uses `IOC_H`.
- the step-2 sweep had collapsed the second `DRIVER_C` in
  `tests/test_ioc.py` and `tests/test_v9958.py` (the constant that meant
  `X_service.c` → `X_proto.c`, shadowing the one that means `X.c`): it is
  `PROTO_C` with `self.proto` again.

### Step 6 — SDK names (T6) — DONE (one owner-approved deviation)

Two rename passes over the live tree (**63 files**): first the table's
names with word boundaries, then the underscore-prefixed assembly symbols
(`_zex_exit`, `_zex_getinfo`, `_zex_diag_*`, `_zos_split`, `_zex_putc`,
…), which `\b` misses because `_` is a word character.

Specials:

- `putchar` is the merged PUTC client in `user/sdk/src/console_proto.c`
  (`int putchar(int)`): HEAD's `zex_putc` body plus the table's return
  value.  `user/sdk/src/console_io.c` loses the `zos_putc` and
  `zos_console_write` wrappers and keeps `console_puts`/`getchar`/
  `console_readline`.
- `exit`/`getinfo` keep their gate bodies (`void exit(int)` passes
  `(unsigned)status` as before).
- a program-local symbol that collides with a new name takes its file's
  base name: `ipc.c`'s `call` → `ipc_call`, `ipccopy.c`'s → `ipccopy_call`,
  `hwtest.c`'s `open` → `hwtest_open`.
- the sweep's over-reach on types and kernel-side names is reverted:
  `struct zos_seg_info`, `struct zos_xmem_info` and the kernel syscall
  bodies (`zos_xmem_alloc` … in `kernel/syscall/xmem.c`).
- `zos.h` no longer includes `zos/diag.h`; the `diag_*` wrappers are
  declared by `user/sdk/include/zos/diag.h`, and the monitor includes that
  header with `INCLUDES=user/sdk/include/zos` (see Decisions).
- `zos_ipc_raw_call` is declared only in `user/sdk/src/zos_internal.h`;
  the IPC target program adds `user/sdk/src` to its `INCLUDES`.

Build: `make` — **production sha256
`c4b407ee6a2cc0f1a885686c0547a911a2718d75b03df83e44ee0a7dd7570a08`**.
Ledgers identical to the baseline: fixed required 8335 / overflow 2 /
stacks 768 / room 7279; cold code end BB33h, data 1527 at BC00h, room
7689; driver hot 21910/32768; driver boot/bulk 2170/24576; common 2358 of
7424 (code 1511, data 847); `mapcheck: OK (18 areas, 362 symbols)`.

**Program sizes — deviation, owner-approved.**  `monitor.zex` payload
6053 → **6068** (+15), reproducible and fully accounted for by the T6
table's `putchar` entry: +10 in the PUTC client (preserving `ch` across
the call, then the driver's 0→byte translation), +4 at `console_io.c`'s
two echo/bell call sites and +1 at `monitor.c`'s, because the parameter is
now `int` where HEAD's `zos_putc` took a `char`.  Evidence: every other
SDK and monitor object is code-identical (`.rel` `A _CODE` sizes), the
pure renames cost 0 bytes, and the cheapest formulation that drops the
error test still costs +5 — so WORK.md's "program sizes in step 6 must
not grow" cannot hold with `int putchar(int)`.  Decision (owner, asked in
step 6): keep the table's `putchar` semantics, re-pin the monitor
constants and record the growth here and in the validation record.

Test pins touched for the same reason (names and paths only, no assertion
deleted, skipped or weakened):

- `tests/test_console_acceptance.py` — `MONITOR_SIZE` = 6068,
  `MONITOR_SHA256` =
  `41430a5fbb99b67720c6c126580f90b51d7462e94a194d80f215fe2c0e431070`
  (owner-approved re-pin of the packed artifact).
- `tests/test_monitor.py` — the bare `_console_` kernel prefix now also
  matches the SDK's own `_console_*` functions, so it names the kernel
  console families instead: `_console_driver`, `_console_forward`,
  `_console_api`, `_console_in`, `_console_out`.
- `tests/test_ipc_selftest.py` — the raw-call declaration is asserted in
  `user/sdk/src/zos_internal.h` and asserted absent from the public
  `zos/ipc.h`.
- `tests/test_iocfat.py` — `assertNotIn("close")` (the renamed
  `zos_close`) also matched the child's "closed on purpose" comment; it is
  `assertNotRegex(text, r"\bclose\b")`.
- `tests/test_hwtest.py` — the `run(` pin matched `hw_run(` too; it is
  `"= run("` again.

Docs: `docs/sdk.md` (one merged `putchar` prototype; `void exit(int)`;
"these four entries"), `docs/abi.md` (the PUTC row's self-referential
"(used by `putchar`)" removed; the raw-call declaration documented as
SDK-private), plus the rename sweep through README and `docs/`.

### Matrix repairs (found by the step-6 image matrix)

The image matrix caught three leftovers that a plain `make check` skips
(the `ipc-selftest` image failed to build):

- `tests/target/ipc/irqx.c` included `"irq.h"`, which T3 moved out of the
  driver roots to `platform/zephyr80/private/irq.h` (the driver class gets
  `platform/zephyr80/public` only).  The test module's compile rule now
  carries `-Iplatform/zephyr80/private` (test-only, commented in the
  Makefile), because the `irqx` test driver programs CTC0 itself with
  `ZOS_CTC0_VECTOR_BASE`; the production driver roots stay public-only.
  The bare `"irq.h"` spelling stays (T3 spelling rule) — the same header
  the file included at HEAD, only moved.
- `user/sdk/zex.mk`'s `INCLUDES` split never ran: the template wrote
  `$(subst :, ,$$($(1)_INC))`, so the variable reference stayed literal
  and a multi-path `INCLUDES=a:b` reached the compiler as the single flag
  `-Ia:b`.  T6's own instruction ("tests that use it add `user/sdk/src` to
  their `INCLUDES`") is the first multi-path user, so the `subst` is
  deferred (`$$(subst …)`); single-path programs are byte-for-byte
  unaffected.  `make ipc-selftest` then builds and replays green (40
  tests, the count the M10 acceptance records).

## Unmapped

- `docs/architecture.md`'s pre-existing uncommitted edit (see above): not
  covered by any table; left untouched, listed here per WORK.md rule 1.
- `LICENSE`: the Apache-2.0 text's "service marks" is legal prose, not a
  code identifier; the T2 rule was not applied (the mechanical sweep's
  change was reverted).  No other live file but `docs/validation/`
  (skipped by contract) contains a `service` token after step 2.
- Mechanical artefacts left for package 47 (comments/docs only, per
  WORK.md rules 3-4): "the five driver drivers" (kernel/main.c),
  "driver drivers' manifests" (test_source_layout.py docstring),
  architecture.md "Driver, device, capability, and driver" heading and
  `driver_bind_defaults()`; docs prose was renamed by the table rule
  only.
- `zos_opendir`/`zos_readdir`/`zos_closedir` keep their `zos_` prefix: T6
  lists `open close read write seek sync stat mkdir rmdir unlink rename
  chdir getcwd` and nothing else, so these three keep the old spelling
  (Unmapped, not renamed).
- kernel-side `zos_*` names (`kernel/syscall/xmem.c`'s `zos_xmem_alloc`,
  `kernel/vfs/`, …) are not SDK names; the sweep's changes there are
  reverted and they stay as they are.
- `docs/abi.md` still describes `zos_ipc_lookup`/`ZOS_IPC_CACHE_ENTRIES`
  and `docs/vfs.md` still references `vfs_fd_check`; both are stale at
  HEAD (packages 42b and 44) and are not covered by any table.
- pre-existing duplicates in the test scaffolding: `OK_LINE`/`FAIL_LINE`
  and the `CMD_*` constants in `tests/test_ioc_sim.py` and
  `tests/test_hid_sim.py`.

## Decisions

- **Step 6, the monitor's `diag` include.**  T6 says the monitor includes
  `zos/diag.h`.  For a ZEX program the roots are `-I abi -I
  user/sdk/include -I <program dir>`, and a quoted include resolves
  relative to the including file first, so `"zos/diag.h"` in
  `user/monitor/monitor.c` reaches `abi/zos/diag.h` — the types only,
  without the `diag_*` wrappers the monitor calls.  The monitor therefore
  includes `"diag.h"` (the SDK header) and its build line carries
  `INCLUDES=user/sdk/include/zos`; the wrappers are otherwise reachable
  only through the umbrella `zos.h`.  Recorded in the step-6 section and
  in `docs/sdk.md`.
- **Step 6, `putchar` size and the monitor pin** (owner asked, option 1
  chosen): keep the table's `putchar` semantics, re-pin `MONITOR_SIZE`/
  `MONITOR_SHA256`, and record the 15-byte growth as a deviation from
  "program sizes in step 6 must not grow".

## Validation (formal batch, 2026-10-12, frozen source)

```sh
make clean && make check                        # exit 0, 213.88 s
make -j16 all subsystem-selftest nucleus-selftest \
     console-integration-selftest console-serial-selftest \
     fs-selftest ns-selftest ipc-selftest xmem-selftest \
     helloworld-image                           # exit 0, 632.87 s
git diff --check                                # no whitespace errors
```

- `make check`: reproducible rebuild
  `c4b407ee6a2cc0f1a885686c0547a911a2718d75b03df83e44ee0a7dd7570a08`
  (`cmp build/zephyros.bin build/zephyr80.bin` byte-identical), 610 tests
  `OK` (104 skipped: the image replays run in the matrix targets),
  `mapcheck: OK (18 areas, 362 symbols)`, fixed core end 3D2Ch (8335
  required + 2 overflow + 768 stacks, room 7279), cold half end BB33h,
  driver hot 21910/32768, driver boot/bulk 2170/24576, common 2358 of
  7424.
- The first matrix attempt failed to *build* the `ipc-selftest` image
  (`irq.h` root and the `INCLUDES` split, see "Matrix repairs"); the batch
  above is the green run on the repaired tree.  All 13 replay discovery
  runs report `OK` (163 tests).
- Each image target was re-run once on its own afterwards to attribute the
  replay counts (the `-j16` log interleaves): subsystem 30, nucleus 6,
  console-integration 15, console-serial 6, filesystem 3, namespace 27,
  IPC 40, xmem 8, helloworld 28 — 163 in total, all green (see the
  validation record's table).
- Program sizes: `monitor.zex` 6068 (pinned), other programs +12…+15 from
  the same merge; the production store stays far inside its capacity.
- No commit (owner instruction).  The tree also carries the pre-existing
  `docs/architecture.md` edit (Unmapped).
