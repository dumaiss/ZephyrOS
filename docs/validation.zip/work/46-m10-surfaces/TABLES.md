# Package 46 tables

Every rename and move is listed here or covered by a stated rule. Anything
else stays as it is (see WORK.md, "Unmapped").

## T1. Tree moves (step 1, `git mv` only)

| from | to |
|---|---|
| `services/console/` | `drivers/console/` |
| `services/manifests/ioc.json` | `drivers/ioc/ioc.json` |
| `services/manifests/sio.json` | `drivers/sio/sio.json` |
| `services/manifests/v9958.json` | `drivers/v9958/v9958.json` |
| `services/manifests/hid.json` | `drivers/hid/hid.json` |
| `services/manifests/iocfat.json` | `drivers/iocfat/iocfat.json` |
| `services/manifests/console-*.json` (2) | `drivers/console/` (same names) |
| `fs/iocfat/` | `drivers/iocfat/` |
| `modules/runtime/` | `drivers/runtime/` |
| `drivers/ctc/ctc.c` (nucleus code) | `kernel/irq/ctc.c` |

Then delete the empty `services/`, `fs/`, `modules/`, `drivers/ctc/` and
`kernel/core/`.

## T2. Driver vocabulary (step 2)

Specific renames first:

| from | to |
|---|---|
| `kernel/service/` | `kernel/driver/` |
| `service_loader.c`, `service_boot.asm` | `driver_loader.c`, `driver_boot.asm` |
| `drivers/*/X_service.c` (ioc, sio, v9958, console) | `X_proto.c` |
| `user/sdk/src/console_service.c` | `user/sdk/src/console_proto.c` |
| `struct ipc_service_boot` | `struct driver_boot` |
| `struct ipc_service_api` | `struct driver_api` |
| other `ipc_service_` prefixes | `driver_` |
| the `call` member's `handle` parameter | `dependency_ref` |
| ROMFS file `services.man` | `drivers.man` |
| Makefile `SVC_` variables; word `svc` | `DRV_`; `drv` |

Then the rule, everywhere (identifiers, file and directory names, section
names such as `SERVICE_IO`, Makefile variables, tool commands and options,
printed labels such as the ledgers, test names, and comments):
`service`→`driver`, `services`→`drivers`, `Service`→`Driver`,
`SERVICE`→`DRIVER`. No exceptions. Skip `docs/validation/` and `work/`.

## T3. Headers (step 3)

| from | to |
|---|---|
| `include/zephyros/ipc.h` | `drivers/include/driver.h` |
| `include/zephyros/ioc.h` | `drivers/include/ioc.h` |
| `include/zephyros/ioc_protocol.h` | `drivers/include/ioc_protocol.h` |
| `include/zephyros/errno.h` | deleted: its 3 codes move to `drivers/include/ioc.h`; includers use `zos/errno.h` |
| `include/zephyros/kernel.h` | `kernel/include/kernel.h` |
| `include/zephyros/process.h` | `kernel/include/process.h` |
| `include/zephyros/platform.h` | `kernel/include/platform.h` |
| `include/zephyros/irq.h` | `kernel/include/irq_types.h` |
| `include/zephyros/romfs.h` | `formats/include/romfs.h` |
| `include/zephyros/zex.h` | `formats/include/zex.h` |
| `include/zephyros/driver.h` (`service.h` before step 2) | `formats/include/zmod.h` |
| `platform/zephyr80/hardware.{h,inc}` | `platform/zephyr80/public/` |
| `platform/zephyr80/{memory,irq}.{h,inc}` | `platform/zephyr80/private/` |

`abi/zos/` (including `protocol.h`, whole), `platform/zephyr80/config.mk`
and the `kernel/<part>/*.h` headers stay. Delete `include/`.

**Include spelling:** bare names (`"kernel.h"`, `"driver.h"`, `"zex.h"`,
`"hardware.inc"`); `"zos/…"` and `"kernel/<part>/…"` stay as they are.

**Include roots (`-I`):**

| build | roots |
|---|---|
| nucleus and kernel-linked tests | `.` `abi` `kernel/include` `drivers/include` `formats/include` `platform/zephyr80/public` `platform/zephyr80/private` `$(BUILD)` |
| drivers (`DRV_CFLAGS`, `MOD_CFLAGS`) | `abi` `drivers/include` `platform/zephyr80/public` `$(BUILD)` + the driver's own directory; **no `.`** |
| SDK and programs | unchanged |

Python tools that read these headers follow the new paths.

## T4. VFS (step 4, `kernel/vfs/`)

| new file | content (moved unchanged) |
|---|---|
| `path.c` | all of today's `path.c`; `ns_fold`, `ns_component_eq`, `ns_component_length`, `ns_path_under` |
| `workspace.c` | unchanged |
| `handles.c` | all of today's `process.c`; `vfs_ns_release_desc`, `vfs_ns_standard_handles` |
| `dev.c` | `ns_pub_*`, `vfs_ns_publication_endpoint`, `vfs_ns_install_publication`, `ns_device_bind`, `ns_enum_device`, `vfs_ns_pub_count` |
| `fs.c` | every `ns_fs_*`, `vfs_ns_fs_call`, `vfs_ns_fs_release`, `ns_enum_fs`, `vfs_ns_fs_endpoint` |
| `system.c` | all of `ns_file.c`; `ns_enum_romfs` |
| `router.c` | everything else in `ns.c` (bind/unbind/resolve, `ns_emit`, `ns_room`, `ns_enum_root`, `vfs_ns_enum`, `ns_fs_namespace_op`, `vfs_ns_file_call`, `vfs_ns_dir_check`, init/reset, `vfs_ready`, `vfs_phase`) |
| `vfs.h` | today's `vfs.h` + `ns.h` |

- A `static` function or variable used by another new file becomes
  extern, with `ns_`→`vfs_` (`ns_fold`→`vfs_fold`, …). Nothing else is
  renamed, except:
- `struct vfs_descriptor`→`struct vfs_handle_entry`,
  `vfs_descriptors`→`vfs_handles`, `VFS_FD_MAX`→`VFS_HANDLE_MAX`,
  `vfs_fd_active_count`→`vfs_handle_active_count`,
  `vfs_ns_release_desc`→`vfs_ns_release_entry`, and local `desc`
  variables of that type → `entry`.
- `vfs_phase` is live (`kernel/syscall.c`): keep it.
- Residency objects: `vfs_router`, `vfs_handles`, `vfs_path`, `vfs_dev`,
  `vfs_fs`, `vfs_system` are **cold**; `vfs_workspace` stays
  **fixed-required**. Update `config/residency.json`, the linker list and
  `tests/maptools.py`.
- System-call handlers stay in `kernel/syscall/`.

## T5. Root literals (step 5)

`"FS"`/`"SYSTEM"` in `kernel/vfs/` comparisons and the enum-of-`/` names,
`VFS_NS_FS_ROOT`, the `/SYSTEM` provider check, `tools/zmodpack.py`
`FS_ROOT`, `tools/bootprogram.py` `SYSTEM_PREFIX`, the stored boot path,
the monitor, programs, tests and smoke strings: lowercase. Path
normalization is unchanged.

## T6. SDK names (step 6)

| old | new |
|---|---|
| `zex_exit(unsigned)` | `void exit(int)` (passes `(unsigned)status` as today) |
| `zex_getinfo` | `getinfo` |
| `zex_write` / `zex_read` / `zex_poll` | `console_write` / `console_read` / `console_poll` |
| `zos_console_write` | deleted; callers use `console_write` (same body) |
| `zex_putc` + `zos_putc(char)` | `int putchar(int)`: the PUTC call; returns `(unsigned char)ch` or the negative error |
| `zos_getc` | `getchar` |
| `zos_puts` | `console_puts` (no newline, unchanged) |
| `zos_read_line` | `console_readline` |
| `zos_printf` / `zos_snprintf` | `printf` / `snprintf` |
| `zos_utoa` `zos_ultoa` `zos_itoa` `zos_ltoa` | `utoa` `ultoa` `itoa` `ltoa` |
| `zos_open close read write seek sync stat mkdir rmdir unlink rename chdir getcwd` | the same without `zos_` |
| `zos_ns_enum` | `list` |
| `zos_ipc_bind` / `_call` / `_unbind` | `bind` / `call` / `unbind` |
| `zos_ipc_raw_call` | unchanged name; declared only in `user/sdk/src/zos_internal.h`; tests that use it add `user/sdk/src` to their `INCLUDES` |
| `zos_exec` | `run` |
| `zos_args` / `zos_split` | `startup` / `splitargs` |
| `zos_xmem_alloc free read write info map` | `xalloc xfree xread xwrite xinfo xmap` |
| `zos_aperture_open` / `_close` | `aperture_open` / `aperture_close` |
| `zos_seg_info` / `zos_seg_map` / `zos_far_call` | `seginfo` / `segmap` / `farcall` |
| `zex_diag_*` | `diag_*` (same suffix); `zos.h` no longer includes `zos/diag.h`; the monitor includes it |

- Types, structs, macros and constants keep `zos_`/`ZOS_`. SDK-internal
  symbols (`zos_scratch`, `*_block`, `zex_runtime_error`, `zos_entry`,
  `zos_tail`, …) and header file names are unchanged. No aliases.
- A program-local symbol that collides with a new name gets its file's
  base name as a prefix (`hwtest.c`'s `open` → `hwtest_open`, `ipccopy.c`'s
  `call` → `ipccopy_call`).

## Collision rule (added after 46)

When two renames produce the same name, the more visible symbol (extern,
or called from other files) keeps the table name. The file-local symbol
gets a suffix: `_bundle`/`_data` for a variable, `_impl` for a function.
List each case under "Unmapped".
