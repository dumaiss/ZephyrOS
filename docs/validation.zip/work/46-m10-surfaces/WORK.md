# Task

**A refactoring only:** present the code with three clean audiences
(nucleus, resident drivers, applications). Every move and rename is fixed
in `TABLES.md`. You make **no design decisions**. No new mechanism, no
behaviour change, no rewording beyond the tables.

Source: the external architecture/developer-experience review
(2026-10-11). Baseline: the 45b tree (production `5a731321…`). Read
`work/00-WORKER.md` and `TABLES.md` first.

## Steps

Do these steps in order. Finish each one before you start the next.

| step | what | table | production image |
|---|---|---|---|
| 1 | tree moves | T1 | **hash identical** |
| 2 | driver vocabulary | T2 | changes (names, `drivers.man`) |
| 3 | headers by audience | T3 | **hash identical to step 2** |
| 4 | VFS split | T4 | changes (code order) |
| 5 | lowercase roots | T5 | changes (strings) |
| 6 | SDK names | T6 | changes (programs) |

**At the end of each step:** build the production image only (no clean
build, no tests, no matrix). Record the step, the production hash and
the ledgers in `progress.md`:
- fixed-core free and cold-half free;
- driver hot and boot used;
- common used;
- the gate stack worst case.

The full validation (below) runs once, after step 6. If it fails, use
`progress.md` to find the step that caused it.

Do not commit; the owner commits.

**Ledger rule.** Fixed-core free, driver hot/boot, common and the gate
stack must be identical to the baseline at every step. Cold-half free may
move only:
- in step 2, by the `services.man` → `drivers.man` name;
- in step 4, by at most 64 bytes, from statics becoming extern.

Program sizes in step 6 must not grow. Any other change: stop and report.

## Rules (no judgement calls)

1. **Unmapped.** If something is not in a table and not covered by a
   table's rule, leave it unchanged. List it in `progress.md` under
   "Unmapped" and in the record. Do not invent a name or a location.
2. **Moves are `git mv`.** A moved function keeps its body byte-for-byte.
   You may change only:
   - `static` to extern, as T4 states;
   - the include lines;
   - identifiers named in a table.
3. **Comments.** Apply the table's rules to comments mechanically, and fix
   any paths that the moves break. Do not otherwise reword comments: that
   is package 47's work.
4. **Docs.** Update `docs/` only where a path or identifier from the
   tables appears. Never touch `docs/validation/` or `work/`.
5. **Tests.** Change tests only by the same renames and path updates.
   - Do not delete, skip or weaken an assertion.
   - A test that fails for any other reason means stop and report.
   - Tests that pin the old layout or names (`tests/test_source_layout.py`,
     ledger-label checks, `tests/maptools.py`) switch to the new layout and
     names.
6. **Stop and report**, rather than working around, if:
   - a step's hash or ledger expectation fails;
   - a table entry does not match the tree;
   - two table rules conflict.

## Additions (the only new code)

1. **VFS file headers** (step 4): each new `kernel/vfs/*.c` file opens
   with one comment line naming its part:
   - `router.c`: the root router;
   - `handles.c`: the handle table;
   - `path.c`: path normalization;
   - `workspace.c`: the staging buffer;
   - `dev.c`: `/dev`, the DEVICE provider;
   - `fs.c`: `/fs`, the forwarding provider;
   - `system.c`: `/system`, the ROMFS provider.
2. **Negative include test** (step 3): a test in
   `tests/test_source_layout.py` compiles a one-line source that includes
   `"kernel.h"`, using the driver include roots from T3. The test passes
   when that compile fails.
3. **Allow-list check** (step 3): the same test file asserts the exact
   `-I` set of each build class in T3.

## Out of scope

- Documentation rewriting (package 47).
- `driver.json`, the system definition and `systemgen`.
- `__banked` far calls.
- The KonaOS rename.
- Splitting `abi/zos/protocol.h`.
- Any fix you notice along the way: list it in the record instead.

## Validation

```sh
make clean && make check
make <the full image matrix>
git diff --check
```

## Record

Write `docs/validation/<date>-m10-surfaces.md`. It contains:
- a per-step table: hash and ledgers;
- the "Unmapped" list;
- a confirmation that every image's tests pass with the same outcomes.
