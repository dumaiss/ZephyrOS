# Task

Finish the kernel side of everything a native shell needs, so M10 (ZShell and
core userland) is pure user space with no kernel changes. M9 already provides
the filesystem syscalls, working directory and synchronous `SYS_EXEC`. This
package adds the two missing pieces: **argument passing** to an executed
program, and a **boot-program setting**, so that switching the boot target
from the monitor to the shell is a one-line configuration change. It also
records the scope decisions for M10 in the architecture.

## Context

Dispatch after package 28 correction-01 is accepted and before package 29.
Read `work/00-WORKER.md` (including "Working efficiently"), architecture
sections 26.3, 26.7-26.9, 32.26, 32.39 and 35, `docs/{abi,zex-format}.md`,
`kernel/process/{exec,process}.c`, `kernel/syscall.c`, `kernel/main.c`
(`kernel_monitor_launcher`), `user/runtime/`, and `work/M9-REFERENCE.md`.
There is no backward-compatibility requirement.

Facts:
- `SYS_EXEC 05h` takes `{path:u16, length:u16}`. Children start with
  HL = 0000h and receive no arguments.
- Native page zero contains only the `RST 30h` vector at `0030h`; the rest of
  `0000h-00FFh` is zeroed by `process_prepare()`. Architecture 26.3 already
  anticipates a versioned startup block in the caller-visible low window.
- The launcher hard-codes `process_exec("/SYSTEM/monitor.zex", ...)` in
  `kernel/main.c`.
- Budget: the kernel ends one byte below a granule boundary (`8DFFh` after
  package 28), so any kernel code here costs one arena granule (36 -> 35).
  That crossing was already counted in the post-28 projection.

## Decisions (do not redesign)

- **The kernel transports bytes; user space parses them.** The kernel never
  splits, quotes or interprets arguments.
- **Startup block v1** lives in the child's own page zero, `0080h-00FFh` (128
  bytes):

  ```text
  0080h  u8   version = 1
  0081h  u8   tail_length  0..125
  0082h  u8   tail[126]    tail_length bytes, then NUL (always NUL-terminated)
  ```

  Every native process, including the boot program, gets a valid block (an
  empty tail when it has no arguments) and starts with **HL = 0080h**.
  Programs that ignore HL are unaffected.
- **`SYS_EXEC` argument block** becomes `{path:u16, length:u16, args:u16,
  args_length:u16}`:
  - `args_length` 0 means no arguments, and `args` is then ignored;
  - `args` follows the existing buffer-window rules (`0100h-DFFFh`, no
    overflow);
  - `args_length` greater than 125 returns `ZOS_EINVAL`;
  - all validation happens in the existing preflight, before any allocation.

  Update the pinned block size, static asserts and host tests.
- **No persistent kernel state.** The tail is read from the parent's bank
  only at the end of `process_prepare()`, after the executable source is
  closed and the VFS workspace is free. It goes through the existing checked
  bank-copy gate and the workspace staging view into the child's page zero
  (through `exec_bank_write`). Do not add a stable argument copy anywhere, in
  bank 7 or in common memory. The parent's bank cannot change during
  `process_prepare()`. If the copy fails, `process_prepare()` fails through
  its existing rollback, before suspension.
- **Boot program setting.** Add `ZOS_BOOT_PROGRAM ?= /SYSTEM/monitor.zex` in
  one build-configuration place (beside the mount configuration, for example
  `config/system.mk` included by the Makefile), compiled into the kernel as a
  constant string the launcher passes to `process_exec()`. Switching to the
  shell is then `ZOS_BOOT_PROGRAM := /SYSTEM/zsh.zex` plus adding the ZEX to
  the recovery manifest. No kernel edit is needed.

  The build validates the setting: an absolute path under `/SYSTEM` (it must
  boot without SD), at most 127 bytes, and naming a file present in the
  selected recovery manifest. Add a negative test for each case.

  There is no fallback chain. A launch failure keeps today's behavior (early
  console diagnostic and controlled halt), with the diagnostic printing the
  configured path instead of the literal word `monitor`. Rename
  `kernel_monitor_launcher` to `kernel_boot_launcher` and update its comment;
  it is no longer "temporary pre-shell".

## Requirements

- Kernel:
  - extend `SYS_EXEC` validation;
  - build the startup block for every launch, with an empty tail from the
    kernel launcher;
  - enter with HL = 0080h;
  - add the boot-program constant and launcher.

  Target: at most 300 bytes of kernel code and **0 bytes of new data**.
  Report both and attribute the code.
- User runtime (`user/runtime/`):
  - `zos_exec(path, args)`, where `args` may be NULL or empty;
  - startup glue that preserves HL at entry, so C `main(argc, argv)`, or a
    documented `zos_args()` accessor, can reach the block;
  - a small user-space splitter: whitespace-separated words, with
    double-quoted words allowed to contain spaces. Its exact rules are
    documented in `docs/zex-format.md`, are runtime policy only, and can
    change without kernel work.

  Programs that do not use arguments do not grow.
- Tests:
  - extend `fschild` (or add `fsargs.zex`) to echo its decoded startup block
    and argv;
  - `fstest` exec cases: no arguments; one word; several words with a quoted
    space; exactly 125 bytes; 126 bytes returning `EINVAL` with nothing
    allocated; an argument pointer outside the window returning `EINVAL`;
    arguments surviving nested exec at depth 2;
  - the kernel-launched program sees version 1 and an empty tail;
  - host tests for the argument-block layout, the startup-block layout and
    the boot-program validation.
- Documentation (this package owns these edits):
  - `docs/abi.md`: `SYS_EXEC` argument block, `EINVAL` cases, HL = 0080h;
  - `docs/zex-format.md`: startup block v1, runtime splitting rules;
  - architecture 26.3: the startup block is defined;
  - architecture 32.26 and 32.34: `FS_STATFS`/`df` are deferred until a
    consumer requires them, **not M10**;
  - architecture 35, the roadmap:
    - **M10 is user space only**: ZShell and core commands built on the M9
      syscalls, `SYS_EXEC` with arguments, and the `ZOS_BOOT_PROGRAM`
      setting;
    - **no signals and no IPC**, accepted for a single-process system:
      programs poll the console themselves, and a running child cannot be
      interrupted by its parent;
    - **M12 far code/data is mainly new syscalls and a user-program API**
      (auxiliary bank allocation, checked bank-to-bank copy, a far-call
      gate, overlays loaded by the user runtime), with no ZEX format or
      loader changes.

## Files

- `kernel/syscall.c`, `kernel/process/{exec,process}.c`, `kernel/main.c`, `include/zephyros/{syscall,process}.h`
- `config/system.mk` (new), `Makefile`, `tools/` (boot-program validation, with the mount tooling or beside it)
- `user/runtime/`, `tests/target/m9/`, `tests/test_m9_exec*.py`, `tests/test_m9_fs.py`
- `docs/{abi,zex-format,architecture}.md`

## Constraints

- No shell, no `df`/`FS_STATFS`, no environment variables, no signals, no
  PATH search in the kernel, no new syscall number (extend `SYS_EXEC`'s
  block), no persistent argument buffers, no common-memory growth.
- The production boot program stays the monitor in this package.

## Validation

At the `00-WORKER.md` efficiency defaults, run one formal batch in the
background:

```sh
make clean && make check
make m9-exec-selftest m9-fs-selftest
python3 -m unittest tests.test_m9_exec tests.test_m9_exec_sim tests.test_m9_fs tests.test_syscall_sim -v
git diff --check
```

Also prove the setting end to end without changing production: build once
with `ZOS_BOOT_PROGRAM=/SYSTEM/fstest.zex` (or another acceptance ZEX) into
a separate build directory and show in the simulator that it is the program
launched. Report:
- the `bank7:` and common ledgers before and after;
- the formal run's wall-clock time;
- every skip in the listed suites, with its reason.

Hardware:
- production: `make smoke-hardware` (banner-only contract), with the
  operator confirming the monitor still works;
- the exec image: `make smoke-hardware-m9-exec`, showing the argument cases.

Record `PENDING` if hardware is unavailable.

## Acceptance criteria

- A program executed with arguments receives them byte-exact in the startup
  block, `argv` splitting works in user space, and every invalid argument
  fails before allocation.
- Changing `ZOS_BOOT_PROGRAM` alone selects the boot program, with build-time
  validation.
- The kernel adds at most 300 bytes of code, no data and no common memory.
- The architecture records M10 as user space only, `df` deferred, no
  signals/IPC accepted, and M12 as syscalls plus user API.
