# Task

Close M9. Run the complete section 33 acceptance matrix with `fstest.zex` on
the simulator and on physical hardware. Reconcile documentation with what was
built, and record durable validation evidence. Correct only defects that this
acceptance exposes.

## Context

Dispatch only after packages 30 (with its correction), 30b and 30c are accepted, so M9 closes on its optimized ledger. There is no backward-compatibility requirement (M9-REFERENCE). Read `work/00-WORKER.md`,
architecture sections 32-34, `work/M9-REFERENCE.md`, and every M9 package
contract (25-30) as the design record. Packages 25-30 each produced partial
evidence. This package proves the pieces together against one final tree and
one set of image hashes.

## Requirements

- Freeze the tree before final validation. All evidence below must come from
  the same source state, and image hashes are recorded once and quoted
  consistently.
- `fstest.zex` must cover every item in the section 33 list. Add any case
  that is still missing:
  - namespace: `/`, `/SYSTEM`, root visibility, shadowing,
    case-insensitivity, absolute and relative paths, `.`/`..`, CWD crossing
    between `/` and `/SYSTEM`;
  - ROMFS: read, stat, enumerate, `EROFS`;
  - IOC-FAT: open, create, open with `TRUNC`, close, read, write, sync,
    seek, stat, mkdir, rmdir, rename, unlink;
  - sizes 1, 127, 128, 129, 511, 512, 513 and >64 KiB, each written then read
    back and compared by a hash computed inside the program;
  - IOC-FAT cache: repeated-read hit, miss/fill, cross-slot reads,
    write-through update/invalidate, no stale data after a write through the
    other open file, generation invalidation;
  - error paths: missing file, wrong type, descriptor-pool exhaustion
    (`EMFILE`), stale
    backend handle, unavailable SD, failed confirmed write, cross-filesystem
    rename `EXDEV`;
  - process lifecycle: inherited CWD, child CWD isolation, child descriptors
    closed on exit, repeated exec/exit without leaks.

  Cache evidence comes from the IOC-FAT test-only counters (package 30),
  exposed to `fstest` through a `TEST-ONLY HOOK` diagnostic. They must be
  absent from the production build, which mapcheck and the module checks
  enforce.
- Hardware cases that cannot be produced deterministically on demand (stale
  backend handle, failed confirmed write) are proven on hardware where
  practical. For stale handles, use an operator-assisted card removal and
  reinsertion that bumps the FS2 generation while a file is open. Otherwise
  they are proven in the simulator against the fake FS2 server, and the record
  says which. Never claim a physical result that was not observed.
- Run these hardware rows, flashing each named image:
  1. Production, with a FAT card.
  2. Production, no card.
  3. The M9 acceptance image with a card: the full `fstest` transcript.
  4. The M8 fallback rows still pass (`m8-fb-*`).

  Rerun the monitor interaction on production: the monitor still launches
  from `/SYSTEM` and works.
- Documentation:
  - Update `docs/architecture.md` section 34 (M9 COMPLETE only when every
    required row passed) and add section 32 implementation notes that point to
    the detailed docs.
  - Finalize `docs/vfs.md`, `docs/abi.md` (FS_* and EXEC, errors),
    `docs/devices.md` (BLOCK class, deferred driver), `docs/module-format.md`
    (ABI v3), `docs/memory.md` (descriptor pool, CWD pool, staging, exec save
    areas, IOC-FAT cache BSS, final `bank7:` ledger),
    `docs/boot.md` (VFS lifecycle) and `README.md`.
  - Remove stale statements that say ROMFS names are case-sensitive, that
    `process_exec` is single-depth, that `ZDEV_STORAGE` exists, or that the
    filesystem is deferred.
  - **Fold the M10-M12 target architecture into `docs/architecture.md`.**
    `docs/m10-m12-target-architecture.md` says it supersedes section 35 and
    should be folded in once M9 closes. This package is that point, and no
    other package may be active while it runs. Steps:
    - replace section 35 with the target's sequencing (M10 extended
      memory/far code/data + ZEX v2, M11 diagnostics, M12 shell and core
      userland) and add its M10-M12 sections, renumbering consistently;
    - remove the superseded M10/M12 wording package 28b wrote into
      section 35;
    - keep the M9 facts the target relies on (startup block v1, `SYS_EXEC`
      arguments, `ZOS_BOOT_PROGRAM`, the SDK, the bank-7 and common budget,
      including the ceiling pinned by 30c);
    - reconcile the target's M12 boot policy (`/SYSTEM/shell.zex` with a
      monitor fallback) with the M9 launcher as a stated M12 change, not an
      M9 one;
    - record whether the 30b M10 residency estimate fits the final M9
      ledger. If it does not, state explicitly that a kernel-residency
      architecture decision is required before M10 (target 1 and 2.18).

    After folding, leave `docs/m10-m12-target-architecture.md` as a short
    pointer (or delete it), so the target lives in one document.
  - Mark `docs/filesystem.md` as the historical proposal, superseded by
    architecture section 32.
- Write `docs/validation/<date>-m9-filesystem.md` with:
  - the tree identity;
  - the image and module hashes;
  - the final `bank7:` ledger, checked against the architecture 32.39
    targets (32-granule arena floor holding the boot set, slack >= 1 KiB),
    plus the IOC-FAT cache slot count;
  - the test counts, including skips and why;
  - the simulator transcripts;
  - the hardware transcripts saved as `*-hw-transcript.txt` beside it;
  - an explicit `PASS`/`PENDING`/`NOT RUN` matrix.

  Validation records and work packages are deliberately not tracked in git.
  Extend `tests/test_docs_evidence.py` so every evidence file the record cites
  must exist on disk, without requiring git tracking.
- Do a final architecture conformance pass against section 32.36. For each of
  the section 32.36 invariants (count them; the list grew during M9), give a one-line pointer to the code, check or test that
  enforces it. If an invariant has no enforcement, add a focused mechanical
  check (mapcheck, source-layout or host test) when that is cheap. Otherwise
  list it as a finding; do not refactor here.

## Files

- `tests/target/m9/`, `tests/test_m9_*.py`, `tests/test_docs_evidence.py`, `tools/{mapcheck,serial_smoke}.py`, `Makefile`
- `docs/*.md`, `docs/validation/`, `README.md`

## Constraints

- No new features. Any defect beyond a narrow fix is reported to the
  supervisor for a correction package; do not redesign it here.
- No firmware changes. The mechanisms proven by M1-M8 must still work on the
  current tree; historical images and transcripts are not oracles.

## Validation

```sh
make clean && make check
make zmod-test romfs-test zex-test monitor-test ioc-test hid-test v9958-test \
     m8-selftest m8-fallback-selftests \
     m9-vfs-selftest m9-provider-selftest m9-fs-selftest m9-exec-selftest \
     m9-iocfat-selftest m9-selftest
python3 -m unittest discover -s tests -v
git diff --check
```

This is the one package that builds the full matrix, including the Mn-1 (M8)
rows: build every image **once**, then run the full suite **once**.
Do not repeat the matrix after documentation-only edits; rerun only the tests
those edits can affect (for example `tests.test_docs_evidence`).

```sh
sha256sum build/zephyros.bin build/modules/*.zmod build/modules/*.zex build-m9-*/*.bin
make clean && git status --short
```

Run the hardware rows listed above. Production rows use `make smoke-hardware`
on `build/zephyros.bin` plus the V9958/HID operator check (the serial `normal`
mode cannot see a V9958-bound console). `make smoke-hardware-m8` checks the
M8 integration image, not production. Also run `smoke-hardware-m9` and the
`m8-fb-*` targets, each on the image its preflight names.

## Acceptance criteria

- Every section 33 item has simulator evidence, and either physical evidence
  or an explicit, justified simulator-only note.
- All hardware rows pass with transcripts, or M9 stays open with named
  `PENDING` rows.
- The documentation matches the implementation, and the validation record is
  durable and checked by tests.
- The final ledger meets the section 32.39 targets (arena floor, slack of at
  least 1 KiB, the common ceiling pinned by 30c), or M9 stays open with the
  shortfall stated.
- `docs/architecture.md` contains the folded M10-M12 architecture and states
  whether M10 fits the end-of-M9 residency or needs a residency decision
  first.
- The tree is clean after `make clean`.
