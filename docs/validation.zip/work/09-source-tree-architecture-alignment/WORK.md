# Task

Align the M0-M4 source tree with `docs/architecture.md` section 3 without changing runtime behavior, ABI, memory placement, linked symbol names, object order, ROM/module bytes, or accepted hardware behavior. The current implementation and tests are authoritative and working; this task is an ownership/path refactor plus enforcement against regressions.

## Context

Section 3.1 makes directory ownership architectural. In particular, `platform/zephyr80/` may contain only board constants and build configuration; it must not contain C functions, assembly routines, reset code, bank-switch code, device sequences, polling, or other byte-emitting implementation.

The current tree violates that boundary. Use these ownership moves while preserving each source unit and its existing object name/link order:

- `platform/zephyr80/reset.asm` -> `boot/shadow_copy.asm`
- `platform/zephyr80/banking.asm` -> `kernel/memory/banking.asm`
- `platform/zephyr80/page_zero.asm` -> `kernel/syscall/page_zero.asm`
- `platform/zephyr80/syscall_entry.asm` -> `kernel/syscall/entry.asm`
- `platform/zephyr80/irq.asm` -> `kernel/irq/init.asm`
- `platform/zephyr80/irq_sources.c` -> `drivers/ctc/ctc.c`
- `platform/zephyr80/sdcc_helpers.asm` -> `kernel/runtime/sdcc_helpers.asm`
- `platform/zephyr80/selftest.asm`, `selftest.inc`, `irq_selftest.asm`, and `irq_selftest.inc` -> `tests/target/zephyr80/`

`boot/start.asm`, `kernel/irq/{entry.asm,vectors.asm,irq.c}`, the device/module mechanisms, and the SIO driver are already under the correct owners. Test-only driver fixtures may remain where they are unless a move is required to eliminate a platform dependency; do not broaden this into a subsystem redesign.

The platform description is also missing the architecture's C-visible memory constants, IRQ mapping headers, and build configuration split. Keep `hardware.h/.inc` for ports and register constants; create `memory.h` alongside `memory.inc`, `irq.h/.inc` for IRQ/vector mapping constants, and `config.mk` for the existing Zephyr-80 build include/configuration values. Move existing constants rather than duplicating definitions. `include/zephyros/platform.h` should include the platform constant headers needed by C code while keeping all existing API declarations and symbol names stable.

## Requirements

- Perform the moves above with history-preserving file moves where practical. Do not merge source units, rename exported symbols, change assembly areas, reorder linker inputs, or rewrite working routines.
- Update `Makefile` prerequisites/source paths and include `platform/zephyr80/config.mk`. Platform configuration must not list or own kernel/boot/driver implementation sources.
- After the refactor, source-controlled `platform/zephyr80/` may contain only `.h`, `.inc`, and `.mk` constant/configuration files. No file there may emit target bytes or define a C/assembly routine. Keep instruction-emitting macros out of platform includes.
- Place memory-region constants in `memory.h/.inc` and IRQ/vector/channel mapping constants in `irq.h/.inc`; keep C/assembly values paired and extend the existing parity tests. Hardware port/register constants remain in `hardware.h/.inc`.
- Preserve the existing `platform_*` function API for this structural pass even when its implementation moves under `kernel/` or `drivers/`; API renaming is out of scope.
- Update live comments and documentation that name old paths, including `README.md`, `docs/memory.md`, `include/zephyros/platform.h`, and self-test comments/headers. Do not rewrite dated acceptance transcripts or historical results.
- Add `tests/test_source_layout.py` to assert the required owner directories/files, reject target-code files under `platform/zephyr80/`, and reject references to the removed implementation paths in live build/source documentation.
- Treat root `build*` directories as generated output: make `.gitignore` cover all current build variants and make `make clean` remove all generated build variants. Do not delete or ignore source directories.

## Files

Likely files to move, create, or modify:

- `boot/shadow_copy.asm`
- `kernel/memory/banking.asm`
- `kernel/syscall/page_zero.asm`
- `kernel/syscall/entry.asm`
- `kernel/irq/init.asm`
- `kernel/runtime/sdcc_helpers.asm`
- `drivers/ctc/ctc.c`
- `tests/target/zephyr80/`
- `platform/zephyr80/{hardware.h,hardware.inc,memory.h,memory.inc,irq.h,irq.inc,config.mk}`
- `include/zephyros/platform.h`
- `Makefile`
- `.gitignore`
- `README.md`
- `docs/memory.md`
- `tests/test_source_layout.py`

## Constraints

- This is not authorization to fix, simplify, or redesign working code. No functional logic, public/internal ABI, ZMOD format, registry/IRQ semantics, memory map, module arena geometry, serial protocol, or validation expectation may change.
- Preserve all linker areas, addresses, exported symbols, object filenames, object ordering, compile defines, image names, and module manifests.
- Do not reintroduce MAME as a validation dependency.
- Preserve the recorded physical-hardware evidence. If byte identity cannot be maintained, stop and report the exact artifact and reason instead of accepting new hashes silently.
- Preserve unrelated user changes and generated hardware-acceptance records.

## Validation

Before moving files, build every variant and record SHA-256 hashes for all generated `.bin` and `.zmod` artifacts in `/tmp`. Then perform the refactor and run from a clean tree:

```sh
make clean
make check
make syscall-selftest
make irq-selftest
make m3-selftest
make m3-fallback
make zmod-test
make m4-loader-selftest
make m4-selftest
make m4-placement-selftest
make m4-failure-selftest
python3 -m unittest discover -s tests -v
git diff --check
```

Compare every post-refactor ROM and ZMOD hash with the pre-refactor baseline. In particular, the hardware-accepted M4 hashes recorded in `docs/validation/2026-10-02-m4-acceptance.md` must remain unchanged. Run a final `make clean` and verify no generated `build*` directory remains and `git status --short` contains no generated artifacts.

## Acceptance criteria

- The source tree satisfies `docs/architecture.md` section 3 and the new layout test enforces the boundary.
- `platform/zephyr80/` contains constants/configuration only; all executable implementation has an owning boot, kernel, driver, or target-test directory.
- All host builds and tests pass with no new warnings or skips when all fixtures are built.
- Every ROM and ZMOD artifact is byte-identical to its pre-refactor counterpart, so the existing physical-hardware acceptance remains applicable.
- Documentation and build dependencies contain no stale references to the removed implementation paths.
- `make clean` leaves a clean source tree with no generated build directories.
