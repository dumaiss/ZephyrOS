# Task

Complete M1 by turning all memory/image invariants into build failures, adding positive and negative validation coverage, providing a bounded serial-output check for the physical machine, finishing operator documentation, and recording final M0/M1 physical-hardware acceptance evidence without expanding kernel functionality.

## Context

The accepted implementation now has a 128 KiB two-page ROM, page-zero/reset content, a bank-7 kernel body at `2000h-DFFFh`, permanent common code/data at `E000h-FEFFh`, a common stack at `FF00h-FFFFh`, banking primitives, and the `RST 30h` gate. `docs/architecture.md` section 12 requires host-side validation of page zero, common regions, stacks, banked sections, and entry points.

There is no Zephyr-80 machine simulation in the validation environment. Target execution must therefore be validated on physical hardware through the SIO0/B serial console. Host-side checks must remain complete enough to catch image and layout errors before a ROM is programmed, while the acceptance record must distinguish automated host validation from an observed hardware boot.

## Requirements

- Implement `tools/mapcheck.py` as the single authoritative post-link layout check, using the generated map/symbol artifact rather than source-text guesses. Invoke it automatically from the default build after linking and before considering the ROM complete.
- Fail with precise symbol/region diagnostics when any of these conditions is violated:
  - page-zero content lies outside `0000h-00FFh`, overlaps reserved bytes, or the reset copier reaches `0030h`;
  - the native vector is absent, not at `0030h`, or not exactly the expected jump stub;
  - bank-7 OS sections leave `2000h-DFFFh`;
  - common sections leave `E000h-FEFFh`;
  - linked code/data overlaps `FF00h-FFFFh` or declared stack bounds are inconsistent;
  - reset/common/syscall entry symbols fall outside their required regions;
  - any mapping-changing instruction path is linked outside common memory;
  - image input contains bytes that the packer would silently discard or place ambiguously.
- Make the packer independently validate final image size, page fill, reset-copier mirroring, page ownership, and that ROM page 1 supplies the bank-7 body. Emit a small machine-readable image manifest with sizes, hashes, fill counts, and key entry addresses for debugging/reproducibility.
- Add unit tests with deliberately invalid fixture maps/images for every rejection class. Tests must assert useful diagnostic text as well as nonzero exit status. Keep fixtures small and deterministic.
- Add `make check` to run unit tests, map validation, image validation, a clean rebuild comparison proving reproducible binaries, and any available static/disassembly checks. It must fail on warnings from project-owned C/assembly where the toolchain permits warning promotion.
- Add a serial capture/check tool (for example `tools/serial_smoke.py`) and `make smoke-hardware`. It must accept the serial device and baud rate as explicit arguments or environment variables, configure 115200 8N1/raw mode, capture output with a bounded timeout, and verify the exact normal banner. A second invocation must verify `syscall selftest: OK` from the self-test image. The target must fail clearly when the serial device is absent or output is incomplete; ordinary host-only `make test` may skip hardware checks explicitly.
- Ensure `make clean` removes only repository build artifacts and never serial devices, captured evidence, or user data outside the build directory.
- Update `README.md`, `docs/boot.md`, `docs/architecture.md`, and `docs/abi.md` so commands, image layout, map, ABI, physical programming steps, serial-capture procedure, expected output, and known M1 limitations agree with the implementation.
- Add a dated acceptance record under `docs/validation/` containing tool versions, commands, binary hashes, host-check results, serial settings, and physical-hardware results. Mark hardware as pending rather than claiming success if it was not actually run.

## Files

Likely files to create or modify:

- `tools/mapcheck.py`
- `tools/pack_image.py`
- `tools/serial_smoke.py`
- `tests/`
- `Makefile`
- `.gitignore`
- `README.md`
- `docs/architecture.md`
- `docs/boot.md`
- `docs/abi.md`
- `docs/validation/`

## Constraints

- Validators must derive facts from build artifacts and explicit layout declarations; do not maintain a second undocumented memory map in test code.
- Do not weaken a check merely to accommodate current output. Fix placement or make the intended exception explicit and tested.
- Do not modify or depend on writable state in adjacent repositories.
- Do not add kernel features. This stage validates and documents M0/M1 only.
- Do not report physical-hardware acceptance without an observed serial transcript or explicit human confirmation.

## Validation

```sh
make clean
make
make test
make check
make smoke-hardware SERIAL_PORT=/dev/ttyUSB0
git status --short
```

Also exercise representative negative fixtures directly and inspect the final map, manifest, disassembly, and serial transcripts. Program the normal and self-test ROM images on physical Zephyr-80 hardware and record their exact serial output. If hardware is unavailable, report the target checks as pending rather than treating host checks as a substitute.

## Acceptance criteria

- Every layout/image invariant named in `docs/architecture.md` is automatically enforced during the default build.
- Every validator rejection class has a passing negative test with actionable diagnostics.
- Clean builds are reproducible and all project tests/checks pass.
- Normal and syscall-self-test images produce the expected serial output on physical hardware.
- Documentation is consistent and sufficient for another developer to build, inspect, program, and validate the image.
- The validation record truthfully distinguishes completed host checks from completed or pending physical-hardware testing.
- M1 is fully accepted only when the automated host checks pass and the physical Zephyr-80 results satisfy the architecture's M0/M1 criteria that can be exercised without machine simulation.
