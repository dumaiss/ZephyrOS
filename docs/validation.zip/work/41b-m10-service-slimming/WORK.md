# Task

M10 step 5 (architecture 36.24): **host assembly.** Reduce the
resident-driver machinery to what a trusted, single-tasking machine with
permanent, build-selected drivers needs:

- drivers linked at their final bank-6 addresses on the host, so the
  loader becomes a copier;
- endpoint numbers **and inter-driver dependencies** resolved on the host;
- validation in the nucleus only;
- near-direct driver-to-driver calls.

Measure the result and project 42a/42b. Behaviour is unchanged.
Production bytes change; record the new hash.

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md` (decisions 11-16);
- architecture 36.4, 36.7, 36.8, 36.11, 36.12, 36.20 and 36.22;
- the package-41 record (`docs/validation/2026-10-08-m10-driver-services.md`).

**Terminology:** the architecture now says **driver** where the code says
*service* (resident driver domain, driver bootstrap interface). Rename the
ledger lines to `driver hot:` and `driver boot/bulk:`, and update the
docs' wording. C identifiers (`service_*`, `SERVICE_IO`) may stay.

Today the packer already computes every bank-6 address. At each boot the
loader re-derives the placement, applies the ZREL records through the copy
gate, checks dependencies and registers endpoints. The production loader
is 5,911 bytes. Driver wrappers are 600-900 bytes each.

## Requirements

1. **Host-linked images** (36.11).
   - `tools/zmodpack.py` links each driver's hot, `SERVICE_IO`, boot and
     bulk segments at their final addresses (the existing tier plan). No
     relocation records.
   - Duplicate, tier-fit and overlap checks move to the packer.
   - Bump the driver ABI version.
2. **Host-resolved dependencies.** A driver declares symbolic protocol
   dependencies; the packer resolves each to a typed endpoint/object
   reference and emits a dependency table.
   - The console's use of VIDEO, INPUT and SERIAL is wired this way.
   - No driver looks another up at run time; remove driver-side lookup
     calls.
3. **Copier loader.** `kernel/service/service_loader.c`:
   - copies the segments;
   - installs the host-built endpoint and dependency tables;
   - runs each boot segment and hot init once.

   Remove `service_relocate`, runtime registration and the dependency
   checks. Keep only the bounds checks that protect the nucleus. Report the
   loader's production bytes against 5,911.
4. **Host-assigned endpoint numbers,** internal to the nucleus.
   `SYS_IPC_LOOKUP` stays for applications until 42a removes it. Remove
   runtime `register` paths with no caller.
5. **Validation in the nucleus only** (36.8, 36.22). Delete frame and
   argument re-validation in the drivers. Keep only checks that stop a
   driver indexing outside its own arrays or programming hardware outside
   its range, and name each one.
6. **Near-direct driver-to-driver calls** (36.7): dispatch through the
   endpoint table, with the frame passed by reference, no copy and no bank
   switch. Measure before and after.
7. **Wrapper itemization after 1-6,** per driver.
   - Add a shared table-driven dispatch layer only if a driver still
     spends more than 300 bytes on dispatch.
   - Fixed-core growth must be at most 300 bytes.
8. **Projection for 42a/42b,** against 36.20:
   - **bank 7:** the root router, the three static providers, the
     publication table, the handle table and bind/call/unbind/`ns_enum`;
   - **bank 6:** IOC-FAT as the `/FS` driver (6,006 + 637 BSS, plus its
     wrapper);
   - **the arena:** removed.

## Constraints

- No protocol changes and no namespace work.
- **Tests:** delete the runtime-relocation, registration, lookup-between-
  drivers and dependency-check tests, replacing them with packer tests.
  Outcome tests pass unchanged. One-line reason per deletion.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-host-assembly.md`.
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation (once, on the final source)

```sh
make clean && make check
make console-integration-selftest console-fallback-selftests video-selftest
make ioc-selftest hid-selftest ipc-selftest m9-selftest
git diff --check
```

The record covers:
- the five ledgers before and after;
- the loader bytes;
- per-driver hot bytes before and after;
- the 42 projection;
- the gate-stack worst case and the driver-stack high-water mark;
- the production hash;
- the per-area diff breakdown.

## Hardware (owner)

One run that also covers package 41's checks:
- `make smoke-hardware`;
- the console with the keyboard and the V9958;
- the serial console;
- ESC `c`.

## Acceptance criteria

- Drivers are host-linked, with dependencies and endpoints host-resolved.
- The loader copies and installs only.
- No driver re-validates or looks another up.
- Every listed image passes.
- The loader and the hot tier shrink measurably.
