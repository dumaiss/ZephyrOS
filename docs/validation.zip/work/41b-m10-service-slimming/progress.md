# 41b-m10-service-slimming — checkpoint status

Contract: [WORK.md](./WORK.md).  Terminology: the architecture says
*driver* where the code says *service*; the ledger lines are now
`driver hot:` / `driver boot/bulk:`.

## Done, with evidence

* **Baseline captured before edits** (package-41 production build):
  loader 5,679 + 232 = **5,911 bytes**; ledgers fixed 7,083/7,752/768/781,
  cold 24,153 end `BE59h`, 13 arena granules, data 1,208 at `DA00h`;
  driver hot 13,216, boot/bulk 2,170; common 2,230; production hash
  `21ca993c...`; ipc-selftest per-call T states (null 18,005,
  vfs-512-direct 93,653, staged 118,111, con256 110,446.8,
  console256 202,937).  Saved in the session workspace.

* **Service ABI 3 + host linking** (`tools/zmodpack.py`,
  `include/zephyros/service.h`): segment records carry the final base and
  an absolute boot entry; endpoint records carry the host-assigned number
  and the absolute dispatch entry; dependency records carry the resolved
  endpoint number; the header relocation fields are zero and
  `parse_service_container` refuses nonzero ones.  `pack --set` links an
  image against its whole load-order set (tier plan, endpoint numbers,
  dependency resolution, duplicate/tier-fit/overlap checks); `services`
  validates the linked set and writes the manifest + plan report.
  Verified: the production set links to its planned bank-6 addresses
  (hot 8D66h/73E2h/8772h/6000h/90E4h, boot 0000h/0030h/006Ch, bulk
  5800h) with the driver ledgers confirmed by the `services` command.
* **Loader is a copier** (`kernel/service/service_loader.c`): reads the
  manifest, bound-checks each container's final layout, copies segments,
  zeroes BSS, installs the endpoint records and the resolved dependency
  array, runs the boot segment and the hot init.  No relocation, no
  placement policy, no dependency check, no runtime registration.
  Loader bytes: `_WINDOW` 4,461 + `_WINDOW_DATA` 167 = **4,628**
  (was 5,911, -21.7 %).
* **Near-direct driver-to-driver calls** (`kernel/ipc/ipc.c`): the
  outermost call stages one frame through the fixed boundary buffer; a
  nested call passes the caller's frame by reference with no copy and no
  bank switch.  `api_register_ep`/`api_lookup` removed; the dependency
  array and boot bundle live in the fixed core.
* **Drivers**: init entries take `struct ipc_service_boot`;
  HID reads its host-resolved IOC number, the console composes HID,
  SERIAL and VIDEO from its resolved dependency row; the IOC service's
  duplicate bulk-length checks are gone (the core validates), the kept
  checks are named.
* **Production build green** with the new format: fixed required 6,955
  (room 909), cold 22,935 end `B997h` (16 granules, 3 free), 12,930 hot /
  2,170 boot/bulk, common 2,230.  Final hash
  `11a9bd2b68c7473eab6b624de4155a45ac738f668033b493c965a92fb7016c2e`.
* Host tests: `tests.test_service_images` rewritten as packer tests
  (31 pass), HID/IOC/V9958/driver-ABI/console-acceptance updated and
  green; the production replay (monitor session, IOC-FAT arena lane)
  passes.

## Validation, measurements and report

* **Every listed image green on the final sources**: `make clean && make
  check` (800 tests OK, 176 conditional skips, reproducible hash),
  console integration 6/6, fallback 3/3 + 1 skip, video 4/4, ioc 2/2,
  hid 2/2, IPC 53/53 (six images placed, `driver hot 6057/32768`),
  m9 7/7.  Two validation findings fixed: the pack rules now wait for the
  whole `--set` object list (parallel-build race), and the IOC/HID/video
  replays parse the renamed `driver <name>:` evidence lines.
* **Near-direct measurement** (same instrument as package 39): null
  18,005.0 -> 15,455.5 T (-14.2 %), vfs-512-direct 93,653.0 -> 87,253.5,
  vfs-512-staged 118,111.0 -> 111,711.5, console256 202,937.0 ->
  198,450.5.  Gate stack 213/256; driver stack high-water 246/512.
* **Report written**: `docs/validation/2026-10-09-m10-host-assembly.md`
  (ledgers, loader bytes, per-driver hot bytes, wrapper itemization
  97-332 bytes per driver, 42a/42b projection, retired tests, hardware
  note).  Hardware run remains with the owner.

## Decisions

* `pack` requires `--set` (every manifest of the load order): the plan
  lives in one place and every image of a build links against the same
  addresses.  The Makefile passes `$(ZOS_SERVICES)` manifests plus the
  synthetic IPC manifests for the IPC image.
* Dependency records are `class, instance, number(u16)`; 0 means an
  optional dependency this build does not export.  The optional flag is
  consumed by the packer (a missing required dependency is a pack error).
* Endpoint numbers are assigned 1..N in load order and endpoint-table
  order; the nucleus scans its small table by number.
* The loader keeps only protective bounds: every table inside the
  container, every segment base + allocation inside its role tier, every
  entry/dispatch inside its segment image, dependency numbers at or below
  the installed high-water mark.

## Rejected

* Rewriting the containers in place from the `services` command (build
  instability); `--set` at pack time keeps the one linked format.
* Keeping the runtime `register_ep` path (no caller after the loader
  installs host records).
