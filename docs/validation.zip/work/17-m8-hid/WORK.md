# Task

Implement `hid.zmod` as a class-aware keyboard/text driver layered solely on
the accepted IOC interface, with bounded local buffering and failure behavior
that never wedges console polling or compromises the SIO fallback.

## Context

Start only after package 16 is reviewed and physically accepted. Read
`work/00-WORKER.md`, architecture sections 30.5 and 30.7-30.9, and the HID/IOC
sections of `work/M8-REFERENCE.md`. The deployed MCU already translates USB
boot-keyboard reports to terminal bytes and maintains the authoritative
128-byte queue. ZephyrOS must consume it; the MCU firmware is not changed.

## Requirements

- Add `include/zephyros/hid.h` with `zhid_ops`, text-read semantics and reserved
  key-event/gamepad shapes. M8 implements only `ZCAP_HID_TEXT`; absent methods
  remain null and absent capabilities must return `ZDEV_ENOTSUP` through any
  helper/tests rather than being inferred from the name.
- Build `drivers/hid/` as an ABI-v2 resident ZMOD. Its init uses only
  `api->device_find(ZDEV_IOC, ZCAP_IOC_COMMAND|ZCAP_IOC_STATUS, ...)` and
  `api->device_interface(...)`; it has no direct imported IOC-module symbol and
  performs no name lookup. Store the returned `zioc_ops` and opaque state.
- Register exactly `hid.keyboard0`, class `ZDEV_HID`, with
  `ZCAP_HID_TEXT|ZCAP_CHAR_IN|ZCAP_CONSOLE_IN`, `zhid_ops`, and input-only
  `zchar_ops`. It has no output methods/capabilities. A missing or malformed IOC
  dependency makes init fail transactionally without disturbing SIO or IOC.
- Use a 16-byte power-of-two local ring. `poll` first reports buffered data;
  otherwise query IOC semantic status and issue `CMD_HID_INPUT` only when
  `ZIOC_STATUS_HID_PENDING` is set. Request exactly the ring's free space (and
  never above the protocol's 24-byte response maximum) because MCU reply bytes
  are dequeued.
- Validate transport success, `RSP_HID_INPUT`, controller status, reply length
  at least two and at most 26, returned byte count no greater than requested,
  and ring capacity before committing any byte. Malformed replies leave the
  ring unchanged. Preserve translated bytes exactly, including NUL/control and
  multi-byte VT100 key sequences.
- `getc` is nonblocking: return the oldest byte or `ZDEV_EAGAIN`. `read_text`
  returns 0 when nothing is available, a positive count up to `max_len`, or a
  negative error. `poll` returns 1/0/error under normal character conventions.
- Implement the proven stuck-doorbell guard: an asserted semantic doorbell
  followed by failed/empty fetch imposes a 64-poll penalty before another IOC
  command; successful data or a released doorbell clears it. Do not cache raw
  RR0, CTS, port, or SIO knowledge in HID.
- Add a fake-IOC ZMOD or host fixture that proves dependency discovery,
  interface verification, fetch-on-doorbell only, exact request sizing,
  wraparound/order, controls/escape sequences, overflow/malformed reply
  atomicity, transport errors, stuck penalty, and IOC disappearance/init
  rollback. Static tests must reject SIO1 port/status constants and direct
  `IN`/`OUT` in all HID sources.
- Add HID and IOC to the M8 ROMFS/test manifests in deterministic order. The
  existing preference policy should yield HID input plus SIO output at this
  stage. Add a target test that types through USB HID while echo/output remains
  visible on SIO0/B, then forces/omits HID and confirms SIO input fallback.

## Files

- `include/zephyros/hid.h`
- `drivers/hid/`, `modules/manifests/hid.json`
- `kernel/main.c`, `recovery/manifest.json`, M8 test manifests
- `tests/test_hid*.py`, `tests/modules/`, `tests/target/m8/`
- `Makefile`, `tools/{mapcheck,serial_smoke}.py`
- `docs/{devices,architecture}.md`, `docs/validation/`

## Constraints

- No raw SIO1, RR0, CTS/DCD, IOC framing, USB stack, key translation, gamepad,
  V9958, filesystem, or firmware implementation belongs in HID.
- Do not make normal console code call HID directly. Binding remains registry
  policy, and early/panic SIO remains independent.

## Validation

```sh
make clean
make check
make zmod-test
make ioc-test
make hid-test
make m8-hid-selftest
make monitor-test
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/modules/monitor.zex
make clean
```

Flash the named HID image and run `make smoke-hardware-m8-hid
SERIAL_PORT=...`; perform a short USB-keyboard pass covering printable input,
Enter, Backspace, Ctrl-X and one arrow escape sequence. Record `PENDING` if
physical HID is unavailable.

## Acceptance criteria

- HID discovers IOC only by class/capability/interface and registers a correct
  text/character-input device.
- Local buffering, strict reply validation and stuck-doorbell throttling are
  demonstrated; idle console polling emits no IOC command traffic.
- USB HID input works physically with SIO output, SIO fallback still works when
  HID is absent, firmware is untouched, and the M7 monitor hash is unchanged.
