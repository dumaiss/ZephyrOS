> <one line: who implements, what it runs after, what it may not touch
> (ABI, firmware, architecture), and the baseline (HEAD, or the dirty tree
> and what in it is in scope)>

# Task

<What changes and why, in a short paragraph.>

## Current state

<The load-bearing facts, stated, not pointed to: "X's WRITE path is
`file:function`, which forwards to Y; Z is a second path beside it.">

Read: `work/00-WORKER.md`; <named files and functions, file:function>;
<the records whose decisions this package builds on>.

## Requirements

1. **<Name>** (Must): <the behaviour>. Structural requirements name their
   observable property: <"a `_Static_assert` that ...", "the only caller of
   ... is ...">.
2. ...

## Invariants

- <"`file:function` stays the only path for ...": exact names>.
- <For each one: how the record shows it survived.>

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| <driver tier free / reserve> | <bytes> | <share> | <stop and report / lower the reserve to N> |

## Criteria

- **Must:** <hard gates>.
- **Should:** <target, with its tolerance>.
- **Informational:** <numbers to record>.

## Simulator

<The peer model and the real implementation it mirrors (file:function);
what it does not model, which the owner checklist covers.>

## Owner checklist

- <Board steps, one line each.>

## Validation

```sh
make && python3 -m unittest <named modules>
make <every image target whose code this package touches>
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-<package-name>.md`.
