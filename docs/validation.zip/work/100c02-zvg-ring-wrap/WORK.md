> Worker package. After 100, before 100c01. A correction, found on the
> board: the new vgmplay plays with stray beeps and missed beats, and
> `sndtest zvg` plays a 3-minute song in about 40 seconds. Three defects;
> the tests missed all of them. No OS change.

# Task

Fix the ZVG ring wrap, the first tick's mute, and sndtest's unpaced
loop. Add the tests that would have caught them.

## Current state (the supervisor's simulator reproduction)

A 600-tick, 60 Hz, 3,317-byte ZVG (2,100 writes; a generator is in the
supervisor's notes, see the recipe below) played by the real
`vgmplay.exe` on its timer, with the card writes compared to
`tests/snd/oracle/zvg_trace`:

- **1. Ring wrap.** The writes differ from the oracle at write indices
  163, 489, 815, 977, 1141, 1303, 1629, 1955: once per 256 stream bytes.
  There, 1-3 bytes come out as junk (`FE FD`, `FF FE 00`).
  - **Why:** `snd_zvg_dec.asm` sets `HL = &snd_zvg_ring[head]` and walks
    a command with `inc hl`. A command that straddles the ring's end
    reads past the buffer instead of wrapping to index 0.
  - **Result:** wrong tones (the beeps) and a desynchronised stream (the
    missed beats).
  - **Why the tests passed:** 97's ZVG fixtures are 64 and 39 bytes, so
    no test ever wraps the ring. Nothing underruns, which is why no
    underrun was reported.
- **2. The first tick muted.** Tick 0 writes the stream's first
  commands, then the first flush's shadow rewrite (`80 00 A0 00 C0 00
  E0 9F BF DF FF`) silences the chip, the ZVG's own chip included. The
  stream's initial notes are lost until it writes them again.
- **3. sndtest zvg is unpaced.** `zvg_play_loop` calls `snd_tick(1)`
  back to back with no timer: right for the replay, wrong on the board
  (it plays as fast as the CPU runs).

**The recipe:** a VGM of N frames, each with a tone latch+data pair, a
volume write and, every 4th frame, a noise pair, then `62h`; header
rate 60, version 1.50, SN clock 3579545. Compile it with
`compile_vgm.py`. Check it in as `tests/snd/fixtures/` generator output
(`gen_fixtures.py`) at 600 frames, well past several ring wraps.

Read: `work/00-WORKER.md`; 100's record; `snd_zvg_dec.asm`, `snd_zvg.c`,
`snd_out.asm` (`_flush_all`); `tests/snd/sndtest.c`; `vgmplay.c`.

## Requirements

1. **The wrap** (Must). The decoder never reads past the ring. Either:
   - make the ring 256-byte aligned (runtime-aligned inside a larger
     buffer, as libgfx's page area does) and step with `inc l`, which
     wraps for free and is faster; or
   - keep a mirror of the ring's first 17 bytes after its end (the
     longest command, a 16-byte run plus its opcode), written by the
     producer.

   Record the choice. The producer's copy into the ring must wrap too
   (check `snd_zvg_refill`).
2. **The first tick** (Must):
   - the reserved chip's shadow rewrite happens before the first tick
     (in `snd_zvg_play`, or at the start of that tick's flush, before
     the decoder), never after the decoder's writes;
   - the other chips' rewrite may stay where it is;
   - tick 0 of the trace equals the oracle's tick 0, with nothing after
     it on that chip.
3. **sndtest pacing** (Must). `sndtest zvg FILE CHIP [batch] [step]`:
   - **paced by the timer by default:** `snd_timer_period`, `notify`,
     `snd_tick(count)` from the handler, `snd_service` and `idle()` in
     the foreground, as vgmplay does;
   - **`step`** keeps the unpaced loop the replays use.

   The tests use `step` where they need tick-exact markers.
4. **vgmplay's jitter** (Should). The supervisor's run shows tick starts
   14-19 ms apart at 60 Hz (the period is 16.7 ms). Measure where the
   variation comes from (a `snd_service` refill delaying event delivery,
   `idle()`), record it, and reduce it if it is libsnd's doing.

- **The owner's song** `tests/snd/fixtures/NIGHT.ZVG` (Night Market,
  79,872 bytes, 11,522 ticks, 56,709 writes; the board's deterministic
  opening beep). Replayed in vgmplay on its timer, it differs from a
  straight decode of its stream at 259 places:
  - the opening reset (requirement 2);
  - every ring wrap from write 303 on (requirement 1).

## Tests

- **The long fixture** (`gen_fixtures.py`, 600 frames, many ring wraps).
  Its oracle golden goes in `tests/snd/golden/`.
- **`NIGHT.ZVG`:**
  - `zvg_trace` refuses it ("first buffer", 6,144 bytes: the old
    player's limit). Lift the limit in the oracle tool;
  - generate its trace at test time instead of checking in a 57k-write
    golden;
  - vgmplay replayed over the whole song: the write sequence equals the
    oracle's, byte for byte, apart from the release's silence.
- **sndtest step mode:** the long fixture's per-tick trace equals the
  golden, from tick 0 (requirement 2 makes tick 0 exact), DIRECT and
  BATCH, chips 0 and 2.
- **vgmplay replayed** on its timer (the CTC on): the chip's write
  sequence equals the golden's, byte for byte, with no extra writes
  except the release's silence at the end; 0 underruns.
- **sndtest paced:** on the timer, the tick starts are about one period
  apart (within the measured jitter), and 600 ticks take about 10 s of
  simulated time.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| ZVG tick figures (100) | wait 286, per byte <= 15 | no increase | report with a profile |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board:
  - `vgmplay /fs/<song>.ZVG` plays cleanly (no stray beeps, no missed
    beats), with 0 underruns and 0 missed events;
  - `sndtest zvg /fs/<song>.ZVG 2` plays the same song at the right
    speed (a 3-minute song takes 3 minutes).

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/VGMPlayer test
python3 -m unittest tests.test_snd tests.test_snd_oracle
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-zvg-ring-wrap.md`.
