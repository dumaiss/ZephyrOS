# 100c02 progress (supervisor implementing)

- [x] 1 ring wrap: ring 256-byte aligned in a 512-byte area
      (snd_zvg_ring_page), decoder steps command bytes with `inc l`
- [x] 2 first-tick reset: snd_zvg_play flushes the pending rewrite
      before PLAYING
- [x] found + fixed: snd_tick ran the ZVG decoder once per call
      regardless of the coalesced count; now loops the bounded count
- [x] found + fixed: BATCH append unbounded under catch-up; a full
      batch is sent first (snd_batch_send)
- [x] 3 sndtest zvg paced by default (timer, snd_tick(count), service,
      idle, key stops); `step` for the replays (tests updated)
- [~] 4 jitter: NIGHT shows 72 x 35 ms gaps = events coalesced while a
      refill runs; the per-call re-seek is 100c01 item 3 - re-measure
      after it
- [x] tests: wraps.zvg (generator + golden, oracle test), in TestSndZvg
      (2 chips x 2 modes); zvg_trace 6 KB limit lifted; TestSndZvgTimed
      (sndtest paced, NIGHT) and TestVgmplayTimed (vgmplay, NIGHT):
      byte-identical to the oracle, events == ticks, 0 underruns
- [x] docs (snd-sdk.md 4.5), make check (986 OK), record
