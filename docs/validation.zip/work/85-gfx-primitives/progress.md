# Package 85: GFX primitives (batch + fill_rect + copy_rect)

## Contract

`work/85-gfx-primitives/WORK.md` — GFX-3, `docs/gfx-sdk.md` sections 8
and 9:

1. **Batch** (Must): `gfx_begin`/`gfx_end`/`gfx_flush`; fixed queue of
   16-byte records (32 entries, SDK build constant); auto-flush when
   full; nested begin/end counted like libtui; call outside a batch
   executes at once; in-order execution.
2. **fill_rect** (Must): HMMV; `gfx_clear` becomes a fill of the
   visible page.
3. **copy_rect** (Must): HMMM, DIX/DIY chosen from the overlap (all
   four directions); source and destination on either page.
4. **Bounds** (Must): x 0..width-1, y 0..511, rectangle inside; G6 x
   and width even; zero sizes no-op; refusals `-KOS_EINVAL`, queue
   nothing.
5. **Docs** (Must): `docs/sdk.md`.

## Design decisions

- Queue lives in `gfx_state` (BSS, 32 x 16 = 512 bytes); no initialized
  non-const statics.
- New member `gfx_batch.c` (begin/end/flush + the enqueue helper);
  `gfx_draw.c` holds clear/fill_rect/copy_rect (validation + enqueue).
- Backend `v9958_run_batch` walks the records in order and programs
  HMMV/HMMM blocks; every command is started and waited for.
- `gfx_clear` = fill_rect(0, 0, width, 212, color) — the visible page
  only; update pview.c's "both pages" comment and the mode-test pins.
- `gfx_set_mode` flushes a pending batch before switching (queued G6
  records must not execute under G7 packing).
- HMMM DIX/DIY: src < dst on an axis -> that axis copies from the far
  edge; the block carries the far-edge coordinates then.
- Coordinates are dot coordinates; the peer divides by dots-per-byte
  from R#0 (G6 = 2, G7/YJK = 1).

## Status

- [ ] read sections 8/9, TUI depth pattern, peer HMMM/HMMV
- [ ] gfx.h + gfx_internal.h additions
- [ ] gfx_batch.c, gfx_draw.c fill/copy, v9958_run_batch
- [ ] gfxtest prims
- [ ] tests (ordering, auto-flush 33, copies 4 directions + pages,
      G6 odd refusal, bounds)
- [ ] docs/sdk.md
- [ ] validation batch + record

## Implementation notes

- gfx_clear is gfx_fill_rect(0, 0, width, 212, color): the visible
  page only; the mode tests pin 212 rows and pview.c's "both pages"
  comment now says the visible page.
- gfx_flush/batch need only video_handle (mode_set==0 cannot have
  queued records); set_mode flushes a pending batch before switching.
- The peer records gfx_set_mode's R#46 stop write as a code-0 command
  entry; the replay filters code 0.
- HMMM DIX/DIY: sx<dx -> DIX with both far edges in the block, sy<dy
  -> DIY; non-overlapping copies still pick the forward direction per
  axis (harmless, correct).
- Command counting in the replay: count at ACQUIRE dispatch, cut at
  RELEASE dispatch (the console's restore redraw appends after it).
- Auto-flush pin: the 33rd queued fill flushes the first 32 while the
  hold is intact (34 commands before key 1, no RELEASE in ops).

## Status

- [x] read sections 8/9, TUI depth pattern, peer HMMM/HMMV
- [x] gfx.h + gfx_internal.h additions
- [x] gfx_batch.c, gfx_draw.c fill/copy, v9958_run_batch
- [x] gfxtest prims
- [x] tests (ordering, auto-flush 33, copies 4 directions + pages,
      G6 odd refusal, bounds)
- [x] docs/sdk.md
- [x] validation batch + record
