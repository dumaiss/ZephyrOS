> Worker package. After 84. Implements `docs/gfx-sdk.md` sections 8 and 9
> (GFX-3).

# Task

The batch and the accelerated rectangle primitives.

## Requirements

1. **Batch** (Must): `gfx_begin`/`gfx_end`/`gfx_flush`; a fixed queue of
   16-byte records (32 entries, an SDK build constant), flushed
   automatically when full; nested begin/end counted as in libtui
   (`tui_begin`/`tui_end`); a call outside a batch executes at once;
   execution in order, never reordered.
2. **fill_rect** (Must): HMMV; `gfx_clear` becomes a fill of the visible
   page.
3. **copy_rect** (Must): HMMM with DIX/DIY chosen from the overlap of the
   source and destination rectangles (all four overlap directions copy
   correctly); source and destination may be on either page.
4. **Bounds** (Must): x 0..width-1 and y 0..511 with the rectangle inside;
   G6 x and width even; zero sizes are a no-op; refusals are
   `-KOS_EINVAL` and queue nothing.
5. **Docs** (Must): `docs/sdk.md`.

## Tests

- Ordering (a fill then an overlapping fill), auto-flush at 33 commands,
  copies in the four overlap directions and across pages, against the
  peer's VRAM (`tests/z80sim.py:V9958Peer` executes HMMV and HMMM with
  DIX/DIY).
- G6 odd x refused; nothing queued.

## Owner checklist

- `gfxtest prims`: a pattern of fills and copies on the board.

## Validation

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_sdk_package
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-gfx-primitives.md`.
