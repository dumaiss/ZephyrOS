# Task

The board now routes latch bits D5-D7 (the ROM page field) into three spare
I/O pins of the memory decoder (GAL22V10, `MEM_DECODER.pld`). This package
evaluates a **revision-13 decoder** that uses them to sub-qualify mode 11 with
an upper **window**: in mode 11, `8000h-DFFFh` shows the bank selected by the
inverted page field (page 0 shows bank 7, exactly as revision 12; page 1 shows
bank 6; up to page 7, which shows bank 0). It produces:
- the revision-13 PLD and test vectors, ready for the owner to program;
- the simulator model and its tests;
- a measured fixed-core/window layout of the nucleus;
- window-based service-call and bank-copy prototypes with cycle counts;
- an owner-run CP/M boot check under revision 13.

Together these are the data the phase-0 resident-service decision record will
be written from.

## Context

Dispatch after package 33 is accepted. Read `work/00-WORKER.md` ("Working
efficiently"), `work/M10-REFERENCE.md`, the package-33 spike report,
`docs/memory.md`, `kernel/memory/{banking,user_copy}.asm`,
`kernel/romfs/rom_access.asm`, `kernel/irq/entry.asm`, `kernel/process/far.asm`
(spike), `tests/z80sim.py`, and from the read-only Zephyr-80 reference:
`Memory Management.md`, `Code/HDL/WinCUPL/src/MEM_DECODER.pld` (revision 12)
and its build outputs.

Hardware facts:
- Revision 12 decodes mode 11 as: `0000h-1FFFh` the bank field (D0-D2),
  `2000h-DFFFh` forced bank 7, and `E000h-FFFFh` forced bank 0. The ROM is
  enabled only in mode 00 (`ROM_CS = !MREQ & RD & !MODE1 & !MODE0`), so D5-D7
  are don't-care for the ROM in modes 01, 10 and 11.
- The supervisor checked revision 12's fuse map: pins 18-21 have an intact
  output-enable row (always disabled, high-impedance), so the bodge is
  electrically safe with revision 12. Pin 21 (`CART_CS`, no equation) is a
  fourth undriven pin.
- The pins are **inputs only**: latch D5-D7 drive them, and the GAL never
  drives them. In the PLD, declare them as plain input pins, so their output
  enable stays permanently off, as in revision 12.
- Owner hardware check (2026-10-06): with the D5-D7 bodge in place and the
  revision-12 GAL, the ZSDOS-based CP/M boots and runs normally. That proves
  the modification is inert under revision 12. It does **not** prove CP/M
  under revision 13. Requirement 5's owner-run boot check after programming
  revision 13 establishes that.
- **Pin mapping (owner-confirmed, 2026-10-06):** GAL pin 18 is latch D5
  (`PAGE0`), pin 19 is D6 (`PAGE1`), pin 20 is D7 (`PAGE2`). All three are
  inputs. Record this in the PLD header and in `docs/memory.md`. Pin 21
  (`CART_CS`, no equation, undriven) stays as revision 12 leaves it.

## Requirements

1. **Revision-13 PLD proposal.** Add it as
   `platform/zephyr80/hdl/MEM_DECODER_rev13.pld`, with a WinCUPL simulation
   vector file (`.si`). It is a hardware description owned by the platform,
   not executable Z80 code. The Zephyr-80 tree stays read-only; the owner
   programs the part. Equations, conceptually:

   ```text
   WIN      = MEM_MODE1 & MEM_MODE0 & A15 & !(A14 & A13)       ; mode 11, 8000-DFFF
   FORCE_B7 = MEM_MODE1 & MEM_MODE0 & OS_BODY & !WIN
   RAM_A16  = (BANK_Q0 & !FORCE_BANK0 & !WIN) # FORCE_B7 # (!PAGE0 & WIN)
   RAM_A17  = (BANK_Q1 & !FORCE_BANK0 & !WIN) # FORCE_B7 # (!PAGE1 & WIN)
   RAM_A18  = (BANK_Q2 & !FORCE_BANK0 & !WIN) # FORCE_B7 # (!PAGE2 & WIN)
   ```

   Every other term is unchanged. The PAGE pins are inputs (output enable
   permanently off). The test vectors cover every mode × address region ×
   bank × page combination that matters. They must prove that **revision 13
   is identical to revision 12 for every case with page = 0, and for every
   case in modes 00, 01 and 10, whatever the page**. Check the product-term
   fit in the WinCUPL report if the toolchain is available; otherwise derive
   it by hand and say so.
2. **Simulator model.** `tests/z80sim.py` gains a `decoder_revision`
   option (12 by default, 13 opt-in) implementing exactly the PLD equations.
   Add host tests: a truth table generated from the same table as the `.si`
   vectors, so the PLD and the simulator cannot drift.
3. **Measure the fixed core.** In an evaluation configuration (its own build
   directory; production unchanged), link the nucleus so that everything
   that must stay visible while the window shows another bank sits in
   `2000h-7FFFh`, and the rest uses bank 7's `8000h-DFFFh`.
   - Must stay visible: syscall, IRQ and transition gates, IPC/far-call
     dispatch, the copy primitives, window-select code, IRQ dispatch, the
     ISR stack, and nucleus data that services or interrupts touch.
   - Classify every kernel object as fixed or cold, with a reason.
   - Report the fixed-core size against 24 KB. Also report the size at the
     alternative split points `6000h` and `A000h` (the window base is one
     PLD constant), with the trade-off.
   - Move the ISR stack out of `DF00h` into the fixed region or common, and
     report what else interrupts depend on.
4. **Window-based mechanisms (prototypes, measured).**
   - **Service call:** fixed-core code sets page 1 (bank 6 in the window),
     plain-`CALL`s a test routine in bank 6 at `8000h+`, and that routine
     plain-`CALL`s a fixed-core nucleus primitive. Restore the page. Measure
     the round-trip cycles, and compare with the package-33 far gate's round
     trip (mode 10 over bank 6, common trampoline).
   - **Bank copy:** copy between the fixed region (or the caller's low
     window) and another bank's `8000h-DFFFh` with a plain `LDIR` through the
     window. Compare cycles and common-memory bytes with `zos_bank_copy`.
     State which M10 xmem/segment placements are reachable through the
     window and which still need the existing gate (slots below `8000h`).
   - **IRQ during a window:** an interrupt arriving while the window shows
     bank 6 must dispatch correctly and return to the same window. Prove it
     in the simulator, including latch save and restore.
5. **CP/M compatibility: an owner hardware check, not an audit.** After the
   owner programs revision 13, boot the ZSDOS-based CP/M and deliberately
   exercise the paths most likely to leave page bits set in mode 11:
   - `DIR` and file reads on drive A (the ROM-disk path);
   - running a few programs;
   - one warm boot.

   The worker supplies the exact check list in the report. A quick grep of
   the BIOS for mode-11 latch writes is optional, as a hint if the check
   fails; no full read-only audit is required.
6. **Report** `docs/validation/<date>-m10-rev13-window.md`:
   - the pin mapping;
   - PLD and vector status;
   - the decoder-equivalence proof for page 0;
   - the fixed/cold classification and fixed-core size at each split;
   - cycle and byte comparisons (window versus gate);
   - the IRQ-during-window result;
   - the CP/M hardware check list and its result (owner-run), or `PENDING`;
   - a recommendation: adopt revision 13 (with split point) for the
     resident-service architecture, or stay on revision 12 with the gate.

## Constraints

- **Production is unchanged.** The production image hash is identical to
  package 33's, and the simulator defaults to revision 12.
- No resident-service implementation (that is phase 0 onwards). Prototypes
  live in the evaluation configuration and the tests only.
- Do not modify the Zephyr-80 repository. The PLD proposal lives in this
  repository.

## Validation

At the efficiency defaults, run one formal batch:

```sh
make clean && make check
make rev13-eval-selftest            # evaluation image, sim with decoder_revision=13
python3 -m unittest tests.test_decoder_rev13 tests.test_rev13_eval_sim -v
git diff --check
```

If WinCUPL is available, also compile and simulate the PLD and record its
output.

Hardware (optional, owner-run): after programming revision 13, run the
production image unchanged (page 0 must behave exactly like revision 12).
That first run is the hardware equivalence check. If an evaluation image is
built for the board, run the window service-call and copy probes. Record
`PENDING` otherwise.

## Acceptance criteria

- The revision-13 PLD, its vectors and the simulator model agree. Revision 13
  is proven identical to revision 12 whenever page = 0 or the mode is not 11.
- The fixed-core size is measured at the candidate splits, and window-based
  service-call and copy costs are measured against the package-33 gate.
  IRQ-during-window works in the simulator.
- The CP/M check list is provided. Its owner-run result, or `PENDING`, is
  recorded, and the report gives a clear adopt/do-not-adopt recommendation.
- The production image is unchanged.
