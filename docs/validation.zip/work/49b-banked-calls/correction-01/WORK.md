# Correction 01: the token-cache test

Runs after 49c, before 49d.

**The defect** (found by 49c, record section 5). With the xmem image
built, `tests.test_xmem_selftest_sim.TestXmemSelftest.
test_the_token_cache_costs_one_segmap_per_segment` fails:

| | expected | measured |
|---|---|---|
| `SYS_SEG_MAP` calls (id: count) | `{0:1, 1:2, 2:2, 3:1}` | `{0:1, 1:5, 2:3, 3:1}` |

49b's record reports a pass, from a run made before its last edit to
`tests/xmem/xmem_far.c`.

**Supervisor arithmetic.** `farcall` calls `segmap` on every call
(`user/sdk/src/seg.c`). That accounts for one call that the expectation
forgot:
- segment 2: explicit `segmap(2)` + `farcall(2)` + 1 cache fill = 3, as
  measured;
- segment 1: explicit `segmap(1)` + `farcall(1)` at lines 220 and 342 +
  1 cache fill = **4**, but **5** were measured. One call is unexplained:
  either the cache misses a second time, or there is a fifth call
  somewhere.

## Requirements

1. **Find segment 1's extra call.** In the replay, attribute every
   `SYS_SEG_MAP` to its caller: the return address on the stack at the
   `RST 30h`, inside `bcall.asm`, `seg.c` (`farcall`/`segmap`), or
   elsewhere. Record the table.
2. **If the trampoline fills the cache twice for segment 1, fix the
   trampoline.** Possible causes: a cache store lost on one path, an
   entry cleared, or the cross-segment return. Name the cause and the
   fix.
3. **Make the test precise.** Count only `SYS_SEG_MAP` calls whose
   caller is the trampoline, and require **exactly one per far segment
   used** (`{1:1, 2:1}`). Keep a second assertion on the program's own
   explicit calls, derived from the program (refused ids 0 and 3 one
   each). No assertion is loosened.
4. **Record** an addendum to `docs/validation/2026-10-12-banked-calls.md`:
   the attribution table, the cause, the fix if any, and the fact that
   the earlier pass came from a stale run.

## Validation (targeted)

```sh
make xmem-selftest      # builds the image and runs its replays, including this test
python3 -m unittest tests.test_bcall
git diff --check
```

If the trampoline changes, also run
`python3 -m unittest tests.test_console_acceptance`.
