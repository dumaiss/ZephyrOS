# Correction 01: the token-cache test — working log

Contract: `WORK.md` (this directory).  Runs after 49c, before 49d.
Result: **the trampoline is not at fault**; the image-wide counter was
counting another program's call.  Only
`tests/test_xmem_selftest_sim.py` changed.

## 1. Attribution (requirement 1)

Replayed `build-xmem-selftest/konaos-xmem-selftest.bin` (built by
`make xmem-selftest`), attributing every SYS_SEG_MAP (RST 30h, A = 27h):

- the program is the one whose gate stub holds the RST address - each
  program links its own `_kos_ipc_raw_call`, the RST at +10 (`xmem_far`
  2301, `xmem_child` 1CE4);
- the caller is the first frame above the marshalling chain: at the RST
  `SP+2` is the return address of the call to `segmap` (both `segmap` and
  `kos_ipc_raw` tail into the stub, so the chain collapses to one frame),
  and the walk skips `_segmap`/`_kos_ipc_raw`/`_kos_ipc_raw_call` if it
  ever does not;
- frames are labelled through each program's own map
  (`build-xmem-selftest/user/<name>/<name>.map`).

The ten calls (table in the record):

| class | calls |
| --- | --- |
| `xmem_far` / `_main` | `{0:1, 1:1, 2:1, 3:1}` - the four explicit `segmap` calls |
| `xmem_far` / `_farcall` | `{1:2, 2:1}` - entry, exit-from-far, segment 2's entry |
| `xmem_far` / `___sdcc_bcall_ehl` | `{1:1, 2:1}` - the token-cache fills |
| `xmem_child` / `_main` | `{1:1}` - the child's foreign-segment probe |

Sum = the measured `{0:1, 1:5, 2:3, 3:1}`.

## 2. Cause (requirement 2)

Row 6 is the "unexplained" fifth segment-1 call: `tests/xmem/xmem_child.c`
calls `segmap(foreign_seg)` when its tail names a segment, and
`tests/xmem/xmem_far.c`'s `make_tail` execs the child with
`"<handle> 1"`.  The parent's child gets `0` (`xmem_selftest.c`'s
`child_tail`) and makes no call.  The counter counted the whole image, so
the child's probe landed on the far program's id-1 total.

**No trampoline fix** (the condition in the contract does not hold):
22 trampoline entries, 2 SYS_SEG_MAPs, cache `[0,0,0,0]` →
`[113,0,0,0]` → `[113,145,0,0]`, and the cross-segment return reuses
slot 1.  `user/sdk/src/bcall.asm` is unchanged (restored byte-identical
after the negative check below).

Negative check (does the corrected test catch a cache regression?): with
the hit path disabled (`ret nz` → `nop; nop`) and the image rebuilt, the
trampoline class becomes `{1:20, 2:1}` and the test fails; restored and
rebuilt afterwards.

## 3. Test (requirement 3)

`SegMapCallCounter` now takes the three `ProgramMap`s and records
`{(program, caller): {id: count}}` plus `unattributed`.  The test asserts
the four classes above and `unattributed == []`: all ten calls pinned,
the two refusals and the child's probe included - nothing loosened.

## 4. Validation

```sh
make xmem-selftest                     # exit 0: Ran 9 tests ... OK (283.298 s)
python3 -m unittest tests.test_bcall   # exit 0: Ran 7 tests ... OK
git diff --check                       # clean
```

Record: addendum in `docs/validation/2026-10-12-banked-calls.md`
(attribution table, cause, no fix, the stale-run note).

Harness kept in the session workspace:
`files/49b-c01-segmap-attribution.py` (regenerates the table).
