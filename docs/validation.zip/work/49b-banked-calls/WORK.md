> **DRAFT. Not dispatched.** Runs after 49a, before 49c.

# Task

**Far calls as plain C.** A program marks a function `__banked` (or puts
a file in a far segment with `#pragma bank <n>`), and calls it like any
function. SDCC emits the call through `___sdcc_bcall_ehl`, and the SDK
provides that trampoline on top of the existing far-code mechanism
(segment tokens, the aperture). `farcall` stays as the primitive.

Read:
- `work/00-WORKER.md`;
- the architecture's far-code section;
- `user/sdk/src/seg.c` and `xmemgate.asm` (`aperture_open/close`);
- `user/sdk/exe.mk` (the `FAR=` and `SEGMENTS=` rules);
- `user/helloworld/fardemo*.c`;
- `tests/xmem/xmem_far*`;
- the SDCC 4.5 manual on banked calls.

## Part 1: spike (stop gate)

Find out, with SDCC 4.5.0 `-mz80` and `sdcccall(1)`, and record:
1. the exact code SDCC emits for a call to a `__banked` function: how
   `E:HL` is loaded, where the `b_<fn>` symbol comes from, and how
   `#pragma bank` sets it;
2. how arguments and return values travel (registers or stack) for 0, 1,
   2 and 3 arguments of 8, 16 and 32 bits, and what the trampoline must
   preserve;
3. whether the linker can place several far areas (`_FAR1` … `_FAR4`) at
   the same base `8000h` in one link without errors.

**Stop and report** if any of these hold:
- a trampoline cannot preserve the convention in at most 64 bytes;
- the arguments cannot pass through unchanged;
- (3) is impossible.

Do not work around a failure.

## Part 2: implementation

1. **Trampoline** `___sdcc_bcall_ehl` in a new SDK file `user/sdk/src/
   bcall.asm`:
   - E is the segment id. Get its token from a per-program cache of 4
     entries, filling it on first use with `segmap(E)`.
   - `aperture_open(token)`, keeping the previous value; call HL (push a
     return address, then `JP (HL)`);
     `aperture_close(previous)`.
   - Every register that carries arguments or results is preserved as
     the spike determined.
   - A banked function may call another segment's banked function. The
     restore re-maps the caller's segment.
   - A `segmap` failure calls the SDK's existing runtime-error path
     (`exe_runtime_error`), with a new code
     `KOS_RT_EFARMAP`.
2. **Build rules:** `FAR1=` … `FAR4=` take source lists. Each is
   compiled with `--codeseg FAR<n>` and `#pragma bank <n>` semantics
   (`b_` = n), linked at `8000h`, and becomes segment n.
   - Segment ids 1-4 are the far code segments. `DATA` segments declared
     with `SEGMENTS=` are numbered from 5. Renumber the existing test
     declarations to match.
   - `FAR=` is deleted. Its users switch to `FAR1=`.
   - Each segment is at most 16 KiB. The build fails above that, naming
     the segment.
3. **Ports:**
   - `fardemo` and `xmem_far` call their far functions as plain C;
   - one test keeps using `farcall` directly, so the primitive stays
     covered.
4. **Size:** report the trampoline's bytes and the cycles of one call:
   the cached path and the first call.

## Tests

- **Simulator:**
  - calls with 0-3 arguments of each width, with return values;
  - a call from segment 1 into segment 2 and back;
  - recursion inside one segment;
  - an invalid segment (runtime error);
  - the token cache filled once (count the `segmap` syscalls).
- **Host:** the `FARn=` rules; the 16 KiB limit; the spike's findings
  written as assertions on a compiled sample (the call sequence SDCC
  emits).

## Constraints

- No kernel or driver change. Production changes only in the store (the
  ported programs).
- Record: `docs/validation/<date>-banked-calls.md`, with the spike
  findings first.

## Validation

```sh
make clean && make check
make xmem-selftest helloworld-image
git diff --check
```
