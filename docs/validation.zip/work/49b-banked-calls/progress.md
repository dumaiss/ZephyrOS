# 49b — banked calls (`__banked` as plain C): working state

## Phase

Part 1 (spike) **done** — findings below, no stop-gate condition holds.
Part 2 (implementation) in progress.

Note: `WORK.md` still carries the "DRAFT. Not dispatched." banner; the
owner dispatched the package in session.  49a is committed (`3ce127b`),
the tree was clean at the start.

## Spike findings (SDCC 4.5.0 #15242, `-mz80`, `sdcccall(1)`)

Sampled in `/tmp/spike49b` with the SDK's own flags
(`-mz80 -c --nostdinc --Werror -I abi -I user/sdk/include`):

1. **The call sequence** a caller emits for a `__banked` function:
   ```asm
   	ld	e, #b_<fn>      ; the bank number, an immediate
   	ld	hl, #_<fn>      ; the function address
   	call	___sdcc_bcall_ehl
   ```
   (a tail call uses `jp ___sdcc_bcall_ehl`).  `b_<fn>` is an *immediate*
   the *defining* module must supply: SDCC emits `b_<fn> = <n>` in the
   module that defines the function **when that module is compiled with a
   bank number** (`-bo <n>` on the command line or `#pragma bank <n>` in
   the source).  Without a bank number `b_<fn>` stays undefined and the
   link fails.  `#pragma bank <n>` puts the code in area `_CODE_<n>`;
   `-bo <n>` does the same; a later `--codeseg FAR<n>` / `#pragma codeseg
   FAR<n>` renames the area, so `sdcc -bo <n> --codeseg FAR<n> <src>`
   yields area `_FAR<n>` **and** `b_<fn> = <n>`.
   The definition must also be `__banked` (the manual: "the callee needs
   it for a proper return").

2. **Arguments and return values.**  Per the manual, for z80 banked calls
   *all* parameters are passed on the stack and the *caller* clears them
   up; `__z88dk_fastcall` (unused here) is the exception.  At the far
   function's entry the compiler assumes the exact stack shape the
   trampoline must produce:
   ```
   SP+0..1   the address the callee's RET pops (the trampoline's continuation)
   SP+2      1 reserved byte   (SDCC's own trampoline keeps the previous bank here)
   SP+3..4   2 reserved bytes  (SDCC's own trampoline: the CALL to ___sdcc_bjump_ehl)
   SP+5...   the arguments, packed, first argument lowest
   ```
   i.e. the trampoline must spend **exactly three bytes** between its
   entry (after the caller's `call ___sdcc_bcall_ehl`, so args start at
   entry SP + 2) and the transfer to the callee.  Evidence: a
   `__banked` definition reads its arguments as `ld hl,#7 / add hl,sp`
   and `ld iy,#5 / add iy,sp`, chars at `SP+5` and ints at `SP+6` with no
   padding.
   Return values travel in registers: 8-bit in `A`, 16-bit in `DE`,
   32-bit in `DEHL` (low word in `DE`, high word in `HL`).  The caller
   spills *everything else* it needs to the stack before the call (seen
   in three samples), so the trampoline must preserve exactly `A`, `DE`
   and `HL` across the far call — SDCC's reference trampoline does this
   with `push af` / `pop af` around the bank restore and requires the
   bank helpers to preserve the rest.

3. **Several far areas at one base.**  `sdldz80` links `_FAR1`, `_FAR2`,
   `_FAR3`, `_FAR4` all based at `8000h` in one link without an error or
   a warning (each stays its own `REL,CON` area).  Two caveats measured:
   a `-b` base for an area no module defines is a **warning** and exit 2,
   so the rule may place only the areas the program actually has; an
   area left unplaced is silently placed after the placed ones, so a
   stray area cannot masquerade as a far segment.

## Part 2 (implementation)

### Files

- **new `user/sdk/src/bcall.asm`** — `___sdcc_bcall_ehl`, the trampoline:
  E = segment id, HL = the far entry.  It saves HL, looks the id up in a
  per-program token cache (4 slots, ids 1-4, filled with `segmap` on
  first use), `aperture_open(token)`, spends exactly the three bytes the
  callee expects (the saved latch in the one-byte slot, the transfer's
  return address in the two-byte slot), `jp (hl)`, then drops the slot,
  `aperture_close(previous)` and returns with A (8-bit), DE (16) and HL
  (32-bit) results intact.  An id outside 1-4, or a refused `segmap`,
  takes the runtime-error path (`exe_runtime_error`, `KOS_RT_EFARMAP` =
  0x30) instead of calling anything.  **68 bytes of `_CODE`, 4 bytes of
  `_DATA`.**
- `user/sdk/include/kos/seg.h` — `KOS_RT_EFARMAP` and the `__banked` half
  of the far-code documentation.
- `user/sdk/exe.mk` — the `FAR1=`..`FAR4=` rules: one "id:source" spec
  per far source, compiled by one shell-loop recipe with
  `-bo n --codeseg FAR<n>` (bank first: area `_FAR<n>` *and*
  `b_<fn> = n`), objects under `$(OBJDIR)/far<n>/`, a stamp target the
  far objects hang off, `-b _FAR<n> = 0x8000` per used option, and the
  auto segment declaration now emits one `FAR_CODE` row per option used,
  id n, area `_FAR<n>`.
- `tools/pack_image.py` — `parse_ihx(text, multi=True)` keeps every value
  of an address in record order (the far areas are one record stream
  each, all at 8000h).
- `tools/exepack.py` — far areas: each `FAR_CODE` row's id must be the
  number in its area name (`_FAR<n>`), must be the row's position (the
  far segments are the container's first ids, 1..k), `DATA` rows follow;
  the *n*-th byte of an address is the *n*-th covering area's (ascending
  id, the link order), so the overlap refusal for areas at 8000h is gone
  and a stream/area count mismatch is refused instead.
- Ports (package 49b §3): `fardemo` calls its far entry as plain C
  (`FAR1=`, `__banked`), `xmem_far` keeps `farcall` for segment 1's
  plain entries *and* calls `__banked` entries as plain C, and a new
  `tests/xmem/xmem_far_code2.c` is segment 2 (`FAR2=`): its plain entry
  keeps the 44b two-bank coverage and its `__banked` entry calls back
  into segment 1, which proves the trampoline restores its caller's
  bank.
- Tests: `tests/test_bcall.py` (new host test: the spike's findings
  asserted on a real SDCC build *and* the trampoline run in the host Z80
  with the SDK members stubbed: results, frame, token cache, error path);
  `tests/xmem/xmem_far.c` + `tests/test_xmem_selftest_sim.py` (the
  banked-call matrix, the recursion, the segment 1→2→1 crossing, the
  invalid segment, and a SYS_SEG_MAP counter proving the cache);
  `tests/test_sdk.py`/`tests/test_exe.py` for the rules; docs (`sdk.md`,
  `exe-format.md`, `abi.md`, `architecture.md` 36.17).

### Finding while implementing

The first trampoline version tested the cache with `ld a,(hl)` + `ret
nz`, but **`ld a,(hl)` does not set the flags**, so `ret nz` always
returned - an empty slot looked like a hit with token 0, i.e. every
banked call took the error path.  `or a` after the load fixed it (and the
byte-index add now carries into H when the slot crosses a page).  This
was caught by running the trampoline in the host Z80
(`tests/test_bcall.py`) before the image boot; the image then passed all
37 far-program checks, including the 18 new `bk-*` ones.

### Cycles (Z80 T-states, from the assembled listing)

- cached path, trampoline + helpers, far function excluded: **310**
  (entry 11+4+17, token lookup hit 65, `aperture_open` 17+48, transfer
  17+4, return 6+10+11+4+17+21+10+10 = 89);
- first call: **+85** (the cache miss) **+ one SYS_SEG_MAP**;
- `farcall` (the 44b path) is the same shape but maps through its own C
  frame: the trampoline's cached path is the cheaper of the two.

## Correction 01 (after this package's run)

`correction-01/` corrects this package's token-cache test: its image-wide
`SYS_SEG_MAP` count was counting the child program's foreign-segment
probe as if the far program had made it.  The trampoline is not at fault
(22 entries, 2 cache fills) and `bcall.asm` is unchanged.  Details in
`correction-01/progress.md` and the addendum in
`docs/validation/2026-10-12-banked-calls.md`.
