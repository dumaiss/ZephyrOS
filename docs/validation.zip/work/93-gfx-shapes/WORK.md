> Worker package. After 86. Implements `docs/gfx-sdk.md` §8.1 (GFX-5):
> rectangles, lines, points and ellipses with COPY and XOR, drawn by the
> VDP. libgfx, its callers, gfxtest, the V9958 peer model, docs. No OS
> change.

# Task

The shape set: `gfx_fill_rect` gains an operation, plus `gfx_rect`,
`gfx_line`, `gfx_point`, `gfx_ellipse` and `gfx_fill_ellipse`. Each is
built from VDP commands (HMMV, LMMV, LINE, PSET); ellipses are computed on
the CPU and drawn as VDP spans.

## Current state

- **libgfx:** `gfx_fill_rect(x, y, w, h, color)` (HMMV, `gfx_draw.c`),
  the 16-byte `struct gfx_cmd` queue (`gfx_batch.c`), and the backend's
  `v9958_run_batch` (`v9958_gfx.c`) building command blocks for R#32-46
  through `v9958_io.asm`.
  - **Rules:** G6 even x/width; YJK x/width multiples of 4.
- **Callers of `gfx_fill_rect`:** `tests/gfx/gfxtest.c`, `UserSoftware/GfxDemo`
  (package 86), `pview` (through `gfx_clear` only). The signature changes,
  and nothing outside the tree uses it, so every call site is updated.
- **V9958 commands:**
  - **LINE** = 70h | op: DX/DY start in R#36-39, Maj in R#40-41, Min in
    R#42-43, CLR in R#44, ARG in R#45 (bit 0 MAJ: 0 = long side along X;
    DIX bit 2, DIY bit 3).
  - **PSET** = 50h | op; **LMMV** = 80h | op (a logical fill, per pixel,
    in dots).
  - **Logical ops:** IMP 0, EOR 3.
  - **Coordinates:** dots, any x, in every mode.
- **The peer** (`tests/z80sim.py:V9958Peer`) executes HMMV, HMMM, LMMV
  with EOR, LMMC and HMMC. It doesn't execute LINE, PSET or LMMV with IMP.

Read: `work/00-WORKER.md`; `docs/gfx-sdk.md` §8, §8.1, §9; packages 85
and 86's records; `gfx_draw.c`, `gfx_batch.c`, `v9958_gfx.c`,
`v9958_io.asm`; `tests/test_gfx.py` (the prims replay).

## Requirements

1. **API** (Must). In `kos/gfx.h`, exactly as §8.1: `enum gfx_op`, and
   the six calls, each taking the op.
   - **Refusals:** an unknown op, or any part (an ellipse's bounding box
     included) outside the mode's width or the 512-line space, is
     `-KOS_EINVAL`, queueing nothing.
   - **YJK:** only an aligned COPY `gfx_fill_rect`; the rest is
     `-KOS_ENOTSUP`.
   - **Zero sizes:** a zero width/height for rectangles is a no-op; a
     zero radius draws the degenerate line or point.
2. **Rectangles** (Must):
   - `gfx_fill_rect` uses HMMV for COPY with byte-aligned x and width,
     and LMMV otherwise, so odd x in G6 is accepted;
   - `gfx_rect` is four LINE commands, with each corner plotted exactly
     once (XOR-safe).
3. **Lines and points** (Must): LINE with Maj/Min and MAJ/DIX/DIY from
   the endpoints, so all 8 octants and the horizontal and vertical cases
   run from (x0, y0) to (x1, y1) inclusive. CLR is the mode's pixel value
   (G6: the low nibble).
4. **Ellipses** (Must):
   - **The algorithm:** midpoint, one quadrant mirrored. 32-bit only in
     the error terms; the span output is 16-bit.
   - **Filled:** one horizontal span per scanline.
   - **Outline:** per scanline, the left and right spans covering every
     outline pixel, never overlapping, so an XOR ellipse drawn twice
     restores everything.
   - **Queueing:** expanded into span records at queue time; the batch
     auto-flushes as it fills.

   Record the CPU T-states for a filled and an outline circle of radius
   50.
5. **Peer** (Must). `V9958Peer` executes LINE (the VDP's Maj/Min error
   stepping), PSET and LMMV with IMP and EOR, in G6 and G7:
   - cite the V9958 Technical Data Book in the model's docstring;
   - list what isn't modelled (other ops, timing) for the owner
     checklist.
6. **Docs** (Must): `docs/sdk.md` (the shape calls, the op, the command
   each uses, the YJK rule).
7. **Speed** (Must). Speed beats code size in libgfx.
   - **Harness:** add `gfxtest timing` and a `tests/test_gfx.py` test.
     They measure CPU T-states between markers in the program bank, the
     way `tests/test_tui_sim.py`'s `test_timing_mode_meets_the_budgets`
     does, and pin each target in the Budgets table.
   - **Baseline first:** before changing anything, record:
     - an opaque 6×8 glyph in G6, in a 32-glyph string;
     - one aligned `gfx_fill_rect`, queued and flushed.

     Package 95 starts from these figures.
   - **The command pipeline goes to assembly.** That is the queue append
     plus `v9958_run_batch`'s per-command block build and its R#32-46
     write: one R#17 set, then OUTI/OTIR. Every shape and every
     transparent glyph pays this per command, so write the new LINE,
     PSET and LMMV builders there, not in C. Package 94 then only moves
     the CE wait.
   - **The ellipse span generator:** C first. Convert it to assembly
     only if it misses its target. A 16-bit or 24-bit error formulation
     is fine wherever it is exact for the 512×512 space.

## Tests

`gfxtest shapes` (new mode) and a `tests/test_gfx.py` replay against the
peer's VRAM, each compared with a Python reference:

- **Lines:** all 8 octants, plus horizontal and vertical, in G7, endpoints
  included. Single points in both modes.
- **G6 pixels:** at odd and even x, the nibble written is the colour's
  low nibble, and the neighbouring pixel is untouched (lines and an odd-x
  fill).
- **Rectangles:**
  - `gfx_rect`: the outline pixels exactly, the corners once;
  - `gfx_fill_rect`: the HMMV path (aligned COPY) and the LMMV path (odd
    x, and XOR), with the command used checked.
- **Ellipses:** filled and outline at several radii, including `rx != ry`
  and a radius of 0. The pixel set equals the reference midpoint ellipse.
- **XOR:** every shape drawn twice in XOR restores the background byte
  for byte.
- **Refusals:** out of bounds and an unknown op `-KOS_EINVAL`, nothing
  queued; YJK line `-KOS_ENOTSUP`.
- **Call sites:** the existing prims, upload, text and gfxdemo tests pass
  with the new `gfx_fill_rect` signature.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| OS bytes | unchanged | 0 | stop and report |
| one command, queue + flush (CPU T-states, CE wait excluded) | baseline | <= 1,200 | report with a profile |
| `gfx_line`, any octant | - | <= 1,500 | report with a profile |
| filled circle r=50 | - | <= 150,000 | report with a profile |
| outline circle r=50 | - | <= 250,000 | report with a profile |
| opaque 6×8 glyph, G6 | - | record (baseline for 95) | - |
| code size | - | report only | - |

## Owner checklist

- On the board, `gfxtest shapes` draws:
  - rectangles, a fan of lines in 8 directions, filled and outline
    circles and ellipses;
  - an XOR marker drawn and erased.

  Then a key, and the console comes back.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/GfxDemo test && make -C UserSoftware/PView test
python3 -m unittest tests.test_gfx tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-gfx-shapes.md`.
