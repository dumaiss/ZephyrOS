# Package 93 progress (GFX shapes)

## Plan
- [x] API: enum gfx_op + 6 shape calls in kos/gfx.h; call sites updated
      (gfxtest, GfxDemo).
- [x] gfx_shapes.c: rect/line/point validation + ellipse midpoint span
      expansion; batch submission.
- [x] v9958_io.asm: LINE/PSET/LMMV block builders; command pipeline
      (one R#17, OUTI/OTIR); HMMV/HMMM stay in assembly path.
- [x] v9958_gfx.c: FILL uses HMMV or LMMV (odd x / XOR); run LINE/PSET/
      LMMV builders.
- [x] V9958Peer: LINE (Maj/Min stepping), PSET, LMMV IMP+EOR in G6/G7,
      docstring cites; not-modelled list.
- [x] gfxtest shapes + timing modes; tests/test_gfx.py replays (Python
      reference for line/ellipse pixels, XOR restore, refusals).
- [x] docs/sdk.md shapes section.
- [x] Validation: package's command block, then validation record.

## Bugs fixed on the way
- run_line ARG byte corruption (|dx| restore clobbered the direction
  bits; stashed in the spare block byte 15).
- Y-major NX/NY stores (NX always major, NY always minor).
- DIX/DIY bit values (0x04/0x08, openMSX VDPCmdEngine).

## Budgets (gfxtest timing, CPU T-states)
- opaque 6x8 glyph G6: 37,509 (baseline for package 95)
- one command queue+flush: 308 (<= 1,200)
- gfx_line any octant: 216 (<= 1,500)
- filled circle r=50: 131,166 (<= 150,000)
- outline circle r=50: 196,351 (<= 250,000)

## Notes
- gfxtest walkdbg scaffolding removed (the tests derive the screens
  from the peer's executed span commands).
