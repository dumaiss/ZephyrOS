# Task

Establish the M8 production foundation: derive the resident-module arena from
the aligned end of the linked static kernel, migrate every driver and consumer
to class-aware driver ABI v2, add safe driver discovery/resource imports, and
retain all earlier milestone behavior under the new internal ABI.

## Context

Read `work/00-WORKER.md`, architecture sections 30.2-30.3 and 30.7, and
`work/M8-REFERENCE.md`. The current fixed `A000h-BFFFh` arena and ABI v1 are
historical M4 geometry. ZMOD container format v1 and its relocation format do
not change; the header's `driver_abi` becomes 2. The clean starting tree has no
unrelated changes. Preserve the M7 `monitor.zex` hash recorded in the M8
reference note.

## Requirements

- Set `ZDRIVER_ABI_VERSION=2`; migrate SIO and all test modules/manifests. ABI
  v1 modules must now be rejected. Replace `struct zdevice_ops` with optional
  `struct zchar_ops`, make capabilities `uint32_t`, and give descriptors and
  registry entries separate `char_ops` and class-typed `class_ops` pointers.
- Keep class values stable: SERIAL=1, VIDEO=2, STORAGE=3, HID=4 (former INPUT),
  IOC=5 (former TRANSPORT), OTHER=6. Use generic capability bits 0-3; allocate
  VIDEO bits 8-14, HID bits 16-18, and IOC bits 24-27 as documented constants.
  Remove live uses of the obsolete class names rather than keeping two models.
- Implement `device_find(class_id, required_caps, after)` and
  `device_interface(handle, expected_class, &class_ops, &state)`. Require all
  requested capabilities, verify class and non-null class interface, expose no
  registry mutation, and return predictable errors for invalid/stale handles.
- Extend the v2 module API with those two read-only discovery calls plus narrow
  ROMFS resource imports: size lookup and bounded read by name and expected
  `ROMFS_FLAG_DATA`. Do not expose `romfs_file_t`, mutable kernel state, or a
  general filesystem API. Pin callback order and all ABI structure layouts in
  tests/documentation.
- Change console dispatch to `char_ops`. `console_bind_defaults()` first seeks
  HID+CONSOLE_IN and VIDEO+CONSOLE_OUT, independently falling back to any
  matching generic console capability. One missing direction must not clear a
  valid other direction. SIO remains both-direction fallback.
- Replace the production fixed arena with a deterministic two-pass (or equally
  reproducible) link: derive the exclusive maximum end of every loadable bank-7
  area (`_CODE`, `_HOME`, `_INITIALIZER`, `_GSINIT`, `_GSFINAL`) from the probe
  map, export it as `__kernel_code_end`, align it upward to `0200h`, and export
  that as `__driver_arena_start`; end is exactly `C000h`. Keep 512-byte
  allocation. Fail the build below 32 granules/16 KiB. Keep `C000h-DFFFh`
  outside the allocator.
- Make loader bitmap/count logic use linked runtime geometry, bounded by the
  architectural maximum from `2000h-C000h`; do not retain a compiled count of
  16. Preserve first-fit, rollback, zeroing, handler validation, and no-unload.
- Update map/image tools and manifests to report static-kernel end, arena
  bounds/size, every production module's image+BSS/granules, total used/free
  granules, and fail if the full declared boot set cannot coexist. Preserve a
  deliberate legacy/variant mechanism for M1-M7 and shifted-placement tests;
  do not weaken their checks to accommodate production geometry.

## Files

- `include/zephyros/{device,driver,module,console}.h`
- `kernel/device/`, `kernel/module/`, `kernel/romfs/romfs.c`
- `kernel/irq/code_end.asm`, `platform/zephyr80/memory.{h,inc}`
- `drivers/sio/`, `modules/manifests/`, `tests/modules/`
- `Makefile`, `linker/`, `tools/{mapcheck,pack_image,zmodpack}.py`, `tests/`
- `docs/{architecture,devices,module-format,memory}.md`

## Constraints

- Platform files remain declarative; generated geometry belongs under the
  build directory. No generated file is committed.
- ZMOD v1 bytes/layout and 512-byte relocation semantics remain unchanged.
- Do not add IOC, HID, or V9958 behavior in this package. No Zephyr-80 source
  or firmware file may be modified.

## Validation

```sh
make clean
make check
make zmod-test
make m4-loader-selftest
make m4-selftest
make m4-placement-selftest
make m4-failure-selftest
make romfs-test
make m6-selftest
make monitor-test
make m7-selftest
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/modules/monitor.zex
make clean
```

Add negative tests for ABI 1, malformed class interfaces, capability high bits,
an arena one granule below 16 KiB, unaligned code end, module-sum overflow, and
linked bytes in the derived arena.

## Acceptance criteria

- ABI v2/class discovery and preferred-direction console binding are fully
  tested; SIO fallback still works.
- Production arena start equals aligned linked-kernel end, end is `C000h`, at
  least 16 KiB remains, and build reports reconcile exactly.
- All earlier suites pass and `monitor.zex` retains the recorded M7 hash.
