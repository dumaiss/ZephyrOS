# Task

Implement the first half of milestone M4: reserve and manage a bank-7 driver arena, define Zephyr Module Format v1 (ZMOD), build host-side pack/dump/validation tooling, and implement a transactional kernel loader with relocation, BSS allocation, versioned driver imports, and rollback. Do not migrate the SIO driver yet; this stage proves loader correctness before hardware integration.

## Context

M3 provides the stable internal device registry, driver API v1, registration checkpoints, console service, and M2 IRQ claims. M4 must reuse those contracts. Modules are boot-loaded from bytes, remain resident until reboot, and cannot directly import private kernel symbols.

Reserve `A000h-BFFFh` as the initial 8192-byte bank-7 driver arena: 16 contiguous 512-byte granules. Restrict linked kernel code/rodata to `2000h-9FFFh`; existing initialized/runtime data and the M2 ISR stack retain their established regions. Export `__driver_arena_start` and `__driver_arena_end`; module code must not depend on their numeric values.

Define a packed little-endian ZMOD v1 header of 28 bytes:

```text
00 magic[4]="ZMOD"   04 format_version:u8   05 type:u8 (1=DRIVER)
06 driver_abi:u8      07 flags:u8
08 image_size:u16     0A bss_size:u16        0C required_granules:u16
0E init_offset:u16    10 fini_offset:u16 (FFFFh=none)
12 reloc_offset:u16   14 reloc_count:u16
16 payload_offset:u16 18 total_size:u16       1A reserved:u16 (=0)
```

Each relocation record is four bytes: `type:u8`, `reserved:u8 (=0)`, `patch_offset:u16`; type 1 is `ZREL_ABS16`. The payload is the linked-at-zero image. All offsets/sizes are relative to the ZMOD start except entry/patch offsets, which are relative to the loaded image.

## Requirements

- Add linker/memory declarations for the arena and make the normal linker, packer, manifest, and `mapcheck.py` reject any kernel section, initialized data, stack, or ROM payload in it. Report total/free granules in build output.
- Implement a deterministic first-fit allocator over 16 granules plus module descriptors. Allocation rounds `image_size + bss_size` upward to 512 bytes, cross-checks header `required_granules`, rejects zero/overflow/exhaustion, and supports freeing only an uncommitted failed load. No public unload operation exists.
- Add `include/zephyros/module.h` with fixed-width on-disk definitions, error codes, loader state, and compile-time size/offset assertions suitable for SDCC and host tests.
- Implement `tools/zmodpack.py` with `pack`, `validate`, and `dump` modes. Consume supported ASxxxx/SDCC relocatable outputs and a small explicit module manifest naming init/fini/BSS. Parse relocation records as the source of truth; do not infer pointers by scanning bytes. Accept only module-local 16-bit absolute relocations, emit `ZREL_ABS16`, and reject unresolved externals, unsupported relocation modes, out-of-range entries/patches, overlap, truncation, overflow, bad reserved fields, or ABI/type mismatch.
- Isolate module builds from kernel links. Link module images at base zero; all private pointers are offsets corrected by relocation. A module may reach the kernel only through the passed `const struct zdriver_api *`; direct references to kernel symbols are a pack-time error.
- Implement header validation before touching the arena. After allocation, copy image, zero BSS, validate and apply each `ZREL_ABS16` as `word += load_base`, construct a LOADING descriptor, and call the relocated init entry with driver API v1.
- Make initialization transactional across arena allocation, device registrations, and IRQ claims. Associate registrations/claims with the loading module owner. On validation, relocation, or init failure, invoke valid optional fini only for init cleanup, roll back that owner's IRQ/device changes, zero/release its allocation, and leave earlier modules/devices untouched. On success mark it RESIDENT; it cannot be freed.
- Extend IRQ handler validation to accept either linked bank-7 kernel handlers or addresses wholly inside a RESIDENT executable module allocation. Reject LOADING/failed/out-of-arena addresses.
- Add an embedded-catalog interface that accepts name/blob/size entries but populate it only with loader test fixtures in this stage. The loader must operate on catalog bytes without filesystem assumptions.
- Add extensive host tests for header fields, endian layout, pack/dump round trips, unsupported relocations/imports, corrupted offsets/sizes, arithmetic overflow, arena fragmentation/exhaustion, relocation boundaries, BSS zeroing, API mismatch, state transitions, and rollback after staged device/IRQ registration.
- Add target-side synthetic modules proving relocation at two arena addresses and failed-init rollback. These need not drive hardware. Preserve all M0–M3 output and behavior.
- Document ZMOD v1 and the loader lifecycle in `docs/module-format.md`; update the architectural implementation notes without redesigning the accepted format.

## Files

Likely files to create or modify:

- `include/zephyros/module.h`
- `kernel/module/loader.c`
- `kernel/module/relocate.c`
- `kernel/module/embedded.c`
- `tools/zmodpack.py`
- `linker/zephyr80.lk`
- `platform/zephyr80/memory.inc`
- `kernel/device/registry.c`
- `kernel/irq/irq.c`
- `Makefile`
- `tools/mapcheck.py`
- `tests/`
- `docs/module-format.md`

## Constraints

- Only module type DRIVER, ABI v1, and `ZREL_ABS16` are supported.
- No filesystem source, runtime unload, hot-plug, replacement, reference counting, arbitrary kernel imports, or executable/user module semantics.
- Validate all arithmetic in wider host/kernel intermediates before narrowing to 16 bits.
- Never mutate the arena until the entire container structure is validated.

## Validation

```sh
make clean
make
make test
make check
make zmod-test
make m4-loader-selftest
```

## Acceptance criteria

- The arena is linker-reserved, granule-managed, reported, and protected by negative tests.
- ZMOD pack/validate/dump produces deterministic containers and rejects every unsupported or corrupt case precisely.
- Synthetic modules relocate and initialize at different valid addresses from identical module bytes.
- BSS is zero and failed loads fully roll back allocation, devices, and IRQ claims.
- Resident handler validation accepts only linked kernel or committed module code.
- All M0–M3 validation remains green.
