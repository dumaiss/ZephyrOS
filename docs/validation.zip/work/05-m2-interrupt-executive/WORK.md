# Task

Implement milestone M2 as defined by `docs/architecture.md`: add a kernel-owned Z80 IM2 interrupt executive, safe common-memory entry/return from either memory mode, fixed logical-source ownership, separate common-transition and bank-7 ISR stacks, a safe `FFh` vector, and a physical-hardware CTC0 self-test. Preserve all accepted M0/M1 behavior.

## Context

M1 enters the kernel in mode `11`, uses common memory at `E000h-FFFFh`, and has a single-depth syscall gate. The syscall gate currently assumes interrupts are disabled; M2 must make it safe once foreground execution enables interrupts. IRQ delivery is non-nested and kernel-owned.

Reserve this layout explicitly:

- `FD00h-FDFFh`: 256-byte-aligned IM2 vector page; `I=FDh`.
- `FE00h`: mandatory guard byte for vector `FFh`.
- `FE01h-FE7Fh`: common IRQ transition state.
- `FE80h-FEFFh`: 128-byte common IRQ transition stack.
- `DF00h-DFFFh`: 256-byte bank-7 ISR stack, initial `SP=E000h`.
- Existing boot stack remains `FF00h-FFFFh`.

Restrict ordinary common code/data to below `FD00h` and ordinary bank-7 runtime data to below `DF00h`. Source IDs are `IRQ_CTC0`, `IRQ_CTC1`, `IRQ_CTC2`, `IRQ_CTC3`, `IRQ_SIO0`, `IRQ_SIO1`, and `IRQ_VDP_FF`; only CTC0 must be enabled in M2. CTC0 is physical port `40h`, CPU clock 10 MHz, daisy-chain priority CTC → SIO0 → SIO1. The test setup may use vector base `00h`, control `A7h`, constant `00h`, and teardown `03h`.

## Requirements

- Add `include/zephyros/irq.h`, bank-7 registry/dispatch code, common assembly entry/source stubs, and Zephyr-80 source mapping. Implement fixed one-owner semantics equivalent to `irq_claim(source, handler, context)` and `irq_release(source)`; mutation occurs under `DI`, invalid sources/duplicate claims fail predictably, and handler/context live in bank 7.
- Create a runtime-initialized IM2 page plus guard in dedicated linker areas. Install valid common-memory entry targets for every enabled vector. Derive bytes `FDFFh/FE00h` from the linked address of `irq_ff_unexpected`; `mapcheck.py` and image validation must prove `word_at(FDFFh) == irq_ff_unexpected`.
- Implement per-source common stubs that preserve the interrupted `AF` before recording source identity. The generic gate must save interrupted SP before using the stack, switch to the common IRQ stack, preserve `AF/BC/DE/HL`, `IX/IY`, alternate `AF'`, and alternate `BC'/DE'/HL'`, and save the exact port-`00h` latch.
- If entry was mode `10`, enter `18h|saved_bank`; if already mode `11`, retain that mapping. Then switch to the bank-7 ISR stack, dispatch the registered handler, return to the common stack, restore the exact latch/context/SP, and execute `RETI`. Keep maskable interrupts disabled throughout; do not allow nesting.
- Validate handler addresses before accepting a claim. M2 accepts only linked bank-7 kernel code (`2000h` through the linker-defined kernel-code end); M4 will extend this to resident modules. Drivers never write the IM2 table directly and never execute `RETI`.
- Record compact unexpected/unclaimed counters and the last logical source. Do not print from IRQ context. For CTC0, provide a safe quiesce/reset path.
- Retrofit the syscall gate for enabled foreground interrupts. It must atomically capture whether maskable interrupts were enabled, execute the single-depth crossing with interrupts masked, and restore the prior enabled/disabled state immediately before returning. An IRQ must never observe partially changed syscall transition state. Update `docs/abi.md` accordingly.
- Add `irq_init()` and call it only after early-console and memory initialization. Register the CTC0 self-test handler before programming the CTC, set `I=FDh`, select IM2, and execute `EI` only after all tables/state are valid.
- Add an `irq-selftest` image/target. It must exercise interrupts from both mode `10` (application stack above `2000h`, banks 0 and 6) and mode `11`, verify full main/alternate register state, SP, PC, mapping, bank identity, repeated handler delivery, clean teardown, and the unclaimed path. Print `irq selftest: OK` only after every check passes.
- Extend the CPU simulator only as needed to replay the real linked entry/return bytes, including IM2 acceptance, alternate registers, `I`, IFF state, and `RETI`. Physical hardware remains authoritative for CTC timing/acknowledgement and daisy-chain behavior.
- Extend linker/map/image validation and negative fixtures for all new reserved regions, stack sizes, vector alignment, entry placement, handler placement, and the `FFh` guard relationship.

## Files

Likely files to create or modify:

- `include/zephyros/irq.h`
- `kernel/irq/irq.c`
- `kernel/irq/entry.asm`
- `kernel/irq/vectors.asm`
- `platform/zephyr80/irq.asm`
- `platform/zephyr80/irq_sources.c`
- `platform/zephyr80/hardware.h`
- `platform/zephyr80/hardware.inc`
- `platform/zephyr80/memory.inc`
- `platform/zephyr80/syscall_entry.asm`
- `kernel/main.c`
- `linker/zephyr80.lk`
- `tools/mapcheck.py`
- `tests/`
- `Makefile`
- `docs/abi.md`
- `docs/validation/`

## Constraints

- No nesting, preemption, scheduling, application vector tables, device registry, or general timer service.
- Common memory contains only vectors, source stubs, transition machinery/state, and transition stack; handlers and registry policy remain in bank 7.
- Preserve the early console and panic path; no lengthy serial output from IRQ context.
- Do not infer CTC1/CTC2 port ordering. M2 uses physical CTC0 at `40h` only.

## Validation

```sh
make clean
make
make test
make check
make irq-selftest
make smoke-hardware-irq SERIAL_PORT=/dev/ttyUSB0
```

Record the physical CTC0 result and exact serial transcript in a dated M2 acceptance record. Mark target validation pending if it was not observed.

## Acceptance criteria

- All M2 criteria in `docs/architecture.md` section 19 pass.
- IM2/guard and both IRQ stacks are linker-reserved and automatically validated.
- IRQs from modes `10` and `11` restore full documented context and exact mapping.
- CTC0 repeatedly dispatches a registered bank-7 handler and tears down cleanly on physical hardware.
- M0/M1 builds, syscall tests, early console, and hardware behavior remain valid.
