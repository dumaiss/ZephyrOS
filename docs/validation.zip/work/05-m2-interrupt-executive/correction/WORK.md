# Correction

The M2 IM2 initializer corrupts the mandatory `FFh` guard at runtime. The linked image correctly stores the little-endian address of `irq_ff_unexpected` at `FDFFh/FE00h`, but `_irq_arch_init` fills `FD00h-FDFFh` as alternating low/high bytes and therefore overwrites `FDFFh` with the target's high byte. For the current link (`irq_ff_unexpected = E17Dh`), vector `FFh` becomes `E1E1h` after initialization. The existing simulator test checks only the pre-initialized ROM bytes and does not expose this.

## Required changes

- Make `_irq_arch_init` leave both vector `00h` and vector `FFh` pointing to their intended common-memory stubs after all runtime table initialization. Preserve the linked `FDFFh/FE00h` guard relationship and derive its bytes from the linked address; do not hard-code the current target address.
- Do not claim that every odd IM2 vector is safe unless the implementation actually guarantees it. M2 enables only CTC0 vector `00h`; the mandatory fallback is vector `FFh`.
- Extend `tests/test_irq_sim.py` (and the simulator only if necessary) to execute the real linked `_irq_arch_init` bytes, then assert `I=FDh`, IM2 selected, interrupts enabled, vector `00h` targets `irq_ctc0_stub`, and `word_at(FDFFh)` still targets `irq_ff_unexpected`. The test must verify runtime state rather than only packed-image bytes.
- Keep the correction scoped to this defect. Preserve the unrelated deletion of `docs/architecture(6).md`.

## Validation

```sh
make clean
make
make test
make check
make syscall-selftest
python3 -m unittest tests.test_syscall_sim -v
make irq-selftest
python3 -m unittest discover -s tests -v
git diff --check
```

## Acceptance criteria

- Runtime initialization cannot corrupt the `FFh` vector/guard.
- The real initializer is covered by linked-byte simulation.
- All M0-M2 host validation remains green with no new build warnings.
