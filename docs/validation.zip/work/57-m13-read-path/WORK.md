> **DRAFT. Not dispatched.** Runs after 56. **Measurement only:** this
> package builds the instrument and stops. The owner runs it on the board
> and the supervisor writes the fix package from the numbers.

# Task

File reads run at ~10 KiB/s on KonaOS against ~39 KiB/s for CP/M on the
same card and the **same IOC firmware and FS2 commands**: a 512-byte read
takes ~50 ms on KonaOS (owner's SDBENCH port, flat per byte across
128 B..4 KiB requests) and 12.8 ms on CP/M's SDBENCH (512-byte ZREAD
pieces). The port was reviewed: only the `read` is timed, the clock's own
cost is calibrated out, its buffer is at ~3719h. KonaOS sends exactly one
`FS2_READ` per block, and both sides run the command lane with CRC. So
~37 ms per block is Z80-side KonaOS cost. The simulator cannot time the
card lane honestly, so the numbers must come from the board.

Read: `work/00-WORKER.md`; architecture 4.9 (IPC copy paths A/B/C) and
5.x (IOC, IOC-FAT); `drivers/ioc/ioc.c`, `ioc_io.asm`,
`drivers/iocfat/iocfat.c`; the CP/M path for comparison:
`../Zephyr-80/Code/HOST/CPM2.2/src/drivers/storage/fat.asm`
(`fat_fs2_read`), `.../core/iocall.asm`, `ioc_command.asm` (`IOCBULK`).

## Requirements

1. **Phase timestamps.** A build option `KOS_IOC_PHASES=1` (off in every
   shipped image) records the timer clock (25.6 µs counts, read the cheap
   way inside the driver: tick count and down-counter, no IPC) at each
   step of one block read, into a small table in the drivers' own data:
   - IOC-FAT entered (the `KFILE_OP_READ` call);
   - cache hit or miss decided;
   - FS2_READ request built (CRC included) and sent;
   - reply received and validated;
   - bulk admission (DCD), first bulk byte, last bulk byte;
   - copy into the IOC-FAT buffer done;
   - `copy_out` to the caller done, and which copy path (A/B/C) it took;
   - IOC-FAT returns.
   Add a read-only way for a program to fetch the last block's table
   (a new IOC-FAT protocol op, present only with the option).
2. **`readphase`**, a program built for the card (`tests/perf/readphase.c`,
   copied like `devtest`): reads a file named on its tail in 512-byte
   calls (and once in 128-byte calls), fetches the phase table after each
   block, and at the end prints, per phase, min/mean/max in ms, plus the
   copy path counts. Two passes: its buffer below `8000h` and in
   `8000h-BFFFh`. Nothing is printed while timing.
3. **An image for the owner**: the production build with
   `KOS_IOC_PHASES=1` (its own make target), plus `readphase.exe` for the
   card. Record both hashes.
4. **No fix in this package.** Do not change behaviour, buffers, copy
   paths or the protocol (beyond the option-only op).

## Tests

- Host: the option is off in production (`systems/*.json`, the build
  flags) and the phase op absent there.
- Simulator: `readphase` runs in the instrumented image with a card file
  and prints a well-formed table (the values are not judged).

## Hand-off

Stop after the record. The owner runs, on the board, from the card:
`readphase BIG.BIN` (a file of several hundred KiB), and sends the table.

## Validation (targeted)

```sh
make
make <the instrumented image target>
python3 -m unittest tests.test_ioc tests.test_iocfat tests.<new tests>
git diff --check
```

Record: `docs/validation/<date>-m13-read-path-measure.md`, with the
image and program hashes and the simulator table.
