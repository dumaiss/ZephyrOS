# KonaOS worker rules

## Role
Implement one assigned `WORK.md`, validate it, hand off accurately. Do not redesign, expand scope, reinterpret criteria or start the next package. `WORK.md` is the contract; `docs/architecture.md` the wider rules. On a blocking conflict or ambiguity, stop and report it exactly.

## Working memory: `progress.md`
- **Create `work/<package>/progress.md` before your first edit.** It is your memory after a context compaction, not a report: present-tense notes.
- **Update it before** a second attempt at the same fix, re-reading a file or re-running a command already done this session, or starting work `WORK.md` does not name.
- Each in-progress item: what is verified (with the command), the hypothesis, the exact blocker, the next action.
- When the next action is unclear, write `STATUS: STEER REQUIRED` and the question, then stop.
- **Taking over a dirty tree:** first classify every modified file (package work / unrelated / unclassified); any unclassified file is `STEER REQUIRED`. No implementation before that.

## Before editing
1. Read this file, all of `WORK.md` and what it references. **Every file and function `WORK.md` names must exist as described; if not, stop** (names go stale).
2. Inspect the code involved, its callers, build rules, tests and validators; `rg` every consumer before changing an interface.
3. Note `git status --short`: pre-existing changes are preserved.

## Implementation
- Smallest coherent diff, in the existing style. No speculative abstractions, no stylistic rewrites.
- **No backward compatibility:** update every producer and consumer; no aliases or shims.
- After a move or rename, update every reference (build, includes, docs, tests, manifests, validators).
- Production holds no acceptance-only code; test code lives under `tests/`. An unavoidable hook uses the documented test-build guard, labelled `TEST-ONLY HOOK`.
- **Dead code goes first**, while production boots and `make check` stays green; report bytes freed. Remove replaced machinery completely.
- No destructive git. Generated output only in `make clean` directories. Never delete an untracked-by-you file without checking git tracks it.
- **Budgets:** `WORK.md` states each constrained figure (tier room, reserve, image share) and the rule on overrun. Report before and after; on an overrun without a rule, stop.
- **Found outside scope** (a real bug in code you did not come to change): record it in `progress.md`; fix it only if it blocks a **Must**, else list it for the supervisor.
- **Simulator models:** a new or changed peer model cites the real implementation it mirrors (file and function: firmware, hardware notes) and lists what it does not model; that list goes into the owner checklist.

## Writing: the tree is "as is, now"
Docs, comments, tests, messages and JSON describe the current system in the present tense. History lives only in `docs/validation/`, `work/` and git. No package or milestone numbers, `work/` paths, dates, or change words ("now", "new", "no longer", "formerly", "replaces", "moved"). Keep the reason, drop the history. Architecture edits go in the subsystem's section, update its cross-references, and remove the roadmap item the package completes. Check: `git diff -U0 | grep -E '^\+.*([Pp]ackage [0-9]|\bM[0-9]{1,2}\b|work/|[Cc]orrection [0-9]|no longer|formerly|retired)'` prints nothing.

## Tests
- A test follows its subject: a retired mechanism's tests are deleted, not ported. Assert observable outcomes; assert internal traces only where `WORK.md` names the property.
- Simulator hooks keyed on an address also check the latch.
- **Debugging code:** `tests/z80sim.py` is a Z80 you can drive directly (C core, about 10M instructions/s):
  - **A fragment:** `Z80(page0, page1)`, write bytes into `z.bank0`, set `z.pc` and the registers, then `z.step()` or `z.run(n, StopSet(...))` (see `tests/test_bcall.py`).
  - **In a replay:** stop at a symbol from the program's `.map`. EXE addresses are fixed (loaded at 0100h in its own bank), so check `z.bank_of(z.pc)` too, not offsets.
  - **Per-function T-states:** `work/88-konaedit-view/keprof.py`.
  - Never write another interpreter.
- Few, focused tests for the new mechanism; no refactoring of unrelated tests (note issues in the record).
- **Each failure, before any fix:** a `progress.md` entry with test, one-line failure, class and evidence. Classes: `implementation` (the test pins accepted behaviour; the code drifted), `test artifact` (the test is stale against an accepted source, cited: a record, a transcript, a hash, the `WORK.md` line), `unknown` (`STEER REQUIRED`). A `test artifact` without a cited source is `unknown`. **No expected output is edited before its entry is classified**; the record lists every pin changed with its source.
- "Failed, then passed on rerun" is not fixed: record both runs and classify.
- `make check` is green at handoff; no deferred failures.

## Criteria
`WORK.md` marks each criterion **Must** (miss fails the package), **Should** (a target with a tolerance; a miss is a finding) or **Informational** (record the number). Unmarked numbers are Informational. For a structural requirement, produce the observable property `WORK.md` names (for example a `_Static_assert`), and state its form in the record.

## Stop and report when
the package contradicts the architecture or accepted behaviour; a choice would change scope or the ABI; an overlapping change cannot be preserved; hardware, data or authority is missing; meeting the contract would weaken a criterion. Difficulty is not a reason to stop.

## Validation (lean, once)
- Build early; iterate with incremental `make` and focused test modules.
- The formal validation runs **once, at the end, as one batch**, wall-clock recorded. `make clean && make check` (~25 min) is never run while developing, and only when `WORK.md` lists it (OS changes); an SDK- or application-only package runs the focused suites `WORK.md` names instead.
- `make clean` removes acceptance images, so `make check` skips their replays. **Run every image target `WORK.md` lists** (`make console-serial-selftest`, `make fs-selftest`, ...) after your last edit; the record lists each as run or not run, with the reason.
- Build only the images and run only the tests `WORK.md` names (no `make hardware-images`); run each listed command, report extras with the reason. Record exact pass/fail/skip counts, warnings, image names and hashes; an unexpected warning or skip is a finding.
- Never reuse old hashes. Byte identity is not acceptance; booting and the tests are.
- `git diff --check`; finish with a clean tree when required.
- **Spike packages** answer "does it boot, and what are the numbers": production unchanged, no coverage work.
- **Hardware:** the simulator does not prove interrupt timing, wiring or analog behaviour; MAME is not acceptance. Keep the smoke transcript, or report `PENDING` with image, hash and the owner's steps.

## Shared tree
Do not edit another active task's files. A file changing unexpectedly: stop editing it, report it, discard nothing. Freeze sources once final validation starts; never report results from a build older than the final source.

## Corrections
Implement only the delta, keep the accepted parts, add the requested regression tests and rerun what the correction invalidates.

## Handoff
The report is `docs/validation/<date>-<package-name>.md`: files added, moved, removed or changed; the result; commands and results; hashes and transcripts; budgets before and after; pins changed with their sources; found-outside-scope items; for each "preserve X", how you verified X survived; warnings, skips, pending hardware, deviations. State that unrelated changes were preserved. Do not start the next package.

## Done means
Every Must met; architecture, code, build, tests and docs agree; the final tree passes the required validation with no regressions or debris; the hardware status is accurate; the supervisor can reproduce the result.
