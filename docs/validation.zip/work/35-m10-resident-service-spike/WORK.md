# Task

Test the resident-service architecture (a bank-7 nucleus, a bank-6 resident
service domain, endpoint handles, synchronous call/reply IPC, nucleus-validated
buffer descriptors) on Zephyr-80 **before** it becomes the architecture. Build
a minimal, real IPC substrate and a set of **synthetic services shaped like the
real ones**, in an evaluation configuration. Test them on the revision-13
transports from `docs/architecture-proposal.md` Part II:

- **A, the 24 KiB window** (adopted by package 34): the full claim set
  C1-C9;
- **B, the 8 KiB slot overlay** (owner proposal): a focused evaluation of
  where it differs from A;
- **C, the revision-12 gate:** no new runs; reuse package 34's measured
  numbers as the baseline.

Then answer, with numbers, whether the design works, choose between A and B,
and pin the open design parameters (frame size, nesting limit, re-entrancy
rule, descriptor model, transport) for the phase-0 decision record.

## Context

Dispatch after package 34 is accepted. This package uses its revision-13
simulator model and its fixed/cold classification of the nucleus. Read
`work/00-WORKER.md` ("Working efficiently"), `work/M10-REFERENCE.md`, the
package-33 and package-34 reports, `docs/architecture-proposal.md` (the
resident-service architecture proposal, the revision-13 hardware basis and
transport options, and the review points this spike must answer), `kernel/process/{far.asm,launch.asm}` (spike),
`kernel/memory/user_copy.asm`, `kernel/irq/`, and `tests/z80sim.py`.

The production configuration stays unchanged. Everything here builds as
`ZOS_RSVC_SPIKE=1`, in its own build directory: one image for transport A,
and for transport B either a second image or the same image under a decoder
variant. The simulator's default stays revision 12.

**What success means here (owner instruction): "does it boot, and what are
the numbers".** This is a design spike, not an acceptance pass. The spike
images must boot in the simulator and run their measurements; the report's
numbers are the deliverable. Do not spend time making unrelated tests green,
extending test coverage, or hardening edge cases beyond what a measurement
needs. Proper testing happens in the implementation packages.

**Test economy:** Do not build or run the full image matrix (all M9/M10
acceptance images plus `unittest discover` with every image built), which
takes over 1.5 hours. A production-like check is enough: `make check` for
production, the spike image(s), and their own test modules. Whether every
other configuration still boots is a question for the implementation
packages, not for this spike.

## Claims under test, and how

| # | claim | evidence required |
|---|---|---|
| C1 | Synchronous endpoint IPC with a small bounded frame serves real protocols | one frame size works for every synthetic protocol below without side channels |
| C2 | No raw cross-domain pointers are needed | services receive only endpoint handles and nucleus-issued buffer descriptors, and move payloads only through a nucleus copy primitive; a test proves a service cannot name a caller address |
| C3 | Crossing cost is acceptable with batching | cycles per call for a null call and per protocol on transport A, with throughput for console write and 512-byte reads compared with today's direct path; gate figures reused from package 34 |
| C4 | Real call graphs nest within a small fixed bound | the deepest chain (app → VFS-like → FAT-like → IOC-like) and the loader upcall chain run, with per-domain stack high-water marks and the maximum nesting depth |
| C5 | Same-domain calls are an invisible optimization | the same client code gives identical results through the nucleus path and the same-domain fast path; the conformance suite runs both |
| C6 | IRQs can be owned by services | a service-claimed IRQ (the test-owned CTC0 helper) fires while a service call is in progress, the handler runs in the service domain on a service-safe stack, the nucleus does the final `RETI`, and the interrupted call completes correctly |
| C7 | Re-entrancy is detectable and refusable | a re-entrant call into a service already on the call stack is refused by the nucleus with `ZOS_EBUSY`, unless the endpoint declares itself re-entrant |
| C8 | Nucleus → service upcalls work | process-exit notification reaches a VFS-like endpoint, and the loader streams an executable through the VFS-like → FAT-like chain using a nucleus-held object handle (no pathname in the nucleus) |
| C9 | The nucleus fits bank 7 with room for M10 | a projected nucleus ledger: today's kernel objects classified nucleus or service (from package 34), plus the measured IPC substrate, plus the package-33 M10 mechanisms; projected bank-6 service occupancy for the current modules plus VFS and providers |

## Build (evaluation configuration only)

1. **IPC substrate in the nucleus.**
   - An endpoint table holding nucleus-owned metadata: owner, class,
     instance, version, domain, dispatch target, a re-entrancy flag and a
     busy flag.
   - `register`, `lookup(class, instance)` and `call(endpoint, op, frame)`.
   - A bounded request/reply frame (start at 16 bytes; measure 8/16/32).
   - Buffer descriptors captured at call entry (execution bank, address,
     length, direction), handed to services as small ids, and used only via
     `copy_in`/`copy_out` primitives.
   - Transport A (the package-34 window select) behind a transport-neutral
     interface, so B can be substituted without changing the services or
     clients. The gate (C) is not rebuilt; its costs come from package 34.
   - Reuse `zos_bank_copy` or the window `LDIR` for copies, the existing IRQ
     executive for IRQ claims, and the bank map for bank 6's exclusion from
     the application pool. Nothing in this list gets a second
     implementation.
2. **Bank-6 resident loading.** Load the synthetic services as ZMOD images
   relocated into bank 6 (the existing relocator; the base differs).
   Registration copies metadata into nucleus storage.
3. **Synthetic services**, each small but protocol-real:
   - `echo`: the null call, for raw cost.
   - `con`: `WRITE(desc, len)` copies from the caller descriptor and
     forwards to the existing V9958 or SIO path, plus `GETC`/`POLL`.
     Measured at 1, 16, 64 and 256 bytes per call.
   - `ioc`, `fat`, `vfs`: a chain where `vfs.READ(handle, desc, 512)` calls
     `fat.READ`, which calls `ioc.READ`. `ioc` fills 512 bytes in bank 6 and
     the payload reaches the caller through a descriptor. One variant
     copies directly (the service copies to the caller's descriptor); one
     stages through the chain. Measure both.
   - an IRQ-owning service, for C6.
   - `vfs.on_process_exit` and an executable-stream read, for C8.
4. **Client stubs.** SDK-style C stubs for `con` and `vfs` in the test ZEX,
   to confirm user-space marshaling cost and size.
5. **Transport B: the 8 KiB slot overlay (focused evaluation).** In mode 11,
   P selects which 8 KiB region of the OS view shows bank 6 at the same
   offset:
   - P = 0: none (revision 12);
   - P = 1-6: regions `2000h` … `C000h`;
   - P = 7: `0000h-1FFFh`.

   Add it as `decoder_revision=13`'s variant `"overlay"` in `tests/z80sim.py`
   and as `platform/zephyr80/hdl/MEM_DECODER_rev13b.pld` with vectors.
   Measure only what differs from A:
   - **Product-term fit:** count terms per `RAM_A1x` (the supervisor's hand
     count is about 11 on `RAM_A16`, whose budget is 10) for: all 7 slots;
     without P = 7; and with one bank-7 region reserved as a never-overlaid
     nucleus core. Say whether a mode-10 far aperture would still fit
     beside it. If WinCUPL is unavailable, derive by hand and give the owner
     the PLD to compile.
   - **Slot plan:** assign today's real modules and the projected VFS and
     providers (sizes from the M9 ledger and package 34) to 8 KiB slots, and
     list what does not fit one slot.
   - **The never-overlaid core:** size what must stay visible whatever slot
     is open (gates, IPC dispatch, cross-slot stub, IRQ dispatch, ISR stack,
     data services or interrupts touch) and where it lives (common or a
     reserved region).
   - **Costs:** a same-slot call, a cross-slot service → service call
     through the nucleus stub, and an IRQ with a slot open. Run them on the
     same synthetic services (`echo`, the `vfs`→`fat`→`ioc` chain split
     across slots), not the full C1-C9 matrix.

## Report

Write `docs/validation/<date>-m10-resident-service-spike.md` with:

- **A table of the C1-C9 claims, each confirmed or refuted**, with evidence.
- **Cycle tables** for transport A, with package 34's gate figures as the
  baseline:
  - a null call;
  - a call per frame size;
  - `con.WRITE` at each size, as cycles per byte, compared with today's
    console write;
  - a 512-byte chained read (direct versus staged), compared with today's
    `FS_READ` of a 512-byte chunk;
  - the IRQ latency added when the handler is in the service domain.
- **Stack high-water marks** per domain and the deepest nesting observed.
- **Resident bytes:** bank-7 IPC substrate, common memory used by each
  transport, bank-6 service domain overhead (dispatchers), and client stub
  size.
- **The projected nucleus and service-domain ledgers (C9)**, with the
  package-33 M10 mechanisms placed on the nucleus side.
- **An A-versus-B comparison** covering:
  - product-term fit, including room for a mode-10 aperture;
  - bank-6 capacity and the slot plan;
  - the size of the never-overlaid core;
  - same-slot and cross-slot call costs;
  - IRQ behavior;
  - what each forces on service design (8 KiB limit, cross-slot calls).
- **Pinned recommendations for phase 0:** frame size, nesting limit,
  re-entrancy rule, descriptor model (direct versus staged copies),
  transport (A, B, or a combination, with split or slot plan), the
  common-ceiling revision, and any architecture point the evidence
  contradicts.

## Constraints

- **Production unchanged** (image hash identical to package 34's). The
  simulator defaults to revision 12.
- Evaluation code only. No real driver or VFS migration, and no syscall
  changes outside the spike configuration.
- Keep the substrate minimal; no asynchronous queues, no revocation, no
  generic marshaling. If a claim fails, stop expanding scope: report the
  failure and what the architecture would need instead.

## Validation

At the efficiency defaults, run one formal batch:

```sh
make clean && make check          # production only: reproducible hash + host suite
make rsvc-spike-selftest          # the spike image(s) for A and B, and their sims
python3 -m unittest tests.test_rsvc_spike tests.test_rsvc_spike_sim tests.test_decoder_rev13 -v
git diff --check
```

Nothing else. Do not build other acceptance images (`m9-*`, `subsystem`,
`rev13-eval`, `m10-spike` and so on), and do not run `unittest discover`
after building images. Skips in `make check`'s host suite for images that
were not built are expected. Report the batch's wall-clock time; the target
is under 15 minutes.

Hardware: if revision 13 has been programmed, the owner may run the
window-transport image; IRQ interaction and bank switching are
hardware-authoritative. Otherwise record `PENDING (spike)`.

## Acceptance criteria

The deciding question is "does it boot, and what are the numbers".

- Every claim C1-C9 has a measured verdict on transport A. Transport B has
  its product-term fit, slot plan, never-overlaid core size and call/IRQ
  costs, and the report compares A and B.
- The report pins the phase-0 parameters, or names exactly which
  architecture assumption failed.
- The production image is unchanged.
