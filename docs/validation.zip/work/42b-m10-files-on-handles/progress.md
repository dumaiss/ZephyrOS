# 42b-m10-files-on-handles — checkpoint status

Contract: [WORK.md](./WORK.md).  Baseline is the committed 42a tree
(`a42a520 42a m10`), clean.  Report: `docs/validation/2026-10-09-m10-files-on-handles.md`.

Last update: after porting the acceptance programs (round 2) and the
first IOC-FAT acceptance replay.  **Open bug:** the card namespace
operations (`zos_mkdir`/`unlink`/...) return `-ZOS_ENOENT` in the
`m9-iocfat-selftest` image *before* the kernel sees a `SYS_CALL` (the
bind of `/FS` works: handle 3, type 0x08).  Two real bugs were found and
fixed on the way (see "Driver first-contact" below); the third symptom
is still open.  The non-replay host suites are green (639 tests, 6
failures all reconciled; 145 in the four touched suites).

## Reconnaissance (done)

- `git status --short` clean at `a42a520`.
- 42a record read (`docs/validation/2026-10-09-m10-namespace-handles.md`
  and `work/42a-m10-namespace-handles/progress.md`): the namespace family
  is built behind `ZOS_NS_HANDLES` (56 sites, 13 files) + 3 `test_link`
  entries; 42b deletes the macro, the `#else` halves, the `test_link`
  entries, the arena/`module_loader`/`ioc_shim`, `fs`, the M9 VFS
  machinery, the registry (dead in production) and the M9 `FS_*` family.
- Frees table (42a): `fs` 2,727, `vfs_mount` 2,235 fixed, `vfs_file`
  2,484 fixed, `vfs_dir` 1,576, `vfs_mutate` 553, `romfs_provider` 1,563,
  `registry` 1,624, generated mount table 55, arena 13 granules = 6,656.
- Kept/reused: `vfs_path`, `vfs_process` (CWD + handle pool), `romfs`,
  `ipc`, `vfs_workspace`, `zos_fs_copy_path` + the block/window helpers.

## Design decisions (taken here; the contract leaves the mechanics open)

1. **Syscall family.** 06h bind, 07h call, 08h unbind, 09h ns_enum
   (42a's numbers, now production); **0Ah SYS_CHDIR, 0Bh SYS_GETCWD** new
   (architecture 36.14 "namespace"); `FS_*` 10h-1Fh retired, numbers stay
   reserved.  `SYS_IPC_LOOKUP` (06h) disappears with `ipc_lookup`.
2. **FILE protocol** (`abi/zos/protocol.h`): READ 0, WRITE 1, SEEK 2,
   META 3, **SYNC 4**.  Every FILE op carries the provider instance in
   `payload[0]` (the driver is bank-6 code and its dispatch receives only
   the frame; the endpoint statics are nucleus-only).  READ/WRITE keep
   `arg0` = offset inside the caller buffer, `arg1` = length; SEEK moves
   its 32-bit offset to `payload[1..4]` and replies the position there;
   META replies a packed `struct zfs_stat` in `payload[0..15]`.
3. **FS-namespace protocol** (type `ZOS_TYPE_FS`, ops `ZFS_OP_*`):
   OPEN 0 (bind), CLOSE 1 (unbind), STAT 2, MKDIR 3, RMDIR 4, UNLINK 5,
   RENAME 6, ENUM 7.
   - **Path transport (driver-side):** the path is staged by the nucleus
     FS provider in the fixed-core VFS workspace slot and named by
     `payload[0..1]` (a nucleus request buffer; the driver's window always
     maps the fixed core, exactly like the frame passed by reference).
     RENAME names two such addresses.  `ZFS_OP_ENUM` adds `payload[2..3]`
     cookie, `payload[4..5]` out size and the caller's out buffer as the
     call descriptor.
   - **Application transport:** `fs.h` binds the provider root
     (`bind("/FS", 0)` / `bind("/SYSTEM", 0)`) - type `ZOS_TYPE_FS` - and
     sends the operation with the **path remainder in the call's one
     descriptor**; the in-process provider endpoint copies it in, stages
     it in the fixed-core workspace and forwards to the driver.  So the
     driver sees one path convention only.
4. **/FS handles are dispatched through the FS provider endpoint**
   (in-process, the ROMFS provider's sibling): the provider looks up the
   caller's handle, stamps the driver instance (`object`) into the frame
   and calls the driver endpoint (nested, near-direct, frame by
   reference).  This is what lets the bank-6 dispatch find its instance
   without an ABI register change.  `bind("/FS/...")` performs the
   driver's `ZFS_OP_OPEN` and records `{endpoint = provider, object =
   instance}`; `/SYSTEM` keeps its in-process ROMFS FILE instance.
5. **`/FS` routing source.**  The FS provider learns the filesystem
   driver's endpoint from a **host-built publication** (`publishes:
   [{"path": "/FS", "type": "FS", ...}]`) that the packer emits and the
   loader installs into the provider (`vfs_ns_install_publication`
   special-cases the `/FS` root).  No `/FS` publication (a build with no
   filesystem driver) -> `/FS` binds `-ZOS_ENODEV`, exactly as 42a.
6. **Card absent:** the driver's init runs CAPS + the root probe and keeps
   `mounted` state; a missing card makes each operation answer
   `-ZOS_ENODEV` (FS2 NO_MEDIA) instead of failing the driver's boot, so
   `/SYSTEM` and the console stay usable.
7. **exec.** `process_prepare()` binds the path (nucleus bind), requires
   FILE, reads metadata (size) and streams the image through FILE calls
   with nucleus-side descriptors naming the **common staging buffer**
   (path A in every mapping, so no bank-7 caller bank is ever
   mis-mapped); a staged (descriptor-less) FILE read form lets the cold
   loader drain the driver's SERVICE_IO staging through `zos_bank_copy`.
   Startup block v1 unchanged; unbind before launch.
8. **chdir/getcwd.** chdir normalizes, asks the owning provider to
   validate the path as a directory (`/FS` -> driver `ZFS_OP_STAT`,
   `/SYSTEM` + `/dev` containers in-process) and stores the canonical
   global path; getcwd returns it (existing CWD pool).
9. **Deletions (requirement 11):** arena + `arena.asm`, `module_loader`,
   `module_relocate`, `ioc_shim`, `kernel/syscall/fs.c` (keeping
   `zos_fs_copy_path` + the block/window helpers, moved into the object
   front end), `kernel/vfs/{file,dir,mount,mutate}.c` + `mount_config.h`
   + the generated mount table + `fs/romfs/romfs_provider.c`, the
   `registry`, the M9 descriptor kinds and `vfs_file_source`.
10. **Manifests:** production services + the IOC-FAT driver move to
    service ABI 4 with `publishes` rows (`/dev/console`,
    `/dev/serial/0`, `/FS`).

## Implementation order

1. ABI headers; 2. kernel namespace/router/IPC; 3. IOC-FAT driver;
4. deletions + Makefile; 5. SDK; 6. tests/programs; 7. docs + ledgers;
8. validation + report.

## Status

- [x] Reconnaissance, baseline recorded, design decided.
- [x] ABI headers (`fs.h`, `syscall.h`, `object.h`, `protocol.h`).
- [x] Kernel: IPC endpoints/call forms, namespace router + providers,
      object syscalls (bind/call/unbind/ns_enum/chdir/getcwd), exec loader.
- [x] IOC-FAT rewritten as a bank-6 driver (calls into IOC, card absent ->
      `-ZOS_ENODEV`).
- [x] SDK: `fs.h`/`fs.c`, `ipc.h`/`ipc.c`, `nsgate.asm`, `runtime.asm`,
      `console_service.c`, `zex.mk` (low data 93 bytes, code base 0x015D).
- [x] Deletions, Makefile, linker, residency and manifests (production
      links and passes `mapcheck --production`).
- [~] Tests and programs: host suites reconciled (see the two surgery
      sections); every acceptance program ported except the IOC-FAT one;
      `make m9-selftest` now **builds, packs and passes mapcheck** and
      its sim suite is being reconciled; `make ipc-selftest` builds and
      boots; `m9-exec-selftest` and `m9-iocfat-selftest` still need their
      run.
- [ ] Docs, ledgers, validation, report.

## Checkpoint: production builds (step 3 of 7 done)

`make` produces `build/zephyros.bin` and passes `mapcheck --production`.
Ledgers as reported by the build (after the endpoint-capacity change the
fixed-core numbers are a few bytes larger; the boot replays re-report
them):

```
fixed core 2000h-5FFFh end 42A1h (7620 required + 2823 overflow + 768
  stacks, 5173 room) | cold half 6000h-DFFFh end A7B5h |
  arena A800h-DBFFh (26 granules) | data 5600h/DC00h
boot set uses 0 of 26 granules, 26 free
```

Production services pack as ABI 4 with their publications (`/dev/console`,
`/dev/input/keyboard`, `/dev/video`, `/dev/serial/0`, `/dev/ioc`, `/FS`).
The IOC-FAT hot image is 0x1DEF bytes of code and 0x4AF bytes of
`_SERVICE_IO`; its tier placement comes from `services.plan.json`.

Obstacles hit and cleared (worth remembering): SDCC emits byte-fragmented
address stores (`add a,#<sym` / `adc a,#>sym`) when a *static* array or
struct member is indexed with a computed index; the packer rejects them
(relocation mode 09h), so the driver copies bytes through the
`iocfat_copy` helper and indexes the open table through a pointer local.
The arena `_ARENA_DECL` symbols and the geometry are kept with an empty
boot set (zero bytes, deviation reported to 42c).

## Test surgery (in progress)

Decisions taken (they follow the contract's image list):

- deleted: `test_m9_vfs*.py`, `test_m9_provider_sim.py`, `test_m9_fs.py`,
  `test_block.py`, `tests/target/m9/{m9_vfs,m9_provider,m9_fs}_test.c`,
  `tests/target/loader/loader_test.c` + `loader_selftest.h` (M4 arena
  fixture), the `tests/m9/mounts-*.json` policy files and
  `manifest-{vfs,provider,fs}.json`;
- kept and adapted: `m9-selftest`, `m9-exec-selftest`,
  `m9-iocfat-selftest` (their stores now list the service set + iocfat),
  `test_ns_selftest*.py`, `test_ipc_selftest*.py`, `test_m9_exec*.py`,
  `test_m9_iocfat*.py`, `test_m9_selftest*.py`, `test_sdk.py`,
  `test_source_layout.py`, `test_zex.py`, `test_monitor.py`,
  `test_validation_cli.py`, `test_console_acceptance.py`,
  `test_driver_abi.py`, `test_pack_image.py`;
- `tools/serial_smoke.py`: the `m9-fs` mode is gone with its image;
- `tools/mapcheck.py`: the M3 registry and M4 loader required-symbol
  lists became prefix tripwires, and `VFS_BANK7_ROUTINES` now names the
  M10 family (`_vfs_ns_*`, `_zos_object_*`, the reused M9 helpers);
- production services publish through ABI 4; the packer accepts the `/FS`
  provider root and the loader installs it.

## Test surgery round 2: the acceptance programs (in progress)

**Discovery (this round).**  Deleting the M9 VFS did not only retire the
M9 *test suites*: the kept acceptance **programs** were still written
against the M9 mount table / VFS façade, so `make m9-selftest`,
`make m9-iocfat-selftest` and `make m9-exec-selftest` all failed to
compile (`vfs_mount_table`, `vfs_mkdir`, `vfs_open`, `vfs_opendir`,
`zos_opendir`/`zos_readdir`/`zos_closedir`, `zos_fs_call`, `ft_block`,
the `ramfs` sections, `config/mounts.json`).  The M10 replacement for
directory iteration is `SYS_NS_ENUM`; the M10 replacement for the mount
table is the `/FS` provider root.

**Done this round**

- `kernel/ipc/ipc.c`: `IPC_ENDPOINT_MAX` 8 -> 12, with the reason in the
  comment.  The IPC acceptance image declares **8 host endpoints** plus
  the in-process ROMFS FILE provider = 9, so the eighth service booted
  into `service loader: ipc-irqx.zmod: endpoint refused` -> `services:
  unavailable 0x06` -> PANIC (the resident set then collided with the
  numbers already installed).  Production needs 7 (six services + the
  provider), so the table now has headroom over the largest declared set.
- `tests/target/include/nsdir.h` (new, test-only): `opendir`/`readdir`/
  `closedir` over `zos_ns_enum`, filling the M9 `struct zfs_dirent`
  (size/attributes from one `ZFS_OP_STAT`, so the callers' assertions
  keep their meaning; `opendir` stats first, which preserves the
  `ENOTDIR`/`ENOENT` contract).
- `fstest.c` ported: card paths gain `/FS`, the card is the only
  writable filesystem (`/STATS` probe and the `iocfat` flag are gone;
  the `ramfs`/`errors`/`pool`/`stale`/`writefail`/`exdev`/`exec`
  sections are deleted with the provider they tested - their outcomes
  live in the IOC-FAT acceptance and `m9-exec-selftest`), the `window`
  case now exercises the bind/call window (`zos_open` with a pointer
  outside the window, an empty path), directory loops use `nsdir_*`,
  the `namespace` case crosses `/SYSTEM` <-> `/FS`, and it removes the
  runner's write probe `/FS/M9PROBE.TMP`.
- `fsfat.c` ported: paths -> `/FS/...`, `nsdir_*` iteration, the root
  case now expects the M10 root entries (`FS`, `SYSTEM`, `dev`), the
  RAM-provider `fsf_is_ram()` short-circuits are gone (the `large`
  65537-byte case always runs), and the fault fences (`fault:stale:*`,
  `fault:write:*`) are unchanged - the simulator arms them.
- `fstest_l.c`, `fsdeep.c`, `fsraw.c`: paths/wording; `fsdeep`/`fsraw`
  needed nothing else.
- Kernel side `m9_selftest.c` + `m9_selftest_runner.c`: the mount-table
  probe became `m9s_card_state()` - one `vfs_ns_bind()` of
  `/FS/M9PROBE.TMP` with `ZFS_O_WRITE|ZFS_O_CREATE` answers 1 writable /
  0 `-ZOS_ENODEV` absent / 2 `-ZOS_EROFS` write-protected.  The runner
  keeps its three transcripts (`m9 selftest: OK`, `OK (card absent)`,
  `OK (read-only card)`) and no longer needs a path operation of its
  own; the `vfs_rmdir` cleanup is gone with the path façade.
- `Makefile`: `INCLUDES=tests/target/include` for `fstest`/`fsfat`
  (they include `nsdir.h`), the vestigial `BOOT_ZMODS` variable and its
  three uses deleted (the arena boot set is empty by design).
- `kernel/main.c`: `kernel_module_unavailable()` (dead since the arena
  loader retired) and its `ZOS_IOCFAT_BOOT` guard deleted.

**Host suites reconciled this round** (were failing at the last
checkpoint): `test_iocfat.py` (service manifest shape: type service,
`hot` segment, class-7 endpoint, `/FS` publication, class-5 dependency;
the packed-container check now reads the hot-tier room from
`build/modules/services.plan.json` and asserts >= 4096 free; Makefile
wiring pins the pattern rules), `test_ioc.py` (the module-loader gating
assertions became "the kernel boots it from the service manifest"),
`test_m9_exec.py` (SDK exec wrapper uses `zos_ipc_raw`, the depth owner
is `abi/zos/process.h`, `exec_close(file, vfs_owner_current())` ordering,
`manifest-exec.json` lists the M10 store), `test_pack_image.py` (the
arena carries no module; the hot numbers come from the service plan).
`test_iocfat.py` (27 tests), `test_ioc.py` (30), `test_m9_exec.py` (49),
`test_pack_image.py` (34), `test_ns_selftest.py` (20) pass.

**Verified this round**

- `make m9-selftest` compiles, links, packs and passes `mapcheck`
  (`20 areas, 340 symbols`).  Its ledgers, which are the ones the report
  will cite for this image:
  `fixed core 2000h-5FFFh end 44DAh (7668 required + 3393 overflow + 768
  stacks, 4555 room) | cold half 6000h-DFFFh end AA51h | arena
  AC00h-DBFFh (24 granules, 0 boot, 24 free) | data 643 bytes at DC00h`;
  `driver hot: 0 bytes of 32768` (the zero is `pack_image`'s own ledger
  - it does not read the service set; the authoritative hot numbers come
  from `build/modules/services.plan.json`);
  `romfs 37734 bytes in recovery pages 2-2`;
  `zephyros-m9-selftest.bin sha256 aa88db98fd82002132aff31fce3340c47834ff80793b931f8ab9a951bea09047`.
- `tests/test_m9_selftest_sim.py`: the first replay failed exactly where
  predicted - `test_absent_card_reports_the_degraded_path` still wanted
  the M9 mount diagnostic `vfs: / unavailable 0x..`.  That assertion is
  replaced (the comment records why there is no mount pass any more); the
  `large` case's "RAM provider" comment is reworded.  The suite is
  re-running.
- `tests/test_*_sim.py` replays are slow (each boot is up to
  `STEP_LIMIT = 60,000,000` steps), so the full
  `python3 -m unittest discover -s tests -p 'test_*.py'` run (2400 s cap)
  was **killed by the cap with no `FAIL:`/`ERROR:` line printed** - the
  non-replay suites are green as far as the run reached.  A verbose run
  is in flight to get the per-suite list; the replay suites are then run
  one by one.

**Still to do in this area**

1. `m9_iocfat_test.c` (kernel-side, ~740 lines) is the one program left
   on the M9 API: it must move onto the SDK (`fs.h` + `/FS`) or be split
   into a ZEX program, with the image booting it (`/SYSTEM/iocfat.zex`)
   or a kernel launcher driving it.  Its fences (`names:begin/end`,
   `cache:N`, `cache:stale:*`, the EROFS/absent notes) are what
   `test_iocfat_sim.py` counts, so the port has to keep them.
   `test_iocfat_sim.py` skips until the image exists.
2. `make m9-exec-selftest`: its programs are ported
   (`fschild`/`fsdeep`/`fsraw`/`fstest`), so the run reconciles
   `test_m9_exec_sim.py` - check for M9 wording in its transcript pins
   (`/R2`, the mount notes) before re-running.
3. `test_ipc_selftest_sim.py`: rerun after the endpoint-capacity fix;
   its earlier 22 failures were a stale image plus the `lookup-*` ->
   `bind-*` transcript rename.  The `ipc-selftest` image itself now
   builds and boots (the `TestIpcAcceptance` boot replays passed); the
   last replay was interrupted by the agent's own timeout, so the suite
   needs one clean run.
4. `make ns-selftest` + `test_ns_selftest_sim.py`, and
   `make console-integration-selftest`, if their images are stale.

## Checkpoint: the kernel boots and the monitor runs

After the ABI/transport fixes the production image boots end to end in the
simulator: banner → service loader (SIO, IOC, console, IOC-FAT) → console
service OK → `/SYSTEM/monitor.zex` launched through the new loader →
prompt → interactive session.  Bugs found and fixed on the way, worth
recording:

1. **The kernel launcher owns no pid.**  `process_running_pid` is
   `PROCESS_NO_PROCESS` (0xFF) during the boot launcher and `VFS_FD_NONE`
   is also 0xFF, so every nucleus-side bind looked like a free slot.
   Added `VFS_OWNER_KERNEL` (0xFE) and `vfs_owner_current()`; the router,
   the `/SYSTEM` provider and the loader resolve against it.
2. **The standard handles were never bound.**  `vfs_process_start()` must
   call `vfs_ns_standard_handles(pid)` (the child's console handles), which
   my rewrite of `kernel/vfs/process.c` had dropped.
3. **`ns_file_seek` used the wrong payload word.**  The FILE protocol puts
   the 32-bit offset at `payload[1..4]` (as `iocfat` implements); the ROMFS
   provider read and wrote `payload[0..3]`, so every image read after the
   first seek landed past EOF.
4. **`exec_file_size` read an uninitialised frame** - `exec_file_call` now
   takes an optional reply frame.
5. `service_loader.c`'s `ZOS_NS_HANDLES` guards had to go (they silently
   compiled the ABI-4 publication install out).

## Driver first-contact (the `m9-iocfat-selftest` replay)

The program port is done: `tests/target/m9/iocfat/iocfat.c` is an SDK
program (the old kernel-side `m9_iocfat_test.c` is deleted, the image
boots `/SYSTEM/iocfat.zex`, the store carries `iocfat.zex`, the kernel
hook and `ZOS_M9_IOCFAT_SELFTEST` CFLAGS are gone and the failure codes
are shared through `tests/target/include/m9_iocfat_selftest.h`).  Its
first replay found two real bugs and one open one:

1. **Fixed: the driver-relative path lost its leading slash.**
   `ns_fs_namespace_op`, the CHDIR stat and the RENAME pair staged
   `norm + 3` ("ZOSTEST") while the driver's `iocfat_walk()` requires a
   leading slash (it got `norm + 2` for FILE binds).  New helper
   `ns_fs_rel()` (root -> "/", otherwise `norm + 2`), used by all four
   sites; `ns_enum_fs` maps the empty remainder to "/" too.
2. **Fixed: a path is caller data, not an argument block.**  The bind
   body validated the path with `zos_syscall_block_ok` (0100h-1FFFh),
   but the SDK's provider root is a 128-byte *stack* buffer and a >4 KiB
   program's string literals also live above 1FFFh.  `zos_object_copy_path`
   now uses `zos_syscall_buffer_ok` (0100h-DFFFh); `abi/zos/object.h`,
   `abi/zos/ipc.h` and `docs/abi.md` say so.
3. **Open: `zos_mkdir("/FS/ZOSTEST")` -> `-ZOS_ENOENT` (0xFFFB).**  The
   probe prints proove the bind/unbind are fine (`bind /FS -> 0x0003
   type 0x08`, `unbind -> 0x0000`) and no kernel diagnostic fires -
   neither `vfs_ns_fs_call` nor the call body's error paths are reached,
   so the `-ENOENT` never crosses the syscall gate: it is produced
   before `SYS_CALL` is issued (the SDK has no `-ENOENT` of its own, so
   the first suspect is `zfs_path_op`/`zfs_provider_root`'s handling of
   `M9I_ROOT` - the *last* instrumented run's build failed, so the raw
   `zos_ipc_call` probe has not been read yet).  Next step: read that
   probe (rebuild `make m9-iocfat-selftest`, then the raw-mkdir line) -
   it separates "the SDK's path/root logic is wrong" from "the call
   reaches the kernel but the driver answers ENOENT".
   Also remember: the *program* still carries three temporary probe
   prints (`bind /FS ->`, `unbind ->`, `raw mkdir ->`) that must be
   removed once the failure is understood, and only then can the
   `test_iocfat_sim.py` transcripts be re-pinned (its M9 expectations
   `vfs: / unavailable 0x..`, `card absent: / not mounted` and
   `m9_iocfat_selftest_result` need the M10 wording).

## Next steps (in order)

1. Finish the `m9-iocfat-selftest` debugging (above), then re-pin
   `test_iocfat_sim.py`; `make m9-selftest` and `make m9-exec-selftest`
   then need their replays read.
2. (done) The `m9_iocfat_test.c` port.
3. Re-run `make ipc-selftest`, then `make ns-selftest` and
   `make console-integration-selftest` if stale.
4. `make clean && make check` and fix fallout.
5. Docs (`vfs.md` §13, `filesystem.md`, `abi.md`, `sdk.md`,
   `devices.md`, `module-format.md`, `memory.md`) + the coverage map for
   the retirement of the M9 file-operation suites.
6. `docs/validation/2026-10-09-m10-files-on-handles.md` (five ledgers,
   gate/driver numbers, hardware PENDING) and the final `make clean`.

## Open items / risks

- `rom_access_staging` (128 bytes, common) is the exec read buffer.
- The driver's SERVICE_IO staging must hold the 512-byte cache and the
  transfer staging (41b's buffer plan: no recorded saving found; the
  cache and staging stay separate unless the map says otherwise).
- `kernel/module/arena.asm` + `GEOMETRY_*` are kept deliberately (the
  granule allocator is still part of the derived-arena plan); only the
  loader/relocator/registry/IOC shim are deleted.  Reported to 42c.
- `include/zephyros/{driver.h,vfs.h}` are still present (pruning
  candidate for 42c, not required by this package).
- Deviation from the M9 acceptance programs: the sections that drove
  providers this package retires (`ramfs`, the RAM `STATS` control file,
  the cross-*mount* rename/exec cases) are deleted rather than ported;
  their *outcomes* are covered by the ported IOC-FAT and SYS_EXEC
  acceptances.  This is recorded in the report's coverage map.

## Round 3 - the `/FS` read bug, and the pivot to correction-01

### The real product bug (fixed)

A program that reads across a 512-byte block boundary got wrong data:
`m9i_read` of 64 bytes at position 500 delivered `ref[0..63]` (the cached
block's start) instead of `ref[500..563]`.

Root cause, proved by tracing every descriptor copy in the sim:

- `iocfat_file_read()` copies cache slices into the driver's 512-byte
  `iocfat_batch` staging in a loop over block boundaries, but every
  iteration wrote to `iocfat_batch[0]`.  The first chunk (112 bytes at
  `within=400/500`) was overwritten by the second chunk (`within=0`), so
  the staging buffer held block-aligned data and the copy-out delivered
  it with the requested length.
- Fix: `iocfat_copy_range(src, offset, dst, at, n)` takes the destination
  offset and the loop passes `confirmed`.  The extra parameter is needed
  because the module packer rejects `&iocfat_batch[<runtime index>]`
  ("relocation mode 09h"); bases must arrive as call arguments.
- Verified: the writable-card replay now prints `dbg r500 ... d 0x00`
  (zero mismatches) and the whole cache section (cache:0..cache:13,
  including the STALE windows and the cross-file invalidations) passes.

Production consequence: any read crossing a block boundary - e.g. a
read of a file's tail, or any read past the first block - returned bytes
from the start of the block.  The new `fs-selftest` will pin this.

### Harness lessons (M9 machinery, all deleted by correction-01)

- Two later "failures" were my own instrumentation, not OS bugs:
  a debug block opened one file twice into one handle variable (leaked a
  driver handle -> `-EMFILE`), and `m9i_read_at()` treated `zos_seek()`'s
  return (the new *position*) as a status, so every read at a non-zero
  offset silently did nothing.
- The child `fstest` program's `namespace`/`romfs`/`window` sections
  report FAIL because they encode M9-era expectations (`stat("/")` is a
  directory, ROMFS files carry `ZFS_ATTR_READONLY`, the store's `.zex`
  images start with the literal `ZEX1`).  Not ported: correction-01
  deletes the M9 acceptance surface and replaces it with `fs-selftest`.
- Reminder that cost several cycles: `make m9-iocfat-selftest` can fail
  *inside* the program compile while the sim still replays the previous
  image.  Always grep the build log for errors and check that
  `iocfat.zmod`/the `.bin` are newer than the sources before trusting a
  replay.

### Pivot (approved): apply correction-01

`work/42b-m10-files-on-handles/correction-01/WORK.md` supersedes 42b's
"keep and adapt" test decisions: delete every M9 acceptance image and
program, replace them with one small M10 outcome image `fs-selftest`, and
validate with `make clean && make check`, the four sim selftests and
`git diff --check`.  Order followed from here:

1. (this section) driver fix landed and validated in the M9 harness.
2. Delete the M9 acceptance machinery (images, programs, host suites).
3. Write `fs-selftest`: one image, ~30 outcome checks (boot to monitor;
   `/FS` create/write/read/seek/enumerate/mkdir/unlink/rename through
   `fs.h`; `/SYSTEM` read; absent card -> clean `/FS` bind failure;
   nested exec with tail and child status; leaked handles released at
   exit), plus its host/sim test and Makefile target.
4. Run the correction's validation set; re-run the production boot replay
   (the driver read fix touches every read).
5. Write the 42b and c01 reports together.

## Round 4: the `fs-selftest` image against the new kernel (all green)

The new image builds and its three replay cases pass (`python3 -m unittest
discover -s tests -p 'test_fs_selftest_sim.py'`: writable card 35/35,
absent card 8/8, handle-release run).  Getting there found **four more
real production bugs**, all now fixed:

1. **ZEX v1 forbids initialised writable data.**  `static int card = 1;`
   in the program made the linker place `_INITIALIZED` at the code base
   and `zexpack` refused the container ("conflicting content for 015Fh").
   Fix is in the program: `card` starts zeroed, `main` sets it
   (`docs/zex-format.md` already stated the rule; the packer's message is
   indirect, which cost a debugging session - worth a clearer diagnostic
   in a later package).
2. **`/FS` root enumeration passed a driver-invisible pointer.**
   `ns_enum_fs` staged the kernel's literal `"/"` for the provider root;
   the driver window maps bank 7, not the image, so the driver read
   `FF FF` and answered `-ZOS_EINVAL` (no wire traffic at all, which is
   why the first probes looked empty).  Fixed in `kernel/vfs/ns.c`:
   `ns_fs_root_path()` stages the root spelling in the path view's spare
   slot and `ns_fs_rel`/`ns_enum_fs` use it.  The same latent bug also
   covered `zos_stat("/FS")` and friends.
3. **The common gate stack was too small (256 bytes).**  The nested-exec
   chain (SYS_EXEC -> ROMFS read -> provider and driver transaction)
   measured **287 bytes** in the simulator, overrunning the reservation
   into `zos_gate_saved_sp/latch` (they sit directly below the stack
   base): the parent then resumed in a corrupt mapping and the next
   syscall took the mode-fault panic path.  Fixed the way the M8 console
   fix did it: `ZOS_GATE_STACK_SIZE` 256 -> 384 in
   `platform/zephyr80/memory.{h,inc}` (common data 719 -> 847 bytes, still
   under the 2560 limit).  This also finally explains a class of "worked
   before" failures: the reservation is only validated by accounting, so
   any deeper chain silently corrupts the transition state.
4. **Process exit never released the standard handles.**  `vfs_ns_unbind`
   refuses handles below `ZOS_HANDLE_FIRST_BOUND` (a live program must not
   drop its console), and `vfs_process_exit` went through it - so every
   process left its two console handles in the 12-slot table.  In a
   launcher that relaunches the boot program this exhausts the table.
   Fixed by factoring `vfs_ns_release_desc()` out of `vfs_ns_unbind` and
   having the teardown use it for every descriptor the pid owns.

Harness-side mistakes corrected along the way (all mine, not OS bugs):
the subdir enumeration check ran before the `mkdir`; `SELFTEST.D` was
checked with `container = 0` although directories are containers; the
replay's leak check sampled the driver slots *after* the parent's own
probe open; the child's "card absent" line was tied to the leak count
(the `/FS` namespace bind needs no card, so 2 handles leak without one).

## Round 5: whole-suite reconciliation (`make check: OK`)

`make clean && make check` is **green** (rc=0, "make check: OK").  The
suite had been frozen against the M9 tree, so this round is the
correction-01 fallout - none of it is new OS behaviour:

* **Makefile: the M9 targets removed by my surgery were not the only
  ones.** `make check` wanted the four `zex_program` rules (`ipc`,
  `ipccopy`, `ns`, `nschild`) and the `ipc-selftest` / `ns-selftest`
  targets back; correction-01 only retires the *M9 acceptance* machinery,
  not the namespace and IPC selftests those rules feed.  Re-added (and
  spliced into the targets region, not the config region - the first
  attempt landed in the wrong place and produced an immediately visible
  build break).
* **`tests/test_source_layout.py`** still demanded `tests/test_syscall_sim.py`
  and the deleted `ramfs` module; its `ZEX_FILES` list now names the two
  new programs (`tests/fs/fs_selftest.c`, `tests/fs/fs_child.c`).
* **`tests/test_sdk.py`** pins the SDK low-data size and entry offset;
  the new program links an extra module (`nsgate`), so `HELLO_LIBRARY_MODULES`
  gained it and the entry offset moved 0x44 -> 0x5D (93-byte low data).
  `docs/sdk.md` carried the same two figures and the layout block.
* **`tools/mapcheck.py`** and **`tests/maptools.py`** both hard-coded the
  old 256-byte gate stack in their defaults/fixtures; both now mirror
  `platform/zephyr80/memory.inc` at 384.  (As Round 4 note 3 says,
  mapcheck validates the *accounted* reservation - the depth still has to
  be measured in the simulator.)
* **Docs repointed at the new acceptance**: `docs/vfs.md` (five spots,
  including deleting the ramfs-provider section body), `docs/abi.md`,
  `docs/architecture.md`, `docs/romfs-format.md`.  `kernel/process/launch.asm`
  comments now cite `include/zephyros/process.h` rather than the deleted
  M9 harness.
* `tests/modules/ramfs.{c,json}` deleted with the rest of the M9
  machinery (70 tracked files total for correction-01).

### Where this leaves the package

| Work package item | State |
| --- | --- |
| M9 acceptance machinery deleted | done (70 files) |
| `fs-selftest` image, 35/8 checks | done, replays green |
| Four production bugs from Round 4 | fixed |
| `iocfat_file_read` cross-block bug | fixed |
| `make clean && make check` | **OK** |
| Four image targets (Round 6/7) | **OK** |
| Production boot replay + image hash | **d5e816f2...**, reproducible |
| 42b report + c01 report | written |

The production boot replay is part of `make check`'s host suite
(`test_console_acceptance.TestProductionImage`: boot lanes, the service
store, the monitor session and the IOC lane against `build/zephyros.bin`),
and all of it passes on the final bytes.

## Round 6: the four acceptance images

`make clean && make check` is green, but three of the four image targets
still failed on expectations frozen before the 42b pivot.  One of them
was a real product-visible wiring gap, the rest were stale test
expectations.  Working through them in order:

### `fs-selftest` - green

3/3 replay cases (writable card 35/35, absent card 8/8, release run).

### `ns-selftest` - the seek payload moved (test-side, 42b ABI)

The probe read its `SEEK` reply from `payload[0..3]`; 42b moved the whole
seek word to `payload[1..4]` (`abi/zos/protocol.h`, the SDK's `zos_seek`,
`kernel/vfs/ns_file.c`, `fs/iocfat/iocfat.c` all agree on `[1..4]`), so a
72-byte file reported `0x4800` = 18432: the size byte landed one place
too high.  Fixed the 42a probe (`tests/ns/ns.c`) to the current contract -
flagged in the report as an ABI move that the old expectation never
caught.

### `ipc-selftest` - one real defect and three stale premises

The image's client reported 46/54: `bind-fat`, `bind-ioc`, `bind-irqx`,
`fsread-status` and the whole `irq-*` group failed.  Replaying it with an
instrumented tracer (a throwaway probe, `/tmp/42b/ipc_table.py`) and
dumping the kernel's own descriptor table at every bind gave the answer:

* **The handle pool really filled up.** `vfs_descriptors` is one global
  12-entry table and a suspended parent keeps its handles, so the boot
  program's five bound providers plus the child client's six, on top of
  the two standard handles each process owns, is fifteen.  The client's
  4th, 5th and 6th binds answered `-ZOS_EMFILE`, `fsread` (a `/SYSTEM`
  file bind) answered `-ZOS_EMFILE` on every iteration, and every
  `irq-*` check ran with handle 0.  This is the documented design
  ("one small global handle table ... the pool is never per-process",
  `kernel/vfs/vfs.h`), so the *program* is what has to live inside it:
  `ipccopy.c` now unbinds its five probes before `zos_exec` (a launcher
  handing the pool to its child).  After that the image reports
  54/54 checks and `ipccopy: PASS`.
* **`bind-ioc` checked the wrong type.**  The client bound all six
  handles and then checked `type == ZOS_TYPE_IOC`, but `type` had been
  overwritten by the `irqx` bind (SERIAL).  Each bind now checks its own
  type where it is bound.
* **The lookup census test had lost its subject.**  42b retired
  `ZOS_SYSCALL_IPC_LOOKUP` and its SDK cache (`abi/zos/object.h`), so
  `test_lookup_census_and_cache` was asserting the behaviour of deleted
  machinery.  Replaced with `test_bind_census_and_refusals`: the tracer
  now keeps the spelled path of every bind (a new `_read_path` in
  `IpcTracer.watch`), and the test reads the client's own six provider
  binds, the `/SYSTEM` file it reads, the deliberate miss and the
  grouping-container refusal, all marshalled through the one window
  block, plus the out-of-window block the gate refuses.
* **The filesystem baseline stopped being "direct".**  `DIRECT_PHASES`
  encoded the M9 premise that a file read issues no IPC call; in the 42b
  model the same read is a FILE protocol call on a bound handle, so
  the phase now carries 72 calls instead of "at most 8".  `DIRECT_PHASES`
  is gone, `IPC_PHASES` includes the `f` phase, and the stale "M9
  filesystem baseline" / "today's direct filesystem path" wording is
  replaced in both the replay and the client.
* **The tracer ended a call's span too early.**  With the IRQ path live
  again, the replay's latch tests failed on nested calls: the fixed-core
  SDK puts several call sites at one address (210Ch), so `pc == ret`
  alone is ambiguous and ended a span when the *next* call was entered
  from the same address - the span then looked like it outlived its own
  service domain, and its last latch write was the domain's open write
  rather than the caller's restore.  The span now ends at the real
  return: `pc == ret` *and* the caller's SP *and* the caller's latch,
  which is exactly what the gate's return path restores
  (`kernel/syscall/entry.asm`).  This keeps the latch tests meaningful
  (the restore is still observed in the write log, not assumed).

## Round 7: the final acceptance record

Run last, after every source edit, from a clean tree:

| command | result |
| --- | --- |
| `make clean && make check` | `check: reproducible rebuild (d5e816f2...)`, full host suite, `make check: OK`, rc=0 |
| `make -j1 fs-selftest ns-selftest ipc-selftest console-integration-selftest` | rc=0: fs 3/3, ns 23/23, ipc 53/53, console 6/6 |
| `make fs-selftest` (once more, after the replay's last edit) | 3/3 OK |
| the three remaining targets again, after `make clean` | rc=0: ns 23/23, ipc 53/53, console 6/6, all four artifacts in place |
| `git diff --check` | clean |

Production `build/zephyros.bin`:
`sha256 d5e816f2e47ace191077f916487e61c65df39e61a0709954aff7b32179e8abec`,
reproduced by the clean rebuild; production ledgers re-read after it:
fixed core ends 42C5h with 5,089 bytes room, cold half ends AAEEh, arena
24 granules free, common 2,358 of 2,560.  The serial run is deliberate:
one earlier failure came from a replay reading `build/zephyros.bin` while
another target rebuilt it.

Reports written:
`docs/validation/2026-10-09-m10-files-on-handles.md` and
`docs/validation/2026-10-09-m10-files-on-handles-c01.md`.
