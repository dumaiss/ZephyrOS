# Correction 01: retire the M9 acceptance machinery now

Runs after 42b completes, as its follow-up cleanup. Owner decision
(2026-10-09): **there is no reason to keep M9 tests and machinery live.** M10 replaces the subjects they test. The known-good M9
reference is git history (the M9 close, commit `0cfe6d7`), not live
images. This supersedes the "keep and adapt" part of `../WORK.md`'s test
decisions.

## Changes

1. **Delete every M9 acceptance image** and its programs, headers, fixtures
   and `test_*` modules:
   - `m9-selftest`, `m9-exec-selftest`, `m9-iocfat-selftest`;
   - the four images `../WORK.md` already deletes;
   - the M9 programs in `tests/target/m9/` (`fstest`, `fsfat`, `fsdeep`,
     `fschild` and the rest).

   This includes whatever 42b ported or adapted. Delete it rather than
   keeping it.
2. **Replace them with one small M10 outcome image** (`fs-selftest`), new
   code written for the new model, not ported. Outcomes only:
   - production-like boot to the monitor prompt;
   - `/FS` through `fs.h`: create, write, read back, seek, enumerate,
     `mkdir`, `unlink`, `rename`;
   - `/SYSTEM` read;
   - card absent: `/FS` bind fails cleanly and `/SYSTEM` still works;
   - nested exec from `/SYSTEM` with a tail, and the child's exit status;
   - leaked handles released at exit.

   Aim for about 30 checks in one client program. Don't recreate the M9
   fault-injection matrix.
3. **Host suite:** delete the host tests whose subject is an M9 mechanism
   (the mount model, the provider ABI, `FS_*`, the M9 descriptor kinds),
   without porting them.
4. **Validation** becomes:

   ```sh
   make clean && make check
   make fs-selftest ns-selftest ipc-selftest console-integration-selftest
   git diff --check
   ```

5. Record a short list of what was deleted (images, programs, test
   modules, line count). No per-test coverage map is needed for M9
   subjects.

Production behaviour is unchanged. Only test machinery is removed and
replaced. Record the production hash (it may change if test-only hooks
leave the build). The report is
`docs/validation/<date>-m10-files-on-handles-c01.md`.
