# Task

M10 step 7 (architecture 36.24): **files on typed handles.**

- The FS provider routes `/FS` to IOC-FAT, which becomes a bank-6
  filesystem driver.
- `fs.h` (`fs_open`/`fs_close`/read/write/...) is built on
  `bind`/`call`/`unbind`.
- Filesystem namespace operations go through the provider.
- `chdir`/`getcwd` follow 36.13, and exec binds a FILE.
- `FS_*` is retired.

IOC-FAT now lives under **`/FS`**, no longer at `/`.

**This is the production switch-over** (42a correction 01). The namespace
code from 42a enters production here, which is only possible because this
package also **deletes** what it replaces: see requirement 11. The rest of
the pruning stays in 42c.

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md`;
- architecture 36.8 and 36.12-36.14;
- `docs/vfs.md`, `docs/filesystem.md`, `docs/abi.md`, `docs/sdk.md`;
- `kernel/vfs/`, `kernel/syscall/fs.c`, `fs/iocfat/`;
- `user/sdk/src/fs.c`, `fsgate.asm`;
- the package-42a record.

**Before starting:** if 42a's record contradicts this contract, stop and
report.

**From 42a** (`docs/validation/2026-10-09-m10-namespace-handles.md`):
- The namespace family is built behind `ZOS_NS_HANDLES` (default 0; 56
  sites in 13 files) and listed as `test_link` in `config/residency.json`.
  This package makes it production: **delete the macro, every `#else`
  half and the `test_link` entries.**
- The objects to delete, with their bytes (19,353 freed):
  - `fs` (keep its argument helpers, moving them into the object front
    end);
  - `vfs_mount`, `vfs_file`, `vfs_dir`, `vfs_mutate` (its operations move
    behind `/FS`), `romfs_provider`, `registry`, `vfs_mounts`;
  - the arena.
- Kept and reused: `vfs_path`, the CWD and handle-pool parts of
  `vfs_process`, `romfs`, `ipc`, `vfs_workspace`.
- Production manifests move to driver ABI 4 (publications).
- Target ledgers: 42a's projection (fixed room about 4,782 bytes).
  Report the re-derived cold data base once the arena is gone.

## Requirements

1. **FILE protocol:** read, write, seek, sync and metadata, with data
   through descriptors (at most 2; 36.8).
2. **`mkdir`, `rmdir`, `unlink` and `rename` are filesystem operations
   in `fs.h`** (owner decision), specific to a real filesystem such as
   IOC-FAT, not nucleus or VFS operations.
   - `fs.h` binds the filesystem (`bind("/FS", 0)`, the
     filesystem-namespace type of 36.14) and sends the operation to the
     driver over IPC, with the path remainder.
   - The driver performs it.
   - There is no `DIRECTORY` handle and no special nucleus support.
3. **FS provider.** Static nucleus routing code. It forwards the
   remainder below `/FS` to the build's filesystem driver
   (host-configured: IOC-FAT), and holds no FAT/FS2 semantics.
4. **IOC-FAT as a driver.**
   - It implements FILE and the filesystem-namespace protocol.
   - Host-linked, with its cache in `SERVICE_IO` and its IOC dependency
     host-resolved (41b).
   - Apply 41b's buffer plan if it measured a saving.
   - The production build selects it, and the arena boot set becomes
     empty.
5. **Enumeration and CWD.**
   - `ns_enum` works below `/FS` through the driver.
   - `chdir(path)` asks the owning provider to validate the path and
     stores the canonical global path; `getcwd` returns it.
   - The card-absent case: `/FS` binds fail cleanly, and `/SYSTEM` still
     works.
6. **`fs.h`.**
   - `fs_open(path, flags)` is `bind` plus a FILE type check.
   - `fs_close` is `unbind`.
   - The other calls are FILE or filesystem-namespace calls.
7. **Exec.** `exec(path, tail)` binds the path, requires FILE, streams the
   image through FILE calls (an upcall shim for the bank-6 driver), and
   unbinds before launch. Startup block v1 is unchanged.
8. **Retire `FS_*`** (`0x10-0x1F`), `kernel/syscall/fs.c` and the M9
   descriptor kinds that served it.
9. **Paths.** Every program, configuration, test and document that named
   IOC-FAT files as `/...` moves to `/FS/...`. `/SYSTEM` paths and
   `ZOS_BOOT_PROGRAM` are unaffected unless they pointed at the card.
10. **Budget.** The driver hot tier keeps at least 4,096 bytes free;
    otherwise stop and report the remedies in bytes. Report the five
    ledgers before and after, set against 42a's projection.
11. **Production switch-over, and the deletions that make room** (they
    move here from 42c):
    - link 42a's namespace code into production, and remove
      `SYS_IPC_LOOKUP`;
    - delete the arena and arena module loading, since IOC-FAT is now a
      driver (`module_loader`, `ioc_shim`, and `module_relocate` if
      unused);
    - delete `fs.c` and the M9 VFS machinery the router replaces (the
      mount table, provider registration, mount/path resolution and the
      descriptor kinds that served `FS_*`), keeping only what 42a reported
      as reused;
    - delete the registry if production no longer needs it (42a found it
      dead in production), deleting its M4/M8 fixture tests with it.

    If production still does not fit after these, stop and report in
    bytes.

## Constraints

- **Images and tests, decided here so you do not have to investigate:**
  - **delete** (the subject is retired): `m9-vfs-selftest`,
    `m9-required-mount-selftest`, `m9-provider-selftest` and
    `m9-fs-selftest`, with their target programs, headers and `test_*`
    modules (`m9_vfs_test.c`, `m9_provider_test.c`, `test_m9_vfs*.py`,
    `test_m9_provider_sim.py`, `test_m9_fs.py`); also the `fsgate` checks
    in `test_sdk.py`, and the registry/arena fixtures (`target/loader/`,
    `loader_selftest.h`, `test_block.py`, and the arena/registry cases in
    `test_driver_abi.py`);
  - **keep and adapt to `fs.h` and `/FS`:** `m9-selftest` (boot, files,
    nested exec, the fault workload), `m9-iocfat-selftest` (the IOC-FAT
    driver) and `m9-exec-selftest`. Merge `m9-exec` into `m9-selftest` if
    it adds nothing.
  - Before deleting the M9 file-operation tests, give a one-line coverage
    map showing where each kept outcome (create, read, write, seek,
    readdir, mkdir, unlink, rename, card absent) is now checked. If one has
    no home, add it to `m9-selftest`.
  - Port nothing that tests internals. No other test refactoring.
- Deletions beyond requirement 11 stay in 42c.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-files-on-handles.md`.

## Validation

```sh
make clean && make check
make m9-selftest m9-exec-selftest m9-iocfat-selftest
make console-integration-selftest ipc-selftest
git diff --check
```

Hardware (owner):
- production with and without a FAT card;
- files under `/FS`;
- the monitor from `/SYSTEM`;
- nested exec.

## Acceptance criteria

- Files work through FILE handles on IOC-FAT (`/FS`) and ROMFS
  (`/SYSTEM`), with one call path.
- Namespace operations need no `DIRECTORY` handle.
- `FS_*` is gone.
- The behaviour holds on hardware.
- The ledgers are within 36.20.
