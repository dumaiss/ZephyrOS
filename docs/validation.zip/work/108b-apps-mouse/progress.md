# 108b progress
Tree classification: dirty files = accepted package 108 (libtui mouse, docs, tests); UserSoftware apps tracked + clean. No unclassified.
Baseline sizes (built against current SDK, before edits): konacmd.exe 38375 B (image 38339, bss 17561, stack base 56448 -> headroom 292); konaedit.exe 45997 B (image 45961, bss 9560, headroom 543).
Both will likely become placed programs once libtui mouse is linked; check test_project pins then.
DONE: rename sed (konacmd->kc, konaedit->kedit) in Makefiles, READMEs, PLAN, tests, main.c, kc_ui.c.
PLAN: KC = mouse_key() translating events to keys (wheel_left repeat), popup/viewer/help handle mouse; time via kc_link_time in kc_serial.c.
KE = next_key helper in dialogs; run_menu(menu, open); edit area case TUI_KEY_MOUSE in switch.
Tests: fake PC server (FileService over z.sio_tx/sio_rx in tick) for KC copy confirm.
NEXT: write KC code.

## Status (code written, builds)
- KC: kc_ui.c mouse (mouse_key, pane_step, focus_to, popup/viewer/help), kc_serial.c kc_link_time; builds, placed (kc.exe 53478 B). Makefile pin libtui tui_mouse=resident (hook indirect call invisible to placer: tui_shutdown (resident) called hook->disable in far1 -> real bug if not pinned; found-outside-scope SDK hazard).
- KE: ke_ui.c mouse (next_key, message_box/prompt/file_dialog, run_popup/run_menu(menu,open), mouse_edit/wheel_view/position_at); builds, placed (kedit.exe 59277 B). Makefile KE_PLACE pins: ke_history=far1, ke_file=far1, tui_key=far1, tui_mouse=resident (tried subsets: resident zone over by 0x2FE..0x3E3 bytes, placer estimate vs packing).
- Test harness KE: getkey_entry() uses __vn_tui_getkey (tui_getkey now in far1, other bank) -> test artifact (placed program).
- KC test_project test_executable_stays_below_stack: end == stack base (56448) placed layout (exeplace.py: resident data fills C000h up to stack) -> assertLessEqual (test artifact, cited tools/exeplace.py).
## Failures (KE existing tests after harness fix), classification pending baseline check in UserSoftware/KonaEditBase (temp copy of HEAD, DELETE after):
1. test_edit_menu_invert...: after F3 + typing PAGE00.TXT + Tab + Enter screen still 'Xalpha' not 'line00' (both classes inherit)
2. test_keys_meet_their_budgets: join tstates 1503152 > 1500000

## FINDING (blocks KE Must "all existing app tests pass", needs steer)
KE with mouse cannot link in one bank: unplaced total 61574 B vs capacity 55971 (baseline 55428; libkos mouse.rel 1039 + libtui tui_mouse 1039 alone exceed it by 1535 before any app code). So kedit is a placed program with a far segment. A far segment is an xmem object; kernel/syscall/xmem.c XMEM_MAX_OBJECTS = 16 system-wide. KE document = 8 objects; replace_document (File>Open with a document open) holds old 8 + fresh 8 = 16 -> 17 with the far segment -> ke_store_init(&fresh) fails -> "Open failed / The document was not replaced". Existing test test_edit_menu_invert_save_and_return_to_shell (F3 open PAGE00.TXT) fails: class implementation (pins accepted behaviour), evidence: xalloc trace in sim (7 ok, 8th fails), KonaEditBase (HEAD build) passes all 10.
Not fixing replace_document without steer (behaviour change). Options for report: (E) validate then load in place; (S) lazily allocated store objects; (T) trim >=5.6 KB (infeasible).
KC: not affected (no xmem use). KC placed: far1 1 object.
Also found: placer cannot see indirect calls via tui_mouse_hook; pinned tui_mouse resident in both apps (tui_shutdown in resident called hook->disable in far1).

## FINAL STATUS: STEER REQUIRED (KE File>Open with a document open)
Validation run once at the end (sources frozen): make sdk (up to date, same archive hash fcd3bf79...), KC make clean && make && make test: all pass (test_protocol OK; test_host 10; test_project 8; test_ui_sim 5 = 1 old + 4 new). KE make clean && make && make test: store test OK; unittest 18 run, 2 fail (same old test in two classes: Open while a document is open), 0 skip.
Sizes: kc.exe 38375 -> 53478; kedit.exe 45997 -> 59162 (placed; zone fill included).
docs/validation record not written: package is blocked on the steer.
Edited-expected-output: none. Pins changed: KC test_project assertLess->assertLessEqual (exeplace.py layout); name pins (Requirement 1).
