> Worker package. After 108 (accepted). KonaCommander and KonaEdit use
> the mouse through 108's libtui API, are rebuilt against the new SDK,
> and ship as `kc.exe` and `kedit.exe`. Only `UserSoftware/KonaCommander`
> and `UserSoftware/KonaEdit` change, plus `make sdk` output. No
> libtui, driver, nucleus or ABI change. Baseline: HEAD at dispatch.

# Task

Make the two TUI applications mouse-aware, keeping every keyboard
behaviour. Each calls `tui_mouse_enable` after `tui_init`; without a
mouse (serial console, no driver) it runs exactly as today.

## Current state

- libtui mouse API (108; exact names in
  `docs/validation/*-tui-mouse.md` and `user/sdk/include/tui.h`):
  `tui_mouse_enable(flags)` / `tui_mouse_disable`, `TUI_KEY_MOUSE` from
  `tui_getkey`/`tui_pollkey`, `tui_mouse_get(&ev)` (screen and window
  cells, buttons, pressed, released, wheel, kind), `tui_mouse_hit`.
  libtui's modal runners (`tui_confirm`, `tui_message_box`,
  `tui_menu_run`) take clicks by themselves.
- Both apps build against `../../build/kos-sdk-0.2.0.tar.gz`, which
  `make sdk` produces; their Makefiles re-extract when its hash changes
  (owner rule: after `make sdk` with header or rule changes, `make clean`
  in each app directory).
- **KonaCommander** (`src/kc_ui.c`, `LIBS=tui_widgets:tui`, target
  `konacmd`):
  - two panes;
  - its own menu bar and pop-up (`render_menu_bar`, `run_menu`,
    `menu_popup_rect`, `open_popup`, `render_popup_selection`);
  - a button row (`render_buttons`, `render_button_focus`, `focus_set`,
    `perform_action`);
  - pane navigation (`panel_next`, `panel_previous`, `activate_entry`,
    `render_navigation`), the viewer (`view_file`, `render_viewer`), and
    copy confirmation through `tui_confirm`;
  - the main loop is in `kc_ui_run`, reading keys through `read_key`.
- **KonaEdit** (`src/ke_ui.c`, `LIBS=tui`, target `konaedit`):
  - its own widgets (`src/ke_widgets.c`: `ke_menubar`, `ke_button`,
    `ke_input`);
  - menus (`run_menu`, `run_popup`, `draw_popup_row`);
  - dialogs (`message_box`, `confirm_box`, `prompt_text`,
    `file_dialog`), each with its own `tui_getkey` loop;
  - the selection (`mark_active`, `mark_anchor`, `selection`);
  - the view (`src/ke_view.h`: `ke_view_row_of`, `ke_view_scroll`,
    `ke_view_next_start`; `follow_column` for the sideways scroll).
- Tests: each app's `tests/test_ui_sim.py` and `tests/test_project.py`
  (exe names, store entry `konacmd.exe` / `konaedit.exe`, map paths).

Read: `work/00-WORKER.md`; `docs/tui.md` (Mouse section); both apps'
README, DESIGN/PLAN files and the functions above.

## Requirements

1. **Names** (Must): targets and files become `kc` (`build/user/kc.exe`)
   and `kedit` (`build/user/kedit.exe`). Update the Makefiles, tests,
   READMEs, usage text, and every `konacmd` / `konaedit` reference in the
   two app trees. The source file names may stay.
2. **KonaCommander** (Must):
   - **Pane entries:** a click focuses the pane and selects the entry.
     A double click (a second press on the same entry within 500 ms,
     timed with `kos/timer.h`) opens it, the same as Enter.
   - **Wheel:** scrolls the pane under the pointer, the same as
     Up/Down per notch.
   - **Menus:** a click on a menu-bar title opens that menu; a click
     on a pop-up item runs it; a click outside the pop-up closes it.
   - **Buttons:** a click on a button runs its action.
   - **Viewer:** the wheel pages up and down; a right click returns,
     the same as Escape.
   - **Copy confirmation:** answers to clicks through `tui_confirm`.
3. **KonaEdit** (Must):
   - **Editing area:**
     - a click places the cursor at the clicked cell (line from the
       view row; column through TAB expansion and the sideways scroll;
       past the line end is the line end) and clears any selection;
     - dragging with the left button selects (`mark_anchor` at the
       press, the cursor follows the drag) and shows `MARK`;
     - the wheel scrolls three lines per notch without moving the
       cursor off-screen.
   - **Menus:** a click on a menu-bar title opens its pop-up; a click
     on a pop-up item runs it; a click outside closes it.
   - **Dialogs** (message, confirm, prompt, file): a click on a button
     chooses it, and a click on an input field focuses it. In the file
     dialog, a click selects a directory entry and a double click opens
     it; the wheel scrolls the list.
   - Keyboard behaviour and undo grouping are unchanged.
4. **Pointer life** (Must): the pointer follows the mouse everywhere in
   both apps and is hidden at exit (`tui_shutdown`).
5. **Docs** (Must): each README gains a Mouse section and the new
   program names; `DESIGN.md` / `PLAN.md` gain a line where they
   describe input.

## Invariants

- Every existing key behaviour, screen and test expectation in both apps
  is unchanged, apart from the exe and store names (cite requirement 1).
- With no mouse, `tui_mouse_enable` fails and the app is fully usable.

## Criteria

- **Must:** each app's `tests/test_ui_sim.py` gains replays with
  scripted mouse reports (`IocCommandPeer` `mouse_reports`) covering:
  - KonaCommander: click select, double-click open, wheel scroll, a
    menu item by mouse, a button by mouse, copy confirm by mouse;
  - KonaEdit: click to place the cursor (including a TAB line and a
    sideways-scrolled line), drag selection, wheel scroll, a menu item
    by mouse, a dialog button by mouse;
  - all existing app tests pass.
- **Informational:** each exe's size before and after.

## Owner checklist

- `kc.exe`: click and double-click in both panes, the wheel, the menus,
  the buttons, the viewer's wheel and right click, copy confirm by click.
- `kedit.exe`: click to place the cursor, drag to select then copy and
  paste, the wheel, the menus, a save dialog driven by the mouse.

## Validation

Application-only package: no OS `make check`. Once, at the end:

```sh
make sdk                              # in the OS tree
cd UserSoftware/KonaCommander && make clean && make && make test
cd UserSoftware/KonaEdit && make clean && make && make test
```

Record: `docs/validation/<date>-apps-mouse.md`.
