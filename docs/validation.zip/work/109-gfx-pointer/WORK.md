> Worker package. After 108 (accepted). libgfx draws its own mouse
> pointer while it holds the VDP. SDK only: no driver, nucleus, ABI or
> firmware change. Baseline: HEAD at dispatch; preserve untracked
> `docs/KonaOS Programmer's Guide.pdf`.

# Task

A libgfx program holds `/dev/video` exclusively, so the console pointer
(`KVIDEO_OP_POINTER`) refuses it with `-KOS_EBUSY`. libgfx gets its own
pointer: a 16×16 hardware sprite it places in both drawing modes, kept
in a fixed VRAM band the program gives up while the pointer is in use.

## Current state

- `user/sdk/gfx/src/backends/v9958/v9958_gfx.c:v9958_set_mode`: R#8 =
  64K DRAM with sprites off (`GFX_V9958_R8_SPRITES_OFF`), R#5/R#6/R#11
  = 0 (`v9958_common_regs`), R#1 display off; `v9958_display_enable`
  writes R#1 whole. Port access only in `v9958_io.asm`
  (`gfx_v9958_io_*`); CPU VRAM paths wait for the command engine first
  (`gfx_v9958_io_wait_command`).
- Modes (`docs/gfx-sdk.md` 6, 15): G6 512×212×16 and G7 256×212
  (256-colour, YJK), two 256-line pages, y 0-511, lines 212-255 of each
  page spare and program-owned; 256 bytes per line in both modes.
- The console's sprite tables sit at colours `1F000h`, SAT `1F200h`,
  patterns `1F800h` (`drivers/v9958/v9958_driver.h` `V9958_CURSOR_*`):
  page 1, y 496-511 in both modes, inside the spare band.
- Sprite mode 2: Y draws one line below the SAT value; Y `D8h` ends
  evaluation; G6 X unit is 2 pixels, G7 X unit 1 pixel; 16×16 needs
  R#1 SI. The 107 driver's rules (`v9958.c` pointer writer) are the
  model.
- Mouse SDK: `kos/mouse.h` (`mouse_open`, `mouse_init`,
  `mouse_track`). Drawing paths are assembly entry to port (owner rule;
  `docs/gfx-sdk.md` 2.6).
- Tests: `tests/test_gfx.py` with `V9958Peer` (`regs`, `vram`,
  `vram_writes`); `tests/gfx/gfxtest.c`.

Read: `work/00-WORKER.md`; `docs/gfx-sdk.md` 2.6, 6, 7, 14.1, 15;
`docs/sdk.md` mouse; the files above.

## Requirements

1. **API** (Must), in `kos/gfx.h`:
   `int gfx_pointer_show(int x, int y)` (screen pixels of the current
   mode: x 0..511 or 0..255, y 0..211; the hot spot top-left; first use
   installs the tables), `int gfx_pointer_hide(void)`,
   `int gfx_pointer_shape(const uint8_t *pattern, uint8_t color)` (32
   bytes, 16×16, one colour; a default white arrow otherwise). Errors:
   `-KOS_EINVAL` out of range or before `gfx_set_mode`.
2. **Tables** (Must): colours `1F000h`, SAT `1F200h`, patterns
   `1F800h` (R#5/R#11/R#6 accordingly); slot 0 the pointer, slot 1 the
   `D8h` terminator. While the pointer is in use, page-1 lines
   496-511 belong to libgfx; `gfx_set_mode` returns them to the program
   (pointer off, sprites off, as today).
3. **Placement** (Must): sprite Y = y − 1 with the D8h rule (`D7h`
   instead); X = x / 2 in G6, x in G7; R#1 SI set while shown, and
   `v9958_display_enable` keeps SI; the SAT is written only when the
   position changed, after `gfx_v9958_io_wait_command`.
4. **Sprites on only while shown** (Must): show clears R#8 SPD, hide
   sets it, so programs without a pointer keep today's command speed.
5. **Assembly** (Must): the show/move path from entry to port in
   `v9958_io.asm` style; setup (table install, shape upload) may be C.
6. **Example** (Must): `user/sdk/examples/gfx_mouse.c` (or the gfx
   demo's existing home): G6, the pointer follows the mouse
   (`mouse_init` 512 × 212), the left button paints, the right button
   switches to G7 and back (the pointer follows the mode), any key
   exits. In the store with the other gfx programs.
7. **Docs** (Must): `docs/gfx-sdk.md`: a pointer section, the reserved
   band in 15 and 14.1 (an atlas band must avoid it), 20 drops "mouse
   handling"; `docs/sdk.md` cross-reference.

## Invariants

- A program that never calls `gfx_pointer_*`: same registers, same
  timing, links no pointer member; `tests/test_gfx.py` existing cases
  unedited.
- The release (`gfx_close`) restores the console as today; no console
  pointer is left shown.

## Criteria

- **Must:** peer evidence: table registers, the SAT bytes for G6 and
  G7 at both edges, the D8h rule, SI kept across display enable, SPD
  cleared on show and set on hide, no SAT write while the engine is
  busy, mode change returns the band; the validation suites green.
- **Informational:** one `gfx_pointer_show` call in T-states; a
  full-screen fill's T-states with the pointer shown and hidden (the
  simulator does not model sprite VRAM contention).

## Owner checklist

- `gfx_mouse`: the pointer follows in G6 and G7, painting under it
  works, no flicker, exit returns to the console with no pointer.
- Note any slowdown of drawing while the pointer is shown.

## Validation

SDK-only package: no `make clean && make check`. Once, at the end:

```sh
make && make sdk
python3 -m unittest tests.test_gfx tests.test_mouse tests.test_sdk \
  tests.test_sdk_package tests.test_device_release tests.test_pack_image
```

Record: `docs/validation/<date>-gfx-pointer.md`.
