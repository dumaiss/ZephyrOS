# 109 gfx-pointer progress

## Tree at start
- `git status --short` clean at HEAD 45b5010; the supervisor's "uncommitted 108/110/108b"
  work is committed in 45b5010 (UserSoftware, xmem, tui mouse). Nothing to classify.
- `docs/KonaOS Programmer's Guide.pdf` present; leave alone.

## Status
- Reading contract and named files.

## Steer (supervisor, accepted)
1. D8h rule: keep runtime check in the move path + structural assert (211-1 < D8h);
   evidence y=0 -> FFh, y=211 -> D2h, slot 1 = D8h. Record: not reachable through
   the public API (R#23 = 0, y 0..211); kept as a guard (also the install's
   "unknown" cache mark, like the driver).
2. gfx_mouse: in-tree SDK example (user/sdk/examples/Makefile + top Makefile beside
   tui examples), shipped in SDK package; test_sdk_package pin follows (source:
   WORK.md req 6 + steer). No production store change.

## Design (decided)
- State in v9958_io.asm _DATA (linked by every set_mode program): _gfx_v9958_r1
  (R#1 shadow: BL | SI), _gfx_pointer_flags (bit0 installed, bit1 shown),
  _gfx_pointer_sat (cached Y, X), _gfx_upload_active (moved from gfx_upload.asm
  up_active, same instructions) so a show during an upload defers its SAT write.
- New members: backends/v9958/gfx_pointer.asm (show/hide, entry to port),
  gfx_pointer.c (install tables, shape, default arrow).
- set_mode clears r1 shadow + pointer flags; display_enable keeps SI.
- Tests: gfxtest `pointer` mode + TestGfxPointer (markers = windows; SAT history
  from vram_writes order; addr_writes times vs command busy_until), gfx_mouse replay.

## Failures
- TestGfxPointer (new) run 1: window 1 regs [(14,7)] != []. Class: test artifact of
  the new test (R#14 = A16..A14 is part of the SAT address set; source: the V9958
  VRAM address protocol, v9958_io.asm set_vram). Expectation fixed to [(14, 7)].
