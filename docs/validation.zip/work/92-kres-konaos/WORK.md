> Worker package. After 90 and 91. The KonaOS edition: `libkres` in the
> SDK, its KonaOS adapter and XMEM catalog cache, a test program and
> native acceptance. No OS change; no client (editor, KonaM2).

# Task

Ship the package-91 core as an optional SDK archive, `LIBS=kres`, with
the KonaOS file adapter (open/read/write/seek/sync/truncate/rename/
unlink) and an XMEM-backed catalog cache. Then prove it on the production
image in the simulator: native containers interoperating with the host
tool.

## Current state

- **The core and its interfaces** (`struct kres_io` and the cache
  interface) come from package 91, in `user/sdk/kres/src/` and
  `kos/kres.h`.
- **SDK file calls** (`kos/fs.h`): `open` (`KFS_O_*`), `read`, `write`,
  `seek` (signed `long`), `sync`, `close`, `rename`, `unlink`, `stat`,
  and `truncate` from package 90.
  - **File slots:** the card serves at most two open files, system-wide.
  - **Names:** they are 8.3 (`docs/filesystem.md`).
- **XMEM** (`kos/xmem.h`): `xalloc(size, flags)`, `xread`, `xwrite`,
  `xfree`. The catalog cache is 2 KiB (design §5.5).
- **Optional archive patterns:** `libgfx` and `libtui` in
  `user/sdk/exe.mk`, `tools/sdkpack.py`, `mk/kos.mk` `LIBS=`,
  `tests/test_sdk_package.py`.
- **Programs that only read** must not link the mutation, flush, builder
  or compaction code (design §8, "Library size").

Read: `work/00-WORKER.md`; `docs/kres-sdk-design.md`; package 91's
record; `docs/sdk.md`; `user/sdk/exe.mk`.

## Requirements

1. **Archive** (Must). `libkres.lib`, shipped by the SDK, linked with
   `LIBS=kres`. Its members are split so that:
   - a sealed-container reader links only the read path, the adapter's
     read side and the cache;
   - mutation and flush, the builder, compaction, extract and verify are
     separate members.

   Record each member's size, and the total a read-only program links.
   - **Starting point** (91's record): the read-only core is 4,616 bytes
     of code without the zero page, against the 3 KiB target. Move
     `kres_zero_page` (512 bytes, defined in `kres_util.c`, used only by
     `kres_mut.c`) into the mutation member, so a reader doesn't link it.
     Then profile the largest functions (`kres_read`, `kres_open`,
     `kres_read_records`, `kres_header_parse`) for size. Use assembly
     only where C can't get there; report what remains.
2. **Adapter** (Must). The KonaOS `struct kres_io`:
   - every SDK call's error is propagated;
   - a write beyond the physical end extends the file with zero records
     (design §5.1);
   - compaction's temporary file and rename use 8.3 names in the
     container's directory;
   - a container beyond 65,535 records is refused at open.
3. **Cache** (Must). The catalog cache in one 2 KiB XMEM object,
   allocated at open and freed at close (including every error path
   after the allocation).
4. **Program** (Must). `krestest` (in-tree, `tests/kres/`, `LIBS=kres`),
   with modes covering:
   - `build`: a sealed container;
   - `edit`: create, write, grow past capacity, rename, delete, flush,
     close;
   - `read`: list and print resource checksums;
   - `compact`: rebuild and rename;
   - `extract`: one resource to a file;
   - `readonly`: open a sealed container read-only, read it, attempt a
     write.
5. **Docs** (Must): `docs/sdk.md` (`LIBS=kres`, the members, the two-slot
   rule: close the container before `run()`, design §9.1). The design's
   status line marks format v1 frozen.
6. **`call()` refusal check** (Must). A carried-over gap from the
   truncate work: nothing fails if `call()` (`user/sdk/src/ipc.c`) goes
   back to returning the reply-status field, which reads 0 when the
   kernel refuses before the provider.
   - Add one check to the `truncate` tail of `tests/fs/fs_selftest.c`:
     `call()` on the open FILE handle with an op the kernel's FILE gate
     does not forward (for example 0xEE) returns `-KOS_EINVAL`.
   - In `tests/test_truncate.py`, CHECKS becomes 14, and the label goes
     into OUTCOMES.
   - Prove the check discriminates: with the old `return
     (int)kos_ipc_call_block.status;` it fails. Revert that, and record
     the failing line.

## Tests

`tests/test_kres_native.py`, production-image replays (the C core makes
them fast). The card holds `krestest.exe` and fixtures:

- **Host to native:** a container made by `build/host/kres pack` is read
  by `krestest read`, and its checksums match.
- **Native to host:** a container made by `krestest edit` is read back by
  the host tool (`verify`, `extract` byte for byte).
- **Growth and commit:** after `edit`, the host `verify` passes and the
  old extents are unreferenced. A run cut off mid-flush (stop the replay
  at the second catalog write) still verifies, with the previous catalog.
- **Compaction:** after `compact`, the file is shorter (truncate), every
  resource is intact, and the recovery name is gone.
- **Sealed and read-only:** writes are refused, and the container is
  unchanged. A program that only reads links no mutation member (check
  its map).
- **Slots:** `krestest` opening a container while another file is open
  works. Opening a second container is refused.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| read-only link (read path + adapter + cache) | - | report; target <= 3 KiB | report |
| full link (all members) | - | report | report |
| driver/OS bytes | unchanged | 0 | stop and report |

## Criteria

- **Must:** requirements 1-6; the tests pass; no OS byte changes.
- **Should:** the read-only target.
- **Informational:** every member's size; card I/O per operation
  (records read and written for open, a lookup, a flush).

## Owner checklist

- On the board:
  - copy a host-packed container and `krestest.exe`, run `krestest read`;
  - run `krestest edit`, then `compact`;
  - copy the container back and `kres verify` it on a PC.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make kres-host
python3 -m unittest tests.test_kres tests.test_kres_native tests.test_truncate tests.test_sdk tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-kres-konaos.md`.
