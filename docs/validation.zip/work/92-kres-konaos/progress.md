# Package 92: kres-konaos

## Contract

`work/92-kres-konaos/WORK.md` — the KonaOS edition: `libkres.lib` in the
SDK with split members, the KonaOS file adapter (8.3 temp names, zero
record extension, 65,535-record refusal), the 2 KiB XMEM catalog cache
(xalloc at open, xfree at close), the `krestest` program, native
replays, docs, and the `call()` refusal check from the truncate gap.

## Status

- [x] read WORK.md (edited version), work/00-WORKER.md
- [x] read the package-91 record, docs/kres-sdk-design.md, docs/sdk.md,
      user/sdk/exe.mk (adapter/cache/exe patterns)
- [x] libkres.lib archive: split members (read path, adapter read
      side, cache, mutation, flush, builder, compaction, extract,
      verify) and LIBS=kres wiring (exe.mk, sdkpack --libkres,
      Makefile sdk tarball, test_sdk_package pins)
- [x] KonaOS adapter: SDK file calls, error propagation, 8.3 temp
      names, zero-record extension, 65,535-record open refusal
      (kres_header_parse enforces next_record > 65,535 -> -KRES_E_BAD,
      the adapter open propagates it)
- [x] XMEM catalog cache: one 2 KiB object, xalloc at open, xfree at
      close on every path
- [x] krestest program (build/edit/read/compact/extract/readonly)
      + kresread (read-only install) as the link-split proof; both
      wired in the Makefile (LIBS=kres, STACK=384, `all`)
- [x] member split proof: kresread.map links kres_util, kres_read,
      kres_adapter, kres_cache_xmem only; krestest.map links all ten
- [x] kres_zero_page moved to kres_mut (512 bytes no longer linked by
      readers); kres_header_parse fixed-field pairs now one 32-bit
      compare per pair (kres_util 1,771 -> 1,740)
- [x] call() refusal check: fs_selftest truncate tail `call()` op 0xEE
      -> -KOS_EINVAL; test_truncate CHECKS 14 + label; discrimination
      proven (status-only return fails at
      `fs-selftest: FAIL trunc-call-refusal`), then restored
- [x] docs/sdk.md LIBS=kres + member table + two-slot rule; design
      status line v1 frozen
- [x] tests/test_kres_native.py replays (5 tests, all green):
      host->native read, readonly refusals, kresread on card,
      native->host verify/extract, growth/commit facts, two-slot
      refusal (-KOS_EMFILE), compact shorter + swap names gone,
      mid-flush cutoff at the second catalog write (previous catalog
      verifies), native build sealed
- [x] member sizes + read-only/full link totals recorded (see Notes)
- [x] validation batch + record
      (docs/validation/2026-10-25-kres-konaos.md): make + make sdk +
      make kres-host clean; unittest block 115 OK (1 pre-existing
      skip); make clean && make check reproducible and green; fs image
      rebuilt after clean and its replays pass; diff --check clean.

## Notes

Member sizes (_CODE bytes, SDCC .rel areas):
kres_util 1,740 (+522 DATA: kres_shared etc), kres_read 2,884,
kres_adapter 1,487 (+10), kres_cache_xmem 1,716 (+16); read-only link
= 7,827 _CODE against the 3 KiB target (overrun reported in the
validation record).  kres_mut 7,901 (zero page included), kres_build
1,582 (+65), kres_compact 1,711 (+320), kres_verify 1,630,
kres_extract 230, kres_adapter_mut 173; full link = 21,054 _CODE.
krestest.exe 31,321 bytes, kresread.exe 15,191, libkres.lib 156,498.

Three bugs the native replays caught and the fixes: the EXE v2
zero-init made `handle == 0` read as an occupied slot (explicit
`open` flags now); compaction's `~` is rejected by the card's 8.3
codec (the adapter spells it `$`); `kres_open` passing CREATE to the
adapter hid the create-on-missing hook (it probes without the flag).
