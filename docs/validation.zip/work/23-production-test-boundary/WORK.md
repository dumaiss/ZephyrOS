# Production/Test Boundary Cleanup

## Task

Remove acceptance-only CTC programming helpers and obsolete IRQ mapping code
from the production kernel while preserving every historical acceptance image
that still needs equivalent test behavior. Strengthen production enforcement
so this class of leak cannot recur.

M1-M8 acceptance remains closed. This package corrects source ownership and
production linkage only; it does not re-evaluate the older milestones.

## Problem and required change

`drivers/ctc/ctc.c` is always linked into production. It contains the required
production `platform_irq_quiesce()` implementation, but also
`platform_ctc0_test_start()` and `platform_ctc0_stop()`, whose consumers are
acceptance paths, plus unused `platform_irq_vector()`. All three appear in the
production map even though the architecture and build documentation say that
production rejects acceptance symbols. `tools/mapcheck.py --production` does
not currently classify these names as forbidden. The public IRQ header also
publishes the test helpers. Separately, `include/zephyros/syscall.h` declares
the target self-test runner even though the test-owned header already declares
it.

Move CTC start/stop implementation and declarations into test-owned source and
headers under `tests/target/`. Keep `platform_irq_quiesce()` with the production
CTC owner. Remove the unused `platform_irq_vector()` declaration and
implementation unless a real production consumer is first demonstrated.

The M4 pending-across-module-load test must preserve its interrupt lock window.
Route that behavior through generic target-test hooks declared by the existing
test seam and implemented in test-owned support, rather than calling named CTC
test helpers from production orchestration. Production builds must not link
the implementation, and milestone-specific compile guards must not spread
beyond the existing target-test boundary. Remove the duplicate self-test
runner declaration from the public syscall header and use the test-owned
header.

Extend source-layout and production-map checks to reject CTC test helpers,
target test runners, and other acceptance-only symbols in production. Add a
focused negative fixture proving that the new forbidden prefix/symbol is
caught. Update `docs/devices.md` diagrams/comments to show the generic test
seam rather than a production CTC API.

## Constraints

- Do not change the production IRQ dispatch, CTC0 quiesce value, IM2 layout,
  interrupt stack, ownership rules, or module-load transaction.
- Preserve the exact CTC programming sequence and critical section in the
  acceptance images that exercise it.
- Do not retain dead production wrappers merely to preserve symbol addresses.
- Do not mix this package with the module-header split from package 22.
- Because removing linked code may move production addresses and change the
  ROM hash, previous hardware evidence applies only where byte identity is
  demonstrated.

## Validation

Run a clean full host suite and build the syscall, IRQ, M3, M4 IRQ, M4 shifted,
M4 failure, and integrated M8 acceptance variants. Run their simulator suites,
`tools/mapcheck.py --production`, the negative mapcheck fixture, and
`git diff --check`. Compare maps and hashes before/after. Historical acceptance
images should be byte-identical where practical; explain any change.

If the production or integrated M8 ROM changes, flash the corrected integrated
M8 image and repeat the package-20 automated serial smoke plus the HID/V9958
human acceptance. If the IRQ or M4 acceptance image changes, repeat its
physical smoke as well. Record new hashes/transcripts; never carry old physical
acceptance across changed hardware-facing bytes without a strong equivalence
proof.

## Acceptance criteria

- The production map contains `platform_irq_quiesce()` but none of
  `platform_irq_vector`, `platform_ctc0_test_start`, or
  `platform_ctc0_stop`.
- CTC acceptance behavior is implemented and declared only under tests.
- No public production header declares a target self-test runner.
- Production map/source checks fail on deliberate acceptance-symbol leakage.
- Required simulator, host, and any invalidated hardware gates pass.

## Expected files

- `drivers/ctc/ctc.c`
- `include/zephyros/{irq,syscall}.h`
- `kernel/main.c`, `tests/target/`, `tests/test_source_layout.py`
- `tools/mapcheck.py`, `Makefile`, `docs/devices.md`

