> **DRAFT. Not dispatched.** Runs after 51. Ends M11 (the shell).

# Task

Make the shell the production boot program and pin the launcher's
failure policy. This is the only kernel change of the shell milestone,
and it is confined to the boot launcher in `kernel/main.c`, cold half.
Then run the hardware acceptance.

Read: the 50, 51 and 51b records (the launcher calls `KCONSOLE_OP_RESET` before every start, from 51b); the architecture's native shell section
(boot policy and acceptance); and the boot launcher in `kernel/main.c`.

## Requirements

1. **Boot program.** The shell enters the OS here. In
   `systems/production.json` and `systems/console-serial.json`: add
   `shell.exe` to `store` (its `exe_program` line gains `STAGE=1`) and set
   `"boot": "/system/shell.exe"`.
2. **Launcher policy.** It is fixed, and a new setting
   `KOS_BOOT_AFTER_EXIT` (`relaunch` | `monitor`) controls what happens
   after a normal exit.

   | event | action |
   |---|---|
   | the boot program exits with a status (any value) | print `boot: <path> exit <n>`; `relaunch` → start it again, `monitor` → start `/system/monitor.exe` |
   | `run` of the boot program fails (< 0: missing, rejected, fault) | print `boot: <path> failed <code>`; start `/system/monitor.exe` |
   | the monitor exits | start the boot program again (the monitor's `Q`/exit returns to the shell) |
   | the monitor itself fails to start | today's controlled halt |

   - Production: `relaunch`.
   - **Every selftest and acceptance image: `monitor`.** A test image
     then runs once and ends at the monitor instead of looping (post-M10
     item 5).
   - The setting is a system-file field (`"after_exit"`), validated by
     `tools/systemgen.py` with the boot setting: the value is one of the
     two, and `monitor.exe` is in the image's store.
3. **The fallback is tested.** Use a test image whose store has no
   `shell.exe` while the boot program names it, and one whose `shell.exe`
   is corrupt (a bad EXE header). Both reach the monitor with the
   `failed` line.
4. **Smoke.** Add `tools/serial_smoke.py --mode shell`. It waits for the
   prompt, then sends:
   - `pwd`;
   - `ls /system`;
   - `hwtest`, checking `hwtest: n/n PASS`;
   - `exit`, checking the relaunch banner and a new prompt.

   It works with and without a card.
5. **Ledgers.** The launcher change stays within the cold half. Fixed
   core, common and driver ledgers unchanged. Record all ledgers and the
   store.

## Owner checklist (hardware; put it in the record)

Run it for each of: V9958+HID production, serial production.
1. Boot. The prompt appears; `pwd` shows `/`, or `/system` with no card.
2. `ls //`, `ls /dev`, `ls /system`.
3. `mkdir /T`, `cd /T`, `cp /system/hwtest.exe .`, `ls`, `hwtest`
   (from `.`), then `cd /`, `rm /T/hwtest.exe`, `rmdir /T`.
4. `monitor` (found in `/system`), then `Q` → back at the shell prompt.
5. `exit` → `boot: /system/shell.exe exit 0`, and the shell starts again.
6. Without a card: boot, `ls /system`, `hwtest` (card-absent branch),
   and `mkdir /X` → `no device`.

## Tests

- **Host:** the `systemgen.py` validation of `after_exit`; the policy table, as
  launcher-level unit cases where the harness allows.
- **Simulator replay:**
  - production boots to the shell prompt;
  - `exit` → relaunch;
  - the two fallback images;
  - a selftest image ends at the monitor after one run;
  - the 50/51 sessions still pass when the shell is the boot program;
  - without a card: the shell starts in `/system` with `shell: no
    filesystem, starting in /system`; `ls /system` and
    `cat /system/drivers.man` work; `ls /` and `mkdir /X` report
    `no device` (deferred from 50/51, where the shell lived on the card).

## Constraints

- No other kernel or driver change. The production hash changes; record
  it.
- Record: `docs/validation/<date>-m11-shell-boot.md`, with the owner
  checklist.

## Validation (targeted: no `make clean && make check`)

Put the tests in `tests/test_boot_policy.py` (host and replay). Use these same commands while developing,
and once at the end:

```sh
make                                              # production builds: store fits, mapcheck passes
python3 -m unittest tests.test_boot_policy
make fs-selftest                                  # one test image ends at the monitor
python3 -m unittest tests.test_console_acceptance # production still boots
git diff --check
```
