# progress — package 52 (m11 shell boot)

State: **complete, uncommitted**.  The launcher, the setting, the system
files, the two fallback images, the boot-policy tests, the migrated
replays, the serial smoke mode, the docs and the validation record are
all done; the console-integration image's own cold-half overflow is a
pre-existing, out-of-scope open item (see the notes).

## Done

1. **Boot program.** `systems/production.json` and
   `systems/console-serial.json`: `"boot": "/system/shell.exe"`,
   `shell.exe` first in the store, `"after_exit": "relaunch"`.  The
   Makefile's shell `exe_program` line gained `STAGE=1` (the store's
   image, not a card program), and its "lives on the card" comment and
   the `all:` dependency line are gone.
2. **Launcher policy.** `kernel/main.c`, cold half only:
   `kernel_boot_line()` composes `boot: <path> exit <n>` /
   `boot: <path> failed <n>` in a `KOS_PATH_MAX + 24` buffer and writes it
   through the console; `kernel_boot_halt()` is the controlled halt; the
   loop tracks whether the program it runs is the boot program or the
   monitor and applies the table - a failed run falls back to
   `/system/monitor.exe` (a failed monitor halts), a normal exit
   relaunches under `relaunch` and hands over under `monitor`, and the
   monitor's exit returns to the boot program.  The old
   `monitor: exit status 0x… active … free-banks …` report is gone, so
   the launcher's decimal output no longer divides (the kernel links no
   arithmetic runtime): `kernel_boot_put_dec()` subtracts powers of ten.
3. **Setting.** `tools/systemgen.py`: the required `after_exit` field
   (`AFTER_EXIT_CHOICES`), `validate_after_exit()` (`monitor` images must
   carry `monitor.exe` as an EXE entry), `KOS_BOOT_AFTER_EXIT` in the
   generated `system.mk`, the `--omit-store NAME` generator flag (the
   entry leaves the packed store, `KOS_STORE_FILES` and the manifest,
   while `validate_boot()` accepts a boot program naming it), and the
   summary line now ends `boot <path> after-exit <policy>`.
4. **System files.** All twelve existing files were rewritten with the
   field in a single order (`schema`, `name`, `drivers`, `boot`,
   `after_exit`, `store`, `cflags`): the two production systems boot the
   shell and relaunch; every acceptance image states `monitor` and
   carries `monitor.exe` (`ipc`, `ns` and `xmem` gained it).  Two new
   files: `systems/boot-missing.json` (the store omits `shell.exe`, the
   boot setting names it) and `systems/boot-corrupt.json` (the boot
   setting names the malformed `exe-bad-magic.exe` container fixture).
5. **Fallback images.** Makefile: `SYSTEM_SUFFIX.boot-missing`/
   `.boot-corrupt`, `SYSTEM_OMIT.boot-missing := --omit-store shell.exe`,
   the boot-header rule also writes
   `#define KOS_BOOT_AFTER_MONITOR` (1 for a `monitor` image), and the new
   `boot-fallback-selftest` target builds both images and runs
   `tests/test_boot_policy.py`.
6. **`SYS_EXEC` path resolution.** `kernel/syscall.c` now normalizes the
   caller's exec path against the caller's CWD exactly as `SYS_BIND` does
   (`vfs_path_normalize_at` into the workspace's normalized slot).  The
   ABI has always stated that rule ("resolved against the caller's
   CWD"), but the exec body skipped it, so a `.`-relative candidate
   reached the card provider raw and came back `KOS_EINVAL`.  With the
   shell as the boot program that gap is on the shell's default path
   (`path` is `. /fs/BIN /system`), so the owner checklist's
   `cp /system/hwtest.exe .` + `hwtest` row, the `hwtest` smoke step and
   the shell's bare-name lookup over a card all depended on it.  Verified
   by replay: `monitor` at the shell, and the `mkdir /T`, `cd /T`, `cp`,
   `ls`, `hwtest` sequence, both work on the production image.
7. **Tests.** `tests/test_boot_policy.py` (host and replay): the system
   files' settings, the generator's rejections (missing setting, unknown
   value, `monitor` without the store entry, `relaunch` without one), the
   generated `system.mk`/`boot_program.h` and the two fallback stores,
   production boots to the shell prompt with no launcher line, `exit 42`
   reports the status and relaunches, the card-less shell stays in the
   store (`shell: no filesystem, starting in /system`, `ls /system`,
   `cat /system/drivers.man`, `ls /` and `mkdir /X` as `no device`), the
   monitor round trip returns to the shell, both fallback images report
   the failed line and end at the monitor (and `q` there tries the boot
   program again), and the filesystem image ends at the launcher's own
   monitor after its run.

## Migrated replays

The old launcher line and the old boot program were pinned by these
modules; the migration kept every claim, retargeted at the shell:

- `tests/test_console_acceptance.py` — production boots the shell, the
  visible session runs the store's monitor as the shell's child and `q`
  returns to the shell prompt (no launcher line); the integration image's
  `q` ends the session the boot program hands over and the launcher's
  exit line plus a second monitor follow.
- `tests/test_console_serial.py` — the serial production image boots the
  shell and its whole session, including `exit`, is on the serial lane.
- `tests/test_hwtest_sim.py` — the exerciser is typed at the shell (the
  production console's lane); the monitor's secondary lane moves out of
  this module with the old boot program.
- `tests/test_shell_sim.py` — the sessions start at the shell prompt
  instead of `X /fs/SHELL.EXE`, the card no longer carries the shell, and
  the card-less rows run here now that the shell is in the store.
- `tests/test_device_release.py` — the takeover program is run from the
  shell prompt.
- `tests/test_subsys_sim.py`, `tests/test_ns_selftest_sim.py`,
  `tests/test_xmem_selftest_sim.py`, `tests/test_far_data.py`,
  `tests/test_sdk.py`, `tests/test_monitor.py`, `tests/test_hwtest.py` —
  the exit/report pins become the launcher's lines (and, for the xmem
  replay, the release proof reads the kernel's bank tables instead of the
  dropped `free-banks` field).
- `tests/test_systemgen.py` — the helper's system document gains the
  field, and the generator's end-to-end case covers the new rejection.

Done after the replay migration: `tools/serial_smoke.py --mode shell`
(the prompt, `pwd`, `ls /system`, `hwtest` with its verdict, `exit` with
the relaunch line and a new prompt; with and without a card) with the
`SUBSYS_EXIT` pins in the other modes; the docs (`architecture.md`,
`boot.md`, `monitor.md`, `sdk.md`, the Makefile smoke table and target
comments) and `docs/validation/2026-10-13-m11-shell-boot.md`.

## Ledgers (current build)

| ledger | value |
|---|---|
| fixed core | unchanged: code end 3D3Fh, 8354 required + 2 overflow + 768 stacks, room 7260 |
| cold half | code end BD35h, code 23861 bytes, data 1527 bytes at BE00h, room 7177 |
| driver hot | 22168 bytes of 32768 (unchanged) |
| driver boot/bulk | 2170 bytes of 24576 (unchanged) |
| common | 2366 of 7424 bytes (code 1519, data 847), ceiling 3072 (unchanged) |
| production store | 18 entries: 6 driver images, `drivers.man`, `shell.exe`, `monitor.exe`, `hwtest.exe`, `xmem_selftest.exe`, `xmem_child.exe`, `xmem_far.exe`, `fs_selftest.exe`, `fs_child.exe`, `far_data.exe`, `banks.exe`, `known.bin` |
| monitor artifact | 6387 bytes, sha256 `baa05b71d665164d8fbd14a939f9438761bc1744fd2dc393e30932f903ffc27d` (unchanged) |
| production image | sha256 `abb159cd371adf9af5245be4cc25701e11f30180bc83cf1a9acc5920f4615d09` |
| recovery store | sha256 `3583db0c2bb00aea2806d09a858f445885fef89a380b1beabd617752feecf9b1` |
| subsystem image | cold code end D7E7h (30695 bytes), data 1735 at D800h, 312 bytes of window room |

The launcher rewrite left the production cold half 29 bytes smaller than
the package-51b build; the fixed core, the driver tiers and the common
region are untouched.

## Validation

- `make`: production builds, store fits, `mapcheck: OK (18 areas, 366
  symbols)`, fixed core 3D3Fh / cold half BD35h / data BE00h.
- `python3 -m unittest tests.test_boot_policy`: 22 tests, OK.
- `make subsystem-selftest`: build + `tests.test_subsys_sim` +
  `tests.test_romfs_sim`, OK.
- `make fs-selftest`: 3 tests, OK (one test image ends at the monitor).
- `python3 -m unittest tests.test_console_acceptance`: production class
  OK (the integration class skips: see the note on that image below).
- `python3 -m unittest tests.test_hwtest_sim tests.test_device_release`:
  16 tests, OK.
- `make console-serial-selftest`: 6 tests, OK (builds the three serial
  images).
- `make helloworld-image` (`tests.test_sdk`), `make xmem-selftest` (9),
  `make ns-selftest` (27), `make ipc-selftest` (40),
  `make nucleus-selftest` (6), `tests.test_shell_sim` (2),
  `tests.test_far_data` (7), `tests.test_console_serial` (6),
  `tests.test_monitor`+`tests.test_hwtest`, `tests.test_systemgen` (39),
  `tests.test_source_layout` (52): OK.
- `python3 -m unittest tests.test_monitor tests.test_hwtest
  tests.test_shell tests.test_shell_sim`: 69 tests, OK (the two artifact
  pins below were stale after the migration and are corrected).
- `git diff --check`: clean; the handoff grep prints nothing.
- `make console-integration-selftest`: **blocked, pre-existing** - see
  the note below.
- No `make clean && make check`: the package is validated with the
  targeted commands above.

## Notes

- The corrupt-boot image uses the store's existing malformed-container
  fixture (`exe-bad-magic.exe`) rather than a byte-patched `shell.exe`:
  the store builds its programs from one shared rule, and overriding it
  for one image would duplicate that recipe for no extra coverage - the
  launcher's failure path cannot tell the two apart.
- The launcher's monitor-failure halt is unchanged and is reachable only
  when `/system/monitor.exe` itself cannot start; the fallback images
  cover the failure branch *before* it (the monitor is present and
  healthy in both).
- `tests/fs/fs_selftest.c` and `tests/console/escc.c` hand the console to
  a monitor of their own before they return (their acceptance flow), so
  the launcher's `monitor` policy shows up after *that* session ends:
  the exit line and a second monitor at the machine's own pid.
- The shell has no serial command lane (the monitor's secondary
  `/dev/serial/0` lane is its own); on the bench the smoke's typed line
  reaches the shell's console through the MCU, and in the replays through
  the HID lane.
- **The console-integration image does not fit its cold half**, and it
  does not fit it *independently of this package*: its cold code ends at
  D87Ch where 30720 bytes end at D800h, and the rewrite above is 29
  bytes smaller than the package-51b kernel, so the image was already
  over the derived data base (`D900h + 1871 > E000h`) before these
  changes.  The working copy has no such image built at all, which is
  why its replays (`tests.test_ioc_sim`, `test_hid_sim`,
  `test_v9958_sim`) and the migrated integration class of
  `test_console_acceptance` skip.  Fixing it means freeing ~124 bytes of
  cold code outside this package's launcher-only scope; the record lists
  it as an open item rather than a package-52 change.
- **A program start resets its console** (package 51b), so a replay that
  types at a session must type *after* the session's prompt is up:
  `tests.test_subsys_sim`'s monitor session now waits for the monitor
  before sending `Q`, and `tests.test_device_release`'s mid-transfer
  reboot waits for the whole `dev: writing <n>` line (with its CRLF)
  before it reboots.
- `tests/test_romfs_sim.py`'s host scratch is the free window run above
  the linked image, which the acceptance images fill to a few hundred
  bytes of the common boundary; the replay's own uses (a request at +0, a
  result at +0x40, a name at +0x100) are what the check bounds now.
- Stale wording removed with the migration: the "keeps the monitor
  launcher" comments on the console-integration and subsystem make
  targets, and the package-numbered notes in `tests/test_sdk.py`,
  `tests/test_shell.py`.
- Two artifact pins still described the shell as a card program and the
  launcher's line as an image literal: `test_shell.py`'s staging test now
  asserts the staged `shell.exe` and the production boot setting, and
  `test_monitor.py` checks the launcher's composed line by its fragments
  (including `/system/monitor.exe`) instead of the whole line.
- Trailing whitespace on the two documentation prompt examples is
  trimmed so `git diff --check` stays clean.
