# Task

Implement milestone M6: add a fixed single-tasking process lifecycle, ZEX v1 construction/loading, useful native syscalls, and an acceptance program loaded from ROMFS that exits back to its parent without leaking bank or process state.

## Context

This package starts only after M5 is reviewed and physically accepted. M5 supplies ROMFS and the only production byte-source abstraction; M6 must use it rather than adding another executable store. Application banks are 0-6, bank 7 remains kernel-only, logical program addresses do not change with physical bank selection, and mode `10`/`11` behavior remains invariant.

Define ZEX v1 as a 20-byte little-endian header followed immediately by the image: `00 magic[4]="ZEX1"`; `04 format_version:u8=1`; `05 abi_version:u8=1`; `06 flags:u8=0`; `07 reserved0:u8=0`; `08 header_size:u16=20`; `0A image_size:u16`; `0C bss_size:u16`; `0E entry_offset:u16`; `10 stack_size:u16`; `12 reserved1:u16=0`. The file size must equal `header_size + image_size`. Load at `0100h`; entry is `0100h + entry_offset`; BSS follows the image; the reserved stack is `[E000h-stack_size,E000h)` and initial SP is `E000h`. Reject overlap, zero image, stack sizes below two bytes, entry outside the image, arithmetic wrap, and any image/BSS/stack collision.

Fix native syscall numbers at: `00 SYS_EXIT`, `01 SYS_CONSOLE_WRITE`, `02 SYS_CONSOLE_READ`, `03 SYS_CONSOLE_POLL`, `04 SYS_GETINFO`. Argument blocks remain in caller addresses `0100h-1FFFh`; read/write buffers may occupy `0100h-DFFFh` and require checked common-resident copyin/copyout. `EXIT` takes `{status:u16}` and does not return; WRITE/READ take `{buffer:u16,length:u16}` and return transferred bytes in HL; POLL takes no block and returns 0/1; GETINFO writes a six-byte v1 record `{size,abi,pid,bank,flags:u16}` and returns 6. Console services use the bound normal console only.

## Requirements

- Add `include/zephyros/{process.h,zex.h}`. Implement a fixed seven-entry process table with FREE/RUNNING/SUSPENDED states, deterministic lowest-free-bank allocation, PID/parent/kernel-parent identity, saved parent SP/context/IFF, exit status, and exact rollback on every failed load. At most one process is RUNNING; bank 7 is rejected everywhere.
- Add `tools/zexpack.py` with pack/validate/dump operations. Build a program linked at `0100h`, reject content outside its declared image, produce deterministic headers/reports, and add malformed fixtures for every validation boundary.
- Implement ROMFS-backed ZEX validation and loading without a heap: allocate a bank, zero `0000h-DFFFh`, construct deterministic native page zero with exactly `JP zos_syscall_entry` at `0030h`, stream the image to `0100h`, zero BSS, and establish the stack. Do not copy CP/M vectors, FCBs, command tails, or `CALL 0005h` state.
- Add common-resident process-bank copy and launch/return gates. Mapping-changing code must use common stacks/state, mask interrupts during transitions, preserve exact parent latch/SP/IFF, and never return through hidden banked code. Launch enters mode `10|bank` with interrupts enabled, HL=0 (no startup block in v1), other registers unspecified, and a common return trap on the process stack; a raw entry return exits with `ZOS_EFAULT`.
- Make `process_exec("name", &status)` synchronous: suspend the parent/kernel launcher, validate and run one child, then restore the exact parent context and return its status. `SYS_EXIT` releases child resources and resumes the parent through the common gate; it must not take the ordinary syscall return path.
- Extend the syscall assembly/C boundary for success and failure results rather than its current unconditional `ENOSYS`/carry behavior. Keep the stable register preservation contract. Validate syscall numbers, low-window argument blocks, buffer wrap/common overlap, and all user copies. Failed operations return defined native errno without damaging process bookkeeping.
- Add `user/runtime/` assembly wrappers that expose the stable register ABI to programs without making SDCC calling conventions public. The runtime owns a bounded low-window scratch block for syscall arguments so ordinary C stacks near `E000h` never violate the argument-block rule. Build `tests/target/m6/zextest.zex`; it verifies zero BSS, stack bounds, GETINFO, normal-console output, and exits with a known status.
- Put `zextest.zex` in `recovery/manifest.json`. Add M6 target coverage for malformed ZEX files, repeated exec/exit, exact parent restoration, and the identical ZEX bytes running in bank 0 and another bank. Exercise the second bank by reserving a lower bank through the tested allocator, not by adding a user-selectable bank bypass.
- Document the packed format and entry ABI in `docs/zex-format.md`, process lifecycle in architecture implementation notes, syscall blocks in `docs/abi.md`, and physical results in a dated validation record.

## Files

- `include/zephyros/{process.h,zex.h,syscall.h}`
- `kernel/process/{process.c,exec.c,launch.asm}`
- `kernel/memory/` common copy support
- `kernel/syscall.c`, `kernel/syscall/entry.asm`
- `user/runtime/`, `tests/target/m6/`
- `tools/{zexpack.py,mapcheck.py,serial_smoke.py}`
- `recovery/manifest.json`, `Makefile`, `tests/`, `docs/`

## Constraints

- No scheduler, preemption, signals, pipes, shell, writable filesystem, dynamic linking, far memory, `.COM` loader, or CP/M structures.
- Do not expose SDCC calling conventions or private kernel symbols as native ABI.
- Keep early console kernel-only and preserve the M5 ROMFS/ZMOD boot sequence.

## Validation

```sh
make clean
make check
make zmod-test
make romfs-test
make m5-selftest
make zex-test
make m6-selftest
make m6-failure-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean
```

Flash `build-m6-selftest/zephyros-m6-selftest.bin` and run `make smoke-hardware-m6 SERIAL_PORT=...`; verify output from `zextest.zex`, known exit status, two-bank execution, repeated cycles, and parent resumption. Record the image/ZEX hashes and transcript. If hardware is unavailable, mark M6 `PENDING` and do not dispatch M7.

## Acceptance criteria

- ZEX format/tooling rejects all malformed geometry before execution and builds reproducibly.
- The same `zextest.zex` runs unchanged in two application banks with zero BSS and a non-overlapping stack.
- Native console syscalls use the dynamic console, `SYS_EXIT` restores the parent exactly, and repeated/failure paths leak no slots or banks.
- Bank 7 remains inaccessible to normal process APIs, early diagnostics remain available, and all M0-M5 validation stays green.
