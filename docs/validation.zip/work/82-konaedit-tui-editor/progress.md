# Package 82: KonaEdit TUI editor — progress

Status: SCROLL HARDWARE CORRECTION IN PROGRESS

## Contract and tree

- Contract: `work/82-konaedit-tui-editor/WORK.md`.
- Worker rules: `work/00-WORKER.md`.
- Baseline observed before implementation: `git status --short` reports only
  `?? docs/gfx-sdk.md`; it is unrelated user-owned work and must be preserved.
- Package-owned paths will be `UserSoftware/KonaEdit/`, this progress file,
  the package validation record, and the package-82 index entry already
  present in `work/README.md`.

## Verified

- The public SDK provides cookie-paged directory enumeration through
  `list()`, file operations through `open/read/write/sync/stat/unlink/rename`,
  and XMEM objects up to 32 KiB.
- The public TUI provides the logical screen, transactions, save/restore,
  normal/selected styles, decoded unmodified keys and procedural widgets.
- The input vocabulary has no modifier state and the render ABI has no
  rectangular move operation; the contract's F7 mark mode and measured
  viewport redraw are the required adaptations.
- A shell parent plus KonaEdit consume two of six process banks. Eight 8-KiB
  document objects pack into two auxiliary banks; two 16-KiB mappable
  clipboard objects occupy their aperture slots; two 32-KiB history objects
  occupy the remaining two banks. This is 12 of the 16 global XMEM records.
- Transactional Open cannot retain old document, new document and the two
  history banks simultaneously. The replacement sequence therefore discards
  undo/clipboard, allocates and fully loads a fresh eight-object document in
  the two support banks while the old document remains intact, swaps only
  after validation, frees the old document, then deterministically rebuilds
  history and clipboard in the released banks/apertures. No other task can
  race the synchronous allocator. A support-store rebuild failure is reported
  as a resource failure and exits without attempting near-RAM fallback.
- `ke_store` is present with eight 8-KiB objects, 64 logical 1-KiB pages,
  page cache, split and fragmented-store boundary propagation. Focused host
  command (2026-10-22): `cc -std=c99 -Wall -Wextra -Werror -DKE_HOST_TEST
  ... tests/test_store.c src/ke_store.c && test_store` ->
  `KonaEdit store tests: OK`. It covers exact 65,536-byte capacity,
  32,767/32,768 edits, full readback and repeated mid-page splits.
- `ke_history` allocates the two 16-KiB clipboard objects and two 32-KiB
  history objects, retains three delta records, and exercises copy/cut/paste
  plus undo/redo. `ke_text` supplies literal-TAB visual columns, logical-line
  navigation, ASCII-folded byte search and streaming CR/CRLF normalization.
  Focused host command rebuilt all three modules with `-Werror` and reports
  `KonaEdit store tests: OK`.

## Current work

- The target now compiles, links, packs and validates as
  `build/user/konaedit.exe` (43,916 bytes). The pack report records image size
  43,880, BSS 11,203, stack `DC00h-E000h` (1,024 bytes), linked end `D82Bh`
  and 981 bytes of headroom, exceeding the package's 512-byte minimum.
- The focused host executable still reports `KonaEdit store tests: OK` after
  the split-scratch removal.
- `make -C UserSoftware/KonaEdit test` completed target validation and the
  host suite, then failed because unittest discovery found zero Python tests
  (exit status 5). Class: **implementation/test coverage**, not an artifact
  or environment fault. Add project-invariant and simulator UI tests before
  repeating the package command.
- Added `README.md` and `DESIGN.md` with operation, keys, file semantics,
  XMEM layout, save state machine, measured memory budget, SDK gaps and the
  explicitly pending owner-hardware checklist.
- Added Python project checks for exact 32-bit/64-KiB limits, standalone SDK
  use, absence of terminal escapes/private includes, required documentation,
  and packed-image stack headroom. Added a focused production-image replay
  that opens an FS2 file, edits it, checks menu selection as two INVERTs with
  zero TEXT cells, saves exact bytes and returns through F10 to the shell.
- The four focused project checks pass. The first simulator run launches the
  editor but shows `Untitled` instead of loading `/fs/ALPHA.TXT` from the
  command argument. Class: **implementation or replay invocation contract**;
  inspect how KonaOS standalone programs receive their argument tail before
  changing either the app or test. No traffic assertion has run yet.
- Root cause: KonaOS passes command-tail words starting at `argv[0]`; it does
  not synthesize a program-name argument. `main.c` incorrectly used the hosted
  C convention (`argc > 1`, `argv[1]`). Corrected it to consume `argv[0]`.
- After rebuilding, the replay reaches `_tui_getkey` but the decoded display
  is blank, rather than showing the loaded file. Class: **implementation or
  replay synchronization**. Add failure diagnostics for the current PC,
  console transcript and filesystem requests to determine whether this is an
  early load dialog, exit path, or a wait on the wrong input call.
- The diagnostic rerun itself errored because the IOC simulator has no
  `fs2_requests` trace member. Class: **test artifact**. Retain PC/transcript
  diagnostics and use the peer's actual request traces if needed.
- Corrected diagnostics show PC `990Bh` (the editor's `_tui_getkey`) with no
  new serial glyph output and a blank visible page. This proves it is an
  editor input wait, but not whether it is the pre-render Open-error modal or
  main loop. Record the call-site return address, FS2 command counts and IOC
  request types on the next focused run.
- The recorded return address (`3F74h`) is not any editor `tui_getkey` call
  site, while the console trace never advances beyond the pre-command shell
  prompt. Class: **test synchronization artifact**: the replay mistook equal
  numeric PCs in the still-running shell for editor symbols. Synchronize first
  on the editor's `_main` entry (which cannot recur after the captured shell
  prompt), then accept its input loop.
- Synchronizing on `_main` alone still collides because standalone programs
  share the same logical link addresses and the shell traverses that address
  while executing the command. Class remains **test artifact**. Capture the
  shell's physical process bank at the prompt and require the `_main` match
  to occur in a different bank before recognizing KonaEdit.
- A bank-only guard also admits transient shell/kernel remaps. The unchanged
  false return address confirms the editor still was not launched when the
  test stopped. Class: **test artifact**. Match a slice of KonaEdit's packed
  `_main` bytes in mapped RAM as well as its PC; this identifies the loaded
  child independently of logical address and transient bank selection.
- The packed-code signature also matches before the bad wait, so this is now
  classified **implementation**, not synchronization: loading the path enters
  an invalid `tui_getkey` call with an impossible return address. Compare an
  otherwise identical no-argument launch to isolate file load/rendering from
  baseline startup before changing the application.
- The no-argument probe produces the identical false wait and reports physical
  bank 6, the driver bank rather than a process bank. Class returns to **test
  synchronization artifact**: bank 6 happens to contain the same byte slice
  at the shared logical address. Require a non-kernel/non-driver process bank,
  different from the shell's captured bank, in addition to the code signature.
- The tightened launch match occurs, but the later stop still lands in bank 6:
  the wait checked only the numeric getkey address after setting `entered`.
  Class: **test artifact**. Retain the physical bank observed at the verified
  KonaEdit `_main` and require `_tui_getkey` to execute in that same bank.
- With the same-bank launch wait, initial path loading is proven correct and
  `/fs/ALPHA.TXT` displays as `alpha`. The next measurement returns before
  consuming `X` because its helper repeats the numeric-PC-only mistake. Class:
  **test artifact**. Return the verified app bank from startup and apply it to
  every measured input-loop transition.
- The verified measurement now processes input: `X` appears before `alpha`.
  Moving the File popup selection emits zero TEXT cells and one render, but
  the VDP trace records three INVERT commands rather than the test's assumed
  two. Class: **test expectation** unless coordinates show unrelated damage;
  the requirement is old/new attribute-only traffic, and the renderer may
  split one logical run. Retain command blocks in evidence and accept two or
  three INVERT commands while continuing to require zero TEXT cells.
- The focused replay now passes end to end: argument-path load, visible edit,
  attribute-only menu move, exact FS2 save (`Xalpha\n`) and F10 return to the
  shell. Began closing application edge cases: ordinary same-line edits redraw
  one viewport row instead of calling the full-screen renderer; newline and
  selection edits retain the safe full redraw. Failed startup loads discard
  any partial fresh content, Save As commits the new pathname only after a
  successful safe save, and Delete/Backspace set modified state only after a
  successful edit.
- The rebuild after adding an explicit one-row render helper packs but leaves
  only 309 bytes below the stack (`DACBh` to `DC00h`), violating the package's
  512-byte acceptance floor. Class: **implementation/resource budget**. Remove
  the extra specialized renderer and retain the TUI model's existing final-
  state diff suppression (the replay already bounds ordinary typing traffic);
  keep the smaller recovery fixes and remeasure.
- After removing it, the packed image is 44,014 bytes: image 43,978, BSS
  11,203, linked end `D88Dh`, stack `DC00h-E000h`, and 883 bytes headroom.
  This restores the required margin.
- Added true transaction grouping for contiguous inserted bytes, forward
  Delete runs and reverse Backspace runs in the XMEM history arena. Selection
  replacement is also one remove+insert record instead of two edits. A host
  regression exercises grouped typing, backspace/delete undo and redo.
- The grouped implementation's target link reaches `E08Eh`, 142 bytes beyond
  even the stack top and 1,054 bytes beyond the required 512-byte headroom.
  Class: **implementation/resource budget**. The generic 32-bit grouped-edit
  path adds about 2 KiB on SDCC. Per the package's explicit budget stop rule,
  it cannot remain. Removed that attempted path and its non-accepting test;
  retained the smaller correctness improvement that selection replacement is
  one remove+insert record. Contiguous-run grouping remains an unmet Must to
  report rather than weakening the stack or hiding the overrun.
- The restored implementation packs as 44,066 bytes (image 44,030; BSS
  11,203), ends at `D8C1h`, and leaves 831 bytes below the 1,024-byte stack at
  `DC00h-E000h`. Selection replacement remains a single history record. Source
  is frozen for the package validation; the simulator prints its insert/menu
  traffic dictionaries into the validation transcript.
- The named validation commands pass on this frozen tree (SDK present; host
  executable OK; 5 Python tests OK in 41.876 s; clean rebuild hash
  `af55f8eb...`; `git diff --check` clean). However, the grouping Must remains
  unmet, so this cannot be the final accepted validation. Link-map evidence
  identifies a recovery path: using any render widget pulls the monolithic
  2,531-byte widget-render archive member, including unused checkbox/listbox.
  Package 82 already owns compound-control policy and may implement its five
  small render helpers over public `tui.h`, potentially funding grouping
  without SDK/ABI changes. This remains within the WORK.md instruction to
  compose controls from public primitives.
- Package-local status/menu/button/label/input render helpers now replace that
  all-or-nothing archive member. They use only public `tui.h`; the executable
  falls from 44,066 to 41,697 bytes, and headroom grows from 831 to 3,200
  bytes (`CF80h` to `DC00h`). This frees enough budget to restore the tested
  grouped-history path without weakening the stack.
- The first focused grouped-history compile did not run because the preceding
  formal `make clean` removed `build/tests`; the linker reports “No such file
  or directory” for its output path. Class: **test invocation artifact**, not
  source. Recreate the generated test directory and repeat the same focused
  command.
- After recreating the generated directory, the grouping regression passes.
  The target with local render helpers plus grouped history packs as 43,714
  bytes (image 43,678; BSS 11,204), ends at `D762h`, and leaves 1,182 bytes
  below the `DC00h-E000h` stack. The prior generic grouping feature is now
  retained with more margin than the original implementation.
- The production-image replay passes with local render helpers. Insert traffic
  is render lengths `[94, 33]`, zero counted TEXT cells and 581,562 cycles;
  the menu move remains one 90-byte render, zero TEXT cells, three INVERTs and
  68,851 cycles. Exact FS2 save and F10 shell return still pass.
- Before source freeze, two small named Musts remain visible in review: a
  successful save whose obsolete recovery file cannot be removed must warn
  with that path, and `match_case` must be user-selectable. Also replace the
  too-small-grid direct console call with a public-TUI error path.
- Owner hardware correction (2026-10-23): ordinary editing takes roughly
  0.75-1.0 s per key; filename entry and file-list selection are also very
  slow; directory `/` suffixes leak into the editor background; and the list
  cannot advance beyond its first eight entries. Target is <=0.1 s per edit.
- Root causes from source plus the hardware screenshot: every typed byte still
  issues an XMEM history write, then calls `render_all`, which walks every
  visible row and repeatedly scans line/column state. The file-dialog loop
  redraws its complete frame, path, eight-row list, input and buttons before
  every key wait. Its container suffix uses unpositioned `tui_putc('/')`, and
  Down on the last visible entry does not advance to the next cookie page.
  These are **implementation** defects; the physical observation is the
  acceptance source.

## Hardware correction result

- File-dialog correction implemented: container suffixes now use explicit
  coordinates; Down at the last visible row advances to the next cookie page,
  Up at its first row returns to the previous page, and Page Up/Down remain
  available. A zero-entry probe after an exact eight-entry final page restores
  the prior page instead of exposing an empty list.
- Selection changes now repaint only the old/new directory rows, and filename
  typing repaints only the input field. Full dialog redraws remain for actual
  page/path/focus changes.
- Ordinary same-line insert, TAB, Delete and Backspace now repaint only the
  affected document row plus status/caret. Newline and multi-line selection
  changes retain the full viewport path.
- The first correction link exceeded the fixed stack base by 150 bytes
  (`DC96h` versus `DC00h`). Class: **implementation/resource budget**. The
  staged-history implementation was compacted to a direct 20-byte buffer and
  the keyboard dialog narrowed from 60 to 48 columns without reducing any
  field or path capacity; the next link fit but had only 59 bytes of headroom,
  below the package's required 512 bytes, so it is not acceptable yet.
- A size-reduction compile then hit an SDCC optimizer diagnostic because a
  one-byte initial stage was immediately tested for being 20 bytes. Class:
  **toolchain-sensitive source expression**; remove the provably unreachable
  test before retrying.
- Final focused package validation passes. The host regression proves that 25
  consecutive typed characters issue one history XMEM write while typing and
  one tail flush on Undo. The simulator measures an ordinary insert at 98,801
  cycles (down from 581,562), a file-list move at 84,084 cycles, and a filename
  key at 41,799 cycles. It also crosses the eighth-entry cookie boundary and
  verifies that the editor row remains exactly `Xalpha` with no leaked `/`.
- The packed executable is 44,766 bytes (44,730-byte image, 10,792-byte BSS),
  ends at `D9E2h`, retains the 1,024-byte `DC00h-E000h` stack and has 542 bytes
  of required headroom. SHA-256 is
  `108cf00b61f7aea4ccbc3331dde2c32c91f17503f8e80793c9fa92f5afcd232a`.

## Next action

- Owner hardware retest reports that typing improved but remains above the
  required 0.1 seconds per key, with Enter/new-line insertion particularly
  slow. This supersedes simulator-only timing acceptance for those paths.
- The first newline baseline replay stopped before reporting traffic because
  its assertion searched for adjacent `X\nalpha` in fixed-width screen rows;
  the screen correctly contains `X` and `alpha` on consecutive padded rows.
  Class: **test artifact** against the replay's existing fixed-grid screen
  representation. Change the assertion to row-prefix checks before repeating
  the same baseline.
- Corrected baseline: a printable insert is 98,801 simulator cycles, newline
  insertion is 584,764 cycles and deleting that newline is 593,906 cycles.
  Each structural edit emits two RENDER requests (`[101, 50]`) because
  `render_all` also clears/redraws the menu and status. Class: **implementation**
  against the hardware target and the work contract's affected-suffix rule.
- XMEM allocation inspection explains the Open exit: eight independent 8-KiB
  document allocations can consume the four-slot runs released by the two
  32-KiB history objects while a transactional fresh document coexists with
  the old one. After the old document is released, no four-slot run is
  guaranteed for history rebuild, and `replace_document` treats that rebuild
  failure as fatal. Use four 16-KiB document objects instead: the same 64-KiB
  capacity, but paired allocations fill complete four-slot data slices, so
  the old document's two slices remain available for the two history objects
  after commit.
- The first affected-tail implementation compiles but links to `DC85h`, 133
  bytes into the stack and 646 bytes above the required 512-byte headroom.
  Class: **implementation/resource budget**. Replace the document-walking
  structural tail with the public TUI's window-scoped insert/delete-line
  primitives plus two local suffix rows, and right-size the saved dialog/menu
  rectangles before retrying; the stack remains 1,024 bytes.
- The window-scoped line-shift version links and packs, but ends at `DB57h`,
  leaving only 169 bytes below `DC00h`; class remains
  **implementation/resource budget**. Right-size the still-generous overlay
  and prompt buffers (37-column compound dialogs, 18-column popups, 95-byte
  find/replace values) to recover more than the missing 343 bytes without
  lowering the stack or document/path capacity.
- With right-sized overlays the build ends at `D9D6h` (554-byte headroom),
  and ordinary insert falls slightly to 96,812 cycles. Window-scoped
  insert/delete-line still costs 398,238/406,788 cycles because the TUI shifts
  the complete viewport cell map. Class: **implementation/performance**. The
  earlier document-tail loop costs only 39 more linked bytes than this version
  after normalizing BSS; restore it so a short document redraws only its two
  content rows plus one clearing row. Narrowing the dialog by one additional
  column preserves the 512-byte headroom requirement.
- The typed-filename Open replay succeeds with the proposed four-object
  document geometry, but review against `WORK.md` and `test_project.py` shows
  that the document's eight 8-KiB objects are a Must, not an implementation
  choice. Class: **implementation**; do not change that accepted pin. The
  allocator can instead be made deterministic by allocating history before
  the startup document: history occupies two complete four-slot slices, the
  document fills around them, and each transactional Open alternates the two
  slice pairs without fragmentation. Revert the document constants and test
  the same actual Open path.
- Owner also reports that activating Open from the file browser exits the
  program instead of opening the file. The current success path treats failure
  to rebuild history/clipboard after replacing the document as fatal. Reproduce
  and inspect XMEM allocation/slot ordering; Open must keep the editor alive
  even if optional undo/clipboard support cannot be rebuilt.
- Profile the exact TUI render records and VDP commands for a printable key and
  Enter. Replace the full-viewport newline path with the smallest affected-row
  update, and remove avoidable per-key status/cursor work while preserving
  visible caret and document state. Revalidate only correction-specific tests.

## Second hardware correction result

- Newline insertion and removal now repaint only the affected document tail,
  stopping after the first clearing row or at the viewport boundary. Same-line
  edits still repaint only their changed suffix. Cursor visibility is computed
  once per key and the resulting line/column are reused by the status and caret
  paths. Full viewport redraw remains reserved for actual scroll and selection
  changes.
- The final production-image replay measures 96,811 cycles for an ordinary
  insertion, 124,870 for Enter, and 125,367 for Backspace across that newline.
  Each structural edit emits one console render rather than the prior two and
  is below the correction-specific 150,000-cycle regression ceiling. Enter is
  78.6% below its 584,764-cycle baseline; newline removal is 78.9% below its
  593,906-cycle baseline.
- The Open failure was reproduced through the real file dialog. Its cause was
  XMEM fragmentation during the transactional replacement: rebuilding the two
  four-slot history objects was not guaranteed after allocating eight separate
  document objects beside the live document. Changing the mandated eight-object
  document geometry was rejected against `WORK.md` and reverted.
- Startup now initializes the complete support store (two 16-KiB clipboard
  objects followed by two 32-KiB history objects) before the eight document
  objects. The required four-slot history runs are therefore secured before
  the independent document allocations can fragment free space, and the later
  Open dispose/allocate/rebuild sequence is deterministic. The replay types
  `PAGE00.TXT`, activates the actual Open button, verifies `page` in the editor,
  and then returns to the shell with F10. The process no longer exits on a
  successful Open.
- The final link packs a 45,412-byte image with 10,108 bytes of BSS, ends at
  `D9E0h`, preserves the 1,024-byte stack at `DC00h-E000h`, and leaves 544
  bytes of headroom. SHA-256 is
  `c2ab12d025de3968072c159cd32963fe03a8455d2b6919b4d8b85ba76c43517f`.

## Next action

- Final focused validation passed: `make -C UserSoftware/KonaEdit test` reports
  the host store/history suite OK and all five Python tests OK in 75.490 s.
  The production-image replay passed the enforced ordinary/newline/file-control
  cycle limits, opened `PAGE00.TXT` through the dialog without exiting, and
  returned to the shell. No OS-wide or unchanged TUI suite was rerun.
- The first validation-record rewrite did not apply because the patch helper
  rejects delete-and-add operations targeting the same path in one patch.
  Class: **editing/tool invocation artifact**; the existing record remained
  intact. Retrying as separate delete and add operations succeeded.
- Package work is complete. The remaining acceptance action is the owner's
  hardware retest of the <=0.1-second ordinary/newline paths and successful
  Open behavior.

## Third hardware report

- Owner hardware reports that launching KonaEdit with
  `/fs/cpm/b/dev/modula-2/list.mod`, which exists, shows the startup Open-failed
  dialog and leaves an empty document. This is the initial command-line load
  path, not the already-corrected in-application Open transaction.
- Initial inspection finds no application path-length issue: the supplied path
  is below the shared 128-byte `KOS_PATH_MAX`, and every component fits the
  filesystem limits. The startup error is currently generic, hiding whether
  `open`, `read`, NUL rejection, the 64-KiB capacity, or document XMEM insertion
  failed. Reproduce the exact nested path in the production-image simulator and
  retain the specific load result for a useful error message.
- The matching 3,840-byte `LIST.MOD` in the companion Zephyr-80 source tree
  identifies the failure exactly. Its real text ends at offset 3,695, followed
  by fifteen CP/M `1Ah` EOF/padding bytes; the rest of the 128-byte record
  contains NULs and directory-entry debris. KonaEdit ignored CP/M EOF, reached
  the later NUL and correctly—but misleadingly—classified the whole input as
  binary. Class: **implementation/text compatibility**.
- The streaming normalizer now treats the first `1Ah` as logical EOF and never
  examines later record padding. A NUL before logical EOF remains a hard binary
  rejection, and saves remain CP850 bytes with Unix LF and no appended CP/M
  marker. Host coverage includes CR immediately before `1Ah`, repeated padding,
  a later NUL and debris. The production replay launches the exact nested path
  after a prior editor session and verifies the expected two text lines.
- The first compatible build packs successfully but ends at `DA04h`, leaving
  508 bytes below the fixed stack—four bytes short of the package's 512-byte
  minimum. Class: **implementation/resource budget**. Return the EOF indication
  directly from the normalizer instead of storing another state byte and
  testing it in the loader; this preserves streaming semantics while removing
  state/init code before retrying.
- Returning EOF directly made SDCC generate a larger 16-bit result path: the
  retry ends at `DA29h`, worse than the one-byte state version. Class:
  **implementation/toolchain size behavior**. Restore the smaller state form
  and right-size the status formatting buffer from 96 to 88 bytes; the display
  is only 85 columns wide, so this removes no visible capacity and should leave
  516 bytes of headroom.
- The first host run after adding CP/M coverage failed the existing line-start
  assertion because the new normalizer check reused and overwrote the shared
  `normalized` test buffer before the original bytes were inserted. Class:
  **test-order artifact**, not implementation. Move the CP/M check after the
  original navigation assertions and repeat the focused suite.
- The first final-record patch did not apply because one context line in the
  validation document did not match exactly. Class: **editing/context
  artifact**; no file was partially changed. Apply smaller, independently
  anchored updates.
- Final focused validation passes. `make -C UserSoftware/KonaEdit test`
  reports the host suite OK and all five Python tests OK in 94.719 seconds.
  The production replay retains the prior edit/Open regressions, then starts a
  second editor with the exact `/fs/cpm/b/dev/modula-2/list.mod` path containing
  `1Ah` padding, NULs and trailing debris; it verifies the two expected lines
  and returns to the shell.
- The final executable is 45,484 bytes (45,448-byte image, 10,100-byte BSS),
  ends at `D9FCh`, preserves the 1,024-byte `DC00h-E000h` stack, and leaves 516
  bytes of headroom. SHA-256 is
  `defca465b912dc6cba219b3f221c78db3e2d91e6708fafe1d20ddff2bd5677cd`.

## Scroll hardware report

- Owner hardware reports roughly three seconds for one-line vertical scrolling
  once the cursor reaches the bottom of the `LIST.MOD` viewport, with a new
  target of at most 0.2 seconds.
- Source inspection confirms that a one-line viewport transition calls
  `render_viewport`, converting all 24 document rows into glyph updates. The
  public `tui_insert_line`/`tui_delete_line` functions also copy the logical
  cell map through ordinary dirty cells, so their current V9958 flush still
  redraws the shifted rows and cannot solve the physical cost.
- Implement a semantic full-width scroll-region render record. On V9958, shift
  the circular bitmap origin by one cell row through R#23, restore rows outside
  the document region with overlap-safe HMMM copies, and clear the newly exposed
  row. Libtui will shift its logical map without dirtying the moved rows and
  emit only that scroll record plus actual edits. KonaEdit will use it for
  single-line viewport transitions and render only the newly exposed document
  row, status, and caret; page jumps and horizontal movement retain full redraw.
- The first combined driver patch did not apply because the V9958 private
  prototypes are not located at the assumed context in `v9958_driver.h`.
  Class: **editing/context artifact**; ABI and libtui edits remain intact, and
  no driver file was partially changed. Locate the actual prototype block and
  apply the driver pieces with narrower anchors.
- Root `make -j2 all sdk` succeeds with the new ABI, V9958 implementation and
  initial transparent line-operation integration. Relinking KonaEdit then ends
  at `DDB3h`, colliding with its `DC00h` stack. Class:
  **implementation/resource budget**. The generic pending-scroll machinery in
  the already-large window/flush members is too expensive for this constrained
  consumer. Replace it with a small opt-in `tui_scroll_rows` archive member:
  flush pending state, submit one scroll record synchronously, then shift the
  clean logical map. Existing insert/delete-line behavior and fallback remain
  unchanged; KonaEdit can fall back to full repaint if the primitive is not
  supported.
- Supervisor (2026-10-23): typing (~0.5 s/char) and scrolling grew with the
  cursor's position: `line_number` counted newlines from byte 0 through
  `ke_store_byte` (~1,500 T-states/byte) on every key. Owner confirmed on the
  board that typing near the top of the file is faster. Fix: line numbers are
  counted from the viewport (`viewport_top`/`viewport_line`) with
  `ke_store_count` (chunked `ke_store_read`); the store keeps `low_edit`, the
  lowest changed position, and an edit before `viewport_top` triggers one
  recount from 0. The fix cost 542 bytes and broke the 512-byte headroom test.
  The status line's single `snprintf` pulled in printf, itoa, ltoa, utoa and
  ultoa; a local formatter replaces it (a long name is cut so the
  Ln/Col/mode tail stays visible). Image 46,442 -> 44,025 bytes, BSS end
  D138h, headroom 2,760. `make -C UserSoftware/KonaEdit test`: 6 tests OK.
  Board timing of scroll and typing is pending.
