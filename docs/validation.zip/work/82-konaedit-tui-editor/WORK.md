> Worker package. Runs after package 81. Standalone user application and
> application tests only: no nucleus, driver, console ABI, libtui or SDK
> implementation change. Preserve the unrelated untracked `docs/gfx-sdk.md`.

# Task

Build `UserSoftware/KonaEdit`, a useful CP850 text editor in the style of
MS-DOS Edit/QBasic and a sustained stress test of the public KonaOS TUI and
XMEM SDK. The application builds only from the packaged standalone SDK and
produces `build/user/konaedit.exe`.

Read `work/00-WORKER.md`, `docs/tui.md`, `docs/sdk.md`,
`docs/filesystem.md`, `docs/memory.md`, the public SDK headers, and
`UserSoftware/KonaCommander` as the standalone-application and TUI replay
reference. Do not include OS-tree-private headers or copy private TUI state.

# Product contract

## Document and file semantics

- One document is open at a time. With no argument the editor starts an
  unnamed empty document; one path argument opens that file.
- Document bytes are CP850. There is no UTF-8 detection or conversion and no
  binary mode. Reject an input containing NUL with a clear error without
  replacing the current document.
- The exact maximum document length is 65,536 bytes. Every document offset,
  length, line number and visual column used by the application is at least
  32 bits; no `uint16_t` wrap at 65,535 is permitted.
- There is no line-length limit. A 65,536-byte single line is valid and is
  navigated with horizontal scrolling.
- TAB is stored as the literal byte `09h`. Display uses tab stops every eight
  visual columns; cursor motion crosses one TAB byte atomically while the
  status bar reports its visual column. Saving never expands tabs.
- The in-memory line separator is LF. Load normalizes CRLF and bare CR to LF;
  save writes LF and does not force a final newline.
- File I/O is streamed through a bounded near-memory buffer. Never stage the
  whole file in primary RAM. A load failure, oversized normalized document,
  NUL byte or XMEM error leaves the old document and its modified state
  intact.
- Save through a same-directory, exclusive temporary 8.3 name: write all
  bytes, `sync`, close, then install it. When replacing a file, first rename
  the old name to a unique recovery name, install the temporary, and remove
  the recovery name; roll back the old name if installation fails. Report a
  retained temporary/recovery path when cleanup cannot complete. Never
  truncate the only good copy first.

## XMEM document model

- XMEM backing is mandatory from startup, including an empty document. The
  document store contains 64 fixed 1,024-byte logical pages backed by eight
  8-KiB runtime XMEM objects. Keep only bounded page cache(s), page order,
  lengths and navigation indexes in primary RAM.
- Implement insertion/deletion with per-page occupancy, split/rebalance and a
  dirty page cache. Ordinary edits near the cursor must not shift the whole
  64-KiB document or issue one XMEM syscall per cursor key.
- Use a separate 64-KiB XMEM history arena (two 32-KiB objects) for at most
  three undo transactions and their redo state. Contiguous typing and
  contiguous backspace/delete runs are one transaction; cut, paste and one
  replacement are each one transaction. Drop the oldest record when the
  arena cannot retain all three, but never corrupt the document. The status
  line must say when an operation cannot be retained for undo.
- The clipboard is XMEM-backed, survives document edits, and holds at least
  32 KiB. Copy/cut over that limit is refused before changing the document.
  The implementation may use two 16-KiB mappable objects so the document,
  clipboard and history pack into the four auxiliary banks available to an
  editor launched by the shell. Access remains through public XMEM calls;
  mapping is optional.
- Allocate all required stores before replacing the current document and
  unwind every partial allocation. An allocation failure is a recoverable
  error dialog, not a crash or a fallback to a near-RAM document.

## Editing and navigation

- Printable CP850 bytes insert or overwrite according to the current mode;
  Enter inserts LF, TAB inserts a literal TAB, Backspace/Delete edit, and
  Insert toggles insert/overwrite.
- Arrows, Home/End and PageUp/PageDown navigate the document. Home/End use the
  logical line, not the visible slice. Keep the caret visible by vertical and
  horizontal scrolling. The visible hardware/TUI cursor is the caret.
- F7 starts or clears keyboard mark mode. Navigation extends the selection;
  Escape clears it. Selected visible text uses `TUI_STYLE_SELECTED`. Cut,
  Copy, Paste, Delete and Select All work through the Edit menu; F8 copies and
  F9 pastes. This mark mode is the required replacement for unavailable
  Shift+navigation events.
- Find is literal CP850 text with an optional ASCII-only case-fold checkbox.
  Provide Find, Find Next and Replace-current; search wraps only after a
  confirmation. Search and replacement fields are bounded to 127 bytes.
  There is no Replace All.
- Three-level Undo and Redo are available from the Edit menu. New edits after
  Undo discard the redo branch.

## TUI and commands

- Full-screen layout: top menu bar, text viewport, and bottom status/help
  line. The status shows path or `Untitled`, modified marker, logical line,
  visual column, Insert/Overwrite, and Mark when active. Query geometry with
  `tui_get_size`; support every grid accepted by the selected `TUI_GRID` and
  refuse a grid too small for the editor with a useful message.
- F1 focuses the menu bar. Left/Right selects File, Edit, Search or Help;
  Down/Enter opens its drop-down; Up/Down moves within it; Enter activates;
  Escape returns one level. No Alt mnemonic is specified or accepted.
- On the main text viewport TAB inserts `09h`. In a dialog, TAB cycles its
  input, list and buttons. Only the focused control is highlighted; an
  enabled but unfocused button remains normal.
- Shortcuts: F2 Save, F3 Open, F4 Find, F5 Find Next, F7 Mark, F8 Copy, F9
  Paste and F10 Exit. Every operation remains reachable through a menu.
- File contains New, Open, Save, Save As and Exit. Edit contains Undo, Redo,
  Cut, Copy, Paste, Delete and Select All. Search contains Find, Find Next,
  Replace and Go To Line. Help contains Keys and About. Disable commands that
  cannot currently act.
- New/Open/Exit and any replacement of the document confirm Save/Discard/
  Cancel when modified. A failed or cancelled save cancels the destructive
  action.
- Open and Save As use one QBasic-style keyboard dialog: current path, paged
  entry list, filename field, parent navigation, action button and Cancel.
  Enumerate with the public `list()` cookie API; do not retain an entire
  directory or assume it fits RAM. Paths obey `KOS_PATH_MAX`; `/fs` is the
  initial directory and `/system` may be opened read-only. Save As confirms
  replacement.
- Compose drop-downs and compound dialogs from public TUI primitives,
  `tui_save`/`tui_restore`, and caller-owned state. Redraw only the editor
  cells covered by an overlay if its save area does not fit. Emit no terminal
  sequence and call no console function directly.

## Deliberate omissions

No mouse, split view, multiple documents, printing, binary/hex mode, syntax
colouring, configurable colours or tab width, CRLF-preservation mode,
wildcard multi-file operation, macros, external compiler integration, or
more than three retained undo transactions. Help is a compact keys/about
dialog, not an indexed help system.

# TUI stress requirements

- Every user action is one outer `tui_begin`/`tui_end` update. Do not clear or
  repaint the full screen for caret motion, focus changes, menu selection,
  ordinary single-line edits or selection changes.
- Caret motion wholly inside the visible slice changes only cursor state.
  Overwrite of one ordinary character changes one text cell. A menu-item move
  changes the old and new attributes through INVERT records and retransmits
  no glyphs. Insert/delete redraw only the affected visible line suffix.
- Opening/restoring a menu or dialog may touch its rectangle only. Vertical
  or horizontal viewport scrolling may redraw the viewport because the
  current render ABI has no region-move record; record its cells, render
  transactions and simulated cycles as an Informational stress result.
- Add a simulator traffic test, modeled on KonaCommander's focused replay,
  that asserts the structural bounds above from console RENDER records and
  verifies final screen contents. Compare one editor menu move with the same
  KonaCommander menu move in the same built OS image; editor Must use zero
  TEXT cells and Should take no more than 125% of its simulated cycles.

# Tests and evidence

Host/model tests must cover:

- empty, 65,535-byte and 65,536-byte documents; rejection of byte 65,537;
- one 65,536-byte line, page-boundary insert/delete/rebalance, edits at byte
  32,767/32,768, and XMEM read/write chunk boundaries;
- literal TAB storage and visual columns on several starting columns;
- CR, CRLF and LF normalization, LF save, NUL rejection and CP850 high bytes;
- three undo/redo levels, edit grouping, redo invalidation, clipboard limit,
  and allocation/I/O failure rollback;
- find across page boundaries, case option, wrap confirmation and replace;
- safe-save success and every failure point, including recovery-name rollback.

The simulator replay must cover:

- start empty and with a path; typing, insert/overwrite, long-line horizontal
  scroll, page scroll, mark/copy/cut/paste, undo/redo and find/replace;
- F1 menu navigation, disabled items, focus-only highlighting, every dialog
  Tab stop, Escape cancellation and modified-document confirmations;
- paged `list()` navigation, Open, Save, Save As, overwrite confirmation and
  the resulting exact file bytes in the FS2 peer;
- return to the shell through F10 with TUI state restored;
- the traffic assertions in the stress requirements.

Add `README.md` with build/run/keys/file-format/resource limits and an owner
hardware checklist. Add `DESIGN.md` with the XMEM page/cache layout, 32-bit
position rules, undo/clipboard allocation, save state machine and measured
primary/XMEM memory budgets. Tests must verify the executable ends below its
stack base and uses only the standalone SDK/public headers.

# SDK gaps exposed by this package

These are findings, not authorization to change the SDK in this package:

1. `tui_key_t` has no modifier bits and the HID path exposes translated text,
   so conventional Shift+Arrow selection and Ctrl/Alt command chords cannot
   be expressed portably. KonaEdit uses F7 mark mode and F1 menus.
2. The widget library has a menu bar but no drop-down/popup-menu widget and no
   generic compound-modal/form runner. KonaEdit must own that policy and its
   overlay buffer.
3. `tui_listbox` requires a resident array of every string; it has no
   provider/virtual-list form. The file dialog must render a visible page
   over `list()` cookies instead of using it for an unbounded directory.
4. The TUI/render protocol has no rectangular cell move or scroll-region
   operation. Viewport scrolls therefore redraw glyphs instead of using a
   V9958 LMMM move (or an ANSI scroll fallback), which may be the dominant
   editor latency.
5. There is no multiline editor/document widget, clipboard or undo service.
   Those properly remain application data structures, but substantially
   increase this application's scope.

Directory enumeration is **not** a gap: `list()` already provides bounded,
cookie-paged namespace enumeration. Normal/reverse selection is also not a
gap: semantic selected style and INVERT rendering already provide it.

# Acceptance

- All product, storage, editing, UI, safety and test requirements above are
  **Must** except the explicitly marked menu-cycle comparison (**Should**) and
  viewport-scroll measurements (**Informational**).
- `konaedit.exe` fits below its declared stack with at least 512 bytes of
  measured headroom. Stop and report if it does not; do not lower the stack
  below 768 bytes merely to make the image link.
- Record executable image/BSS/stack figures; primary static storage by
  subsystem; allocated XMEM objects/slots/banks at startup; and simulator
  traffic/cycles for caret, overwrite, menu move, insert, vertical scroll and
  horizontal scroll.
- Hardware is not inferred from simulation. Record the checklist as PENDING
  unless it is actually run: edit/save/reopen CP850 and TAB text; a 64-KiB
  file; a one-line file wider than the screen; all menus/dialogs; three
  undo/redos; scroll both axes; and subjective key-to-screen responsiveness.

# Validation

This is a standalone user-mode consumer. Do not rerun the full OS `make
check` or the existing TUI suite: their accepted results are inputs, and this
package changes neither. Build the current SDK archive if it is absent, then
run only the new consumer's validation:

```sh
make sdk
make -C UserSoftware/KonaEdit test
make -C UserSoftware/KonaEdit clean
make -C UserSoftware/KonaEdit
git diff --check
```

Record `docs/validation/<date>-konaedit-tui-editor.md`, including the exact
commands/counts, stress figures, resource budgets, warnings/skips, physical
status, and confirmation that unrelated changes were preserved.
