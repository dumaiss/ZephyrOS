> Worker package. Independent; runs before 91/92. ABI, the IOC-FAT
> driver, the SDK wrapper, docs and tests. No firmware change: the
> SD firmware already has FS2 `TRUNCATE` (40h).

# Task

Truncate an open file to a given length: a new FILE operation, served by
the IOC-FAT provider over FS2 `TRUNCATE`, with an SDK wrapper
`truncate(handle, length)`. KRES compaction (packages 91/92) needs it to
give disk space back.

## Current state

- **FILE operations:** `abi/kos/protocol.h` numbers them `KFILE_OP_READ`
  0 .. `KFILE_OP_PHASES` 5. The provider dispatch is the `switch
  (frame->op)` in `drivers/iocfat/iocfat.c`; `iocfat_sync_op` is the
  model for a small operation.
- **FS2 TRUNCATE (40h):** request = token (2 bytes) + new size (4 bytes,
  `FS2_OFF_TRUNC_SIZE`). `iocfat.c` already sends it for a truncating
  open (`FS2_OPENF_TRUNC`: `iocfat_put16`/`iocfat_put32`,
  `iocfat_exchange(FS2_CMD_TRUNCATE, 6u)`, `iocfat_map_status`). The
  simulated firmware handles it: `IocCommandPeer._fs2_truncate` in
  `tests/z80sim.py` shrinks the file and refuses a read-only token.
- **The read cache** (`iocfat_cache.asm`, `docs/filesystem.md` "a read
  hit is served locally") keeps aligned blocks per FS2 file. A truncate
  must not leave stale bytes past the new end.
- **The doc says** "Truncation is `KFS_O_TRUNC` at open; there is no
  truncate-to-size" (`docs/filesystem.md`). That changes here.
- **SDK wrappers** live in `user/sdk/src/fs.c` (`sync` is the pattern);
  prototypes in `user/sdk/include/kos/fs.h`.

Read: `work/00-WORKER.md`; `docs/filesystem.md`; `drivers/iocfat/iocfat.c`
(open, sync, seek, the cache invalidation calls); `tests/test_iocfat.py`.

## Requirements

1. **ABI** (Must). `KFILE_OP_TRUNCATE` (6) in `abi/kos/protocol.h`:
   - `payload[1..4]` holds the new length, unsigned 32-bit;
   - returns 0, or a negative errno;
   - the comment block lists it with the other FILE operations.
2. **IOC-FAT** (Must). `iocfat_truncate_op`:
   - **Refused** (`-KOS_EINVAL`): a handle that isn't a writable file;
   - **No-op**: a length at or past the current size returns 0 without
     any FS2 traffic (FatFs truncation only shrinks);
   - **Otherwise:** FS2 `TRUNCATE` with the token and the length, mapped
     through `iocfat_map_status`;
   - **Cache:** the file's cached blocks are invalidated (all of them,
     if partial invalidation costs more code);
   - **Position:** if it was past the new length, it becomes the new
     length.
3. **Other providers** (Must): the ROMFS/system provider refuses the
   operation with the error it already uses for a write to a read-only
   file.
4. **SDK** (Must). `int truncate(unsigned int handle, unsigned long
   length);` in `kos/fs.h`, in its own libkos member, so programs that
   don't call it don't link it.
5. **Docs** (Must):
   - `docs/filesystem.md`: the operation, its no-op rule, and the
     invalidation. Drop "there is no truncate-to-size".
   - `docs/sdk.md`: the wrapper.
   - `docs/abi.md`, if it lists FILE operations.

## Tests

In `tests/test_iocfat.py`, or a new `tests/test_truncate.py`, a
production-image replay driving a small test program (add a mode to an
existing filesystem test program rather than a new program, if one
fits):

- **Shrink:** write 3,000 bytes, truncate to 1,000. `stat` reports 1,000,
  the first 1,000 bytes read back intact, and a read at 1,000 is EOF.
- **Stale cache:** read at 1,500 (cached), truncate to 1,000, read at
  1,500: EOF, not the stale bytes.
- **No-op:** a truncate to the current size or beyond returns 0 and sends
  no FS2 `TRUNCATE` (count the IOC requests).
- **Read-only handle:** refused; the file is unchanged.
- **Position:** after a truncate below the position, `seek(h, 0, CUR)`
  returns the new length.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free (`test_iocfat` ledger) | measure | <= 96 bytes | report |
| reserve (1,536, kept for the mouse/controller drivers) | held | held | stop and report |

Put the operation in the driver's cold/IO segment if the dispatch
allows; record where it went and what it cost.

## Criteria

- **Must:** requirements 1-5; the tests pass; the reserve is held.
- **Informational:** the driver's hot/cold bytes before and after, and
  the size of the `truncate` member.

## Owner checklist

- On the board: write a file, truncate it from a test program, and check
  its size from the shell (`dir`) and on a PC.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk
python3 -m unittest tests.test_iocfat tests.test_truncate tests.test_sdk tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-file-truncate.md`.
