# Package 90: file-truncate

## Contract

`work/90-file-truncate/WORK.md` — KFILE_OP_TRUNCATE (6), the IOC-FAT
op over FS2 TRUNCATE (40h), the SDK `truncate(handle, length)` member,
docs, tests.

## Status

- [x] read the named files (protocol.h, iocfat.c, fs.c, fs.h,
      filesystem.md, test_iocfat.py, z80sim peer, abi.md, exe.mk)
- [x] ABI: KFILE_OP_TRUNCATE in abi/kos/protocol.h
- [x] IOC-FAT: iocfat_truncate_op (refusals, no-op, FS2, cache,
      position)
- [x] Other providers refuse (ROMFS/system)
- [x] SDK: truncate() member + kos/fs.h
- [x] docs (filesystem.md, sdk.md; abi.md lists no FILE ops)
- [x] tests (shrink, stale cache, no-op, read-only, position)
- [x] validation batch + record

## What was done

- ABI: `KFILE_OP_TRUNCATE` (6) in abi/kos/protocol.h — `payload[1..4]`
  is the little-endian unsigned 32-bit new length; returns 0 or a
  negative errno; a read-only provider answers `KOS_EROFS`.
- The IOC-FAT op lives in `drivers/iocfat/iocfat_trunc.asm`
  (hand-written: the compiled form cost several times as much and the
  operation must fit the driver hot budget).  `_iocfat_truncate_op`
  validates the handle (object, generation, write flag, writable
  card), applies the no-op rule (a length at or past the size sends
  nothing), builds the FS2 TRUNCATE request (token + length), checks
  the exchange and its status, drops the whole cache, stores the size
  and clamps a position past the new end to it.  `_iocfat_write_note`
  extends the recorded size when a write ends past it, so the no-op
  rule sees the current size.  Eight driver symbols were un-staticed
  so the asm can reference them (`iocfat_file_get`,
  `iocfat_file_generation`, `iocfat_exchange`, `iocfat_map_status`,
  `iocfat_cache_drop_all`, `iocfat`, `iocfat_request`, `iocfat_reply`).
- The kernel's FILE gate in kernel/vfs/fs.c now forwards
  `KFILE_OP_TRUNCATE` like the other FILE operations; before that the
  op was refused before the driver saw it.
- `user/sdk/src/ipc.c` `call()` returns the syscall's primary result
  instead of the reply status: an early kernel refusal never reaches
  the frame, so the old form returned a stale zero and `truncate()`
  reported success on refusals.
- SDK: `user/sdk/src/truncate.c` (its own libkos member),
  `user/sdk/include/kos/fs.h`, `user/sdk/exe.mk`.
- kernel/vfs/system.c: `KFILE_OP_TRUNCATE` answers `-KOS_EROFS` (the
  ROMFS/system provider).
- Tests: `tests/fs/fs_selftest.c` `truncate` tail (13 checks: open,
  write 3,000, cached read at 1,500, shrink to 1,000, EOF, stat,
  first 1,000 intact, end of file, two no-ops, position clamp,
  read-only handle, unchanged file, read-only `/system` refusal) and
  `tests/test_truncate.py` (HwtestReplay: all 13 check lines, the
  summary, the shell prompt, and the FS2 request log pins — exactly
  one TRUNCATE after the shrink, exactly two after the position
  clamp, so the no-ops sent none).
- Docs: docs/filesystem.md (truncation rule, FILE-op table row),
  docs/sdk.md (layout row, 6.2 signature, what-links-what row).
- tests/test_source_layout.py: `user/sdk/src/truncate.c` in
  OWNER_FILES, `iocfat_trunc.asm` in the iocfat directory list.

## Debugging notes

The package reads as wiring (one op, one SDK member, tests), but the
96-byte hot-budget forced the op out of C: the compiled form needed two
32-bit compares (length vs size for the no-op rule, position vs the new
size for the clamp) and a 32-bit copy around the FS2 calls, costing
+343 bytes and driving the reserve below 1,536 (1,429 free).  The
bulk tier cannot help (boot-only), so the op is hand assembly -
`iocfat_trunc.asm`, 176 bytes, net +235, reserve held with 1,538
free.

The asm was debugged in a fragment harness (the module in bank 6 of
tests/z80sim.py, stubbed exchange/status/cache-drop, a synthetic file
slot and IPC frame in DRIVER_IO).  The bugs, by class:

- Register state (2): `tr_open` left DE = file+1 after the flags
  check, shifting every later field read by one byte (`dec de`);
  the clamp setup computed the size pointer with `add hl,de` after
  `ex de,hl`, when HL held the leftover constant, so the compare saw
  HL=4/DE=0x0F instead of the two MSB pointers (push the offset
  pointer while computing the size pointer).
- Branch direction (1): the clamp branch was inverted - it needed
  `jr nc,tr_zero` (position below the size stays) plus
  `jr z,tr_zero` (equal must not enter the copy loop, where B=0
  would run 256 iterations).
- Stack discipline (2 exit paths): the clamp's `jp tr_copy_down`
  skipped the entry `pop ix`, so its `ret` popped the saved IX as
  the return address; the exchange-fail and status-fail paths jumped
  to `tr_ret` with the file still pushed, so `ret` popped the file
  pointer.  Both now balance (`tr_fail` drops the file, the clamp
  pops IX before the jump).
- One false alarm: `tr_cmp_msb`'s copy count (B = 4 - the differing
  byte's index) looked wrong in a trace but is exact; the "failure"
  was a harness expectation error.

Bugs elsewhere that presented as asm failures:

- The kernel's FILE gate in kernel/vfs/fs.c forwarded only
  `op <= KFILE_OP_SYNC`, so KFILE_OP_TRUNCATE (6) was refused before
  the driver saw it - the op never ran.
- `user/sdk/src/ipc.c` `call()` returned the reply-status field,
  which an early kernel refusal never writes, so `truncate()`
  returned a stale 0 (success while doing nothing).
- Two buffer overruns in the test tail: writing 2,560 bytes from the
  512-byte `pattern` array and reading 1,000 bytes into the 512-byte
  `buf`.  The read overrun stomped the program's own
  `checks`/`failures` counters, producing the bogus
  "43154 checks, 58053 failures" summary.  Both now run in bounded
  512-byte slices; the driver behaved correctly throughout.
- The replay's first FS2-count pin was racy (the program outruns its
  console); the pins sit at markers whose following calls cannot
  change the count.
- The simulator's banks default to 0xFF; the harness zeroes the
  driver's io segment before each case.

## Budget

- Driver hot tier: 30,995 (baseline) -> 31,230 (+235 bytes against
  the 96-byte target — reported as an overrun).  Free = 1,538 >=
  the 1,536 reserve.
- The hand asm is 176 bytes in the hot tier; the compiled form cost
  over 400.

## Validation

- `python3 -m unittest tests.test_iocfat tests.test_truncate
  tests.test_sdk tests.test_source_layout`: green.
- `make check`: reproducible rebuild OK, 920 tests 0 failures
  (119 skipped), mapcheck and pack clean, konaos.bin == zephyr80.bin
  (sha256 81f0f50e...), driver hot 31,230.
- Recorded in docs/validation/2026-10-24-file-truncate.md.
