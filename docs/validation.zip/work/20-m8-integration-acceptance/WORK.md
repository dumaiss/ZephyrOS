# Task

Finish and accept milestone M8 as one coherent production device stack: make
boot order/failure policy deterministic, validate every console fallback and
class error path, reconcile module/arena reporting, run the full regression and
physical matrix, and record final architecture and evidence without changing
the IOC firmware.

## Context

Start only after packages 14-19 are individually reviewed and their required
hardware gates accepted. Read `work/00-WORKER.md`, architecture sections
30-31, every preceding M8 contract, and `work/M8-REFERENCE.md`. Review the
settled tree and actual diffs rather than trusting stage reports. M8 does not
include FAT, shell, full diagnostics, unload/hot-plug, far memory, or CP/M.

## Requirements

- Make production boot order explicit and deterministic:
  `sio.zmod`, `ioc.zmod`, `hid.zmod`, `v9958.zmod`, then one final
  `console_bind_defaults()`, then the unchanged `process_exec("monitor.zex")`
  launcher. A missing/failed optional module logs a precise early-SIO diagnostic
  and continues; it must not roll back or invalidate earlier resident modules.
  ROMFS corruption itself retains the existing fatal recovery policy.
- Ensure production and M8 test ROMFS manifests carry exactly the required
  ZMODs, `v9958-6x8.font`, and `monitor.zex`, with correct media types and no
  test fixture. Validate dependency order without adding a general resolver.
- Add failure variants for: all modules; no/failing V9958; no/failing HID (with
  IOC still present); no/failing HID and V9958; failing IOC (therefore HID init
  rollback); malformed class interface; unsupported VIDEO/HID/IOC operation;
  and arena exhaustion before the last module. Assert exact binding outcomes:
  HID/V9958, HID/SIO, SIO/V9958, SIO/SIO. Early/panic SIO must work in every
  image independently of registry/normal console state.
- Complete linked simulation of the real production M8 bytes. Exercise IOC
  command/status/bulk sequencing, HID queue traffic, V9958 port/VRAM model,
  split console syscalls, monitor interaction, two exit/relaunch cycles, and
  post-fault recovery. Include malformed/null/class/capability calls and prove
  they do not call invalid pointers, alter device/module tables, leak arena
  granules, or leave SIO/VDP handshake state active.
- Make build output and the image manifest reconcile: aligned static-kernel
  end, arena bounds/size, minimum 16 KiB, each module image+BSS and granules,
  total resident used/free. Assert `C000h-DFFFh` has no module allocation and
  all four production modules fit simultaneously. Preserve clean reproducible
  output and no generated debris.
- Preserve the exact M7 monitor bytes (`3533`, SHA-256
  `67574d57bdc2326ef3ecbbae9fdefcb313f0c63523b846c710e459afcda643ed`) and
  prove it contains no SIO, V9958, HID, IOC, early-console, CP/M, or private
  kernel dependency. Its normal console syscall ABI is unchanged.
- Extend `serial_smoke` with explicit M8 boot/fallback modes. The full image's
  serial portion validates early diagnostics and target selftests; the normal
  monitor interaction is a human HID/V9958 gate. Fallback images must not claim
  a direction that cannot be observed: use serial scripts for SIO-bound
  directions and a recorded operator check for V9958-bound output.
- Update `docs/architecture.md` status/source tree/implementation notes,
  `docs/devices.md`, module/memory/boot documentation, README targets, and add
  one dated final M8 validation record plus preserved serial transcripts. Mark
  physical items `PENDING` unless actually observed; only then mark M8 complete.

## Files

- `kernel/main.c`, `kernel/device/`, `recovery/manifest.json`
- `drivers/{sio,ioc,hid,v9958}/`, `modules/manifests/`
- `Makefile`, `tools/{mapcheck,pack_image,serial_smoke}.py`
- `tests/test_m8*.py`, `tests/target/m8/`, M8 manifests/fixtures
- `README.md`, `docs/`, especially `docs/validation/<date>-m8-device-stack.md`

## Constraints

- Freeze source before final clean validation. Preserve unrelated user work and
  investigate any unexplained shared-tree mutation.
- Do not modify/rebuild IOC firmware, add MCU commands, weaken CRC/header tests,
  use a destructive raw-LBA test, or introduce MAME as acceptance.
- Do not start M9 filesystem work or alter the native syscall ABI/monitor.

## Validation

```sh
make clean
make check
make zmod-test
make romfs-test
make zex-test
make m6-selftest
make monitor-test
make m7-selftest
make ioc-test
make hid-test
make v9958-test
make m8-selftest
make m8-fallback-selftests
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/modules/monitor.zex build/modules/*.zmod build/zephyros.bin
make clean
git status --short
```

Build and flash `build-m8-selftest/zephyros-m8-selftest.bin`; run
`make smoke-hardware-m8 SERIAL_PORT=...` before reset. Then perform and record a
human USB-HID/V9958 monitor pass: help, `R`, dump, safe modify/readback, harmless
port read, rejected latch write/bank 7/bad syntax, and two `Q` relaunches with
stable process/bank counts. Run the observable fallback image matrix and record
each exact image hash. Hardware is authoritative for IOC/HID, V9958 WAIT/timing,
and complete interaction.

## Acceptance criteria

- Every architecture section 31 criterion is mapped to passing host/simulator
  evidence and, where hardware-dependent, an observed physical result.
- Production boots all resident modules in dependency order, selects HID/V9958,
  and degrades through every specified fallback without losing early SIO.
- Arena/module reports reconcile, all modules fit, the M7 monitor is
  byte-identical, all regressions pass with no unexplained skips/warnings, and
  IOC firmware remains untouched.
