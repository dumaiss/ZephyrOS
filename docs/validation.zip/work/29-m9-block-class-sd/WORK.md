# Task

Rename `ZDEV_STORAGE` to `ZDEV_BLOCK` and publish the generic block-device
class contract (`include/zephyros/block.h`). Do not build any block driver: M9
has no consumer for one (architecture 32.15 and 32.39). The directory name is
historical. This is a small definition-only package.

## Context

Dispatch only after packages 28b and 28c are accepted. Read `work/00-WORKER.md`,
architecture sections 32.15-32.20 and 32.39, and `work/M9-REFERENCE.md`. There
is no backward-compatibility requirement.

`ZDEV_STORAGE` is enum slot 3 in `include/zephyros/device.h` and has never had
a driver. The future `sd-ioc.zmod` backend facts are recorded in M9-REFERENCE
("IOC volume units") for the milestone that adds a native filesystem.

## Requirements

- Rename `ZDEV_STORAGE` to `ZDEV_BLOCK` everywhere: source, tests, docs and
  tools. Keep the numeric value 3 and add no alias.
- Add `include/zephyros/block.h` with the architecture 32.15 `zblock_info` and
  `zblock_ops` layouts, plus static asserts and host tests pinning their
  sizes and offsets. Capability bits go in the previously unused range 20-23:
  - `ZCAP_BLOCK_READ 0x00100000`
  - `ZCAP_BLOCK_WRITE 0x00200000`
  - `ZCAP_BLOCK_FLUSH 0x00400000`
  - `ZCAP_BLOCK_REMOVABLE 0x00800000`

  Document the reserved range in `device.h` and `docs/devices.md`. Results are
  0 or a negative `ZOS_E*`.

  `media_status` returns:
  - 0 when the media is present and usable;
  - `ZOS_ENODEV` when there is no media;
  - `ZOS_EIO` when the media is degraded.
- The header must pass the module-facing header boundary checks: it is a
  driver-consumable class contract. It belongs in `include/zephyros/`, not
  in the user ABI (`abi/zos/`), because user programs never see device
  classes.
- Add a source-layout check that no `drivers/sd/` or other `ZDEV_BLOCK` driver
  is built or packed into the production ROMFS in M9, and that no kernel
  `block/` directory exists. This keeps the "no resident feature without a
  consumer" rule mechanical.
- Update `docs/devices.md` and the architecture implementation notes, stating
  that the first block driver arrives with its first consumer.

## Files

- `include/zephyros/{device,block}.h`
- `tests/test_source_layout.py`, `tests/` (header layout test)
- `docs/devices.md`, `docs/architecture.md` (implementation note only)

## Constraints

- No driver, no kernel code and no ROMFS change. The production image must be
  byte-identical before and after, because the rename is source-only and the
  header is not yet included by linked code. Prove this with hashes.

## Validation

```sh
make clean && make check
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/zephyros.bin build/modules/*.zmod
make clean && git status --short
```

No hardware run is needed if the production image and module hashes are
byte-identical to package 28's accepted build.

## Acceptance criteria

- `ZDEV_BLOCK` replaces `ZDEV_STORAGE` everywhere, and `block.h` is pinned by
  tests.
- A mechanical check prevents a block driver from becoming resident in M9.
- Production artifacts are byte-identical.
