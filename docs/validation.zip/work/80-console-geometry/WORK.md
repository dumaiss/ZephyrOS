> Worker package. Runs after package 79 (both touch
> `drivers/v9958/v9958_proto.c`). ABI change (no compatibility path:
> architecture 6.1). Drivers, SDK, libtui, tests, docs.

# Task

Make the console's text grid a reported value, exactly as
`docs/architecture.md` 5.6 ("Console geometry is reported, not fixed")
states, so a later font or grid change breaks no program.

## Current state

- `abi/kos/console_render.h`: `KCONSOLE_RENDER_COLS 85`,
  `KCONSOLE_RENDER_ROWS 26`, used by `drivers/v9958/v9958_proto.c`
  (`v9958_render_validate`) and pinned by `tests/test_tui.py`.
- `user/sdk/tui/src/tui_internal.h`: `TUI_LOGICAL_COLS`/`ROWS` (85/26)
  size the cell map and bitmaps; `tui_lifecycle.c` sets `screen` and
  `window` from them; the public `tui_get_size` (`user/sdk/include/tui.h`)
  reports `screen`.
- The V9958 grid: `V9958_COLUMNS`/`V9958_ROWS` (`v9958_driver.h`).
- Protocol numbering: `abi/kos/protocol.h` (`KCONSOLE_OP_*` up to RENDER
  6, `KVIDEO_OP_*` up to RENDER 4); the info-reply pattern:
  `KSOUND_OP_INFO` (`abi/kos/ksound.h`), `KTIMER_OP_INFO`.
- Console forwarding: `drivers/console/console_proto.c`; the serial build
  (`KOS_CONSOLE_SERIAL`); the tee (RENDER refused while armed).

Read: `work/00-WORKER.md`; architecture 5.6, 6.1; the files above;
`docs/tui.md`, `docs/sdk.md`, `docs/abi.md`.

## Requirements

1. **ABI** (Must): `KCONSOLE_OP_INFO` (7) and `KVIDEO_OP_INFO` (5), no
   descriptor; the reply payload is `struct kconsole_info`: `cols`, `rows`,
   `attr_bits` (bit 0 reverse), `flags` (bit 0 RENDER supported), the rest
   reserved zero; `_Static_assert` on its size. `KCONSOLE_RENDER_COLS`/
   `ROWS` are removed; the render stream's bounds are the reported grid.
2. **Answers** (Must): the V9958 console forwards INFO to VIDEO (85, 26,
   reverse, RENDER); while the tee is armed it clears the RENDER flag. The
   serial console answers 85, 26, reverse, no RENDER, itself.
3. **Validation** (Must): `v9958_render_validate` bounds by its grid;
   `attr` bits other than those reported are refused (as today for > 1).
4. **SDK** (Must): `console_info(struct kconsole_info *out)` as its own
   libkos member (no size change for programs that do not call it).
5. **libtui** (Must): `tui_init` reads the grid; `screen` and `window`
   come from it; a grid above the compiled capacity (`TUI_MAX_COLS`/
   `TUI_MAX_ROWS`, 85/26) fails `tui_init` with `-KOS_ENOTSUP`; a smaller
   grid works (cell map indexed by the capacity, scans bounded by the
   grid). The public `tui_*` API does not change.
6. **INVERT** (Must): documented as the normal/reverse exchange only;
   `libtui` emits INVERT only for that exchange (as today).
7. **Docs** (Must): `docs/abi.md`, `docs/sdk.md`, `docs/tui.md`,
   `docs/devices.md`. Remove the roadmap item "The direct text renderer"
   from architecture section 14 (package 79 is done by then).

## Tests

- INFO on both console builds and while the tee is armed;
- a RENDER outside the reported grid is refused before drawing;
- libtui with a reported 80 x 24 grid (a test console or simulator hook,
  under `tests/`): `tui_get_size` reports it and a full-screen draw stays
  inside it; a grid above capacity fails `tui_init`;
- the existing TUI, KonaCommander and serial transcripts unchanged.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free / reserve | after 79 / 1,536 | ≤ 64 bytes | stop and report |

Record `tui_test.exe`, `tui_dialog.exe` and `konacmd.exe` sizes before and
after.

## Criteria

- **Must:** requirements 1-7; the tests; `make check` green;
  `make console-serial-selftest`, `make sdk`,
  `make -C UserSoftware/KonaCommander test` green.

## Validation

```sh
make && python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_console_tee tests.test_console_serial tests.test_sdk tests.test_sdk_package tests.test_source_layout
make console-serial-selftest
make sdk && make -C UserSoftware/KonaCommander test
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-console-geometry.md`.
