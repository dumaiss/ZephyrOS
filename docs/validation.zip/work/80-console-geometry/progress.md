# Package 80: console geometry - progress (working memory, present tense)

Status: COMPLETE; KonaCommander fixed by package 81.
check` once at the end.

## Tree at start

Clean; HEAD has 78+79 (owner committed).

## Plan

1. ABI: KCONSOLE_OP_INFO (7), KVIDEO_OP_INFO (5), struct kconsole_info;
   drop KCONSOLE_RENDER_COLS/ROWS.
2. Drivers: v9958 INFO, console forward (tee clears RENDER), serial INFO.
3. Validation bounds from the grid; attr bits.
4. SDK console_info member; libtui capacity vs grid.
5. Tests, docs, roadmap item removal.

## Done

- ABI: `KCONSOLE_OP_INFO` 7, `KVIDEO_OP_INFO` 5 (protocol.h);
  `struct kconsole_info` (8 bytes), `KCONSOLE_ATTR_REVERSE`,
  `KCONSOLE_INFO_RENDER`, `KCONSOLE_INFO_SIZE` in console_render.h (the
  header the SDK ships; protocol.h is not shipped); grid constants gone.
  Stale protocol.h text about the atlas upload fixed (package 79 leftover).
- V9958: INFO case (pointer walk); validation bounds by
  `V9958_COLUMNS`/`V9958_ROWS`, attr by `~KCONSOLE_ATTR_REVERSE`.
- Console: `console_info()` - serial answers 85x26 itself; V9958 passes
  the caller's frame to VIDEO (reply in place, op put back) and clears
  RENDER while the tee is armed.
- Budget: hot 30,471 -> 30,550 (+79; budget 64; overrun 15). First cut
  +184 (two 32-byte frame copies, an IX frame in dispatch); trimmed by a
  pointer walk, the in-place frame and a separate function. Not chased
  further: 2,218 free against the 1,536 reserve (owner's rule: no byte
  hunting). Report as a finding.
- SDK `user/sdk/src/console_info.c` (own member), `console.h` prototype.
- libtui: `TUI_MAX_COLS/ROWS` capacity, `tui_init` asks the console,
  refuses 0 or above capacity with `-KOS_ENOTSUP`, screen/window from the
  grid; `tui_flush` phys_x clamp by the screen.
- Tests: `test_tui.TestTuiHeader.test_render_abi_is_pinned` failed on
  `KCONSOLE_RENDER_COLS` - test artifact (WORK.md requirement 1 removes
  it); now pins the INFO ABI. New `grid` mode in tests/tui/tui_test.c;
  `test_tui_sim` `_grid_hook` (overrides the console's INFO reply at its
  return) + three tests (85x26, 80x24, 90x30 -> init -7): V9958 3 OK.
  `test_console_tee.TestConsoleTeeTui.test_info_withdraws_render_while_armed`:
  4 OK.

- Added `bad_y` (row 26) to renderbad (out-of-grid row; `bad_x` was the
  column). Docs: tui.md, abi.md, devices.md (console table + INFO para,
  V9958 RENDER bound), sdk.md (prototype, text, member table), roadmap
  item removed.
- Batch: 215 run, 1 failed `test_the_screen_is_the_reported_grid` (row 2
  held `/> `). Class: my new test - the shell prompt can follow on row 2
  before the decode; it passed alone by timing. Rows checked from 3. The
  five grid tests on both lanes rerun: OK.
- `make console-serial-selftest` 6 OK; `make sdk` OK.
- BLOCKER (owner): KonaCommander no longer links -
  `EXE_EXEC_ERR_COLLISION`. Pre-80 it had 10 bytes between BSS end
  (DC76h) and its 896-byte stack (DC80h); package 80 adds 198 bytes of
  code to it (console_info 102, tui_init +60, the rest). Needs ~190
  bytes in UserSoftware/KonaCommander (owner's tree): STACK 896 -> 704,
  or trimming. Sizes: tui_dialog 20,955 -> 21,300; tui_test 37,647 (new
  mode); konacmd 37,637 -> does not link.

## Next action

Final gate: `make clean && make check`, `make console-serial-selftest`;
record; report the KonaCommander decision.
