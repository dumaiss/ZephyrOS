# Task

Complete `v9958.zmod` as the normal text-output device by porting the proven
85x26 6x8 terminal renderer, character operations, scrolling and sprite cursor,
then exercise the same native monitor with split HID-input/V9958-output binding.

## Context

Start only after package 18 is physically accepted. Read `work/00-WORKER.md`,
architecture sections 30.4 and 30.9, and `work/M8-REFERENCE.md`. Port behavior
from the pinned `v9958.asm`; do not transplant its CP/M driver table, BIOS
addresses, HID entry points, VIDEO_SEND payload ceiling, or build layout. The
font/atlas and low-level VIDEO core from package 18 are the only renderer base.

## Requirements

- Port the reference terminal state machine and drawing algorithms into the
  V9958 module: printable CP850 bytes, NUL/BEL/control consumption, CR, LF/VT,
  BS, TAB, FF, ESC c/D/E/M/H/7/8, CSI cursor movement/absolute positioning,
  erase display/line, SGR normal/reverse, save/restore, DEC auto-wrap `?7h/l`,
  and insert/delete lines. Unknown/partial sequences are consumed/recovered
  predictably without writing outside state/VRAM bounds.
- Retain the hardware-proven layout: 85 logical columns, 26 rows, 6x8 glyphs,
  208-line text surface with four-line margin, normal/reverse atlas pages,
  circular R#23 scrolling, and sprite-mode-2 cursor. Port print-run batching
  (64 bytes) and flush before control operations, present, blocking points and
  cursor updates so ordinary strings remain efficient and visible.
- Implement output-only `zchar_ops`: `putc` feeds one byte to the parser;
  `write` processes the entire 16-bit length and returns the exact count or the
  first error/partial count under existing character conventions. Input
  methods remain null. Add `ZCAP_CHAR_OUT|ZCAP_CONSOLE_OUT` to `v9958.0`; keep
  all VIDEO operations/capabilities from package 18.
- RESET must reinitialize terminal/parser/cursor and all VDP state, reload the
  ROMFS font atlases, clear/present, and leave normal/reverse and auto-wrap in
  defaults. Do not call HID or console services from the module. The generic
  console service alone composes V9958 output with independently bound input.
- Add host parser/model tests for every supported control family, boundary
  coordinates, right-margin wrap/no-wrap, top/bottom scrolling, insert/delete,
  reverse video, saved state, cursor hide/show/update, print-run split/flush,
  arbitrary chunking across `write` calls, and reset. Compare modeled command
  blocks/VRAM effects to fixed golden cases derived from the reference rather
  than merely checking that some VDP traffic occurred.
- Add simulator integration for four binding states now possible from the
  existing modules: HID/V9958, HID/SIO, SIO/V9958, and SIO/SIO. Prove each
  direction independently and prove early/panic SIO bypasses bindings. Inject
  renderer/video-operation errors and ensure the other console direction and
  registry remain intact.
- Build the unchanged M7 `monitor.zex` and assert exact size/hash from
  `work/M8-REFERENCE.md`. Boot it normally with HID input and V9958 output; no
  monitor source, manifest, linked object or syscall ABI may differ. Add an M8
  target path whose early-SIO transcript reports selected input/output classes
  and whose visible session covers help, `R`, dump, safe modify/readback,
  rejected input and two `Q`/relaunch cycles.
- Document terminal behavior and explicitly distinguish native VIDEO class,
  V9958 character output, HID character input, SIO fallback, and direct early
  SIO. Update arena reports and fail if the expanded module set no longer fits.

## Files

- `drivers/v9958/`, `modules/manifests/v9958.json`
- `kernel/device/console.c`, M8 boot/test manifests, `Makefile`
- `tests/test_v9958*.py`, `tests/test_m8_sim.py`, `tests/target/m8/`
- `tools/{mapcheck,serial_smoke}.py`
- `docs/{devices,architecture}.md`, `docs/validation/`

## Constraints

- V9958 remains output-only and has no IOC/HID/SIO input knowledge. The module
  must not import kernel console, process, syscall, or early-console symbols.
- No monitor rebuild customization, CP/M behavior, shell, VDP IRQ, 4x6 mode,
  or full future diagnostic suite.

## Validation

```sh
make clean
make check
make zmod-test
make ioc-test
make hid-test
make v9958-test
make m8-console-selftest
make monitor-test
python3 -m unittest discover -s tests -v
git diff --check
sha256sum build/modules/monitor.zex
make clean
```

Flash the named console image. Run the early-SIO smoke command for boot/module
status, then perform the documented human pass using the USB keyboard and V9958
display. Record both evidence channels; serial cannot stand in for visible VDP
or physical HID interaction.

## Acceptance criteria

- V9958 exposes working VIDEO and output-character interfaces with the full
  bounded terminal behavior, while HID remains an independent input device.
- All four split/fallback bindings work in simulation and early SIO remains
  independent.
- The exact M7 monitor runs through HID/V9958 on physical hardware without any
  SIO-specific change and retains the pinned hash.
