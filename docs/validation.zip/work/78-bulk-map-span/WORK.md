> Worker package. Baseline: HEAD plus the uncommitted 74 correction-01,
> 76 and 77 work in the tree (preserve them). Nucleus, host tools, docs
> and tests; no driver uses the mechanism yet (package 79 does).

# Task

Implement the bulk-map span and mapped segments exactly as
`docs/architecture.md` 5.2, 5.4, 4.5, 4.9 and section 9 now state: a
driver can map bank 6's first 8 KiB into `0000h-1FFFh` (Q = 6) and read
and write its own mapped segment directly, at its linked address.

## Current state

- Mode 11 shows the caller's bank Q at `0000h-1FFFh` while a driver runs;
  the nucleus owns every latch write (architecture 2.1).
- The bootstrap API table: `drivers/include/driver.h:struct driver_api`,
  filled in `kernel/ipc/ipc.c` (the table near `api_bulk_read`).
  `api_bulk_read`/`api_bulk_write` resolve the calling driver through the
  per-level endpoint record (`ipc.c`, "The endpoint being dispatched").
- Copy paths A/B/C: `kernel/ipc/ipc.c`, `ipc_asm.asm`, `ipc_common.asm`.
- Segment roles: `tools/modpack.py` (`ROLE_CODES`, the role ranges,
  `place_bulk`, the plan rows), `kernel/driver/driver_loader.c` (segment
  placement and the tier checks), `docs/module-format.md`.
- Ledgers: `tools/mapcheck.py`, `docs/memory.md` (bank-6 table and the
  ledger lines).
- IPC selftest drivers: `tests/target/ipc/` with manifests in
  `tests/target/ipc/manifests/`; `tests/test_ipc_selftest.py`;
  `make ipc-selftest`.

Read: `work/00-WORKER.md`; architecture 2, 4.3, 4.5, 4.9, 5.2-5.4, 9;
the files above.

## Requirements

1. **Primitives** (Must): `bulk_map(void)` and `bulk_unmap(void)` in the
   API table, fixed-core code. `bulk_map` saves the latch's Q, writes
   Q = 6 keeping mode and P, and returns 0; nested, it returns
   `-KOS_EBUSY` and changes nothing. `bulk_unmap` restores the exact saved
   Q; outside a span it is a no-op. Each costs at most 150 T-states
   (record the measured figure).
2. **Refusals** (Must): inside a span `copy_in`, `copy_out`,
   `bulk_read`, `bulk_write`, `call` and `event_post` refuse
   (`-KOS_EBUSY`; `event_post` ignores the post) with no side effect.
3. **Leak closure** (Must): when an endpoint dispatch returns with a span
   open, the return path restores Q and increments one fault counter,
   published where `SYS_DIAG_SYSTEM_INFO` publishes the IRQ counters (or
   beside them in the monitor's `R` line if the record has no room;
   state which).
4. **Interrupts** (Must): an interrupt inside a span returns to Q = 6
   (the exact-latch rule). No event is delivered there.
5. **Mapped role** (Must): manifest role `mapped` (image and BSS areas),
   a MOD role code, planner placement in `0100h-1FFFh` in load order,
   refusal above 7,936 bytes in total, boot and bulk placed above the
   mapped run. The loader loads mapped images as it loads bulk images and
   zeroes mapped BSS. `0000h-00FFh` stays free.
6. **Ledger** (Must): `driver mapped: <bytes> of 7936` printed and
   checked with the other ledgers; `docs/memory.md` shows the bank-6
   layout and the ledger.
7. **Docs** (Must): `docs/devices.md` (bootstrap API) and
   `docs/module-format.md` describe the primitives, the rules and the
   role, in the tree's voice.

## Tests

In the IPC selftest image, a test driver (an existing one or a new
`#16`-class one) with a mapped segment holding a known pattern and a BSS
area:
- inside a span it reads the pattern at its linked address and writes
  the BSS; after `bulk_unmap` the caller window is the caller's again;
- every refusal in requirement 2, and nested `bulk_map`;
- a dispatch that returns with the span open: Q restored, counter + 1;
- a timer interrupt taken inside a span (stay mapped across ticks):
  returns mapped, the driver's next read is correct;
- planner: a mapped set over 7,936 bytes is refused; placement is in
  load order from `0100h`.

## Invariants

- Without a span, every path behaves exactly as now: the production
  replays and `test_ipc_selftest` pass unchanged.
- The gate stack worst case stays at or below 360.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| nucleus fixed room | 6,108 | ≤ 200 bytes | stop and report |
| common | ceiling 3,072 | 0 bytes | stop and report |
| driver hot free / reserve | 1,741 / 1,536 | 0 bytes | stop and report |

## Criteria

- **Must:** requirements 1-7; the tests; `make check` green;
  `make ipc-selftest` green.
- **Informational:** `bulk_map` + `bulk_unmap` T-states; fixed-core bytes.

## Simulator

`tests/z80sim.py` already models the latch and mode 11 (decoder revision
13); the span needs no new peer. The NMI is not modelled.

## Validation

```sh
make && python3 -m unittest tests.test_ipc_selftest tests.test_mod tests.test_device_release tests.test_source_layout
make ipc-selftest
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-bulk-map-span.md`. Remove nothing from
the roadmap: "The direct text renderer" completes with package 80.
