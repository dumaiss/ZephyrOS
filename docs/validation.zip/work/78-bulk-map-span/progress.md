# Package 78: bulk-map span - progress (working memory, present tense)

Status: COMPLETE, final gate green (make check: OK).
run once at the end of 78+79). Record:
`docs/validation/2026-10-21-bulk-map-span.md`.

## Tree at start

`git status --short` clean (owner committed 74c01/76/77). HEAD: see
`git log -1` at record time.

## Verified facts (read, no command needed)

- Driver API table: `kernel/ipc/ipc.c:ipc_api` (12 entries, order =
  `drivers/include/driver.h:struct driver_api`). New entries go at the
  end.
- Latch writes in the fixed core live only between `ipc_asm_begin` and
  `ipc_domain_switch_end` in `kernel/ipc/ipc_asm.asm` (comment says the
  layout check allows exactly these writes): `bulk_map`/`bulk_unmap` go
  there. Mapcheck rule still to locate (grep for `domain_switch` found
  nothing in tools/mapcheck.py by that name).
- Frames: `ipc_syscall_call_object` passes the syscall's frame **in place
  in the caller window** (0100h-1FFFh). Inside a span that window shows
  bank 6, so a driver must not touch its request frame inside a span.
  Architecture 5.2 must say so (add).
- IRQ trampoline (`ipc_irq_trampoline`) keeps the bank field; a handler
  interrupting a span runs with Q = 6 (handlers never use the caller
  window). `api_event_post` is called from handlers: the refusal must
  apply only outside IRQ context (`ipc_bulk_open && !ipc_irq_active`), or
  every timer/VDP event that lands in a render span would be lost.
  `kos_event_post_bank` maps bank 6 to the gate latch already.
- `SYS_DIAG_SYSTEM_INFO` is a fixed 13-byte record; existing binaries
  (shell banner, UserSoftware/ColecoGo) pass 13-byte buffers, so growing
  it would overflow them. Decision: the leak-fault counter is the fixed
  data symbol `_ipc_bulk_faults`, read by tests through the map; docs
  name it. (WORK.md requirement 3 allowed stating the choice.)

## Plan

1. asm primitives + state (`_ipc_bulk_open`, `_ipc_bulk_q`,
   `_ipc_bulk_faults`) in ipc_asm.asm before `ipc_domain_switch_end`.
2. driver.h entries; ipc.c table, refusals, leak closure in
   `invoke_endpoint`.
3. modpack `mapped` role, MOD role code, loader, ledger, docs.
4. IPC selftest driver coverage; targeted tests.

## Done

- Latch-write rule: `tools/pack_image.py:verify_no_banked_latch_writes`
  allows the extent `_ipc_domain_enter`..`ipc_domain_switch_end`; the
  primitives sit inside it (docstring still to update).
- Step 1-2: `_ipc_bulk_map`/`_ipc_bulk_unmap` + `_ipc_bulk_open`,
  `_ipc_bulk_q`, `_ipc_bulk_faults` in ipc_asm.asm; `api_bulk_map` (C,
  refuses in IRQ context: the exact-latch return would leave the flag
  set); refusals in api_copy/api_call/api_bulk_read/api_bulk_write;
  `api_event_post` ignores only outside IRQ context; `ipc_span_close`
  after all three invoke paths; driver.h entries appended. `make` OK.
  Fixed room 6,108 -> 5,945 (+163, budget 200).

- Step 3: `tools/modpack.py` role `mapped` (code 5, tier 0100h-2000h,
  `place_mapped` before boot/bulk, boot cursor starts after the mapped run,
  cross-role overlap check for mapped/boot/bulk, ledger fields
  `driver_mapped_bytes`/`_capacity_bytes`, plan `mapped_base`, row
  format); `tools/pack_image.py` `DRIVER_MAPPED_LEDGER_LINE`,
  `DRIVER_MAPPED_CAPACITY`; `formats/include/mod.h` `MOD_SEGMENT_MAPPED`;
  `kernel/driver/driver_loader.c` accepts role 5 inside 0100h-2000h,
  reports it, prints `driver mapped:` in evidence builds. `make` OK; plan
  prints `driver mapped: 0 bytes of 7936`. Boot bases moved 0000h ->
  0100h (page zero reserved).

## Failures

- `test_driver_images.TestDriverSet.test_boot_and_bulk_share_the_lower_tier`:
  `256 != 0` (boot base). Class: test artifact - it pins boot at 0000h;
  architecture 5.2 (this package, WORK.md requirement 5: "0000h-00FFh stays
  free") moves the first boot segment to 0100h. Pin changed to 0100h.
  Added: mapped order/boot-above, 7,936 limit, plan ledger tests. Module
  green (34).

- Step 4: IPC selftest coverage. `echo` gains a mapped segment
  (`tests/target/ipc/echo_map.c`: const pattern + BSS) and ops
  ECHO_SPAN (mask of 8 checks: mapped read, BSS write, nested map, call,
  copy_in, bulk_read refusals, latch Q=6 inside / caller's after, copy_in
  works after unmap) and ECHO_LEAK; `irqx` gains a mapped pattern
  (`irqx_map.c`) and IRQX_SPAN (CTC0 delivery inside a span, Q=6 and the
  pattern intact after). Client checks span-probe, span-leak,
  span-after-leak, span-irq. Replay: plan line includes `mapped`, the
  `driver mapped:` ledger, `_ipc_bulk_faults == 1`, `_ipc_bulk_open == 0`.
  Makefile rule `ipc_%_map.rel` (--constseg MAPPED --dataseg
  MAPPED_BSS). Note: an address taken into a local splits into bytes
  (relocation mode 0Bh, refused by the packer); the drivers keep mapped
  addresses in statics set at init.
  `make ipc-selftest`: client 58/58; `tests.test_ipc_selftest_sim
  tests.test_ipc_selftest`: 41 OK.

## Failures (continued)

- `test_ipc_selftest_sim.TestIpcDriverImages.test_loader_reports_the_packer_plan`:
  the expected line lacked ` mapped 0100h`. Class: test artifact - the
  plan builds its expected line from the plan roles; WORK.md requirement 5
  adds the role. Extended with `mapped_base` and the mapped ledger line.

## Done (final)

- Docs: architecture 5.2 (frame out of reach; handlers cannot open a
  span), devices.md 13, module-format.md, memory.md; pack_image docstring.
- Span state folded into one byte (80h | Q): bulk_map 142 T, unmap 93 T.
- Re-ran `make ipc-selftest` after the fold: 58/58, 41 OK. Production
  replays 52 OK; host batch 203 OK. Fixed room 5,950 (+158).
