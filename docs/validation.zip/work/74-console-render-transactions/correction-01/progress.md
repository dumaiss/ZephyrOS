# Correction 01 progress — working memory, present tense

Status: implementing. Tree at de3bf64 (tee committed); correction scope
does not overlap the tee commit.

## Requirements and plan

1. Hold (Must): console entries (PUTC/WRITE/RENDER) must not touch the
   VDP while exclusive. Plan:
   - v9958.c: `v9958_overtaken` non-static, declared in v9958_driver.h.
   - v9958_proto.c render worker: count via v9958_overtaken and only set
     render_active after the hold check.
   - v9958_io.asm: `V9958_ST_EXCLUSIVE = 20` (+header _Static_assert);
     wrappers bracket sprites_off/restore and the render finish worker
     with hold checks (`v9958_hold_off`/`v9958_hold_restore`/
     `v9958_hold_finish`).
   - Probe: devtest.c dev_hold gains a holder R#8 write and a
     console_render of a 10-byte STATE stream; test_device_release.py
     asserts zero VDP traffic after the R#8 write and dropped += 10.
2. Colours (Should): header _Static_asserts tie CLEAR_COLOR /
   FILL_COLOR_REVERSE to NORMAL/REVERSE (nibble twice); source-layout
   pin in test_v9958.py ties the asm fill equates to the header.
3. Fallback (Must): tui_flush.c - ENOTSUP sets render_support=2
   whatever it was; when it was 1, tui_dirty_all() then ANSI, and the
   flush returns the ANSI result.  Test: production-image replay with
   the serial tee (renderflip mode): support 1 -> armed -> flush ->
   full ANSI repaint on both lanes, pass line.
4. Cost (Must): measure one KonaCommander menu move in phases
   (libtui flush / console_render IPC / console forward / validation /
   execution+finish+wrappers).  Fix if one phase dominates within
   tui_flush.c/v9958_proto.c (expected: the two-pass cell scan).
5. Coverage (Must):
   - invertwrap mode: 31 scrolls (origin 248), INVERT row 0 on/off;
     assert exact LMMV/EOR DY=248/NY=8 per direction, page-zero only,
     decoded screen correct both directions.
   - rendersync mode: TEXT+INVERT+STATE with cursor move in one RENDER;
     assert exactly one SAT write and one final command wait (status
     reads after the SAT write end with CE=0).
   - Delete the `wrapped` source grep; update the wrapper-order grep
     for the hold-aware wrappers.

## Facts verified

- scroll_origin is always a multiple of 8 (only scroll_up +8), so an
  8-line INVERT cell can end at scanline 255 (origin 248, row 0:
  DY=248/NY=8) but never straddle; the split branch fires there with
  wrapped==0 -> one command per direction.  The two-command split stays
  reachable for multi-row fills (fill_cells).
- V9958Peer: commands/status_reads/reg_writes carry `now`; vram_writes
  do not - the merged event order comes from per-step list growth.
- test_device_release.py already reads driver bank-6 state via
  v9958.report.json + drivers.plan.json (dropped at offset 21..22,
  exclusive at 20).
- tui dirty bitmap is linear over cells (2210 bits, 277 bytes), not
  row-aligned (85 not multiple of 8).

## Pending measurement

- Phase table of one menu move (KonaCommander), then decide the scan
  fix (byte-skip within rows, keeping the two-pass order).

## Scan optimization (requirement 4) — resolved

- Before: P1 flush scan+stream build = 331,078 cycles of one
  KonaCommander Right menu move (~97% of the move).  PC histogram:
  per-cell bitmap test dominates (shift loop per cell).
- Fix: incremental mask/byte walk in `tui_flush_render` — keep `bits`
  (the bitmap byte) and `mask` (1 << (index & 7)) in sync with the
  cell; a whole clean byte skips 8 cells.  Two passes preserved.
- After (measured via /tmp/measure_phases.py + /tmp/measure_final.py):
  P1 28,650; P2 console_render IPC 848; P3 forwarding 237;
  P4 validation 2,676; P5 execution+finish+return 1,774;
  total flush->next getkey 34,185 (was ~340,390).  ~10x.
- tui_flush.rel: 18,448 -> 20,861 bytes (+2,413); KonaCommander links
  and exepack validates again (STACK=896, _DATA end well inside).
- Full tui_sim suite exposed the three new tests inherited by
  TestTuiSerialScreen; added SERIAL branches: invertwrap asserts one
  refused RENDER + SGR7/SGR0 WRAP; rendersync asserts one refusal and
  XY/CD inverse via ANSI; renderflip asserts one refusal, key via
  sio_rx, FLIP/TAIL/SGR/Z on the lane (no full repaint: support never
  reached 1).  All six variants pass.

## Final validation status (2026-10-21)

- test_v9958 + test_device_release: 39 tests OK (1 skip) — hold probe,
  zero-VDP-traffic on both replays, colour/offset pins.
- tests.test_tui: 29 OK (discipline check failed once: invertwrap used
  `\033[26;1H`; replaced with 56 LFs = 25 advances + 31 scrolls from
  the home position, no ANSI in the test program).
- tests.test_console_serial + test_iocfat + test_source_layout: 78 OK.
- Full tests.test_tui_sim: 47 tests, 0 failures (serial class included:
  SERIAL branches added to the three new tests).
- make console-serial-selftest: OK; console-serial.mod byte-identical
  (1150f41f...); console-v9958-hid.mod byte-identical (9534a607...).
- make -C UserSoftware/KonaCommander test: exit 0 (protocol + host +
  project + UI replay).
- driver hot tier: 31,031 -> 31,027 used (-4 <= 64); free 1,737 ->
  1,741 (reserve 1,536).
- tui_flush.rel 18,448 -> 20,861; konacmd.exe 37,637 bytes exepack OK.
- git diff --check: clean.
- Remaining: `make clean && make check` (running), then
  `make console-serial-selftest` to restore the serial image, final
  hashes, the record append, no commit.
