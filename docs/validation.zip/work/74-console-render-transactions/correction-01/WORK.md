> Correction 01 to package 74. Worker. Baseline: HEAD (`f40cb6d`). Scope:
> `drivers/v9958/`, `user/sdk/tui/src/tui_flush.c`, their tests and the
> record. No ABI change, no console driver, no firmware.

# Correction 01 — exclusive holds, measured cost, behavioural coverage

The rest of package 74 is accepted; implement only this delta. Findings:
`docs/validation/2026-10-19-console-render-transactions.md`, "Supervisor
review".

## Current state

- `drivers/v9958/v9958_io.asm`: `_v9958_char_putc`, `_v9958_char_write` and
  `_v9958_render_transaction` call `v9958_sprites_off` before the worker and
  `v9958_sprites_restore` after it. The workers check the hold
  (`v9958.c:v9958_overtaken`; `v9958_proto.c:v9958_driver_render_worker`
  checks `v9958_state.exclusive` without counting).
- `_v9958_render_transaction` always calls `v9958_render_finish_worker`,
  which runs `v9958_term_sync` (flush, cursor SAT, command wait).
- `v9958_driver.h`: `V9958_COLOR_NORMAL 04h`, `V9958_COLOR_REVERSE 0Fh`,
  `V9958_INVERT_COLOR`; `V9958_CLEAR_COLOR 44h`,
  `V9958_FILL_COLOR_REVERSE FFh`. `v9958_io.asm` repeats `44h`/`FFh` as
  `V9958_FILL_NORMAL`/`V9958_FILL_REVERSE`.
- `tui_flush.c:tui_render_send` switches to ANSI (`render_support = 2`) on
  `-KOS_ENOTSUP` only while `render_support == 0`.
- `tests/z80sim.py:V9958Peer`: each command is busy a fixed
  `command_busy = 400` T-states.

Read: `work/00-WORKER.md`; package 74's `WORK.md` and record; the files above.

## Requirements

1. **Hold** (Must): while `v9958_state.exclusive` is set, no console entry
   (PUTC, WRITE, RENDER) performs a VDP port access: no R#8 write, no SAT
   write, no command wait. RENDER during a hold returns the stream length
   and adds it to `dropped`, as WRITE does. Observable property: a replay
   that holds the VDP, sets R#8 to a holder value, then writes and renders
   through the console sees zero V9958 port writes from those calls and the
   holder's R#8 unchanged.
2. **Colours** (Should): `_Static_assert`s tie `V9958_CLEAR_COLOR` and
   `V9958_FILL_COLOR_REVERSE` to `V9958_COLOR_NORMAL`/`REVERSE` (each packed
   byte is the nibble twice). The assembly names its fill bytes from one
   place or a source-layout check pins them to the header.
3. **Fallback** (Must): `-KOS_ENOTSUP` from `console_render` switches
   `libtui` to the ANSI path whatever `render_support` was. When it was 1,
   every logical cell is marked dirty first, so the ANSI path repaints the
   whole screen (the new backend has not seen it). A host test covers
   1 → ENOTSUP → full ANSI repaint, and the call returns the ANSI result.
4. **Cost** (Must): measure where the extra T-states of a RENDER menu move
   go. Split one move (the KonaCommander 100-move run) into: `libtui` flush
   (scan + stream build), the `console_render` IPC, driver validation,
   execution, finish/wrappers. Record the table. If one phase dominates and
   a fix fits inside `tui_flush.c` or `v9958_proto.c` without an ABI change
   (for example a single scan, or skipping zero dirty/invert bytes eight
   cells at a time), make it; the record states before and after.
5. **Coverage** (Must), simulator behaviour, not source greps:
   - an INVERT span on a row whose cell crosses scanline 255 (scroll the
     origin first): two LMMV/EOR commands with the exact DY/NY pairs, and
     the decoded screen correct in both directions;
   - a multi-record RENDER (TEXT + INVERT + STATE) with a cursor move:
     exactly one SAT write and one final command wait.
   The existing source-grep checks that these replace are deleted.

## Invariants

- RENDER outside a hold: the accepted 74 replays (`invertspan`,
  `renderboundary`, `renderrows`, `renderbad`, `rendermax`, KonaCommander
  UI replay) pass unchanged.
- The serial transcript tests pass unchanged.

## Budgets

| figure | now | this correction | on overrun |
|---|---|---|---|
| driver hot tier free / reserve | 2,126 / 2,048 | ≤ 64 bytes | stop and report |

## Criteria

- **Must:** requirements 1, 3, 4, 5; the validation below green.
- **Should:** requirement 2; menu-move T-states not above the ANSI control
  (23.4 M per 100 moves); a miss is a finding with the cost table.
- **Informational:** console image hot bytes before/after; T-states per move.

## Simulator

`V9958Peer` command timing is a fixed 400 T-states, not the V9958's per-dot
LMMV rate. Real LMMV/EOR duration is for the owner checklist.

## Owner checklist

- KonaCommander: F1, Left/Right across the menu bar (one visual action, no
  repaint), close the menu, cursor correct.
- A game holding the VDP that prints to the console: its sprites stay on.

## Validation

```sh
make && python3 -m unittest tests.test_v9958 tests.test_tui tests.test_tui_sim tests.test_console_serial tests.test_iocfat tests.test_source_layout
make console-serial-selftest
make -C UserSoftware/KonaCommander test
make clean && make check   # once, at the end
git diff --check
```

Record: append "Correction 01" to
`docs/validation/2026-10-19-console-render-transactions.md`.
