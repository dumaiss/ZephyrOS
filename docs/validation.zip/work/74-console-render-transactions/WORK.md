# Task

Make one TUI flush one driver-visible rendering transaction, and make a
normal/reverse-only selection change an in-place V9958 pixel operation instead
of a glyph redraw. The important outcome is perceptual as well as measured:
moving a menu selection must not visibly erase and repaint the two affected
labels.

The V9958 operation is **LMMV with EOR** (`R#46 = 83h`), not LMMC. LMMC is a
CPU-to-VRAM transfer and would reintroduce a byte stream. LMMV applies one
logical colour to a rectangle already in VRAM. In GRAPHIC 6, LMMV's R#44
colour is one 4-bit pixel, so blue `4` XOR white `F` is `0Bh`; this exchanges
every normal foreground/background pixel in either direction.

Read:

- `work/00-WORKER.md`;
- `docs/konaos-tui-sdk-architecture.md`, especially the output model;
- `work/TUI-REFERENCE.md` and packages 66-73;
- `abi/kos/ipc.h` and the CONSOLE/VIDEO protocols in
  `abi/kos/protocol.h`;
- `drivers/console/`, `drivers/v9958/`, and the current TUI dirty/flush path;
- the accepted console buffering and V9958 renderer tests and validation
  records.

## Required design

### 1. One descriptor is one rendering transaction

Add `KCONSOLE_OP_RENDER` and the corresponding private output dependency
operation `KVIDEO_OP_RENDER`. A RENDER request has one IN descriptor,
`arg0 = offset`, and `arg1 = byte length`; the limit remains
`KOS_IPC_DESC_MAX`. The descriptor is a versioned, bounded command stream,
not a generic facility for batching arbitrary IPC calls.

Define the shared byte layout in an ABI header shipped by the SDK. Pin v1 to:

```text
stream header: version:u8 flags:u8 total_length:u16

record header: op:u8 record_length:u8

TEXT:          op,len,x,y,attr,count,bytes[count]
INVERT:        op,len,x,y,attr,count,bytes[count]
STATE:         op,6,x,y,attr,visible
```

`record_length` includes its two-byte record header. TEXT and INVERT require
`record_length == 6 + count`; STATE requires 6. Coordinates are absolute,
0-based terminal cells. `attr` is 0 normal or 1 reverse. A span is nonempty,
lies wholly in one of the 85 x 26 rows, and contains CP850 glyph bytes.
Header flags and all reserved values are zero.

TEXT paints the supplied characters with the requested attribute. INVERT has
the precondition that the displayed characters already equal the supplied
fallback bytes and that only normal versus reverse changed; it changes the
attribute without changing the characters. The included bytes make the
record self-contained for a backend that must repaint. STATE establishes the
post-transaction cursor position, rendition and visibility and, when present,
is the last record. A stream may omit STATE, but `libtui` includes it in every
nonempty render request so each request is self-contained.

Validate the complete header, record walk, lengths, coordinates and attributes
before the first display or output operation. A malformed
request returns `-KOS_EINVAL` with no partial rendering. A successful request
returns the descriptor bytes consumed. A zero-length request, inconsistent
total length, unknown version/opcode/flag, truncation or trailing byte is
invalid.

The V9958/HID console forwards the descriptor unchanged so it remains one
application IPC and one VIDEO call. The serial console may implement the
records as cursor/SGR/text output, or return `-KOS_ENOTSUP`; `libtui` must then
cache that result and use its existing ANSI dirty-run path. Ordinary WRITE,
PUTC and RESET behavior is unchanged.

### 2. The V9958 owns the hardware transaction

Execute a validated render stream on the renderer's private stack with sprite
evaluation disabled for the whole stream. Absolute TEXT spans set the
renderer row, column and attribute directly, feed their characters into the
existing run engine, and preserve the current pairing/coalescing optimizations.
Do not manufacture ANSI sequences inside the driver.

Within one RENDER call:

- wait only where command ordering requires it;
- do not update the cursor SAT after each record or each 64-byte descriptor
  staging chunk;
- do not restore sprite evaluation between records;
- flush the last pending glyph run, apply the final STATE, update the cursor
  SAT once, wait for the final command once, then restore sprite evaluation;
- leave the ordinary WRITE/PUTC synchronization contract unchanged.

The transaction parser may copy the descriptor more than once: one validation
pass before I/O and one execution pass is preferred to staging 4 KiB in the
driver. Record headers crossing the 64-byte staging boundary must work.

### 3. In-place normal/reverse transitions

Implement INVERT on V9958 as LMMV/EOR over the existing page-zero pixels:

```text
DX = x * 6
DY = scroll_origin + y * 8
NX = count * 6
NY = 8
CLR = 0Bh
ARG = 00h
CMD = 83h                 LMMV + EOR
```

Flush an earlier glyph run before launching the logical fill. Split a span
whose physical eight-line cell crosses scanline 255 exactly as the existing
circular-bitmap fills do. The operation must work in both directions:
normal-to-reverse and reverse-to-normal use the same EOR rectangle. Do not
read VRAM and do not redraw or copy a glyph for an accepted INVERT record.

Keep `0Bh` derived or asserted from the console's normal and reverse pixel
colours so a palette/rendering change cannot silently invalidate it. Add the
LMMV and EOR constants beside the existing command-engine constants.

### 4. TUI dirty classification and fallback

Keep the existing logical cell map. Add one bit per cell to distinguish a
pending invert-only transition from a glyph redraw:

- unchanged character plus one 0/1 attribute toggle: toggle the invert bit;
- a second toggle before flush cancels that bit;
- any character change promotes the cell to ordinary redraw and clears its
  invert bit;
- once promoted, a cell remains an ordinary redraw until committed;
- adjacent cells with the same final attribute are coalesced into horizontal
  TEXT or INVERT spans.

Use a bounded render buffer, split only at record boundaries, and reserve room
for the final STATE record. One ordinary menu-selection move (old selection
off plus new selection on plus final state) must fit in one RENDER call. After
each successful request, clear only the dirty/invert cells committed by that
request; a later failure must not cause an already-applied EOR span to be
toggled a second time. On the serial `-KOS_ENOTSUP` fallback, retain the
existing idempotent ANSI redraw behavior and its current failure semantics.

The public `tui_*` API and widget API do not change. Add only the low-level
SDK console entry needed by `libtui`; it flushes earlier buffered console bytes
before RENDER so output ordering remains exact.

## Tests and evidence

1. ABI/source tests pin every operation number, header/record size and SDK
   package member. Unknown and malformed streams are rejected before any VDP
   command or serial byte.
2. V9958 unit/simulator tests cover TEXT, STATE, records and headers crossing
   64-byte staging boundaries, maximum legal length, circular-Y splitting,
   and both directions of INVERT. Assert `CMD=83h`, `CLR=0Bh`, the exact
   rectangle, no atlas HMMM for an invert-only span, and one final cursor/SAT
   synchronization for a multi-record transaction.
3. TUI host tests cover invert parity, promotion to redraw, span coalescing,
   record-buffer splitting and retry bookkeeping. Existing unchanged-flush,
   clipping, save/restore and serial transcript outcomes remain correct.
4. Extend the menu replay (and KonaCommander replay where practical) so one
   Left/Right selection move emits two INVERT spans in one RENDER call on the
   V9958 route. Assert that neither complete menu labels nor the whole menu
   bar are sent as TEXT.
5. Record simulator command counts and elapsed T-states for at least 100 menu
   selection moves before and after. Raw throughput need not improve for this
   package to pass; the visual acceptance below is primary.

## Physical acceptance

On V9958/HID hardware, run KonaCommander and repeatedly move across the menu
bar with Left/Right:

- the old and new selections change as one visual action;
- glyph shapes remain stable—there is no visible erase/repaint or full-menu
  redraw;
- cursor visibility and position remain correct after closing the menu;
- ordinary screen drawing, reverse text, scrolling and exit restoration still
  work.

Record the executable and image hashes plus PASS/FAIL/PENDING. A simulator
trace cannot substitute for the visual row. On serial, verify the same menu
contents and selection state through the fallback; no RENDER bytes may leak to
the terminal.

## Acceptance

- A TUI flush reaches V9958 as a bounded transaction rather than independent
  terminal writes, and one menu move uses one RENDER request.
- The V9958 waits/presents and commits the cursor once at the transaction
  boundary, not once per staging chunk or render record.
- An attribute-only menu move uses two LMMV/EOR rectangles and zero glyph
  redraws for those labels.
- Repeated toggles, redraw promotion, partial buffer commits and serial
  fallback are correct and deterministic.
- Existing console clients and both TUI backends retain their observable
  behavior.

## Constraints

- This is a console/VIDEO/TUI optimization, not generic multi-call IPC,
  asynchronous rendering, page flipping, a screen server or a new colour
  model.
- Do not expose raw VDP commands through CONSOLE or the public TUI API.
- Do not switch glyph output to HMMC/LMMC, add a VRAM shadow, or change the
  85 x 26 GRAPHIC 6 layout.
- Preserve the existing ordinary console-write path and all unrelated/user
  changes.
- Keep driver staging bounded; do not allocate a descriptor-sized driver
  buffer.
- Record the driver hot-tier delta. This feature may consume the planned
  reserve, but the final production set keeps at least 2 KiB free. The host
  placement plan may backfill the unused run below DRIVER_IO; it must remain
  deterministic and pass the existing overlap/embedded-base checks.
- Record `docs/validation/<date>-console-render-transactions.md` and maintain
  `work/74-console-render-transactions/progress.md`.

## Validation

Develop with focused builds/tests. Once source is frozen, run the formal gate
once:

```sh
make -B build/user/tui_test.exe build/user/tui_dialog.exe \
    build/UserSoftware/KonaCommander/kc.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_v9958 tests.test_console_serial tests.test_sdk \
    tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Rebuild the named V9958/HID and serial replay images after the clean gate only
when their replay tests require images removed by `make clean`. Do not rerun
an equivalent suite merely to duplicate a recorded passing result.

