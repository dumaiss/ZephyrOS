# Progress

## Status

COMPLETE — the ABI, TUI classification/render path, V9958 transaction driver,
KonaCommander conversion, focused replay coverage, clean gate and validation
record are in place. No commit has been made.

## Done

- Added `abi/kos/console_render.h` with the v1 header, TEXT, INVERT and STATE
  record layouts, pinned operation numbers and sizes.
- Added `KCONSOLE_OP_RENDER` (6), `KVIDEO_OP_RENDER` (4), the SDK
  `console_render()` entry, console forwarding and serial `-KOS_ENOTSUP`.
- Added the V9958 validation pass and execution pass: bounded descriptor
  copies, complete rejection before I/O, absolute TEXT/STATE records,
  one private-stack transaction with sprites disabled, one final cursor/SAT
  synchronization, and LMMV/EOR (`83h`, colour `0Bh`) for INVERT.
- Added TUI dirty/invert classification, promotion back to glyph redraw,
  bounded render-buffer splitting, per-request commit bookkeeping and cached
  ANSI fallback.
- Restored the ANSI cursor/run transcript to the accepted serial behavior;
  the earlier cursor-motion suppression from the started work changed serial
  byte counts and was rejected.
- Added focused target modes and replay checks:
  - `invertspan`: two INVERT spans in one request, both directions;
  - `renderboundary`: a record header crossing the 64-byte staging chunk;
  - `renderrows`: a two-row flush split into two RENDER requests;
  - `renderbad`: malformed streams rejected without glyph/invert commands;
  - `rendermax`: a valid 4096-byte render stream.
- Updated the V9958 screen decoder to apply LMMV/EOR attribute toggles and
  corrected the flush-count, shutdown and serial transcript expectations for
  the split backend paths.
- The started KonaCommander TUI conversion and its `test_ui_sim.py` focused
  replay are preserved.

## In progress

- The focused V9958 and serial render tests pass.
- KonaCommander builds against the rebuilt SDK and its UI replay passes.
- A 100-move KonaCommander measurement after F1/menu focus recorded 100
  RENDER calls, 3,000 render bytes, 200 INVERT commands, zero glyph copies,
  zero text cells, zero cursor-SAT writes and 36,120,304 simulator T-states.
- Serial replay: 26 tests pass. KonaCommander host/project/UI suites pass.
- Final clean gate: 859 tests, 116 expected skips, `make check: OK`.
- Final serial image rebuild: 6 tests pass; serial TUI replay: 20 tests pass.
- Validation record: `docs/validation/2026-10-19-console-render-transactions.md`.

## Decisions

- Keep the serial ANSI fallback byte-for-byte compatible with the accepted
  transcript; render transactions are an optimization only where accepted.
- Keep one shared 101-byte `tui_run`/`tui_render` buffer and split only at
  record boundaries, reserving six bytes for the final STATE record.
- Attribute-only transitions use the two-valued invert bitmap; a character
  change or an already-promoted dirty cell stays a TEXT redraw.
- V9958 INVERT uses LMMV/EOR over the existing page-zero pixels rather than
  reading VRAM or redrawing glyphs.

## Open items

- The work file names `build/UserSoftware/KonaCommander/kc.exe`; the
  project's actual output is `UserSoftware/KonaCommander/build/user/
  konacmd.exe` (the correct KonaCMD executable).
- Driver hot-tier delta is +1,462 bytes versus the package-65 baseline
  (29,180 -> 30,642 used); 2,126 bytes remain free. The owner accepted the
  larger delta because the render-transaction feature requires it.
- 100-menu-move comparison recorded against the same final source with
  `console_render()` overridden to force ANSI fallback: fallback 3,400
  console bytes, 800 glyph/text cells and 23,380,356 T-states; production
  100 RENDER calls, 3,000 bytes, 200 LMMV/EOR operations, zero glyph/cell
  redraws and 36,120,304 T-states.  The added states are V9958 command waits;
  WORK allows throughput not to improve.
- Physical V9958/HID and serial acceptance is PENDING.
- No source commit.

## Failures under investigation

0 implementation / 0 test artifact / 0 unknown in the final tree.

The clean-check failures were resolved: `console_render()` moved to its own
libkos member, restoring the accepted 6,790-byte monitor identity; the monitor
module list now includes `idle`/`idle_halt`; and the console-buffer probe has
its local `idle` stub. The final clean gate and focused serial rerun pass.
