# Task

**Device events**: an application subscribes to events on a device handle,
and the nucleus delivers them to it signal-style, at a safe point, **only
while that application is running**. The driver keeps owning the
interrupt; the application never claims one. First event source: the
timer's channel-3 event timer, with exact deadlines.

Read: `work/00-WORKER.md`; architecture 4.5 (interrupt executive), 4.7
(processes), 4.9-4.10; the 51b record (`KOS_OP_RELEASE`); the 53 timer
driver; the Zephyr-80 `Z80 Peripherals Controller.md` (CTC).

## Prerequisite: the geometry race

`Makefile` (`$(GEOMETRY_INC) $(GEOMETRY_MEMORY):`, around line 346) is a
two-target rule, so a parallel build runs `mapcheck.py geometry derive`
twice; the second run rewrites the include while `bank7_end.asm` reads it
(about one clean build in five fails with a phase error). Make it a
grouped target (`&:`), so one run produces both files. Verify with five
clean parallel builds (`make clean && make`), all green.

## Rules (the design; do not change them)

| state of the subscribing process | event |
|---|---|
| its own code runs (interrupted latch mode 10, PC below `E000h`) | delivered when the interrupt returns |
| inside its own syscall or IPC call | held (counted) and delivered when that syscall returns to it |
| its handler is running | held; delivered after the handler returns (never nested) |
| a child it started is running | dropped; `missed` counts it |
| it exited / unbound the handle | the subscription is gone |

- Held events coalesce: the handler receives `count` (events since the
  last delivery, at least 1) and `missed` (dropped since the last
  delivery). Nothing is queued.
- The handler is ordinary application code in the primary image, with
  interrupts enabled. It may call the SDK and IPC. It must not touch state
  the interrupted code may be half-way through (say so in `docs/sdk.md`).

## Requirements

1. **Nucleus: state and calls.**
   - Table `KOS_EVENT_MAX` = 4: owner pid, handle, handler, pending,
     missed; plus a per-process `in_handler` flag. In common memory (the
     delivery code reads it in mode 10); record the ledger.
   - `event_post(sub)` (driver API, ISR-safe): owner running → `pending++`,
     else `missed++`; saturate at FFFFh.
   - `NOTIFY` {handle, handler}: subscribe (0 = unsubscribe); the nucleus
     sends `KOS_OP_SUBSCRIBE` (sub id in the frame) to the handle's
     endpoint; a driver without events refuses (`KOS_ENOTSUP`).
     `EVENT_RETURN`: see the algorithm. Next free syscall numbers; record.
   - Exec: the child runs → the parent's posts count as `missed`. Exit
     and unbind free the subscription (driver hears `KOS_OP_RELEASE`).

### The delivery algorithm (implement exactly this)

**Frame** (on the program's own stack, from the new SP upward, 24 bytes):
`latch, 0, HL', DE', BC', AF', IY, IX, HL, DE, BC, AF, PC`.

**Deliverable** = some sub of the running process has `pending > 0`, its
`in_handler` is 0, the interrupted/caller latch is mode 10 over that
process's bank, and the code it returns to had interrupts enabled.

**A. Interrupt exit** (`kernel/irq/entry.asm`, after `out` of the saved
latch, still on the transition stack, interrupts masked):
1. Read the interrupted PC at `irq_saved_sp + 2` (the stub pushed AF at
   `irq_saved_sp`). Deliverable and PC < `E000h` → continue; else the
   normal exit (the event stays pending).
2. Copy the saved registers from the transition stack into the frame
   below `irq_saved_sp`; [AF][PC] already there complete it. Store the
   saved latch in the frame.
3. Pick the lowest sub with `pending > 0`: snapshot `count = pending`,
   `missed`, zero both; set `in_handler = 1`.
4. Output the latch with the page field cleared (primary mapping), set
   SP = frame, load HL = count, DE = missed, BC = handler, and leave
   with the normal exit's `EI` / `RETI` (53 adds the `EI`), but to the
   libkos trampoline `kos_event_entry`.

**B. Syscall exit** (`kernel/syscall/entry.asm`, after restoring the
caller latch and SP, before the result registers are rebuilt):
1. Deliverable (saved IFF = 1) → build the frame with the **result**
   registers (A, carry in F, HL) and the preserved ones; the caller's
   return PC is already on its stack. Then steps A3-A4.
2. Else the normal return.

**C. Trampoline** (libkos, primary image, never in a far segment): call
`handler(count, missed)` with the SDK's C convention, then `RST 30h` with
`A = EVENT_RETURN`.

**D. `EVENT_RETURN`**: the frame sits just above the trampoline's RST
return address on the caller stack. Clear `in_handler`. If another event
is deliverable, reuse the same frame (A3-A4 again: no second frame).
Otherwise, in common code: output the frame's latch (the exact interrupted
latch, page included), set SP to the frame, pop it in reverse, `EI`, `RET`
to the interrupted PC.

**Constraint to check first:** the frame is pushed with the interrupted
latch, and popped after restoring it, so the program stack must never be
inside the `8000h-BFFFh` aperture. Confirm from the SDK's stack placement;
if it can be there, stop and report.

2. **Timer event source** (the 53 driver):
   - Channel 3, timer mode, prescaler 256 (25.6 µs counts).
   - `KTIMER_OP_EVENT` {period in counts, 0 = stop}; one subscriber
     (`KOS_EBUSY` for a second).
   - Exact deadlines: keep an absolute deadline in counts; each channel-3
     interrupt loads the next chunk's time constant (at most 256 counts,
     the remainder last) and posts when the deadline is reached, then adds
     the period. No drift; period ≥ 1 count.
   - Quiesce stops channel 3 as well.
3. **SDK** (`kos/event.h`, short names):
   - `int notify(int handle, void (*handler)(unsigned int count, unsigned int missed))`;
   - `int timer_event(int handle, uint32_t period_counts)`;
   - the trampoline and `EVENT_RETURN` live in libkos, not in programs.
4. **Docs.** Architecture: the rules table and the mechanism in 4.5/4.10,
   the timer event in the devices part, and remove the item from 14.
   `docs/abi.md` (`NOTIFY`, `EVENT_RETURN`), `docs/sdk.md` (handler rules),
   `docs/devices.md` (`KTIMER_OP_EVENT`).

## Tests

- **Host:** table logic (subscribe/unsubscribe/full; pending vs missed by
  owner state; coalescing); the chunk sequence for 20 ms, 1 count, and a
  period of exactly 256 counts.
- **Simulator replay** (a test program in the `fs` image):
  - 20 ms period for 1 s of simulated clocks: 50 ± 1 deliveries, and
    deadline error ≤ 2 counts each (read `now` in the handler);
  - main loop doing console writes and a card read: events landing inside
    them are delivered after return, none lost;
  - `run` of a child during events: `missed` > 0 afterwards, no delivery
    while the child ran;
  - the handler itself calls `console_write`;
  - exit with an active subscription; a second program can subscribe.
- Measure: delivery cost in T-states and CPU share at 50 Hz (expect ~2 %).

## Owner checklist (hardware)

`/system/beat.exe` (store, small): subscribes at 500 ms and toggles a 440 Hz
SN76489 tone each event, for 10 s, printing `count/missed`. Check by ear
and stopwatch; then run it while `ls /fs` repeats.

## Constraints

- Nucleus changes: the table, `event_post`, the two return-path checks,
  `NOTIFY`, `EVENT_RETURN`. Nothing else. Record every ledger.
- Record: `docs/validation/<date>-m12-device-events.md`.

## Validation

Nucleus change: run once, at the end:

```sh
make clean && make check
make fs-selftest
make console-serial-selftest
git diff --check
```

While developing: `python3 -m unittest tests.test_events tests.test_timer`
and `make fs-selftest`.
