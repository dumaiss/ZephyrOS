# Correction 01: split the subsystem acceptance image in two

Runs after 53b. Test side only: production, the kernel, the drivers and
the SDK keep their bytes. Targeted validation.

## Problem

`make subsystem-selftest` no longer links: with the device-event code the
image's cold code ends at `DC52h` and its 1,735 cold-data bytes do not fit
below `E000h` (about 1.1 KB short). Acceptance test objects compile cold
by rule (Makefile, "Acceptance images compile their target-test objects
cold too"), and the subsystem image carries five groups of them. The
owner chose to split the image, keeping that rule and every test.

## Requirements

1. **Two images, one system file each.**
   - `systems/subsystem.json` keeps the syscall-gate and IRQ groups
     (`syscall_test`, `syscall_selftest_asm`, `irq_test`,
     `irq_selftest_asm`, `ctc_test`) and the monitor session.
   - A new `systems/process.json` carries the ROMFS and process/EXE groups
     (`romfs_test`, `process_test`) with the store those need (the EXE
     fixtures, `exe2*`, the truncated and wrong-type entries).
   - Name the second image `process-selftest` (`build-process-selftest`),
     with its own Makefile target and suffix row, in the `SYSTEM_*` tables
     and the image matrix wherever `subsystem-selftest` appears
     (`hardware-images`, `serial_smoke.py` if it has a mode for it).
   - `kernel/main.c`'s acceptance runner selects the groups by the image's
     flags; each image runs only its own groups and reports them.
2. **Point every consumer at the right image.** `tests/test_subsys_sim.py`
   (the syscall/IRQ groups and the monitor session),
   `tests/test_romfs_sim.py` and `tests/test_exe.py`'s image-reading rows
   (`process_expect.inc`, `exe2*.exe`, the recovery store, the modules
   directory) move to `build-process-selftest`; split a module only where
   it reads both.
3. **Room.** Record each image's cold code end and room; each must keep at
   least 1 KB of cold room so the next kernel package does not break it.
4. No assertion is weakened or dropped: every group runs every check it
   runs today, and every replay test still runs (on one image or the
   other). Record the test count before and after.

## Validation (targeted)

```sh
make                          # production unchanged
make subsystem-selftest
make process-selftest
python3 -m unittest tests.test_exe tests.test_source_layout tests.test_systemgen
git diff --check
```

Record: an addendum to `docs/validation/2026-10-14-m12-device-events.md`.
