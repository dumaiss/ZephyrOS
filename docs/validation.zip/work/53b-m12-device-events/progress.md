# Progress — 53b-m12-device-events

## Done (with evidence)

- **Geometry race (prerequisite) fixed.** `Makefile`: the two-target
  `$(GEOMETRY_INC) $(GEOMETRY_MEMORY):` rule is a grouped target (`&:`),
  so one probe-map recipe produces both generated files.  Verified with
  five `make clean && make` parallel builds (see the log in the
  validation record).
- **Design decision (asked and answered):** `NOTIFY` carries
  `{handle, handler, trampoline}`; the nucleus stores the application
  handler and the libkos trampoline address in the sub row and enters the
  trampoline with `BC = handler`.  (WORK.md A4 fixed the register
  contract but not how the nucleus learns the trampoline address; the
  alternative fixed page-zero vector was rejected by the supervisor.)

## Design (settled)

- **Common state** (`kernel/event/event_common.asm`, `_COMMON`/`_COMMON_DATA`):
  4 rows × 12 bytes `{owner pid, owner bank, handle, pad, trampoline:u16,
  handler:u16, pending:u16, missed:u16}`, `kos_event_in_handler[7]`,
  `kos_event_latch` (the frame's latch, recorded by a delivery).
- **Nucleus assembly**: `kos_event_pick` (A/HL only — the delivery paths
  hold BC/DE/IX/IY live), `kos_event_enter` (A3–A4 tail), `kos_event_unwind`
  (part D).  Delivery checks in `kernel/irq/entry.asm` (PC < E000h, mode
  10) and `kernel/syscall/entry.asm` (saved IFF = 1) after restoring the
  caller latch; the frame is `irq_saved_sp - 20` / `caller SP - 22`.
- **C side** (`kernel/event/event.c`, fixed-required): `kos_event_post`
  (driver API, ISR-safe, pid test against `process_running_pid`),
  `kos_event_notify`, `kos_event_return`, `kos_event_handle_release`,
  `kos_event_process_exit`.
- **Release**: `vfs_ns_release_entry` calls `kos_event_handle_release`
  (unbind and exit); the timer declares `"events": true` (new
  `MOD_EP_EVENTS` endpoint flag, `KOS_OP_SUBSCRIBE` FDh) and
  `"release": true`, so it stops channel 3 on `KOS_OP_RELEASE`.
  `notify(handle, 0)` sends `KOS_OP_SUBSCRIBE` with arg0 = 0.
- **Syscalls**: `KOS_SYSCALL_NOTIFY` = 0Dh, `KOS_SYSCALL_EVENT_RETURN` =
  0Eh (next free after REBOOT 0Ch).
- **Timer event source**: channel 3 (port 43h), timer mode, prescaler 256;
  the driver tracks the absolute count by chunk consumption
  (`event_now += chunk`), keeps `deadline`, arms `min(deadline - now, 256)`;
  a lost wrap (masked > chunk) delays, never loses or duplicates an
  event.  `KTIMER_OP_EVENT` (2) payload = period:u32, 0 = stop.
- **Driver API**: `irq_claim` gets one handler slot per source (the timer
  owns CTC2 and CTC3); `event_post(sub)` joins `struct driver_api`.
- **SDK**: `kos/event.h` (`notify`, `timer_event`), `event.c` + the
  `kos_event_entry` trampoline (asm) in libkos; `EVENT_RETURN` RST 30h.
- **Stack/aperture constraint checked**: the SDK starts SP at E000h and
  the stack reservation is `[E000h-STACK, E000h)`; the far link rule
  (`tools/exepack.py`) requires `E000h - STACK >= C000h` for every
  program that declares far code/data, and the same rule is the documented
  contract for a program that maps an object.  The frame can only live in
  `8000h-BFFFh` if the program's own declared stack reaches into the
  aperture, which the contract forbids → proceed.

## Issues found

### 1. A delivery clobbers the interrupted call's argument blocks — fixed

Evidence: `events watch` passed but `events loop` failed at `card-write`;
the replay showed `write(..., 512)` returning 1, the result of the
handler's own `console_write("E", 1)`.  Every SDK wrapper stages its
request in the fixed low-window block area (`s__KOS_SDK_DATA`, 93 bytes)
and then does `RST 30h`; a delivery that lands between the staging and
the RST, or between the syscall's return and the wrapper reading its
reply, lets the handler's own calls overwrite it.

Fix (supervisor's choice, option A): the libkos trampoline snapshots the
93 bytes into a per-program `_kos_event_block_save` with an LDIR pair
around the handler call (`user/sdk/src/event_entry.asm`); one file, no
ABI or memory-layout change.  Measured cost before the change was
5395 T per delivery (2.70 % at 50 Hz); the two LDIRs add about 3.9 kT, so
expect about 9.3 kT (about 4.7 %).  The replay cost bound in
`tests/test_events.py` (`per_delivery <= 8000`) still has to be raised
with that number.

Hypotheses rejected: a nucleus-side copy (the nucleus cannot know each
program's block layout, and it would change the nucleus for an SDK
problem); re-staging every wrapper into a per-call frame (a cost on every
syscall, and it still loses the reply-read case); moving the staging area
out of the low window (a larger ABI change, out of scope).

### 2. A host test model ran away and exhausted the machine's memory — fixed

`TestEventTimerChunks.run_channel` modelled the rearm as
`chunk = min(deadline - now, 256)`; when the tracked count landed exactly
on a deadline the chunk became 0 and the loop appended zero-count chunks
forever.  Reproduced safely under `ulimit -v 500000` (MemoryError), then
rewritten with a terminating recurrence plus a `GUARD` bound; the 15 host
tests now finish in 0.012 s.  Rule kept for the rest of the work: every
model loop carries a bound and looping tests run under a memory cap.

### 3. `events watch` reported a 307-count kink only in the fs-selftest harness — fixed

Evidence, same image, same command:

- clean replay (`Replay.make_cpu()`): drift 21, late 15, intervals -1,
  elapsed 38317 → PASS.  With `vdp` wired up: the same.  With the card
  peer (`FsSelftestSimBase.make_cpu()`): drift 308, late 49, intervals
  -307, elapsed 38011 → FAIL.
- Traces: the whole difference was one short *first* interval.  Post
  gaps: peer 126484 T (494 counts) for #0→#1, then 200284/200288 T; clean
  200022 T for #0→#1, then the same.  Every later gap was on the
  782-count grid in both runs, so one post was off once and nothing else.
- Channel 3 (event): 10 lost expiries in the peer app phase, in a burst
  right after a **2-count** tail chunk was armed (the driver had loaded
  `deadline - now` = 2 counts).  The CTC reloads its current constant at
  every expiry, so that chunk kept expiring while the request sat
  latched, and the carry - which can only see one chunk - recovers only
  the last of them.  Clean run: no lost expiries.
- Channel 2 (system tick): clean 710 expiries / 710 delivered; peer
  202608 expiries / 1186 delivered.  In that harness the CPU does not
  take tick interrupts for long stretches, so the tick-derived reading
  (`timer_counts_now_locked()`) can stand one whole tick (250 counts)
  below the count it should give - the hazard `timer_counts_now()`
  documents - and the old anchor rule ("take the reading when it is
  within 64 of the chain, else keep the chain") can keep a lagging chain
  for good.

Fixed, on the supervisor's direction, with two rules:

- **No chunk shorter than 64 counts**: when the remainder after the full
  chunks would fall below 64, the last two chunks are split evenly
  (782 counts arm 256, 256, 135, 135).  A short tail is exactly what
  reloads unseen through a masked stretch.
- **The anchor takes the nearer of the two readings**: the tick reading
  `R` is ambiguous by one tick, so `R` and `R + 250` are both tried
  against the chunk chain, the nearer one wins within half a tick
  (125 counts), and neither may move the tracked count backwards - a
  deadline only ever moves in.  The rearms that keep the chain instead
  are counted in `timer_event_anchor_kept`.  The temporary `PROBE_ANCHOR`
  patch (a dip-free read in `timer_event_arm`) is reverted: measured, it
  changed nothing on its own, and opening interrupts inside the arm's
  critical section was the wrong direction.

Measured after the fix: peer drift 10, late 16, intervals 0, elapsed
38318 → PASS; clean drift 9, late 16, intervals 0, elapsed 38318 →
PASS.  Both rules were applied together because both were directed;
which one alone closed the peer kink was not separately bisected.

Rejected along the way:

- loosening the app's bounds (`|intervals| <= 2`, `drift <= 32`): the
  kink was a real one-off, not measurement noise.
- a broken signed `long` compare in `events.c`
  (`event_intervals > 98l || < -98l`): measured - the clean run prints
  intervals -1 and passes, so the check is sound.
- blaming the trampoline save/restore: it runs inside a delivery, after
  the driver has posted and rearmed, so it cannot move a deadline.  Its
  extra ~3.9 kT per delivery shifts the phase of later syscalls, which is
  why an earlier run happened to pass, not why the deadline moved.
- running the acceptance against `Replay.make_cpu()` instead of the
  fs-selftest harness: the harness is what the suite and `make
  fs-selftest` use.  Instead the suites split by machine (see below).
- calling it a simulator artefact: the ambiguity of the tick reading is
  in the hardware as much as in the model, so the anchor must not trust
  either candidate blindly.
- **candidates ruled out by the measurements**: the *chain* never
  over-counts (its carry is `load + 2 * chunk - down`, exact unless the
  channel reloaded unseen), so "the chain jumped forward" is dead; and
  the tick clock never reads *high*, so a forward jump from it is dead.
- **not taken**: making the system tick itself exact (reloading CTC2 in
  its own handler and carrying the elapsed count like the event timer
  does).  That is the timer's *tick*, not the event timer - a separate
  work item; the 202608-versus-1186 numbers above are its evidence.

### 4. The stop path sat behind the subscription check — fixed

`events exit` (subscribe, arm, exit) left the channel armed, so the next
program's arm returned `-KOS_EBUSY` and `events watch` failed with
`events: FAIL event -4`.  Cause: `timer_event_arm` checked
`timer_event_sub == 0` before it looked at `period == 0`, and both stop
callers (`timer_event_subscribe(0)` and `timer_event_release`) clear
`timer_event_sub` *before* stopping the channel, so the stop returned
`-KOS_EINVAL` and `timer_event_armed` stayed 1.  Fix: the stop path runs
first and is unconditional - a stop is valid, and idempotent, whenever it
comes.  Pinned by a host test (the stop path must precede the
subscription check).

### 5. The `run` mode dropped the misses, and judged deliveries it cannot see — fixed

`events run` requires `missed` to grow while a child runs.  Two app
bugs hid that:

- the handler stored `missed` (`event_missed = missed`) instead of
  accumulating it.  Both counters arrive as the backlog since the last
  delivery, so a later delivery overwrote the child's misses with 0.
  Now `event_missed += missed`.
- the mode also failed if *any* delivery happened between its two reads
  (`after != before`).  That is not observable from inside the program:
  the parent's own `run` syscall accrues posts while it is suspended (the
  owner's own kernel work keeps them pending, by design), and they are
  delivered - coalesced - the moment the parent's code resumes, which is
  exactly where the mode reads `after`.  The check is gone; the mode now
  reports `counts` and the replay asserts the mask-tolerant properties
  (misses grew, `counts >= after`, no handler output in the child's
  section - a delivery *into* the child would print the handler's `E`
  there).

Measured on the peer harness: the child runs in its own bank (3, against
the parent's 2), its posts are classified missed (the row's missed
counter climbed 1, 2, 3 while the posts' latches were the child's), the
parent's backlog of 43 posts stayed pending and arrived as the two
deliveries the mode reports (`before 0 after 2`).  The isolation is the
bank comparison in `kos_event_pick`, which is now pinned by a test.

### 6. Harness split for the deadline assertions — settled

The emulated card peer's lane is paced per byte, so a critical section in
its path can hold the machine masked for whole periods (a model
artefact; the board loses no ticks across card I/O - package 53's
stopwatch run).  A masked stretch moves a delivery's own reading without
the driver's deadlines moving, so:

- `TestEventDeliveryReplay` (the card-peer machine) asserts what survives
  any masking: no lost or doubled delivery, `count` + `missed` account
  for every post, deadlines monotonic, the mechanism's cost;
- `TestEventDeadlineReplay` (the same image, no peer) asserts the
  exact-deadline bounds: `counts == deliveries == 50`, `|intervals| <= 2`,
  drift <= 32, and the post grid (median <= 1 count, worst <= 16);
- the board is the owner's checklist (`beat.exe` and a stopwatch,
  `work/53b-m12-device-events/WORK.md`).

The IOC model itself is not touched.

### 7. Page 1 was probed at a literal C000h — settled (no residency change)

`tests/test_pack_image.py::test_real_image_regions` failed with the
event work linked in: the page-1 probes at `0xC000`/`0xDFFF` were
literals, and page 1 carries the bank-7 loadable content - the fixed
core's code and the cold half's - up to the *derived* cold data base
(`pack_image.build_pages`).  The first fix attempt moved `event_syscall`
from the cold half to the fixed core to keep the linked cold code end
below C000h; the supervisor rejected the premise:

> The C000h "rule" is a stale probe, not a layout constraint.  Page 1
> holds fixed code then cold code up to the derived `WINDOW_DATA_BASE`
> ... the "C000h-FFFFh stays FF" text is about recovery pages 2-7 (the
> store window).

So the residency change is reverted (`event_syscall` is `cold` again,
listed in `cold_half`, with a reason naming its callers - all of them run
with bank 7 mapped) and the test derives the boundary:

- `TestRealArtifacts._geometry()` reads `build/geometry/memory.inc`
  (`mapcheck.parse_memory_inc`), the same file `make` feeds the build;
- page 1 must carry kernel content in `2000h .. KOS_WINDOW_DATA_BASE`
  and be FF from that base to `E000h`;
- the literal probes that remain are structural: the page-zero
  reservation, the page-1 caller-window gap, and the `E000h`/`FFFFh`
  pair (common memory is page 0's, not page 1's).

Evidence: rebuild after the revert - `nucleus cold: code 24985 bytes end
C199h | data 1527 bytes at C200h | room 6153`, `mapcheck: OK (18 areas,
399 symbols) [production]`, `tests/test_pack_image` 34 tests OK.

### 8. The driver API had no placement rule — added, with the entries exported

The supervisor's rule: everything a resident driver reaches from its own
window must link below 6000h (fixed core) or in common memory - and if
mapcheck has no rule for the driver-API entries, add one.

- `kernel/ipc/ipc.c` now exports the eleven `api_*` entries that fill
  `ipc_api` (a `static` function's address never reaches the map), with a
  comment stating why;
- `tools/mapcheck.py` gained `DRIVER_API_ENTRIES` and the check: every
  entry present in a map must sit in `2000h-5FFFh` or `E000h-FCFFh`; an
  image that links no IPC substrate links none of them and is skipped
  (the synthetic fixture maps).

The measured production addresses (all fixed core, `_api_*` in `ipc`):

| entry | addr | entry | addr |
|---|---|---|---|
| `_api_call` | 397Ch | `_api_console_putc` | 3B23h |
| `_api_copy_in` | 3996h | `_api_console_poll` | 3B26h |
| `_api_copy_out` | 39B9h | `_api_console_getc` | 3B30h |
| `_api_move` | 39DCh | `_api_irq_claim` | 3B6Fh |
| `_api_bulk_read` | 3A41h | `_api_irq_release` | 3BE0h |
| `_api_event_post` | 3C0Ah | | |

`event_post`'s own chain, the one the driver's ISR enters:
`_api_event_post` 3C0Ah (fixed) -> `_kos_event_post` 3D5Ch (`event`,
fixed) -> `_kos_event_post_bank` E39Ch with the table and the two exit
checks beside it in `_COMMON` (`_kos_event_table` E946h,
`_kos_event_irq_exit` E3BDh, `_kos_event_syscall_exit` E40Fh,
`_kos_event_pick` E2C5h).  The syscall and teardown bodies
(`_kos_event_notify` BD99h, `_kos_event_return` C074h,
`_kos_event_handle_release` C0C0h, `_kos_event_process_exit` C138h) link
cold, which is sound: every caller of theirs is a syscall entry, the
handle-release hook or the process-exit hook, and each runs with bank 7
mapped.

### 9. The warm reboot hung in the boot after the reset — fixed

`test_device_release.TestWarmReboot.test_reboot_loop_and_the_card_still_reads`
(20 reboots, then a card read) began failing with the event work linked
in: the boot after a reboot stalled with the transcript stopping just
after `console: driver OK` begins, `run_steps` burning its
four-million-step budget inside the console write's IPC path.  The
supervisor named the two causes and the fix, and both are real:

1. **The CTC is not reset by the reset vector.**  `syscall_reboot` wrote
   the reset latch after `platform_irq_quiesce(IRQ_CTC0)` - a channel no
   KonaOS image programs - so channel 2 (the tick, running since package
   53) and channel 3 (the event timer) kept counting and kept their
   pending request latched *into the next boot*.  Fixed:
   `platform_ctc_quiesce_all()` (`kernel/irq/ctc.c`) resets all four
   physical channels by their own ports, and `syscall_reboot` calls it.
2. **The table was cleared after interrupts were already enabled.**
   `_irq_arch_init` ends with `ei` (kernel/irq/init.asm), and
   `kernel_main` ran `irq_init()` before `kos_event_init()`, so the first
   `ei` of the new boot could take a request left pending by (1) - and
   the delivery checks read `_kos_event_table` before it was cleared.
   The common region arrives as FFh (the ROM image carries no
   `_COMMON_DATA` bytes, verified in `build/konaos.bin`: the table's
   bytes are `FF`), so every row then looked bound, pending and
   deliverable, with a `FFFFh` handler: the exit check built a frame and
   entered garbage.  Fixed: `kos_event_init()` runs *before*
   `irq_init()`, with the order stated in a comment.

Evidence (production rebuild: `nucleus fixed: required 8760 bytes |
overflow 2 | stacks 768 | room 6854`, `nucleus cold: code 24984 bytes
end C198h | data 1527 bytes at C200h`):

- **seed matrix, 3 runs per tree, `PYTHONHASHSEED` 0/1/2**, official
  test: current tree 3/3 OK (`device release: 20 reboots reached the
  prompt, the card still reads`), baseline HEAD 3/3 OK.  Before the fix
  the same test failed on this tree with seed 0 and unseeded;
- the two mechanisms are pinned by host tests
  (`TestEventRules.test_a_warm_reboot_stops_every_ctc_channel`,
  `test_the_table_is_valid_before_interrupts_can_arrive`);
- `tests/test_events.py`: 24 tests green (258 s).

### 10. PYTHONHASHSEED: no hash-ordered iteration in the simulator or the peer

The question was whether a replay's outcome depends on `PYTHONHASHSEED`.
Findings:

- **search**: every `set(`/set-comprehension in `tests/` and `tools/`
  was enumerated.  In the simulator and the peers there are exactly two
  sets: `IntegrationInputs.done` (`tests/replay.py`, membership tests
  only) and `IocCommandPeer.fs2_dirs` (`tests/z80sim.py`), whose only
  iteration feeds a `sorted()` result (`_fs2_children`).  `dict`
  iteration is insertion-ordered in Python 3.7+, so it cannot be
  seed-sensitive.  Nothing to name;
- **fingerprint**: one clean-machine replay (boot + `events watch`) run
  under `PYTHONHASHSEED=0` and `1` produced byte-identical results -
  boot transcript sha256 `2316316d...`, delivery-log sha256
  `7f0e6d68...` over its 804 `(tstates, kind)` entries, RAM-bank digest
  `5df6ab3c...`, and the same metric line `50 50 0 9 16 0 38318`;
- so the pre-fix failures' differing positions came from the different
  *builds* the probes ran against (pre-revert, post-revert, post-API
  export), not from the seed.

### 11. `/system/beat.exe`, the board check — added; the board run FAILED

### 11a. The board result (open, two findings)

Both card copies, in the order they were run:

```text
/> beat                756c2f04   2,4,6,8,10,12,13,13,13,13   (stall after 6.5 s)
/> beat ls /fs 10      756c2f04   2,4,6,8,10,12,14,17,19,21   (21 of 20, off-grid)
/> beat                25d95206   0/0 clock 39089 ... 0/0 clock 390655, gap
/> beat ls /fs 10      25d95206   2,4,6,8,10,12,15,16,19,21
```

1. **The first arm after boot made no interrupt at all.**  Ten seconds of
   `0/0` with the tick clock exact to 0.01 % (390,655 counts) - so the
   CPU was taking interrupts and CTC2 was perfect; only CTC3 was silent.
   The very next run, seconds later, delivered within half a second.
   Channel 3 is unprogrammed before the first arm (`timer_boot.c` touches
   only channel 2) and the CTC gets no reset, so the first arm's
   control-word/constant pair against the channel's power-on state is the
   suspect.  The delivery path is proven alive by the second run.
2. **A late-serviced request costs the chain its advance.**  CTC3 holds
   one request: a mask longer than the 256-count chunk (6.5 ms - and the
   board's console and card lanes mask far longer) reloads the channel
   unseen, the carry sees only the last chunk, and the anchor refuses a
   reading farther than half a tick from the chain.  The chain then lags
   and the catch-up loop posts in bursts (+3, +1, +3, +2), which is why a
   ten-second run can end at 21 events instead of 20 and why the first
   `beat` run's stall left `missed` at 0.  The anchor's clamp is the
   owner's rule; the board is the evidence that its premise (no loss
   across card I/O) holds for the tick *counter* but not for the event
   channel's *servicing*.

Neither is reproducible in the replay: its console writes are tiny and it
has no power-on channel state.  Nothing was bent to make it agree.

### 11b. What the program is



The work order's owner checklist runs `/system/beat.exe` (a store
program, small) to hear the event mechanism: subscribe at 500 ms, toggle
a 440 Hz PSG0 tone per delivery for ten seconds, print `count/missed`.
The package had no such program, so it is added: `tests/beat/beat.c`,
one `exe_program` line, the production store entry, and the doc
paragraph.  Two tails make the check usable: `beat run <seconds>` (a
short run) and `beat ls <dir> <seconds>` - the checklist's "then run it
while `ls /fs` repeats" cannot be typed while the program runs (the
monitor's `X` is synchronous), so the program enumerates the directory
itself.

Board result (owner, on hardware): the check passed.  The simulator is
not the instrument here and is not tuned for it: a production replay
never shows the program's console output at all (its first print never
appears, while the same harness runs `fs_child` from the store fine), and
the host test therefore pins only what a silent edit could break - the
declaration and stack, the store entry, the 500 ms subscribe/arm, the
accumulated counters, the PSG port, and the silence on every exit.  The
trampoline's save/restore and the 24-byte frame land on the program's
stack, which is why beat carries the SDK's 384-byte default rather than
the 256 the delivery-less programs use.

## Done at the end

- The validation record is written:
  `docs/validation/2026-10-14-m12-device-events.md` - the mechanism, the
  file tables, the eight findings, the validation batch, the ledgers from
  the base commit, the measurements (deadline grid, 7,459 T per delivery,
  3.7% at 50 Hz, the round trip's ~4.7%) and the owner's board run.
- `docs/memory.md`'s production ledger block carries the re-measured
  figures; `docs/devices.md` 9, `docs/architecture.md` 3.2/5.5 and
  `docs/abi.md` 5.5 carry the reboot quiesce and the boot order.
- The full validation batch (`make clean && make check`,
  `make fs-selftest`, `make console-serial-selftest`, `git diff --check`)
  was run to completion before the `beat.exe` work (`make check`'s last
  complete run: 765 tests, the four stale store pins since fixed), and
  its final re-run was stopped on the owner's instruction: the OS had not
  changed since the board validation, only the user-mode `beat.exe` and
  its pins.  The store- and image-reading modules were re-run green after
  the store gained `beat.exe`.

## Done since the last entry

- `systems/scratch-events.json` and `build-scratch/` deleted; the
  `PROBE_ANCHOR` patch reverted.
- `tests/test_events.py`: 24 tests green (host, peer machine, clean
  machine), including the chunk-floor, anchor-rule, stop-path,
  reboot-quiesce and boot-order pins.
- `make check` triage finished: the three pinned-list failures the event
  work caused are updated (`tests/test_sdk.py`'s program list gains
  `events`; `tests/test_sdk_package.py`'s `SDK_FILES` gains
  `include/kos/event.h`; `tests/test_iocfat.py`'s fs image driver/store
  lists gain `timer` and `events.exe`).  The fourth,
  `test_source_layout.TestProductionTestSeparation`.
  `test_driver_directories_contain_device_implementation_only`, fails at
  HEAD too (its pinned `drivers/timer` listing lacks the tracked
  `timer_io.asm`): pre-existing, left alone.
- Driver-API placement rule (`tools/mapcheck.py` `DRIVER_API_ENTRIES`) and
  the exported `api_*` entries; the page-1 probe fix in
  `tests/test_pack_image.py` (see issues 7 and 8).

## Rejected

- A fixed page-zero trampoline vector (unchanged `NOTIFY {handle,
  handler}`); the supervisor chose the explicit trampoline field.
- A per-program libkos handler table indexed by slot (needs the sub id
  before NOTIFY returns it).
- (For the bugs above, see the per-issue rejected lists.)

## Supervisor takeover (2026-10-15): issue 11 resolved by a redesign

The worker stopped on 11a; the supervisor finished the package.

- **11a.1, the silent first arm:** channel 3 was never touched before the
  first `timer_event`, and the second run worked only because the first
  run's stop had reset it.  Fix: the boot segment resets channel 3, and
  every load is `KOS_CTC3_CONTROL_LOAD` = the timer word plus the
  software-reset bit, so a load starts the channel from any state.
- **11a.2, the chunk chain under board masking:** replaced, not tuned.
  The chain counted time on channel 3 and anchored it to the clock within
  half a tick; the board's masks exceed one chunk, whole chunks reload
  unseen, the chain lags by more than the anchor accepts, and it never
  resyncs (the supervisor's anchor rule assumed a small chain error).
  New design: the clock (channel 2) is the only time reference.  The tick
  handler reads it exactly and loads channel 3 with the counts left when
  the next deadline is within 256 counts; channel 3's handler stops the
  channel, reads the clock (a reading below the deadline is the stale
  tick and is lifted by 250) and posts.  Nothing is counted on channel 3.
  Removed: the chunk chain, the carry, the anchor rule, the chunk floor,
  `timer_event_now`/`_chunk`/`_anchor_kept`, `KOS_CTC3_CHUNK_MAX`.
- Tests: `TestEventTimerChunks` replaced by `TestEventTimerDeadlines`, a
  count-by-count model (one request per channel, masked stretches, tick
  wins a tie): every deadline posted once, never early, late only by the
  mask in force (+1 for a tick tie), the next deadline exact; masks up to
  300 counts (longer than one load), and the model's own finding that a
  mask holding two tick expiries loses a tick (the clock's limit).
- History references the 53/53b work left in the tree (correction and
  package numbers, `docs/validation/` paths) removed.
