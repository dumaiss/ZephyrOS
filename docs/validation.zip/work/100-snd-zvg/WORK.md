> Worker package. After 99. `docs/snd-sdk.md` section 4.5: ZVG (ZVGC
> v1/v2) pre-rendered streams through the reader, with foreground
> prefetch and an assembly decoder on the tick. VGMPlayer becomes a
> libsnd client. No OS change.

# Task

The `snd_zvg_*` API:
- **Validate and prefetch in C:** `snd_zvg_open`/`prepare`, the ring
  filled by `snd_service`.
- **Decode in assembly on the tick:** complete commands from the ring,
  the bytes written to one chosen PSG.
- **Move VGMPlayer onto it,** with its trace unchanged.

## Current state

- **The reference decoder:** `UserSoftware/VGMPlayer/vgmplay.c`
  `decoder_tick`, with ring head/tail bytes and `validate_header`. Its
  own double buffer plus `fread` refills: replace them, don't copy them.
- **The format:** a 16-byte header (`ZVGC`, version 1 or 2, a rate of
  1-180 Hz, header length 16, the stream length, the tick count), then
  `00h` END, `01h b` WRITE, `02h lo hi` WAIT16 (nonzero),
  `40h-7Fh` WAIT 1-64, `80h-8Fh` + 1-16 bytes WRITE RUN. The bytes are
  one SN76489's.
- **Already in place:** 97's ZVG goldens and harness, 98's output engine
  and tick, 99's reader and `kos_reader_read_full`.
- **VGMPlayer's base timer** is 180 Hz with a phase accumulator, because
  the file rates (for example 60) don't divide the timer evenly. libsnd's
  rate is the file's; the application times `snd_tick` with
  `snd_timer_period`.

Read: `work/00-WORKER.md`; `docs/snd-sdk.md` 4.1, 4.5, 6, 7; `vgmplay.c`
and its README; 97's and 98's records.

## Requirements

1. **Open and validate (C)** (Must). `snd_zvg_open(reader, chip)`:
   - the header checks, exactly `validate_header`'s, plus the
     reader's size against the declared length;
   - the chip in 0-3, and its four voices free;
   - on success the chip's voices are reserved; on failure nothing
     changes.
2. **Prefetch (C, foreground)** (Must):
   - a ring of documented size (`SND_ZVG_RING`, a power of two), with
     byte head and tail, the producer `snd_service` and the consumer the
     tick;
   - `snd_service` reads at most one bounded chunk per call through
     `read_at`, and publishes the new tail only after the bytes are in;
   - `snd_zvg_prepare` fills the ring before `snd_zvg_play`;
   - I/O errors are kept and reported in the status.
3. **Decode (assembly)** (Must). In `snd_tick`, for an active ZVG:
   - per tick: the wait counter, then complete commands up to the next
     wait or the end;
   - WRITE and WRITE RUN bytes go to the chip: DIRECT straight to its
     port, BATCH appended to the tick's batch;
   - **the shadow:** a ZVG chip bypasses the shadow, which is marked
     uncertain for that chip and refreshed when the ZVG stops;
   - an incomplete command at the head is an underrun (section 6.3):
     mute the chip, count it, and resume when `snd_service` refills.
     Never a partial command;
   - a malformed opcode is an error state, muted, with the offset kept;
   - END finishes playback (the `DONE` state, the chip silenced, the
     reservation kept until `snd_zvg_stop`/`close`).
4. **Control and status (C)** (Must). `snd_zvg_play`, `stop`, `close`
   (forget the source, close nothing) and `get_status`: state, ticks,
   bytes, writes, underruns, last error and offset. While a ZVG is
   active, `snd_tick_rate` is its rate.
5. **VGMPlayer** (Must). `UserSoftware/VGMPlayer`:
   - on SDK 0.2.0 and `LIBS=snd`, with the stdio reader;
   - timed by `snd_timer_period`, calling `snd_tick(count)` from the
     handler and `snd_service` from the foreground loop (keep `idle()`);
   - its private decoder, ring and buffers deleted; the same report at
     the end (ticks, writes, underruns, missed);
   - the README updated.
6. **Docs** (Must): `docs/sdk.md` (ZVG playback, ring size, costs);
   `docs/snd-sdk.md` 4.5 confirmed or corrected from the build.

## Tests

- **Target:** `tests/snd/sndtest.c` mode `zvg FILE CHIP`, and VGMPlayer,
  replayed:
  - each ZVG fixture's per-tick trace equals 97's golden, in DIRECT and
    BATCH, on chip 0 and on chip 2 (the bytes the same, the port
    moved);
  - VGMPlayer's trace equals the golden;
  - a reader that stalls (the fake, a delay at a chosen offset) gives
    a counted underrun, a muted chip, no partial command, and exact
    resumption;
  - each malformed fixture is refused at open, or stops at its opcode,
    with no write to the card;
  - the tick path makes no reader call (count `read_at` calls between
    tick markers);
  - manual notes on a free chip play during a ZVG, and are refused on
    its chip.

## Budgets (CPU T-states, interrupts out)

Measured by the timing mode of `tests/test_snd.py` (PC-attributed tick
intervals; the interrupt path and the sound_write delivery that frames
each marker are excluded).  A wait-only tick costs 609 T-states whole:
323 is the engine's documented idle pass, 286 is the ZVG's own wait
path - inside the 300 target.  A command tick costs 859: 250 over the
wait tick is the decoder's fixed command-loop entry (ring checks and
the consumed-bytes count); the marginal per written byte within a run
is 0-15, inside the 50 target.  Tick 0 additionally carries the
one-time 4,652-T-state shadow rewrite of the reserved chip.

| figure | now | target | on overrun |
|---|---|---|---|
| ZVG tick, a wait only | 286 (609 whole) | <= 300 | report with a profile |
| ZVG tick, per written byte (DIRECT) | 0-15 marginal (250 fixed loop) | <= 50 | report with a profile |
| `snd_service`, one chunk | 0 on the tick path | report | - |
| OS bytes | unchanged | 0 | stop and report |

## Owner checklist

- On the board: `vgmplay /fs/MUSIC.ZVG` plays as before, with the end
  report clean (0 underruns, 0 missed).
- `sndtest zvg` on chip 2 plays the same music.

## Validation

Develop with single tests by dotted name. Run the block once, at the end.

```sh
make && make sdk && make -C UserSoftware/VGMPlayer test
python3 -m unittest tests.test_snd tests.test_sdk_package tests.test_source_layout
make clean && make check
git diff --check
```

Record: `docs/validation/<date>-snd-zvg.md`.
