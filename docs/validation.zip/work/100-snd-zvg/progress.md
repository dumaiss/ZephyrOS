# 100-snd-zvg progress (present tense)

- Package 100 is complete: all 18 tests in tests/test_snd.py pass,
  including the five TestSndZvg tests (golden traces on chips 0 and 2
  in DIRECT and BATCH, malformed-fixture outcomes, the stall
  contract, manual-note refusal on the reserved chip, the reader-call
  and budget report).

- Shipped:
  - user/sdk/snd/src/snd_zvg.c: open/validate exactly the reference's
    checks plus the reader's size against the declared length, the
    chip's four voices reserved; the 256-byte ring prefetched by
    snd_service (one bounded chunk per call, tail published after the
    bytes are in) and snd_zvg_prepare; play/stop/close/get_status.
  - user/sdk/snd/src/snd_zvg_dec.asm: the per-tick decoder - wait
    continuation in the same tick, WRITE/RUN bytes to the chip
    (DIRECT to its port, BATCH appended), WAIT16-zero error, counted
    underrun vs truncated stream at the EOF, the three-byte mute,
    END with no writes.
  - snd_out.asm: SND_BATCH_MAX 44->60; the flush preserves the ZVG's
    pre-appended pairs and runs on a non-empty batch; the count
    resets on the write outcome paths.
  - The VGMPlayer rework: SDK 0.2.0, LIBS=snd, the stdio reader,
    snd_timer_period + snd_tick(count) in the handler, snd_service +
    console_poll + idle in the loop, the report from
    snd_zvg_get_status (ticks, bytes, writes, underruns, missed).
  - The oracle rewritten standalone (tests/snd/oracle/zvg_trace.c):
    the goldens and the malformed table reproduce byte for byte; the
    dead console/event/timer host stubs are gone.
  - sndtest modes zvg FILE CHIP [batch], zvgstall FILE CHIP and
    zvgnotes FILE CHIP.

- Measured budgets (the WORK.md table carries the profile): a
  wait-only tick is 286 T-states of ZVG work (609 whole with the
  engine's idle pass) inside the 300 target; the per-byte marginal is
  0-15 inside the 50 target, with a fixed 250-T-state command loop
  reported; snd_service costs nothing on the tick path.

- Docs: docs/sdk.md, docs/snd-sdk.md 4.5 (corrected from the build),
  docs/validation/2026-10-25-snd-zvg.md.
