> Spike package. Worker. Production code is unchanged: a new bench
> program under `tests/bench/`, its build rule, one test, the record.
> Baseline: HEAD at start (record the commit).

# Task

Measure what a direct-write text renderer (font in CPU RAM, glyph bytes
written to VRAM through the data port, the SymbOS method) would gain over
the console's HMMM renderer, on the same realistic text, before any RAM
is spent on it in the driver tier. The renderers live in a user program,
so their size is free here; the record reports their size so the cost of
moving one into the driver can be judged.

## Current state

- Board (package 76 record): `con.mixed` 3,782 T-states per char,
  `con.held` (call chain, no rendering) 147, `vdp.hmmm6` 3,383 per copy,
  `vdp.hmmm12` 4,636, `vdp.direct.on` 1,686 per 6x8 glyph of constant
  bytes, `vdp.direct.off` 1,631.
- `tests/bench/iobench.c`: `make_mixed_text` (the `con.mixed` text),
  the VDP hold (`bench_video_hold`, `unbind`), `vdp_reg`, the summary
  block (`sum_add`, `sum_report`), the timer instrument (`row_begin`,
  `batch_begin`, `batch_end`, `row_report`).
- GRAPHIC 6: 512 x 212, 4 bits per pixel, 256 bytes per line, a 6-pixel
  cell is 3 whole bytes. The console: 85 x 26 cells, normal pixels
  `04h`/`0Fh` (packed fill `44h`), reverse = byte XOR `BBh`, vertical
  scroll through the R#23 origin (`drivers/v9958/v9958.c:v9958_scroll_up`,
  `v9958_row_vram_y`).
- Font: `drivers/v9958/assets/font_cp850_6x8.inc`, packed by
  `tools/fontpack.py` (2,048 bytes; bits 7..2 of a row byte are the six
  pixels, `v9958.c:v9958_expand_row`).
- A program's initialised non-const static array does not link (`_GSINIT`
  after the based `_KOS_SDK_DATA`); build tables at run time or use
  `static const` (package 76 record).

Read: `work/00-WORKER.md`; the package 76 record; the files above;
`tests/test_io_sim.py`; `tests/test_tui_sim.py:decode_v9958_screen`.

## Requirements

1. **Program** (Must): `tests/bench/textbench.c` (+ `.asm` as needed),
   built as `/system/textbench.exe` beside `iobench.exe`. It renders the
   `con.mixed` text (same generator, shared or copied) from a cleared
   screen at the home position, once per row below, with the timer
   instrument and the closing summary of `iobench`.
2. **Rows** (Must), T-states per character:
   - `txt.console`: the text through `console_write` in 256-byte calls
     (the baseline; equals `con.mixed`).
   - `txt.glyph1`: holding the VDP; per glyph, eight scanlines of
     "set address, three `OUT (A0h)`", bytes expanded from the 1-bit font
     through a 64-entry, 3-byte table (normal), XOR `BBh` for reverse.
   - `txt.glyph6`: as `txt.glyph1` from a pre-coloured 6,144-byte font
     (24 bytes per glyph, `OUTI`), no expansion.
   - `txt.run1` / `txt.run6`: per run (the printable bytes up to a control
     byte or the right margin): for each scanline one address set, then
     three bytes per glyph of the run; 1-bit expanded and pre-coloured.

   The direct rows own the text model themselves: CR, LF, wrap at 85,
   and scrolling as the console does it (R#23 origin plus one HMMV for the
   exposed row). They are written in assembly, unrolled where it pays.
3. **Same pixels** (Must, structural): in the simulator, after each direct
   row the page-zero bitmap equals the `txt.console` row's screen, cell
   for cell (decode both to cells if the peer does not apply HMMM to
   VRAM; state which in the record). The test is
   `tests/test_textbench.py` on the production image.
4. **Split** (Must): for every row, the simulator's CPU-only T-states per
   character (the model has no WAIT) beside the board figure; the
   difference is the V9958 wait per character.
5. **Sizes** (Must): code and table bytes of each direct renderer, and
   the font bytes, from the link map: what the driver tier would carry.
6. **Production unchanged** (Must): `git diff --stat` shows only
   `tests/`, the build rule and the record; the production image hash is
   recorded.

## Budgets

None for production. `textbench.exe` must load; record its size.

## Criteria

- **Must:** requirements 1-6; the validation below green.
- **Informational:** every figure; chars/s at 10 MHz per row; a full
  85 x 26 screen's time per row.

## Simulator

`V9958Peer` models neither the V9958's WAIT nor its access slots, and its
command busy is 400 instructions. Its CPU-side figures are exact; the
board supplies the wait.

## Owner checklist

- Copy the image and `textbench.exe`; run `textbench` at the shell
  prompt; photograph the summary. Run it twice.

## Validation

```sh
make && python3 -m unittest tests.test_textbench tests.test_io_sim tests.test_source_layout
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-direct-text-spike.md`: the per-row table
(simulator CPU, board, wait, chars/s), the renderer sizes, the
same-pixels evidence, the board summary (PENDING until the owner runs
it). No recommendation beyond what the numbers show.
