# Package 77 — direct-text spike — working memory

## Tree state at start

- HEAD `de3bf64`.  Dirty files = package 74 correction + package 76's
  bench (evolved by the supervisor: `vdp.hmmm` split into `vdp.hmmm6` /
  `vdp.hmmm12`, direct rows re-described, the `sum:` summary block, the
  board numbers recorded).  Preserved; this package adds tests/bench/
  files, the textbench build rule, tests/test_textbench.py and the
  record.  No commit.

## Owner note

- Do NOT run `make clean && make check` at the end: production code is
  unchanged.  Validation = `make && python3 -m unittest
  tests.test_textbench tests.test_io_sim tests.test_source_layout` +
  `git diff --check`.

## Verified facts (from v9958.c / v9958_driver.h / hardware.h)

- DISPLAY_OFFSET = 4; R#23 = origin - 4 (mod 256); origin 0 -> R#23 =
  0xFC (KOS_V9958_R23_TEXT_BASE).  decode_v9958_screen uses reg23+4.
- Pair tables (normal): [44, 4F, F4, FF] mapping pixel pair 00,01,10,11
  (pixel on = F, off = 4); reverse = XOR 0xBB per byte.
  expand_row: dst[0]=pair[(bits>>6)&3], dst[1]=pair[(bits>>4)&3],
  dst[2]=pair[(bits>>2)&3].  So the 64-entry 3-byte table indexes with
  v = font_byte >> 2.
- clear_screen: origin=0; R#23=FC; one HMMV DX=0 DY=0 NX=512 NY=256
  CLR=44h (attr 0); wait.
- scroll_up: origin=(o+8)&0xFF; HMMV DY=origin-4 NX=512 NY=4 CLR=44h
  (the fixed margin above row 0, hidden except near the ring wrap);
  fill_cells(0,25,85,1) = HMMV DX=0 DY=(origin+200)&0xFF NX=510 NY=8
  CLR=44h split at physical line 255 like fill_cells; wait; R#23 =
  origin-4.  LF at row 25 keeps row 25 (the console's newline col=0;
  term_lf restores col, which is 0 anyway for CRLF text).
- row_vram_y(row) = (row*8 + origin) & 0xFF; cell address =
  Y*256 + col*3 (3 bytes per scanline, 4bpp G6).
- Data-port writes select the page through R#14 (R#14=0 -> page 0);
  address set = low byte, high|0x40 through the command port.
- The mixed text (snprintf ls-style, < 80 cols, CR LF, padded with
  spaces to 2000) never wraps at 85 and scrolls ~10 times per pass
  (origin ends ~80, so the bottom-row fill DOES cross Y=255 -> the
  split path must be implemented).
- iobench.c now has `sum_add`/`sum_report` (the owner's summary block):
  copy its shape for textbench (textbench: summary + sum: lines).

## Design decisions

- textbench prints nothing during a row: per-row mode = render
  (measured), unbind, `console_read` wait, then the row line, then
  exit.  The test snapshots at the first entry to `_console_read`
  (symbol from the program map) - a clean state (no report glyphs yet)
  - and then sends a key for the row line.  The console row's clear
  (`ESC [2J` full-screen HMMV 512x256 CLR 44h) is the uniquely
  identifiable command that starts the reference decode.
- No-arg run: all five rows + the closing summary (owner checklist).
- The 1-bit font is generated into the program's object directory by
  tests/bench/font2c.py from the pinned .inc (single source); the
  6,144-byte pre-coloured font and the 192-byte expand table are built
  at run time outside the measured batch (the _GSINIT trap).
- Direct rows live in textbench.asm (model + render, unrolled); the
  scroll and the HMMV clear stay in C (called from asm).
- textbench.exe is NOT added to the production store (the image stays
  byte-identical); the owner copies the exe to the card like READPH.

## Status

- [ ] Write tests/bench/font2c.py; Makefile rule + textbench_INCFLAGS.
- [ ] tests/bench/textbench.c (generator copy, instrument copy,
      vdp helpers, clear/scroll, main with modes + summary).
- [ ] tests/bench/textbench.asm (four renderers with the text model).
- [ ] tests/test_textbench.py (same-pixels per row, sizes from the map,
      row-line shape).
- [ ] make && unittest tests.test_textbench tests.test_io_sim
      tests.test_source_layout; git diff --check.
- [ ] docs/validation/2026-10-21-direct-text-spike.md (per-row sim
      table, board PENDING, sizes, same-pixels evidence, image hash).

## Final status — 2026-10-21, complete except owner board run

Two renderer bugs found by the same-pixels test and fixed:
- glyph6_cell held its OUTI source in HL; cell_base /
  address_set_next clobber HL -> raw text bytes landed in VRAM.
  Fixed with push/pop HL around both calls.
- flush_run1 / flush_run6 zeroed _textbench_run_len before reading it
  as the glyph count (B=0 -> djnz 256 times).  Fixed: the length now
  survives the flush (zeroed after the glyph loop, before ret).

Final figures (simulator CPU-only):
- txt.console 4,646 T/char; txt.glyph1 3,367; txt.glyph6 2,798;
  txt.run1 2,792; txt.run6 2,392.
- Map sizes: glyph1 56, glyph6 56, run1 125, run6 125 code bytes,
  shared block 117; font image 2,048; expand 192 BSS; font6 6,144 BSS.
- textbench.exe 12,034 bytes, sha256
  d82da3a6f48d8906a31be47c8e8cebf8d41119e735297e6d53f92b458f156902.
- Production image unchanged: f3e9e5796e84...

Validation green: make; python3 -m unittest tests.test_textbench
tests.test_io_sim tests.test_source_layout (57 OK);
git diff --check clean.  make clean && make check waived (owner note).
Record: docs/validation/2026-10-21-direct-text-spike.md.
Nothing committed.

Status:
- [x] tests/bench/font2c.py; Makefile rule + textbench_INCFLAGS.
- [x] tests/bench/textbench.c (generator copy, instrument copy,
      vdp helpers, clear/scroll, main with modes + summary).
- [x] tests/bench/textbench.asm (four renderers with the text model).
- [x] tests/test_textbench.py (same-pixels per row, sizes from the map,
      row-line shape).
- [x] make && unittest tests.test_textbench tests.test_io_sim
      tests.test_source_layout; git diff --check.
- [x] docs/validation/2026-10-21-direct-text-spike.md (per-row sim
      table, board PENDING, sizes, same-pixels evidence, image hash).
