# Task

M10 stage 2 (architecture 36.24, step 2). Link the production nucleus as a
**fixed core** (`2000h-5FFFh`) and a **cold half** (`6000h-DFFFh`) under
revision 13. Make every gate normalize the page field P, and replace the M9
bank-7 budget with the M10 ledgers.

No feature is added, and the system behaves as at M9. This package
establishes the layout, the rules and their enforcement, so that later
stages can switch the window to bank 6 safely.

## Context

Read:

- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md`;
- `docs/architecture.md` 36.2, 36.5, 36.9, 36.10 and 36.20;
- the package-36 report (`docs/validation/2026-10-07-m10-two-bank-feasibility.md`),
  particularly §2-§3 (classification) and §7 (the linked spike layout);
- `tests/m10/two-bank-classification.json`;
- `tools/rev13_layout.py`, `tools/pack_image.py`, `tools/mapcheck.py`;
- `kernel/syscall/entry.asm`, `kernel/irq/`, `kernel/memory/`.

Package 37 is accepted: revision 13 is the only decoder and the simulator
default. The resident-service spike (`ZOS_RSVC_SPIKE`) is kept until
package 39 promotes it. It must keep passing here.

Until stages 4-5 move the drivers and the VFS to bank 6, bank 7 still holds
everything M9 holds, which does not fit 16 KiB fixed plus 32 KiB cold
under a strict split. Hence the placement rule below.

## Requirements

1. **Residency classification.** Promote the package-36 classification
   to a production source, for example `config/residency.json`, with one
   entry per kernel object.
   - Apply the fixed rule of 36.5 (code that executes, or data that is
     touched, while the window shows another bank). Under that rule
     `process`, `process_exec`, `module_loader` and `module_relocate` are
     cold.
   - Each entry is tagged `fixed-required`, `cold`, or `moves` (to bank 6
     in stage 4 or 5, with the stage named).
   - `tests/m10/two-bank-classification.json` becomes this file or is
     removed.
2. **Placement rule:**
   - `fixed-required` objects and data **must** link inside
     `2000h-5FFFh`.
   - Anything else **may** use leftover fixed space. Report that overflow
     separately.
   - `cold` and `moves` objects fill the cold half.
   - The ISR stack (256 bytes) and the service stack (512 bytes, unused
     until stage 3) are reserved in the fixed core now.
   - The driver arena moves to the cold half and keeps its current
     contents. Replace the 32-granule floor with a check that the boot
     modules fit.
3. **Enforcement.** `tools/mapcheck.py` fails the build when:
   - a `fixed-required` symbol lies at or above `6000h`;
   - any region overflows;
   - an object is missing from the classification.
4. **Ledgers.** `tools/pack_image.py` emits the five ledger lines of
   36.20 in place of the M9 `bank7:` line:
   - `nucleus fixed:` (required, overflow, stacks, room);
   - `nucleus cold:`;
   - `service hot:` and `service boot/bulk:` (0 until stage 4);
   - `common:`.
   The gate-stack worst case is reported as before.
5. **P-normalizing gates:**
   - **Syscall entry** saves the whole latch (Q, mode, P), dispatches with
     P = 0, and restores the saved latch exactly on exit.
   - **IRQ entry** saves the latch in its own slot and dispatches
     nucleus-owned handlers with P = 0. Nucleus-owned handlers include
     drivers still in the arena. IRQ exit restores the latch exactly, and
     never disturbs the slot of an interrupted call (36.10).
   - **Every other latch writer** in the nucleus and in common either
     preserves P or sets it deliberately. List each writer in the report.
6. **Upcall shim.** Add the fixed primitive described in 36.5: save the
   latch, select a window page, call, restore. Exercise it in a test image
   against a fixed-core test routine. Nothing in production calls it yet.
7. **Documents.** Update the layout and the ledger lines in
   `docs/memory.md`.
8. **Build fix (package 37, finding 2).** The SDK/ZEX `zex_program` rule
   lists no header dependencies, so a stale client object can mask a real
   failure. Give it proper header dependencies.

## Constraints

- Behaviour is unchanged: the same boot, the same console, the same
  filesystem. The production image bytes change; record the new hash.
- Do not move any driver or VFS code out of bank 7, and do not add IPC.
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation

```sh
make clean && make check             # new production hash; ledgers; mapcheck rules
make m9-selftest
make console-integration-selftest    # IRQ + console under the new gates
make rsvc-spike-selftest             # the spike uses the gates; it must still pass
git diff --check
```

Add one test image or test for the upcall shim and the P-normalization
(syscall with P ≠ 0 on entry; IRQ arriving with P ≠ 0). Build nothing
else. Target: under 20 minutes.

Hardware (owner): run `make smoke-hardware` on the board. Bank switching is
hardware-authoritative.

## Acceptance criteria

- The production image boots and behaves as at M9.
- The five ledger lines are emitted, and every `fixed-required` object lies
  below `6000h` (mapcheck-enforced).
- The syscall and IRQ gates normalize P and restore the latch exactly
  (tested).
- The upcall shim exists and is tested.
