# 106 progress

STATUS: reading contract and references; no edits yet.
Pre-existing: untracked PDF (user), work/106-hid-mouse/ + work/README.md line (supervisor). Preserve.
Baseline (make, HEAD, before edits): driver hot 31268/32768 (free 1500); nucleus fixed required 9664, data 920, room 5950; cold code 25087, data 1543, room 6137.
Production publications before: console, input(group), input/keyboard, video, serial(group), serial/0, ioc, timer, sound = 9 rows (to verify).
Decision note: test_hid.py pins hid.json endpoints, packed publications and production store list exactly; Requirement 3/5 force these three pins to change (test artifact, source = WORK.md Req 3 and Req 5). Keyboard expectations untouched.

## Plan (verified names exist: hid_fetch, hid_driver, hid_driver_dispatch, hid_driver_init, _handle_request, _build_hid_reply, dev.c:130, VFS_NS_PUB_MAX 12, IPC_ENDPOINT_MAX 12, TYPES)
1. ioc_protocol.h: mouse vocab, pin 75, move IOC_RSP_UNKNOWN_CMD here from drivers/ioc/ioc_proto.h (HID needs it; private header must not be included by HID). Fix "never modified" in ioc_proto.h comments too.
2. object.h KOS_TYPE_MOUSE 11, protocol.h KOS_CLASS_MOUSE 11 + KMOUSE protocol, modpack TYPES, dev.c range.
3. hid.c/hid_driver.h/hid.json: mouse endpoint hid_mouse_dispatch; separate penalty/backoff.
4. SDK mouse.h/mouse.c, exe.mk list, sdk test lists.
5. tests/mouse/mouse.c + Makefile exe_program + production.json store (+ console-serial? no: only production).
6. z80sim mouse_reports/mouse_faults.
7. vfs.h 16 + comment; modpack plan-level row check uses MAX_PUBLICATIONS(12, per image) as provider table size -> add NS_TABLE_ROWS=16 for the plan check (else 16 unreachable). Report as deviation-note.
8. hwtest namespace stage bind /dev/input/mouse (owner checklist).
9. tests/test_mouse.py; docs.
Pins to change: test_hid manifest endpoints / packed publications / store list; test_ioc level 74->75; test_systemgen/test_v9958/test_hwtest store lists; reserve pins x4 (if needed).
- Driver built: hot 31268 -> 31530 (+262), free 1238 < 1472. Reserve lowered to 1216 in test_iocfat, test_pack_image, test_sound, architecture 9 (WORK.md budget rule). Tried smaller forms: shared-frame (+300), null-src single loop (+266); kept two-loop local-frame form (+262). Pointer-to-static zero array refused by modpack (byte-fragmented reloc).
- Cold data 1543 -> 1623 (+80, the table), cold room 6137 -> 6057. Fixed unchanged.

## Failures (focused run after implementation), all classified before any pin edit
- test_hid.test_manifest_shape: endpoints list lacks mouse endpoint. test artifact; source WORK.md Req 3 (hid.json adds endpoint class 11).
- test_hid.test_packed_container: publications ['/input/keyboard'] only. test artifact; WORK.md Req 3 (publication /dev/input/mouse).
- test_hid.test_system_file_and_boot_order: store list lacks mouse.exe. test artifact; WORK.md Req 5 (/system/mouse.exe) + owner checklist.
- test_ioc.test_general_api_keeps_mcu_command_numbers_private: pins 'IOC_FW_LEVEL_PINNED   74u'. test artifact; WORK.md Req 1 (pin becomes 75), firmware include/ioc_frame.h IOC_FW_LEVEL 75.
- test_systemgen.test_production_store_is_the_canonical_order: store order. test artifact; WORK.md Req 5.
- test_sdk.test_every_program_is_declared_once_by_the_generic_rule: program list lacks mouse. test artifact; WORK.md Req 5 (exe_program STAGE=1).
- test_sdk_package.test_the_tarball_holds_the_pinned_layout: include/kos/mouse.h not in pinned layout. test artifact; WORK.md Req 4 (standalone SDK).
Also to update w/o failure: test_v9958 store list (same as test_hid), test_hwtest STORE_PROGRAMS (check), test_ns_selftest TYPES (add MOUSE), test_source_layout owner files (add).
- test_console_acceptance.test_boot_lanes_and_driver_store: pins one endpoint+publication per image. test artifact; WORK.md Req 3. NOTE contract conflict: Invariants say test_hid/test_console_acceptance green "without edits to their expectations" but Req 3 (Must) changes the hid image's endpoint/publication shape those files pin. Edited only the image-shape/store pins; no keyboard/console behaviour expectation edited. Report to supervisor.
- Implementation + docs done. Focused modules green (test_hid, test_mouse, ns, pack_image, iocfat, sound, console_acceptance, hwtest_sim, ioc, systemgen, sdk, sdk_package, source_layout, mod, v9958). ns-selftest built + its tests green.
- test_mouse informational: mouse_track ~31,897 T with IOC command, ~12,707 during penalty.
- NEXT: pre-check broader quick modules, then final validation batch once (WORK.md order).
- test_shell_sim.test_file_commands: `ls /dev/input` now lists keyboard + mouse. test artifact; WORK.md Req 3 (publication /dev/input/mouse).
- test_timer.test_the_resolved_endpoint_and_store: assumes endpoint number = driver's load-order place; hid's second endpoint shifts timer to 7. test artifact; WORK.md Req 3 (endpoint +1). Fix: number = endpoints of earlier drivers + 1 (the packer's numbering).
- FINAL VALIDATION started; sources frozen.
- DONE. Final batch green (v1 125 OK/1 skip; ns-selftest OK; make check 1024 OK/119 skip, 867 s). Hash 4bbf0030...3665b. Record docs/validation/2026-10-31-hid-mouse.md.
