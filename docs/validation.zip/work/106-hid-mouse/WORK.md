> Worker package. After 105. The HID driver gains a mouse endpoint and
> `/dev/input/mouse`; the SDK gains `kos/mouse.h`. IOC firmware is fixed
> at level 75 (Zephyr-80 repo): do not touch it. No pointer drawing (next
> package). Baseline: HEAD; `docs/KonaOS Programmer's Guide.pdf` is user
> work, untracked: preserve.

# Task

The IOC firmware (level 75) serves `CMD_HID_MOUSE`: a keyboard/mouse
dongle's mouse, read and cleared per command. Expose it to programs:
a MOUSE protocol endpoint in the HID driver, published as
`/dev/input/mouse`, that forwards the controller's reply; an SDK client
that turns deltas into a clamped position. Policy (position, clamping)
lives in the SDK; the driver only forwards and protects the console from
a dead link.

## Current state

- Firmware contract (Zephyr-80 `Code/MCU/IOController`):
  `include/ioc_frame.h` (`CMD_HID_MOUSE`, `IOC_OFF_HID_MOUSE_*`),
  `src/handlers.c:handler_hid_mouse`, `src/ioc_hid.c:hid_mouse_take`.
  `12h` → `92h`, no request DATA, reply DATA 9 bytes: `0` flags (bit 0
  second HID interface mounted, bit 1 its reports decode as the mouse),
  `1` buttons held (bit 0 left, 1 right, 2 middle), `2` buttons pressed
  since the last read, `3-4` dx, `5-6` dy, `7-8` wheel (signed 16-bit
  LE, motion since the last read, capped ±32767; +dy is down). Reading
  clears dx/dy/wheel/pressed. A diagnostic-profile or older controller
  answers `RSP_UNKNOWN_COMMAND` (`FEh`).
- `drivers/include/ioc_protocol.h`: pins `IOC_FW_LEVEL_PINNED 74u` and
  says the firmware is never modified (stale).
- `drivers/hid/hid.c`: `hid_fetch` (one IOC command through
  `hid_api->call(..., KIOC_OP_COMMAND, ...)`, strict reply validation),
  `hid_driver` (stuck-doorbell penalty/backoff), `hid_driver_dispatch`,
  `hid_driver_init`. `hid.json`: one endpoint (class 4, instance 0), one
  publication `/dev/input/keyboard` type `INPUT`.
- Types/classes: `abi/kos/object.h` `KOS_TYPE_*` 1..10;
  `abi/kos/protocol.h` `KOS_CLASS_*`; `tools/modpack.py` `TYPES`;
  `kernel/vfs/dev.c:130` range check `type > KOS_TYPE_TIMER`.
- Capacities: `kernel/vfs/vfs.h` `VFS_NS_PUB_MAX 12` (the system-wide
  `/dev` table in `kernel/vfs/dev.c`, 20-byte rows; its comment counts
  stale roles), `VFS_NS_NAME_MAX 16`; `kernel/ipc/ipc.c`
  `IPC_ENDPOINT_MAX 12`. `tools/modpack.py` `MAX_PUBLICATIONS` is per
  driver image: unchanged.
- Driver hot tier: 31,268 of 32,768 used (`build/konaos.manifest.json`),
  free 1,500; reserve 1,472 pinned in `tests/test_iocfat.py:171-178`,
  `tests/test_pack_image.py:447`, `tests/test_sound.py:153`,
  architecture 9.
- Simulator: `tests/z80sim.py:IocCommandPeer._handle_request` answers
  `CMD_HID_INPUT` via `_build_hid_reply` with fault injection.
- Patterns: `user/sdk/src/timer.c` (open, type check, descriptor-less
  call); `tests/timer/timer.c` + `Makefile` `exe_program ... STAGE=1`;
  `tests/test_device_release.py` (outcome program replay with peers).

Read: `work/00-WORKER.md`; architecture 4.10, 5.3-5.6, 6.3, 9, 14;
`docs/devices.md` HID; `docs/sdk.md`.

## Requirements

1. **Protocol vocabulary** (Must): `ioc_protocol.h` gains
   `IOC_CMD_HID_MOUSE 0x12u`, `IOC_RSP_HID_MOUSE 0x92u`, the DATA
   offsets, `IOC_HID_MOUSE_LEN 9u`, the two flag bits; the pin becomes
   75 and the header describes the firmware as it is (no "never
   modified").
2. **MOUSE type and class** (Must): `KOS_TYPE_MOUSE 11u`,
   `KOS_CLASS_MOUSE 11u` (device families share the number);
   `modpack.TYPES["MOUSE"] = 11`; `dev.c` accepts up to
   `KOS_TYPE_MOUSE`. `abi/kos/protocol.h` documents the protocol:
   `KMOUSE_OP_READ (0)`, descriptor-less, returns 0 and the 9-byte
   report in the reply payload in the IOC layout, or a negative error;
   flags 0 means no mouse.
3. **Driver endpoint** (Must): `hid.json` adds endpoint (class 11,
   instance 0, `hid_mouse_dispatch`) and publication `/dev/input/mouse`
   type `MOUSE`. `KMOUSE_OP_READ` sends `CMD_HID_MOUSE` through the
   existing IOC dependency and copies the 9 DATA bytes verbatim after
   validating class, status and length. `RSP_UNKNOWN_COMMAND` → success
   with an all-zero report. A transport failure → all-zero report and a
   backoff on this endpoint: the next calls answer zeros without an IOC
   command, `KHID_STUCK_PENALTY` doubling to `KHID_STUCK_PENALTY_MAX`, a
   good reply clears it. Mouse state is separate from the keyboard ring
   and penalty; the keyboard path is unchanged. No position, clamping or
   scaling in the driver.
4. **SDK** (Must): `user/sdk/include/kos/mouse.h`,
   `user/sdk/src/mouse.c`, in libkos and the standalone SDK:
   - `struct mouse_report { uint8_t flags, buttons, pressed; int16_t dx,
     dy, wheel; }`; `int mouse_open(void)` (bind + type check, as
     `timer_open`); `int mouse_read(int handle, struct mouse_report *r)`.
   - `struct mouse { int handle; int x, y, width, height, wheel;
     uint8_t buttons, pressed, present; }`;
     `void mouse_init(struct mouse *m, int handle, int width, int
     height)` (centre, clear); `int mouse_track(struct mouse *m)`: one
     read, adds deltas, clamps x to `0..width-1` and y to
     `0..height-1`, accumulates wheel, ORs `pressed` (caller clears),
     sets `buttons` and `present` (flags bit 1); returns 1 when anything
     changed, 0 when not, negative on error.
5. **Outcome program** (Must): `tests/mouse/mouse.c` as
   `/system/mouse.exe` (`STAGE=1`). Bare: the owner check, one line per
   change (position, buttons, wheel) until a key. `stage`: the replay
   checks.
6. **Simulator peer** (Must): `IocCommandPeer` answers `CMD_HID_MOUSE`
   from a scripted queue (`mouse_reports`), an all-zero report when
   empty; faults `"unknown"` and a transport failure. Docstring cites
   the firmware functions above and what it does not model (USB, the
   decode, report timing).
7. **Publication table 16** (Must): `VFS_NS_PUB_MAX 16u`, room for the
   controllers' `/input/joy`, `/input/joy/0`, `/input/joy/1`; the `vfs.h`
   comment states the production rows and the reason for 16. Record the
   nucleus ledger change (80 bytes expected).
8. **Docs** (Must): architecture 4.10 (device names), 5.6 table, 9
   (reserve figure), 14 (item 1 keeps the pointer sprite and the
   controllers, named `/dev/input/joy/0` and `/1`); `devices.md` HID;
   `sdk.md` mouse; `docs/memory.md` ledger figures.

## Invariants

- Keyboard input, the doorbell, the console and `/dev/input/keyboard`
  unchanged: `tests/test_hid.py`, `tests/test_console_acceptance.py`
  green without edits to their expectations.
- The HID driver calls the IOC only through its dependency handle.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| driver hot free | 1,500 | the mouse endpoint | lower the reserve to no less than 1,024 in all four pins; below that stop and report |
| publications | count them | +1 row; capacity 16 | over 16: stop and report |
| endpoints | count them | +1 | over 12: stop and report |
| nucleus fixed/cold | ledger | +80 data (the table) | above that, or a ledger rule broken: stop and report |

## Criteria

- **Must:** `bind("/dev/input/mouse")` returns type MOUSE; a scripted
  replay shows deltas, clamping at both edges, wheel, the press latch,
  `present` 0 for `"unknown"`, and the backoff (no IOC command during
  the penalty, then recovery); keyboard tests unchanged; `make check`
  green.
- **Informational:** driver hot bytes added; one `mouse_track` call in
  T-states (simulator).

## Owner checklist

- Controller at level 75 (normal profile). Flash the image.
- `/system/hwtest.exe`: the namespace stage binds `/dev/input/mouse`.
- `/system/mouse.exe` with the dongle: position follows the mouse and
  stops at the edges; buttons and wheel report; keyboard still types.

## Validation

```sh
make && python3 -m unittest tests.test_hid tests.test_mouse \
  tests.test_ns_selftest tests.test_pack_image tests.test_iocfat \
  tests.test_sound tests.test_console_acceptance tests.test_hwtest_sim
make ns-selftest
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-hid-mouse.md`.
