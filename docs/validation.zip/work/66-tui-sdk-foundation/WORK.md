# Task

Establish the TUI SDK as a real, separately linked component: pin the public
core header, add `libtui`, teach the shared program rule to link optional SDK
libraries, ship the library in the standalone SDK, and implement the console
lifecycle and fixed logical geometry. This package does not implement the
screen map, text drawing, key decoder, or widgets.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`;
- `docs/konaos-tui-sdk-architecture.md`, sections 1-9 and 12-17;
- `user/sdk/exe.mk`, `mk/kos.mk`, `tools/sdkpack.py`;
- `tests/test_sdk.py`, `tests/test_sdk_package.py`;
- `user/sdk/src/console_proto.c` and `user/sdk/include/kos/console.h`.

## Requirements

1. Add the complete v1 `user/sdk/include/tui.h` surface from architecture
   section 9, with the numeric constants unchanged. Document the return and
   ownership rules from `work/TUI-REFERENCE.md`. It includes only public SDK
   headers.
2. Create `user/sdk/tui/src/` and a deterministic `libtui.lib`. Keep private
   state and declarations private to that directory. The first archive members
   implement:
   - `tui_init`, `tui_shutdown`;
   - `tui_get_size` returning 85 x 26;
   - `tui_begin`, `tui_end`, `tui_flush` with the transaction/error rules in
     the reference.
3. Lifecycle output uses `console_write`/`console_flush`: normal rendition,
   clear, home, visible cursor at init; normal rendition and visible cursor at
   shutdown. It contains no driver call, raw port access, lookup, or terminal
   capability probe.
4. Extend `exe_program` with `LIBS=` exactly as pinned in the reference.
   Existing declarations and their link maps are unchanged when `LIBS=` is
   absent. Add the in-tree archive rules without duplicating the standalone
   build logic.
5. Ship `include/tui.h` and `lib/libtui.lib` from `make sdk`. Update the
   package's exact file list, header-closure check, deterministic archive
   check, and forbidden-path check. Do not bump `KOS_SDK_VERSION` yet and do
   not change `EXE_ABI_VERSION`.
6. Add `tests/tui/tui_test.c` as `tui_test.exe`, linked with `LIBS=tui` and
   not stored in any system image. Its foundation mode initializes, verifies
   the size, writes one marker through ordinary console I/O, shuts down, and
   reports PASS.
7. Add the foundation checks to `tests/test_tui.py`. Prove the header values,
   archive membership, optional-library link order, no-TUI link-map absence
   for `hello.exe`, and TUI presence for `tui_test.exe`.

## Acceptance

- An ordinary SDK program has no TUI member or BSS cost.
- `tui_test.exe` initializes and shuts down without leaving rendition or cursor
  state dirty, on both console system builds in the simulator.
- An out-of-tree program copied beside the unpacked SDK builds with
  `LIBS=tui` and no repository path.
- Existing SDK examples build and run unchanged.

## Constraints

- User SDK, its build/package tooling, and TUI tests only. No kernel, driver,
  system manifest, firmware, or console protocol change.
- Do not add placeholder definitions for later APIs. A declaration may exist
  before its archive member; the staged test calls only implemented functions.
- Preserve the user's untracked architecture document unchanged.
- Record `docs/validation/<date>-tui-sdk-foundation.md` with archive members,
  archive size, `tui_test.exe` image/BSS sizes, and exact commands.

## Validation

```sh
make build/user/tui_test.exe build/user/hello.exe sdk
python3 -m unittest tests.test_tui tests.test_sdk tests.test_sdk_package
git diff --check
```

Do not run the full clean suite in this package; package 73 owns it.

