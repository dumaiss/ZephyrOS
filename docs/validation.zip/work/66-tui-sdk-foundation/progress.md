# Progress

## Done
- Read WORK.md, TUI-REFERENCE.md, architecture sections 1-9/12-17, worker rules.
- Inspected exe.mk, mk/kos.mk, sdkpack.py, test_sdk.py, test_sdk_package.py.
- Confirmed the architecture document is untracked and must stay unchanged.
- Added the complete `tui.h`, `libtui` foundation members, `LIBS=` link rule,
  SDK packaging and the package tests.
- Formal validation passed: 49 tests, 48 passed, 1 pre-existing image skip.
- Supervisor review passed: the focused suite plus source-layout checks ran
  101 tests (100 passed, 1 expected image skip), and independent simulator
  replays reached `tui: PASS` on both V9958/HID and serial consoles.
- Accepted 2026-10-18. Package 67 is the next dispatch.

## In progress
- None.

## Decisions
- libtui private state is split from the function groups so a flush-only
  program does not pull lifecycle code.
- The in-tree libtui archive is deterministic (`sdar -rcD`) and is also the
  archive sdkpack ships.
- `tui_test.exe` verifies lifecycle, geometry and nesting, then reports PASS
  after shutdown.

## Rejected
- No placeholder implementations for later TUI APIs.
- No replay test in test_tui.py: replay belongs to the screen-engine package,
  which adds test_tui_sim.py.
