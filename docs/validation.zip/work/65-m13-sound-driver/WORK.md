> Runs after 64. The `sound` driver, to the design in architecture 5.6
> ("Sound is lifecycle plus a coarse path"). The ABI (`abi/kos/ksound.h`,
> `KOS_CLASS_SOUND` in `abi/kos/protocol.h`) and the SDK client
> (`kos/sound.h`, `user/sdk/src/sound.c`, `sound_out.asm`) exist already:
> implement the driver behind them, do not redesign them.

# Task

A resident driver for the Afternoon Blend card: four SN76489 PSGs at
`E0h-E3h` (clock 3,579,545 Hz) and a DAC at `E4h`, published as
`/dev/sound` (type `SOUND`, class 9, instance 0).

Read: `work/00-WORKER.md`; architecture 5.6 (the sound design) and 4.10
(exclusive binds, release); `abi/kos/ksound.h`; `docs/devices.md` (the
timer and V9958 sections: release and ACQUIRE); `drivers/timer/` (the
smallest driver, its layout to follow); `user/sdk/include/kos/sound.h`.

## Requirements

1. **The driver** `drivers/sound/`: `sound.json`, a dispatch, and every
   port access in one `.asm` file (as the timer and V9958 drivers do).
   - **One reset routine**: `9Fh BFh DFh FFh` to each PSG, then the DAC's
     neutral code, `80h` (midscale; the owner has checked it does not
     click). It runs at init, at ACQUIRE, at `KSOUND_OP_RESET` and at
     the release of an exclusive hold (`KOS_OP_RELEASE`, `arg1` != 0). No
     shadow of the chips' registers.
   - **`KSOUND_OP_INFO`**: `struct ksound_info` in the reply payload:
     version 1, flags `DIRECT_IO | BATCH_WRITE | DAC`, 4 PSGs at
     `E0h-E3h`, the DAC at `E4h`, 3,579,545 Hz, reserved bytes 0.
   - **`KSOUND_OP_WRITE`**: the IN descriptor's pairs through a 64-byte
     `DRIVER_IO` buffer, `copy_in` per chunk.
     - An odd or zero count, or any target above 4, is `-KOS_EINVAL`
       **before any write**: validate the whole sequence first, chunk by
       chunk, then write it.
     - Returns the bytes consumed. The write loop is assembly.
   - **ACQUIRE** refuses a second hold (`-KOS_EBUSY`) and resets the card.
     **WRITE and RESET** are served on any handle.
   - Manifest: `"release": true`. No events, no IRQ.
2. **Images**: `sound` joins `systems/production.json` and every system
   file whose image runs a sound program or a sound test (after 3). Reports of the
   hot tier, the io block and the cold half's room, before and after.
3. **Room**: the driver tier keeps a reserve for planned drivers, and this
   is one. Lower `test_iocfat`'s reserve from 4,096 to 3,584 bytes free
   after every image is placed: the driver gets up to 513 bytes. Report
   its hot and io bytes; if it needs more, stop and report.
4. **Simulator**: a sound peer in `tests/z80sim.py` that records every
   write to `E0h-E4h` (port, value, T-state). Tests assert the sequences.
5. **Tests** `tests/test_sound.py`, plus a card program `tests/sound/`
   that drives the SDK, run from the production shell (as
   `tests/test_vblank.py` does):
   - INFO's whole record;
   - a batched write lands as exactly its `OUT`s, in order;
   - an unknown target or an odd count writes nothing;
   - a sequence over 4 KiB is split by the SDK and lands whole;
   - an exclusive open resets the card, and a second exclusive open is
     `-KOS_EBUSY`;
   - `sound_out` writes reach the ports;
   - close, and exit without close, both reset the card (the silence
     sequence after the program's last write);
   - the driver's init leaves the card silent.
6. **Docs**:
   - `docs/devices.md`: a sound section beside the timer's.
   - architecture 5.6: the `sound` row loses "the driver is the next one
     built".
   - `/dev/sound` and `SOUND` lose "later" in 4.10 and 6.1.
7. **Diagnostic I/O**: in-tree programs do not write `E0h-E4h` through
   `SYS_DIAG_IO_OUT`; find any with `rg` and move them to the driver.
   The owner moves `UserSoftware/VGMPlayer` and `UserSoftware/SNTracker`
   (out of scope here: do not edit `UserSoftware/`). The record lists, for
   each, the calls that change: `diag_io_out(PSG_FIRST_PORT + n, v)`
   becomes one `ksound_write` pair per byte, batched per tick into one
   `sound_write`, or `sound_out` under an exclusive open.

## Owner checklist

- `vgmplay` and SNTracker on the driver, after the owner moves them: plays
  as before. Quitting mid-song, or killing it with a reboot, leaves the
  card silent.

## Validation

```sh
make && python3 -m unittest tests.test_sound tests.test_sdk tests.test_sdk_package tests.test_iocfat tests.test_source_layout
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-m13-sound-driver.md`.
