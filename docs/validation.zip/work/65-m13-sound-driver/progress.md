# 65-m13-sound-driver - worker progress

## Done

- `drivers/sound/`: `sound.json`, `sound_proto.c` (dispatch, INFO,
  lifecycle, init) and `sound_io.asm` (reset, pair loop, chunked
  validate/write sequence; every `E0h-E4h` access).
- `systems/production.json`: `sound` before `iocfat`; the production
  driver set is eight images.
- `tests/z80sim.py`: `SoundPeer` records `(port, value, T-state)`.
- `tests/sound/sound.c` and `tests/test_sound.py`: the SDK card program
  and the production replay; the replay asserts the card's exact write
  sequence and the program's lines.
- `tests/beat/beat.c`: PSG writes moved from `diag_io_out` to the sound
  driver; `tests/test_events.py` follows.
- Docs: `docs/devices.md` section 10 and renumbering,
  `docs/architecture.md` (5.6, 4.10, 6.1, 9), `docs/abi.md`,
  `docs/vfs.md`, `docs/memory.md`, `drivers` test lists.
- `tests/test_iocfat.py` / `tests/test_pack_image.py` reserve 3,584
  bytes free.

## Numbers

- `sound` hot 442 + io 67 = 509 bytes; container 510; share 513.
- driver hot 28,671 -> 29,180 of 32,768; free 4,097 -> 3,588.
- driver I/O block 4,340 -> 4,408 bytes; io segment bytes 4,336 ->
  4,403.
- driver boot/bulk 19,598 unchanged; nucleus cold unchanged (room
  6,137).

## Decisions

- The reset is one `OTIR` loop over the four SN76489 silence bytes per
  PSG, then the DAC's `80h`.
- WRITE validates every chunk before the first `OUT`, then copies each
  chunk again and performs it; the 64-byte buffer is 32 pairs.
- The sequence calls the bootstrap `copy_in` through a local one-byte
  `jp (hl)`.  Linking `drivers/runtime/sdcc_indirect_calls.asm` would
  add 79 bytes and overrun the 513-byte share.
- `sound_write` checks the descriptor, a non-zero even count and the
  targets; `arg0` is the ABI's zero offset and is not otherwise used.

## Evidence

- Focused suite: 118 tests, OK (skipped=1), 53.0 s.
- `make clean && make check`: 801 tests, OK (skipped=115), 25 m 3.4 s.
- `build/konaos.bin`
  `236f5ed44403e9427a41899f37c7dbe0df837c1347f7d8b295db673e2d363d81`;
  `build/modules/sound.mod`
  `7089426cc61bf444af1b516ff54cfa0f3a6c98e12ae84a60f35f8bd3a362a215`.
- `git diff --check` clean; no stray generated file.

## Open

- Board check is the owner's: `vgmplay`/SNTracker on the driver, quit
  mid-song and a reboot leave the card silent.
- The hot tier has four bytes above the reserve; the next resident
  addition needs the budget revisited.

## Rejected

- A C write loop: the first cut was 342 bytes for `sound_write`, over
  the share; the assembly sequence replaced it.
- Linking the shared SDCC runtime: 79 bytes, over the share.
