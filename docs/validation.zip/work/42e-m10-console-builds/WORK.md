# Task

M10 step 8 (architecture 36.11): **consoles are selected per build.**
Replace the console driver's runtime choice between V9958+HID and serial
with two build-selected CONSOLE drivers, each host-wired to its
dependencies and each publishing `/dev/console`. No fallback at run time
(owner decision; a fallback console may come later as an ordinary driver).

## Context

Read:
- `work/00-WORKER.md`;
- `work/M10-REFERENCE.md` decision 12;
- architecture 36.11 and 36.12;
- `services/console/` and the console fallback tests;
- the package-42c record.

**Before starting:** check the 42c record; stop on a contradiction.

## Requirements

1. **Two drivers:**
   - `console-v9958-hid` (VIDEO + INPUT);
   - `console-serial` (SERIAL).

   Both implement CONSOLE with the existing protocol, and both declare
   host-resolved dependencies (41b). Shared code stays shared; don't
   duplicate it.
2. **Build selection.**
   - Production selects `console-v9958-hid`.
   - Add a `console-serial` production variant (the same image set with
     the other console) and a make target that builds it.
   - A required driver that fails to initialize is an explicit boot failure
     on the early console.
3. **Remove the runtime fallback logic:** the HID readiness probe that
   picks the input/output paths, and the fallback branches.
4. **ESC `c` check.** Add a tiny test program in `/SYSTEM` that writes ESC
   `c` and then a line of text, so the owner can check the display reset on
   the board. It is test-only content and not part of production.
5. **Tests.**
   - The runtime-fallback images and tests become: the `console-serial`
     variant boots to the monitor prompt on serial.
   - Delete the fallback-branch tests, with reasons.

## Constraints

- No protocol change.
- No sub-agents. Keep `progress.md`. The report is
  `docs/validation/<date>-m10-console-builds.md`.

## Validation

```sh
make clean && make check
make console-integration-selftest console-serial-selftest ipc-selftest
git diff --check
```

Hardware (owner):
- production: the keyboard, the V9958 and the ESC `c` program;
- the `console-serial` variant: the monitor prompt on `/dev/ttyUSB0`, and
  typing on serial.

## Acceptance criteria

- Two build-selected console drivers, and no runtime fallback.
- Both builds boot to `/dev/console`, on hardware too.
- ESC `c` is checkable on the board.
