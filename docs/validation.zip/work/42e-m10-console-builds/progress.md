# Package 42e progress (consoles selected per build)

Working state for `work/42e-m10-console-builds/WORK.md`. Report:
`docs/validation/2026-10-10-m10-console-builds.md`.

## Baseline

- Tree clean at `299f162` (42c M10). `make check` assumed green (42c record).
- 42c record checked: loader 1,986 bytes against the 2,000-byte review
  target; no contradiction with this package.

## Decisions taken

1. **One shared source, two images.** `services/console/console_service.c`
   compiles twice: `console-v9958-hid.rel` (HID input, VIDEO output,
   required deps 4.0 + 2.0) and `console-serial.rel`
   (`-DZOS_CONSOLE_SERIAL=1`; SERIAL both directions, required dep 1.0).
   The runtime probe and the fallback branches are deleted; the driver
   reads only its host-resolved dependency numbers.
2. **Build selection.** `ZOS_CONSOLE ?= console-v9958-hid`; the default
   production set is `sio ioc hid v9958 $(ZOS_CONSOLE) iocfat`.
   Subset images that have no HID+VIDEO pair select `console-serial`
   explicitly. `console-serial-selftest` builds the production image set
   with `ZOS_CONSOLE=console-serial` (production store manifest, monitor
   boot program).
3. **Required-driver init failure is explicit.** Every init entry returns
   a `uint8_t` status (sdcccall(1) leaves it in A; the upcall shim now
   publishes it in `zos_upcall_ret_a`). The loader refuses a non-zero
   status (`invalid`), and the nucleus returns from `kernel_boot_services`
   with a failure: it prints `console: service failed` after the loader's
   line and halts before the launcher. The console drivers return failure
   on a zero required dependency (a malformed bundle; the packer refuses
   a missing required dependency in a normal build). HID keeps its soft
   link policy - a down IOC link at init stays recoverable, so the
   serial-console build boots without the MCU - but fails init when its
   required dependency number is zero.
4. **ESC c check.** `tests/console/escc.c` (SDK program) writes ESC `c`
   and a line, then execs the monitor; the console integration image
   boots it (`ZOS_BOOT_PROGRAM=/SYSTEM/escc.zex`), so the owner sees the
   display reset on the board and the replay checks the reset path.
5. **Fallback images/tests are deleted** (runtime fallback is gone); the
   serial build is covered by `tests/test_console_serial.py` replaying
   `build-console-serial-selftest` to the monitor prompt on serial, and
   the required-console boot-failure image
   (`build-console-serial-fail-selftest`, a store that omits
   `console-serial.zmod`) asserts the explicit halt.

## Log

- 2026-10-10: package started; context read (WORK, 42c record, 36.11/36.12,
  console code, tests, Makefile).
- 2026-10-10: source split done (shared `console_service.c`, two
  manifests); fallback probe/branches deleted; init-status mechanism
  (upcall A publication, loader check, main halt, all 14 inits return 0);
  Makefile selection (`ZOS_CONSOLE`), serial + failure images and their
  four replay tests pass; ESC c program added and the integration image
  boots it (6 acceptance tests pass); HID image updated for its
  console-serial selection (2 tests pass); docs pass under way.
- 2026-10-10: validation on the frozen tree, all exit 0: `make clean &&
  make check` 93 s (reproducible rebuild `6e437af5…`, 562 tests OK,
  112 skipped); `make console-integration-selftest console-serial-selftest
  ipc-selftest` 1177 s (75 s / 7 tests, 81 s / 4 tests, 1021 s / 53
  tests); `git diff --check` clean.  Report carries the exact hashes and
  the out-of-scope findings below.
- 2026-10-10: package complete.  Hardware checks left to the owner
  (keyboard/V9958/ESC c; serial monitor on /dev/ttyUSB0).

## Findings reported, not fixed (pre-existing on 42c)

- `romfs-corrupt-selftest` cannot build: `ZOS_SERVICES := sio
  console-serial` against the production `recovery/manifest.json` store
  (`input not found: ioc.zmod`); the boot set and the store disagree.
- `tests/test_romfs_sim.py::_derive_scratch` still reads the deleted
  `arena.plan.json`; hidden behind the image that never builds.
  A repair attempt in this package was reverted (42c/42d scope).
