# Task

Implement milestone M7 by porting the Zephyr-80 monitor as an ordinary native `monitor.zex`, adding a narrow validated diagnostic syscall boundary, reusable user-side parsing/formatting support, and the default pre-shell boot launcher. Implement the monitor in C, NOT in assembly. You can look at the current monitor
implementation for reference.

## Context

Start only after M6 is reviewed and physically accepted. The read-only behavioral reference is `/home/kitamura/Documents/Zephyr-80/Code/HOST/Monitor/`; do not modify or depend on it at build time. Reuse its familiar parsing, dump, and command behavior, but remove every CP/M BIOS/BDOS, fixed resident address, old launcher, direct SIO, and old banking assumption.

The M7 command surface is: `H`/`?` help; `R` system/bank information; `D <addr> <len>` dump the monitor's bank; `DB <bank> <addr> <len>` dump bank 0-6; `M <addr> <value>` modify one byte in the monitor's bank; `MB <bank> <addr> <value>` modify one byte in bank 0-6; `I <port>` input; `O <port> <value>` output; `Q` exit. Commands are case-insensitive hexadecimal, lines are limited to 80 characters, dumps use 16-byte rows, and malformed/trailing arguments report `ERR: ARG`. Intel HEX load/export, `G`, `APP`, and CP/M register snapshot semantics are deferred rather than emulated.

Reserve diagnostic syscall numbers: `40 SYS_DIAG_MEM_READ`, `41 SYS_DIAG_MEM_WRITE`, `42 SYS_DIAG_IO_IN`, `43 SYS_DIAG_IO_OUT`, `44 SYS_DIAG_BANK_INFO`, `45 SYS_DIAG_SYSTEM_INFO`. Memory read args are `{bank:u8,reserved:u8,address:u16}` and return one byte in HL; write args are `{bank:u8,value:u8,address:u16}`. Reads allow banks 0-6 and addresses `0000h-DFFFh`; writes allow `0100h-DFFFh`, protecting native page zero and common memory. I/O args are `{port:u8}` or `{port:u8,value:u8}`; reject ports `00h-0Fh` because the memory latch is aliased there. BANK_INFO takes no args and returns current bank in L and mask `7Fh` in H. SYSTEM_INFO writes a versioned eight-byte record containing size, native ABI, application/OS mode values, common base, kernel bank, and ROMFS first page.

## Requirements

- Implement the diagnostic services in kernel-owned code and declare only packed ABI numbers/blocks in public headers/docs. Reuse M6 checked process-bank copy mechanisms, restore the exact active latch after every operation, reject bank 7/range wrap/reserved fields, and keep failures side-effect free. Diagnostic calls are explicitly recovery facilities, not driver bypasses for ordinary programs.
- Add reusable `user/runtime/` components for native syscall wrappers, console byte/string I/O, bounded line editing with backspace/CR handling, hex byte/word parsing, hex formatting, 16-byte hexdumps, and common status/error output. These components must be linked into the ZEX, not the kernel.
- Port the monitor under `user/monitor/` and build it through the unchanged M6 ZEX v1 path. All ordinary input/output must use `SYS_CONSOLE_*`; all memory/port/system operations must use `SYS_DIAG_*`. Map/source tests must reject SIO port constants, direct `IN`/`OUT`, early-console symbols, CP/M vectors/BDOS calls, and private kernel symbol references in `monitor.zex`.
- Add `monitor.zex` to ROMFS and make the kernel's temporary launcher call the same synchronous `process_exec("monitor.zex", &status)` used by M6. After normal `Q`, print an early/normal diagnostic from the resumed launcher and re-exec the monitor; failure uses early console and a controlled halt. Do not special-case monitor loading or format.
- Add host tests for parsing edge cases, line overflow/recovery, formatting, command dispatch, ABI layouts, diagnostic range/port rejection, exact latch restoration, and absence of forbidden dependencies. Extend linked-byte simulation to script console input and verify output without assuming SIO inside the program.
- Add an M7 target image and serial smoke mode that scripts at least help, system info, current-bank dump, a safe scratch-byte modify/readback, harmless port input, rejected latch-port output, invalid bank 7, bad syntax, and `Q`; repeat launch/exit at least twice and verify process/bank counts remain stable.
- Update architecture implementation notes, `docs/abi.md`, add `docs/monitor.md`, update ROMFS maps, and create a dated M7 validation record with `monitor.zex` and ROM hashes plus the interactive transcript.

## Files

- `include/zephyros/syscall.h`
- `kernel/syscall.c`, `kernel/process/`, `kernel/main.c`
- `user/runtime/`, `user/monitor/`
- `recovery/manifest.json`
- `tools/{zexpack.py,romfspack.py,serial_smoke.py,mapcheck.py}`
- `Makefile`, `tests/`, `docs/`

## Constraints

- `monitor.zex` is an ordinary ZEX and must remain byte-identical when the console device is later rebound; it contains no SIO/V9958/HID knowledge.
- No direct memory-latch writes, bank 7 selection, common-memory writes, kernel pointers, CP/M compatibility, shell, Intel HEX loader/exporter, or arbitrary jump command.
- Preserve all M0-M6 behavior and keep target-only scripted acceptance code under `tests/`.

## Validation

```sh
make clean
make check
make zmod-test
make romfs-test
make zex-test
make m6-selftest
make monitor-test
make m7-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean
```

Flash `build-m7-selftest/zephyros-m7-selftest.bin` and run `make smoke-hardware-m7 SERIAL_PORT=...`. Preserve the scripted transcript and also perform a short human interactive pass for help, dump, modify/readback, I/O read, rejected requests, and two `Q`/relaunch cycles. If hardware is unavailable, record M7 as `PENDING`; do not claim milestone completion from host simulation.

## Acceptance criteria

- `monitor.zex` is built as ordinary ZEX v1, stored in ROMFS, and launched/relaunched through unmodified M6 exec semantics.
- Required commands work through native console and diagnostic syscalls, with unsafe bank/range/latch-port requests rejected predictably.
- Exit restores the launcher and repeated cycles leak no process state; invalid requests do not corrupt kernel bookkeeping.
- Static inspection proves no serial-hardware, early-console, CP/M, or private-kernel dependency, and physical interactive evidence completes M7 acceptance.
