# Correction

`tui_frame_title()` does not preserve the primitive no-op contract for an
empty rectangle. It calls `tui_frame()`, which correctly returns success for a
zero-height clipped rectangle, but then uses the original width and visible
`y` to write title cells. A `5 x 0` rectangle therefore changes the model.

## Required changes

- After the normal lifecycle, pointer, frame-style, and text-style validation,
  make every zero-area titled frame (`w == 0` or `h == 0`) a successful no-op.
  It must not dirty cells, move cursor/window/style state, flush, or emit
  backend writes.
- Preserve `TUI_FRAME_NONE` title-only behavior for nonempty rectangles.
- Preserve clipping for partially visible nonempty rectangles and all current
  one-cell/two-cell frame behavior.
- Add a target regression with sentinel cells or an equivalent model oracle
  that covers at least `5 x 0`, `0 x 5`, `1 x 1`, and a partially clipped
  nonempty titled rectangle. The prior implementation must fail the `5 x 0`
  case.
- Exercise the regression through both serial and V9958/HID simulator routes,
  and assert that an empty titled frame produces no model change. Retain the
  existing write-batching checks.
- Update package 70's validation record and progress file. Preserve the
  accepted packages 66-69 and the existing uncommitted package 71-72 work.

Do not modify package 71-73 behavior as part of this correction.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk_package tests.test_v9958 tests.test_console_serial
git diff --check
```

## Acceptance criteria

- `tui_frame_title()` changes no cell for any zero-area rectangle.
- Invalid inputs retain their existing error behavior.
- `TUI_FRAME_NONE` still renders a clipped title in nonempty rectangles.
- Degenerate nonempty frames and partially clipped titles remain deterministic
  and memory-safe on both backends.
- Packages 66-69 outcomes and package 71-72 implementation remain unchanged.
