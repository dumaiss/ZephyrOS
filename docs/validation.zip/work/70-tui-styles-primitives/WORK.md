# Task

Add semantic styles, the low-level normal/reverse attribute, and clipped fill,
line, frame, and titled-frame primitives. Applications must not contain SGR or
CP850 constants.

Read:

- `work/00-WORKER.md`;
- `work/TUI-REFERENCE.md`, especially "Styles and glyphs";
- `docs/konaos-tui-sdk-architecture.md`, sections 8-9 and WP-TUI-4;
- `docs/devices.md`, section 6, and the V9958 terminal's accepted SGR behavior;
- packages 66-69 and their accepted validation records;
- the current screen engine and clipping tests.

## Requirements

1. Implement:

   ```text
   tui_set_style tui_get_style tui_set_attr tui_get_attr
   tui_fill tui_hline tui_vline tui_frame tui_frame_title
   ```

2. Use the exact normal/reverse semantic mapping and private CP850 glyph table
   in `work/TUI-REFERENCE.md`. Reject invalid style/frame/attribute values
   before changing state.
3. Store resolved attributes in cells. Style changes affect subsequent drawing
   only; they do not recolor existing cells. Flush emits SGR only at a run
   boundary whose attribute differs from the backend's last known attribute.
4. Every primitive uses the package-68 clipping layer. Handle width/height 1
   and 2 without duplicate corners or unsigned underflow. `TUI_FRAME_NONE`
   emits no border. A title is clipped inside the top edge with one separating
   space where room permits and never writes outside the rectangle.
5. Extend the target program with framed panels, title, highlighted selection,
   status line, error text, crossing clips, and degenerate rectangles. Assert
   the cell bytes and attributes on the V9958 route and the raw ANSI/CP850 byte
   stream on the serial route.
6. Add a source check that TUI examples/tests refer only to symbolic styles and
   frame APIs: terminal escapes and the twelve pinned CP850 box bytes occur
   only in the `libtui` backend/drawing implementation and their tests.
7. Re-run the write-count checks with alternating styles. Attribute changes may
   split runs; individual cells still never produce individual IPC calls.

## Acceptance

- The demo renders single and double frames, a clipped title, selected/status
  reverse runs, and normal runs on both console implementations.
- Application/test drawing code embeds no ANSI or CP850 knowledge.
- Style changes do not dirty unchanged cells by themselves.
- Invalid and degenerate inputs are deterministic and memory-safe.
- Packages 66-69 outcomes remain unchanged.

## Constraints

- CP850 plus normal/reverse is the complete v1 backend. Do not add color
  negotiation, UTF-8, alternate glyph packs, or a runtime backend probe.
- No kernel, driver, firmware, protocol, or system-image change.
- Record `docs/validation/<date>-tui-styles-primitives.md` with styled-run
  write counts and size deltas.

## Validation

```sh
make build/user/tui_test.exe sdk
python3 -m unittest tests.test_tui tests.test_tui_sim \
    tests.test_sdk_package tests.test_v9958 tests.test_console_serial
git diff --check
```

