# Progress

## Status

DONE — accepted by supervisor on 2026-10-18 after correction 01. Packages
69-72 are accepted and package 73 is active. No commit was made.

## Done

- `user/sdk/tui/src/tui_style.c`: exact normal/reverse semantic mapping,
  private CP850 box bytes, `tui_fill`, `tui_hline`, `tui_vline`, `tui_frame`,
  `tui_frame_title`; degenerate rectangles and clipped titles.
- `tests/tui/tui_test.c`: `styles` mode with single/double/title-only frames,
  1 x 1/2 x 2/1 x 3/3 x 1 frames, fill and line primitives, high attribute,
  and alternating reverse/normal status runs.
- `tests/test_tui.py`: CP850 and ANSI confinement checks.
- `tests/test_tui_sim.py`: exact row/attribute model on both backends and
  batched-write checks.
- Report: `docs/validation/2026-10-18-tui-styles-primitives.md`.

## Supervisor review

- The implemented style mapping, primitive clipping, symbolic glyph ownership,
  and styled-run coverage are otherwise consistent with the package contract.
- `tui_frame()` correctly treats a clipped zero-area rectangle as a no-op.
  `tui_frame_title()` then continues from the original rectangle and writes a
  title whenever `w >= 5` and `y` is visible, even when `h == 0`.
- See [`correction-01/WORK.md`](correction-01/WORK.md).

## Correction 01

- `tui_frame_title()` validates the lifecycle, pointers, frame style and text
  style first, then returns success immediately for `w == 0` or `h == 0`
  without touching cells, cursor, window, style, transactions or console.
- `TUI_FRAME_NONE` title-only behavior for nonempty rectangles is preserved.
- `styles` mode now keeps a `SENT` model sentinel and exercises `5 x 0`,
  `0 x 5`, a titled `1 x 1` frame and a partially clipped nonempty titled
  rectangle at the right edge.
- Serial/V9958 models assert the sentinel survives the empty titled frames.
- `tui_style.rel` is 12,381 bytes; styled writes are
  `[126, 8, 119, 27, 116, 13, 113, 17, 105, 7, 18]`.
- Report updated: `docs/validation/2026-10-18-tui-styles-primitives.md`.

## Final supervisor acceptance

- Direct review confirmed that all argument validation precedes the zero-area
  return and that nonempty title-only frames retain their behavior.
- The correction-specific styles replay passed on both serial and V9958/HID,
  including the `5 x 0`/`0 x 5` sentinel oracle.
- The worker's full 173-test result is accepted; no duplicate full-suite run
  was performed.
