> **DRAFT. Not dispatched.** Runs after 57. Drivers only; no kernel, SDK
> or ABI change.

# Task

Make card file I/O fast: a 512-byte read costs ~47 ms in the simulator
(board ~50 ms, SDBENCH port) against CP/M's 12.8 ms on the same firmware.
57's phase table (simulator; the board image could not be made to run, so
the simulator is the instrument) attributes it:

| phase (512-byte read, path B) | ms |
|---|---|
| command, reply, admission | 6.6 |
| bulk transfer (`INI` loop) | 3.1 |
| **staging copy + return (`copy`)** | **31.6** |
| copy to the caller | 1.7 |

The staging copy is a C byte loop (`drivers/iocfat/iocfat.c`,
`iocfat_transfer`: `data[i] = src[i]`) that SDCC compiles to ~290 T per
byte (IX-relative address arithmetic per iteration); an `LDIR` costs 21.

Read: `work/00-WORKER.md`; 57's record
(`docs/validation/2026-10-16-m13-read-path-measure.md`); `drivers/ioc/ioc.c`,
`ioc_io.asm`, `ioc_proto.c`; `drivers/iocfat/iocfat.c`; architecture 5.x.

## Requirements

1. **No staging copy.** The IOC driver's bulk receive (`INI` loop) writes
   straight into the destination the IOC-FAT driver names, and the bulk
   send (`OUTI`) reads straight from its source: both buffers are bank-6
   memory in the same domain. Extend `KIOC_OP_BULK_READ`/`_WRITE` so the
   caller passes the buffer address (`arg`/payload field; document it in
   `drivers/include/ioc_protocol.h` and `docs/devices.md`); update every
   in-tree caller; no old form kept.
2. **No C byte-copy loops on a data path.** Add one shared block-copy
   helper in assembly to the driver runtime (`drivers/runtime/`, `LDIR`,
   count 0 safe) and use it for every remaining copy loop in the drivers
   (`iocfat.c` 597/727/744, `v9958.c` 1495, any other found by search).
3. **The command path, measured first.** With 1-2 in, re-run the phase
   image; if `sent`/`reply` still exceed 3 ms each, move the command-frame
   CRC to a table-driven or assembly routine (same polynomial and result,
   pinned by a host test against the C reference) and remove the
   per-field IX-heavy work the profile names. Stop there.
4. **Measure** (simulator): `make phase-image` before and after, the three
   passes; record the tables. Target: a 512-byte miss under 20 ms.
5. No behaviour change: same FS2 commands and bytes on the wire, same
   errors; every replay passes.

## Owner checklist (hardware, production image)

1. SDBENCH port: read throughput at 128 B, 512 B and 4 KiB, before and
   after (CP/M: ~39 KiB/s, 12.8 ms per 512 B).
2. `hwtest` 4/4; `fs_selftest` 37/37; `timer card BIG.BIN` against a
   stopwatch; `vgmplay night.zvg` with no underrun.

## Validation (targeted; drivers change)

```sh
make
make phase-image
make fs-selftest
python3 -m unittest tests.test_ioc tests.test_iocfat tests.test_readpath tests.test_hwtest_sim tests.test_console_acceptance tests.test_shell_sim tests.test_device_release
git diff --check
```

Record: `docs/validation/<date>-m13-read-path-fix.md`, with both phase
tables and the board SDBENCH rows.
