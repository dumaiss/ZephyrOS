# Task

Expose the VFS to native programs. Add the global owner-tagged descriptor
pool, per-process CWD, the pinned `FS_*` syscall family (`10h-1Fh`) with
bounded argument blocks and a 512-byte staging buffer, the VFS-ready gate,
cleanup at exit, user runtime wrappers, and the first `fstest.zex` acceptance
program.

## Context

Dispatch only after package 26 is accepted and the supervisor bank-7 budget
checkpoint (M9-REFERENCE) has cleared continuation. Read `work/00-WORKER.md`,
architecture sections 32.21-32.31, 32.32.5 and 32.39, `docs/abi.md`,
`include/zephyros/syscall.h`, and `work/M9-REFERENCE.md`. There is no
backward-compatibility requirement.

Existing syscall rules apply:
- Argument blocks lie in `0100h-1FFFh`.
- Buffers lie in `0100h-DFFFh` and move only through the checked bank-copy
  gates.
- Results return in HL; errors return as carry set plus `ZOS_E*` in A.

Processes are single-tasking. Nested exec arrives in package 28; here the
parent is always the kernel launcher, whose CWD is the constant `/`.

## Requirements

- **Errors.** Add the eight M9-REFERENCE values to `errno.h` and document
  them in `docs/abi.md`.
- **Descriptor pool** (`kernel/vfs/`, kernel-only): one global `_DATA` pool
  of 8 entries, each holding the owner pid, `FREE`/`FILE`/`DIRECTORY`, mount
  index, provider handle, uint32 offset and access flags.
  - The fd is the pool index.
  - Every fd-taking call verifies range, type and owner; a mismatch returns
    `ZOS_EINVAL`.
  - Allocation takes the lowest free entry; a full pool returns
    `ZOS_EMFILE`.
  - Provider handles are never exposed.
- **CWD.** A static pool of `ZOS_EXEC_MAX_DEPTH` (4) canonical CWD slots of
  128 bytes, allocated at process start and released at exit. Running out
  fails the launch cleanly.
  - `vfs_process_start(pid, parent_pid)` gives the child the parent's CWD,
    or `/` under the launcher.
  - `vfs_process_exit(pid)` closes every pool entry owned by the pid (with
    `close` semantics) and frees its CWD. It runs on every exit path
    (`SYS_EXIT`, raw-return `ZOS_EFAULT`, failed launch rollback) and is
    idempotent.
- **Syscalls `10h-1Fh`** (numbers pinned in M9-REFERENCE):
  - Path arguments are `{path:u16, length:u16}`, with a length of 1..127
    bytes and no NUL. They are copied into the shared pathname scratch
    buffer and normalized against the caller's CWD.
  - `FS_OPEN {path,len,flags:u8}` returns the fd in HL.
  - `FS_READ`/`FS_WRITE {fd,buffer,length}` return the count in HL. They are
    chunked through the 512-byte staging buffer. A failure after confirmed
    chunks returns the confirmed count; otherwise it returns the error.
  - `FS_SEEK {fd,whence,offset:i32}` writes the resulting u32 back into the
    block.
  - `FS_STAT {path,len,out}` copies `zfs_stat` out through the gate.
  - `FS_READDIR {fd,out}` returns HL=1 with an entry, or HL=0 at the end.
  - `FS_GETCWD {buffer,length}` writes the NUL-terminated canonical CWD and
    returns its length. A buffer that is too small returns `ZOS_EINVAL`.
  - `FS_CHDIR` requires an existing directory and stores the canonical path,
    so it crosses mounts transparently.
  - `FS_CLOSE`, `FS_CLOSEDIR`, `FS_SYNC`, `FS_MKDIR`, `FS_RMDIR`,
    `FS_UNLINK` and `FS_RENAME {from,flen,to,tlen}` follow the package-26
    semantics.
  - Validation completes before any state change. Before READY, every
    `FS_*` call returns `ZOS_EBUSY`.
- **ABI header and tests.** Add the argument blocks to
  `include/zephyros/fs.h` with static asserts. Add host tests pinning
  numbers, sizes and offsets.
- **User runtime** (`user/runtime/`): add gate stubs plus C wrappers taking
  NUL-terminated strings (`zos_open`, `zos_close`, `zos_read`, `zos_write`,
  `zos_seek`, `zos_stat`, `zos_opendir`, `zos_readdir`, `zos_closedir`,
  `zos_mkdir`, `zos_rmdir`, `zos_unlink`, `zos_rename`, `zos_chdir`,
  `zos_getcwd`, `zos_sync`). They reject strings over 127 bytes locally and
  never expose SDCC conventions as ABI. Rebuilding the monitor against the new
  runtime is fine, but it must still work.
- **`fstest.zex`** (`tests/target/m9/fstest/`, packed into the `/SYSTEM` of
  M9 acceptance images only) uses only the public wrappers and prints
  `fstest: <case> OK|FAIL <code>`, ending with `fstest: PASS n/n`. It covers:
  - the section 33 namespace cases against ROMFS + ramfs;
  - ROMFS read, stat, enumeration and `EROFS`;
  - ramfs mutation, `TRUNC`, and the sizes;
  - missing file and wrong type;
  - pool exhaustion (the 9th open returns `ZOS_EMFILE`);
  - a stale handle, using the ramfs control;
  - a failed confirmed write (offset unchanged);
  - `EXDEV`;
  - argument-window faults.
- **Launcher test.** After `fstest` exits, a second exec finds all 8 pool
  entries free and its CWD back at `/`.

## Files

- `include/zephyros/{errno,fs,syscall}.h`, `kernel/syscall.c`, `kernel/vfs/`
- `kernel/process/{process,exec}.c`, `user/runtime/`
- `tests/target/m9/`, `tests/m9/`, `tests/test_m9_*.py`, `tests/test_syscall_sim.py`, `Makefile`
- `docs/{abi,vfs,zex-format}.md`

## Constraints

- No `SYS_EXEC`, block class or IOC-FAT. No `FS_STATFS` or `FS_TRUNCATE`.
- Descriptors are not stdin/stdout, are not inherited, and have no dup.
- Gate-stack discipline: no automatic path or dirent buffers. No dynamic
  allocation.

## Validation

```sh
make clean && make check
make zex-test monitor-test \
     m8-selftest m9-vfs-selftest m9-provider-selftest m9-fs-selftest
python3 -m unittest discover -s tests -v
git diff --check
make clean && git status --short
```

Report the `bank7:` ledger before and after, and the worst-case gate-stack
depth of the deepest `FS_*` path measured in the simulator. The suite must
assert that it stays inside 256 bytes.

Hardware: flash production `build/zephyros.bin` and run `make smoke-hardware` (early serial banner), plus an operator check that the V9958 display shows the monitor prompt and HID input works (the serial `normal` mode cannot see a V9958-bound console). Then flash the
M9 FS acceptance image and run `make smoke-hardware-m9-fs SERIAL_PORT=...`,
which expects `fstest: PASS`. Record `PENDING` if hardware is unavailable.

## Acceptance criteria

- Every pinned `FS_*` service works through the gate with complete argument
  validation, and pre-READY calls are refused.
- `fstest.zex` passes in the simulator, and on hardware or recorded
  `PENDING`.
- Pool entries close on every exit path, a child's CWD never leaks, repeated
  exec/exit leaks nothing, and the monitor still works.
