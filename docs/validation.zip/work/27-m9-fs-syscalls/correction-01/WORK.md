# Correction

Package 27 meets its contract, but bank-7 runtime data carries about 0.94 KB
of avoidable state. Under the derived data base, that comes directly out of the
module arena: two granules at a point where the end-of-M9 slack projection is
1.4-3.2 KB.

`M9-REFERENCE.md` ("Pinned kernel decisions") allows one shared static
128-byte pathname scratch buffer, plus a second only for `rename`. The
production map now carries six pathname buffers and a formatting buffer:

```text
_fs_path1             128  kernel/syscall/fs.c        user-path copy-in   (pkg 27)
_fs_path2             128  kernel/syscall/fs.c        rename copy-in      (pkg 27)
_vfs_cwd_canonical    128  kernel/vfs/process.c       chdir build buffer  (pkg 27)
_vfs_norm             128  kernel/vfs/mount.c         normalized path     (pkg 25)
_vfs_rename_target    128  kernel/vfs/mutate.c        rename normalized   (pkg 26)
_kernel_boot_path     128  kernel/main.c              /SYSTEM/<name>.zmod (pkg 25)
_vfs_required_diag    168  kernel/vfs/mount.c         panic line format   (pkg 26)
_fs_staging           512  kernel/syscall/fs.c        read/write staging  (pkg 27)
```

Syscalls cannot overlap: execution is single-tasking, the gate is not
re-entrant, and no ISR touches VFS. No syscall needs the data-staging role and
the path roles at the same time. `OPEN`, `STAT`, `OPENDIR`, `MKDIR`, `RMDIR`,
`UNLINK`, `RENAME` and `CHDIR` use paths; `READ`, `WRITE` and `READDIR` use
data. `READDIR` holds at most one 76-byte `zfs_dirent`.

The validation record also misstates the "before" ledger: it gives package 26
data as 1294 bytes, but the accepted value is 1501. The real package-27 data
delta is +1548, not +1755. It also says "32-granule production boot set"
where the boot set is 20 granules.

Read `work/00-WORKER.md`, `work/M9-REFERENCE.md`, `kernel/syscall/fs.c`,
`kernel/vfs/`, `kernel/main.c`, and the package-27 validation record. There is
no backward-compatibility requirement. The worker is the only actor in the
tree during this correction.

## Required changes

- **One VFS workspace.** Replace `_fs_staging`, `_fs_path1`, `_fs_path2`,
  `_vfs_norm` and `_vfs_rename_target` with a single 512-byte bank-7 workspace,
  owned by `kernel/vfs/` and declared kernel-only in `kernel/vfs/vfs.h`. It has
  two views: the transfer-staging view (all 512 bytes) and four 128-byte path
  slots (copy-in A, normalized A, copy-in B, normalized B; the B pair is used
  only by `rename`). Document which operations use which view. Debug and
  simulator builds assert that the views are never used together. Boot-time
  kernel callers (loader and exec through the kernel file API) use the path
  view only; no syscall can be active during boot.
- **No chdir build buffer.** Delete `_vfs_cwd_canonical`. `chdir` normalizes
  into the workspace path slot, verifies the directory, then copies once into
  the caller's CWD pool slot.
- **No boot path buffer.** Delete `_kernel_boot_path`. The `/SYSTEM/*.zmod`
  boot names are compile-time constant strings, or the boot loader uses the
  workspace path slot.
- **No diagnostic buffer.** Delete `_vfs_required_diag`. Write the
  `vfs: required mount <path> failed 0xNN` line piecewise to the early
  console, with identical output text.
- **Record corrections.** Fix the package-27 record's "before" data figure
  (1501) and data delta (+1548), and the boot-set wording. Then add a
  correction section with the before/after ledger and per-symbol `_DATA` sizes
  for the objects touched.

## Validation

At the "Validation depth" defaults (`00-SUPERVISOR.md`), the worker runs and
records:

```sh
make clean && make check
make m9-vfs-selftest m9-provider-selftest m9-fs-selftest m9-required-mount-selftest
python3 -m unittest tests.test_m9_fs tests.test_syscall_sim tests.test_m9_vfs \
     tests.test_m9_vfs_sim tests.test_m9_provider_sim -v
git diff --check
```

- `fstest` still prints `PASS 9/9` and `launcher OK`, and the
  required-mount panic text is byte-identical.
- Re-measure the worst-case gate-stack depth (it was 151 of 256 bytes); it
  must not increase.
- Report the `bank7:` ledger: production `_DATA` must drop by at least
  900 bytes.
- A host test asserts that the production map contains exactly one
  pathname-sized workspace symbol and none of the deleted symbols.

Hardware: production boot only, `make smoke-hardware` on
`build/zephyros.bin` plus the operator's V9958 prompt check. Record `PENDING`
if hardware is unavailable.

## Acceptance criteria

- One 512-byte VFS workspace replaces the six pathname buffers and the
  staging buffer, and the diagnostic and boot path buffers are gone.
- Production `_DATA` is at least 900 bytes smaller and the arena gains the
  freed granules. Behavior and the gate-stack depth are unchanged.
- The package-27 record states correct ledger figures.
