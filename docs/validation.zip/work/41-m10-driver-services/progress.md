# 41-m10-driver-services — checkpoint status

Contract: [WORK.md](./WORK.md). Working tree: 124 changed paths (81 M, 23 D, 20 ??).

## Done, with evidence

* **Versioned service protocols** — [`abi/zos/protocol.h`](../../abi/zos/protocol.h); five service images
  (`services/manifests/{sio,ioc,hid,v9958,console}.json`, hot/boot halves in `drivers/*`, console in
  `services/console/`) plus the V9958 font as a bulk segment (`drivers/v9958/v9958_font.asm`). Substrate
  extension `bulk_read` / `ipc_service_bulk_set`. Packer emits `SERVICE_ABI_VERSION = 2`
  ([`tools/zmodpack.py`](../../tools/zmodpack.py)).
* **Store manifest + loader** — `services.man` (load order), [`kernel/service/service_loader.c`](../../kernel/service/service_loader.c),
  boot tier through the mode-10 gate [`kernel/service/service_boot.asm`](../../kernel/service/service_boot.asm);
  runs are linked into every acceptance image through the new store manifests
  (`tests/{ioc,hid,video,console}/manifest*.json`).
* **Retirements** — console syscalls and the `zdriver_api` device path are gone; nucleus talks to the console
  service; the SDK console client and `ioc_shim` speak the service protocol.
* **Budget ledgers** — packer and loader both report `service hot: 13216 bytes of 32768` and
  `service boot/bulk: 2170 bytes of 24576` (package 36 projected hot 14 166 / boot 1 957) — see `/tmp/prod6.log`
  and the loader lines; per-image evidence rows `service <name>.zmod: hot XXXXh [boot|bulk XXXXh]`.
* **Working boot evidence** — `build/zephyros.bin` boots to `console: service OK` on the V9958 lane and reaches
  the monitor banner + `Z80> ` at ≈4.19 M steps; a scripted `r` / `q` session relaunches the monitor
  (2 banners). Console acceptance suite passed 6/6 and `test_console_sim.py` 2/2 on the pre-patch build.
* **Driver bugs fixed** — HID staged-reply offset ([`drivers/hid/hid.c`](../../drivers/hid/hid.c)); V9958
  `v9958_set_api()` wiring ([`drivers/v9958/v9958.c`](../../drivers/v9958/v9958.c), `v9958_driver.h`,
  `v9958_service.c`) — patch currently applied.
* **Build/infrastructure fixes** — `COLD_OBJS` ordering, `MODULES := $(BUILD)/modules`, per-image store
  manifests, `ZOS_IOCFAT_BOOT` derived from the arena set, `zmodpack.py plan` accepts an empty module list,
  dead M8 variants/fixtures retired.
* **Docs** — `docs/devices.md` §12 (protocols), `docs/abi.md`, `docs/sdk.md`.

## Root cause of the "stalled loader" — found, it is a replay-harness bug (fixed)

The stall was **not** in the loader. Every replay harness skipped the kernel's ~1 s serial-connect spin with

```python
if z.pc == self.syms["_kernel_serial_connect_delay"]:
    z.pc = z.pop16()
```

but that address is **bank-dependent**: the fixed nucleus (latch `18h` = mode 11, page 0, window on bank 7)
holds the spin, while with bank 6 in the window (mode-10 service-boot gate, mode-11 service calls) the *same
PC* is mid-instruction of a resident-service image. Evidence (frozen artifacts, `/tmp/det41`,
sha256 `f5242bc9…` image + `645ebc1f…` map):

```
step=1       latch=18 bank=7 code=11 A3 0B 06 00 10 ret=66AF sp=FFFA  DELAY  <- the spin, correct to skip
step=13377E  latch=16 bank=6 code=DD 34 FF DD 7E FF ret=B900 sp=FFA8  OTHER  <- v9958 service code, popped
```

Popping the stack there corrupts the loader; the boot then resets, re-enters and shows the "SP walked upward /
executing data / chunk-copy spinner at `0x2400-0x2460`" symptoms. That is also what both acceptance agents
reported as a loader bug (one of them found the same root cause independently and already guarded its replay).

Fixes applied:

* [`tests/test_console_sim.py`](../../tests/test_console_sim.py) `skip_delay()` now only fires with
  `z.latch == 0x18` (documented); this is the shared helper used by the console acceptance, console-selftest and
  fallback replays.
* [`tests/test_console_fallback.py`](../../tests/test_console_fallback.py) `FallbackBase` is an abstract harness;
  it is now skipped instead of being collected as a third test that booted the wrong image and hung.
* `tests/test_v9958_sim.py` already carried the same guard (written by the video agent).

## Validation status (in scope) — final

Determinism: frozen image/map/romfs in a private directory (`/tmp/det41`, sha256 `f5242bc9…` image,
`645ebc1f…` map), two replays per harness mode — **bit-identical**; the earlier flapping was the harness-mode
difference, not build interference or a nondeterministic simulator.

Serial-delay skip: one shared helper, no unguarded copies.  `z80sim.skip_serial_connect_delay(cpu, address)`
carries the `latch == 18h` guard and is used by every replay harness
(`test_console_sim`, `test_v9958_sim`, `test_v9958_console`, `test_subsys_sim`, `test_ioc_sim`, `test_iocfat_sim`,
`test_ipc_selftest_sim`, `test_m9_exec_sim`, `test_m9_provider_sim`, `test_m9_selftest_sim`, `test_m9_vfs_sim`,
`test_nucleus_sim`, `test_romfs_sim` (both sites), `test_sdk`, `test_syscall_sim`, `test_hid_sim`).
`tests/test_console_fallback.py` also learned to skip its abstract base class instead of being collected.

Replays (final source, `make clean` first):

* `python3 -m unittest tests.test_console_acceptance tests.test_console_sim tests.test_console_fallback
  tests.test_v9958_sim` → **15 tests OK, 1 skipped** (the abstract fallback harness, 88 s): production boot lanes +
  store, `console: service OK` on the V9958 lane, monitor banner/prompt, scripted `r`/`q` session incl. launcher
  relaunch, IOC lane bring-up + FS2 exchange, integration-image transcript, ROMFS payload identity, both fallback
  subsets (nohid → `input serial`/`output video`; nohid-nov9958 → serial/serial), video service
  boot/console/marker/reset/malformed.
* `make console-selftest console-integration-selftest video-selftest console-fallback-selftests` → rc 0 each
  (the fallback target now builds *both* subset images — its second `$(MAKE)` invocation had the wrong
  `BUILD=`/output path and rebuilt the nohid image).
* Formal batch on the final source (one pass, serialized):
  `make clean && make check` → clean ok, check **rc 2** (see below);
  `make console-integration-selftest` → rc 0;
  `make hid-selftest ioc-selftest video-selftest` → rc 2 (video replay 4 tests OK; ioc image fails on the
  deferred manifest blocker);
  `make ipc-selftest m9-selftest` → rc 2 (both acceptance images, see below);
  `git diff --check` → rc 0.
* **Production hash (recorded):** `build/zephyros.bin` =
  `f5242bc9d30d0847cb658f7d3f64a4617b8bdb9c440da733144af72bc9bc63f5` (`build/recovery.romfs`
  `8489c93448a1e4423633a9cc1ac2b8ae634db3a40709a4852eed5cbc56b23d59`); unchanged across the harness/Makefile
  edits of this pass, so the boot evidence above is the same artifact.

### Contract confirmations

* **Loader slimming — shared ZREL logic:** `zmod_reloc_decode()` / `zmod_reloc_add()` live in
  `kernel/module/relocate.c` and are the ones `service_loader.c` calls (lines 508/522); only the gate-based patch
  I/O is service-specific.
* **Loader slimming — production cost:** the loader object is `_WINDOW` 5679 B + `_WINDOW_DATA` 232 B = 5911 B in
  production (contract baseline 6.3 KB); the *same source* built for an acceptance image is 6234 B + 232 B, so the
  evidence/plan/ledger printing is ~555 B of test-only code.
* **Evidence-only printing:** `#if ZOS_TARGET_TEST_BUILD` guards every plan/ledger/evidence emitter
  (`service_loader.c` lines 157/679/706/999/1005).  Proof from the linked bytes: `build/zephyros.bin` contains
  **0** occurrences of `images in bank 6`, `service hot: `, `service boot/bulk`, while
  `build-console-integration-selftest/…bin` contains them (1 each).
* **`SYS_IPC_*` routed in the dispatcher:** `kernel_syscall_dispatch()` (`kernel/syscall.c` ~250) routes
  `ZOS_SYSCALL_IPC_LOOKUP`/`ZOS_SYSCALL_IPC_CALL` to `zos_ipc_dispatch()`, and `kernel/syscall.c` contains **no**
  `ZOS_TARGET_TEST_BUILD` reference any more (package 39's routing seam is gone).
* **Five ledgers before → after** (before: `docs/validation/2026-10-07-m10-nucleus-layout.md` §2, package-40
  production baseline; after: this build's `arena.plan.json` / `zmodpack` / packer lines):

  | ledger | before (package 40) | after (package 41) |
  |---|---|---|
  | nucleus fixed | required 3746 / overflow 10891 / stacks 768 / room 979 | required 7083 / overflow 7752 / stacks 768 / room 781 |
  | nucleus cold | code 14822 end 99E6h, arena 33 granules (33 boot, 0 free), data 892 at DC00h, room 158 | code 24153 end BE59h, arena 13 granules (13 boot, 0 free), data 1208 at DA00h, room 751 |
  | service hot | 0 of 32768 | 13216 of 32768 |
  | service boot/bulk | 0 of 24576 | 2170 of 24576 |
  | common | used 2106 of 7424 (code 1412, data 694), ceiling 3072, m10 512, limit 2560 | used 2230 of 7424 (code 1511, data 719), ceiling 3072, m10 512, limit 2560 |

  The arena shrink is the package's structural win: 33 → 13 granules, all of it IOC-FAT (image 6006 + bss 637),
  while the fixed core's overflow dropped by 3139 bytes and the cold half absorbed the loader and the substrate.
* **Gate-stack worst case / service-stack high-water:** the documented figures are gate stack 213 of 256 bytes
  (M9 image) and service stack 256 of 512 (package-39 correction-01 image), with the service-call chain measured
  at 278 bytes (`docs/architecture.md` 5064/5396, `docs/memory.md` 43).  The replays that re-measure them
  (`test_m9_selftest_sim`, `test_iocfat_sim`, `test_ipc_selftest_sim::test_stack_high_water_marks`) are blocked by
  the two acceptance-image breaks listed below, so this pass reports the documented values, not a fresh
  measurement.

## Deferred (listed for the report, deliberately not ported)

* **ioc / hid acceptance images and replays** — files exist (`tests/target/{ioc,hid}/*`,
  `tests/test_{ioc,hid}_sim.py`, written by the two agents); both agents' final reports say their three files
  pass as soon as the store matches the service set.  Blockers to clear first: `tests/ioc/manifest.json` and
  `tests/hid/manifest.json` omit `console.zmod` while those Makefile variants set
  `ZOS_SERVICES := sio ioc console` / `sio ioc hid console` (the loader then aborts the whole set);
  `$(BUILD)/ioc_test.rel` does not list `tests/target/include/service_client.h` as a prerequisite;
  `ROMFS_MANIFEST` changes are not tracked, so a manifest switch needs `rm -rf $(BUILD)`.
* **Stale old-test expectations** (M8 vocabulary, not ported): `tools/serial_smoke.py` console/video/IOC mode
  tokens, `tests/test_v9958.py` (`ZOS_VIDEOSELFTEST_FAIL_*`, `video: video0 OK`),
  `tests/test_ioc.py::TestTargetTestWiring`, `tests/test_source_layout.py` on the deleted
  `tests/video/manifest-fontfail.json`, `tests/test_driver_abi.py`'s retired failure-manifest cases.
* **Two acceptance images broken by this package's own changes, not fixed in this pass** (out of the scoped
  deliverables, but they are the two `make check` / `make …-selftest` failures left after the deferred list):
  * `make ipc-selftest` — with the substrate/loader now production objects, the old duplicate-object wiring was
    removed and the image's `--cold-extra` set restored (both landed), but the image's cold half no longer fits
    the derived geometry: `mapcheck: linked cold code ends at DB28h, past the derived cold data base D800h`
    (the arena shrink moved the derived bases).  Needs a placement decision for this package-39 image.
  * `make m9-selftest` — `zexmanifest: scratch zos_scratch at 2270h size 16 leaves the 0100h-1FFFh window`: the
    SDK's new console client (console_service + ipc + gate) grows `fstest.zex` past the 8 KiB ZEX window.
  * Nine target diagnostics (`tests/target/{m9,romfs,process,loader}/*.c`) were ported off the retired
    `zephyros/console.h` in this pass (four of them now use `service_cli_console_handle()`/`service_cli_write()`,
    five dropped the vestigial include) so the M9/romfs/process/loader images compile again.
* The other M3–M9 replay harnesses now share the guarded skip helper (see above); no unguarded copy remains.
* `z80dis-1.0.6-py3-none-any.whl` was fetched with `pip download z80dis` while looking for a Z80 disassembler to
  read the emulated spin loop; pip wrote it into the repository root.  It has been deleted.

## Tried, did not work / rejected

* "Wild jumps to 0000h" — the `jp 0000h` at bank-6 `0x2C` is the legit SIO boot entry tail-calling its own
  hardware init (the bank-6 boot tier starts at 0); a `PC < 0x10` crash detector gives false positives.
* Reverting the V9958 patch — a reverted build stalled too; the patch only moves image sizes by 10 bytes, so
  patch/no-patch was never the cause.
* Clean rebuilds / deleting `build/modules`, `recovery.romfs`, `zephyros.bin` — removed an earlier "5 banners"
  reset loop, but the deterministic stall reproduced from a frozen copy afterwards.
* Blaming concurrent agent `make` runs for rewriting `build/` — disproved by the frozen-directory determinism
  check (identical results twice per mode).  Both agents were stopped and no build ran beside a replay.
* Advancing `z.cycles` by the skipped spin (0.4 M / 1 M / 3 M) at the skip point — no effect; the emulator's
  clock is not the sensitive quantity.
* PC histograms, call/ret tracing and symbol attribution of the spinner — localised the loop but never identified
  the writer; the bank check above did.

## Correction 01 progress (2026-10-08)

* **Complete.** SDK gate-visible state now has one fixed `_ZOS_SDK_DATA` area: `zos_scratch` plus all three IPC blocks occupy
  68 bytes at 0100h-0143h for ordinary ZEX programs, and code starts at 0144h.  The special caller-buffer probe
  uses 0300h-0343h and starts code at 0344h.  Fresh `ipc.zex` is 6970 bytes and all four gate-visible blocks are
  within 0100h-1FFFh; the obsolete whole-program-below-2000h assertion was removed because the gate contract is
  per-block.  The final M9 run built `fstest.zex` at 8487 bytes and passed all seven replay tests, including the
  nine-fence fault workload moved into that public-SDK client.  Final M9 geometry is fixed room 170, cold end
  BF6Eh, 13/13 arena granules and cold-data room 473.
* IOC/HID manifests now carry `console.zmod`; the IOC object tracks `service_client.h`; the ROMFS rule already
  tracked `ROMFS_MANIFEST`.  The retired conditional target branches and simulator internal-result assertions
  were removed.  Fresh focused results: `make hid-selftest` passed its two replay tests; `make ioc-selftest`
  passed its two replay tests after the harness waited for the complete `OK\r\n` line.
* The retired font-failure, HID no-IOC/bad-IOC and console bad-IOC/arena test cases, stale target-wiring classes,
  dead owner/build-list entries and dead serial-smoke mode/help entries are removed.  The two live fallback
  variants remain.
* A clean IPC rebuild proved the image uses production placement and fits: fixed room 746 bytes; cold code ends
  C490h; arena C600h-DA00h (10 free granules); cold room 696 bytes.  The earlier DB28h overflow came from objects
  compiled with the stale pre-change cold flags.  Replay wiring now expects the actual eight-image set (SIO,
  console and six synthetic services) and reads the IPC image's own reports.  The target reports passed 55/55
  and ipccopy 23/23.  The full replay's 47 unaffected assertions passed; its six stale trace expectations were
  corrected and then passed together on the final file (241.002 s), for complete composite coverage without a
  second full replay.
* Production rebuilt with the SDK correction at sha256
  `21ca993c5336dcc55acf2d019008033fe6183291d0c18a26f252399b8456e563`; the nucleus/service ledgers are unchanged
  from the package-41 figures above.  A completed clean validation passed 790 tests with 176 conditional-image
  skips; console integration 6/6, both fallback rows (plus one abstract-harness skip), video 4/4, IOC 2/2, HID
  2/2 and M9 7/7 passed.  Fresh high-water figures are gate 213/256 and service 256/512.  `git diff --check`
  passes.  A redundant second clean-suite invocation was stopped on supervisor instruction and is not counted.
* Validation record: `docs/validation/2026-10-08-m10-driver-services.md`.  Hardware is `PENDING (owner)` with
  the exact image, hash, serial command and USB-keyboard/V9958/fallback/ESC-c procedure recorded there.
