# Task

M10 stage 4, part 2 (architecture 36.24, step 4). Move the device drivers
(SIO, HID, IOC, V9958) and the console into bank 6 as **resident
services**, with versioned service protocols. Then:

- retire the console syscalls in favour of SDK stubs;
- retire `zdriver_api` for the migrated drivers;
- retire the device registry, if nothing still needs it.

## Context

Read:

- `docs/architecture.md` 36.4, 36.6, 36.7, 36.10, 36.12 and 36.14;
- `docs/devices.md`;
- `drivers/`, `kernel/device/` (`console.c`, `registry.c`) and
  `kernel/module/loader.c` (`zdriver_api`);
- the package-36 driver split (§5.1: hot and boot bytes per module,
  including the V9958 display-reset caveat);
- package 40's service-image format and loader.

## Requirements

1. **Protocols.** Define versioned service protocols, with operation
   numbers, frame layouts and descriptor use, for:
   - **console:** buffered `WRITE(desc, len)`, `READ`/`GETC`, `POLL`;
   - **HID input;**
   - **V9958 video**, including the display reset;
   - **SIO serial;**
   - **IOC transport and block access.**

   Batch hot paths by design (36.7). Document the protocols in
   `docs/devices.md`.
2. **Migration.**
   - Each driver becomes a service image with:
     - a hot segment: run-time operations, IRQ handlers, and every path
       reachable after boot, **including the V9958 display reset**;
     - a boot segment: init, probing, the font and atlas upload,
       registration;
     - bulk data: the V9958 font.
   - Drivers call each other, and the console calls them, only through
     endpoints.
   - The console service composes HID, video and SIO, as `console.c` does
     today.
   - IRQ-owning drivers claim their IRQs through the bootstrap interface
     (36.10).
   - Classify the CTC driver (`drivers/ctc`) by the placement test (36.4)
     and state the result.
3. **Production switch-over.** This is the first package in which
   production links the IPC substrate (package 39) and the service loader
   and manifest (package 40). Route `SYS_IPC_LOOKUP`/`CALL` in the
   dispatcher proper, and remove package 39's `ZOS_TARGET_TEST_BUILD`
   routing seam in `kernel/syscall.c`. Driver I/O buffers follow the
   `SERVICE_IO` rule (36.8).

   The budget is tight. Production's cold half has 158 bytes free; moving
   four drivers out of the arena frees about 10 KB; the loader (6.3 KB
   today) plus making room in the fixed core for the substrate (about
   1.8 KB) costs about 8.3 KB. Before switching, slim the loader:
   - share the ZREL_ABS16 record validation and arithmetic with
     `kernel/module/relocate.c`, so that only the gate-based patch I/O is
     service-specific;
   - move the evidence-only plan and ledger printing
     (`service_report`, hex and decimal helpers) behind the test hook,
     keeping the error lines.

   Report the loader's production cost and every ledger before and after.
   If a ledger does not fit, stop and report it in bytes; do not raise
   anything. It fits because the drivers leave the arena:
   shrink the arena to the boot set that remains (IOC-FAT), then move the
   cold-tier objects now in the fixed core's overflow into the freed cold
   space, so that the fixed core has room for the substrate. Report the
   ledgers before and after.
4. **Nucleus side:**
   - The early console and the panic path stay in the nucleus and are
     usable before, and without, the console service. Keep today's
     fallback behaviour: serial-only, no HID, no V9958.
   - `CONSOLE_WRITE`, `CONSOLE_READ` and `CONSOLE_POLL` are removed. The
     SDK console functions (`user/sdk/src/console*.{c,asm}`) become
     client stubs.
   - `zdriver_api` no longer serves these drivers.
   - Remove the device registry if the VFS no longer needs it. Otherwise
     report what still uses it; package 42 removes it.
5. **Production manifest:** IOC, HID, V9958, SIO, console. IOC-FAT stays an
   arena module behind the in-nucleus VFS until package 42. It reaches the
   IOC service through the package-38 upcall shim, because it lives in the
   cold half. That shim path is temporary and goes away in package 42.
6. **Budget.** Show `service hot:` and `service boot/bulk:` with
   per-service rows. Compare hot and boot bytes per driver against
   package 36's projection (hot 14,166 bytes, boot 1,957 bytes, font
   2,048 bytes), and explain any growth.

## Constraints

- No backward compatibility: convert every first-party program and test
  that used the console syscalls.
- No VFS or filesystem change (package 42).
- Do not edit the architecture, `M10-REFERENCE.md` or other packages.

## Validation

```sh
make clean && make check
make console-integration-selftest
make hid-selftest ioc-selftest video-selftest    # adapted to the services
make ipc-selftest m9-selftest
git diff --check
```

Build nothing else. Target: under 30 minutes.

Hardware (owner):

- `make smoke-hardware`;
- the console with a USB keyboard and the V9958, and the serial
  fallback;
- ESC `c` (display reset) on the V9958.

Real IRQ sources are hardware-authoritative.

## Acceptance criteria

- The drivers and the console run as bank-6 services, with their IRQs
  delivered through the nucleus.
- The console syscalls are gone, and the SDK uses the console protocol.
- The early console and panic work without services.
- The production boot, console and fallback rows pass on hardware.
- The ledgers are within 36.20.
