# Correction 01: close package 41

Fresh session. Read `work/00-WORKER.md`, which has new **Progress file** and
**Tests** sections, then `../WORK.md` and `../progress.md`. The progress
file is the state of the tree; trust it, and verify claims as you touch
them. Keep `progress.md` updated.

The scope below is all that remains. The driver migration, the loader
slimming, the IPC routing and the shared skip helper are done; do not
redo them.

## Requirements

1. **`make check` green.** Delete the tests whose subject this package
   retired, giving one line of reason per test in the report. Do not port
   them. Known set:
   - the `tools/serial_smoke.py` M8 console/video/IOC tokens (switch them
     to the new transcript tokens, or delete the dead modes);
   - `tests/test_v9958.py` (`ZOS_VIDEOSELFTEST_FAIL_*`, `video: video0 OK`);
   - `tests/test_ioc.py::TestTargetTestWiring`;
   - the `tests/test_source_layout.py` entry for the deleted
     `tests/video/manifest-fontfail.json`;
   - the retired failure-manifest cases in `tests/test_driver_abi.py`.

   Fix any other failure at its cause.
2. **SDK low-window rule (affects every program).** The gate sees only
   `0100h-1FFFh` of the caller, but the SDK's syscall/IPC scratch
   (`zos_scratch`, the IPC blocks) currently lands wherever the program's
   BSS ends. `fstest.zex` puts it at `2270h`.
   - Give the SDK one fixed low-window area for every block the gate must
     read or write, linked first, so it lands in the low window whatever
     the program's size. `zexmanifest` keeps its check.
   - Report the SDK client cost (console stub plus IPC plus gate) for
     helloworld, before and after this package.
   - `make m9-selftest` passes.
3. **`ipc-selftest` placement.** Its cold half overflows because the
   derived bases moved with the arena shrink. Fix the image configuration:
   for example a smaller boot set, or `moves` objects in the fixed core's
   leftover space. Do not change production. `make ipc-selftest` passes.
4. **IOC/HID images: finish them; don't redesign.**
   - Add `console.zmod` to `tests/ioc/manifest.json` and
     `tests/hid/manifest.json` (the variants set it in `ZOS_SERVICES`).
   - Add `service_client.h` as a prerequisite of `$(BUILD)/ioc_test.rel`.
   - Make `ROMFS_MANIFEST` a tracked prerequisite of the store.
   - Review the agent-written `tests/target/{ioc,hid}/*` and
     `tests/test_{ioc,hid}_sim.py` against the Tests rules, and trim
     anything that asserts internals beyond what is needed.
   - `make ioc-selftest hid-selftest` pass. If either needs more than these
     fixes, stop and report.
5. **Stack figures, measured fresh** on the final images: the gate-stack
   worst case and the service-stack high-water mark.
6. **Validation record** `docs/validation/<date>-m10-driver-services.md`.
   Make it compact. Cover:
   - each requirement of `../WORK.md` and this correction, with its
     evidence;
   - the five ledgers before and after;
   - the loader cost;
   - the root cause of the stall;
   - the deletions with their reasons;
   - the per-area diff breakdown (OS / tests / docs / tools, files and
     lines);
   - the production hash.

## Constraints
- No new features and no test modernization. Production changes only for
  requirement 2, if the SDK fix touches production programs.
- No sub-agents.

## Validation (once, on the final source)
```sh
make clean && make check
make console-integration-selftest console-fallback-selftests video-selftest
make ioc-selftest hid-selftest ipc-selftest m9-selftest
git diff --check
```

## Hardware (owner)
Run `make smoke-hardware`, then:
- the console with a USB keyboard and the V9958;
- the serial fallback;
- ESC `c`.

Record the result as `PENDING (owner)` with exact instructions.
