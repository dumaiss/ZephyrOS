# 105-snd-ztr-crc progress

## State
Complete; handoff record written. make check: 4 pre-existing HEAD failures (HID), reported.

## Verified facts
- Baseline `make && make sdk`: green (log /tmp/105-build-before.log).
- Production image hash before: build/konaos.bin == build/zephyr80.bin
  sha256 8243d62a6191c346a3213e36121eda0261a62d094ca00b789c9628fe127ed28d
  (work/105-snd-ztr-crc/image-before.sha256).
- snd_ztr_open before (openprof.py, production image, C core):
  night-market 13,963,420 T total / 8,712,349 app (3.9 s);
  RunawayCircuit 36,735,928 T total / 31,812,404 app (10.3 s).
- fur2ztr.py is byte-identical in both trees; Zephyr-80 tree is OFF LIMITS
  (user steer). Fixtures are copied from Zephyr-80 by gen_fixtures.py, so
  gen_fixtures stamps the copies; the test_snd_oracle byte-equality pin
  (test_the_ztr_songs_are_the_zephyr80_sources) must be updated (source:
  WORK.md req 4 "gen_fixtures.py stamps its good fixtures").
- UserSoftware songs regenerate from their .csm with the KonaOS csmc.py
  (user steer: rerun the modified compiler on the CSM files).

## Deviation to report
- WORK.md req 7 names test_malformed_streams_refused_or_stopped
  (tests/test_snd.py:1166) for "drop the content-refusal arm". That test is
  pure ZVG (TestSndZvg): the ZVG loader is outside this package and keeps
  its header checks, so no arm is retired. Keeping the test unchanged;
  the ztrcheck.exe simulator arm is added as required.

## Plan (in flight)
1. snd_ztr.c: delete validation (lines 156-697 minus helpers), add
   table-driven CRC-16, new order: header -> magic/capacity -> resident
   reads feeding CRC -> verify -> remap/compact/split -> mask/loudness/
   largest-order. Keep memory-safety guards (counts, number<16 scatter,
   largest-order scan).
2. fur2ztr.py encode_ztr stamps 0x16 (csmc.py inherits via encode_ztr);
   decode_ztr verifies it.
3. gen_fixtures.py: stamp good fixtures, zero 0x16 in malformed, retarget
   values-reserved to byte 55 (0x16 is the CRC field now; source: WORK.md
   req 4 + 6). Regenerate fixtures + malformed. Rebuild songs via csmc.py.
4. Oracle ztr.c accepts nonzero 0x16; regenerate malformed.md
   (values-reserved row changes to "reserved header byte"; source: req 6).
5. UserSoftware/ZTRCheck/: core + Z80 + host twin + Makefile + README.
6. tests: verdict golden (tests/snd/golden/ztrcheck.md + make_ztrcheck.py),
   open partition test, CRC-flip test, zero-CRC test, simulator ztrcheck
   test.
7. Docs: ZTR-Format.md, snd-sdk.md, kos/snd.h.
8. Validation batch per WORK.md; openprof after-numbers; record.

## Dirty tree classification (git status --short at start)
- `M UserSoftware/SNTracker/Makefile`, `M UserSoftware/SNTracker/README.md`,
  `?? sntview.c, view.c/h, ztrdoc.c/h, docs/sntrack-ui.md, tests/test_sntrack_view.py`
  → 104 package work (user's). PRESERVE, never touch.
- WORK.md preamble also names "HID/song files" as user work — check status again before edits.

## Plan
1. Read: docs/ZTR-Format.md, snd_ztr.c (ranges 156-697, 976-995), kos/reader.h,
   tests/snd/host/host_ztr.c, UserSoftware/SNTracker/Makefile, kc_crc16,
   csmc.py, fur2ztr.py, gen_fixtures.py, make_malformed.py, tests/test_snd.py
   (lines 797, 1166), oracle ztr.c.
2. Implement per WORK.md sections 1-7.
3. Validation once at end per WORK.md Validation block.

## ztrdoc.c (user-authorized touch, 2026-10-29)
User: "the dirty file ztrdoc.c will also need updating since it look like it
checks the ZTR file beyond the CRC also".  Done:
- check_header: dropped the h[16h]/h[17h] reserved-zero rejection.
- New crc_table/crc_feed/crc_sweep/check_crc (same CCITT-FALSE table values
  as libsnd, verified identical by copy): ztrdoc_open verifies the stamped
  CRC right after check_header, sweeping [64,pattern_data) and the note
  table through the caller's scratch; stored==0 skips everything.
- sntview rebuilt; tests.test_sntrack_view 4/4 green on the stamped songs
  (CRC verify path exercised on Z80).

## Pre-existing failure found (NOT 105): test_sound_api.py
make -C UserSoftware/SNTracker test failed at HEAD already: commit 04a65b6
("pacing the console input") changed sntracker.c to
`if (!(pollnow++) && console_poll() > 0)` but the source-grep test still
asserts the literal `if (console_poll() > 0)`.  Classification: test
artifact (stale against the committed pacing change, unrelated to this
package).  Minimal repair: assert `console_poll() > 0` without the `if (`
prefix.  Suite then green; sntrack.exe/sntview.exe exepack-validate OK.

## Fixtures + oracle golden regenerated
- gen_fixtures.py run: good fixtures stamped (night-market 0C3A,
  RunawayCircuit 734F — the Zephyr-80 source bytes, stamped here);
  malformed all carry 0x16=0000h; only values-reserved.ztr content moved
  (byte 22 -> byte 55).
- malformed.md regenerated: one row changed, values-reserved now
  "reserved header byte (-2)" (source: WORK.md requirement 6).
- test_snd_oracle.py: source-equality test now asserts fixture ==
  gen.stamp_ztr(source) + nonzero stamp (source: WORK.md requirement 4).
- tests.test_snd_oracle 9/9 green.

## ZTRCheck created (UserSoftware/ZTRCheck)
- ztrcheck_core.c: lifted checks (header per-field, layout, CP/M padding,
  CRC-first-when-nonzero, strings, instruments, resident_macro_ok as
  zc_macro, pattern placement, pattern_streams_ok as zc_stream over a
  forward window walker, note divisors), reader-based, diagnostic enum +
  file offset, report carries CRC state + OK metadata + title/author/
  source.  Two bugs fixed en route: dir window must live outside scratch
  (walker refills clobbered it -> static zc_dir_window), and macro value
  check is only each entry's flags byte (stride 3), not every byte
  (value int16s legitimately have high bits).  uint32 multiplies written
  as shifts: the SDK lib lacks ___muluint2ulong.
- ztrcheck.c (Z80) + ztrcheck_host.c print identical verdict lines
  (target \r\n, host \n).  Host shims: host/include/kos/types.h over
  stdint.h (16-bit wraparound matters for the CRC).
- Makefile/README shaped like SNTracker's; tests/test_ztrcheck.py: both
  stamped songs OK+crc=ok, covered-byte flip -> MISMATCH, unstamped ->
  crc=none OK, truncated -> FAIL.  make -C UserSoftware/ZTRCheck test
  green; ztrcheck.exe packs at 22970 bytes.

## Docs (req 1) done
- docs/ZTR-Format.md: 16h = content CRC-16 (CCITT-FALSE); new "Content
  CRC" section (covered ranges, producer stamp order, zero=unprotected,
  one-sentence 0000h blind spot); intro reader contract: player checks
  signature/capacities/CRC, structural validation lives in ztrcheck.
- docs/snd-sdk.md: 4.2 open bullet + 6.1 "Open: one forward pass"
  rewritten to the CRC contract; largest-order total now "from the
  pattern directory"; file listing snd_ztr.c line updated.  Package
  appendix (578+) untouched: history by nature.
- kos/snd.h snd_ztr_open comment: load/CRC contract, ztrcheck named.

## openprof breakpoint method broke; switched to markers
- The old openprof.py broke at _snd_ztr_open's map address while
  app-mapped.  The slimmed loader moved _snd_ztr_open to 341B, which the
  shell's own code also passes during command handling (address-only
  breakpoint on a banked system; boot hits showed stack tops 0000/0001,
  never a real frame).  Not a product bug: TestSndZtrLoad's on-target
  ztrload checksums pass for both songs.
- openprof.py now drives `sndtest ztrbudget` (the committed marker
  mode) through the harness profiled(): open = marks[1]-marks[0],
  prepare and one service window reported too.  Marker call overhead
  (~100 T-states) included; immaterial against the 7.35M target.

## Budget: largest-order scan was the leftover hot spot
- After the loader slimming, open still measured 9.06M (night-market) /
  30.4M (RunawayCircuit) T-states vs the 5x target ~7.35M.  HEAD runs
  the IDENTICAL O(orders x patterns) setup_order_for scan at open
  (54k iterations with two 16-bit multiplies each for RunawayCircuit);
  deleting the stream walk only removed ~6M.
- Rewrote the largest-order total channel-major: per channel a
  pattern-number -> length table (first match wins, exactly
  setup_order_for's resolution), then every order's selections totalled
  from it; both tables in order-buffer slot 0 (512 B lengths + 272 B
  totals < 1024 B), free until the first refill.  0xFFFF sentinel is
  safe: a stream length is bounded by the 64 KB file less its offset.
  Same acceptance semantics, same ENOSPC threshold.
- Host loader/CRC tests 5/5 green; on-target ztrload checksums still
  match the host for both songs after the rewrite.

## Budget round 2: CRC loop and read chunking
- PC-attribution profile of the RunawayCircuit open window (11.46M):
  _timer_event 4.15M (proportional background tax), _snd_ztr_open 4.06M
  (CRC feed dominated: 16-bit shifts + width masks per byte),
  kernel/driver 2.24M (18 FS2 reads, ~120k each), memset/memcpy 0.34M.
- CRC now split hi/lo byte tables (the engine's div_lo/div_hi pattern):
  the step is all 8-bit, so the host-width masks vanished by
  construction.  Tables generated by script, verified against the
  0x29B1 check value.
- ZTR_WINDOW_BYTES 256 -> 1024 (the order-buffer size the windows
  already scratch in); ztr_read_forward's chunk cap tracks it.  Read
  chunks for RunawayCircuit: ~29 -> 12.
- 6/6 loader/CRC/target-checksum tests green after the change.

## Budget round 3: scan code shape
- Fine PC profile: the whole 4.06M in _snd_ztr_open was the scan loops
  (snd_ztr.c:697-725); the 16-bit CRC loop was already ~cheap
  (~0.5M), the byte-table rewrite kept it (all-8-bit, no width masks)
  but was not the lever.  FS2 reads are 512B-block granular: 15
  requests is the floor for RunawayCircuit's 6.8KB covered span.
- Scan extracted to largest_order_total() with file-scope scratch
  pointers (scan_entry/scan_selection/scan_slot/scan_total_at/
  scan_work/scan_i): SDCC puts function locals in an ix frame at ~19+
  T per access; statics address absolutely.  Reverse fill retained
  (first-match-wins without a sentinel read in the store path).

## Budget round 4 (mask/loudness/patdir/unused-channel) - TARGET MET
Edits: load_resident mask scan rewritten channel-outer (running bit, early
break on first use); loudness page via Bresenham remainder walk (no
multiply, no subtract loop); patdir compaction copies the 6 bytes inline
(memcpy call per entry cost more than the bytes); largest_order_total
skips channels absent from snd_ztr_mask (computed earlier in open).
Result: RunawayCircuit open 8,727,047 -> 7,111,648 T-states = 5.17x vs
the 36,735,928 baseline (target >=5x, <=~7.35M: MET). night-market
6,439,581 -> 6,087,877. TestSndZtrLoad 9/9 green; image hash unchanged
(8243d62a...).

## Informational figures
- Unstamped RunawayCircuit (0x16 zeroed): open 4,920,464 T-states -
  the resident loads alone, no string read, no CRC feed (vs 7,111,648
  stamped: the difference is the string-pool reads plus the CRC feed).
- ztrcheck on target on RunawayCircuit: 129,817,939 T-states (36.3 s)
  from command to report - walks every pattern stream in C; the cost
  that used to be paid inside every open.
- Per-function profile of the final open window (7,111,648):
  largest_order_total 2,343,254 (32.9%), ztr_crc_feed 2,084,247
  (29.3%), load_sections 359,390, remap_and_split 96,378, load_resident
  35,352 (mask scan rewrite: 1,338,078 before), open body 2,125; the
  remainder is the kernel's FS2 reads (~1.57M, 512 B-block granular)
  and the proportional timer-event tax (~37%).
- snd_ztr.c: 1171 -> 1009 lines (plus ztrcheck_core.c holds the lifted
  checks).

## Loudness fencepost (found by the full suite, fixed)
Round 4's remainder-walk loudness page stored after advancing, giving
floor(base*(macro+1)/15): golden traces failed (volume 147 vs 148).
Store-then-advance matches floor(base*macro/15) for all 256 entries
(checked exhaustively in Python). sntrack.exe links SNTracker's own SDK
copy: rebuild it after a libsnd change or the trace test runs stale.
Final open: RunawayCircuit 7,122,458 (5.16x), night-market 6,098,990,
unstamped 4,933,173; ztrcheck on target 129,817,939 (36.3 s).

## Final validation (frozen sources)
- SNTracker 4/4, ZTRCheck 4/4, unittest trio 51/51, diff --check clean,
  WORKER history grep clean (two comments reworded to present tense).
- make clean && make check: 1010 tests, 4 FAIL, 119 skip, 761 s. All 4
  fail identically on a clean build of untouched HEAD in a worktree:
  8dc1af2's HID backoff change (source pin + hot tier 1500 < 1536).
  Not ours; reported.
- Image: clean build 5881b667... == clean untouched HEAD. image-before
  8243d62a... was a stale incremental build predating 8dc1af2.
- Record: docs/validation/2026-10-29-snd-ztr-crc.md.

## HEAD failures adapted (owner: board works, adapt the tests)
test_hid pin -> one-expression backoff; hot-tier reserve 1536 -> 1472 in
test_iocfat/test_pack_image/test_sound + architecture.md. make check:
1010 OK (119 skip), 681 s; image 5881b667... unchanged.
