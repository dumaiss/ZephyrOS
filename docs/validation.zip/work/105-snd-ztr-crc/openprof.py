#!/usr/bin/env python3
"""Measure snd_ztr_open T-states in `sndtest ztrbudget` on the production
image (package work scratch, not committed to the test suite).

    python3 work/105-snd-ztr-crc/openprof.py [song ...]

The ztrbudget mode brackets `snd_ztr_open`, `snd_ztr_prepare` and one
`snd_service` refill with marker-port writes; the harness attributes the
steps and reports the absolute marker T-states.  Each window's figure is
the elapsed T-states between its markers, including the marker call
overhead (~100 T-states).
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "tests"))

import snd_harness as H  # noqa: E402

PROGRAM = os.path.join(ROOT, "build", "user", "sndtest.exe")
FIXTURES = os.path.join(ROOT, "tests", "snd", "fixtures")


class Replay(H.SndReplay):
    def runTest(self):
        pass


def measure(song):
    with open(PROGRAM, "rb") as handle:
        program = handle.read()
    with open(os.path.join(FIXTURES, song + ".ztr"), "rb") as handle:
        fixture = handle.read()
    p = Replay()
    p.setUp()
    z, _since = p.start(
        {"SNDTEST.EXE": program, "RUN.ZTR": fixture},
        b"/fs/sndtest.exe ztrbudget /fs/run.ztr\r")

    def done(z):
        return "ztrbudget PASS" in "".join(z.glyphs)

    _intervals, marks = p.profiled(z, done)
    if len(marks) < 4:
        raise SystemExit("%s: only %d markers" % (song, len(marks)))
    open_total = marks[1] - marks[0]
    prepare_total = marks[2] - marks[1]
    service_total = marks[3] - marks[2]
    print("%s: snd_ztr_open %d T-states (%.2f s at 3.58 MHz); "
          "prepare %d, one service %d"
          % (song, open_total, open_total / 3579545.0,
             prepare_total, service_total))
    return open_total


def main():
    songs = sys.argv[1:] or ["night-market", "RunawayCircuit"]
    for song in songs:
        measure(song)


if __name__ == "__main__":
    main()
