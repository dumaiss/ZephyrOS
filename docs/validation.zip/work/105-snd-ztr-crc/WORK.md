> Worker package. After 104. ZTR open-time validation becomes a stamped
> content CRC; structural validation moves to a new `ztrcheck` program.
> No engine (`snd_ztr_dec.asm`), ABI, or architecture change. Baseline:
> HEAD plus the dirty 104 tree (`sntview.c`, `view.c/h`, `ztrdoc.c/h`,
> `docs/sntrack-ui.md`, `tests/test_sntrack_view.py`, HID/song files):
> user work — preserve, never touch.

# Task

`snd_ztr_open` validates a complex song for up to 20 s by walking every
pattern stream in C. The producers (`csmc.py`, `fur2ztr.py`) emit valid
ZTR, so the library's structural validation is replaced by a header
CRC-16 the tools stamp: open verifies it only when nonzero, feeding the
reads it already performs. The deleted validation moves, enriched with
diagnostics, into `UserSoftware/ZTRCheck/`, a Z80 + host program that
reports OK + metadata or the first defect.

## Current state

- `user/sdk/snd/src/snd_ztr.c`: validation is `validate()` (458-697),
  `pattern_streams_ok()` (322-456), `resident_macro_ok()` (283-315), the
  `zs_*` window walkers (156-263), the `1Ah` padding check in
  `snd_ztr_open` (976-995). All validation-only: the producer paths
  (`setup_order_for`, `refill_order`) never use them.
- Kept regardless: magic/version sanity; capacity (`SND_ZTR_MAX_ORDERS`
  136, `SND_ZTR_MAX_PATTERNS` 400, `SND_ZTR_MACRO_BYTES` 6640,
  `SND_ZTR_ORDER_STREAM` 960 → `-KOS_ENOSPC`); the resident loads,
  instrument/macro remap, loudness page, channel mask, largest-order
  scan, CP/M 128-byte rounding acceptance (not the `1Ah` content check).
- Header (`docs/ZTR-Format.md`): `0x16` is a reserved u16. Offsets:
  order list `0x22`, pattern data `0x2A`, note table `0x2C`, size
  `0x2E`. Sections are contiguous and ordered.
- CRC: CRC-16/CCITT-FALSE (poly `1021h`, init `FFFFh`) —
  `UserSoftware/KonaCommander/src/kc_protocol.c` `kc_crc16` is exactly
  it; host-side it is one line: `binascii.crc_hqx(data, 0xFFFF)`.
- Pinned by tests today: `tests/test_snd.py`
  `test_sdk_loader_refuses_every_malformed_ztr` (797),
  `test_malformed_streams_refused_or_stopped` (1166);
  `tests/snd/golden/malformed.md` via `tests/snd/oracle/
  make_malformed.py` pins the **oracle** (`tests/snd/oracle/ztr.c`,
  `ztr_trace`). Fixtures regenerate: `tests/snd/fixtures/
  gen_fixtures.py`. Songs: `UserSoftware/SNTracker/songs/*.ztr`, built
  from their `.csm`.

Read: `work/00-WORKER.md`; `docs/ZTR-Format.md`; `snd_ztr.c` (the
ranges above); `kos/reader.h`; `tests/snd/host/host_ztr.c`;
`UserSoftware/SNTracker/Makefile` (program build shape).

## Requirements

1. **Format** (Must): `docs/ZTR-Format.md` — `0x16` becomes the content
   CRC-16 (CCITT-FALSE) over `[0,16h)` + `[18h, pattern_data_offset)` +
   `[note_table_offset, +192)`; `0000h` means unprotected and always
   passes (a computed CRC of `0000h` is stored as-is, blind spot
   accepted — one sentence). Reader contract: a player checks magic,
   capacity and this CRC; structural validation belongs to `ztrcheck`.
   Update `docs/snd-sdk.md` and the `snd_ztr_open` comment in
   `kos/snd.h` to match.
2. **CRC in libsnd** (Must): a libsnd-private CRC-16 (table-driven; the
   KonaCommander semantics, not its code — no cross-tree import). Open
   feeds it the bytes it already reads, in file order — header, string
   pool (read only when the field is nonzero), orders, instrument
   directory, macro area, pattern-directory windows, note table —
   verifies after the last covered read, before any remap; mismatch is
   `-KOS_EINVAL` via `snd_ztr_last_error`. Field zero: no string read,
   no CRC, open is the resident loads alone.
3. **Slim the loader** (Must): delete the code listed above. The order
   becomes: header read → magic/capacity → resident reads feeding the
   CRC → verify → remap/compact/split → mask/loudness/largest-order.
4. **Producers stamp** (Must): `csmc.py`, `fur2ztr.py` patch `0x16`
   after assembly (zero field, `crc_hqx` over the ranges, store, in
   that order). `gen_fixtures.py` stamps its good fixtures; malformed
   fixtures keep `0x16 = 0000h` so the structural checks are what fail.
   Regenerate `songs/*.ztr` stamped.
5. **`ztrcheck`** (Must), `UserSoftware/ZTRCheck/` (Makefile and README
   shaped like SNTracker's):
   - `ztrcheck_core.c`: the lifted checks (string pool, instruments,
     `resident_macro_ok`, `pattern_streams_ok`, note divisors, header
     arithmetic), reader-based, host/Z80 portable; each check reports a
     diagnostic enum + file offset, not 0/1. Verifies the CRC first
     when nonzero and reports `none`/`ok`/`MISMATCH stored= computed=`.
   - `ztrcheck.c` (Z80): `ztrcheck FILE.ZTR` over a `kos_reader_t` on
     the open file. OK: one summary — title, author, source, rate,
     speed, rows, orders, patterns, instruments, macro bytes, size,
     CRC state. Failure: `FAIL <check> at <offset>: <detail>`.
   - host twin so tests run it without the simulator.
6. **Oracle** (Must): `tests/snd/oracle/ztr.c` accepts a nonzero `0x16`
   (no verification); `malformed.md` is otherwise unchanged.
7. **Tests** (Must):
   - Every malformed ZTR fixture now passes `snd_ztr_open` (unstamped);
     `test_sdk_loader_refuses_every_malformed_ztr` moves to host
     `ztrcheck`: each fixture's verdict line pinned (extend
     `make_malformed.py` or a sibling golden).
   - `test_malformed_streams_refused_or_stopped`: drop the
     content-refusal arm; keep reader errors. One malformed fixture via
     `ztrcheck.exe` in the simulator asserts the target report.
   - New: a stamped good fixture with one byte flipped in a covered
     range → open `-KOS_EINVAL`; stamped `night-market` +
     `RunawayCircuit` play through `sntrack` exactly as before
     (existing golden traces stay green).
   - A computed CRC of `0000h` in a synthetic fixture passes open.

## Invariants

- `snd_ztr_dec.asm`, `kos/snd.h` signatures, the `kos_reader_t`
  contract, and the golden playback traces: unchanged.
- Production image bytes unchanged (libsnd is SDK-side).
- The 104 tree (preamble): untouched.

## Budgets (CPU T-states)

| figure | now | target | on overrun |
|---|---|---|---|
| `snd_ztr_open`, RunawayCircuit | ~20 s class | ≥ 5× faster | report with a profile |
| `snd_ztr_open`, unstamped file | - | = resident loads only | report |
| production image | HEAD | byte-identical | stop and report |

## Criteria

- **Must:** all of section Tests green; `make check` green; docs agree
  with the code.
- **Should:** the open budget met; libsnd shrinks (~450 lines out).
- **Informational:** open T-states before/after, both songs; ztrcheck
  run time on RunawayCircuit.

## Owner checklist

- Board: `sntrack` plays both stamped songs; `ztrcheck
  /fs/night-market.ztr` prints the OK summary; a host-corrupted copy
  prints MISMATCH; an unstamped copy prints `crc=none` and validates.

## Validation

```sh
make && make sdk
make -C UserSoftware/SNTracker test && make -C UserSoftware/ZTRCheck test
python3 -m unittest tests.test_snd tests.test_snd_oracle tests.test_sntrack_view
git diff --check
make clean && make check   # once, at the end
```

Record: `docs/validation/<date>-snd-ztr-crc.md`.
