> Worker package (implemented by the supervisor). Baseline: HEAD plus the
> uncommitted package 80 in the tree (preserve it). SDK, libtui, build
> rules, tests, docs; no driver, no nucleus.

# Task

Give every TUI program room and let a program choose its grid capacity:
a 4-bit attribute store, a smaller `console_info`, clamping instead of
refusing a larger grid, and a per-program `TUI_GRID` build option.
Package 80 left KonaCommander 188 bytes over its stack (it had 10 bytes of
headroom before).

## Current state

- `user/sdk/tui/src/tui_internal.h`: `TUI_MAX_COLS`/`ROWS` 85/26 (the
  capacity), `TUI_CELL_COUNT`, `TUI_CELL_INDEX` (stride the capacity);
  `tui_state.c` holds `struct tui_cell tui_cells[TUI_CELL_COUNT]`
  (2 bytes per cell, 4,420 bytes). 21 accesses in tui_flush.c,
  tui_lifecycle.c, tui_window.c, tui_region.c, tui_screen.c.
- The public `struct tui_cell` (`tui.h`) is the `tui_save`/`tui_restore`
  buffer format.
- `tui_init` refuses a grid above capacity with `-KOS_ENOTSUP`.
- `user/sdk/src/console_info.c`: 102 bytes (the request built field by
  field).
- Programs name libraries with `LIBS=` (`mk/kos.mk` `$(1)_LIBS`,
  `$(1)_LIBFILES`); `user/sdk/exe.mk` builds `libtui.lib`;
  `tools/sdkpack.py` ships it; `tests/test_sdk_package.py` pins the files.

## Requirements

1. **Attribute store** (Must): the cell map is one byte per character
   plus one 4-bit attribute per cell (two cells per byte), behind
   accessor functions; every access goes through them. `struct tui_cell`
   stays the save/restore format. Observable: the 85 x 26 storage is
   2,210 + 1,105 bytes (record the map figures).
2. **console_info** (Must): zero the request once (`memset`), set the
   operation, call, copy the record. Record its size.
3. **Clamp** (Must): `tui_init` uses `min(reported, capacity)` for each
   dimension; only a zero dimension is refused (`-KOS_ENOTSUP`).
4. **TUI_GRID** (Must): `TUI_GRID=<cols>x<rows>` in a program's rule
   options selects a libtui built for that capacity: `libtui.lib` is
   85 x 26, `libtui_128x35.lib` is 128 x 35; `LIBS=tui` resolves to the
   chosen one. Both archives are built and shipped in the SDK. An unknown
   grid is a build error.
5. **Docs** (Must): `docs/tui.md` (geometry, memory cost, `TUI_GRID`),
   `docs/sdk.md` (the rule option, the archive), `mk/kos.mk` header.

## Tests

- the existing TUI host and replay suites, both lanes, unchanged;
- 90 x 30 reported: `tui_init` succeeds, `tui_get_size` reports 85x26,
  the fill stays inside 85 x 26;
- a `tui_test` built with `TUI_GRID=128x35` (a second program,
  `tui_wide`): 128 x 35 reported -> size 128x35; 90 x 30 -> 90x30;
  (drawing is not checked: no console displays 128 columns yet);
- the SDK package lists `libtui_128x35.lib`;
- KonaCommander links and its suites pass (`make -C
  UserSoftware/KonaCommander test`), headroom recorded.

## Budgets

| figure | now | this package | on overrun |
|---|---|---|---|
| KonaCommander BSS end vs stack base | +188 over | must fit | stop and report |

## Validation

```sh
make && make sdk
python3 -m unittest tests.test_tui tests.test_tui_sim tests.test_sdk tests.test_sdk_package tests.test_console_tee tests.test_source_layout
make -C UserSoftware/KonaCommander test
make console-serial-selftest
make clean && make check   # once, at the end
git diff --check
```

Record: `docs/validation/<date>-tui-storage.md`.
