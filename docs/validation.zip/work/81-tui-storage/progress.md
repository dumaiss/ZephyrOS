# Package 81: libtui storage - progress (working memory, present tense)

Status: COMPLETE, final gate green.

## Tree at start

HEAD + uncommitted package 80 (preserved).

## Done

- Attribute store: `tui_chars[]` + `tui_attrs[]` (4 bits, two cells per
  byte), `tui_priv_attr`/`tui_priv_store` in tui_state.c; all 21 accesses
  converted; `struct tui_cell` stays the save/restore format.
- `tui_append_dec` takes three digits (a 128-column grid's columns).
- Clamp in `tui_init` (only a zero dimension is refused).
- `console_info`: `memset` + op + call + copy.
- KonaCommander: links, 10 + 7 + 1 OK, headroom 868 bytes (was -188).
- `TUI_GRID`: `TUI_GRID_COLS/ROWS` in tui_internal.h (default 85/26);
  `libtui_128x35.lib` built in exe.mk, shipped by sdkpack
  (`--libtui-wide`), pinned in test_sdk_package; mk/kos.mk
  `KOS_TUI_GRIDS := 85x26 128x35`, `$(1)_GRID`, unknown grid -> $(error);
  checked with the shipped SDK (85x26 -> libtui.lib, 128x35 ->
  libtui_128x35.lib, 99x9 -> stop).
- Tests: grid mode doc; `gridsize` mode; `tui_wide` program
  (TUI_GRID=128x35) in the replay store; 90x30 -> clamped 85x26 (was
  "fails init": test artifact, WORK.md requirement 3);
  `test_the_wide_build_adopts_a_wide_grid` (128x35, 90x30). V9958: 4 OK.
- Docs: tui.md, sdk.md, architecture 5.6.

- `make console-serial-selftest` 6 OK. Map (tui_core_probe): chars
  2,210, attrs 1,105, dirty 277, invert 277.
- Batch (tui, tui_sim both lanes, sdk, sdk_package, tee, layout): 185
  run, 3 failed, all test artifacts:
  `test_flush_groups_runs_by_attribute_and_emits_both_sgr_forms` and
  `test_one_cell_map_and_two_classification_bitmaps` pinned the 2-byte
  `tui_cells` (WORK.md requirement 1); `test_sdk` program list lacked
  `tui_wide` (requirement 4 adds it). Retargeted; test_tui + test_sdk
  56 OK. The replay suites passed in the batch.

## Next action

Final gate: make clean && make check; console-serial-selftest;
KonaCommander; record.
