# The EXE executable format

An EXE file is a native KonaOS program: a primary image plus zero or more
auxiliary segments. It is stored in the ROM store (`docs/romfs-format.md`)
or on the card, loaded into one primary bank `0-5` (plus auxiliary banks
for its segments), and entered in mode 10. The loader is
`kernel/process/exec.c`; the host packer (`tools/exepack.py`) applies every
check the loader applies, so a bad link never reaches a store. The rules
are in `docs/architecture.md` section 6.7.

## 1. Logical load address

Every primary image is linked as a flat image whose first byte
executes at logical address `0100h`:

```text
0100h                 start of the primary image
0100h + image_size    start of the primary BSS (zero-filled by the loader)
...                   free process memory
E000h - stack_size    initial SP (stack grows downward from E000h)
E000h                 permanent common memory begins
```

The logical addresses are independent of the physical application bank:
the same bytes run unchanged in bank 0, 1, ..., 5.  There is no base
relocation.

## 2. Header

The header is 36 bytes, little-endian for every field:

| Offset | Size | Field | Value / meaning |
| --- | --- | --- | --- |
| `00h` | 4 | `magic` | ASCII `KEX2` (`4B 45 58 32`) |
| `04h` | 1 | `format_version` | `2` |
| `05h` | 1 | `abi_version` | `1` |
| `06h` | 1 | `flags` | `0` (no flags defined) |
| `07h` | 1 | `reserved0` | `0` |
| `08h` | 2 | `header_size` | `36` |
| `0Ah` | 1 | `segment_count` | segment-table rows, `0..8` |
| `0Bh` | 1 | `total_segment_slots` | whole 8-KiB slots all segments need |
| `0Ch` | 2 | `image_size` | bytes of primary image, `> 0` |
| `0Eh` | 2 | `bss_size` | zero-initialized bytes after the primary image |
| `10h` | 2 | `entry_offset` | entry = `0100h + entry_offset` |
| `12h` | 2 | `stack_size` | initial stack size, `>= 2` |
| `14h` | 4 | `segment_table_offset` | file offset of the segment table |
| `18h` | 4 | `primary_payload_offset` | file offset of the primary payload |
| `1Ch` | 4 | `file_size` | total container size |
| `20h` | 4 | `reserved1` | `0` |

Every file offset and the total size are 32-bit, so a container may
exceed 64 KiB.  After the header come, in file order: the primary
payload, the segment table (`segment_count` rows) and the segment
payloads (4-byte aligned); the packer emits exactly this layout.

## 3. Segment table

One 16-byte row per segment, in ascending id order from 1:

| Offset | Size | Field | Value / meaning |
| --- | --- | --- | --- |
| `00h` | 1 | `id` | `1..segment_count`, ascending |
| `01h` | 1 | `kind` | `EXE_SEG_KIND_*` (`1` far code, `2` data) |
| `02h` | 2 | `image_size` | bytes copied into the segment's memory |
| `04h` | 2 | `bss_size` | zero-initialized bytes after the image |
| `06h` | 2 | `flags` | `EXE_SEG_FLAG_*` (`1` mappable `DATA`); `0` otherwise |
| `08h` | 4 | `payload_offset` | file offset of the segment payload |
| `0Ch` | 4 | `reserved1` | `0` |

- **`DATA` segments** become extended-memory objects owned by the process
  (architecture 4.8): the loader places them before the program runs,
  and `SYS_SEG_INFO` names each one and returns the handle that
  `SYS_XMEM_READ`/`SYS_XMEM_WRITE` use.  A loader segment is
  released only at exit; `SYS_XMEM_FREE` refuses it.
- **`flags` bit 0 (`EXE_SEG_FLAG_MAPPABLE`)** is valid on a
  `DATA` row and nowhere else: the loader places such a segment in the
  aperture slice of an auxiliary bank, so its image is at `8000h` where
  the link put it, the loader zeroes its BSS right after, and the object
  carries `KOS_XMEM_FLAG_MAPPABLE` - `SYS_XMEM_MAP` returns the token
  that opens the aperture onto it.  `SYS_SEG_INFO` reports the row's
  flags, so a program finds its far data by scanning its own segments.
  The row is limited to the 16 KiB aperture, exactly as a far-code row is,
  and one mappable row costs one auxiliary bank, as a far-code row does.
- **`FAR_CODE` segments** are linked at `8000h` and executed in place
  through the aperture: the loader places each one in the aperture slice
  of its own auxiliary bank (one far-code segment per bank), and
  `SYS_SEG_MAP` returns the token that opens it.  A
  far-code segment has no handle: `SYS_SEG_INFO` reports `0`.

## 4. Geometry rules

Validated in this order (first violation wins); the codes are also the
`process_exec()` result values (`formats/include/exe.h`):

| Order | Check | Failure code |
| --- | --- | --- |
| 1 | magic is `KEX2` | `EXE_EXEC_ERR_MAGIC` |
| 2 | `format_version == 2` | `EXE_EXEC_ERR_FORMAT` |
| 3 | `abi_version == 1` | `EXE_EXEC_ERR_ABI` |
| 4 | `flags == 0` | `EXE_EXEC_ERR_FLAGS` |
| 5 | `reserved0 == 0` | `EXE_EXEC_ERR_RESERVED0` |
| 6 | `header_size == 36` | `EXE_EXEC_ERR_HEADER` |
| 7 | `reserved1 == 0` | `EXE_EXEC_ERR_RESERVED1` |
| 8 | `image_size > 0` | `EXE_EXEC_ERR_IMAGE` |
| 9 | file size == `file_size` | `EXE_EXEC_ERR_FILESIZE` |
| 10 | `entry_offset < image_size` | `EXE_EXEC_ERR_ENTRY` |
| 11 | `stack_size >= 2` | `EXE_EXEC_ERR_STACK` |
| 12 | `segment_count <= 8` and `total_segment_slots <= 20` | `EXE_EXEC_ERR_SEG_SLOTS` |
| 13 | table inside the file | `EXE_EXEC_ERR_SEG_TABLE` |
| 14 | primary payload inside the file | `EXE_EXEC_ERR_FILESIZE` |
| 15 | `0100h + image_size <= E000h` | `EXE_EXEC_ERR_IMAGE_END` |
| 16 | `image_end + bss_size <= E000h` | `EXE_EXEC_ERR_BSS_END` |
| 17 | `stack_base >= 0100h` and `stack_base >= bss_end` | `EXE_EXEC_ERR_COLLISION` |
| 18 | row kind is `DATA` or `FAR_CODE` | `EXE_EXEC_ERR_SEG_KIND` |
| 19 | row geometry: non-empty, `image + bss` within its kind's limit (`DATA` 32 KiB, `FAR_CODE` 16 KiB, 16 KiB for a mappable `DATA` row), `flags` only `EXE_SEG_FLAG_MAPPABLE` and only on `DATA`, reserved zero, payload inside the file | `EXE_EXEC_ERR_SEGMENT` |
| 20 | row ids are `1..segment_count` in order | `EXE_EXEC_ERR_SEGMENT` |
| 21 | row slot sums equal `total_segment_slots` | `EXE_EXEC_ERR_SEG_SLOTS` |

Checks 1-14 and 12-13 are the loader's **one up-front feasibility check**
from the header alone: every count and size the load needs, read
before a slot, a bank or a byte changes.  Checks 15-17 are part of that
same header validation; checks 18-21 are the protective bounds applied to
the table as it is read, before anything is allocated.

The slot total is 20 because a `DATA` object is contiguous inside one
bank and takes at most the four non-aperture slots of its bank, and the
child's primary bank can never hold auxiliary slots - five banks' worth
is the most a container can place.  The same bound covers far code: a
`FAR_CODE` segment occupies the aperture slice of its own bank (one far
segment per bank, at most two slots) and the packer sums every row's
slots into this one field.

The loader adds these result codes around the geometry checks:
`EXE_EXEC_ERR_ARG` (null argument / invalid request),
`EXE_EXEC_ERR_ROMFS` (name not found), `EXE_EXEC_ERR_TYPE` (entry is not
an EXE), `EXE_EXEC_ERR_NOSPACE` (no free process slot, bank, auxiliary
run or object-table entry), `EXE_EXEC_ERR_READ` (payload read or copy
failed).  All arithmetic is done in 32 bits so 16-bit wrap can never mark
an out-of-range geometry valid.

## 5. Link layout contract

Every EXE is linked by the SDK's program rule (`mk/kos.mk`,
`docs/sdk.md`), which derives the manifest from the link map; the
linker script and the packer must both agree with the resulting map:

- `_CODE` is linked at `0100h`; the linked bytes must be entirely inside
  `[0100h, 0100h + image_size)`;
- `_DATA` is linked at `0100h + image_size` and must satisfy
  `s__DATA == 0100h + image_size` (`s__DATA` proves where BSS starts) and
  `l__DATA <= bss_size`;
- initialized writable data is not supported:
  `l__INITIALIZER` and `l__INITIALIZED` must be zero, so every static
  starts zeroed;
- the declared entry symbol must resolve to exactly
  `0100h + entry_offset`;
- the runtime scratch symbol (`kos_scratch`) must lie inside the
  syscall argument window `0100h-1FFFh`, so it remains accessible in
  mode `10` and in mode `11`.

The SDK links crt0 and the shared runtime object first (`crt0.rel
runtime.rel <program>`, then `libkos`), so the scratch block always sits
at the start of `_DATA`, ahead of the program's own statics: the whole
program, its statics and the scratch stay below `2000h` even when the
program's BSS is large.  The manifest
`scratch` field names that one symbol per program; a program linked
without crt0 (the raw-return test child) declares no scratch at all.

A `DATA` segment is declared in the manifest with a raw payload file and
a BSS size (`SEGMENTS=` on the `exe_program` line); the packer derives
its `image_size` from the payload file and lays out the table.

A **mappable `DATA` segment** (far data) is declared the same
way plus `"flags": 1`, or with a linker `area`/`bss_area` pair instead of
a payload file: the SDK rule compiles a `DATA<n>=` source with
`--constseg DATA<n> --dataseg DATA<n>B` and the link bases both areas at
`8000h`, so the row's image is `l__DATA<n>` bytes of `const` objects at
`8000h` and its BSS is the whole `_DATA<n>B` area, which must start
exactly where the image ends (`s__<bss_area> == s__<area> + l__<area>`) -
the loader zeroes it there.  A `DATAn=` source may hold `const` objects
and zeroed ones only: an initialized writable object would need the
`_INITIALIZED`/`_INITIALIZER` areas, which the format has no startup
support for, and the packer refuses it by name.

A **`FAR_CODE` segment** is declared with a linker `area` instead
(`{"id": 1, "kind": "FAR_CODE", "area": "_FAR1", "bss_size": 0}`): the
rule compiles the program's `FAR<n>=` sources with bank n and
`--codeseg FAR<n>` and the link bases `_FAR<n>` at `8000h`
(`-b _FAR<n> = 0x8000`), so the area is resolved by the program's own
link and the packer takes its bytes from the program's IHX (holes
zero-filled) using the map's `s__FAR<n>`/`l__FAR<n>` symbols.  A
`FAR_CODE` row's id is the number in its area name - `_FAR<n>` is segment
n, the number the module's `__banked` definitions emit as `b_<fn>` - and
the far rows are the container's first segments, ids
`1..k` for the `FAR1=`..`FARK=` options used, with the `DATA` rows after
them.  Every far area is its own IHX record stream in link order, all of
them at `8000h`: the packer reads each area's payload from its own
stream.  With no `SEGMENTS=` the rule generates the declaration itself,
one `FAR_CODE` row per option used.

Every declaration is checked against the **far link rule**: a program
with far code or far data must keep its primary image and BSS below
`8000h` and its stack base at or above `C000h`, so the aperture
`8000h-BFFFh` belongs to segments alone; a far area's `image + bss` is at most 16 KiB and each
auxiliary bank holds at most one far segment.  `tools/exepack.py` rejects
any violation, so the generic rule cannot pack a program that the kernel
would later refuse.

## 6. Load sequence

`process_exec(path)` (the boot launcher) and `SYS_EXEC` (`docs/abi.md`
section 5.3, an ordinary process) both run the same two
steps: `process_prepare()` loads, then `process_launch()` enters.

`process_prepare()` performs:

1. bind the path through the namespace and require a FILE object (the
   media gate: a `/system` entry must carry `ROMFS_FLAG_EXE`);
2. read the file size and the header;
3. run the one up-front feasibility check from the header;
4. read the segment table and validate every row;
5. allocate a process slot (fails with `EXE_EXEC_ERR_NOSPACE` if none is
   free), the child's VFS state and the lowest free application bank
   `0-5`;
6. place the container's segments (fails with `EXE_EXEC_ERR_NOSPACE`,
   rolled back completely): a `DATA` segment becomes an extended-memory
   object owned by the child, a `FAR_CODE` segment takes the aperture
   slice of its own auxiliary bank (one far segment per bank, token from
   `SYS_SEG_MAP`, no handle);
7. write the native page-zero vector at `0030h`: `C3` followed by the
   entry address (the `RST 30h` gateway from `docs/abi.md`);
8. copy the primary payload in 64-byte chunks from the source through the
   common `kos_user_copy_staging` block into the bank at `0100h`;
9. zero the primary BSS region `[0100h + image_size, + bss_size)`;
10. copy each segment payload into its object and zero the segment BSS;
11. close the executable source, then build startup block v1 (below) and
    write it into the child's page zero at `0080h`;
12. return the prepared child.

**Memory initialization:** the loader zeroes only
the primary BSS, each segment's BSS, the startup block and the page-zero
vector.  There is **no whole-bank clear**: the rest of the child's bank
and every extended-memory object keep whatever the previous process left
there, and a program must not read outside its image, its BSS, its stack
and the startup block.

`process_launch()` then marks the descriptor RUNNING and enters the
common process-launch gate, which saves the launcher's continuation,
switches to mode `10 | bank`, installs `SP = E000h - stack_size`, and
transfers to the entry with `HL = 0080h` (the startup block pointer).  It
performs no check that can fail: every fallible step (including the
SYS_EXEC depth, frame-size and argument preflight) happened before the
suspension point.

### 6.1 Startup block v1

Every native process, including the kernel launcher's, receives a valid
startup block in its own page zero:

```text
0080h  u8   version = 1
0081h  u8   tail_length  0..125
0082h  u8   tail[126]    tail_length raw bytes, then one NUL
```

`SYS_EXEC` copies the caller's raw tail (`args`, `args_length`) here
byte-exact; the kernel launcher passes an empty tail.  The block lives in
the caller-visible low window so it is readable in modes `10` and `11`,
but it is *below* the `0100h` syscall buffer window, so a program must
copy the tail into its own data before handing it to a syscall.

`user/sdk/` is the first-party user-space runtime for it: crt0
(`user/sdk/src/crt0.asm`, entry symbol `kos_entry`) receives the block in
`HL`, stores the pointer for `startup()` before anything clobbers `HL`,
runs `splitargs()` over the raw tail, calls `int main(int argc, char
**argv)` and exits through `SYS_EXIT` with the returned status.  A
program writes no entry assembly; `startup()` returns the kernel's
page-zero block for programs that inspect it at entry, and crt0 copies
the tail into the SDK's own buffer before `splitargs()` parses it *in
place* there, so `argv` points into program data rather than at a
delivery the syscall path is free to reuse.

#### Tail splitting (runtime policy)

`splitargs(char *tail, char **argv, int max)` splits the NUL-terminated
tail in place and returns the total word count, storing at most `max`
pointers.  It is the one parser the shell and every program's startup
share, so a child's `argv` always agrees with the words the shell ran it
with.  The rules are runtime policy, not an ABI, and may change without
any kernel work:

- words are separated by whitespace: one or more spaces (`0x20`) or
  tabs (`0x09`); leading and trailing separators are ignored;
- a single quote (`'`) toggles a literal section: separators,
  backslashes and double quotes inside it are ordinary characters, and
  the quotes themselves are removed;
- a double quote (`"`) toggles a quoted section whose separators are
  literal and whose quotes are removed.  Inside it `\"` is a `"` and
  `\\` is a `\`; every other backslash is an ordinary character;
- outside both quotes `\x` is a literal `x` (so `a\ b` is one word
  containing a space), and a backslash at the end of the tail stands for
  itself;
- adjacent quoted and unquoted runs join into one word (so `ab"c d"e`
  is the single word `abc de`);
- an empty quoted word (`''` or `""`) is an empty argument;
- an unterminated quote runs to the end of the tail;
- a NUL byte ends the tail; there is no other metacharacter;
- `argv[0]` is the first argument: the kernel does not pass a program
  name, so there is no `argv[0]` convention for it.

The kernel preflight refuses a 126-byte tail and a tail pointer outside
the window with `KOS_EINVAL` before allocating. `tests/test_fs_selftest_sim.py`
checks a child's exact `argv` across these cases.

A raw `RET` from the entry point lands in a common trap and exits the
process with `KOS_EFAULT`; programs leave through `SYS_EXIT` only.

Failure inside `process_prepare()` releases the slot, the bank
reservation, the child's CWD slot, every descriptor it opened and every
segment object it created, and closes the source before returning the
result code, so a rejected program leaves the process table, the bank
allocator, the object table, the caller bank, and the parent context
unchanged (the subsystem image's loader-outcome programs and the
simulator tests check this).

A child started by `SYS_EXEC` is a full ordinary process: a fresh
application bank, its own page zero, its own extended-memory segments,
its own VFS process state (it *inherits* the parent's CWD and *not* the
parent's descriptors), and its exit status handed back as the `SYS_EXEC`
result.  Up to `KOS_EXEC_MAX_DEPTH` (4) user processes may be suspended
in one chain; the suspension cost is the gate-stack frame described in
`docs/memory.md` and `docs/abi.md`.

## 7. Runtime

The SDK (`docs/sdk.md`) is the C runtime for EXE programs: `crt0` and
`libkos`, wrappers around `RST 30h` with SDCC's `sdcccall(1)` convention.
Negative returns are `-errno`. The wrappers share one argument scratch
(`kos_scratch`, in `user/sdk/src/runtime.asm`), which is why the scratch
symbol must satisfy the window rule above. The process wrappers are
`exit(int)`, `getinfo()`, `run(path, args)`, `startup()` and `splitargs()`
(`kos/process.h`, `kos/console.h`); segments are reached with `seginfo`,
`segmap`, `farcall`, `__banked` calls and `farmap` (`kos/seg.h`).

## 8. Tooling

```sh
python3 tools/exemanifest.py build/user/exetest/exetest.map \
        build/user/exetest/exetest.json --name exetest.exe \
        --entry kos_entry --stack 256 --scratch kos_scratch:16
python3 tools/exepack.py get      build/user/exetest/exetest.json image_size
python3 tools/exepack.py pack     build/user/exetest/exetest.json out.exe \
        --objdir build/user/exetest --report out.report.json
python3 tools/exepack.py validate out.exe
python3 tools/exepack.py dump     out.exe
```

`tools/exemanifest.py` derives `image_size`, `bss_size` and
`entry_offset` from the link map, so no size is ever hand-entered, and
`--segments FILE` merges a JSON list of `DATA` segment declarations
(`id`, `kind`, `input`, `bss_size`); the packer resolves `input` against
`--objdir`, derives each segment's `image_size` from the payload file and
lays out the table.  The packer output (image bytes, report JSON) is
byte-deterministic; the report carries the header fields, image/BSS/stack
geometry, entry symbol resolution, the segment table and sha256 digests.
`make exe-test` packs, validates and dumps a test program and runs the
host suite (`tests/test_exe.py`) that pins `exepack.py`'s constants and
result codes to `formats/include/exe.h`.
